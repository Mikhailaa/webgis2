#pragma once
#include "pch.h"

int calcWidthStep(int width, int depth, int channels, int a4);

class IImageControlR
{
public:
	IImageControlR() {};
	virtual ~IImageControlR() {};
	virtual int width(void) = 0;
	virtual int height(void) = 0;
	virtual int nChannels(void) = 0;
	virtual uchar* pdata(void) = 0;
	virtual int depth(void) = 0;
	virtual int depthPix(void) { return depth() * nChannels(); };
	virtual int widthStep(void) { return (width() * depth() * nChannels() / 8 + 3) / 4 * 4; };
	virtual int sizeData(void) { return height() * widthStep(); };
	virtual uchar* line(int l) { return pdata() + widthStep() * l; };
	virtual uchar* point(int x, int y) { return line(y) + depthPix() * x / 8; };
};

class MatImage : public IImageControlR
{
public:
	MatImage() {};
	~MatImage() {};
	int width(void) { return m_vMI_4.cols; };
	int height(void) { return m_vMI_4.rows; };
	int nChannels(void) { return m_vMI_4.channels(); };
	uchar* pdata(void) { return m_vMI_4.data; };
	int depth(void) { 
		int dword_108BBB0[8] = { 8, 8, 0x10, 0x10, 0x20, 0x20, 0x40, 0 };
		return dword_108BBB0[m_vMI_4.flags & 7]; 
	};
	int widthStep(void) { return width() * depth() * nChannels() / 8; };

	/*void load(IImageControlR &a2)
	{
		Mat m(a2.height(), a2.width(), 8 * a2.nChannels() - 8, a2.pdata(), a2.widthStep());
		m.copyTo(m_vMI_4);
	}*/
public:
	Mat m_vMI_4;
};

class IImageControl : public IImageControlR
{
public:
	IImageControl() {};
	~IImageControl() {};
	
	virtual void reset(void) { free(); zeroize(); };
	virtual int create(int width, int height, int depth, int channels)
	{
		free();
		setWidth(width);
		setHeight(height);
		setnChannels(channels);
		setDepth(depth);
		setWidthStep(IImageControlR::widthStep());
		setSizeData(sizeData());
		uchar* pd = new uchar[sizeData()];
		setpData(pd);
		if (pdata())
			return 0;
		zeroize();
		return 1;
	};
	virtual void setWidth(int) = 0;
	virtual void setHeight(int) = 0;
	virtual void setnChannels(int) = 0;
	virtual void setDepth(int) = 0;
	virtual void setpData(uchar *) = 0;
	virtual void setSizeData(int a2) { };
	virtual void setWidthStep(int a2) { };
	virtual void free(void)
	{
		if (pdata()) delete[] pdata();
		setpData(0);
	};
	virtual void zeroize(void)
	{
		setWidth(0);
		setHeight(0);
		setnChannels(0);
		setDepth(0);
		setpData(0);
		setSizeData(0);
	};

	int create(tagSIZE sz, int depth, int channels)
	{
		return create(sz.cx, sz.cy, depth, channels);
	};

	int load(IImageControlR &a2)
	{
		int res = 1;
		if (width() == a2.width() && height() == a2.height() && nChannels() == a2.nChannels() && depth() == a2.depth())
			res = 0;
		if (res)
			res = create(a2.width(), a2.height(), a2.depth(), a2.nChannels());
		if (!res)
		{
			if (widthStep() == a2.widthStep())
			{
				memcpy(pdata(), a2.pdata(), a2.sizeData());
			}
			else
			{
				int ws = min(widthStep(), a2.widthStep());
				for (int i = 0; i < height(); ++i)
				{
					memcpy(line(i), a2.line(i), ws);
				}
			}
		}
		return res;
	};
};

class RawImageContainer : public TRawImageContainer
{
public:
	RawImageContainer()
	{
		this->pxRIC_bmi = 0;
		this->pRIC_data = 0;
		this->pxRIC_bmi = new tagBITMAPINFO;
		memclr(this->pxRIC_bmi, sizeof(tagBITMAPINFO));
		this->pxRIC_bmi->bmiHeader.biPlanes = 1;
		this->pxRIC_bmi->bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	}
	~RawImageContainer()
	{
		delete[] pxRIC_bmi;
		delete[] pRIC_data;
	}
	int load(tagBITMAPINFO *pbmi, uchar *pdata)
	{
		if (!this->pxRIC_bmi)
		{
			this->pxRIC_bmi = new tagBITMAPINFO;
		}
		memcpy(this->pxRIC_bmi, pbmi, sizeof(tagBITMAPINFO));
		delete[] this->pRIC_data;
		this->pRIC_data = new uchar[pbmi->bmiHeader.biSizeImage];
		memcpy(this->pRIC_data, pdata, pbmi->bmiHeader.biSizeImage);
		return 0;
	}
};

class RawImageContainerR : public TRawImageContainer
{
public:
	RawImageContainerR()
	{
		this->pxRIC_bmi = 0;
		this->pRIC_data = 0;
		this->pxRIC_bmi = new tagBITMAPINFO;
		memclr(this->pxRIC_bmi, sizeof(tagBITMAPINFO));
		this->pxRIC_bmi->bmiHeader.biPlanes = 1;
		this->pxRIC_bmi->bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	};
	~RawImageContainerR()
	{
		delete[] pxRIC_bmi;
		delete[] pRIC_data;
	};
	int depth()
	{
		if (this->pxRIC_bmi)
		{
			ushort v2 = this->pxRIC_bmi->bmiHeader.biBitCount;
			if (v2 >= 8)
				return v2 / (v2 >> 3);
		}
		return 0;
	}
	int widthStep()
	{
		int width = this->pxRIC_bmi ? this->pxRIC_bmi->bmiHeader.biWidth : 0;
		int depth = RawImageContainerR::depth();
		int nChannels = this->pxRIC_bmi ? (this->pxRIC_bmi->bmiHeader.biBitCount >> 3) : 0;
		return calcWidthStep(width, depth, nChannels, 4);
	}
};

class CRawImageContainer : public IImageControl, RawImageContainer
{
public:
	CRawImageContainer() {};
	~CRawImageContainer() {};
	int width(void) { return this->pxRIC_bmi->bmiHeader.biWidth; };
	int height(void) { return this->pxRIC_bmi->bmiHeader.biHeight; };
	int	nChannels(void) { return this->pxRIC_bmi->bmiHeader.biBitCount >> 3; };
	uchar* pdata(void) { return this->pRIC_data; };
	int depth(void) { return this->pxRIC_bmi->bmiHeader.biBitCount; };
	int widthStep(void) { return (width() * depth() / 8 + 3) / 4 * 4; };
	int create(int width, int height, int depth, int channels) {
		int res = IImageControl::create(width, height, depth, channels);
		if (!res)
			initColorMap(depth, this->pxRIC_bmi->bmiColors);
		return res;
	};
	void setWidth(int width) { this->pxRIC_bmi->bmiHeader.biWidth = width; };
	void setHeight(int height) { this->pxRIC_bmi->bmiHeader.biHeight = height; };
	void setnChannels(int ch ) { this->pxRIC_bmi->bmiHeader.biBitCount = 8 * ch; };
	void setDepth(int depth) { this->pxRIC_bmi->bmiHeader.biBitCount = depth; };
	void setpData(uchar *pd) { this->pRIC_data = pd; };
	void setSizeData(int size) { this->pxRIC_bmi->bmiHeader.biSizeImage = size; };
	void zeroize(void) { this->pRIC_data = 0; };
	
	void initColorMap(int depth, tagRGBQUAD *colors)
	{
		int i;
		ulong* clr = (ulong*)colors;
		switch (depth)
		{
		case 1:
			for (i = 0; i < 2; ++i)
				clr[i] = 0x1010101 * (uchar)(0 - i);
			break;
		case 4:
			for (i = 0; i < 16; ++i)
				clr[i] = 0x1010101 * (uchar)(0 - i);
			break;
		case 8:
			for (i = 0; i < 256;++i)
				clr[i] = 0x1010101 * i;
			break;
		}
	}

	void setResolution(int a2, int a3)
	{
		this->pxRIC_bmi->bmiHeader.biYPelsPerMeter = a3;
		this->pxRIC_bmi->bmiHeader.biXPelsPerMeter = a2;
	}
};

class IImageControlRef : public IImageControl
{
public:
	IImageControlRef() {};
	~IImageControlRef() {};
	void reset(void) { free(); zeroize(); };
	void free(void) 
	{
		if (ownData()) 
			IImageControl::free();
		else
		{
			setpData(0);
			setOwnData(true);
		}
	};
	void zeroize(void) { 
		setWidthStep(0);
		setOwnData(true);
		IImageControl::zeroize();
	};

	virtual bool ownData(void) = 0;
	virtual void setOwnData(bool) = 0;
	virtual int fref(int w, int h, uchar *p, int ws, int d, int ch)
	{
		if (!p)
			return 1;
		setOwnData(false);
		setWidth(w);
		setHeight(h);
		setpData(p);
		setWidthStep(ws);
		setnChannels(ch);
		setDepth(d);
		setSizeData(ws * h);
		return 0;
	};

	int ref(IImageControlR & a2)
	{
		return fref(a2.width(), a2.height(), a2.pdata(), a2.widthStep(), a2.depth(), a2.nChannels());
	};

	int ref(IImageControlR &a2, int x, int y, int w, int h)
	{
		return fref(w, h, a2.pdata() + a2.widthStep() * y + a2.depthPix() / 8 * x, a2.widthStep(), a2.depth(), a2.nChannels());
	};

	int ref(IImageControlR &a2, tagPOINT const&pt, tagSIZE const&sz)
	{
		return fref(sz.cx, sz.cy, a2.pdata() + pt.y * a2.widthStep() + a2.depthPix() / 8 * pt.x, a2.widthStep(), a2.depth(), a2.nChannels());
	};

	int ref(IImageControlR &a2, tagRECT const&rc)
	{
		return fref(rc.right - rc.left, max(rc.top, rc.bottom) - min(rc.top, rc.bottom), 
			a2.pdata() + min(rc.top, rc.bottom) * a2.widthStep() + a2.depthPix() / 8 * rc.left, a2.widthStep(), a2.depth(), a2.nChannels());
	};

	int ref(int width, int height, uchar *pdata, int ws, int depth, int ch)
	{
		if (ws == -1)
			ws = calcWidthStep(width, depth, ch, 4);
		return fref(width, height, pdata, ws, depth, ch);
	}
};

class CBufferImage : public IImageControlRef
{
public:
	CBufferImage() { IImageControlRef::zeroize(); };
	~CBufferImage() { IImageControlRef::free(); };
	int width(void) { return m_nBI_width; };
	int height(void) { return m_nBI_height; };
	int nChannels(void) { return m_nBI_channels; };
	uchar* pdata(void) { return m_pBI_Data; };
	int depth(void) { return m_nBI_depth; };
	int widthStep(void) { return m_nBI_widthstep; };
	void setWidth(int w) { m_nBI_width = w; };
	void setHeight(int h) { m_nBI_height = h; };
	void setnChannels(int ch) { m_nBI_channels = ch; };
	void setDepth(int d) { m_nBI_depth = d; };
	void setpData(uchar *p) { m_pBI_Data = p; };
	void setWidthStep(int ws) { m_nBI_widthstep = ws; };
	bool ownData(void){ return m_fBI_own; };
	void setOwnData(bool f){ m_fBI_own = f; };

protected:
	bool m_fBI_own;
	int m_nBI_width;
	int m_nBI_height;
	int m_nBI_channels;
	int m_nBI_depth;
	int m_nBI_widthstep;
	uchar *m_pBI_Data;
};