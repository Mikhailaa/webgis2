#pragma once
#include "pch.h"
#include "imaging.h"

class IImageHelper
{
public:
	TResultContainer *m_pxIHL_4;
	int(*m_pfIHL_8)(imaging::eRI_Commands, imaging::RI_Parameters *);

	IImageHelper();
	virtual ~IImageHelper();
	virtual void Release();
	int InitFromBuffer(uchar *, uint);
	static TResultContainer *AllocResultContainer(TResultContainer *);
	static TRawImageContainer *FullDuplicateTRawImageContainer(TRawImageContainer *a1);
	void ReleaseImage();
	int WriteToBuffer(imaging::RI_SaveFileParameters *);
	int GetImageInfoFromBuffer(uchar *, uint, imaging::RI_ImageInfo *);
	TRawImageContainer *GetRawImageContainer(void);
	int WriteToFile(imaging::RI_SaveFileParameters *);
	int WriteToFile(wchar_t const*, imaging::eRI_ImageFormats);
	TResultContainer *init(TResultContainer *a2);
};

class CImageHelperLib : public IImageHelper
{
public:
	CImageHelperLib();
	virtual ~CImageHelperLib();
	virtual void Release();
};

class CImageHelper : public CImageHelperLib
{
public:
	CImageHelper() {};
	virtual ~CImageHelper() {};
};

