#include "packageversion.h"
#include "common/resources.h"

namespace packageversion
{
	string getCoreMode(void)
	{
		return string("fullrfid");
	}

	string getCoreVersion(void)
	{
		return string("5.2.3421");
	}

	string getDocList(void)
	{
		static string dataJson;
		if (dataJson.empty())
			common::resources::getFile(0, string("db.json"), dataJson);
		return dataJson;
	}
}