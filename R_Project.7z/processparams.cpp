#include "processparams.h"
#include "common/common.h"

namespace processparams
{
	namespace ProcessModeConvertor
	{
		eProcessMode convert(string const & a2)
		{
			return common::mapValues(getMap(), a2, PROCESSMODE_0);
		}

		unordered_map<string, eProcessMode> getMap(void)
		{
			unordered_map<string, eProcessMode> ret = {
				unordered_map<string, eProcessMode>::value_type(string("creditcard"), PROCESSMODE_creditcard),
				unordered_map<string, eProcessMode>::value_type(string("debugSaveLogs"), PROCESSMODE_debugSaveLogs),
				unordered_map<string, eProcessMode>::value_type(string("debugSaveImages"), PROCESSMODE_debugSaveImages),
				unordered_map<string, eProcessMode>::value_type(string("debugSaveImagesCroppedByFrame"), PROCESSMODE_debugSaveImagesCroppedByFrame),
				unordered_map<string, eProcessMode>::value_type(string("debugSaveCroppedImages"), PROCESSMODE_debugSaveCroppedImages),
				unordered_map<string, eProcessMode>::value_type(string("rfid"), PROCESSMODE_rfid),
				unordered_map<string, eProcessMode>::value_type(string("lex"), PROCESSMODE_lex),
				unordered_map<string, eProcessMode>::value_type(string("id3Rus"), PROCESSMODE_id3Rus),
				unordered_map<string, eProcessMode>::value_type(string("multipageProcessing"), PROCESSMODE_multipageProcessing),
				unordered_map<string, eProcessMode>::value_type(string("uvTorchPresent"), PROCESSMODE_uvTorchPresent),
				unordered_map<string, eProcessMode>::value_type(string("disableFocusingCheck"), PROCESSMODE_disableFocusingCheck),
				unordered_map<string, eProcessMode>::value_type(string("switchToUvProcessImage"), PROCESSMODE_switchToUvProcessImage),
				unordered_map<string, eProcessMode>::value_type(string("returnUncroppedImage"), PROCESSMODE_returnUncroppedImage),
				unordered_map<string, eProcessMode>::value_type(string("doublePageSpread"), PROCESSMODE_doublePageSpread),
				unordered_map<string, eProcessMode>::value_type(string("manualCrop"), PROCESSMODE_manualCrop)
			};
			return ret;
		}

		string convert(eProcessMode a2)
		{
			string str;
			vector<string> v9 = common::mapKeys(getMap(), a2);
			if (!v9.empty())
				return v9[0];
			return str;
		}
	}
}