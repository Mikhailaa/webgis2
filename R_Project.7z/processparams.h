#pragma once
#include "pch.h"

namespace processparams
{
	enum eProcessMode
	{
		PROCESSMODE_0,
		PROCESSMODE_creditcard,
		PROCESSMODE_debugSaveLogs,
		PROCESSMODE_debugSaveImages,
		PROCESSMODE_debugSaveImagesCroppedByFrame,
		PROCESSMODE_debugSaveCroppedImages,
		PROCESSMODE_rfid,
		PROCESSMODE_lex,
		PROCESSMODE_id3Rus,
		PROCESSMODE_multipageProcessing,
		PROCESSMODE_uvTorchPresent,
		PROCESSMODE_disableFocusingCheck,
		PROCESSMODE_switchToUvProcessImage,
		PROCESSMODE_returnUncroppedImage,
		PROCESSMODE_doublePageSpread,
		PROCESSMODE_manualCrop
	};

	namespace ProcessModeConvertor
	{
		eProcessMode convert(string const&);
		string convert(eProcessMode);
		unordered_map<string, eProcessMode> getMap(void);
	}
}
