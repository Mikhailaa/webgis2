#include "rclhelp.h"
#include <algorithm>
#include "regula.h"
#include "common/container/jsoncpp.h"
#include "docformatinfo.h"
#include "common/resources.h"
#include "common/common.h"
#include "mrz/MRZAnalyze.h"

bool validateQACheck(TImageQualityCheckList *, eImageQualityCheckType, bool)
{
	return 0;
}

namespace rclhelp {
			
	void GetRclForPage(TResultContainerList * pRcl, int nPage_idx, RclHolder & rclHolder)
	{
		rclHolder.clear();
		RclHolder tmp(pRcl, 1);
		rclHolder.addNoCopy(tmp.getRcListByPage(nPage_idx));
	}

	bool checkImagesSize(TResultContainerList & rcl)
	{
		RclHolder rclHolder;
		rclHolder.addNoCopy(rcl);
		return checkImagesSize(rclHolder);
	}

	bool checkImagesSize(RclHolder & rclHolder)
	{
		int width = 0;
		int height = 0;

		vector<TResultContainer *> vpRc = rclHolder.getRcList(1);
		for (vector<TResultContainer *>::iterator iter = vpRc.begin(); vpRc.end() != iter; iter ++)
		{
			TRawImageContainer *pRic = (*iter)->u.pTRC_RIC;
			if (pRic && pRic->pxRIC_bmi && pRic->pRIC_data)
			{
				if (width)
				{
					if (width != pRic->pxRIC_bmi->bmiHeader.biWidth || height != pRic->pxRIC_bmi->bmiHeader.biHeight)
						return false;
				}
				else
				{
					height = pRic->pxRIC_bmi->bmiHeader.biHeight;
					width = pRic->pxRIC_bmi->bmiHeader.biWidth;
				}
			}
		}	
		
		return true;
	}

	TResultContainer container(int nResult_type, uchar * pData, uint nbuf_length)
	{
		TResultContainer rc;

		rc.nTRC_result_type = nResult_type;
		rc.nTRC_light = RPRM_Lights_0;
		rc.nTRC_buf_length = nbuf_length;
		rc.u.pTRC_UCHAR = pData;
		rc.u1.nTRC_exposure = 0;
		rc.pTRC_XML_buffer = 0;
		rc.nTRC_list_idx = 0;
		rc.nTRC_page_idx = 0;

		return rc;
	}

	TResultContainer container(int nResult_type, uchar * pData, uint nbuf_length, uint nPage_idx)
	{
		TResultContainer rc;
		
		rc.nTRC_result_type = nResult_type;
		rc.nTRC_light = RPRM_Lights_0;
		rc.nTRC_buf_length = nbuf_length;
		rc.u.pTRC_UCHAR = pData;
		rc.u1.nTRC_exposure = 0;
		rc.pTRC_XML_buffer = 0;
		rc.nTRC_list_idx = 0;
		rc.nTRC_page_idx = nPage_idx;

		return rc;
	}

	TRawImageContainer * convertPointerToRawImage(TResultContainer *pRc)
	{
		if (pRc)
			return pRc->u.pTRC_RIC;
		else
			return 0;
	}

	vector<TResultContainer> convertToContainers(vector<TResultContainer *> const& vpRc)
	{
		vector<TResultContainer> vRc;
		vRc.reserve(vpRc.size());
		for (vector<TResultContainer *>::const_iterator iter = vpRc.begin(); vpRc.end() != iter; ++iter)
		{
			vRc.push_back(**iter);
		}

		return vRc;
	}

	int deviceType(TResultContainerList &rcl)
	{
		for (uint i = 0; i < rcl.nTRCL_Count; i ++)
		{
			if (rcl.pTRCL_TRC[i].nTRC_result_type == 82 && rcl.pTRCL_TRC[i].u.pTRC_RDP)
				return rcl.pTRCL_TRC[i].u.pTRC_RDP->nRDP_DeviceType;
		}

		return -1;
	}

	int deviceTypeReal(TResultContainerList &rcl)
	{
		int res = deviceType(rcl);
		if (res == -1)
			res = 0;
		return res;
	}

	CDocFormat docFormatFromDocumentPosition(RclHolder & rclHolder)
	{
		CDocFormat res;
		vector<TBoundsResult *> vpBr = bounds::getBoundsResult(rclHolder, BoundsResultStatus_0);

		if (vpBr.empty())
			res = DOCFORMAT_3;
		else
			res = (CDocFormat)vpBr[0]->nTBR_docFormat;

		return res;
	}

	CDocFormat docFormatFromRecognizeResult(TResultContainerList const & rcl)
	{
		TResultContainer *pRc = findFirstContainer(rcl, 9);
		CDocFormat res = DOCFORMAT_3;

		if (pRc && pRc->u.pTRC_TOC)
		{
			if (pRc->u.pTRC_TOC->pxTOC_FDSIDList)
				res = (CDocFormat)pRc->u.pTRC_TOC->pxTOC_FDSIDList->nFDSIDL_dFormat;
		}
				
		return res;
	}

	CDocFormat documentFormat(TResultContainerList const & rcl)
	{
		TResultContainer * pRc = rcl.pTRCL_TRC;
		for (uint i = 0; i < rcl.nTRCL_Count; i++)
		{
			if (rcl.pTRCL_TRC[i].nTRC_result_type == 95)
				return (CDocFormat)rcl.pTRCL_TRC[i].u.nTRC_UINT;
		}

		return DOCFORMAT_UNKNOWN;				
	}

	CDocFormat documentFormatByImages(TResultContainerList & rcl, float tolerance, int * pResolution)
	{
		CDocFormat res;
		tagSIZE size; 
		int resolution = 0;

		size.cx = 0;
		size.cy = 0;

		imageParameters(rcl, resolution, size);
		if (resolution)
			res = docformatinfo::getDocFormatByMM(size.cx / resolution * 1000.0f, size.cy / resolution * 1000.0f, tolerance, DOCFORMAT_3E8);
		else
			res = docformatinfo::getDocFormatByProportion((float)size.cx, (float)size.cy, resolution, tolerance, DOCFORMAT_3E8);

		if (pResolution)
			*pResolution = resolution;

		return res;
	}

	CDocFormat documentFormatFromCLMix(TResultContainerList & rcl, int *pResolution)
	{
		CDocFormat res;
		vector<int> vdf;
		
		vdf = documentFormatsFromCLMix(rcl, pResolution);

		if (vdf.empty())
			res = DOCFORMAT_UNKNOWN;
		else
			res = (CDocFormat)vdf[0];
		
		return res;
	}

	CDocFormat documentFormatFromContainers(RclHolder & rclHolder, vector<int>& vnTypes)
	{
		CDocFormat res;
				
		for (vector<int>::iterator iter = vnTypes.begin(); vnTypes.end() != iter; iter ++)
		{
			if (*iter == 3)
			{
				res = documentFormatFromMRZOld(rclHolder.m_xTRCL);
				if (res == DOCFORMAT_UNKNOWN)
					res = DOCFORMAT_3;				
			}
			else if (*iter == 8 || *iter == 9)
			{
				res = docFormatFromRecognizeResult(rclHolder.m_xTRCL);
			}
			else if (*iter == 95)
			{
				res = getDocFormat(&rclHolder.m_xTRCL);
			}
			else if (*iter == 85)
			{
				res = docFormatFromDocumentPosition(rclHolder);
			}
			else
			{
				res = DOCFORMAT_3;
			}
			if (res != DOCFORMAT_3)
				return res;
		}
		return DOCFORMAT_3;
	}

	CDocFormat documentFormatFromMRZOld(TResultContainerList const & rcl)
	{		
		string str; 

		TResultContainer * pRc = findFirstContainer(rcl, 3);		
		if (!pRc)
			return DOCFORMAT_UNKNOWN;

		TDocVisualExtendedInfo *pDvei = pRc->u.pTRC_DVEI;
		if (!pDvei)
			return DOCFORMAT_UNKNOWN;			

		for (int i = 0; i < pDvei->nDVEI_Fields; i++)
		{
			if (pDvei->pDVEI_ArrayFields[i].u0.nDVEF_FieldType == 35)
			{
				str = pDvei->pDVEI_ArrayFields[i].pszDVEF_Buf_Text;
				break;
			}
		}			
		
		if (str.length() == 4)
		{
			if (!str.compare("ID-1"))
				return DOCFORMAT_0;
			if (!str.compare("ID-2"))
				return DOCFORMAT_1;
			if (!str.compare("ID-3"))
				return DOCFORMAT_2;
			else
				return DOCFORMAT_UNKNOWN;
		}
		
		return DOCFORMAT_UNKNOWN;
	}

	void documentFormatUpdate(RclHolder & rclHolder, CDocFormat df)
	{
		vector<TResultContainer *> vpRc = rclHolder.getRcList(95);
		if (vpRc.empty())
			rclHolder.addNewWithOwnership<void>(95, (void *)df, RPRM_Lights_0);
		else
			vpRc[0]->u.nTRC_UINT = df;
	}

	vector<int>  documentFormatsFromCLMix(TResultContainerList & rcl, int * pResolution)
	{
		vector<int> vdf;

		vdf.clear();

		int nDfMrz = documentFormatFromMRZOld(rcl);		

		float tolerance = 0.07f;

		if (nDfMrz != -1)
			tolerance = 0.2f;

		int nDfImg = documentFormatByImages(rcl, tolerance, pResolution);

		if (nDfMrz != -1 && nDfMrz == nDfImg)
			vdf.push_back(nDfMrz);
		else
		{
			vdf.push_back(nDfImg);

			if (nDfMrz == 1 && nDfImg == 2)
				vdf.push_back(1);
		}			

		return vdf;
	}

	int documentIDRecogn(TResultContainerList & rcl)
	{
		TOneCandidate *pOc; 		

		pOc = getDocInfoRecogn(rcl);
		if (pOc)
			return  pOc->nTOC_ID;
		return 0;
	}

	vector<TResultContainer *> filter(vector<TResultContainer*> const & vpRc_in, eRPRM_Lights light)
	{
		vector<TResultContainer *> vpRc_out;

		vpRc_out.clear();

		vpRc_out.reserve(vpRc_in.size());

		vector<TResultContainer *>::const_iterator iter = vpRc_in.cbegin();

		for (; vpRc_in.end() != iter; ++iter)
		{
			if ((*iter)->nTRC_light == light)
			{
				vpRc_out.push_back(*iter);
			}
		}

		return vpRc_out;
	}

	vector<TResultContainer *> filter(vector<TResultContainer*> const & vpRc_in, vector<int> const & vnTypes)
	{
		vector<TResultContainer*> vpRc_out;

		vpRc_out.clear();

		vpRc_out.reserve(vpRc_in.size());

		vector<TResultContainer *>::const_iterator iter = vpRc_in.begin();
		
		for (; vpRc_in.end() != iter; ++iter)
		{
			if (common::contains(vnTypes, (*iter)->nTRC_result_type))
			{
				vpRc_out.push_back(*iter);
			}
		}

		return vpRc_out;
	}

	vector<TResultContainer> filter(vector<TResultContainer> const& vRc_in, eRPRM_Lights light)
	{
		vector<TResultContainer> vRc_out;

		vRc_out.clear();

		vRc_out.reserve(vRc_in.size());
		
		vector<TResultContainer>::const_iterator iter= vRc_in.begin();

		for (; vRc_in.end() != iter; ++iter)
		{
			if ((*iter).nTRC_light == light)
			{
				vRc_out.push_back(*iter);
			}
		}

		return vRc_out;
	}

	vector<TResultContainer> filter(vector<TResultContainer> const & vRc_in, eRPRM_ResultType type)
	{
		vector<TResultContainer> vRc_out;

		vRc_out.clear();

		vRc_out.reserve(vRc_in.size());

		vector<TResultContainer>::const_iterator iter = vRc_in.begin();

		for (; vRc_in.end() != iter; ++iter)
		{
			if ((*iter).nTRC_result_type == type)
			{
				vRc_out.push_back(*iter);
			}
		}

		return vRc_out;
	}

	vector<TResultContainer> filter(vector<TResultContainer> const& vRc_in, vector<int> const& vnTypes)
	{
		vector<TResultContainer> vRc_out;

		vRc_out.clear();

		vRc_out.reserve(vRc_in.size());

		vector<TResultContainer>::const_iterator iter = vRc_in.begin();

		for (; vRc_in.end() != iter; ++iter)
		{
			if (common::contains(vnTypes, (*iter).nTRC_result_type))
			{
				vRc_out.push_back(*iter);
			}
		}

		return vRc_out;
	}

	vector<TResultContainer> filterByExposure(vector<TResultContainer> const & vRc_in, int exposure)
	{
		vector<TResultContainer> vRc_out;

		vRc_out.clear();

		vRc_out.reserve(vRc_in.size());

		vector<TResultContainer>::const_iterator iter = vRc_in.cbegin();

		for (; vRc_in.cend() != iter; ++iter)
		{
			if ((*iter).u1.nTRC_exposure == exposure)
			{
				vRc_out.push_back(*iter);
			}
		}

		return vRc_out;
	}

	vector<TResultContainer> filterByPage(vector<TResultContainer> const & vRc_in, int page_idx)
	{
		vector<TResultContainer> vRc_out;

		vRc_out.clear();

		vRc_out.reserve(vRc_in.size());

		vector<TResultContainer>::const_iterator iter = vRc_in.cbegin();

		for (; vRc_in.cend() != iter; ++iter)
		{
			if ((*iter).nTRC_page_idx == page_idx)
			{
				vRc_out.push_back(*iter);
			}
		}

		return vRc_out;
	}

	vector<TResultContainer *> findContainer(TResultContainerList const & rcl, int type)
	{
		vector<TResultContainer *> vpRc;

		TResultContainer *pRc = rcl.pTRCL_TRC;
		
		for (uint i = 0; i < rcl.nTRCL_Count; i++)
		{
			if (pRc[i].nTRC_result_type == type)
			{
				vpRc.push_back(&pRc[i]);
			}
		}

		return vpRc;
		
	}

	vector<TResultContainer*> findContainer(TResultContainerList const & rcl, int type, int page_idx)
	{

		vector<TResultContainer*> vpRc;

		TResultContainer *pRc = rcl.pTRCL_TRC;

		for (uint i = 0; i < rcl.nTRCL_Count; i++)
		{
			if (pRc[i].nTRC_result_type == type && pRc[i].nTRC_page_idx == page_idx)
			{
				vpRc.push_back(&pRc[i]);
			}
		}

		return vpRc;
	}

	/*vector<TResultContainer*> findContainer(TResultContainerPointersList const & rcpl, int type)
	{
		vector<TResultContainer*> vpRc;

		TResultContainer *pRc;

		vpRc.clear();

		for (int i = 0; i < rcpl.nTRCPL_Count; i++)
		{
			pRc = rcpl.ppTRCPL_List[i];

			if (pRc[i].nTRC_result_type == type)
			{
				vpRc.push_back(pRc);
			}
		}

		return vpRc;
	}*/

	TResultContainer *findFirstContainer(TResultContainerList const & rcl, int type)
	{

		TResultContainer *pRc = rcl.pTRCL_TRC;		

		for (uint i = 0; i < rcl.nTRCL_Count; i++)
		{
			if (pRc[i].nTRC_result_type == type)
			{
				return &pRc[i];
			}
		}

		return 0;
	}

	TResultContainer *findFirstContainer(TResultContainerList const *pRcl, int type)
	{
		if (pRcl)
			return findFirstContainer(*pRcl, type);
		return 0;
	}

	int generateImageFromHiResolutionImage(tagSIZE &size, eRPRM_Lights light, RclHolder &rclHolder)
	{
		TRawImageContainer *pRic;
				
		vector<eRPRM_Lights> vLightsGroup = regula::light::lightGroup(light);
		vector<TResultContainer *> vpRc = rclHolder.getRcList(RT_TRawImageContainer_1, vLightsGroup);
		for (vector<TResultContainer *>::iterator iter = vpRc.begin(); iter != vpRc.end(); iter ++)
		{
			if (*iter)
			{
				pRic = (*iter)->u.pTRC_RIC;
				if (pRic)
				{
					tagBITMAPINFO *pBi = pRic->pxRIC_bmi;
					if (pBi->bmiHeader.biWidth == size.cx && pBi->bmiHeader.biHeight == size.cy)
					{
						return 0;
					}						
				}
			}
		}
		
		vector<TResultContainer *> vpRc1 = rclHolder.getRcList(RT_TRawImageContainer_17, vLightsGroup);
		for (vector<TResultContainer *>::iterator iter = vpRc1.begin(); iter != vpRc1.end(); iter++)
		{
			if (*iter)
				pRic = (*iter)->u.pTRC_RIC;
			else
				pRic = 0;
			cv::Mat xMatDst;
			cv::resize(wrapByMat(*pRic), xMatDst, Size(size.cx, size.cy));
			TResultContainer xRc = *(*iter);
			xRc.nTRC_result_type = RT_TRawImageContainer_1;
			xRc.u.pTRC_RIC = copyMatToRic(xMatDst, pRic->pxRIC_bmi->bmiHeader.biXPelsPerMeter, pRic->pxRIC_bmi->bmiHeader.biYPelsPerMeter).release();
			rclHolder.addWithOwnership(xRc);
		}			
		return 0;
	}

	int generateWhiteGray(RclHolder & rclHolder)
	{
		vector<shared_ptr<RclHolder>> vspRclh;
		TRawImageContainer *pRic;
		TResultContainer *pRc;
		cv::Mat xImgRGB, xImgGray;
		vspRclh = splitByPage(rclHolder);		

		for (vector<shared_ptr<RclHolder>>::iterator iter = vspRclh.begin(); vspRclh.end() != iter; iter ++)
		{
			if ((*iter)->getRcList(1, 0x2000000).empty())
			{
				pRic = regula::light::findImageUsingLightGroup((*iter)->m_xTRCL, RPRM_Lights_6, 0, 0, 0);
				if (pRic)
				{
					if (pRic->pRIC_data && pRic->pxRIC_bmi)
					{
						xImgRGB = wrapByMat(*pRic);
						cv::cvtColor(xImgRGB, xImgGray, COLOR_BGR2GRAY);						
						unique_ptr<TRawImageContainer, TRawImageContainer*(*)(TRawImageContainer*)> upRic = copyMatToRic(xImgGray,
							pRic->pxRIC_bmi->bmiHeader.biXPelsPerMeter,
							pRic->pxRIC_bmi->bmiHeader.biYPelsPerMeter);
						pRc = rclHolder.addNewWithOwnership<TRawImageContainer>(1, upRic.release(), RPRM_Lights_0);
						pRc->nTRC_light = RPRM_Lights_2000000;

						if ((*iter)->m_xTRCL.nTRCL_Count)
							pRc->nTRC_page_idx = (*iter)->m_xTRCL.pTRCL_TRC->nTRC_page_idx;
						else
							pRc->nTRC_page_idx = 0;						
						
					}
				}
			}
		}
		
		return 0;
	}

	TAuthenticityCheckResult * getAuthenticityContent(TResultContainerList * rcl, eRPRM_Authenticity authenticity)
	{
		vector<eRPRM_ResultType> vnTypes = { RT_TAuthenticityCheckList_14, RT_TAuthenticityCheckList_22 };
		
		for (uint i = 0; i < vnTypes.size(); i++)
		{
			vector<TResultContainer *> vpRc = findContainer(*rcl, vnTypes[i]);
			for (vector<TResultContainer *>::iterator iter = vpRc.begin(); iter != vpRc.end(); ++iter)
			{
				TAuthenticityCheckList *pAcl = (*iter)->u.pTRC_ACL;
				if (pAcl)
				{
					if (pAcl->ppACL_List)
					{
						for (int j = 0; j < pAcl->nACL_Count; ++j)
						{
							if (pAcl->ppACL_List[j] && pAcl->ppACL_List[j]->nACR_Type == authenticity)
							{
								return pAcl->ppACL_List[j];
							}
						}
					}
				}
			}
		}
		return 0;
	}

	void * getContainerContent(TResultContainerList const *pRcl, int type)
	{
		TResultContainer *pRc; 

		pRc = rclhelp::findFirstContainer(pRcl, type);
		if (pRc)
			return  pRc->u.pTRC_CHAR;
		else
			return  0;
	}

	vector<TResultContainer*> getContainers(TResultContainerList const & rcl)
	{
		vector<TResultContainer*> vpRc;

		for (uint i = 0; i < rcl.nTRCL_Count; i ++)
		{			
			vpRc.push_back(&rcl.pTRCL_TRC[i]);
		}

		return vpRc;
	}

	CDocFormat getDocFormat(TResultContainer const *pRcl)
	{
		if (pRcl && (pRcl->nTRC_result_type == 94 || pRcl->nTRC_result_type == 95))
			return (CDocFormat)pRcl->u.nTRC_UINT;
		return  DOCFORMAT_3;
	}

	CDocFormat getDocFormat(TResultContainerList const *pRcl)
	{
		TResultContainer *pRc = findFirstContainer(pRcl, 94);

		if (pRc && (pRc->nTRC_result_type == 94 || pRc->nTRC_result_type == 95) && pRc->u.nTRC_UINT != DOCFORMAT_3)
			return (CDocFormat)pRc->u.nTRC_UINT;
		
		pRc = findFirstContainer(pRcl, 95);
		if (pRc && (pRc->nTRC_result_type == 94 || pRc->nTRC_result_type == 95))
			return (CDocFormat)pRc->u.nTRC_UINT;
		
		return DOCFORMAT_3;
	}

	int getDocId(RclHolder & rclHolder)
	{
		vector<int> vnDocIds = getDocIds(rclHolder);
		if (vnDocIds.size() == 1)
			return vnDocIds[0];
		return 0;
	}

	vector<int> getDocIds(RclHolder & rclHolder)
	{
		vector<int> vnDocIds;
		vector<TResultContainer *> vpRc = rclHolder.getRcList(9);

		for (vector<TResultContainer *>::iterator iter = vpRc.begin(); iter != vpRc.end(); ++iter)
		{
			if ((*iter)->u.pTRC_TOC)
			{
				vnDocIds.push_back((*iter)->u.pTRC_TOC->nTOC_ID);
			}
		}

		return vnDocIds;
	}

	TOneCandidate * getDocInfoRecogn(TResultContainerList & rcl)
	{
		TResultContainer *pRc = rcl.pTRCL_TRC;

		for (uint i = 0; i < rcl.nTRCL_Count; i++)
		{
			if (pRc[i].nTRC_result_type == 9)
			{
				if (pRc[i].u.pTRC_TOC)
					return pRc[i].u.pTRC_TOC;
			}
		}

		return 0;
	}

	int getExposure(TResultContainer const & xRc)
	{
		return xRc.u1.nTRC_exposure;
	}

	int getPage(TResultContainerList const & rcl)
	{
		
		if (rcl.nTRCL_Count)
			return rcl.pTRCL_TRC->nTRC_page_idx;
		else
			return 0;
	}

	/*int getPageIndxMax(TResultContainerList const & rcl)
	{
		
		TResultContainer *pRc = rcl.pTRCL_TRC;

		int res = -1;

		for (int i = 0; i < rcl.nTRCL_Count; i++)
		{
			if (res < pRc[i].nTRC_page_idx)
			{
				res = pRc[i].nTRC_page_idx;					
			}
		}

		return res;
	}*/

	vector<int> getPages(TResultContainerList const & rcl)
	{
		vector<int> vnPages;

		if (!rcl.nTRCL_Count)
			return vnPages;
		if (!rcl.pTRCL_TRC)
			return vnPages;

		for (uint i = 0; i < rcl.nTRCL_Count; ++i)
		{		
			vector<int>::iterator iter;
			for (iter = vnPages.begin(); vnPages.end() != iter; iter ++)
			{
				if (*iter == rcl.pTRCL_TRC[i].nTRC_page_idx)
					break;
			}
			if (iter == vnPages.end())
				vnPages.push_back(rcl.pTRCL_TRC[i].nTRC_page_idx);
		}
			
		sort(vnPages.begin(), vnPages.end());

		return vnPages;
	}

	Json::Value getProcessParams(RclHolder & rclHolder, char const *lpszPP)
	{		
		string str;

		if (lpszPP)
		{
			str = string(lpszPP);
		}
		
		return getProcessParams(rclHolder, str);
	}

	Json::Value getProcessParams(RclHolder & rclHolder, string const& strPP)
	{
		vector<TResultContainer *> v7 = rclHolder.getRcList(51);
		if (v7.empty() || v7[0]->u.pTRC_JV == 0)
			return jsoncpp::convert(strPP);
		return Json::Value(*v7[0]->u.pTRC_JV);
	}

	/*string getSamplePath(TResultContainerList & rcl)
	{
		string strSampePath;

		const char *v5; 		

		strSampePath.clear();

		TResultContainer *pRc = findFirstContainer(rcl, 71);

		if (pRc)
		{
			if (pRc->pTRC_obj)
			{
				strSampePath = string((char *)pRc->pTRC_obj);				
			}
		}
		return strSampePath;
	}*/

	int imageParameters(TResultContainerList const & rcl, int & resoultion, tagSIZE & size)
	{
		tagBITMAPINFO *pBi;
		
		for (uint i = 0; i < rcl.nTRCL_Count; i ++)
		{
			if (rcl.pTRCL_TRC[i].nTRC_result_type == 1)
			{
				if (rcl.pTRCL_TRC[i].u.pTRC_RIC && rcl.pTRCL_TRC[i].u.pTRC_RIC->pxRIC_bmi)
				{
					pBi = rcl.pTRCL_TRC[i].u.pTRC_RIC->pxRIC_bmi;
					if (pBi->bmiHeader.biWidth && pBi->bmiHeader.biHeight)
					{
						size.cx = pBi->bmiHeader.biWidth;
						size.cy = pBi->bmiHeader.biHeight;
						resoultion = pBi->bmiHeader.biXPelsPerMeter;
						break;
					}
				}
				
			}
		}
		return 0;
	}

	int imageResolution(TResultContainerList const & rcl)
	{
		int resolution = 0;
		tagSIZE size = { 0,0 };
		imageParameters(rcl, resolution, size);
		return resolution;
	}

	tagSIZE imageSize(TResultContainerList &rcl)
	{
		tagSIZE size;
		int resolution = 0;
		size.cx = 0;
		size.cy = 0;
		imageParameters(rcl, resolution, size);
		return size;
	}

	/*bool imageSizeMM(TResultContainerList & rcl, float & rxmm , float & rymm)
	{
		tagSIZE size = { 0,0 };

		rxmm = 0.0;
		rymm = 0.0;
		int resolution = 0;
	
		rclhelp::imageParameters(rcl, resolution, size);

		if (!resolution)
			return 1;

		rxmm = size.cx * 1000.0 / resolution;
		rymm = size.cy * 1000.0 / resolution;

		return 0;
	}

	int indexOf(TResultContainerList const & rcl, TResultContainer const & rc)
	{

		TResultContainer * pRc = rcl.pTRCL_TRC;

		for (int i = 0; i < rcl.nTRCL_Count; ++i)
		{
			if (!memcmp(&rc, pRc, 0x20u))
				return i;

			pRc++;
		}

		return -1;
	}*/

	void mergeResults(RclHolder & rclHolder, TResultContainerList * pRcl)
	{
		vector<TResultContainer *> vpRc_second;
		vector<TResultContainer *> vpRc_first;
		vector<eRPRM_ResultType> vnResultType = { RT_TAuthenticityCheckList_14, RT_TAuthenticityCheckList_22 };
		vector<TAuthenticityCheckResult *> vpACR;		
		TResultContainer *pRc_second;
		TAuthenticityCheckList *pAcl_second;
		TResultContainer *pRc_first;
		TAuthenticityCheckList *pAcl_first;
		int nNewSize;
		bool flag = 0;

		if (!pRcl)
			return;
		for (uint i = 0; i < vnResultType.size(); i++)
		{
			vpRc_second = findContainer(*pRcl, vnResultType[i]);
			vector<TResultContainer *>::iterator iter_second = vpRc_second.begin();
			while (iter_second != vpRc_second.end())
			{
				pRc_second = *iter_second;
				vpACR.clear();
				pAcl_second = pRc_second->u.pTRC_ACL;

				if (!pAcl_second || !pAcl_second->nACL_Count || !pAcl_second->ppACL_List)
					continue;

				for (int j = 0; j < pAcl_second->nACL_Count; ++j)
				{
					if (pAcl_second->ppACL_List[j])
					{
						vpACR.push_back(pAcl_second->ppACL_List[j]);
					}
				}

				if (!vpACR.empty())				
				{
					vpRc_first = findContainer(rclHolder.m_xTRCL, vnResultType[i]);
					vector<TResultContainer *>::iterator iter_first = vpRc_first.begin();
					
					while (iter_first != vpRc_first.end())
					{
						pRc_first = *iter_first;
						if (pRc_first->nTRC_page_idx == pRc_second->nTRC_page_idx)
						{
							if (!pRc_first)
							{
								pRc_first = new TResultContainer;
								memset(pRc_first, 0, sizeof(TResultContainer));
								pRc_first->nTRC_result_type = vnResultType[i];
								pRc_first->nTRC_page_idx = pRc_second->nTRC_page_idx;
								pRc_first->nTRC_light = pRc_second->nTRC_light;
								pRc_first->nTRC_list_idx = pRc_second->nTRC_list_idx;
							}
							pAcl_first = pRc_first->u.pTRC_ACL;
							if (!pAcl_first)
							{
								pAcl_first = new TAuthenticityCheckList;
								pAcl_first->nACL_Count = 0;
								pAcl_first->ppACL_List = 0;
								pRc_first->nTRC_buf_length = 4;
								pRc_first->u.pTRC_ACL = pAcl_first;
							}
						
							nNewSize = pAcl_first->nACL_Count + vpACR.size();
							TAuthenticityCheckResult **ppNewList = new TAuthenticityCheckResult *[nNewSize];
							TAuthenticityCheckResult **pos= ppNewList;
							for (int j = 0; j < pAcl_first->nACL_Count; j++)
							{								
								*pos++ = pAcl_first->ppACL_List[j];
							}		
							for (uint k = 0; k < vpACR.size(); k++)
							{
								*pos++ = Duplicate(vpACR[k], 0);
							}
							
							if (pAcl_first->ppACL_List)
								delete[] (pAcl_first->ppACL_List);

							pAcl_first->nACL_Count = nNewSize;
							pAcl_first->ppACL_List = ppNewList;

							if (*iter_first)
							{
								flag = 1;
							}
							else
							{
								rclHolder.addCopy(*pRc_first);
								pAcl_first->nACL_Count = 0;
								if (pAcl_first->ppACL_List)
									delete[] pAcl_first->ppACL_List;
								pAcl_first->ppACL_List = 0;
								delete pRc_first->u.pTRC_ACL;
								delete pRc_first;
								flag = 1;
							}
						}
						++iter_first;
					}

					if (!flag)
						rclHolder.addCopy(*pRc_second);
					flag = 1;
				}
				++iter_second;
			}
		}
	}

	void setExposure(TResultContainer & rc, int exposure)
	{
		rc.u1.nTRC_exposure = exposure;
	}

	int setResolution(TResultContainerList &rcl, int resolution)
	{
		for (uint i = 0; i < rcl.nTRCL_Count; i++)
		{
			if (rcl.pTRCL_TRC[i].nTRC_result_type == 1 && rcl.pTRCL_TRC[i].u.pTRC_RIC)
			{
				rcl.pTRCL_TRC[i].u.pTRC_RIC->pxRIC_bmi->bmiHeader.biXPelsPerMeter = resolution;
				rcl.pTRCL_TRC[i].u.pTRC_RIC->pxRIC_bmi->bmiHeader.biYPelsPerMeter = resolution;
			}
		}
		return 0;
	}

	vector<shared_ptr<RclHolder>> splitByContainerType(RclHolder & rclHolder, vector<int> const &vnTypes)
	{
		vector<shared_ptr<RclHolder>> vspRclHolder = {
			make_shared<RclHolder>(), make_shared<RclHolder>()
		};
		
		vector<TResultContainer *> vpRc = rclHolder.getRcList();
		uint i, j;
		for (i = 0; i < vpRc.size(); ++i)
		{
			for (j = 0; j < vnTypes.size(); ++j)
			{
				if (vnTypes[j] == vpRc[i]->nTRC_result_type)
					break;
			}
			if (j == vnTypes.size()) vspRclHolder[1]->addNoCopy(*vpRc[i]);
			else vspRclHolder[0]->addNoCopy(*vpRc[i]);
		}
		return vspRclHolder;
	}

	vector<shared_ptr<RclHolder>> splitByPage(RclHolder & rclHolder)
	{
		vector<shared_ptr<RclHolder>> vspRclHolder;
		vector<int> vnPages;		

		vnPages = getPages(rclHolder.m_xTRCL);
		vspRclHolder.resize(vnPages.size());
		for (uint i = 0; i < vnPages.size(); ++i)
		{
			vspRclHolder[i] = make_shared<RclHolder>();
			vspRclHolder[i]->addNoCopy(rclHolder.getRcListByPage(vnPages[i]));
		}
		return vspRclHolder;
	}

	int updateCLByDocumentFormat(RclHolder & rclHolder, CDocFormat docFormat, cv::Size_<float>& rSize)
	{

		float rProportion = 1.0;
		float ry = 1.0;

		updateImagesByDocumentFormat(rclHolder, docFormat, rProportion, ry, rSize);

		updateDocumentPosition(rclHolder, docFormat, rProportion, ry);

		return 0;
	}

	int updateContainerType(RclHolder &rclHolder, eRPRM_ResultType typeOld, eRPRM_ResultType typeNew)
	{
		
		vector<TResultContainer *> vpRc = rclHolder.getRcList(typeOld);
		for(vector<TResultContainer *>::iterator iter = vpRc.begin(); iter != vpRc.end(); iter ++)
		{			
			(*iter)->nTRC_result_type = typeNew;
		}
		
		return 0;
	}

	int updateDocumentPosition(RclHolder & rclHolder, CDocFormat docFormat, float rProportion, float ry)
	{

		TBoundsResult *pBr;

		vector<TResultContainer *> vpRc = rclHolder.getRcList(85);

		vector<TResultContainer *>::iterator iter = vpRc.begin();

		while (vpRc.end() != iter)
		{
			pBr = (*iter)->u.pTRC_TBR;
			if (pBr)
			{				
				pBr->nTBR_docFormat = docFormat;
				pBr->nTBR_Width = (int)(pBr->nTBR_Height * ry * rProportion);
				pBr->nTBR_Height = (int)(pBr->nTBR_Height * ry);
			}
			++iter;
		}
	
		return 0;
	}

	int updateImagesByDocumentFormat(RclHolder & rclHolder, CDocFormat docFormat, float & rProportion, float & ry, cv::Size_<float>& rSize)
	{
		
		tagSIZE size = { 0,0 };
		int resolution = 0;
		float rcx, rcy;
		int cx, cy;
		float rProportion_real, rProportion_standard;
		float rRatio;
		float resolution_new;

		ry = 1.0;
		rProportion = 1.0;
		
		imageParameters(rclHolder.m_xTRCL, resolution, size);

		rcx = (float)size.cx;
		rcy = (float)size.cy;

		
		if ((docFormat | 2) != 0x3EA)
			docformatinfo::docSizeMM(docFormat, rSize.width, rSize.height);


		if (rSize.height != 0.0)
		{

			rProportion_standard = rSize.width / rSize.height;

			if (rProportion_standard != 0.0)
			{
				rProportion_real = rcx / rcy;

				if ((fabsf(rProportion_real - rProportion_standard) / rProportion_real) <= 0.05)
				{
					cy = size.cy;
					cx = size.cx;
				}
				else
				{
					rRatio = rProportion_standard / rProportion_real;

					cy = (int)(rcy / rRatio);

					if (size.cy >= cy)
					{
						ry = 1.0f / rRatio;
						cx = size.cx;
					}
					else
					{
						cy = size.cy;
						cx = (int)(rRatio * rcx);
						rcx = rRatio * rcx;
						rProportion = rRatio;
						
					}
					common::images::ResizeImage(rclHolder.m_xTRCL, cx, cy);
				}

				resolution_new = rcx / rSize.width * 1000.0f;

				if (resolution)
				{	
					
					if (size.cx == cx && size.cy == cy)
					{						
						if (fabs(resolution - resolution_new) / resolution <= 0.05)
							return 0;
					}
				}			
				setResolution(rclHolder.m_xTRCL, (int)resolution_new);
			}
		}

		return 0;
	}

	namespace bounds {

		vector<TBoundsResult*> getBoundsResult(RclHolder const& rclHolder, eBoundsResultStatus status)
		{
			vector<TBoundsResult*> vpBr;
			TBoundsResult *pBr;
			vector<TResultContainer *> vpRc = rclHolder.getRcList(0x55);

			for (vector<TResultContainer *>::iterator iter = vpRc.begin(); vpRc.end() != iter; ++iter)
			{
				pBr = (*iter)->u.pTRC_TBR;
				if (pBr && (!status || pBr->cTBR_ResultStatus & status))
				{
					vpBr.push_back(pBr);
				}
			}
			return vpBr;
		}

		Rect getBoundsResultForPage(RclHolder const& rclHolder, int page_idx)
		{
			Rect xRect;
			TBoundsResult *pBr;

			xRect.x = xRect.width = xRect.y = xRect.height = 0;
			if (!rclHolder.empty())
			{
				vector<TResultContainer *> vpRc = rclHolder.getRcList(0x55, page_idx);
				if (!vpRc.empty() && vpRc[0]->u.pTRC_TBR)
				{
					pBr = vpRc[0]->u.pTRC_TBR;
					xRect.x = min(min(pBr->xTBR_LeftBottom.x, pBr->xTBR_LeftTop.x), min(pBr->xTBR_RightBottom.x, pBr->xTBR_RightTop.x));
					xRect.width = max(max(pBr->xTBR_LeftBottom.x, pBr->xTBR_LeftTop.x), max(pBr->xTBR_RightBottom.x, pBr->xTBR_RightTop.x))- xRect.x;
					xRect.y = min(min(pBr->xTBR_LeftBottom.y, pBr->xTBR_LeftTop.y), min(pBr->xTBR_RightBottom.y, pBr->xTBR_RightTop.y));
					xRect.height = max(max(pBr->xTBR_LeftBottom.y, pBr->xTBR_LeftTop.y), max(pBr->xTBR_RightBottom.y, pBr->xTBR_RightTop.y)) - xRect.y;
				}				
			}
			return xRect;
		}

		bool updateBoundsResultByDpi(RclHolder & rclHolder, int nDpi_min, int nDpi_max, float tolerance, int nDpi_param)
		{
			TBoundsResult *pBr;
			vector<int> vnTypes = { 0x5F, 9, 3, 9, 0x55 };
			double dDist_lb_rb, dDist_rb_rt, dDist_rt_lt, dDist_lt_lb;
			Size2f rSize, rSizeMM_id, rSizeMM;
			int nPpm, nDpi;
			bool res = false;

			vector<TBoundsResult *> vpBr = getBoundsResult(rclHolder, BoundsResultStatus_0);
			if (vpBr.empty())
				return false;
						
			for (vector<TBoundsResult *>::iterator iter = vpBr.begin(); vpBr.end() != iter; iter ++)
			{
				pBr = *iter;
				if (pBr->cTBR_PerspectiveTr)
				{
					dDist_lb_rb = sqrt((double)(
						(pBr->xTBR_LeftBottom.y - pBr->xTBR_RightBottom.y))
						* (pBr->xTBR_LeftBottom.y - pBr->xTBR_RightBottom.y)
						+ (pBr->xTBR_LeftBottom.x - pBr->xTBR_RightBottom.x)
						* (pBr->xTBR_LeftBottom.x - pBr->xTBR_RightBottom.x));
					
					dDist_rb_rt = sqrt((double)(
						(pBr->xTBR_RightBottom.y - pBr->xTBR_RightTop.y))
						* (pBr->xTBR_RightBottom.y - pBr->xTBR_RightTop.y)
						+ (pBr->xTBR_RightBottom.x - pBr->xTBR_RightTop.x)
						* (pBr->xTBR_RightBottom.x - pBr->xTBR_RightTop.x));

					dDist_rt_lt = sqrt((double)(
						(pBr->xTBR_RightTop.y - pBr->xTBR_LeftTop.y))
						* (pBr->xTBR_RightTop.y - pBr->xTBR_LeftTop.y)
						+ (pBr->xTBR_RightTop.x - pBr->xTBR_LeftTop.x)
						* (pBr->xTBR_RightTop.x - pBr->xTBR_LeftTop.x));

					dDist_lt_lb = sqrt((double)(
						(pBr->xTBR_LeftTop.y - pBr->xTBR_LeftBottom.y))
						* (pBr->xTBR_LeftTop.y - pBr->xTBR_LeftBottom.y)
						+ (pBr->xTBR_LeftTop.x - pBr->xTBR_LeftBottom.x)
						* (pBr->xTBR_LeftTop.x - pBr->xTBR_LeftBottom.x));
								
					rSize.width = (float)((dDist_lb_rb + dDist_rt_lt) * 0.5);
					rSize.height = (float)((dDist_rb_rt + dDist_lt_lb) * 0.5);
					rSizeMM_id = docdesc::getDocSizeMM(getDocId(rclHolder));
					rSizeMM = rSizeMM_id;

					if (rSizeMM.width == 0.0 || rSizeMM.height == 0.0)
					{
						CDocFormat docFormat = (CDocFormat)documentFormatFromContainers(rclHolder, vnTypes);
						if (docFormat != DOCFORMAT_3 && docFormat != DOCFORMAT_3E8 && docFormat != DOCFORMAT_3EA)
						{
							rSizeMM = docformatinfo::docSizeMM(docFormat);
						}
					}
					if (rSizeMM.width == 0.0 || rSizeMM.height == 0.0)
						break;
					nPpm = docformatinfo::getPpmForImageSize(rSize, rSizeMM);

					nDpi = nDpi_min;

					if (nDpi_min == -1 || nPpm >= nDpi_min)
					{
						nDpi = nPpm;
						if (nPpm > nDpi_max && nDpi_max != -1)
							nDpi = nDpi_max;
					}
					if (nDpi)
					{
						if (nDpi_param)
							nPpm = nDpi_param;
						
						if (fabs((float)(nPpm - nDpi)) / nDpi > tolerance)
						{
							rSize = docformatinfo::getImageSizeForPpm(nDpi, rSizeMM);
							pBr->nTBR_Width = (int)rSize.width;
							pBr->nTBR_Height = (int)rSize.height;
							pBr->nTBR_Dpi = nDpi;

							res = true;
						}
					}
				}
			}
			return res;
		}

		void removeBoundsResultWithoutMrz(RclHolder &)
		{
		}
	}

	/*namespace debug {
		

		void printAllContainersType(ScopeLogHelper &, RclHolder &)
		{

		}

	}*/

	namespace docdesc {
		
		int convertDocDesc(RclHolder & rclHolder, char const * lpszDocDesc, Json::Value & xjvDocDesc)
		{
						
			string strDocDesc;

			if (!xjvDocDesc.empty())
				xjvDocDesc.clear();

			vector<TResultContainer *> vpRc = rclHolder.getRcList(63);
			if (!vpRc.empty())
			{
				if (vpRc[0]->u.pTRC_JV && vpRc[0]->nTRC_buf_length)
				{
					xjvDocDesc = Json::Value(*vpRc[0]->u.pTRC_JV);
					return 0;
				}
			}					

			vpRc = rclHolder.getRcList(68);
			if (!vpRc.empty())
			{
				if (vpRc[0]->u.pTRC_CHAR && vpRc[0]->nTRC_buf_length)
				{
					strDocDesc = string(vpRc[0]->u.pTRC_CHAR, vpRc[0]->nTRC_buf_length);
					lpszDocDesc = 0;
				}
			}
			
			if (lpszDocDesc)			
				strDocDesc = string(lpszDocDesc);		

			if (strDocDesc.length() && jsoncpp::convert(strDocDesc, xjvDocDesc))
				return 2;		

			return 0;
		}

		int docID(CDocInfo & xDocInfo, Json::Value & xjvParam)
		{
			int res; 

			res = xDocInfo.nTDI_DocID;
			if (!res)
				res = docID(xjvParam);
			return res;
		}

		int docID(Json::Value & xjvParam)
		{
			Json::Value xjvDocId = xjvParam["document"]["number"];
			if (xjvDocId.isNull())
				return 0;
			else
				return xjvDocId.asInt();
		}

		int getChildDocList(Json::Value & xjvParam, vector<int>& vnChildDocs)
		{		

			Json::ValueIteratorBase xjviter_begin;
			Json::ValueIteratorBase xjviter_end;

			vnChildDocs.clear();
			if (xjvParam.isMember("document"))
			{
				Json::Value xjvDocument = xjvParam["document"];

				if (xjvDocument.isMember("childDocuments"))
				{
					Json::Value childDocuments = xjvDocument["childDocuments"];

					if (childDocuments.isArray())
					{						
						xjviter_begin = childDocuments.begin();
						xjviter_end = childDocuments.end();

						while (xjviter_begin != xjviter_begin)
						{
							vnChildDocs.push_back(xjviter_begin.deref().asInt());
							xjviter_begin.increment();
						}
					}
				}
			}
			
			return 0;
		}

		int getChildDocList(int nDocId, vector<int> & vnChildDocs)
		{
			
			string strDocDesc;

			common::resources::getDocDesc(nDocId, strDocDesc);
			getChildDocList(strDocDesc, vnChildDocs);

			return 0;
		}

		int getChildDocList(string &strParam, vector<int>& vnChildDocs)
		{
			Json::Value xjvParam; 			

			jsoncpp::convert(xjvParam, strParam);
			getChildDocList(xjvParam, vnChildDocs);

			return 0;
		}

		CDocInfo * getDocDescFromContainer(RclHolder & rclHolder)
		{			
			vector<TResultContainer *> vpRc = rclHolder.getRcList(0x51);

			if (vpRc.empty())
				return 0;
			else
				return (CDocInfo *)vpRc[0]->u.pTRC_TDI;
		}

		Size2f getDocSizeMM(Json::Value const& xjvParam)
		{
			Size2f rSize;
			rSize.width = rSize.height = 0;

			if (xjvParam["document"].isMember("docSizeMM"))
			{
				rSize.width = (float)xjvParam["document"]["docSizeMM"].get("w", Json::Value(0)).asInt();
				rSize.height = (float)xjvParam["document"]["docSizeMM"].get("h", Json::Value(0)).asInt();
			}
			return rSize;
			
		}

		Size2f getDocSizeMM(int nDocId)
		{
			Size2f rSize_out;
			Size2f rSize; 
			string strDocDesc; 

			if (nDocId)		
			{				
				common::resources::getDocDesc(nDocId, strDocDesc);
				rSize = getDocSizeMM(jsoncpp::convert(strDocDesc));
				rSize_out.width = (float)llrintf(rSize.width);
				rSize_out.height = (float)llrintf(rSize.height);
			}
			else
			{
				rSize_out.width = 0.0;
				rSize_out.height = 0.0;
			}
			return rSize_out;
		}

		int getPairPageDocList(Json::Value & xjvParam, vector<int>& vnPairPageDocs)
		{
			
			Json::ValueIteratorBase xjvIter_begin;
			Json::ValueIteratorBase xjvIter_end;

			vnPairPageDocs.clear();

			if (xjvParam.isMember("document"))
			{
				if (xjvParam["document"].isMember("pairPage"))
				{
					if (xjvParam["document"]["pairPage"].isArray())
					{
						xjvIter_begin = xjvParam["document"]["pairPage"].begin();
						xjvIter_end = xjvParam["document"]["pairPage"].end();

						while (xjvIter_begin != xjvIter_end)
						{
							vnPairPageDocs.push_back(xjvIter_begin.deref().asInt());
							xjvIter_begin.increment();
						}
					}
				}
			}

			return 0;
		}

		int getPairPageDocList(int nDocId, vector<int>& vnPairPageDocs)
		{
			
			string strDocDesc; 			
			common::resources::getDocDesc(nDocId, strDocDesc);
			getPairPageDocList(strDocDesc, vnPairPageDocs);
		
			return 0;
		}

		int getPairPageDocList(string & strDocDesc, vector<int>& vnPairPageDocs)
		{
			Json::Value xjvDocDesc;

			jsoncpp::convert(xjvDocDesc, strDocDesc);
			getPairPageDocList(xjvDocDesc, vnPairPageDocs);

			return 0;
		}

		bool isDocsHasMrz(vector<int> const & vnDocIds, bool bFlag)
		{
			bool res;
			
			vector<int>::const_iterator iter = vnDocIds.begin();
			
			while (iter != vnDocIds.end())
			{
				string strDocDesc;
				Json::Value xjvDocDesc;

				common::resources::getDocDesc(*iter, strDocDesc);
				jsoncpp::convert(xjvDocDesc, strDocDesc);
				
				res = bFlag;

				if (xjvDocDesc["document"].isMember("dMRZ"))
				{					
					res = xjvDocDesc["document"].asInt() != 0;
				}
				
				if (res)
					return 1;
				
				++iter;
			}
			return res;
		}
	}

	namespace docinfo {
		
		void addMainDocumentInfo(RclHolder & rclHolder_update, RclHolder & rclHolder, vector<int> const & vnDocIds)
		{
			addMainDocumentInfo(vnDocIds, rclHolder_update);
			updateMainDocumentInfo(rclHolder_update, rclHolder);
		}

		void addMainDocumentInfo(vector<int> const & vnDocIds, RclHolder & rclHolder)
		{
			
			if (!vnDocIds.empty())
			{
				TChildDocInfo xCdi = { 0, (uint)-1 };
				TDocumentInfo xDi = { 0 };				

				vector<TChildDocInfo> vxCdi(vnDocIds.size(), xCdi);

				xDi.nTDI_ChildCount = vnDocIds.size();
				for (uint i = 0; i < vnDocIds.size(); i ++)
				{					
					vxCdi[i].nCDI_ID = vnDocIds[i];
				}
				xDi.pxTDI_ChildDocumentsList = &vxCdi[0];

				rclHolder.addNewCopy<TDocumentInfo>(98, &xDi, 0);
			}
		}

		int documentWasProcessed(RclHolder & rclHolder, int nOcId)
		{

			TOneCandidate *pOc;
			vector<TResultContainer *> vpRc; 

			vpRc = findContainer(rclHolder.m_xTRCL, 9);

			vector<TResultContainer *>::iterator iter = vpRc.begin();

			for (; vpRc.end() != iter; ++iter)
			{				
				if (*iter)
				{
					pOc = (*iter)->u.pTRC_TOC;
					if (pOc)
					{
						if (pOc->nTOC_ID == nOcId)
							return (*iter)->nTRC_page_idx;
					}
				}
			}

			return -1;
			
		}

		vector<int> getUnrecognizedDocId(RclHolder & rclHolder)
		{
			vector<int> vnDocIds;

			vnDocIds.clear();

			TResultContainer *pRc = findFirstContainer(rclHolder.m_xTRCL, 98);

			if (pRc)
			{
				TDocumentInfo *pDi = pRc->u.pTRC_TDMI;
				if (pDi)
				{
					for (uint i = 0; i < pDi->nTDI_ChildCount; ++i)
					{
						TChildDocInfo *pCdi = pDi->pxTDI_ChildDocumentsList;

						if (pCdi[i].nCDI_Processed == (uint)-1)
						{
							vnDocIds.push_back(pCdi[i].nCDI_ID);
						}
					}
				}
			}
			return vnDocIds;
		}

		void updateMainDocumentInfo(RclHolder & rclHolder_update, RclHolder & rclHolder)
		{
			TResultContainer *pRc = findFirstContainer(rclHolder_update.m_xTRCL, 98);
			if (pRc)
			{
				TDocumentInfo *pDi = pRc->u.pTRC_TDMI;
				if (pDi)
				{
					for (uint n = 0; n < pDi->nTDI_ChildCount; n ++)
					{
						int page_idx = documentWasProcessed(rclHolder, pDi->pxTDI_ChildDocumentsList[n].nCDI_ID);
						TChildDocInfo *pCdi = &pDi->pxTDI_ChildDocumentsList[n];
						pCdi->nCDI_Processed = page_idx;
					}
				}
			}
		}
	}

	namespace mrz {
		
		tagPOINT getMrzCenter(RclHolder const& rclHolder)
		{
			tagPOINT xptMrzCenter;
			xptMrzCenter.x = xptMrzCenter.y = 0;

			vector<TResultContainer *> vpRc = rclHolder.getRcList(87);
			if (!vpRc.empty())
			{
				TResultMRZDetector * pRmrzd = vpRc[0]->u.pTRC_RMD;
				float * rBounds = pRmrzd->rnRMD_boundingQuadrangle;
				xptMrzCenter.x = (int)((rBounds[0] + rBounds[2] + rBounds[6] + rBounds[4]) * 0.25f);
				xptMrzCenter.y = (int)((rBounds[1] + rBounds[3] + rBounds[7] + rBounds[5]) * 0.25f);
			}
			return xptMrzCenter;
		}

	}

	namespace page {

		void setPageIndex(vector<TResultContainer*> const & vpRc, int page_idx)
		{
			for (vector<TResultContainer*>::const_iterator iter = vpRc.begin(); vpRc.end() != iter; iter ++)
			{
				(*iter)->nTRC_page_idx = page_idx;
			}
		}

		void sortByFaceMrz(RclHolder & rclHolder)
		{
			float v4 = 0.0;
			int nPageIndex = -1;
			int nPageIndex2 = -1;
			int v39 = 0;
			bool v47 = 0;
			int nPageIndex3 = -1;

			for (uint n = 0; n < rclHolder.m_xTRCL.nTRCL_Count; n ++)
			{
				TResultContainer *pRc = rclHolder.m_xTRCL.pTRCL_TRC;
				if (pRc[n].nTRC_result_type == 97)
				{
					if (pRc[n].u.pTRC_CRC)
					{
						CRectCandidats *pRectCan = pRc[n].u.pTRC_CRC;
						for (int k = 0; k < pRectCan->m_nRC_Count; k ++)
						{
							tagRECT *v14 = &pRectCan->m_pRC_List[k].xRL_pRects;
							vector<TResultContainer *> vpRc = rclHolder.getRcListByPage(rclHolder.m_xTRCL.pTRCL_TRC[n].nTRC_page_idx);
							int v20 = abs(v14->right - v14->left);
							int v21 = abs(v14->bottom - v14->top);
							float v22 = (float)(v21 * v20);
							RclHolder tmp(vpRc, 1);
							tagSIZE size;
							size = imageSize(tmp.m_xTRCL);
							float v24 = 0.0;
							if (size.cx * size.cy)
								v24 = v22 / (size.cx * size.cy);
							if (nPageIndex == -1 || v4 < v24 || pRectCan->m_pRC_List[k].nRL_Probability > v39)
							{
								v4 = v24;
								v39 = pRectCan->m_pRC_List[k].nRL_Probability;
								nPageIndex = rclHolder.m_xTRCL.pTRCL_TRC[n].nTRC_page_idx;
							}
						}
					}
				}
				else if (v39 || pRc[n].nTRC_result_type != 6)
				{
					if (pRc[n].nTRC_result_type == 87)
					{
						TResultMRZDetector * pRmrzd = pRc[n].u.pTRC_RMD;
						if (pRmrzd)
						{
							if (!v47)
							{
								nPageIndex2 = (int)pRc[n].nTRC_page_idx;
								nPageIndex3 = MRZAnalyze::pageIndexUsual(pRmrzd, v47);
							}
						}
					}
				}
				else
				{
					TDocGraphicsInfo * pDgi = pRc[n].u.pTRC_DGI;
					if (pDgi)
					{
						for (uint k = 0; k < pDgi->nDGI_nFields; k++)
						{							
							if (pDgi->pDGI_pArrayFields[k].nDGF_FieldType == GFT_Portrait)
								nPageIndex = (int)pRc[n].nTRC_page_idx;
						}
					}
					v39 = 0;
				}
			}
			if ((nPageIndex2 & nPageIndex) != -1)
			{
				int v34 = v47;
				int v35 = v34 | ~nPageIndex;
				if (v47)
					nPageIndex = nPageIndex2;
				if (!v35)
					nPageIndex = nPageIndex2;
				if (nPageIndex2 != -1)
					nPageIndex2 = nPageIndex3;
				if (v47)
					v34 = nPageIndex3;
				if (!v35)
					v34 = nPageIndex2;
				if (v34 != -1)
				{
					if (nPageIndex != v34 && nPageIndex != -1)
					{
						swapPageIndex(rclHolder.getRcList(), nPageIndex, v34);
					}
				}
			}
		}

		void swapPageIndex(TResultContainer & rc, int page_idx_1, int page_idx_2)
		{
			if (rc.nTRC_page_idx == page_idx_1)
			{
				rc.nTRC_page_idx = page_idx_2;
			}
			else if (rc.nTRC_page_idx == page_idx_2)
			{
				rc.nTRC_page_idx = page_idx_1;
			}
			if (rc.nTRC_result_type == 98)
			{
				TDocumentInfo *pDi = rc.u.pTRC_TDMI;
				if (pDi)
				{
					for (uint i = 0; i < pDi->nTDI_ChildCount; ++i)
					{
						TChildDocInfo *pCdi = &pDi->pxTDI_ChildDocumentsList[i];
						int processed = (int)pDi->pxTDI_ChildDocumentsList[i].nCDI_Processed;
						if (processed != -1)
						{
							if (processed == page_idx_1)
							{
								pDi->pxTDI_ChildDocumentsList[i].nCDI_Processed = (uint)page_idx_2;
							}
							else if (processed == page_idx_2)
							{
								pDi->pxTDI_ChildDocumentsList[i].nCDI_Processed = (uint)page_idx_1;
							}
						}
					}
				}
			}
		}

		void swapPageIndex(vector<TResultContainer*> const & vpRc, int page_idx_1, int page_idx_2)
		{
			for (vector<TResultContainer*>::const_iterator iter = vpRc.begin(); vpRc.cend() != iter; iter ++)
				swapPageIndex(*(*iter), page_idx_1, page_idx_2);
		}

		void updateMrzContainerPageByBoundsResult(RclHolder & rclHolder)
		{
			
			vector<int> vnPages;

			vnPages = getPages(rclHolder.m_xTRCL);
			
			for (uint i = 0; i < vnPages.size(); ++i)
			{
				int nPage = vnPages[i];
				vector<TResultContainer *> vpRc = rclHolder.getRcList(85, vnPages[i]);
				
				if (!vpRc.empty())
				{
					TBoundsResult * pBr = vpRc[0]->u.pTRC_TBR;

					if (pBr && (pBr->cTBR_ResultStatus & 2) && nPage != -1)
					{
						vpRc = rclHolder.getRcList(mrzContainerTypes());
						vector<TResultContainer *>::iterator iter = vpRc.begin();

						while (vpRc.end() != iter)
						{							
							(*iter)->nTRC_page_idx = nPage;
							++iter;
						}
						break;
					}
						
				}
				
			}
			
		}

		void updatePageIndex(vector<TResultContainer*> const & vpRc, int page_idx_1, int page_idx_2)
		{
			vector<TResultContainer*>::const_iterator iter = vpRc.cbegin();
			for (; vpRc.cend() != iter; ++iter)
			{
				if (*iter)
				{
					if ((*iter)->nTRC_page_idx == page_idx_1)
						swapPageIndex(*(*iter), page_idx_1, page_idx_2);
				}
			}
		}

		void updatePageIndexByDocId(RclHolder & rclHolder)
		{
			vector<shared_ptr<RclHolder>> vspRclHolder = splitByPage(rclHolder);

			vector<shared_ptr<RclHolder>>::iterator iter = vspRclHolder.begin();
			for (; vspRclHolder.end() != iter; iter ++)
			{
				int nDocId = getDocId(*((*iter).get()));
				if (nDocId)
				{
					int nPageIndex;
					if ((*iter)->m_xTRCL.nTRCL_Count)
						nPageIndex = (*iter)->m_xTRCL.pTRCL_TRC->nTRC_page_idx;
					else
						nPageIndex = 0;
					rclhelp::page::updatePageIndex(rclHolder.getRcListByPage(nPageIndex), nPageIndex, nDocId);
				}
			}
		}

		void updatePageIndexFrom0Step1(RclHolder & rclHolder)
		{
			vector<int> vnPages = getPages(rclHolder.m_xTRCL);
			if (!vnPages.empty())
			{
				for (vector<int>::iterator iter = vnPages.begin(); vnPages.end() != iter; iter++)
				{
					if (*iter > -1)
					{
						if (vnPages.begin() != iter)
						{
							std::rotate(vnPages.begin(), iter, vnPages.end());
						}
						break;
					}
				}

				vector<int> v17, v18;
				for (vector<int>::iterator iter = vnPages.begin(); vnPages.end() != iter; iter++)
				{
					if (rclHolder.getRcList(1, *iter).empty())
					{
						v17.push_back(*iter);
					}
					else
					{
						v18.push_back(*iter);
					}
				}
				vnPages.assign(v18.begin(), v18.end());
				vnPages.insert(vnPages.end(), v17.begin(), v17.end());

				vector<TResultContainer*> vpRc = rclHolder.getRcList();
				for (vector<TResultContainer*>::iterator iter = vpRc.begin(); vpRc.end() != iter; iter++)
				{
					uint i;
					for (i = 0; i < vnPages.size(); i ++)
					{
						if (vnPages[i] == (*iter)->nTRC_page_idx)
							break;
					}
					if (i < vnPages.size())
						(*iter)->nTRC_page_idx = i;
				}
			}
		}
	}

	namespace qa {


		/*int getQACheck(TImageQualityCheckList * pIqcl)
		{

			if (pIqcl)
				return pIqcl->nTIQCL_result;
			else
				return 2;
			
		}

		int getQACheck(TImageQualityCheckList *pIqcl, eImageQualityCheckType type)
		{

			if (pIqcl)
			{
				TImageQualityCheck ** ppIqcList = pIqcl->ppTImageQualityCheck;

				if (ppIqcList)
				{
					int v3 = 4 * pIqcl->nTIQCL_Count;
					while (v3)
					{
						TImageQualityCheck * v4 = *ppIqcList;
						++ppIqcList;
						v3 -= 4;
						if ((*ppIqcList)->nTIQC_type == type)
							return (*ppIqcList)->nTIQC_result;
					}
				}
			}
			return 2;
		}*/

		bool hasNoGlares(RclHolder & rclHolder, bool)
		{

			void *pIqcl = getContainerContent(&rclHolder.m_xTRCL, 30);
			return validateQACheck((TImageQualityCheckList *)pIqcl, ImageQualityCheckType_0, 0);
		}

		bool isInFocus(RclHolder & rclHolder, bool a2)
		{

			bool res; 

			vector<TResultContainer *> vpRc = rclHolder.getRcList(30);
			vector<TResultContainer *>::iterator iter = vpRc.begin();
		
			res = 1;
			while (vpRc.end() != iter)
			{
				if ((*iter)->u.pTRC_IQCL)
				{
					res = validateQACheck((*iter)->u.pTRC_IQCL, ImageQualityCheckType_1, 0);
					if (res != a2)
						break;
				}
				++iter;
			}
			return res;
			
		}

	}
}


