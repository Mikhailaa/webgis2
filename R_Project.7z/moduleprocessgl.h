#pragma once
#include "pch.h"

namespace regulaconfig
{
	void setPathFunc(void(*a1)(int, int));
};

namespace moduleprocessgl
{
	class IProcessFunction
	{
	public:
		IProcessFunction();
		virtual ~IProcessFunction();
		virtual int process(int, void *, const char *, void **, char **) = 0;
		virtual vector<int> getCommands() = 0;
	};

	int process(int, void *, const char *, void **, char **);
	bool isCommandSupported(eProcessGlCommands);
};

int processgl(int a1, TResultContainerList *a2, const char *a3, void **a4, char **a5);