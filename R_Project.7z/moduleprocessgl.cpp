#include "moduleprocessgl.h"
#include "common/ModuleOrchestrator.h"
#include "NotifyFunction.h"
#include "common/common.h"
#include "common/StringUtils.h"
#ifndef ANDROID_NDK
#include <thread>
#endif

unordered_multimap<int, weak_ptr<moduleprocessgl::IProcessFunction>> g_map_11410BC;
vector<eProcessGlCommands> g_vec_11410B0;

struct scheduler_operation_1
{
	scheduler_operation_1 *next_;
	void(*func_)(void *, scheduler_operation_1 *, void *, size_t);
	int task_result_;
	char field_C;
	char field_D;
	char field_E;
	char field_F;
	int idx;
	vector<shared_ptr<moduleprocessgl::IProcessFunction>> *modules;
	int* pa1;
	void** pa2;
	char** pa3;
	void*** pa4;
	char*** pa5;
	mutex *mtx;
	unordered_multimap<int, weak_ptr<moduleprocessgl::IProcessFunction>> *map;
	vector<eProcessGlCommands> *commands;
	vector<int> *vec;
	int field_3C;
};
#ifdef ANDROID_NDK
void sub_6DDD94(void** a1)
{
	using namespace boost::asio::detail;

	if (a1[2])
		a1[2] = 0;
	if (a1[1])
	{
		thread_info_base::deallocate(thread_context::thread_call_stack::top(), a1[1], sizeof(scheduler_operation_1));
		a1[1] = 0;
	}
}

void sub_6DDC04(void *a1, scheduler_operation_1 *a2, void *a3, size_t a4)
{
	void* v32[3];
	int nRet;

	v32[1] = a2;
	v32[2] = a2;
	a2->field_D = 0;
	sub_6DDD94(v32);
	if (a1)
	{
		moduleprocessgl::IProcessFunction* module = (*a2->modules)[a2->idx].get();
		vector<int> v40 = module->getCommands();
		vector<int>::iterator iter;
		if (!v40.empty())
		{
			for (iter = v40.begin(); iter != v40.end(); iter++)
			{
				if (*iter == *a2->pa1)
					break;
			}
			if (iter == v40.end())
			{
				(*a2->vec)[a2->idx] = 1;
				sub_6DDD94(v32);
				return;
			}
		}
		nRet = module->process(*a2->pa1, *a2->pa2, *a2->pa3, *a2->pa4, *a2->pa5);
		if (!nRet)
		{
			vector<int> v36 = module->getCommands();
			for (iter = v36.begin(); iter != v36.end(); iter++)
			{
				a2->mtx->lock();
				int val = *iter;
				a2->map->emplace(val, (*a2->modules)[a2->idx]);
				a2->commands->push_back(val);
				a2->mtx->unlock();
			}
			nRet = 0;
		}
		(*a2->vec)[a2->idx] = nRet;
	}
	sub_6DDD94(v32);
	return;
}
#else
void sub_6DDC04(scheduler_operation_1 *a2)
{
	int nRet;

	//scheduler_operation_1 *a2 = (scheduler_operation_1 *)param;
	a2->field_D = 0;
	if (1)
	{
		moduleprocessgl::IProcessFunction* module = (*a2->modules)[a2->idx].get();
		vector<int> v40 = module->getCommands();
		vector<int>::iterator iter;
		if (!v40.empty())
		{
			for (iter = v40.begin(); iter != v40.end(); iter++)
			{
				if (*iter == *a2->pa1)
					break;
			}
			if (iter == v40.end())
			{
				(*a2->vec)[a2->idx] = 1;
				return;
			}
		}
		nRet = module->process(*a2->pa1, *a2->pa2, *a2->pa3, *a2->pa4, *a2->pa5);
		if (!nRet)
		{
			vector<int> v36 = module->getCommands();
			for (iter = v36.begin(); iter != v36.end(); iter++)
			{
				a2->mtx->lock();
				int val = *iter;
				a2->map->emplace(val, (*a2->modules)[a2->idx]);
				a2->commands->push_back((eProcessGlCommands)val);
				a2->mtx->unlock();
			}
			nRet = 0;
		}
		(*a2->vec)[a2->idx] = nRet;
	}
	return;
}
#endif
namespace regulaconfig
{
	void(*g_pPathFunc)(int, int);

	void setPathFunc(void(*a1)(int, int))
	{
		g_pPathFunc = a1;
	}
}

namespace moduleprocessgl
{
	IProcessFunction::IProcessFunction()
	{

	}
	
	IProcessFunction::~IProcessFunction()
	{

	}

	bool isCommandSupported(eProcessGlCommands a1)
	{
		vector<eProcessGlCommands>::iterator iter;
		for (iter = g_vec_11410B0.begin(); iter != g_vec_11410B0.end(); iter ++)
		{
			if (*iter == a1)
				break;
		}
		if (iter != g_vec_11410B0.end())
			return true;
		return false;
	}

	int process(int a1, void *a2, const char *a3, void **a4, char **a5)
	{
		vector<shared_ptr<IProcessFunction>>& v91 = common::getModuleOrchestrator()->getModules();
		int nRet = 1;
		switch (a1)
		{
		case 0xC8:
			NotifyFunction::setLog((void(*)(int, int))a2);
			nRet = 0;
			break;
		case 0xC9:
			NotifyFunction::setNotify((void(*)(int, int))a2);
			nRet = 0;
			break;
		case 0xCA:
			regulaconfig::setPathFunc((void(*)(int, int))a2);
			nRet = 0;
			break;
		case 0xCB:
			// common::ModuleUtils::GetModulePath();
			nRet = 0;
			break;
		case 0xCC:
			// common::ModuleUtils::GetModulePath();
			nRet = 0;
			break;
		case 0xCF:
			nRet = 0;
			break;
		default:
			break;
		}
		vector<shared_ptr<IProcessFunction>>::iterator iter;
		if (!v91.empty())
		{
			if (!g_map_11410BC.size())
			{
				for (iter = v91.begin(); iter != v91.end(); iter ++)
				{
					vector<int> v34 = (*iter).get()->getCommands();
					for (vector<int>::iterator iter1 = v34.begin(); iter1 != v34.end(); iter1++)
					{
						g_map_11410BC.emplace(*iter1, *iter);
					}
				}
			}
			int val = 1;
			vector<int> v41(v91.size(), val);
			size_t i;
			if (a1 == 0xCD)
			{
#ifdef ANDROID_NDK
				using namespace boost::asio::detail;
				boost::asio::thread_pool v32;
				std::mutex v42;
				unordered_multimap<int, weak_ptr<IProcessFunction>> v36;
				vector<int> v35;
				
				for (i = 0; i < v91.size(); i++)
				{
					scheduler_operation_1* op = (scheduler_operation_1*)thread_info_base::allocate(thread_context::thread_call_stack::top(), sizeof(scheduler_operation_1));
					op->next_ = 0;
					op->func_ = sub_6DDC04;
					op->task_result_ = 0;
					op->field_D = 1;
					op->idx = i;
					op->modules = &v91;
					op->pa1 = &a1;
					op->pa2 = &a2;
					op->pa3 = (char**)&a3;
					op->pa4 = &a4;
					op->pa5 = &a5;
					op->mtx = &v42;
					op->map = &v36;
					op->commands = &v35;
					op->vec = &v41;
					v32.scheduler_.post_immediate_completion((scheduler_operation *)op, false);
				}
				v32.join();
				g_vec_11410B0 = v35;
				g_map_11410BC = v36;
#else
				std::mutex v42;
				unordered_multimap<int, weak_ptr<IProcessFunction>> v36;
				vector<eProcessGlCommands> v35;
				vector<thread> vThread;
				for (i = 0; i < v91.size(); i++)
				{
					scheduler_operation_1* op = new scheduler_operation_1;
					op->next_ = 0;
					op->func_ = 0;
					op->task_result_ = 0;
					op->field_D = 1;
					op->idx = i;
					op->modules = &v91;
					op->pa1 = &a1;
					op->pa2 = &a2;
					op->pa3 = (char**)&a3;
					op->pa4 = &a4;
					op->pa5 = &a5;
					op->mtx = &v42;
					op->map = &v36;
					op->commands = &v35;
					op->vec = &v41;
					vThread.push_back(thread(sub_6DDC04, op));
				}
				for (vector<thread>::iterator iter = vThread.begin(); iter != vThread.end(); iter++)
				{
					iter->join();
				}
				g_vec_11410B0 = v35;
				g_map_11410BC = v36;
#endif
			}
			else
			{
				vector<weak_ptr<IProcessFunction>> v31 = common::mapValues(g_map_11410BC, a1);
				val = 1;
				v41.resize(v31.size(), val);
				for (i = 0; i < v31.size(); i++)
				{
					string strLog("moduleprocessgl::process() CMDGL (");
					strLog.append(common::StringUtils::toString(a1));
					strLog.append(")");
					v41[i] = v31[i].lock().get()->process(a1, a2, a3, a4, a5);
				}
				if (a1 == 0xCE)
					g_map_11410BC.clear();
			}
			int v25 = 1;
			for (vector<int>::iterator iter1 = v41.begin(); iter1 != v41.end(); iter1++)
			{
				v25 = *iter1;
				if (v25 != 1) break;
			}
			if (v25 != 1)
				nRet = v25;
		}

		return nRet;
	}
}

int processgl(int a1, TResultContainerList *a2, const char *a3, void **a4, char **a5)
{
	if (a1 >= 0x2FA9 && a1 < 0x300C)
		return 1;
	return moduleprocessgl::process(a1, a2, a3, a4, a5);
}