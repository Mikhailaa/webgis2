#include "regula.h"
#include "common/container/RclHolder.h"

namespace regula
{
	ProcessParameters::ProcessParameters()
	{
		m_xPP_0 = {
			map<string, RequestProp>::value_type(string("ocr"), { 0x84, 0x2014 }),
			map<string, RequestProp>::value_type(string("mrz"), { 0x40, 8 }),
			map<string, RequestProp>::value_type(string("barcode"), { 0x100, 0x20 }),
			map<string, RequestProp>::value_type(string("detect"), { 0x8000, 4 }),
			map<string, RequestProp>::value_type(string("locate"), { 0x10, 4 }),
			map<string, RequestProp>::value_type(string("authenticity"), { 0x200, 0x400 }),
			map<string, RequestProp>::value_type(string("imageQA"), { 0x10000, 0 }),
			map<string, RequestProp>::value_type(string("images"), { 8, 2 }),
			map<string, RequestProp>::value_type(string("doctype"), { 0x20, 0x2000 }),
			map<string, RequestProp>::value_type(string("graphics"), { 4, 0x4000 }),
			map<string, RequestProp>::value_type(string("bankCard"), { 0, 0x100000 }),
			map<string, RequestProp>::value_type(string("rfid"), { 0, 0x80000 })
		};
		//m_xPP_0[string("ocr")] = { 0x84, 0x2014 };
		for (map<string, RequestProp>::iterator iter = m_xPP_0.begin(); iter != m_xPP_0.end(); iter++)
		{
			m_xPP_C.push_back(iter->first);
		}
	}

	ProcessParameters::~ProcessParameters()
	{

	}

	int ProcessParameters::getCapabilities(string const&a2)
	{
		map<string, RequestProp>::iterator iter = m_xPP_0.find(a2);
		if (iter == m_xPP_0.end())
			return 0;
		return iter->second.nPP_RP_cap;
	}

	vector<string> ProcessParameters::getFullRequestsList(void)
	{
		return m_xPP_C;
	}

	int ProcessParameters::getImageModes(string const&a2)
	{
		map<string, RequestProp>::iterator iter = m_xPP_0.find(a2);
		if (iter == m_xPP_0.end())
			return 0;
		return iter->second.nPP_RP_mode;
	}

	namespace light
	{
		bool contains(vector<eRPRM_Lights> const&a1, eRPRM_Lights a2)
		{
			for (vector<eRPRM_Lights>::const_iterator iter = a1.begin(); iter != a1.end(); iter++)
			{
				if (*iter == a2)
					return true;
			}
			return false;
		}

		TRawImageContainer *findImageUsingLightGroup(TResultContainerList &a1, eRPRM_Lights a2, bool a3, bool a4, bool a5)
		{
			common::container::RclHolder v21;
			v21.addNoCopy(a1);
			vector<TResultContainer*> v19 = v21.getRcList(1, a2);
			if (!v19.empty())
				return v19.front()->u.pTRC_RIC;
			vector<eRPRM_Lights> v18(whiteGroup());
			for (vector<eRPRM_Lights>::iterator iter = v18.begin(); iter != v18.end(); iter++)
			{
				if (*iter == a2)
				{
					if (a4) v18.insert(v18.begin(), RPRM_Lights_2000000);
					if (a5)
					{
						v18 = unite(v18, irGroup());
					}
					v19 = v21.getRcList(1, v18);
					if (!v19.empty())
						return v19.front()->u.pTRC_RIC;
					break;
				}
			}
			for (vector<eRPRM_Lights>::iterator iter = irGroup().begin(); iter != irGroup().end(); iter++)
			{
				if (*iter == a2)
				{
					v19 = v21.getRcList(1, irGroup());
					if (!v19.empty())
						return v19.front()->u.pTRC_RIC;
					if (!a3) return 0;
					v19 = v21.getRcList(1, RPRM_Lights_2000000);
					if (!v19.empty())
						return v19.front()->u.pTRC_RIC;
					break;
				}
			}
			return 0;
		}
		vector<eRPRM_Lights>& irGroup(void)
		{
			static vector<eRPRM_Lights> g_vec_1141248;
			if (g_vec_1141248.empty())
			{
				g_vec_1141248.push_back(RPRM_Lights_18);
				g_vec_1141248.push_back(RPRM_Lights_1000000);
				g_vec_1141248.push_back(RPRM_Lights_10);
				g_vec_1141248.push_back(RPRM_Lights_8);
				g_vec_1141248.push_back(RPRM_Lights_40);
			}
			return g_vec_1141248;
		}
		vector<eRPRM_Lights> lightGroup(eRPRM_Lights a2)
		{
			for (vector<eRPRM_Lights>::iterator iter = whiteGroup().begin(); iter != whiteGroup().end(); iter++)
			{
				if (*iter == a2)
				{
					return whiteGroup();
				}
			}
			for (vector<eRPRM_Lights>::iterator iter = irGroup().begin(); iter != irGroup().end(); iter++)
			{
				if (*iter == a2)
				{
					return irGroup();
				}
			}
			return vector<eRPRM_Lights>(1, a2);
		}
		vector<eRPRM_Lights> unite(vector<eRPRM_Lights> const&a2, vector<eRPRM_Lights> const&a3)
		{
			vector<eRPRM_Lights> ret;
			ret.insert(ret.begin(), a3.begin(), a3.end());
			ret.insert(ret.begin(), a2.begin(), a2.end());
			return ret;
		}
		vector<eRPRM_Lights>& whiteAndIrGroup(void)
		{
			static vector<eRPRM_Lights> g_vec_1141254;
			if (g_vec_1141254.empty())
			{
				g_vec_1141254 = unite(whiteGroup(), irGroup());
			}
			return g_vec_1141254;
		}
		vector<eRPRM_Lights>& whiteGroup(void)
		{
			static vector<eRPRM_Lights> g_vec_114123C;
			if (g_vec_114123C.empty())
			{
				g_vec_114123C.push_back(RPRM_Lights_6);
				g_vec_114123C.push_back(RPRM_Lights_800000);
				g_vec_114123C.push_back(RPRM_Lights_4);
				g_vec_114123C.push_back(RPRM_Lights_2);
				g_vec_114123C.push_back(RPRM_Lights_20);
			}
			return g_vec_114123C;
		}
	}
}
