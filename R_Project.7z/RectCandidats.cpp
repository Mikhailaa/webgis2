#include "RectCandidats.h"

CRectCandidats::CRectCandidats() 
{ 
	m_nRC_Count = 0; 
	m_pRC_List = 0; 
	m_nRC_CountFalseDetection = 0; 
	m_nRC_Reserved1 = 0; 
	m_nRC_Reserved2 = 0; 
}

CRectCandidats::~CRectCandidats()
{
	clear();
}

void CRectCandidats::clear()
{
	if (m_pRC_List)
	{
		delete[] m_pRC_List;
		m_pRC_List = 0;
	}
}

void CRectCandidats::resize(uint a2)
{
	clear();
	m_pRC_List = new ResultList[a2];
	memset(m_pRC_List, 0, sizeof(ResultList) * a2);
}