#pragma once

#pragma warning(disable:4005)

#include <SDKDDKVer.h>

#include <guiddef.h>

#include <stdio.h>
#include <tchar.h>
#include <vector>
#include <thread>
#include <string>
#include <unordered_map>
#include <map>
#include <algorithm>
#include <unordered_set>

#include <opencv2/core.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/core/types.hpp>
#include <opencv2/opencv.hpp>

#include <rapidjson.h>
#include <document.h>
#include <writer.h>

#ifdef ANDROID_NDK
#include <boost/thread/thread.hpp>
#include <boost/thread/tss.hpp>
#include <boost/asio/thread_pool.hpp>
#endif

using namespace std;
using namespace cv;
using namespace rapidjson;

typedef void*			pvoid;
#define memclr(buf, len) memset(buf, 0, len)

#ifndef ANDROID_NDK
typedef unsigned long __thread_id;
__thread_id pthread_self();
#endif

#ifndef PI
#define PI 3.14159265
#endif

#ifndef MAXFLOAT
#define MAXFLOAT 1E17f
#endif

#include "commonStruct.h"
#include "imsegStruct.h"

#ifdef _DEBUG
#define Log printf
#else
#define Log
#endif