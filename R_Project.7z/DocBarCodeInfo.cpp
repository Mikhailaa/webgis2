#include "stdafx.h"
#include "DocBarCodeInfo.h"
#include "common/container/container.h"

CDocBarCodeField::CDocBarCodeField(CDocBarCodeField const&a2)
{
	this->nDBCF_bcCountModule = 0;
	this->pDBCF_bcDataModule = 0;
	this->pDBCF_bcFieldMask = 0;
	load(a2);
}

CDocBarCodeField::CDocBarCodeField()
{
	this->nDBCF_bcCountModule = 0;
	this->pDBCF_bcDataModule = 0;
	this->pDBCF_bcFieldMask = 0;
}

CDocBarCodeField::~CDocBarCodeField()
{
	free();
}

void CDocBarCodeField::free(void)
{
	common::container::Delete(this);
	this->nDBCF_bcCountModule = 0;
	this->pDBCF_bcDataModule = 0;
	this->pDBCF_bcFieldMask = 0;
}

void CDocBarCodeField::getData(vector<uchar> &a2)
{
	a2.empty();
	for (int i = 0; i < this->nDBCF_bcCountModule; i ++)
	{
		for (int j = 0; j < this->pDBCF_bcDataModule[i].nTDM_mLength; ++j)
		{
			a2.push_back(this->pDBCF_bcDataModule[i].nTDM_mData[j]);
		}
	}
}

int CDocBarCodeField::getType(void)
{
	return this->nDBCF_bcType_DECODE;
}

void CDocBarCodeField::load(CDocBarCodeField const&a2)
{
	free();
	common::container::Duplicate((TDocBarCodeField*)&a2, this);
}

void CDocBarCodeField::load(string &a2)
{
	free();
	this->nDBCF_bcCountModule = 1;
	TIP_DECODE_MODULE * v4 = new TIP_DECODE_MODULE;
	memclr(v4, sizeof(TIP_DECODE_MODULE));
	this->pDBCF_bcDataModule = v4;
	int v8 = (int)a2.size();
	v4->nTDM_mLength = v8;
	uchar* v10 = new uchar[v8];
	memclr(v10, v8);
	v4->nTDM_mData = v10;
	memcpy(v10, a2.data(), v8);
}

int CDocBarCodeField::loadDecodeResult(TDocBarCodeField *a2)
{
	if (!a2->nDBCF_bcCountModule)
		return -1;
	if (this->pDBCF_bcDataModule)
	{
		this->nDBCF_bcCountModule = 0;
		delete[] this->pDBCF_bcDataModule;
		this->pDBCF_bcDataModule = 0;
	}
	int v6 = 0;
	for (int i = 0; i < a2->nDBCF_bcCountModule; i ++)
	{
		v6 += a2->pDBCF_bcDataModule[i].nTDM_mLength;
	}
	if (v6 - 1 > 0x270F)
		return -1;
	this->nDBCF_bcCountModule = 1;
	TIP_DECODE_MODULE * v11 = new TIP_DECODE_MODULE;
	memclr(v11, sizeof(TIP_DECODE_MODULE));
	this->pDBCF_bcDataModule = v11;
	v11->nTDM_mLength = v6;
	uchar* v13 = new uchar[v6];
	memclr(v13, v6);
	v11->nTDM_mData = v13;
	v6 = 0;
	for (int i = 0; i < a2->nDBCF_bcCountModule; i ++)
	{
		memcpy(&this->pDBCF_bcDataModule->nTDM_mData[v6], a2->pDBCF_bcDataModule[i].nTDM_mData, a2->pDBCF_bcDataModule[i].nTDM_mLength);
		v6 += a2->pDBCF_bcDataModule[i].nTDM_mLength;
	}
	return 0;
}

int CDocBarCodeField::setRect(tagRECT a2)
{
	if (a2.left >= 0 && a2.left <= 100000 && a2.top >= 0 && a2.top <= 100000 &&
		a2.right >= 0 && a2.right <= 100000 && a2.bottom >= 0 && a2.bottom <= 100000)
	{
		this->xDBCF_bcROI_DETECT = a2;
		return 0;
	}
	return -1;
}


CDocBarCodeInfo::CDocBarCodeInfo()
{
	this->nDBCI_nFields = 0;
	this->pDBCI_pArrayFields = 0;
	m_nCDBCIR_field_8 = 0;
}

CDocBarCodeInfo::~CDocBarCodeInfo()
{
	free();
}

CDocBarCodeField *CDocBarCodeInfo::add(void)
{
	if (this->nDBCI_nFields >= m_nCDBCIR_field_8)
	{
		if (m_nCDBCIR_field_8)
		{
			reserve(2 * m_nCDBCIR_field_8);
		}
		else
		{
			reserve(1);
		}
	}
	this->nDBCI_nFields ++;
	return (CDocBarCodeField *)&this->pDBCI_pArrayFields[this->nDBCI_nFields - 1];
}

void CDocBarCodeInfo::free(void)
{
	common::container::Delete(this);
	this->nDBCI_nFields = 0;
	this->pDBCI_pArrayFields = 0;
	m_nCDBCIR_field_8 = 0;
}

void CDocBarCodeInfo::reserve(int a2)
{
	TDocBarCodeField *newField = new TDocBarCodeField[a2];
	memclr(newField, a2 * sizeof(TDocBarCodeField));
	m_nCDBCIR_field_8 = a2;
	for (uint i = 0; i < this->nDBCI_nFields; ++i)
	{
		memcpy(&newField[i], &this->pDBCI_pArrayFields[i], sizeof(TDocBarCodeField));
	}
	if (this->pDBCI_pArrayFields)
		delete[] this->pDBCI_pArrayFields;
	this->pDBCI_pArrayFields = newField;
}