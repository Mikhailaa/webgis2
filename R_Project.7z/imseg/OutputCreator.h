#pragma once
#include "CTCHypoth.h"
#include "SymbolCandidatWithRect.h"

namespace imseg
{
	class OutputCreator
	{
	public:
		OutputCreator();
		~OutputCreator();
		static void createOutput(Rect_<int> const&, vector<CTCHypoth>&, vector<vector<SymbolCandidatWithRect>> &);
		static void CTCHypothToOutput(vector<CTCHypoth> &, vector<Rect_<int>> const&, vector<vector<SymbolCandidatWithRect>> &);
		static vector<Rect_<int>> findSymbolRects(Rect_<int> const&, vector<CTCHypoth> const&);
		static void increaseAllProbsInOrderToNotAllowSymbolDeleting(vector<CTCHypoth> &);
		static void makeRectsPlausible(vector<Rect_<int>> &);
	};
}