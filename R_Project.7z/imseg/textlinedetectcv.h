#pragma once
#include "pch.h"

#include "common/resources.h"
#include "common/container/container.h"
#include "common/container/RclHolder.h"
#include "Json/Value.h"

using namespace common::resources;
using namespace common::container;

namespace imseg
{
	namespace textlinedetectcv
	{
		void detectWords(cv::Mat &,vector<cv::Rect> &);
		int findLines(cv::Mat &, int, float, vector<vector<cv::Rect>> &);
	}
}