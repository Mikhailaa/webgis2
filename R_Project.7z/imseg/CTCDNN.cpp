#include "CTCDNN.h"

using namespace imseg;

CTCDNN::CTCDNN()
{
	m_xCTCDNN_Size_4 = cv::Size(0,0);
	m_sptrCTCDNN_IFieldMask_4C = make_shared<imseg::FieldMaskArbitrarySymbols>();
}

CTCDNN::~CTCDNN()
{
}

void CTCDNN::visit(RichTextLines &xRTL)
{
	if (xRTL.empty()) return;

	vector<cv::Mat> vNormalImgs = xRTL.getNormalizedImgs();
	vector<DbgFolder> vDbgFolders = xRTL.getDbgFolders();

	for (size_t i = 0; i < vNormalImgs.size(); i++)
	{
		//Log("imseg::CTCDNN::visit");
		//Log("start inference ...");


		vector<cv::Mat> vMatTmp(1, vNormalImgs[i]);
		cv::Mat_<float> mtTmp = m_xCTCDNN_mtDNN_14.forward(vMatTmp);
		vMatTmp.clear();

		//Log("finish inference");

		int nMul = 1;
		for(int j=0;j<mtTmp.dims;j++)
			nMul *= mtTmp.size.p[j];
		int nLabelNum = m_nCTCDNN_DecorderCTC_24.getLabelNum();
		cv::Mat mat = mtTmp.reshape(1, nMul / nLabelNum);

		set<uint> setAlphabet = xRTL.getAlphabetSet();

		//Log("start parsing ...");
		unsigned int nTopLCID = xRTL.getTopPriorityLCID();
		if (i < m_vCTCDNN_sptrIFieldMask_40.size())
			m_sptrCTCDNN_IFieldMask_4C = m_vCTCDNN_sptrIFieldMask_40[i];
		vector<CTCHypoth> vCTCHypoth =m_nCTCDNN_DecorderCTC_24.parseLogits(nTopLCID, setAlphabet, m_sptrCTCDNN_IFieldMask_4C, mat);
		//Log("finish parsing");
		
		vector<uint> vLabels = m_nCTCDNN_DecorderCTC_24.getLabels();

		//dbgInfoSaver::saveBeforLogicalCorrection(vDbgFolders[i], vCTCHypoth, mat, vLabels);

		xRTL.getScale(i) *= (1.0f / ((float)m_nCTCDNN_field_C / (float)m_xCTCDNN_Size_4.width));

		xRTL.append(vCTCHypoth);
	}
}

shared_ptr<IFieldMask>* CTCDNN::getMaskAnyWay(uint n_a2)
{
	shared_ptr<IFieldMask>* ret = &m_sptrCTCDNN_IFieldMask_4C;
	if (n_a2 < m_vCTCDNN_sptrIFieldMask_40.size()) ret = &m_vCTCDNN_sptrIFieldMask_40[n_a2];
	return ret;
}

int CTCDNN::getOutputWidth2InputWidthRatio()
{
	return m_nCTCDNN_field_C / m_xCTCDNN_Size_4.width;
}

cv::Size CTCDNN::getSize()
{
	return m_xCTCDNN_Size_4;
}

void imseg::CTCDNN::io_generic(cv::dnn::DnnReader &a2)
{
	m_nCTCDNN_DecorderCTC_24.io_generic(a2);
	m_xCTCDNN_mtDNN_14.load(a2);
	a2.io(&m_xCTCDNN_Size_4.width);
	a2.io(&m_xCTCDNN_Size_4.height);
	a2.io(&m_nCTCDNN_field_C);
	m_nCTCDNN_field_10 = m_xCTCDNN_Size_4.width / m_nCTCDNN_field_C;
}

void CTCDNN::setMasks(vector<shared_ptr<IFieldMask>> const &v_sptrIFM)
{
	m_vCTCDNN_sptrIFieldMask_40 = v_sptrIFM;
}

