#pragma once
#include "pch.h"
#include "common/resources.h"
#include "common/container/container.h"
#include "common/container/RclHolder.h"
#include "Json/Value.h"
#include "DocInfo.h"
#include "Layer.h"

namespace imseg
{
	namespace debug
	{
		namespace fieldsinfo
		{
			void getSplitFieldInfo(TDocInfo &,string &);
			void addFieldInfo(RclHolder &, cv::Mat &, TDocInfo &, TVisualField &, int);
			void saveFieldWithRandomNameInTmpFolder(cv::Mat &, TDocInfo &, TVisualField &, Field &);
			void generateFieldGenerateInfo(Layer_R &, Json::Value &);
		}
	}
}