#pragma once
#include "pch.h"
#include "word_beam_search.h"
#include "LanguageModel.h"

namespace imseg
{
	namespace word_beam_search
	{
		class Beam
		{
		public:
			double                     m_dBeam_0;
			shared_ptr<LanguageModel>  m_spBeam_8;
			vector<double>             m_vBeam_10;
			vector<uint>               m_vBeam_1C;
			vector<uint>               m_vBeam_28;
			vector<float>              m_vBeam_34;
			vector<uint>               m_vBeam_40;
			vector<uint>               m_vBeam_4C;
			vector<vector<uint> >      m_vBeam_58;
			int                        m_nBeam_64;
			int                        m_nBeam_68;
			float                      m_rBeam_6C;
			int                        m_nBeam_70;
			float                      m_rBeam_74;
			bool                       m_fBeam_78;
			bool                       m_fBeam_79;
			bool                       m_fBeam_7A;
		public:
			Beam(Beam const&);
			Beam(shared_ptr<LanguageModel> const&, bool, bool, bool);
			~Beam();

			shared_ptr<Beam> createChildBeam(double, uint, float, uint);
			double getAvgWordProb(void);
			vector<float> getCharProbs(void);
			vector<uint> getCharXs(void);
			map<int, Char> getNextChars(void);
			vector<uint> getText(void);
			vector<vector<uint>> getWords(void);
		};

		class BeamList
		{
		public:
			unordered_map<vector<uint>, shared_ptr<Beam>, HashFunction> m_umBL_0;
		public:
			void addBeam(shared_ptr<Beam> const&);
			vector<shared_ptr<Beam>> getBestBeams(uint);
		};
	}
}
