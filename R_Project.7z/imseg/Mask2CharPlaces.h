#pragma once
#include "../pch.h"
#include "common/resources.h"
#include "common/container/container.h"
#include "common/container/RclHolder.h"
#include "Json/Value.h"

#include "CharPlace.h"
#include "unicodes.h"
#include "TextPartStruct.h"
#include "SubField.h"

using namespace common::resources;
using namespace common::container;

namespace imseg
{
	namespace Mask2CharPlaces
	{
		vector<CharPlace> atom2UnicodeSeq(TextPartStruct &, map<wstring, SubField> &, vector<int> &, set<uint> &);
		vector<CharPlace> buidCharPlacesFrom(SubField &, vector<int> &);
		vector<CharPlace> buildCharPlacesFrom(map<wstring, SubField>&, TextPartStruct &, set<uint> &);
		//atoms2UnicodeSeq(std::__ndk1::vector<std::__ndk1::vector<std::__ndk1::basic_string<wchar_t,std::__ndk1::char_traits<wchar_t>,std::__ndk1::allocator<wchar_t>>,std::__ndk1::allocator<std::__ndk1::basic_string<wchar_t,std::__ndk1::char_traits<wchar_t>,std::__ndk1::allocator<wchar_t>>>>,std::__ndk1::allocator<std::__ndk1::vector<std::__ndk1::basic_string<wchar_t,std::__ndk1::char_traits<wchar_t>,std::__ndk1::allocator<wchar_t>>,std::__ndk1::allocator<std::__ndk1::basic_string<wchar_t,std::__ndk1::char_traits<wchar_t>,std::__ndk1::allocator<wchar_t>>>>>> const&,std::__ndk1::map<std::__ndk1::basic_string<wchar_t,std::__ndk1::char_traits<wchar_t>,std::__ndk1::allocator<wchar_t>>,SubField,std::__ndk1::less<std::__ndk1::basic_string<wchar_t,std::__ndk1::char_traits<wchar_t>,std::__ndk1::allocator<wchar_t>>>,std::__ndk1::allocator<std::__ndk1::pair<std::__ndk1::basic_string<wchar_t,std::__ndk1::char_traits<wchar_t>,std::__ndk1::allocator<wchar_t>> const,SubField>>> const&,std::__ndk1::vector<int,std::__ndk1::allocator<int>> const&)
		//process(std::__ndk1::basic_string<wchar_t, std::__ndk1::char_traits<wchar_t>, std::__ndk1::allocator<wchar_t>> const&, std::__ndk1::map<std::__ndk1::basic_string<wchar_t, std::__ndk1::char_traits<wchar_t>, std::__ndk1::allocator<wchar_t>>, SubField, std::__ndk1::less<std::__ndk1::basic_string<wchar_t, std::__ndk1::char_traits<wchar_t>, std::__ndk1::allocator<wchar_t>>>, std::__ndk1::allocator<std::__ndk1::pair<std::__ndk1::basic_string<wchar_t, std::__ndk1::char_traits<wchar_t>, std::__ndk1::allocator<wchar_t>> const, SubField>>> const&, std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&, std::__ndk1::set<uint, std::__ndk1::less<uint>, std::__ndk1::allocator<uint>> &)
		//splitByAtom(std::__ndk1::basic_string<wchar_t, std::__ndk1::char_traits<wchar_t>, std::__ndk1::allocator<wchar_t>> const&)
		//splitByOr(std::__ndk1::basic_string<wchar_t, std::__ndk1::char_traits<wchar_t>, std::__ndk1::allocator<wchar_t>> const&)

 	};
}