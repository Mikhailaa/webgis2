#pragma once
#include "pch.h"
#include "common/resources.h"
#include "common/container/container.h"
#include "common/container/RclHolder.h"
#include "Json/Value.h"
#include "RecognizedTextDoc.h"

using namespace Json;
using namespace common::container;

namespace imseg
{
	namespace series
	{
		class ProcessSeriesControl
		{
		public:
			int m_nMinProbForFieldRecogn_0;
			int m_nMinProbForFieldRecognLastStep_4;
			int m_nMinProbForFieldRecognLastStep_8;
			int m_nfieldTypeForControlSeries_C;
			int m_nminTextLenForResult_10;
			int m_nconfirmResultCount_14;
			int m_nminProbThresholdDnn_14;
			set<int> m_setn_1C;
			RclHolder m_xRclHolder_28;
			CRecognizedTextDoc m_xCRecognizedTextDoc_3C;
			CRecognizedTextDoc m_xCRecognizedTextDoc_48;
			int isPSC_field_54;
			int isPSC_field_58;//bool, byte
			map<int, int> m_mapnn_5C;
			vector<int> m_vn_68;
			map<int, int> m_mapnn_74;
			map<int, int> m_mapnn_80;
			vector<int> m_vn_8C;
			map<int, vector<shared_ptr<CRecognizedTextFieldSDK>>> m_mapnvspCRecognizedTextFieldSDK_98;

			ProcessSeriesControl();
			~ProcessSeriesControl();
			void resetSeries();
		};
		
		bool checkSeries(int, TDocVisualExtendedInfo const*, bool, bool &);
		bool checkReadyFieldDnn(vector<shared_ptr<CRecognizedTextFieldSDK>>&, CRecognizedTextFieldSDK&, map<int, bool>&, int, int);
		bool checkReadyFieldDnnOff(CRecognizedTextFieldSDK &, float);
		CRecognizedTextFieldSDK *chooseMostProbableResultDnnOff(vector<shared_ptr<CRecognizedTextFieldSDK>>&, float);
		CRecognizedTextFieldSDK *chooseMostProbableResultDnn(vector<shared_ptr<CRecognizedTextFieldSDK>>&);
		void updateParams(ProcessSeriesControl&, Json::Value&);
	}
}