﻿#pragma once
#include "pch.h"
#include "Symbols.h"
#include "Field.h"
#include "TextEx.h"
#include "FontDesc.h"
#include "imseg_interface.h"
#include "ImageControl.h"

class Layer_R : public IText , public vector<Field>
{
public:
	Layer_R();
	virtual ~Layer_R();
	virtual void linesList(vector<Text *> &);
	virtual void linesList(vector<pair<Text *, Field *>> &);
	virtual void linesListWithText(vector<Text *> &);

	vector<vector<CBufferImage *>> images();
	void setRecognizeMeAllwaysWithoutTextDetection(bool);
	bool recognizeMeAllwaysWithoutTextDetection();

public:
	//vft_0
	vector<Field> m_vField_4;
	SymbolInfoEx * m_pSymboInfoEx_10;
	LayerParam m_xParam_14;
	vector<TextEx> m_vTextEx_8C;
	bool field_98;
};

