#include  "VLinesCandidates.h"
#include "AnalyzeLinesCandidates.h"
#include "rcvmat.h"
#include "RCv.h"

bool VLinesCandidates::findAngle(InitConstStructs &a2, FontDesc &a3, float &a4)
{
	m_rAngle_C = 0;
	int nPointCount = 0;

	for (uint i = 0; i < m_vLinesCandidates.size(); i++)
	{
		nPointCount += m_vLinesCandidates[i].m_vTxPoints_0.size();
	}

	vector<TPointEx> m_vPt_2C;
	m_vPt_2C.reserve(nPointCount);

	int v10 = 0;
	int v14 = 0;
	for (uint i = 0; i < m_vLinesCandidates.size(); i++)
	{
		for (uint j = 0; j < m_vLinesCandidates[i].m_vTxPoints_0.size(); j++)
		{
			if (m_vLinesCandidates[i].m_vTxPoints_0[j].nField_8 > v14)
				v14 = m_vLinesCandidates[i].m_vTxPoints_0[j].nField_8;
			m_vPt_2C.push_back(m_vLinesCandidates[i].m_vTxPoints_0[j]);
			m_vPt_2C.back().nField_4 += v10;
			m_vPt_2C.back().nField_8 += v10;
		}

		v10 += v14 + 2 * a3.m_xFontDescBase_0.m_nFDB_Field_4;
	}

	float v30 = 0.0f;
	if (!AnalyzeLinesCandidates::findAngleUsingLines(
		m_vPt_2C, a2.m_xTLineAnalyzeFirst_0.maxAngle, 3 * a3.m_xFontDescBase_0.m_nFDB_Field_4, 0, 0.05f, v30))
	{
		m_rAngle_C = v30;
		a4 = v30;
		return false;
	}

	return true;
}

void VLinesCandidates::getHInfo(int n_a1, int n_a2, vector<int> &vn_a3)
{
	vn_a3.resize(n_a2 + 1);
	for (uint i = 0; i < m_vLinesCandidates.size(); i++)
	{
		vector<int>::iterator v11 = vn_a3.begin();
		int nTmp_v14;
		for (uint j = 0; j < m_vLinesCandidates[i].m_vTxPoints_0.size(); j++)
		{
			nTmp_v14 = m_vLinesCandidates[i].m_vTxPoints_0[j].nField_C;
			if (nTmp_v14 >= n_a1 && nTmp_v14 <= n_a2)
				vn_a3[nTmp_v14]++;
		}
	}
}

int VLinesCandidates::lineCandidateCount()
{
	int res = 0;
	for (uint i = 0; i < m_vLinesCandidates.size(); i++)
		res += m_vLinesCandidates[i].m_vTxPoints_0.size();
	return res;
}

bool VLinesCandidates::rotate(vector<vector<CBufferImage *>> a2)
{
	if (m_rAngle_C == 0.0f) return true;
	for (uint i = 0; i < a2.size(); i++)
	{
		if (!a2[i].empty())
		{
			tagPOINT ptCenter = { a2[i][0]->width() / 2, a2[i][0]->height() / 2};
			m_vLinesCandidates[i].rotatePoints(m_rAngle_C, ptCenter);

			for (uint j = 0; j < a2[i].size(); j++)
			{
				cv::Mat mat = RCvMat::ref(*a2[i][j]);
				cv::Mat mat1;
				mat.copyTo(mat1);
				cv::Point2f center2f(mat1.cols*0.5f, mat1.rows * 0.5f);
				cv::Mat mat2 = cv::getRotationMatrix2D(center2f, m_rAngle_C, 1.0f);
				cv::warpAffine(mat1, mat, mat2, mat1.size(), 1, 5);
			}
		}
	}
	return false;
}


