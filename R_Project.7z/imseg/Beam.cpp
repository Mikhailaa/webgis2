#include "Beam.h"
#include "LanguageModel.h"
#include "word_beam_search.h"

namespace imseg
{
	namespace word_beam_search
	{ 
		Beam::Beam(Beam const & a2)
			: m_spBeam_8(a2.m_spBeam_8)
			, m_vBeam_10(a2.m_vBeam_10)
			, m_vBeam_1C(a2.m_vBeam_1C)
			, m_vBeam_28(a2.m_vBeam_28)
			, m_vBeam_34(a2.m_vBeam_34)
			, m_vBeam_40(a2.m_vBeam_40)
			, m_vBeam_4C(a2.m_vBeam_4C)
			, m_vBeam_58(a2.m_vBeam_58)
		{
			m_dBeam_0 = a2.m_dBeam_0;
			m_nBeam_64 = a2.m_nBeam_64;
			m_nBeam_68 = a2.m_nBeam_68;
			m_rBeam_6C = a2.m_rBeam_6C;
			m_nBeam_70 = a2.m_nBeam_70;
			m_rBeam_74 = a2.m_rBeam_74;
			m_fBeam_78 = a2.m_fBeam_78;
			m_fBeam_79 = a2.m_fBeam_79;
			m_fBeam_7A = a2.m_fBeam_7A;
		}

		Beam::Beam(shared_ptr<LanguageModel> const & a2, bool a3, bool a4, bool a5)
			: m_spBeam_8(a2), m_fBeam_78(a3), m_fBeam_79(a4), m_fBeam_7A(a5)
		{
			m_dBeam_0 = 1.0;
			m_nBeam_68 = 0;
			m_rBeam_6C = 1.875f;
			m_nBeam_70 = 0;
			m_rBeam_74 = 1.875f;
		}

		Beam::~Beam()
		{
		}
		shared_ptr<Beam> Beam::createChildBeam(double a3, uint a4, float a5, uint a6)
		{
			shared_ptr<Beam> a1 = make_shared<Beam>(*this);

			if (a4 != -1 && (m_vBeam_28.empty() || m_vBeam_28.back() != a4))
			{
				set<uint> s12 = a1->m_spBeam_8->getWordChars();

				if (s12.end() == s12.find(a4))
				{
					a1->m_vBeam_4C.clear();
				}
				else
				{
					a1->m_vBeam_4C.push_back(a4);
				}

				a1->m_vBeam_1C.push_back(a4);
				a1->m_vBeam_34.push_back(a5);
				a1->m_vBeam_40.push_back(a6);
			}

			a1->m_vBeam_28.push_back(a4);
			a1->m_dBeam_0 = a3;

			return a1;
		}
		double Beam::getAvgWordProb(void)
		{
			vector<vector<uint>> vv9 = getWords();
			if (vv9.empty())
			{
				return 0.0;
			}

			double d5 = 0.0;
			int n4 = 0;

			for (size_t i = 0; i < vv9.size(); i++)
			{
				if (vv9[i].size() >= 2)
				{
					n4++;
					if (m_spBeam_8->getUnigramProb(vv9[i]) != 0.0)
					{
						d5 += 1.0;
					}
				}
			}

			if (n4)
			{
				return d5 / n4;
			}

			return 0.0;
		}
		vector<float> Beam::getCharProbs(void)
		{
			return m_vBeam_34;
		}
		vector<uint> Beam::getCharXs(void)
		{
			return m_vBeam_40;
		}
		map<int, Char> Beam::getNextChars(void)
		{
			return m_spBeam_8->getNextChars(m_vBeam_4C);
		}
		vector<uint> Beam::getText(void)
		{
			return m_vBeam_1C;
		}
		vector<vector<uint>> Beam::getWords(void)
		{
			vector<vector<uint>> a1;
			set<uint> s1a(m_spBeam_8->getNonWordChars());
			vector<uint> v16;

			for (size_t i = 0; i < m_vBeam_1C.size(); i++)
			{
				if (s1a.end() != s1a.find(m_vBeam_1C[i]))
				{
					if (v16.empty())
					{
						continue;
					}

					a1.push_back(v16);
					v16.clear();
				}
				else
				{
					v16.push_back(m_vBeam_1C[i]);
				}
			}

			if (!v16.empty())
			{
				a1.push_back(v16);
			}

			return a1;
		}
		void BeamList::addBeam(shared_ptr<Beam> const & a2)
		{
			unordered_map<vector<uint>, shared_ptr<Beam>, HashFunction>::iterator iter = m_umBL_0.find(a2->m_vBeam_1C);

			if (iter != m_umBL_0.end())
			{
				iter->second->m_dBeam_0 += a2->m_dBeam_0;
			}
			else
			{
				m_umBL_0[a2->m_vBeam_1C] = a2;
			}
		}

		bool comp(pair<vector<uint>, shared_ptr<Beam>> & a1, pair<vector<uint>, shared_ptr<Beam>> & a2)
		{
			return a1.second->m_dBeam_0 > a2.second->m_dBeam_0;
		}

		vector<shared_ptr<Beam>> BeamList::getBestBeams(uint a3)
		{
			vector<pair<vector<uint>, shared_ptr<Beam>>> v16(m_umBL_0.begin(), m_umBL_0.end());
			sort(v16.begin(), v16.end(), comp);
			vector<shared_ptr<Beam>> a1;
			a1.reserve(a3);

			for (size_t i = 0; i < v16.size() && i < a3; i++)
			{
				a1.push_back(v16[i].second);
			}

			return a1;
		}
	}
}
