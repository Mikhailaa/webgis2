#pragma once
#include "pch.h"
#include "commonStruct.h"

enum eProcessOptions
{
	PROCESS_OPTION_0 = 0,
	PROCESS_OPTION_2 = 2,
	PROCESS_OPTION_4 = 4,
	PROCESS_OPTION_7 = 7,
	PROCESS_OPTION_8 = 8,
	PROCESS_OPTION_9 = 9,
	PROCESS_OPTION_10 = 10,
	PROCESS_OPTION_11 = 11,
	PROCESS_OPTION_12 = 12,
	PROCESS_OPTION_13 = 13,
	PROCESS_OPTION_14 = 14
};

class FieldParam
{
public:
	FieldParam();
	FieldParam(FieldParam&);
	~FieldParam();
	bool contain(eProcessOptions);
	FieldParam& operator=(FieldParam const&);
	vector<uchar> param(eProcessOptions);
	vector<uchar> paramValue(eProcessOptions);

	int m_nFP_0;
	int m_nCount_4;
	unordered_map<eProcessOptions, string> m_umap_FP_4;
};
