#include "FontDesc.h"

FontDesc::FontDesc()
{
}

FontDesc::~FontDesc()
{
}

FontDesc &FontDesc::operator=(FontDesc const &other)
{
	m_xFontDescBase_0 = other.m_xFontDescBase_0;
	m_xBaseLines_38 = other.m_xBaseLines_38;
	m_mapLetterParam_6C = other.m_mapLetterParam_6C;
	return *this;
}

LetterParam::LetterParam()
{
}

LetterParam::~LetterParam()
{
}

LayerParam::LayerParam()
{
}

LayerParam::LayerParam(LayerParam &other)
{
	m_xFontDesc = other.m_xFontDesc;
}
