#include "Label2Unicodes.h"
#include "unicodes.h"

namespace imseg
{
	namespace unicodes
	{
		extern vector<vector<uint>> visuallyIdenticalUnicodes;
	}
}

namespace imseg {
	vector<uint> Label2Unicodes::m_nullCode(1, 0x10FFFF);

	Label2Unicodes::Label2Unicodes(vector<uint> const & a2, set<uint> const & a3)
		: m_vL2U_field_C(a2), m_sL2U_field_24(a3)
	{
		m_vL2U_field_0.resize(a2.size());

		for (size_t i = 0; i < m_vL2U_field_0.size(); i++)
		{
			if (m_sL2U_field_24.find(a2[i]) != m_sL2U_field_24.end())
			{
				m_vL2U_field_0[i].push_back(a2[i]);
				m_tL2U_field_18[a2[i]] = i;
			}

			for (size_t j = 0; j < imseg::unicodes::visuallyIdenticalUnicodes.size(); j++)
			{
				vector<uint> v1a(imseg::unicodes::visuallyIdenticalUnicodes[j]);

				for (size_t k = 0; k < v1a.size(); k++)
				{
					if (v1a[k] == a2[i])
					{
						for (size_t l = 0; l < v1a.size(); l++)
						{
							if (m_sL2U_field_24.find(v1a[l]) != m_sL2U_field_24.end() && v1a[l] != a2[i])
							{
								m_vL2U_field_0[i].push_back(v1a[l]);

								if (m_tL2U_field_18.find(v1a[l]) == m_tL2U_field_18.end())
								{
									m_tL2U_field_18[v1a[l]] = i;
								}
							}
						}
						break;
					}
				}
			}

			if (m_vL2U_field_0[i].empty())
			{
				m_vL2U_field_0[i].push_back(-1);
			}
		}
	}

	uint Label2Unicodes::unicode2Label(uint a2) const
	{
		map<uint, uint>::const_iterator iter = m_tL2U_field_18.find(a2);

		if (m_tL2U_field_18.end() == iter)
		{
			return -1;
		}

		return iter->second;
	}

	void Label2Unicodes::deleteForbiddenSymbols(cv::Mat &a2)
	{
		double d2, d3;
		cv::minMaxLoc(a2, &d2, &d3);

		for (int i = 0; i < a2.cols - 1; i++)
		{
			if (m_vL2U_field_0[i].size() == 1 && m_vL2U_field_0[i][0] == -1)
			{
				vector<uint> v23 = getIdxsForProbabilityTransfer(m_vL2U_field_C[i]);

				if (!v23.empty())
				{
					cv::Mat m1 = a2.col(i);

					for (size_t j = 0; j < v23.size(); j++)
					{
						cv::Mat m31 = a2.col(v23[j]);

						for (int k = 0; k < m31.rows; k++)
						{
							cv::MatExpr me30 = cv::max(m31.row(k), m1.row(k));
							m31.row(k) = me30;
						}
					}
				}

				a2.col(i) = cv::Scalar(d2);
			}
		}
	}
	vector<uint> Label2Unicodes::getIdxsForProbabilityTransfer(uint a3)
	{
		vector<uint> a1;
		set<uint> * s5 = unicodes::getUnicodesForProbabilityTransfer(a3);

		if (s5)
		{
			for (set<uint>::iterator iter = s5->begin(); iter != s5->end(); iter++)
			{
				for (size_t i = 0; i < m_vL2U_field_0.size(); i++)
				{
					for (size_t j = 0; j < m_vL2U_field_0[i].size(); j++)
					{
						if (m_vL2U_field_0[i][j] == *iter)
						{
							a1.push_back(i);
						}
					}
				}
			}
		}

		return a1;
	}

	bool Label2Unicodes::isInExtendedAlphabet(uint a2) const
	{
		return (m_sL2U_field_24.find(a2) != m_sL2U_field_24.end());
	}

	vector<uint>  Label2Unicodes::operator()(uint const & a2) const
	{
		if (a2 < m_vL2U_field_0.size())
		{
			return m_vL2U_field_0[a2];
		}

		return Label2Unicodes::m_nullCode;
	}

	uint Label2Unicodes::size(void) const
	{
		return m_vL2U_field_C.size();
	}
}



