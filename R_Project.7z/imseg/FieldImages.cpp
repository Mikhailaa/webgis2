#include "FieldImages.h"

FieldImages::FieldImages()
{
}

FieldImages::FieldImages(FieldImages const &a1)
{
	m_xRect_0 = a1.m_xRect_0;
	m_xRect_10 = a1.m_xRect_10;
	m_vCBufImg_20 = a1.m_vCBufImg_20;
}

FieldImages::~FieldImages()
{
}

FieldImages FieldImages::operator=(FieldImages const & a1)
{
	m_xRect_0 = a1.m_xRect_0;
	m_xRect_10 = a1.m_xRect_10;
	m_vCBufImg_20.assign(a1.m_vCBufImg_20.begin(), a1.m_vCBufImg_20.end());
	return *this;
}
