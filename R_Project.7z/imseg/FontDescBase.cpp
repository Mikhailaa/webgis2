#include "FontDescBase.h"

FontDescBase::FontDescBase()
{
	memclr(this, sizeof(FontDescBase));
}

FontDescBase::~FontDescBase()
{
}
