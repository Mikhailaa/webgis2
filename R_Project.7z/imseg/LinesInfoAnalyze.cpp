#include "LinesInfoAnalyze.h"

void LinesInfoAnalyze::getXPosition(multimap<int, int> & mmParam1, int nParam2, int nParam3, int &nParam4, int &nParam5)
{
	nParam4 = 0x7FFFFFFF;
	nParam5 = 0x80000000;
	for (int i = nParam2; i < nParam3; i++)
	{
		vector<int> v = common::mapValues(mmParam1, i);
		for (size_t j = 0; j < v.size(); j++)
		{
			if (v[j] < nParam4)
			{
				nParam4 = v[j];
			}
			if (v[j] > nParam5)
			{
				nParam5 = v[j];
			}
		}
	}
}

void LinesInfoAnalyze::getHistY(vector<TPointEx> &vParam1, vector<int> &vParam2, vector<int> &vParam3, multimap<int, int> *pmmParam4, multimap<int, int> *pmmParam5, int nParam6, int nParam7)
{
	vector<int> vv(vParam1.size());
	if (!nParam6 || !nParam7)
	{
		for (size_t i = 0; i < vParam1.size(); i++)
		{
			vv[i] = i;
		}
	}
	else
	{
		//no check
		for (size_t i = 0; i < vParam1.size(); i++)
		{
			if(vParam1[i].nField_C > nParam6 && vParam1[i].nField_C < nParam7)
				vv[i] = i;

		}
	}
	int v24 = 0;
	for (size_t i = 0; i < vv.size(); i++)
	{
		if (vParam1[vv[i]].nField_8 > v24)
			v24 = vParam1[vv[i]].nField_8;
	}
	v24++;
	vParam2.resize(v24, 0);
	vParam3.resize(v24, 0);
	for (size_t i = 0; i < vv.size(); i++)
	{
		if (vParam1[vv[i]].nField_4 >= 1 && (size_t)vParam1[vv[i]].nField_4 < vParam2.size())
		{
			vParam2[vParam1[vv[i]].nField_4]++;
			if (pmmParam4)
			{
				pmmParam4->emplace(vParam1[vv[i]].nField_4, vParam1[vv[i]].nField_0);
			}
		}
		if (vParam1[vv[i]].nField_8 >= 1 && (size_t)vParam1[vv[i]].nField_8 < vParam3.size())
		{
			vParam3[vParam1[vv[i]].nField_8]++;
			if (pmmParam5)
			{
				pmmParam5->emplace(vParam1[vv[i]].nField_8, vParam1[vv[i]].nField_0);
			}
		}
	}
}