#pragma once
#include "imseg_interface.h"
#include "CTCHypoth.h"

namespace imseg
{
	class DeleteFalseSymbolsAtEdges : public ICorrector
	{
	public:
		float m_rDeleteFalseSymbolsAtEdges_8;
		float m_rDeleteFalseSymbolsAtEdges_C;
		float m_rDeleteFalseSymbolsAtEdges_10;
		DeleteFalseSymbolsAtEdges(ICorrector*);
		~DeleteFalseSymbolsAtEdges();
		virtual void process_impl(vector<CTCHypoth> &);
	};
}