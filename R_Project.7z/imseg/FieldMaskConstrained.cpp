#include "FieldMaskConstrained.h"

namespace imseg
{
	FieldMaskConstrained::FieldMaskConstrained(vector<CharPlace>&arg1)
		:m_vCharPlace_4(arg1)
		, m_vCTCHypoth_18()
	{
		MergeRepeats *pMR= (true, nullptr);
		DeleteSequentialSpaces *pDSS = new DeleteSequentialSpaces(pMR);
		m_spICorrector_10 = make_shared<DeleteSequentialSpaces>(pDSS);
	}
	void FieldMaskConstrained::setPreviousPath(vector<CTCHypoth> const &a2)
	{
		m_vCTCHypoth_18 = a2;
		m_spICorrector_10->process(m_vCTCHypoth_18);
		int nSize;
		if (m_vCTCHypoth_18.size() > m_vCharPlace_4.size())
		{
			m_b_24 = true;
		}
		else
		{
			m_b_24 = false;
			nSize = m_vCTCHypoth_18.size();
			for (int v10 = 0; v10 < nSize; v10++)
			{
				uint nUnicode = m_vCTCHypoth_18[v10].getUnicode();
				if (!m_vCharPlace_4[v10].is_possible(nUnicode))
				{
					m_b_24 = true;
				}
			}
		}
	}
	bool FieldMaskConstrained::isUnicodePossible(uint a2)
	{
		if (m_b_24)
			return false;
		if (a2 != 0x10ffff)
		{
			if (m_vCTCHypoth_18.size() < m_vCharPlace_4.size())
				return m_vCharPlace_4[m_vCTCHypoth_18.size()].is_possible(a2);
		}
		return false;
	}
	int FieldMaskConstrained::getBeamWidth()
	{
		return 3;
	}
	bool FieldMaskConstrained::isAllSymbolsFound(vector<CTCHypoth> const & a2)
	{
		setPreviousPath(a2);
		int a2Size = a2.size();
		if (a2Size == m_vCharPlace_4.size()) return m_b_24 == false;
		return false;
	}
	bool FieldMaskConstrained::doNotDeleteSymbolsAfterMe()
	{
		return true;
	}
}