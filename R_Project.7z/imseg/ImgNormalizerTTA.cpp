#include "ImgNormalizerTTA.h"

namespace imseg {
	ImgNormalizerTTA::ImgNormalizerTTA(cv::Size const &Size_a1, uint const &un_a2, vector<TTAParams> const &vTTAParams_a3, bool f_a4)
		: m_xImgNormalizer_4(Size_a1, un_a2)
		, m_vTTAParams_1C(vTTAParams_a3)
	{
	}

	ImgNormalizerTTA::~ImgNormalizerTTA()
	{
	}

	void ImgNormalizerTTA::visit(RichTextLines &xRichTextLines)
	{
		vector<RichTextLines> vRichTextLines_4(m_vTTAParams_1C.size(), xRichTextLines);
		for (size_t i = 0; i < m_vTTAParams_1C.size(); i++)
		{
			vRichTextLines_4[i].augment(m_vTTAParams_1C[i]);
			vRichTextLines_4[i].accept(m_xImgNormalizer_4);
		}
		xRichTextLines.setAugmentedVersions(vRichTextLines_4);
	}
}

