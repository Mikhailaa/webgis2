#include "debug.h"
#include "rclhelp.h"


void imseg::debug::fieldsinfo::getSplitFieldInfo(TDocInfo &, string &)
{
}

void imseg::debug::fieldsinfo::addFieldInfo(RclHolder &xRclH_a1, cv::Mat &xFieldImage_a2, TDocInfo &xDocInfo_a3,
	TVisualField &xCVisualField_a4, int n_a5)
{
	//string strSamplePath = rclhelp::getSamplePath(xRclH_a1.m_xTRCL);
	//strSamplePath += "/fields";
}

void imseg::debug::fieldsinfo::saveFieldWithRandomNameInTmpFolder(cv::Mat &, TDocInfo &, TVisualField &, Field &)
{
}

void imseg::debug::fieldsinfo::generateFieldGenerateInfo(Layer_R &, Json::Value &)
{
}
