#pragma once
#include "commonStruct.h"

class TextPartStructPosition
{
public:
	TextPartStructPosition();
	TextPartStructPosition(TextPartStructPosition const&);
	~TextPartStructPosition();
	bool isReady();
	int len();
	void setAsOutSide(int a1, int a2);
	void setPosition(int a1, int a2);
	TextPartStructPosition& operator=(TextPartStructPosition const &a1);
	int status();

	int m_nStatus_0;
	int m_nStartPos_4;
	int m_nEndPos_8;
};

