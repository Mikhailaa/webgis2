#pragma once
#include "pch.h"

namespace reader1D
{
	namespace CTypeCodeCheck
	{
		int getTypeCode3(cv::Mat &);
	}
}