#pragma once

#include "ParsedMask.h"
#include "CTCHypoth.h"

namespace imseg
{
	class Seq2MaskAligner : public ITextLinesVisitor
	{
	public:
		Seq2MaskAligner();
		Seq2MaskAligner(ParsedMask&);
		vector<CharPlace> expandOptional(vector<CTCHypoth>&, vector<CharPlace> const&);
		virtual void process(vector<vector<imseg::CTCHypoth> > &);
		virtual void visit(RichTextLines &);
		static shared_ptr<imseg::ITextLinesVisitor> createSeq2MaskAligner(ParsedMask &);

		ParsedMask m_xParsedMask_4;
	};

	class Seq2MaskAlignerLineBreaksDoesNotMatter :public Seq2MaskAligner
	{
	public:
		Seq2MaskAlignerLineBreaksDoesNotMatter(ParsedMask const&);
		void process(vector<vector<CTCHypoth>> &);
		//virtual void visit(RichTextLines &);
		static vector<vector<CTCHypoth>> uniteSeqs(vector<vector<CTCHypoth>> const&);
		static vector<vector<CTCHypoth>> splitSeqsBack(vector<vector<CTCHypoth>> const&, vector<vector<CTCHypoth>> const&);
	};
}