#pragma once

#include "pch.h"

class CAlphabetFilter
{
public:
	static uchar mask(char);
};
