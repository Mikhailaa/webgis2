#pragma once

#include "pch.h"

namespace imseg
{
	class LCIDPriority
	{
	public:
		LCIDPriority() {};
		~LCIDPriority() {};
		//getLCIDSFromMask No Xref
		uint getTopPriorityLCID(set<uint> const&);
		void push_front(LCIDPriority const&);

		vector<uint> m_vunLCIDP_0;
	};
}