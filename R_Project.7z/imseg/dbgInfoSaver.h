#pragma once
#include "DbgFolder.h"
#include "CTCHypoth.h"
#include "VocabInfo.h"
#include "RichTextLines.h"
#include "common/fs.h"

namespace imseg
{
	class dbgInfoSaver
	{
	public:
		static void saveAfterAlignment(DbgFolder const&, vector<CTCHypoth> const&);
		static void saveAfterLogicalCorrection(imseg::DbgFolder const&, vector<imseg::CTCHypoth> const&);
		static void saveBeforLogicalCorrection(DbgFolder const&, vector<CTCHypoth> const&, cv::Mat const&, vector<uint> const&);
		static void saveInputs(RichTextLines &, string, VocabInfo const&, char const*);
		static void saveImage(cv::Mat const&, cv::Rect_<int> const&, common::fs::Path, string const&);
	};
}