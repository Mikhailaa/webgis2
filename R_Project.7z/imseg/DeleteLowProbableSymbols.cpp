#include "DeleteLowProbableSymbols.h"
#include "HParam.h"

imseg::DeleteLowProbableSymbols::DeleteLowProbableSymbols(int n_a1, ICorrector* pICorrector)
{
	m_pIC_4 = pICorrector;
	m_nDeleteLowProbableSymbols_field_C = n_a1;
	string _s_0("m_lowProb");
	HParam::HParam(m_rDeleteLowProbableSymbols_field_8, _s_0, -1);
}

imseg::DeleteLowProbableSymbols::~DeleteLowProbableSymbols()
{
}

int imseg::DeleteLowProbableSymbols::mustBeDeleted(CTCHypoth &xCTCHypoth)
{
	return (xCTCHypoth.getUnicode() != ' ' && xCTCHypoth.getUnicode() == 0x10FFFF && xCTCHypoth.m_fHandmade_14 < m_rDeleteLowProbableSymbols_field_8);
}

void imseg::DeleteLowProbableSymbols::process_impl(vector<CTCHypoth>&vCTCHypoth)
{
	for (size_t i = 0; i < vCTCHypoth.size(); i++)
	{
		if (mustBeDeleted(vCTCHypoth[i]))
		{
			vCTCHypoth.erase(vCTCHypoth.begin() + i);
		}
	}
}
