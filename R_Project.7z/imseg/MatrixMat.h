#pragma once
#include "imseg_interface.h"

namespace imseg
{
	namespace word_beam_search
	{
		class MatrixMat : public IMatrix
		{
		public:
			const cv::Mat *m_pMM_4;
		public:
			MatrixMat(Mat const&);

			double getAt(uint, uint) const;
			void setAt(uint, uint, double) const;
			int rows(void) const;
			int cols(void) const;
		};
	}
}