#include "MatrixMat.h"

using namespace imseg::word_beam_search;

MatrixMat::MatrixMat(Mat const & a2)
{ 
	m_pMM_4 = &a2;
}

double MatrixMat::getAt(uint a2, uint a3) const
{
	return m_pMM_4->at<float>(a2, a3);
}

void MatrixMat::setAt(uint, uint, double) const
{
}

int MatrixMat::rows(void) const
{
	return m_pMM_4->rows;
}

int MatrixMat::cols(void) const
{
	return m_pMM_4->cols;
}
