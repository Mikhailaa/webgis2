#include "DeleteSequentialSpaces.h"

namespace imseg
{
	set<uint> DeleteSequentialSpaces::m_canNotBeSequential = { ' ','.','-' };//32 46 45
	bool DeleteSequentialSpaces::canNotBeSequential(uint a1)
	{
		return m_canNotBeSequential.find(a1) != m_canNotBeSequential.end();
	}
	DeleteSequentialSpaces::DeleteSequentialSpaces(ICorrector *pICorrector)
	{
		m_pIC_4 = pICorrector;
	}

	void DeleteSequentialSpaces::process_impl(vector<CTCHypoth>&vCTCHypoth)
	{
		if (vCTCHypoth.size() < 2)
			return;

		for (size_t i = 0; i < vCTCHypoth.size() - 1; i++)
		{
			uint nTmpUnicode0 = vCTCHypoth[i].getUnicode();
			uint nTmpUnicode1 = vCTCHypoth[i + 1].getUnicode();
			if (nTmpUnicode0 == nTmpUnicode1)
			{
				if (canNotBeSequential(nTmpUnicode0))
				{
					vCTCHypoth.erase(vCTCHypoth.begin() + i);
					i--;
				}
			}
		}
	}
}