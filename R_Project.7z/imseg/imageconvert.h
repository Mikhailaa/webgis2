#pragma once
//#include "../common/all/Json.h"
//#include "../common/container/RclHolder.h"
#include "json/Value.h"
#include "commonStruct.h"

namespace procmgr {
	
	namespace imageconvert {

		int getImageFromJson(eProcessCommands, Json::Value &, common::container::RclHolder &);
		int cropImage(Json::Value &, common::container::RclHolder &, float, POINT &);			
	}
}
