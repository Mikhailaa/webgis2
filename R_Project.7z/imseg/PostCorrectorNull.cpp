#include "PostCorrectorNull.h"

imseg::PostCorrectorNull::PostCorrectorNull()
{
}

void imseg::PostCorrectorNull::visit(RichTextLines &)
{
}
