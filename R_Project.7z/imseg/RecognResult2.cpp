#include "RecognResult2.h"

RecognResult2::RecognResult2()
{
}

RecognResult2::RecognResult2(RecognResult2 &&a1)
{
	m_vSymCandidat = move(a1.m_vSymCandidat);
}

vector<int> RecognResult2::candidates(float a1)
{
	vector<int> vRet;
	for(size_t i = 0; i < m_vSymCandidat.size(); i++)
	{
		if(probF(i) >= a1)
			vRet.push_back(candidate(i));
	}
	return vRet;
}

int RecognResult2::candidate(int a1)
{
	if(m_vSymCandidat.empty())
		return 0;
	else
		return m_vSymCandidat[a1].m_wszCandiateCharacter_0;
}

void RecognResult2::candidates(int a1, vector<int>& a2)
{
	a2.clear();
	float rProb = probF(0);
	for(size_t i= 0; i < m_vSymCandidat.size(); i++)
	{
		if(probF(i) <= a1 / 100.0f)
			a2.push_back(candidate(i));
	}
}

int RecognResult2::prob(int arg1)
{
	if ((int)m_vSymCandidat.size() <= arg1)
		return 0;
	return int((m_vSymCandidat.at(arg1).m_rProv_4) * 100.0f + 0.5f);
}

float RecognResult2::probF(int arg1)
{
	if ((int)m_vSymCandidat.size() <= arg1)
		return 0.0f;
	return m_vSymCandidat.at(arg1).m_rProv_4;
}

RecognResult2& RecognResult2::operator=(RecognResult2 &arg1)
{
	if(this != &arg1)
		m_vSymCandidat = arg1.m_vSymCandidat;
	return *this;
}

