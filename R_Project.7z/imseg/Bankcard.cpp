#include "Bankcard.h"

int sub_4BFC84(float r_L, float r_H, Rect xRect_a2)
{
	if (r_L > xRect_a2.height * xRect_a2.width)
		return 1;
	int res = 0;
	if (r_H > xRect_a2.height)
		res = 1;
	return res;
}

bool compY(Rect&A, Rect&B)
{
	if (A.y < B.y)
		return 1;
	else
		return 0;
}

namespace imseg
{
	namespace bankcard
	{
		TextDetectorBankCardDummy::TextDetectorBankCardDummy()
		{
			m_rTextDetectorBankCardDummy_C = 0;
			m_rTextDetectorBankCardDummy_10 = 0;
			m_rTextDetectorBankCardDummy_14 = 0;
		}

		TextDetectorBankCardDummy::~TextDetectorBankCardDummy()
		{

		}

		vector<Rect> TextDetectorBankCardDummy::postprocDetections(Mat &, vector<Rect>&)
		{
			return vector<Rect>();
		}

		//RichTextLines& TextDetectorBankCardDummy::detect(RichTextLines &xRichTextLines)
		//{
		//	return xRichTextLines;
		//}

		Mat TextDetectorBankCardDummy::resize(Mat& Mat_a1, float& r_a2, float& r_a3)
		{
			r_a2 = 1.0f;
			r_a3 = 1.0f;
			return Mat(Mat_a1);
		}

		TextDetectorBankCardName::TextDetectorBankCardName(Size& Size_a1, shared_ptr<dnn::Net> &sp_Net_a2)
		{
			m_spNet_4 = sp_Net_a2;
			m_xSize_C = Size_a1;
			m_r_14 = 0.2f;
			m_r_18 = 10.0f;
		}

		TextDetectorBankCardName::~TextDetectorBankCardName()
		{

		}

		Mat TextDetectorBankCardName::resize(Mat& Mat_a1, float& r_a2, float& r_a3)
		{
			Mat res;
			cv::resize(Mat_a1, res, m_xSize_C, 0.0, 0.0, 2);
			r_a2 = 1.0f * Mat_a1.cols / res.cols;
			r_a3 = 1.0f * Mat_a1.rows / res.rows;
			return res;
		}

		vector<Rect> imseg::bankcard::TextDetectorBankCardName::findTextLines(vector<Rect>&vRect_a1)
		{
			vector<Rect> res;
			if (vRect_a1.empty())
				return res;
			vector<Rect> vRect_18(vRect_a1), vRect_C;
			sort(vRect_18.begin(), vRect_18.end(), compY);
			Rect xRectTmp;
			for (size_t i = 0; i < vRect_18.size(); i++)
			{
				vRect_C.push_back(vRect_18[i]);
				Rect xRectTmp_i = vRect_18[i], xRectTmp;
				for (size_t j = i; j < vRect_18.size(); j++)
				{
					float rTmp_v14 = (float)abs(vRect_C[i].y + vRect_C[i].height - vRect_18[j].y - vRect_18[j].height);
					if (rTmp_v14 * 2 / (vRect_C[i].height + vRect_18[j].height) >= 0.6f)
						break;
					if (vRect_C[i].height < 1 || vRect_C[i].width < 1)
						vRect_C[i] = vRect_18[j];
					else
					{
						if (vRect_18[j].width >= 1 && vRect_18[j].height >= 1)
						{
							vRect_C[i].x = MIN(vRect_C[i].x, vRect_18[j].x);
							vRect_C[i].y = MIN(vRect_C[i].y, vRect_18[j].y);
							vRect_C[i].width = MAX(vRect_C[i].x + vRect_C[i].width, vRect_18[j].x + vRect_18[j].width) - vRect_C[i].x;//PKS Z
							vRect_C[i].height = MAX(vRect_C[i].y + vRect_C[i].height, vRect_18[j].y + vRect_18[j].height) - vRect_C[i].y;
						}
					}
					i++;
				}
			}
			res = vRect_C;
			return res;
		}

		vector<Rect> TextDetectorBankCardName::postprocDetections(Mat& Mat_a1, vector<Rect>& vRect_a2)
		{
			vector<Rect> res, vRect_C;
			float rTmp_v8 = Mat_a1.size().height * Mat_a1.size().width * 0.015f;
			float rTmp_v9 = Mat_a1.rows * 0.15f;

			res = findTextLines(vRect_a2);
			if (res.empty())
				return res;
			size_t i, j;
			for (i = 0; i < res.size(); i++)
			{
				if (sub_4BFC84(rTmp_v8, rTmp_v9, res[i]))
				{
					for (j = i; j < res.size() - 1; j++)
					{
						if (!sub_4BFC84(rTmp_v8, rTmp_v9, res[j]))
						{
							res[i] = res[j];
							i++;
						}
					}
					break;
				}
			}
			res.erase(res.begin() + i, res.end());

			Rect xRectTmp;
			for (i = 0; i < res.size(); i++)
			{
				xRectTmp.x = max(0, res[i].x - int(m_r_18 * res[i].height));
				xRectTmp.y = max(0, res[i].y);
				xRectTmp.width = min(Mat_a1.size().width,
					int((res[i].width + m_r_18 * 2 * res[i].height) + (res[i].x - m_r_18 * res[i].height))) - xRectTmp.x;
				xRectTmp.height = min(Mat_a1.size().height,
					(res[i].y + res[i].height)) - xRectTmp.y;

				if (xRectTmp.width < 1 || xRectTmp.height < 1)
				{
					xRectTmp.x = 0;
					xRectTmp.y = 0;
					xRectTmp.width = 0;
					xRectTmp.height = 0;
				}
				res[i] = xRectTmp;
			}
			return res;
		}

		TextDetectorBankCardValidThru::TextDetectorBankCardValidThru(Size &xSize_a1, shared_ptr<dnn::Net>&spNet_a2)
		{
			m_spNet_4 = spNet_a2;
			m_xSize_C = xSize_a1;
			m_r_14 = 0.01f;
			m_r_18 = 0.0f;
			m_r_1C = 6.0f;
		}

		TextDetectorBankCardValidThru::~TextDetectorBankCardValidThru()
		{
		}

		vector<Rect> TextDetectorBankCardValidThru::postprocDetections(Mat &xMat, vector<Rect>&vRect)
		{
			vector<Rect> vRectRes;
			Rect xRect_0;
			if (!vRect.empty())
			{
				for (int i = 0; ; i++)
				{
					if (i == vRect.size())
					{
						xRect_0 = vRect.front();
						break;
					}

					if (float(vRect[i].width) / float(vRect[i].height) < m_r_1C)
					{
						xRect_0 = vRect[i];
						break;
					}
				}
				xRect_0.x -= int(m_r_18 * xRect_0.height);
				xRect_0.width += int(2 * m_r_18 * xRect_0.height);
				vRectRes.push_back(xRect_0);
			}
			return vRectRes;
		}

		Mat TextDetectorBankCardValidThru::resize(Mat &xMat, float &r_1, float &r_2)
		{
			Mat Mat_res(xMat);
			float rKW = (float)m_xSize_C.width / Mat_res.size().width;
			float rKH = (float)m_xSize_C.height / Mat_res.size().height;
			if (rKH >= rKW)
			{
				cv::resize(Mat_res, Mat_res, Size(m_xSize_C.width, int(rKW * Mat_res.size().height)), 0.0, 0.0, 2);
				int nDH = m_xSize_C.height - Mat_res.size().height;
				if (nDH >= 1)
					copyMakeBorder(Mat_res, Mat_res, 0, nDH, 0, 0, 1);
				rKH = rKW;
			}
			else
			{
				cv::resize(Mat_res, Mat_res, Size(int(rKH * Mat_res.size().width), m_xSize_C.height), 0.0, 0.0, 2);
				int nDW = m_xSize_C.width - Mat_res.size().width;
				if (nDW >= 1)
					copyMakeBorder(Mat_res, Mat_res, 0, nDW, 0, 0, 1);
				rKH = rKW;
			}
			r_1 = 1.0f / rKH;
			r_2 = 1.0f / rKW;
			return Mat_res;
		}


		BankCardNumberPostCorrector::BankCardNumberPostCorrector()
		{
		}

		void BankCardNumberPostCorrector::visit(RichTextLines &)
		{
		}

		BankCardDatePostCorrector::BankCardDatePostCorrector()
		{
		}

		void BankCardDatePostCorrector::visit(RichTextLines &)
		{
		}

		BankCardExtractNameStringPostCorrector::BankCardExtractNameStringPostCorrector()
		{
		}

		void BankCardExtractNameStringPostCorrector::visit(RichTextLines &)
		{
		}
	}
}


