#include "DecoderCTC.h"
#include "imseg.h"
#include "dnn/dnn_serialization.h"

using namespace imseg;

cv::Mat softmax(cv::Mat &a2)
{
	cv::Mat ret(a2.size(), 5);

	for (int i = 0; i < a2.rows; i++)
	{
		cv::Mat v31 =  a2.row(i);
		float rMax = *(float *)v31.data;
		for (int j = 0; j < a2.cols; j++)
		{
			if (*((float *)v31.data + j) > rMax)
				rMax = *((float *)v31.data + j);
		}

		cv::MatExpr v30 = cv::operator-(v31, cv::Scalar_<double>(rMax, 0.0, 0.0, 0.0));
		cv::Mat mat_1C8;
		cv::exp((cv::Mat)v30, mat_1C8);
		cv::Scalar_<double> scalar_1E8 = cv::sum(mat_1C8);
		mat_1C8.convertTo(mat_1C8, -1, 1.0 / scalar_1E8[0], 0.0);
		mat_1C8.copyTo(ret.row(i));
	}
	return ret;
}

DecoderCTC::DecoderCTC()
{
	string strName("m_secondHypProbDivisor");
	HParam(m_rDCTC_secondHypProbDivisor_0, strName, -1);
}

void DecoderCTC::addVisualyIdenticalHypoths(set<unsigned int> const &set_a1, CTCHypoth &xCTCHy)
{
	uint nUnicode = xCTCHy.getUnicode();
	vector<uint> vVisualIdentSet = imseg::unicodes::getVisualIdenticalSetForUnicode(nUnicode);

	for (size_t i = 0; i < vVisualIdentSet.size(); i++)
	{
		if (set_a1.find(vVisualIdentSet[i]) != set_a1.end() && nUnicode != vVisualIdentSet[i])
		{
			CTCHypoth xCTCHyTmp(xCTCHy);
			xCTCHyTmp.setUnicode(vVisualIdentSet[i]);
			xCTCHy.m_lstImCTCHy_18.push_back(xCTCHyTmp);
			xCTCHyTmp.m_lstImCTCHy_18.clear();
		}
	}
}

set<uint> DecoderCTC::getAllUnicodes()
{
	set<uint> set_ret;
	for (size_t i = 0; i < m_vDCTC_Labels_10.size(); i++)
		set_ret.insert(m_vDCTC_Labels_10[i]);
	return set_ret;
}

int DecoderCTC::getLabelNum()
{
	return m_vDCTC_Labels_10.size() + 1;
}

vector<uint> DecoderCTC::getLabels()
{
	return m_vDCTC_Labels_10;
}



void DecoderCTC::getSecondaryHypoths(float const *pr_a2, uint const &n_a3, Label2Unicodes const &xL2U_a4, CTCHypoth &xCTCHy_a5)
{
	for (size_t i = 0; i < n_a3; i++)
	{
		if (i != xCTCHy_a5.field_8)
		{
			if (xCTCHy_a5.m_fHandmade_14 >= pr_a2[i] &&
				(xCTCHy_a5.m_fHandmade_14 / m_rDCTC_secondHypProbDivisor_0) < pr_a2[i])
			{
				vector<uint> vTmp = xL2U_a4(i);
				for (size_t j = 0; j < vTmp.size(); j++)
				{
					CTCHypoth CTCHy;
					CTCHy.field_0 = vTmp[j];
					CTCHy.m_wcUnicode_4 = vTmp[j];
					CTCHy.field_8 = i;
					CTCHy.m_nIndex_C = xCTCHy_a5.m_nIndex_C;
					CTCHy.m_fcalcX_10 = 0.0f;
					CTCHy.m_fHandmade_14 = pr_a2[i];
					xCTCHy_a5.m_lstImCTCHy_18.emplace_back(CTCHy);

				}
			}
		}
	}

	xCTCHy_a5.m_lstImCTCHy_18.sort(greater<>());

}

void imseg::DecoderCTC::io_generic(cv::dnn::DnnReader & a2)
{
	cv::dnn::io_vec_uint(a2, m_vDCTC_Labels_10);
	dnn_serialization::io(a2, m_tDCTC_field_4);
}

vector<CTCHypoth> DecoderCTC::parseByWordBeamSearch(uint n_a2, cv::Mat const &mat_a3, Label2Unicodes const &xL2U_a4)
{
	vector<CTCHypoth> vRet;
	
	map<unsigned int, shared_ptr<LanguageModel>>::iterator find_iter = m_tDCTC_field_4.find(n_a2);

	if(find_iter != m_tDCTC_field_4.end() && !find_iter->second)
	{ 
		//no check;
		//Log("imseg::ParseByWordBeamSearch");
		MatrixMat matrixMat(mat_a3);
		vRet = wordBeamSearch(matrixMat, xL2U_a4, find_iter->second, LANGUAGEMODELTYPE_0);
	}
	
	return vRet;
}

vector<CTCHypoth> DecoderCTC::parseByMaskBeamSearch(cv::Mat const &mat_a2, cv::Mat const &mat_a3, 
	Label2Unicodes const &xL2U_a4, vector<CTCHypoth> vHy_a5, shared_ptr<IFieldMask>& sptr_a6, set<uint> const &set_a7)
{
	vector<CTCHypoth> vCTCHy = parseFast(mat_a2, mat_a3, xL2U_a4);
	vHy_a5 = vCTCHy;
	if (sptr_a6->isAllSymbolsFound(vCTCHy))
	{
		vHy_a5 = vCTCHy;
	}
	else
	{
		//no check
		vector<CTCHypoth> vCTCHy1 = parseSlow(sptr_a6, mat_a2, mat_a3, xL2U_a4);
		if (!vCTCHy1.empty()) vHy_a5 = vCTCHy1;
	}

	if (!sptr_a6->isAllSymbolsFound(vCTCHy)) 
		vHy_a5 = vCTCHy;

	for (size_t i = 0; i < vHy_a5.size(); i++)
	{
		addVisualyIdenticalHypoths(set_a7, vHy_a5[i]);
		getSecondaryHypoths((float*)(mat_a3.data + *mat_a3.step.p * vHy_a5[i].m_nIndex_C),mat_a3.cols,xL2U_a4, vHy_a5[i]);
	}
	return vHy_a5;
}

vector<CTCHypoth> DecoderCTC::parseFast(cv::Mat const &mat_a2, cv::Mat const &mat_a3, Label2Unicodes const &xL2U_a4)
{
	// TODO: insert return statement here
	shared_ptr<IFieldMask> sptrFMSA = make_shared<FieldMaskArbitrarySymbols>();
	CTCBeam xCTCBeam(sptrFMSA, mat_a2.rows);
	for (int i = 0; i < mat_a3.rows; i++)
		xCTCBeam.update((float*)(mat_a3.data + *mat_a3.step.p * i), mat_a3.cols, xL2U_a4, i);
	return xCTCBeam.getMostProbableSeq();
}

vector<CTCHypoth> DecoderCTC::parseLogits(uint n_a2, set<uint> const &set_a3, shared_ptr<IFieldMask>& sptr_a4, cv::Mat &mat_a5)
{
	vector<CTCHypoth> vRet;
	
	Label2Unicodes  xL2U(m_vDCTC_Labels_10, set_a3);
	xL2U.deleteForbiddenSymbols(mat_a5);
	cv::Mat matTmp = softmax(mat_a5);
	xL2U.deleteForbiddenSymbols(matTmp);

	vRet = parseByWordBeamSearch(n_a2, matTmp, xL2U);

	if(vRet.empty())
	{
		vRet = parseByMaskBeamSearch(mat_a5, matTmp, xL2U,
			vector<CTCHypoth>(vRet), sptr_a4, set_a3);
	}
	
	return vRet;
}

vector<CTCHypoth> DecoderCTC::parseSlow(shared_ptr<IFieldMask>& sptrIFM_a1, cv::Mat const &mat_a2, cv::Mat const &mat_a3, Label2Unicodes const &xL2U_a4)
{
	vector<CTCHypoth> vRet;
	CTCBeam xCTCBeam(sptrIFM_a1, mat_a2.rows);
	for (int i = 0; i < mat_a2.rows; i++)
		xCTCBeam.update((float*)(mat_a3.data + *mat_a3.step.p * i), mat_a3.cols, xL2U_a4, i);
	xCTCBeam.deleteUnfinishedPathsIfFinishedPathExist();
	if (!xCTCBeam.empty()) vRet = xCTCBeam.getMostProbableSeq();
	return vRet;
}
