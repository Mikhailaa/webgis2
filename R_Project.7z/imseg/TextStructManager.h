#pragma once 
#include "commonStruct.h"
#include "AlphabetInfo.h"
#include "BaseLines.h"
#include "VisualField.h"
#include "RecognizedTextDoc.h"
#include "InitConstStructs.h"
#include "SymbolCandidatWithRect.h"
#include "Symbols.h"
#include "TextStruct.h"
#include "imseg_interface.h"

using namespace imseg;


class TextStructManager
{
public:
	static void correctEnums(TextStruct &);
	static void correctLcids(IAlphabetInfo &, ISymbolsIndexMap &, TextStruct &);
	static void checkSemantic(ISymbolsInfoByUnicode &, TextStruct &, InitConstStructs &, BaseLines &, bool);
	static void deleteTrashDublicates(vector<vector<vector<SymbolCandidatWithRect>>> &);
	static void generateResults(IFieldInfo &, TextStruct &, CVisualField &, CRecognizedTextDoc &, int, int, float);
	static void generateWordsInString(TextStruct &, int, int, bool);
	static void getParamFromMask(string&, unordered_map<eProcessOptions, string> &);
	static vector<int> getUnicFieldTypeList(TextStruct &);
	static void initAlphabets(TextStruct &, CVisualField &, ISymbolsInfoEx &);
	static bool isFix(TextStruct &, vector<uchar> &, bool);
	static bool isStructureReady(TextStruct &);
	static void lineCount(TextStruct &, int &);
	static void maskAnalize(TextStruct &, FieldParam &);
	static void numberOfError(TextStruct &, int &, int &);
	static void postProcessing(CRecognizedTextFieldSDK &, eTextPostProcessing);
	static void splitByContent2(TextStruct &, Text &);
	static void splitByContentR(TextStruct &, Text &, int, vector<pair<int, int>> &, bool &);
	static void splitByNeighbor(TextStruct &, Text &, bool, bool, bool);
	static bool splitBySpaceAttempt(vector<CSymbolResult> &, TextPartStruct &, int &, int &, int, int, bool);
	static bool splitMask(string &, CVisualField &, TextStruct &);
	static void updateSpacePosition(TextStruct &);
};