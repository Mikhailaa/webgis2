#include "TextPartStruct.h"
#include "common/UnicodeUtils.h"

TextPartStruct::TextPartStruct()
{
	reset();
}

TextPartStruct::TextPartStruct(TextPartStruct const & a2) :
	m_xCAlphatF_C(a2.m_xCAlphatF_C),
	m_vucharName_3C(a2.m_vucharName_3C),
	m_vuchar_48(a2.m_vuchar_48),
	m_vpairnn_54(a2.m_vpairnn_54),
	m_vCSymbolResult_60(a2.m_vCSymbolResult_60),
	m_xTextPartLCIDInfo_70(a2.m_xTextPartLCIDInfo_70)
{
	m_Position_0 = a2.m_Position_0;
	m_bField_38 = a2.m_bField_38;
	m_bField_39 = a2.m_bField_39;
	m_bField_3A = a2.m_bField_3A;
	m_nField_30 = a2.m_nField_30;
	m_pCVisualSubField_34 = a2.m_pCVisualSubField_34;
	m_sFieldType_6C = a2.m_sFieldType_6C;
	m_bField_6E = a2.m_bField_6E;
	m_bField_6F = a2.m_bField_6F;
}

TextPartStruct::TextPartStruct(TextPartStruct && a2)
{
	m_xCAlphatF_C = move(a2.m_xCAlphatF_C);
	m_vucharName_3C = move(a2.m_vucharName_3C);
	m_vuchar_48 = move(a2.m_vuchar_48);
	m_vpairnn_54 = move(a2.m_vpairnn_54);
	m_vCSymbolResult_60 = move(a2.m_vCSymbolResult_60);
	m_xTextPartLCIDInfo_70 = move(a2.m_xTextPartLCIDInfo_70);
	m_Position_0 = a2.m_Position_0;
	m_bField_38 = a2.m_bField_38;
	m_bField_39 = a2.m_bField_39;
	m_bField_3A = a2.m_bField_3A;
	m_nField_30 = a2.m_nField_30;
	m_pCVisualSubField_34 = a2.m_pCVisualSubField_34;
	m_sFieldType_6C = a2.m_sFieldType_6C;
	m_bField_6E = a2.m_bField_6E;
	m_bField_6F = a2.m_bField_6F;

}

TextPartStruct::~TextPartStruct()
{
}

TextPartStruct& TextPartStruct::operator=(const TextPartStruct& a2)
{
	m_Position_0 = a2.m_Position_0;
	m_xCAlphatF_C = a2.m_xCAlphatF_C;
	m_nField_30 = a2.m_nField_30;
	m_pCVisualSubField_34 = a2.m_pCVisualSubField_34;
	m_bField_38 = a2.m_bField_38;
	m_bField_39 = a2.m_bField_39;
	m_bField_3A = a2.m_bField_3A;

	if (this != &a2)
	{
		m_vucharName_3C = a2.m_vucharName_3C;
		m_vuchar_48 = a2.m_vuchar_48;
		m_vpairnn_54 = a2.m_vpairnn_54;
		m_vCSymbolResult_60 = a2.m_vCSymbolResult_60;
	}

	m_sFieldType_6C = a2.m_sFieldType_6C;
	m_bField_6E = a2.m_bField_6E;
	m_bField_6F = a2.m_bField_6F;
	m_xTextPartLCIDInfo_70 = a2.m_xTextPartLCIDInfo_70;
	return *this;
}

int TextPartStruct::fieldType()
{
	return m_sFieldType_6C;
}

int TextPartStruct::fieldTypeFull()
{
	int v4;

	if (m_xTextPartLCIDInfo_70.m_vLcids_4.empty())
		v4 = 0;
	else
		v4 = m_xTextPartLCIDInfo_70.m_vLcids_4.front() << 16;

	return m_sFieldType_6C | v4;
}

wstring TextPartStruct::getName()
{
	return common::UnicodeUtils::UncheckedUtf8ToWStr(string(m_vucharName_3C.begin(), m_vucharName_3C.end()));
}

bool TextPartStruct::isSpace()
{
	return false;
}

void TextPartStruct::reset()
{
	m_bField_38 = true;
	m_bField_39 = false;
	m_bField_3A = false;
	m_nField_30 = 0;
	m_pCVisualSubField_34 = 0;
	m_sFieldType_6C = 0;
	m_bField_6E = 0;
	m_bField_6F = 0;
	m_vucharName_3C.clear();
	m_vuchar_48.clear();
	m_xTextPartLCIDInfo_70.m_vLcids_4.clear();
}

vector<CSymbolResult>& TextPartStruct::text()
{
	return m_vCSymbolResult_60;
}

TextPartStructPosition& TextPartStruct::position()
{
	return m_Position_0;
}
