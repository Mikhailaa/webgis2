#pragma once
#include <set>
#include "pch.h"
#include "Symbol.h"
#include "BaseLines.h"
#include "TextStruct.h"

class Text
{
public:
	vector<imseg::Symbol> m_vimsegSymbol_0;
	vector<BaseLines> m_vBaseLines_C;
	int m_nLcid_18;
	int field_1C;
	int field_20;	

	Text();
	Text(Text const&);
	Text(Text &&);
	~Text();
	void init(vector<cv::Rect> &);
	void init(vector<Text> &);
	void init(tagRECT &);

	//void addShift(tagPOINT &); no xref
	BaseLines& baseLine(int);
	int baseLineIndex(int);
	//distance(int,int)  no xref
	//getText(std::__ndk1::vector<int,std::__ndk1::allocator<int>> &) no xref
	Text& operator=(Text const&);
	Text & operator=(Text &&a2);
};

namespace TextInfo
{
	void alphabets(TextStruct&, set<int>&);
};
