#pragma once
#include "..\pch.h"
class ConflictGroups
{
public:
	ConflictGroups();
	int m_n_0;
	vector<int> m_vn_4;
	vector<int> m_vn_10;
};