﻿#include "FacadeDNNOCR.h"
#include "imseg.h"
#include "Corrector.h"

namespace imseg
{

	FacadeDNNOCR::FacadeDNNOCR()
	{
	}

	FacadeDNNOCR::~FacadeDNNOCR()
	{
	}

	vector<uint> FacadeDNNOCR::addNumberToAlphabet(string const &str_a3, vector<uint> const &v_a4)
	{
		if (str_a3.find('W') == -1)
			return v_a4;

		vector<uint> v_ret;
		v_ret.push_back(0x2116);
		v_ret.push_back('N');
		for (size_t i = 0; i < v_a4.size(); i++)
			v_ret.push_back(v_a4[i]);

		return v_ret;
	}

	Ensemble* FacadeDNNOCR::getMostSuitableEnsemble(uint n_a2)
	{
		// TODO: insert return statement here
		map<uint, Ensemble>::iterator iter = m_tFDNNO_field_0.find(n_a2);
		if (iter == m_tFDNNO_field_0.end()) return NULL;
		return &iter->second;
	}

	ITextDetector* FacadeDNNOCR::getMostSuitableTextDetector(uint n_a2)
	{
		// TODO: insert return statement here
		map<uint, shared_ptr<ITextDetector>>::iterator iter = m_tFDNNO_field__C.find(n_a2);
		if (iter == m_tFDNNO_field__C.end()) return nullptr;
		return (*iter).second.get();
	}

	uint FacadeDNNOCR::getTopPriorityLCID(ParsedMask &xPM_a2)
	{
		// TODO: insert return statement here
		if (xPM_a2.isBankCardNumber())
			return 10000;
		if (xPM_a2.isBankCardValidThru())
			return 10001;
		if (xPM_a2.isBankCardName())
			return 10002;
		set<uint> setFoundLCIDs = xPM_a2.getFoundLCIDs();
		return m_xFDNNO_LCIDP__18.getTopPriorityLCID(setFoundLCIDs);
	}

	void FacadeDNNOCR::recognize(TextLines &xTL_a2, VocabInfo const &xVI_a3, ParsedMask &xPM_a4,
		char const *sz_a5, DbgFolder const &xDF_a6, Field &xF_a7)
	{

		//Log("imseg::FacadeDNNOCR::recognize");
		//imshow("dd", xTL_a2.m_xMat_4);
		//waitKey();
		string strMask = xPM_a4.getStringMask();
		vector<uint> vAddtionalAlphabet = xPM_a4.getAdditionalAlphabet();
		vector<uint> vTmp = addNumberToAlphabet(strMask, vAddtionalAlphabet);
		vector<shared_ptr<IFieldMask>> vspFiledMask = xPM_a4.getFieldMasks();
		uint nTopPrioLCID = getTopPriorityLCID(xPM_a4);
		RichTextLines xRTL(xTL_a2, vTmp, xDF_a6, nTopPrioLCID);

		Ensemble *pMSE_Ensm = getMostSuitableEnsemble(nTopPrioLCID);
		if (pMSE_Ensm)
		{
			pMSE_Ensm->setMasks(vspFiledMask);
			xRTL = refineTextDetection(nTopPrioLCID, xRTL);

			if (!xRTL.empty())
			{
				cv::Size xSize = pMSE_Ensm->getSize();
				shared_ptr<ITextLinesVisitor> spITLV_1 = IImgNormalizer::factory(nTopPrioLCID, xVI_a3.nCount_0, xSize);
				shared_ptr<ITextLinesVisitor> spITLV_2 = IPostCorrector::factory(xF_a7.param());
				Corrector xCorrector(nTopPrioLCID, vspFiledMask, xF_a7.param());
				shared_ptr<ITextLinesVisitor> spITLV_3 = Seq2MaskAligner::createSeq2MaskAligner(xPM_a4);
				SeqConfidenceVouter xSCV;
				dbgInfoSaver::saveInputs(xRTL, strMask, xVI_a3, sz_a5);

				xRTL.accept(*spITLV_1);
			

				xRTL.accept(*pMSE_Ensm);
				for (size_t k1 = 0; k1 < xRTL.m_vRichTLs_98.size(); k1++)
				{
					
					for (size_t k2 = 0; k2 < xRTL.m_vRichTLs_98[k1].m_vvImCTCHy_74.size(); k2++)
					{
						int nFlag = 0, nCount = 0, nIgnor = 0;
						for (size_t k3 = 0; k3 < xRTL.m_vRichTLs_98[k1].m_vvImCTCHy_74[k2].size(); k3++)
						{
							if (xRTL.m_vRichTLs_98[k1].m_vvImCTCHy_74[k2][k3].field_0 != 0x0010FFFF) {
								if (nCount > 50 || nIgnor)
								{
									xRTL.m_vRichTLs_98[k1].m_vvImCTCHy_74[k2][k3].field_0         = xRTL.m_vRichTLs_98[k1].m_vvImCTCHy_74[k2][k3-1].field_0;
									xRTL.m_vRichTLs_98[k1].m_vvImCTCHy_74[k2][k3].m_wcUnicode_4   = xRTL.m_vRichTLs_98[k1].m_vvImCTCHy_74[k2][k3-1].m_wcUnicode_4;
									xRTL.m_vRichTLs_98[k1].m_vvImCTCHy_74[k2][k3].field_8         = xRTL.m_vRichTLs_98[k1].m_vvImCTCHy_74[k2][k3-1].field_8;
									xRTL.m_vRichTLs_98[k1].m_vvImCTCHy_74[k2][k3].m_nIndex_C      = xRTL.m_vRichTLs_98[k1].m_vvImCTCHy_74[k2][k3-1].m_nIndex_C;
									xRTL.m_vRichTLs_98[k1].m_vvImCTCHy_74[k2][k3].m_fcalcX_10     = xRTL.m_vRichTLs_98[k1].m_vvImCTCHy_74[k2][k3-1].m_fcalcX_10;
									xRTL.m_vRichTLs_98[k1].m_vvImCTCHy_74[k2][k3].m_fHandmade_14  = xRTL.m_vRichTLs_98[k1].m_vvImCTCHy_74[k2][k3-1].m_fHandmade_14;
									xRTL.m_vRichTLs_98[k1].m_vvImCTCHy_74[k2][k3].m_lstImCTCHy_18 = xRTL.m_vRichTLs_98[k1].m_vvImCTCHy_74[k2][k3-1].m_lstImCTCHy_18;
									nIgnor = 1;
								}
								nFlag = 1;
								nCount = 0;
							}
							nCount += nFlag;
						}
					}
				}
				xRTL.accept(xCorrector);
				xRTL.accept(xSCV);
				//xRTL.accept(*spITLV_3);
				xRTL.accept(*spITLV_2);
				xRTL >> xTL_a2;
				vector<vector<vector<SymbolCandidatWithRect>>> vResults = xTL_a2.getResults();
				string strResults = imseg::toString(vResults);

				//Log("recognition result = %s", strResults);
				float rMinProb = xTL_a2.calcMinProb();
				strResults = to_string(rMinProb);
				//Log("min symbol prob = %f", strResults);
			}
		}
	}

	RichTextLines FacadeDNNOCR::refineTextDetection(uint n_a2, RichTextLines &xRTL_a3)
	{
		ITextDetector *pITLV = getMostSuitableTextDetector(n_a2);
		if (pITLV)
		{
			//no check
			//Log("imseg::FacadeDNNOCR::recognize::textDetector");
			xRTL_a3.accept(*(ITextLinesVisitor*)pITLV);
		}

		return xRTL_a3;
	}

	
	int FacadeDNNOCR::load(istringstream & a2)
	{
		cv::dnn::DnnReader dnnReader;
		uint n1;
		uint nCount;
		vector<uint> a1;
		cv::Size size;
		shared_ptr<cv::dnn::Net> ptrDnn;
		LCIDPriority v53;
		vector<vector<uint>> v50;
		shared_ptr<ITextDetector> v46;

		dnnReader.m_pDR_istream = &a2;
		dnnReader.io(&n1);

		if (n1 != 4)
		{
			return 0;
		}
		dnnReader.io(&nCount);

		for (size_t i = 0; i < nCount; i++)
		{
			cv::dnn::io_vec_uint(dnnReader, a1);
			dnnReader.io(&size);
			ptrDnn = make_shared<cv::dnn::Net>();
			ptrDnn->io(dnnReader);
			for (size_t j = 0; j < a1.size(); j++)
			{
				v46 = ITextDetector::factory(a1[j], size, ptrDnn);
				m_tFDNNO_field__C[a1[j]] = v46;
			}
		}
		cv::dnn::io_vec_uint(dnnReader, v53.m_vunLCIDP_0);
		m_xFDNNO_LCIDP__18.push_front(v53);

		cv::dnn::io_vec_vec_uint(dnnReader, v50);

		for (size_t i = 0; i < v50.size(); i++)
		{
			Ensemble ensemble;

			ensemble.io_generic(dnnReader);
			for (size_t j = 0; j < v50[i].size(); j++)
			{
				m_tFDNNO_field_0[v50[i][j]] = ensemble;
			}
		}

		return true;
	}

}


