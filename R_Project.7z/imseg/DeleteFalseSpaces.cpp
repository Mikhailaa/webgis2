#include "DeleteFalseSpaces.h"

imseg::DeleteFalseSpaces::DeleteFalseSpaces(int n_a1, ICorrector *pICorrector)
{
	m_pIC_4 = pICorrector;
	m_nDeleteFalseSpaces_field_8 = n_a1;
	m_rDeleteFalseSpaces_field_C = 0.46f;
}

imseg::DeleteFalseSpaces::~DeleteFalseSpaces()
{
}

float imseg::DeleteFalseSpaces::calcMeanSymbolsDist(vector<CTCHypoth>&vCTCHypoth)
{
	if (vCTCHypoth.size() < 2)
		return 1.0;
	int v5 = 0, v9;
	for (size_t i = 1; i < vCTCHypoth.size(); i++)
	{
		v9 = vCTCHypoth[i].getIndex() + v5;
		v5 = v9 - vCTCHypoth[i - 1].getIndex();
	}
	return 1.0f * v5 / (vCTCHypoth.size() - 1);
}

void imseg::DeleteFalseSpaces::process_impl(vector<CTCHypoth>&vCTCHypoth)
{
	if (m_nDeleteFalseSpaces_field_8 == 1067 && vCTCHypoth.size() >= 3)
	{
		for (size_t i = 0; i < vCTCHypoth.size() - 2; i++)
		{
			if (vCTCHypoth[i].getUnicode() == ' '
				&& vCTCHypoth[i].field_8 != -1
				&& calcMeanSymbolsDist(vCTCHypoth) * m_rDeleteFalseSpaces_field_C >= float(vCTCHypoth[i + 1].getIndex() - vCTCHypoth[i].getIndex())
				&& calcMeanSymbolsDist(vCTCHypoth) * m_rDeleteFalseSpaces_field_C >= float(vCTCHypoth[i].getIndex() - vCTCHypoth[i - 1].getIndex()))
			{
				vCTCHypoth.erase(vCTCHypoth.begin() + i);
				i--;
			}
		}
	}
}
