#pragma once
#include "..\pch.h"
class SubField
{
public:
	int m_nLCID_0;
	wstring m_wsMask_4;
	map<wchar_t, set<uint>> m_map_wchar_setun_10;
	set<uint> m_setun_1C;

	SubField();
	SubField(SubField const&);
	SubField(wstring&, map<wchar_t, set<uint>>&, uint);
	SubField& operator=(SubField&&);
	int getLCID();
	wstring *getMask();
};