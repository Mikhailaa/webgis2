﻿#pragma once
#include "pch.h"
#include "commonStruct.h"
#include "ImageControl.h"
#include "Analyse.h"

class LineDetect//complete
{
public:
	static void checkRectSize(CBufferImage &, vector<tagRECT> &);
	static int filterLines(vector<tagRECT> &, int, int);
	static void locateLineX(CBufferImage &, int, vector<tagRECT> &);
	static void sortingLines(vector<tagRECT> &);
};