#include "SymbolCandidat.h"

SymbolCandidat::SymbolCandidat()
{
}

SymbolCandidat::SymbolCandidat(SymbolCandidat const &arg1)
{
	m_wszCandiateCharacter_0 = arg1.m_wszCandiateCharacter_0;
	m_rProv_4 = arg1.m_rProv_4;
	field_8 = arg1.field_8;
	field_C = arg1.field_C;
	field_10 = arg1.field_10;	
}

SymbolCandidat::SymbolCandidat(int arg1, float arg2, int arg3, int arg4, int arg5)
{
	m_wszCandiateCharacter_0 = arg1;
	m_rProv_4 = arg2;
	field_8 = arg3;
	field_C = arg4;
	field_10 = arg5;
}

SymbolCandidat::~SymbolCandidat()
{
}

SymbolCandidat & SymbolCandidat::operator=(SymbolCandidat &arg1)
{
	m_wszCandiateCharacter_0 = arg1.m_wszCandiateCharacter_0;
	m_rProv_4 = arg1.m_rProv_4;
	field_8 = arg1.field_8;
	field_C = arg1.field_C;
	field_10 = arg1.field_10;

	return *this;
}
