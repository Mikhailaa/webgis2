#include "RSubFieldManager.h"
#include "AlphabetManager.h"
#include "VisualSubFieldEx.h"
#include "SubField.h"
#include "common/UnicodeUtils.h"

recursive_mutex g_Mutex;
ListSubField g_LSF_1141D44;
map<wstring, SubField> g_mRSFM_1141D50;

map<wstring, SubField>* RSubFieldManager::getName2SubfieldMap()
{
	return &g_mRSFM_1141D50;
}

ListSubField * RSubFieldManager::subFields()
{
	return &g_LSF_1141D44;
}

void remove(wstring &wstrParam1, wchar_t wcParam2)
{
	wstring::iterator iter = remove(wstrParam1.begin(), wstrParam1.end(), wcParam2);
	wstrParam1.erase(iter, wstrParam1.end());
}

int RSubFieldManager::init(ListSubField & a1)
{
	g_Mutex.lock();
	g_LSF_1141D44 = a1;
	for (int i = 0; i < g_LSF_1141D44.count(); i++)
	{
		string str1(g_LSF_1141D44[i].m_szTVSF_110);
		if (str1 == "SPACE")
		{
			g_LSF_1141D44[i].m_nTVSF_Count_210 = 1;
			strcpy(g_LSF_1141D44[i].m_lpTVSF_Buffer_214, " ");
		}
		if (g_LSF_1141D44[i].m_nTVSF_Count_210)
		{
			g_LSF_1141D44[i].m_nTVSF_MinMaxLen_108 = 0x7FFFFFFF;
			g_LSF_1141D44[i].m_nTVSF_10C = 0;
			vector<int> vv;
			for (int j = 0; j < g_LSF_1141D44[i].m_nTVSF_Count_210; j++)
			{
				string str2(&g_LSF_1141D44[i].m_lpTVSF_Buffer_214[0x100 * j]);
				wstring wstr = common::UnicodeUtils::Utf8ToWStr(str2);
				int len = wstr.length();
				if (len < g_LSF_1141D44[i].m_nTVSF_MinMaxLen_108)
					g_LSF_1141D44[i].m_nTVSF_MinMaxLen_108 = len;
				if (len > g_LSF_1141D44[i].m_nTVSF_10C)
					g_LSF_1141D44[i].m_nTVSF_10C = len;
				for (int k = 0; k < len; k++)
				{
					vv.push_back(wstr[k]);
				}
			}
			CAlphabetContainer cac;
			cac.append(vv);
			CAlphabetManager::convert(cac, g_LSF_1141D44[i].m_aTVSF_Alphabet_218);
		}
		else if (!CVisualSubFieldEx::isDynamic((TVisualSubField)(g_LSF_1141D44[i])))
		{
			g_LSF_1141D44[i].m_nTVSF_MinMaxLen_108 = str1.length();
			g_LSF_1141D44[i].m_nTVSF_10C = str1.length();
		}
		map<wchar_t, set<uint>> m = getAlphabets((TVisualSubField)(g_LSF_1141D44[i]));
		wstring wstr = common::UnicodeUtils::Utf8ToWStr(str1);
		remove(wstr, L'{');
		remove(wstr, L'}');
		g_LSF_1141D44[i].m_sTVSF_lcid;
		str1 = string(g_LSF_1141D44[i].m_szTVSF_4);
		wstring wstr1 = common::UnicodeUtils::Utf8ToWStr(str1);
		g_mRSFM_1141D50[wstr1] = SubField(wstr, m, g_LSF_1141D44[i].m_sTVSF_lcid);
	}
	g_Mutex.unlock();
	return 0;
}

set<uint> copyCharsToVector(char const *pcParam1, uint nParam2)
{
	set<uint> s;
	string str(pcParam1);
	wstring wstr = common::UnicodeUtils::Utf8ToWStr(str);
	for (size_t i = 0; i < wstr.length(); i++)
	{
		s.emplace(wstr[i]);
	}
	return s;
}

map<wchar_t, set<uint> > RSubFieldManager::getAlphabets(TVisualSubField &a1)
{
	map<wchar_t, set<uint> > m;
	for (int i = 0; i < 4; i++)
	{
		if (a1.m_aTVSF_Alphabet_218[i].m_bCA_HasData_0)
		{
			m[(wchar_t)a1.m_aTVSF_Alphabet_218[i].m_bCA_HasData_0] = copyCharsToVector(a1.m_aTVSF_Alphabet_218[i].m_szCA_Alphabet, strlen(a1.m_aTVSF_Alphabet_218[i].m_szCA_Alphabet));
		}
	}
	return m;
}