#include "Base.h"
#include "rclhelp.h"
#include <algorithm>

namespace imseg
{
	namespace Base
 	{
		void removeFields(CRecognizedTextDoc &arg1, CRecognizedTextDoc &arg2, vector<int> const &arg3)
		{
			CRecognizedTextFieldSDK *v7, *v11, *v12;
			int v8, _nFlag = 0;
			for (int i = 0; i < arg1.count(); i++)
			{
				v7 = arg1.at(i);
				v8 = v7->getLCID();

				for (size_t j = 0; j < arg3.size(); j++)
				{
					if (arg3[j] == v8)
					{
						if (j == arg3.size() - 1)
							_nFlag = 1;
						else
							_nFlag = 2;
						break;
					}
				}
				
				if (_nFlag != 2)
				{
					v11 = arg2.add();
					v12 = arg1[i];
					v11->set(v12);
				}
				_nFlag = 0;
			}
		}
		void sortFields(CRecognizedTextDoc &arg1, CRecognizedTextDoc &arg2, vector<int> const &arg3)
		{
			int _nPos_8 = 0;
			CRecognizedTextFieldSDK *v7, *v8, *v12, *v13;
			vector<int> _vn_C;
			int _nFlag = 0;

			for (size_t i = 0; i < arg3.size(); i++)
			{
				_nPos_8 = arg1.getPos((eVisualFieldType)i);
				if (_nPos_8 != -1)
				{
					v7 = arg2.add();
					v8 = arg1[_nPos_8];
					v7->set(v8);
					_vn_C.push_back(_nPos_8);
				}
			}

			for (int j = 0; j < arg1.count(); j++)
			{
				for (size_t k = 0; k < _vn_C.size(); k++)
				{
					if (_vn_C[k] == j)
					{
						if (_vn_C.size() - 1 == j)
							_nFlag = 1;
						else
							_nFlag = 2;
						break;
					}
				}

				if (_nFlag != 2)
				{
					v12 = arg2.add();
					v13 = arg1[_nPos_8];
					v12->set(v13);
				}
				_nFlag = 0;
			}
		}
		void resetLayers(CDocInfo &arg1)
		{
			for (int i = 0; i < arg1.count(); i++)
				arg1.get(i)->xTVF_Font.m_nFF_layer = 0;
		}
		void updateFieldsOrder(vector<Layer_R> &arg1, vector<int> &arg2, vector<unsigned int> &arg3)
		{
			int v8 = 0, v18, v7 = 0;
			for (size_t i = 0; i < arg1.size(); i++)
			{
				if (arg2[i] >= 100)
				{
					bool  v13 = 0;
					Layer_R *_pLayer = &arg1[i];
					for (size_t j = 0; j < _pLayer->size(); j++)
						v13 |= (*_pLayer)[j].param().contain(PROCESS_OPTION_10);
					v18 = v8;
					if (v13 == 0)
						v18 = v8 + v7;

					vector<uint>::iterator iter = arg3.begin();
					std::rotate<vector<uint>::iterator>(iter + v18, iter + i, iter + i + 1);
					if(v13)v8++;
					else v7++;
				}
			}
		}
		bool updateImgParams(common::container::RclHolder &arg1, CDocInfo* arg2)
		{
			tagSIZE _tagSIZE_0;
			int a3 = 0;
			rclhelp::imageParameters(arg1.m_xTRCL, a3, _tagSIZE_0);
			if (!a3 || !_tagSIZE_0.cx || !_tagSIZE_0.cy)
				return 1;
			arg2->updateDPI(a3);
			arg2->reverseH(_tagSIZE_0.cy);
			return 0;
		}
		bool updateDocInfoWithBind(common::container::RclHolder &arg1, char const *arg2, CDocInfo &arg3)
		{
			bool res = 0;
			vector<TResultContainer*> _vTResultContainer_28 = arg1.getRcList(70);
			if (!_vTResultContainer_28.empty())
			{
				vector<TResultContainer*> _vTResultContainer_2C = arg1.getRcList(70);
				TBindingResultsList *v7 = (TBindingResultsList *)(_vTResultContainer_2C.front()->u.pTRC_obj);
				arg3.addShift(*v7);
				res = 0;
			}
			else
			{
				TResultContainerList *a5 = 0;
				//if (!moduleprocessgl::process(1301, (void *)&arg1, (char *)arg2, (void **)a5, 0) && a5)
				{
					TResultContainer *v10 = rclhelp::findFirstContainer(a5, 70);
					if (v10)
					{
						arg3.addShift((TBindingResultsList&)(v10->u.pTRC_obj));
						arg1.addNoCopy(*v10);
					}
					return 0;
				}
				//Log "ImSeg.dll" "ImSegNS::ProcessCommand::ePC_Process doc info: error in bind part"
			}
			return 1;

		}
	}
}