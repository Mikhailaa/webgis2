#pragma once

#include "pch.h"
#include "commonStruct.h"
#include "common/common.h"

class LinesInfoAnalyze
{
public:
	static void getXPosition(multimap<int, int> &, int, int, int &, int &);
	static void getHistY(vector<TPointEx> &, vector<int> &, vector<int> &, multimap<int, int> *, multimap<int, int> *, int, int);
};