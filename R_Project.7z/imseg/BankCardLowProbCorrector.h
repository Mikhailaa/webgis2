#pragma once
#include "imseg_interface.h"
#include "CTCHypoth.h"

namespace imseg
{
	class BankCardLowProbCorrector : public ICorrector
	{
	public:
		float m_rBankCardLowProbCorrector_8;

		BankCardLowProbCorrector(float, ICorrector*);
		~BankCardLowProbCorrector();
		virtual void process_impl(vector<CTCHypoth> &);
	};
}