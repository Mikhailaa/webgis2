#include "ImSegStatic.h"
#include "common/StringUtils.h"
#include "moduleprocessgl.h"
#include "RSubFieldManager.h"
#include "legacycommonlib.h"
#include "VisualSubField.h"
#include "VisualSubFieldEx.h"
#include "common/container/jsoncpp.h"
#include "common/RegulaConfig.h"


ImSegStatic::ImSegStatic()
	: m_xInitConstStructs_0()
	, m_xSymbols_4C()
	, m_fsTmpPath_E0()
	, m_s_FC()
	, m_xistrstream_108()
	, m_xistrstream_194()
	, m_xistrstream_220()
	, m_xistrstream_2AC()
	, m_xistrstream_338()
	, m_vn_3C8()
	, m_xFacadeDNNOCR_3D4()
	, m_jsUnicodeSettings_400(0)
	, m_jsLCIDs_418(0)
	, m_xFieldsLoadFilter_434()
{
	m_xSymbolInfoEx_C4.m_pSymbols_4 = 0;
	field_CC = 0;
	field_D0 = 0;
	field_D4 = 0;
	m_bField_D8 = false;
	m_nBestSymbolH_DC = 35;
	m_nSaveDebugInfo_F8 = 0;
	field_3C4 = 0;
	field_3FC = 0;
	m_bSaveFieldWithRandomNameInTmpFolder_3F8 = 0;
	field_430 = 0;
	field_454 = 0;
	reset();
}


ImSegStatic::~ImSegStatic()
{
}

int ImSegStatic::init()
{
	if (!loadDNN(m_xistrstream_108))//DNNOCR.dat
		return 2;
	if (!loadDNN(m_xistrstream_194))//DNNOCRCN.dat
		return 2;
	if (!loadDNN(m_xistrstream_2AC))//DNNOCRAR.dat
		return 2;
	if (!loadDNN(m_xistrstream_220))//DNNOCRAS.dat
		return 2;
	if (!loadDNN(m_xistrstream_338))//DNNOCRBC.dat
		return 2;
	if (!m_s_FC.size())
		return 2;
	imseg::parameters::Configuration *v7 = imseg::parameters::Configuration::obj();
	if (common::container::jsoncpp::convert(m_s_FC, v7->m_xJsonValue_8))
		return 2;

	imseg::parameters::Configuration *v9 = imseg::parameters::Configuration::obj();
	m_s_FC.reserve(0);
	if (v9->m_xJsonValue_8["Main"].isMember("removeResultByLcid"))
	{
		Json::Value v13 = v9->m_xJsonValue_8["Main"]["removeResultByLcid"];
		string _s_48 = v13.asString();
		vector<string> _vs_60 = common::StringUtils::Split(_s_48, ',');
		for (size_t i = 0; i < _vs_60.size(); i++)
			m_vn_3C8.push_back(atoi(_vs_60[i].data()));
	}

	if (v9->m_xJsonValue_8["Main"].isMember("saveDebugInfo"))
	{
		Json::Value v13 = v9->m_xJsonValue_8["Main"]["saveDebugInfo"];
		m_nSaveDebugInfo_F8 = v13.asInt();
		if (v13.asInt())
		{
			fs::Path _xfsPath_60;
			if (v9->m_xJsonValue_8["Main"].isMember("debugInfoFolder"))
			{
				Json::Value v36 = v9->m_xJsonValue_8["Main"]["removeResultByLcid"];
				string _s_48 = v36.asString();
				fs::Path _xPath_tmp0 = fs::Path(_s_48);
				_xfsPath_60 = _xPath_tmp0;
			}
			else
			{
				fs::Path _xPath_tmp0 = fs::Path("DNNOCR_debugInfo");
				_xfsPath_60 = _xPath_tmp0;
			}
			string _s_3C = RegulaConfig::GetTmpPath();
			fs::Path _xfsPath_48(_s_3C);
			m_fsTmpPath_E0 = _xfsPath_48.add(_xfsPath_60);
			if (fs::isExist(m_fsTmpPath_E0))
				fs::mkDir(m_fsTmpPath_E0);

		}
	}
	else
		m_nSaveDebugInfo_F8 = 0;

	if (v9->m_xJsonValue_8["Main"].isMember("saveOriginalFieldImage"))
	{
		Json::Value v13 = v9->m_xJsonValue_8["Main"]["saveOriginalFieldImage"];
		m_bSaveFieldWithRandomNameInTmpFolder_3F8 = v13.asBool();
	}
	else
		m_bSaveFieldWithRandomNameInTmpFolder_3F8 = false;

	m_xInitConstStructs_0.initFromIni(v9->m_xJsonValue_8);
	Json::Value _xjValue_48(35);
	Json::Value _xjValue_60 = v9->m_xJsonValue_8["Main"].get("BestSymbolH", _xjValue_48);
	m_nBestSymbolH_DC = _xjValue_60.asInt();

	if (v9->m_xJsonValue_8.isMember("UnicodesSettings"))
		m_jsUnicodeSettings_400 = Json::Value(v9->m_xJsonValue_8["UnicodesSettings"]);

	if (v9->m_xJsonValue_8.isMember("LCIDs"))
		m_jsLCIDs_418 = Json::Value(v9->m_xJsonValue_8["LCIDs"]);

	int v15 = SymbolBaseLoad::load(m_jsUnicodeSettings_400, m_jsLCIDs_418, m_xSymbols_4C);
	if (!v15)
	{
		m_xSymbolInfoEx_C4.m_pSymbols_4 = &m_xSymbols_4C;
		processgl(600, 0, 0, 0, 0);
		v15 = 0;
	}

	return v15;
}

void ImSegStatic::initSubFields(ListSubField &arg1)
{
	ListSubField *v3 = RSubFieldManager::subFields();
	v3->reset();
	RSubFieldManager::init(arg1);
}

int ImSegStatic::initSubFieldsBin(vector<uchar>&arg1)
{

	if (arg1.empty())
		return 1;
	ListSubField _xListSubField_0;
	CVisualSubFieldEx::load(_xListSubField_0, arg1);
	initSubFields(_xListSubField_0);
	return 0;
}

int ImSegStatic::initSubFieldsJson(string &arg1)
{
	if (!arg1.size())
		return 1;
	ListSubField _xListSubField_0;
	legacycommonlib::jsoncpp::convert(arg1, _xListSubField_0);
	initSubFields(_xListSubField_0);
	return 0;
}

bool ImSegStatic::loadDNN(istringstream &arg1)
{
	bool res = false;
	string _s_8 = arg1.rdbuf()->str();
	if (_s_8.size() == 0)
		res = true;
	arg1.clear();
	if (m_xFacadeDNNOCR_3D4.load(arg1))
		res = true;
	return res;
}

void ImSegStatic::unload()
{
	imsegStatic(true);
}

ImSegStatic *ImSegStatic::imsegStatic(bool arg1)
{
	static ImSegStatic *obj = nullptr;
	ImSegStatic *v3 = obj;
	if (arg1)
		obj = nullptr;
	else
	{
		if (obj)
			return obj;
		v3 = obj;
		obj = new ImSegStatic();
	}
	if (v3)
		delete v3;
	return obj;
}

ImSegStatic * ImSegStatic::obj()
{
	return imsegStatic(false);
}

void ImSegStatic::reset()
{
	memclr(&m_xFieldsLoadFilter_434, sizeof(m_xFieldsLoadFilter_434));
	m_xFieldsLoadFilter_434.field_18 = -1;
	m_xFieldsLoadFilter_434.field_1C = 0xFFFF;
}
