#include "PrefixTree.h"
#include "word_beam_search.h"
#include "dnn/dnn_serialization.h"


namespace imseg
{
	namespace word_beam_search
	{ 
		PrefixTree::PrefixTree()
		{
			m_spPT_0 = make_shared<Node>();
		}
		PrefixTree::~PrefixTree()
		{
		}
		void PrefixTree::addWord(vector<uint> const & a2)
		{
			shared_ptr<Node> sp32(m_spPT_0);

			m_spPT_0->m_nNode_18++;

			for (size_t i = 0; i < a2.size(); i++)
			{
				size_t j;
				for (j = 0; j < sp32->m_vNode_0.size(); j++)
				{
					if (sp32->m_vNode_0[j].first == a2[i])
					{
						sp32->m_vNode_0[j].second->m_nNode_18++;
						sp32 = sp32->m_vNode_0[j].second;
						break;
					}
				}

				if (j == sp32->m_vNode_0.size())
				{
					shared_ptr<Node> sp31 = make_shared<Node>();
					sp31->m_nNode_18 = 1;
					sp32->m_vNode_0.push_back(pair<uint, shared_ptr<Node> >(a2[i], sp31));
					sp32 = sp31;
				}
			}

			sp32->m_vNode_C = a2;
		}
		void PrefixTree::allWordsAdded(void)
		{
			deque<shared_ptr<Node>> dq({ m_spPT_0 });

			while (dq.size())
			{
				sort(dq[0]->m_vNode_0.begin(), dq[0]->m_vNode_0.end());

				for (size_t i = 0; i < dq[0]->m_vNode_0.size(); i++)
				{
					dq.push_back(dq[0]->m_vNode_0[i].second);
				}

				dq.pop_front();
			}
		}

		map<int, Char> PrefixTree::getNextChars(vector<uint> const & a3)
		{
			map<int, Char> a1;
			shared_ptr<Node> sp1a = getNode(a3);

			if (sp1a.get())
			{
				for (size_t i = 0; i < sp1a->m_vNode_0.size(); i++)
				{
					shared_ptr<Node> sp16 = sp1a->m_vNode_0[i].second;
					Char x14;
					x14.nChar_0 = sp1a->m_vNode_0[i].first;
					x14.rChar_4 = (float)sp16->m_nNode_18 / sp1a->m_nNode_18;
					a1.insert(pair<int, Char>(sp1a->m_vNode_0[i].first, x14));
				}
			}

			return a1;
		}

		vector<vector<uint>> PrefixTree::getNextWords(vector<uint> const & a3)
		{
			vector<vector<uint>> vv29;
			shared_ptr<Node> sp1a = getNode(a3);			

			if (sp1a.get())
			{
				if (a3.size() != 1 || m_mPT_8.find(a3[0]) == m_mPT_8.end())
				{
					deque<shared_ptr<Node>> d27({ sp1a });

					while (d27.size())
					{
						for (size_t i = 0; i < d27[0]->m_vNode_0.size(); i++)
						{
							d27.push_back(d27[0]->m_vNode_0[i].second);
						}

						if (!d27[0]->m_vNode_C.empty())
						{
							vv29.push_back(d27[0]->m_vNode_C);
						}

						d27.pop_front();
					}

					if (a3.size() == 1)
					{
						m_mPT_8[a3[0]] = vv29;
					}

					return vv29;
				}

				vector<vector<uint>> a1((++m_mPT_8.find(a3[0]))->second);
				return a1;
			}

			return vector<vector<uint>>();
		}

		shared_ptr<PrefixTree::Node> PrefixTree::getNode(vector<uint> const & a3)
		{
			shared_ptr<Node> a1;
			shared_ptr<Node> sp1a(m_spPT_0);

			for (size_t i = 0; i < a3.size(); i++)
			{
				int n9 = sp1a->m_vNode_0.size(), n11, nTmp = 0;
				
				while (n9)
				{
					n11 = n9;
					n9 /= 2;

					if (sp1a->m_vNode_0[nTmp + n9].first < a3[i])
					{
						n9 = n11 - 1 - n9;
						nTmp = n9 + 1;
					}
				}

				if (nTmp == sp1a->m_vNode_0.size() || sp1a->m_vNode_0[nTmp].first > a3[i])
				{
					return shared_ptr<Node>();
				}

				shared_ptr<Node> sp21(sp1a->m_vNode_0[nTmp].second);
				sp1a = sp21;
			}
			
			return sp1a;
		}
		void PrefixTree::io(cv::dnn::DnnReader & a2, shared_ptr<Node>& a3)
		{
			uchar uch;
			uint nSize;
			a3 = make_shared<Node>();

			a2.io(&uch);
			if (!uch)
			{
				cv::dnn::io_vec_uint(a2, a3->m_vNode_C);
				a2.io(&a3->m_nNode_18);
				nSize = a3->m_vNode_0.size();
				a2.io(&nSize);
				if (nSize != a3->m_vNode_0.size())
				{
					a3->m_vNode_0.resize(nSize);
				}
				for (size_t i = 0; i < nSize; i++)
				{
					a2.io(&a3->m_vNode_0[i].first);
					io(a2, a3->m_vNode_0[i].second);
				}
			}
		}
		void PrefixTree::io_generic(cv::dnn::DnnReader & a2)
		{
			io(a2, m_spPT_0);
		}
		bool PrefixTree::isWord(vector<uint> const & a2)
		{
			shared_ptr<Node> sp1a = getNode(a2);

			if (sp1a.get() && !sp1a->m_vNode_C.empty())
			{
				return true;
			}

			return false;
		}
	}
}

