#pragma once
#include "imseg_interface.h"
#include "CTCHypoth.h"

namespace imseg
{
	class DeleteFalseSpaces : public ICorrector
	{
	public:
		int m_nDeleteFalseSpaces_field_8;
		float m_rDeleteFalseSpaces_field_C;

		DeleteFalseSpaces(int, ICorrector *);
		~DeleteFalseSpaces();
		float calcMeanSymbolsDist(vector<CTCHypoth>&);
		virtual void process_impl(vector<CTCHypoth> &);
	};
}