#pragma once
#include "../pch.h"
#include "common/resources.h"
#include "common/container/container.h"
#include "common/container/RclHolder.h"
#include "Json/Value.h"

using namespace common::resources;
using namespace common::container;

namespace imseg
{
	namespace rect
	{
		cv::Rect scale(cv::Rect const&, float);
		vector<cv::Rect> scale(vector<cv::Rect> const&, float);
		cv::Rect addShift(cv::Rect const&, int);
	}
}