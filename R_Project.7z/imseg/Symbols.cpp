#include "Symbols.h"

Symbols::Symbols()
	:m_xAlphabetInfo_10()
	,m_xBaseFontsFilter_3C()
	,m_xSymbolsInfoByUnicode_4C()
{
}

Symbols::~Symbols()
{
}

void Symbols::reset()
{
	m_xAlphabetInfo_10.reset();
	m_xBaseConflictGroups_2C.clear();
	m_xSymbolsInfoByUnicode_4C.m_uomap_nSymbolInfo_4.clear();
}

namespace SymbolBaseLoad
{
	int load(Json::Value & a1, Json::Value & a2, Symbols & a3)
	{
		set<int> sint_34;
		readLCIDs(a2, a3.m_xAlphabetInfo_10);

		for (uint i = 0; i < a3.m_xAlphabetInfo_10.m_vvn_10.size(); i++)
		{
			for (uint j = 0; j < a3.m_xAlphabetInfo_10.m_vvn_10[i].size(); j++)
				sint_34.insert(sint_34.end(), a3.m_xAlphabetInfo_10.m_vvn_10[i][j]);
		}

		readCodePages(a1, sint_34, a3);
		set<int>::iterator begin = sint_34.begin();
		while (begin != sint_34.end())
		{
			if (a3.m_mapnn_4.end() == a3.m_mapnn_4.find(*begin))
				a3.m_mapnn_4.insert(pair<int, int>(*begin, *begin));
			begin++;
		}
		return 0;
	}

	void readCodePages(Json::Value& a1, set<int>& a2, Symbols& a3)
	{
		set<int>::iterator begin, end;
		begin = a2.begin();
		end = a2.end();

		while (begin != end)
		{
			string str_64 = to_string(*begin);
			Json::Value jValue_48(Json::json_type_null);

			if (a1.isMember(str_64))
			{
				jValue_48 = Json::Value(a1[str_64]);
				a1.removeMember(str_64);
			}
			else
				jValue_48 = Json::Value(a1["default"]);

			SymbolInfo si;
			si.nField_0 = jValue_48[0].asInt();
			si.nField_4 = jValue_48[1].asInt();
			si.nField_8 = jValue_48[2].asInt();
			a3.m_xSymbolsInfoByUnicode_4C.m_uomap_nSymbolInfo_4.insert(a3.m_xSymbolsInfoByUnicode_4C.m_uomap_nSymbolInfo_4.end(),
				pair<int, SymbolInfo>(*begin, si));

			begin++;
		}

		if (a1.size() > 1)
		{
			vector<string> vstr_2c = a1.getMemberNames();
			for (uint i = 0; i < vstr_2c.size(); i++)
			{
				if (vstr_2c[i] != "default")
				{
					SymbolInfo si;
					si.nField_0 = a1[vstr_2c[i]][0].asInt();
					si.nField_4 = a1[vstr_2c[i]][1].asInt();
					si.nField_8 = a1[vstr_2c[i]][2].asInt();
					a3.m_xSymbolsInfoByUnicode_4C.m_uomap_nSymbolInfo_4.insert(a3.m_xSymbolsInfoByUnicode_4C.m_uomap_nSymbolInfo_4.end(),
						pair<int, SymbolInfo>(stoi(vstr_2c[i], 0, 10), si));
					a2.insert(stoi(vstr_2c[i]));
				}
			}
		}
	}

	void readLCIDs(Json::Value& a1, AlphabetInfo& a2)
	{
		vector<string> v1 = a1.getMemberNames();
		a2.m_vn_4.resize(v1.size());
		a2.m_vvn_10.resize(v1.size());

		for (uint i = 0; i < v1.size(); i++)
		{
			a2.m_vn_4[i] = stoi(v1[i], 0, 10);
			Json::Value v2 = a1[v1[i]];
			for (uint j = 0; j < v2.size(); j++)
				a2.m_vvn_10[i].push_back(v2[j].asInt());
		}
	}
};

AlphabetInfo& SymbolInfoEx::alphabetInfo()
{
	return m_pSymbols_4->m_xAlphabetInfo_10;
}

SymbolsInfoByUnicode&  SymbolInfoEx::symbolsInfo()
{
	return m_pSymbols_4->m_xSymbolsInfoByUnicode_4C;
}

int SymbolsIndexMap::index(int)
{
	return 0;
}

ConflictGroups& BaseConflictGroups::getConflictGroup(int, int, vector<int>&)
{
	ConflictGroups *ret = new ConflictGroups;
	return *ret;
}
