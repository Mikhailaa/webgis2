#include "test.h"

void imseg::test::createTestSample(RclHolder &, string &)
{
}
