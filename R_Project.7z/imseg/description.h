#pragma once
#include "../pch.h"
#include "common/resources.h"
#include "common/container/container.h"
#include "common/container/RclHolder.h"
#include "Json/Value.h"
#include "Base.h"
#include "legacycommonlib.h"
#include "DocInfo.h"

using namespace common::resources;
using namespace common::container;

namespace imseg
{
	namespace description
	{
		class DocDescObj
		{
		public:
			CDocInfo *m_pDocInfo_0;
			int field_4;
			Json::Value m_xJsonValue_8;
			shared_ptr<CDocInfo> m_spCDocInfo_20;
			int field_28;

			DocDescObj();
			~DocDescObj();
		};

		bool getDocInfo(RclHolder &, string const&, description::DocDescObj &, int, legacycommonlib::FieldsLoadFilter *);
	}
}