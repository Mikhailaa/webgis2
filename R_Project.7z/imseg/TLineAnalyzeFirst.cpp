#include "TLineAnalyzeFirst.h"

TLineAnalyzeFirst::TLineAnalyzeFirst()
{
	noiseLower = 0.4f;
	noiseUpper = 0.1f;
	stopHistogram = 150;
	m_n_C = 20;
	threshLineH = 10;
	maxAngle = 3;
 	m_n_18 = 50;
	m_n_1C = 50;
	m_r_20 = 1.3f;
	m_r_24 = 1.15f;
	m_r_28 = 3.0;
	m_r_2C = 0.2f;
	m_r_30 = 1.0;
	m_n_34 = 1;
	m_r_38 = 15.0;
}
