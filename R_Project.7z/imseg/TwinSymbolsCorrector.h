#pragma once
#include "imseg_interface.h"
#include "CTCHypoth.h"

namespace imseg
{
	class TwinSymbolsCorrector : public ICorrector
	{
	public:
		static vector<pair<uint, uint>> m_twins;
		static int m_twinsIdentical;
		TwinSymbolsCorrector(ICorrector *);
		~TwinSymbolsCorrector();
		void insertInMostProbablePlace(vector<CTCHypoth>::iterator, vector<CTCHypoth>::iterator, uint);
		virtual void process_impl(vector<CTCHypoth> &);
	};
}