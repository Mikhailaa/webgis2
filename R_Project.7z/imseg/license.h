#pragma once
//#include "json/Json.h"
#include "json/Value.h"

namespace procmgr {

	namespace license {

		int checkLicense(int, Json::Value &, string &);
		int initLicense(Json::Value &, string &);
			
	}
}