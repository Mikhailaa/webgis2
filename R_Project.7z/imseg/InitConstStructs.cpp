#include "InitConstStructs.h"

void InitConstStructs::initFromIni(Json::Value &a1)
{
	Json::Value v29(a1["LineAnalyzeFirst"]);
	double dval = v29.get("noiseLower", Json::Value(-1)).asDouble();
	if (dval != -1.0)
		m_xTLineAnalyzeFirst_0.noiseLower = (float)dval;

	dval = v29.get("noiseUpper", Json::Value(-1)).asDouble();
	if (dval != -1.0)
		m_xTLineAnalyzeFirst_0.noiseUpper = (float)dval;

	int nval = v29.get("stopHistogram", Json::Value(-1)).asInt();
	if (nval != -1)
		m_xTLineAnalyzeFirst_0.stopHistogram = nval;

	nval = v29.get("threshLineH", Json::Value(-1)).asInt();
	if (nval != -1)
		m_xTLineAnalyzeFirst_0.threshLineH = nval;

	nval = v29.get("maxAngle", Json::Value(-1)).asInt();
	if (nval != -1)
		m_xTLineAnalyzeFirst_0.maxAngle = nval;

	v29 = Json::Value(a1["StringsAnalyze"]);
	nval = v29.get("minSpace", Json::Value(-1)).asInt();
	if (nval != -1)
		minSpace = nval;

	v29 = Json::Value(a1["TextStructManager"]);
	nval = v29.get("threshMinSymbolPr", Json::Value(-1)).asInt();
	if (nval != -1)
		threshMinSymbolPr = nval;

	nval = v29.get("threshDiffProb", Json::Value(-1)).asInt();
	if (nval != -1)
		threshDiffProb = nval;

	v29 = Json::Value(a1["ImSeg"]);
	nval = v29.get("dinRange", Json::Value(-1)).asInt();
	if (nval != -1)
		dinRange = nval;
}

InitConstStructs::InitConstStructs()
	:m_xTLineAnalyzeFirst_0()
{
	minSpace = 3;
	threshMinSymbolPr = 80;
	threshDiffProb = 4;
	dinRange = 1;
}
