#include "HParam.h"

map<string, map<int, double>> HParamPool::m_nameToValue =
{
	{ "m_sigmaCoeff"  ,{ { 1067,1.81 },{ 1032,1.9 } ,{ 1059,3.0 } ,{ 1055,3.0 } ,{ 1049,3.0 } ,{ 1037,3.0 } ,{ 0, 3.0 } ,{ -1,3.0 }} },
	{ "m_sigmaCoeff2" ,{ { 1067,1.48 },{ 1032,1.0 } ,{ 1037,1.0 } ,{ 1049,1.0 } ,{ 1059,1.0 } ,{ 1055,1.0 } ,{ 0, 1.0 } ,{ -1,1.0 } } },
	{ "m_lowProb"     ,{ { -1,   0.0 },{ 1032,0.4 } } },
	{ "m_secondHypProbDivisor"  ,{ { -1,10000.0 }} },
	{ "m_lmAlpha"  ,{ { -1,1.0 } } },
	{ "minLanguageCharProb"  ,{ { -1,0.034 }} },
};

int HParamPool::m_arbitraryLCID = -1;

float HParamPool::get(string const &strName, int nVal)
{
	map<string,map<int,double>>::iterator iter= m_nameToValue.find(strName);

	map<int, double> m = iter->second;

	map<int, double>::iterator iter1 = m.find(nVal);
	if (iter1 == m.end()) return (float)m.find(m_arbitraryLCID)->second;
	return (float)iter1->second;
}

HParam::HParam(float &rRet, string &strName, int nVal)
{
	rRet = HParamPool::get(strName, nVal);
}

