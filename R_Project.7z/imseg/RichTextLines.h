#pragma once

#include "pch.h"
#include "common/resources.h"
#include "common/container/container.h"
#include "common/container/RclHolder.h"
#include "TextLines.h"
#include "DbgFolder.h"
#include "CTCHypoth.h"
#include "imseg_interface.h"
#include "imseg.h"

using namespace common;
using namespace common::resources;
using namespace common::container;

namespace imseg
{
	class RichTextLines : public TextLines ,public IVisitable
	{
	public:
		//TextLines m_xTLs_0;	
		uint m_nTopPriority_58;
		vector<uint> m_vn_5C;
		vector<DbgFolder> m_vDbgF_68;
		vector<vector<CTCHypoth>> m_vvImCTCHy_74;
		vector<cv::Mat> m_vMat_80;
		vector<float> m_vf_8C;
		vector<RichTextLines> m_vRichTLs_98;
		vector<RichTextLines> m_vRichTLs_A4;

		RichTextLines(TextLines const&, vector<uint> const&, DbgFolder const&, uint);
		RichTextLines(RichTextLines const&);

		virtual void accept(ITextLinesVisitor &);
		~RichTextLines();
		RichTextLines &operator=(RichTextLines &&);
		RichTextLines &operator=(RichTextLines const&);
		void operator>>(TextLines&);
		void append(vector<CTCHypoth> &);
		void augment(TTAParams&);
		void setAugmentedVersions(vector<RichTextLines> const&);
		void setNormalizedImgs(vector<cv::Mat> const&);
		void setTextROIs(vector<cv::Rect> const&);
		void setVotingSeqs(vector<RichTextLines> const&);
		bool hasAugmentedVersions();
		vector<RichTextLines>& getVotingSeqs();
		uint getTopPriorityLCID();
		vector<cv::Rect>& getTextROIs();
		cv::Rect& getTextROI(uint);
		vector<vector<CTCHypoth>> &getSeqs();
		float& getScale(uint);
		vector<cv::Mat>& getNormalizedImgs();
		int getMaxWidth();
		cv::Mat& getImg();
		vector<DbgFolder> &getDbgFolders();
		vector<RichTextLines>& getAugmentedVersions();
		set<uint> getAlphabetSet();
		vector<uint>& getAlphabet();
		bool empty();
	};
}
