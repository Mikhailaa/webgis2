#pragma once

class CDocGraphicField
{
public:
	CDocGraphicField() {};
public:

};