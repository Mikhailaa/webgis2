#pragma once

#include "pch.h"
#include "VisualSubField.h"
#include "ListSubField.h"

class CVisualSubFieldEx
{
public:
	static bool findResultInEnum(vector<wstring> &, vector<vector<pair<int, int>>> &, wstring&);
	static bool findResultInEnum2(vector<wstring> &, vector<vector<pair<int, int>>> &, wstring&);
	static int getVariantsFromSubField(CVisualSubField &, vector<wstring> &);
	static bool isDynamic(TVisualSubField &);
	static int load(ListSubField &, vector<uchar> &);
	static int save(ListSubField &,vector<uchar> &);
};