#include "LanguageModel.h"
#include "dnn_serialization.h"

namespace imseg
{
	namespace word_beam_search
	{

		LanguageModel::LanguageModel()
		{
			m_nLM_14 = 0;
			m_nLM_18 = 0;
			m_nLM_1C = 0;
		}

		LanguageModel::~LanguageModel()
		{ 
		}

		unordered_map<uint, uint> LanguageModel::codepointToLabelMapping(vector<uint> const & a3)
		{
			unordered_map<uint, uint> a1;

			for (size_t i = 0; i < a3.size(); i++)
			{
				a1[a3[i]] = i;
			}

			return a1;
		}

		set<uint> & LanguageModel::getAllChars(void)
		{
			return m_setLM_54;
		}

		map<int, Char> LanguageModel::getNextChars(vector<uint> const & a3)
		{
			map<int, Char> a1 = m_xLM_20.getNextChars(a3);

			float r9 = 0.0f;

			if (m_setLM_6C.size())
			{
				r9 = 1.0f / m_setLM_6C.size();
			}

			m_xLM_20.isWord(a3);

			for (set<uint>::iterator iter = m_setLM_6C.begin(); iter != m_setLM_6C.end(); iter++)
			{
				a1[*iter].nChar_0 = *iter;
				a1[*iter].rChar_4 = r9;
			}

			return a1;
		}

		vector<vector<uint>> LanguageModel::getNextWords(vector<uint> const & a3)
		{
			return m_xLM_20.getNextWords(a3);
		}

		set<uint> LanguageModel::getNonWordChars(void)
		{
			return m_setLM_6C;
		}

		double LanguageModel::getUnigramProb(vector<uint> const & a2)
		{
			unordered_map<vector<uint>, Unigram, HashFunction>::iterator iter = m_umLM_0.find(a2);

			if (iter != m_umLM_0.end())
			{
				return iter->second.m_dUg_8;
			}

			return 0.0;
		}

		set<uint> LanguageModel::getWordChars(void)
		{
			return m_setLM_60;
		}

		void LanguageModel::io_generic(cv::dnn::DnnReader & a2)
		{
			cv::dnn::io_vec_uint(a2, m_vLM_34);
			cv::dnn::io(a2, m_umLM_40);
			cv::dnn::io_set_uint(a2, m_setLM_54);
			cv::dnn::io_set_uint(a2, m_setLM_60);
			cv::dnn::io_set_uint(a2, m_setLM_6C);
			m_xLM_20.io_generic(a2);
			uint n13 = m_umLM_0.size();
			a2.io(&n13);

			if (n13 == m_umLM_0.size())
			{
				for (unordered_map<vector<uint>, Unigram, HashFunction>::iterator iter = m_umLM_0.begin(); iter != m_umLM_0.end(); iter++)
				{
					vector<uint> v2a(iter->first);
					cv::dnn::io_vec_uint(a2, v2a);
					Unigram x14(iter->second);
					a2.io(&x14.m_nUg_0);
				}
			}
			else
			{
				int n7 = 0;
				for (size_t i = 0; i < n13; i++)
				{
					vector<uint> v2a;
					/*int nVecSize;
					a2.io(&nVecSize);

					for (int j = 0; j < nVecSize; j++)
					{
						int nVal;
						a2.io(&nVal);
						v2a.push_back(nVal);
					}*/

					uint n8 = v2a.size();
					a2.io(&n8);
					if (n8 != v2a.size())
					{
						v2a.resize(n8);
					}

					for (size_t i = 0; i < n8; i++)
					{
						a2.io(&v2a[i]);
					}


					//cv::dnn::io_vec_uint(a2, v2a);
					Unigram x14;
					a2.io(&x14.m_nUg_0);
					n7 += x14.m_nUg_0;
					m_umLM_0[v2a] = x14;
				}

				for (unordered_map<vector<uint>, Unigram, HashFunction>::iterator iter = m_umLM_0.begin(); iter != m_umLM_0.end(); iter++)
				{
					iter->second.m_dUg_8 = (double)(iter->second.m_nUg_0) / (double)n7;
				}
			}
		}

		uint LanguageModel::labelToUnicode(uint a2)
		{
			return m_vLM_34[a2];
		}

		LanguageModel::Unigram::Unigram()
		{
			m_nUg_0 = 0;
			m_nUg_4 = 0;
			m_dUg_8 = 0.0;
		}

		LanguageModel::Unigram::Unigram(Unigram const & a2)
			: m_umUg_10(a2.m_umUg_10)
		{
			m_nUg_0 = a2.m_nUg_0;
			m_nUg_4 = a2.m_nUg_4;
			m_dUg_8 = a2.m_dUg_8;
		}
		LanguageModel::Unigram & LanguageModel::Unigram::operator=(Unigram const & a2)
		{
			m_nUg_0 = a2.m_nUg_0;
			m_nUg_4 = a2.m_nUg_4;
			m_dUg_8 = a2.m_dUg_8;
			m_umUg_10 = a2.m_umUg_10;
			return *this;
		}
		LanguageModel::Unigram & LanguageModel::Unigram::operator=(Unigram && a2)
		{
			m_nUg_0 = a2.m_nUg_0;
			m_nUg_4 = a2.m_nUg_4;
			m_dUg_8 = a2.m_dUg_8;
			m_umUg_10 = move(a2.m_umUg_10);
			return *this;
		}
	}
}
