#include "CTCBeam.h"
#include "FieldMaskArbitrarySymbols.h"

using namespace imseg;

CTCBeam::CTCBeam(shared_ptr<IFieldMask>& spIFM_a2, uint n_a3)
{
	m_rCBCT_0 = 1000000.0;
	m_nCBCT_field_4 = n_a3;
	m_sptr_CBCT_IFM_8 = spIFM_a2;

	m_nCBCT_Width_10 = spIFM_a2->getBeamWidth();
	m_sptrCTCB_IC_20 = make_shared<imseg::MergeRepeats>(true, nullptr);
}

void CTCBeam::deleteDuplicatePaths(list<shared_ptr<CTCBeamNode>>& l_spCTCBN_a2)
{
	set<string> set_Unicode;
	list <shared_ptr<CTCBeamNode>>::iterator Iter;
	for (Iter = l_spCTCBN_a2.begin(); Iter != l_spCTCBN_a2.end();)
	{
		vector<CTCHypoth> vPath = (*Iter)->calcPath();
		m_sptrCTCB_IC_20->process(vPath);

		string strUnicode;
		for (size_t i = 0; i < vPath.size(); i++)
		{
			uint nUnicode = vPath[i].getUnicode();
			strUnicode.push_back(nUnicode);
		}

		int nOldCnt = set_Unicode.size();
		set_Unicode.insert(strUnicode);

		if (set_Unicode.size() == nOldCnt)
			Iter = l_spCTCBN_a2.erase(Iter);
		else Iter++;
	}
}

bool sub_4D852A(float a1, imseg::CTCBeamNode &a2)
{
	if (a2.getLogProb() < a1)
		return 1;
	return false;
}

void CTCBeam::deleteLowProbPaths(list<shared_ptr<CTCBeamNode>>& l_spCTCBN_a2)
{
	if (!l_spCTCBN_a2.empty())
	{
		deleteDuplicatePaths(l_spCTCBN_a2);
		float rLogProb = l_spCTCBN_a2.front()->getLogProb();

		list <shared_ptr<CTCBeamNode>>::iterator Iter;

		float rTmp = rLogProb * m_rCBCT_0;
		for (Iter = l_spCTCBN_a2.begin(); Iter != l_spCTCBN_a2.end(); )
		{
			if (sub_4D852A(rTmp, *Iter->get()))
			{
				list <shared_ptr<CTCBeamNode>>::iterator Iter1 = Iter;
				Iter1++;
				while (l_spCTCBN_a2.end() != Iter1 && sub_4D852A(rTmp, *Iter1->get()))
					Iter1++;

				Iter = l_spCTCBN_a2.erase(Iter, Iter1);
				if (Iter == l_spCTCBN_a2.end())
				{
					continue;
				}
			}
			Iter++;
		}

		if (l_spCTCBN_a2.size() > (uint)m_nCBCT_Width_10)
			l_spCTCBN_a2.resize(m_nCBCT_Width_10);
	}
}

void CTCBeam::deleteUnfinishedPathsIfFinishedPathExist()
{
	list<shared_ptr<CTCBeamNode>> list_spCTCB;
	list <shared_ptr<CTCBeamNode>>::iterator Iter;
	for (Iter = m_lCTCB_sptrCTCB_14.begin(); Iter != m_lCTCB_sptrCTCB_14.end(); Iter++)
	{
		vector<CTCHypoth> vCTCHy = (*Iter)->calcPath();
		if (m_sptr_CBCT_IFM_8->isAllSymbolsFound(vCTCHy))
		{
			list_spCTCB.push_back(*Iter);
		}
	}

	m_lCTCB_sptrCTCB_14 = list_spCTCB;
}

bool CTCBeam::empty()
{
	return m_lCTCB_sptrCTCB_14.empty();
}

vector<CTCHypoth> CTCBeam::getMostProbableSeq()
{
	// TODO: insert return statement here
	vector<CTCHypoth> vRet;
	deleteLowProbPaths(m_lCTCB_sptrCTCB_14);

	if (!m_lCTCB_sptrCTCB_14.empty())
		vRet = m_lCTCB_sptrCTCB_14.front()->calcPath();

	return vRet;
}

void CTCBeam::pushBackUpdatedNodes(shared_ptr<CTCBeamNode>& spCTCBN_a2, float const *r_a3, int n_a4, 
	Label2Unicodes const &xL2U_a5, int n_a6, list<shared_ptr<CTCBeamNode>>& l_spCTCBM_a6)
{
	vector<CTCHypoth> vPath;
	if (spCTCBN_a2.get())
		vPath = spCTCBN_a2->calcPath();

	m_sptr_CBCT_IFM_8->setPreviousPath(vPath);

	TopResultSet xTRS(m_nCBCT_Width_10);

	for (int i = 0; i < n_a4; i++)
	{
		vector<uint> vTmp = xL2U_a5(i);
		for (size_t j = 0; j < vTmp.size(); j++)
		{
			if (vTmp[j] != -1)
			{
				if (!vPath.empty() && vPath.back().getUnicode() == vTmp[j] ||
					m_sptr_CBCT_IFM_8->isUnicodePossible(vTmp[j]))
				{
					xTRS.addPoint(r_a3[i], i, vTmp[j]);
				}
			}
		}
	}

	int nTemp = (xTRS.m_nVRT_field_28 < m_nCBCT_Width_10) ? xTRS.m_nVRT_field_28 : m_nCBCT_Width_10;

	for (int i = 0; i < nTemp; i++)
	{
		CTCHypoth CTCHy;
		CTCHy.field_0 = xTRS.m_vTRS_field_C[i];
		CTCHy.m_wcUnicode_4 = xTRS.m_vTRS_field_C[i];
		CTCHy.field_8 = xTRS.m_vTRS_field_0[i];
		CTCHy.m_nIndex_C = n_a6;
		CTCHy.m_fcalcX_10 = 0;
		CTCHy.m_fHandmade_14 = xTRS.m_vTRS_field_18[i];

		shared_ptr<CTCHypoth> sptrCTCHy = make_shared<CTCHypoth>(CTCHy);
		shared_ptr<CTCBeamNode> sptrCTCBN = make_shared<CTCBeamNode>(spCTCBN_a2, sptrCTCHy);
		l_spCTCBM_a6.push_back(sptrCTCBN);
	}
}

void CTCBeam::update(float const *r_a2, int n_a3, Label2Unicodes const &xL2U_a4, int n_a5)
{
	list<shared_ptr<CTCBeamNode>> l_spCTCBN;
	
	if (!m_lCTCB_sptrCTCB_14.empty())
	{
		list <shared_ptr<CTCBeamNode>>::iterator Iter;
		for (Iter = m_lCTCB_sptrCTCB_14.begin(); Iter != m_lCTCB_sptrCTCB_14.end(); Iter++)
			pushBackUpdatedNodes((*Iter), r_a2, n_a3, xL2U_a4, n_a5, l_spCTCBN);
	}
	else
	{ 
		shared_ptr<CTCBeamNode> spCTCB = nullptr;
		pushBackUpdatedNodes(spCTCB, r_a2, n_a3, xL2U_a4, n_a5, l_spCTCBN);
	}
	deleteLowProbPaths(l_spCTCBN);

	m_lCTCB_sptrCTCB_14 = l_spCTCBN;
}
