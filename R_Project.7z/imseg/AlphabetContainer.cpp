#include "AlphabetContainer.h"

void CAlphabetContainer::append(vector<int>& vn_a2)
{
	for (uint i = 0; i < vn_a2.size(); i++)
		m_setAplpahbet_0.insert(vn_a2[i]);
}

void CAlphabetContainer::get(vector<int>& vn_a2)
{
	set<int>::iterator s_iter = m_setAplpahbet_0.begin();
	while(s_iter != m_setAplpahbet_0.end())
	{
		vn_a2.insert(vn_a2.end(), *s_iter);
		s_iter++;
	}
}
