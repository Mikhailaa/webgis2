#pragma once
#include "imseg_interface.h"
#include "CTCHypoth.h"

namespace imseg
{
	class MergeRepeats : public ICorrector
	{
	public:
		MergeRepeats();
		MergeRepeats(bool,ICorrector*);
		virtual ~MergeRepeats();

		//virtual void process(vector<CTCHypoth> &);
		virtual void process_impl(vector<CTCHypoth> &);
		bool m_bFlag_8;
	};
}