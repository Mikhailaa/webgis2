#include "rect.h"

namespace imseg
{
	namespace rect
	{
		Rect scale(Rect const&arg1, float arg2)
		{
			Rect res;
			res.x = int(arg1.x * arg2);
			res.y = int(arg1.y * arg2);
			res.width = int(arg1.width * arg2);
			res.height =int(arg1.height * arg2);
			return res;
		}

		vector<cv::Rect> scale(vector<cv::Rect> const&arg1, float arg2)
		{
			vector<cv::Rect> res;
			Rect _xRect_0, _xRect_10;
			res.reserve(arg1.size());
			for (size_t i = 0; i < arg1.size(); i++)
			{
				_xRect_10 = arg1[i];
				_xRect_0 = scale(_xRect_10, arg2);
				res.push_back(_xRect_0);
			}
			return res;
		}

		Rect addShift(Rect const &arg1, int arg2)
		{
			Rect res;
			res.x = arg1.x + arg2;
			res.y = arg1.y + arg2;
			res.width = arg1.width + arg2;
			res.height = arg1.height + arg2;
			return res;
		}
	}
}