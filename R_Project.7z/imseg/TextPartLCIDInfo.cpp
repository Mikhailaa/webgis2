#include "TextPartLCIDInfo.h"
#include "common/StringUtils.h"

void TextPartLCIDInfo::setAsMainLcid(int nMainLcid)
{
	for (uint i = 0; i < m_vLcids_4.size(); i++)
	{
		if (m_vLcids_4[i] == nMainLcid)
		{
			m_vLcids_4[i] = m_vLcids_4[0];
			m_vLcids_4[0] = nMainLcid;
			return;
		}
	}

}

TextPartLCIDInfo::TextPartLCIDInfo()
{
	m_nTPLCIDI_0 = 0;
}

TextPartLCIDInfo::TextPartLCIDInfo(TextPartLCIDInfo const &pTPLCIDI)
	: m_nTPLCIDI_0(pTPLCIDI.m_nTPLCIDI_0)
	, m_vLcids_4(pTPLCIDI.m_vLcids_4)
{

}

TextPartLCIDInfo::TextPartLCIDInfo(TextPartLCIDInfo &&pTPLCIDI)
	: m_nTPLCIDI_0(move(pTPLCIDI.m_nTPLCIDI_0))
	, m_vLcids_4(move(pTPLCIDI.m_vLcids_4))
{
}

TextPartLCIDInfo::~TextPartLCIDInfo()
{
}

void TextPartLCIDInfo::addLcid(int nLcid)
{
	m_vLcids_4.push_back(nLcid);
}

void TextPartLCIDInfo::init(string &strLcid)
{
	uint i;
	for (i = 0; i < strLcid.length(); i++)
	{
		if (strLcid[i] == '+') break;
	}

	m_nTPLCIDI_0 = (i != strLcid.length());

	char szTk = '+';
	if (i == strLcid.length()) szTk = ',';

	vector<string> vSplitted = common::StringUtils::Split(strLcid, szTk);
	for (uint i = 0; i < vSplitted.size(); i++)
	{
		addLcid(common::StringUtils::toInt(vSplitted[i]));
	}

}

int TextPartLCIDInfo::lcid()
{
	if (m_vLcids_4.empty())
		return 0;
	return m_vLcids_4[0];
}

vector<int>& TextPartLCIDInfo::lcids()
{
	return m_vLcids_4;
}

TextPartLCIDInfo & TextPartLCIDInfo::operator=(TextPartLCIDInfo const&a2)
{
	// TODO: insert return statement here
	m_vLcids_4 = a2.m_vLcids_4;
	m_nTPLCIDI_0 = a2.m_nTPLCIDI_0;
	return *this;
}
