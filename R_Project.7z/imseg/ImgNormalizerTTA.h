#pragma once

#include "imseg.h"
#include "imseg_interface.h"
#include "ImgNormalizer.h"

namespace imseg
{
	class ImgNormalizerTTA : public ITextLinesVisitor
	{
	public:
		ImgNormalizerTTA(cv::Size const&, uint const&, vector<TTAParams> const&, bool);
		virtual ~ImgNormalizerTTA();
		virtual void visit(RichTextLines &);

		ImgNormalizer m_xImgNormalizer_4;
		vector<TTAParams> m_vTTAParams_1C;
	};
}