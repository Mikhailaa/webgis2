#pragma once 
#include "CTCHypoth.h"
#include "HParam.h"
#include "Label2Unicodes.h"
#include "LanguageModel.h"
#include "MatrixMat.h"
#include "word_beam_search.h"

#include "unicodes.h"
#include "CTCBeam.h"
#include "FieldMaskArbitrarySymbols.h"

cv::Mat softmax(cv::Mat &);

using namespace imseg::word_beam_search;

namespace imseg
{
	//testFile : Front(4).jpg
	class DecoderCTC
	{
	public:
		DecoderCTC();

		void addVisualyIdenticalHypoths(set<unsigned int> const&, CTCHypoth &); //called
		set<uint> getAllUnicodes();
		int getLabelNum();//called
		vector<uint> getLabels();//called
		void getSecondaryHypoths(float const*,uint const&,Label2Unicodes const&,CTCHypoth &);
		void io_generic(cv::dnn::DnnReader &a2);
		vector<CTCHypoth> parseByWordBeamSearch(uint, cv::Mat const&, Label2Unicodes const&);//called
		vector<CTCHypoth> parseByMaskBeamSearch(cv::Mat const&, cv::Mat const&, Label2Unicodes const&, vector<CTCHypoth>, 
			shared_ptr<IFieldMask> &, set<uint> const&);//called
		vector<CTCHypoth> parseFast(cv::Mat const&, cv::Mat const&, Label2Unicodes const&);//called
		vector<CTCHypoth> parseLogits(uint,set<uint> const&,shared_ptr<IFieldMask> &, cv::Mat &);//called
		vector<CTCHypoth> parseSlow(shared_ptr<IFieldMask> &, cv::Mat const&, cv::Mat const&, Label2Unicodes const&);
		
		float m_rDCTC_secondHypProbDivisor_0;
		map<unsigned int, shared_ptr<LanguageModel>> m_tDCTC_field_4;
		vector<uint> m_vDCTC_Labels_10;
	};
}

/*
imseg::Label2Unicodes

vector m_vL2U_field_0;
vector m_vL2U_field_C;
__tree m_tL2U_field_18;
__tree m_tL2U_field_24;

*/