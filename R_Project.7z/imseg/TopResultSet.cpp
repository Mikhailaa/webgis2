#include "TopResultSet.h"

using namespace imseg;

TopResultSet::TopResultSet(uint nSize)
{
	m_nVRT_field_28 = 0;
	m_nVRT_Size_24 = nSize;
	m_vTRS_field_0.resize(nSize);
	m_vTRS_field_C.resize(nSize);
	m_vTRS_field_18.resize(nSize);
	m_rVRT_field_2C = 1.1755e-38f;
	m_vTRS_field_18[m_nVRT_Size_24 - 1] = 1.1755e-38f;
}

TopResultSet::~TopResultSet()
{
}

void TopResultSet::addPoint(float r_a2, uint n_a3, uint n_a4)
{
	if (m_rVRT_field_2C < r_a2)
	{
		int i;
		for (i = m_nVRT_field_28; i > 0; i--)
		{
			if (m_vTRS_field_18[i - 1] >= r_a2) break;
			if (i < m_nVRT_Size_24)
			{
				m_vTRS_field_18[i] = m_vTRS_field_18[i - 1];
				m_vTRS_field_0[i] = m_vTRS_field_0[i - 1];
				m_vTRS_field_C[i] = m_vTRS_field_C[i - 1];
			}
		}

		if (m_nVRT_field_28 < m_nVRT_Size_24)
			m_nVRT_field_28++;

		m_vTRS_field_18[i] = r_a2;
		m_vTRS_field_0[i] = n_a3;
		m_vTRS_field_C[i] = n_a4;
		m_rVRT_field_2C = m_vTRS_field_18[m_nVRT_Size_24 - 1];
	}
}
