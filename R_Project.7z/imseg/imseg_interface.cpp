﻿#include "imseg_interface.h"
#include "common/common.h"
#include "ImgNormalizer.h"
#include "imseg.h"
#include "ImgNormalizerTTA.h"
#include "Bankcard.h"

using namespace common;

vector<TTAParams> ttaParamsStrong = { { 0.0f, 0.0f, 0.0f },{ 0.05f, 0.027f, -0.05f },{ -0.05f, -0.027f, 0.05f } };

void applyCLAHE(Mat & xMat)
{
	Ptr<CLAHE> ptrCLAHE = createCLAHE(1.0, Size_<int>(MAX(1, xMat.cols / 48), MAX(1, xMat.rows / 48)));
	if (xMat.flags & 0xFF8)
	{
		Mat _Mat_40;
		vector<Mat> _pMat_4;
		cvtColor(xMat, _Mat_40, 45);
		split(_Mat_40, _pMat_4);
		ptrCLAHE->apply(_pMat_4[0], _pMat_4[0]);
		merge(_pMat_4[0], _Mat_40);
		cvtColor(_Mat_40, xMat, 57);
	}
	else
		ptrCLAHE->apply(xMat, xMat);
}

void calcTotalMeanAndStd(Mat &xMat, float& r_1, float& r_2)
{
	Scalar _Scalar_50, _Scalar_30;
	meanStdDev(xMat, _Scalar_50, _Scalar_30);
	int v14 = ((xMat.flags >> 3) & 0x1FFF) + 1;
	int v15 = ((xMat.flags >> 3) & 0x1FFF) + 1;
	int i = 0;
	while (v15)//PKS Z
	{
		--v15;
		r_1 += (float)_Scalar_50[i];
		r_2 += (float)_Scalar_30[i];
		i++;
	}
	r_1 /= v14;
	r_2 /= v14;
}

namespace imseg
{
	void ICorrector::process(vector<CTCHypoth>&a1)
	{
		if (m_pIC_4)
			m_pIC_4->process(a1);

		process_impl(a1);
	}

	shared_ptr<ITextLinesVisitor> IImgNormalizer::factory(uint const &n_a2, uint const &n_a3, cv::Size const &xSize_a4)
	{
		int nTmp = n_a2;
		if (n_a2 == 1066) nTmp = n_a3;
		else if (n_a2 == 10001)
			return shared_ptr<ITextLinesVisitor>(new ImgNormalizerTTA(xSize_a4, n_a2, ttaParamsStrong, 0));
		return shared_ptr<ITextLinesVisitor>(new ImgNormalizer(xSize_a4, nTmp));
	}


	shared_ptr<ITextLinesVisitor> IPostCorrector::factory(FieldParam &xFieldParam)
	{
		if (xFieldParam.contain(PROCESS_OPTION_12))
		{
			return shared_ptr<ITextLinesVisitor>(new bankcard::BankCardNumberPostCorrector);
		}
		else if (xFieldParam.contain(PROCESS_OPTION_13))
		{
			return shared_ptr<ITextLinesVisitor>(new bankcard::BankCardDatePostCorrector);
		}
		else if (xFieldParam.contain(PROCESS_OPTION_14))
		{
			return shared_ptr<ITextLinesVisitor>(new bankcard::BankCardExtractNameStringPostCorrector);
		}
		else
		{
			return shared_ptr<ITextLinesVisitor>(new PostCorrectorNull);
		}
	}

	
	void ITextDetector::accept(ITextLinesVisitor &)
	{

	}

	vector<Rect> ITextDetector::detect(Mat & xMat)
	{
		vector<Rect> vRect_res;
		float _r_24, _r_20;
		Mat _Mat_D0 = resize(xMat, _r_24, _r_20);
		standartizeImg(_Mat_D0);
		if (!(_Mat_D0.flags & 0xFF8))
			cvtColor(_Mat_D0, _Mat_D0, 8);
		Mat _Mat_98;
		Scalar _Scalar_60;
		dnn::blobFromImage(_Mat_98, 1.0, m_xSize_C, _Scalar_60, 1);
		dnn::Net *pNet = m_spNet_4.get();
		cv::String _cvs_60("");
		pNet->setInput(_Mat_98, _cvs_60);
		cv::String _cvs_28;
		Mat _Mat_60 = pNet->forward();
		Mat _Mat_28(_Mat_60.size.p[2], _Mat_60.size.p[3], 5, _Mat_60.data, 0);
		float *prData;
		Rect _xRect_10;
		for (int i = 0; i < _Mat_28.rows; i++)
		{
			prData = _Mat_28.ptr<float>(i);
			if (prData[2] > m_r_14)
			{
				_xRect_10.x = int(prData[3] * _Mat_D0.size().width);
				_xRect_10.y = int(prData[4] * _Mat_D0.size().height);
				_xRect_10.width = int(prData[5] * _Mat_D0.size().width - _xRect_10.x);
				_xRect_10.height = int(prData[6] * _Mat_D0.size().height - _xRect_10.y);
			}
			if (_xRect_10.width && _xRect_10.height)
				vRect_res.push_back(_xRect_10);
		}

		for (uint i = 0; i < vRect_res.size(); i++)
		{
			vRect_res[i].x = int(vRect_res[i].x * _r_24);
			vRect_res[i].y = int(vRect_res[i].y *_r_20);
			vRect_res[i].width = int(vRect_res[i].width * _r_24);
			vRect_res[i].height = int(vRect_res[i].height * _r_20);
		}

		Rect xRectTmp;
		for (uint i = 0; i < vRect_res.size(); i++)
		{
			xRectTmp.x = MAX(vRect_res[i].x, 0);
			xRectTmp.y = MAX(vRect_res[i].y, 0);
			xRectTmp.width = MIN(vRect_res[i].x + vRect_res[i].width, xMat.size().width) - xRectTmp.x;
			xRectTmp.height = MIN(vRect_res[i].y + vRect_res[i].height, xMat.size().height) - xRectTmp.y;
			vRect_res[i] = xRectTmp;
			if (xRectTmp.width < 1 || xRectTmp.height < 0)
				vRect_res.erase(vRect_res.begin() + i);
		}
		vector<Rect> vRect_10 = postprocDetections(xMat, vRect_res);
		vRect_res = vRect_10;
		return vRect_res;
	}

	RichTextLines ITextDetector::detect(RichTextLines & xRichTextLines)
	{
		Mat _Mat_34(xRichTextLines.getImg());
		vector<Rect> _vRect_28 = detect(_Mat_34);
		xRichTextLines.setTextROIs(_vRect_28);
		//common::fs::Path _xfsPath_10(xRichTextLines.getDbgFolders().front().m_xCfsPath_0);
		string _s_0("TextDetectorBankCard.jpg");
		//imseg::dbgInfoSaver::saveImage(&_Mat_34, &_vRect_28, &_xfsPath_10, &_s_0);
		RichTextLines res(xRichTextLines);
		return res;
	}

	shared_ptr<ITextDetector> ITextDetector::factory(uint un_a1, Size & xSize_a2, shared_ptr<dnn::Net>& spNet_a3)
	{
		if (un_a1 = 10002)
		{
			shared_ptr<bankcard::TextDetectorBankCardName> sp = make_shared<bankcard::TextDetectorBankCardName>(xSize_a2, spNet_a3);
			return sp;
		}
		else if (un_a1 = 10001)
		{
			shared_ptr<bankcard::TextDetectorBankCardValidThru> sp = make_shared<bankcard::TextDetectorBankCardValidThru>(xSize_a2, spNet_a3);
			return sp;
		}
		else
		{
			shared_ptr<bankcard::TextDetectorBankCardDummy> sp = make_shared<bankcard::TextDetectorBankCardDummy>(/*xSize_a2, spNet_a3*/);
			return sp;
		}
	}

	void imseg::ITextDetector::standartizeImg(Mat & xMat)
	{
		float r_1 = 0.0f, r_2 = 0.0f;
		applyCLAHE(xMat);
		calcTotalMeanAndStd(xMat, r_1, r_2);
		xMat.convertTo(xMat, 5, 1.0, -r_1);
		xMat.convertTo(xMat, -1, 0.0078125, 0.0);
		normalize(xMat, xMat, 0.0, 255.0, 32);
	}

	void ITextDetector::visit(RichTextLines &xRichTextLines)
	{
		RichTextLines _xRichTextLines = detect(xRichTextLines);
		xRichTextLines = _xRichTextLines;
	}

	vector<Rect> imseg::ITextDetector::postprocDetections(Mat & xMat, vector<Rect>& vRect)
	{
		vector<Rect> vRectRes(vRect);
		return vRectRes;
	}
}

void IAlphabetInfo::addNumbers(vector<wchar_t>& a2)
{
	for (int i = '0'; i <= '9'; i++)
	{
		a2.push_back(i);
	}
}
