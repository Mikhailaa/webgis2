#include "Seq2MaskAligner.h"
#include "CostMat.h"
#include "NeedlemanWulschAlg.h"
#include "RichTextLines.h"
#include "dbgInfoSaver.h"

namespace imseg
{
	Seq2MaskAligner::Seq2MaskAligner()
	{
	}

	Seq2MaskAligner::Seq2MaskAligner(ParsedMask &a2)
		: m_xParsedMask_4(a2)
	{
	}

	vector<CharPlace> Seq2MaskAligner::expandOptional(vector<CTCHypoth>& a2, vector<CharPlace> const &a3)
	{
		vector<CharPlace> result;
		for (size_t i = 0; i < a3.size(); i++)
		{
			CharPlace v15(a3[i]);
			bool v10 = v15.isOptional();
			result.push_back(v15);
			if (v10)
			{
				for (size_t j = 1; j < a2.size(); j++)
				{
					result.push_back(v15);
				}
				result.back().makeObligatory();
			}
		}
		return result;
	}

	void Seq2MaskAligner::process(vector<vector<CTCHypoth> >& a2)
	{
		CostMat v27;
		for (size_t v4 = 0; v4 < a2.size(); v4++)
		{
			if (a2[v4].size())
			{
				vector<CTCHypoth> v25(a2[v4]);
				vector<vector<CharPlace> > v24 = m_xParsedMask_4.getParsedMaskAnyWay(v4);
				float v7 = 3.4028e38f;
				vector<CTCHypoth> v21;
				for (size_t v8 = 0; v8 < v24.size(); v8++)
				{
					vector<CTCHypoth> v18;
					vector<CharPlace> v17;
					vector<CharPlace> v16 = expandOptional(a2[v4], v24[v8]);
					float v11 = NeedlemanWulschAlg::alignSeqs(a2[v4], v16, v27, v18, v17);
					if (v11 < v7)
					{
						v21 = v18;
						v7 = v11;
					}
				}

				a2[v4] = v21;
			}
		}
	}

	void Seq2MaskAligner::visit(RichTextLines &a2)
	{
		vector<vector<CTCHypoth> > &v4 = a2.getSeqs();
		process(v4);
		//vector<DbgFolder> v5 = a2.getDbgFolders();
		for (size_t i = 0; i < v4.size(); i++)
		{
			//dbgInfoSaver::saveAfterAlignment(v5->at(i), v4[i]);
		}
	}

	shared_ptr<ITextLinesVisitor> Seq2MaskAligner::createSeq2MaskAligner(ParsedMask &xPM_a2)
	{
		if (xPM_a2.isLineBreaksDoesNotMatter())
		{
			return shared_ptr<ITextLinesVisitor>(new Seq2MaskAlignerLineBreaksDoesNotMatter(xPM_a2));
		}
		return shared_ptr<ITextLinesVisitor>(new Seq2MaskAligner(xPM_a2));
	}

	Seq2MaskAlignerLineBreaksDoesNotMatter::Seq2MaskAlignerLineBreaksDoesNotMatter(ParsedMask const &)
	{

	}

	void Seq2MaskAlignerLineBreaksDoesNotMatter::process(vector<vector<CTCHypoth>>& a2)
	{
		vector<vector<CTCHypoth>> v9 = uniteSeqs(a2);
		Seq2MaskAligner::process(v9);
		vector<vector<CTCHypoth>> v7 = splitSeqsBack(v9, a2);
		a2 = v7;
	}

	vector<vector<CTCHypoth>> Seq2MaskAlignerLineBreaksDoesNotMatter::uniteSeqs(vector<vector<CTCHypoth>> const&a1)
	{
		vector<vector<CTCHypoth>> result;
		vector<CTCHypoth> v8;
		for (size_t i = 0; i < a1.size(); i++)
		{
			v8.insert(v8.end(), a1[i].begin(), a1[i].end());
		}
		result.reserve(1);
		result[0] = v8;

		return result;
	}

	wstring sub_627BBBE4(vector<vector<CTCHypoth>> const&a2)
	{
		wstring result;
		for (size_t i = 0; i < a2[0].size(); i++)
		{
			result.push_back(a2[0][i].getUnicode());
		}
		return result;
	}

	vector<vector<CTCHypoth>> Seq2MaskAlignerLineBreaksDoesNotMatter::splitSeqsBack(vector<vector<CTCHypoth>> const&a1, vector<vector<CTCHypoth>> const&a2)
	{
		vector<vector<CTCHypoth>> result;
		vector<vector<CTCHypoth>> v42 = uniteSeqs(a2);
		wstring v41 = sub_627BBBE4(v42);
		wstring v40 = sub_627BBBE4(a1);
		vector<int> v37;
		map<uint, pair<uint, uint>> v33;
		uint v6 = 0, v11;
		alignStrings(v41, v40, v37);
		for (size_t i = 0; i < v37.size(); i++)
		{
			if (v37[i] == 2)
			{
				v11 = v6 + 2;
				v33[i] = pair<uint, uint>(v6, v11);
				v6 = v11;
			}
			else if (v37[i] == 1)
			{
				v33[i] = pair<uint, uint>(v6, v6);
			}
			else
			{
				v11 = v6 + 1;
				v33[i] = pair<uint, uint>(v6, v11);
				v6 = v11;
			}
		}
		size_t j = 0;
		for (vector<vector<CTCHypoth>>::const_iterator iter = a2.begin(); iter != a2.end(); iter++)
		{
			vector<CTCHypoth> v30;
			size_t v16 = j + iter->size();
			for (; j < v16; j++)
			{
				map<uint, pair<uint, uint>>::iterator v17 = v33.find(j);
				if (v17 != v33.end())
				{
					for (uint k = v17->second.first; k < v17->second.second; k++)
					{
						v30.push_back(a1[0][k]);
					}
				}
			}
			result.push_back(v30);
		}

		return result;
	}
}
