#include "Ensemble.h"

using namespace imseg;

Ensemble::Ensemble()
{
}

Ensemble::~Ensemble()
{
}

void Ensemble::visit(RichTextLines & xRTL)
{
	vector<RichTextLines> vRTL;
	if (xRTL.hasAugmentedVersions())
		vRTL = xRTL.getAugmentedVersions();
	else
		vRTL = vector<RichTextLines>(m_vEsm_sptrCTCDNN_4.size(), xRTL);

	for (size_t i = 0; i < vRTL.size(); i++)
	{
		m_vEsm_sptrCTCDNN_4[i].get()->visit(vRTL[i]);
	}

	xRTL.setVotingSeqs(vRTL);
}

cv::Size Ensemble::getSize()
{
	return m_vEsm_sptrCTCDNN_4[0].get()->getSize();
}

void imseg::Ensemble::io_generic(cv::dnn::DnnReader &a2)
{
	int a2a;
	a2.io(&a2a);
	if (a2a != m_vEsm_sptrCTCDNN_4.size())
	{
		for (int i = 0; i < a2a; i++)
		{
			shared_ptr<CTCDNN> v9 = make_shared<CTCDNN>();

			m_vEsm_sptrCTCDNN_4.push_back(v9);
		}
	}
	for (int i = 0; i < a2a; i++)
	{
		m_vEsm_sptrCTCDNN_4[i]->io_generic(a2);
	}
}

Ensemble & imseg::Ensemble::operator=(Ensemble const &arg1)
{
	if (this != &arg1)
		m_vEsm_sptrCTCDNN_4.assign(arg1.m_vEsm_sptrCTCDNN_4.begin(), arg1.m_vEsm_sptrCTCDNN_4.end());
	return *this;
}

void Ensemble::setMasks(vector<shared_ptr<IFieldMask>>& v_sptrIFM)
{
	for (size_t i = 0; i < m_vEsm_sptrCTCDNN_4.size(); i++)
	{
		m_vEsm_sptrCTCDNN_4[i].get()->setMasks(v_sptrIFM);
	}
}
