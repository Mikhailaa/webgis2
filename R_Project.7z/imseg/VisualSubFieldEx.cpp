#include "VisualSubFieldEx.h"
#include <regex>
#include "common/StringUtils.h"
#include "common/UnicodeUtils.h"

bool CVisualSubFieldEx::findResultInEnum(vector<wstring>& a1, vector<vector<pair<int, int>>>& a2, wstring & a3)
{
	a3.clear();
	int v29 = a1.size();
	int v5 = a2.size();

	for (int i = 0; i < v29; i++)
	{
		if (a1[i].length() == v5)
		{
			int v14 = 0;
			for (uint j = 0; j < a1[i].length(); j++)
			{
				int v17 = 0;
				uint v18 = 0;
				while (!v17 && v18 < a2[j].size())
				{
					if (a2[j][v18].first == a1[i][j])
						v17 = 1;
					v18++;
				}
				v14 = 1;
				if (!v17)
				{
					v14 = 0;
					break;
				}
			}
			if (v14)
			{
				a3 = a1[i];
				break;
			}

		}
	}

	return a3.empty();
}

bool CVisualSubFieldEx::findResultInEnum2(vector<wstring>& a1, vector<vector<pair<int, int>>>& a2, wstring & a3)
{
	string v28;
	for (uint i = 0; i < a2.size(); i++)
	{
		if (a2[i].empty())
			v28.append(" ");
		else
			v28.push_back(a2[i].front().first);
	}
	vector<regex> v27(a2.size());
	for (uint j = 0; j < a2.size(); j++)
	{
		string v26 = v28;
		v26.replace(j, 1, "[A-Za-z]{1}");
		common::StringUtils::Replace(v26, string("*"), string("[*]{1}"));
		v27[j] = regex(v26);
	}

	vector<wstring> v26;
	for (uint k = 0; k < a1.size(); k++)
	{
		for (uint v14 = 0; v14 < v27.size(); v14++)
		{
			string v24 = common::UnicodeUtils::UncheckedWStrToUtf8(a1[k]);
			if (regex_search(v24, v27[v14]))
			{
				v26.push_back(a1[k]);
			}
		}
	}
	if (v26.empty())
		return 1;
	a3 = v26.front();
	return 0;
}

int CVisualSubFieldEx::getVariantsFromSubField(CVisualSubField & a1, vector<wstring>& a2)
{
	a2.clear();
	for (int i = 0; i < a1.m_nTVSF_Count_210; i++)
	{
		string v14(a1.m_lpTVSF_Buffer_214 + 256 * i);
		wstring v15 = common::UnicodeUtils::Utf8ToWStr(v14);
		a2.push_back(v15);
	}
	return 0;
}

bool CVisualSubFieldEx::isDynamic(TVisualSubField & a1)
{
	string v16(a1.m_szTVSF_110);

	return v16.find("WORD") != -1 || v16.find("STRING") != -1;

}

int CVisualSubFieldEx::load(ListSubField & a1, vector<uchar>& a2)
{
	a1.reset();
	unsigned char * v4 = a2.data();
	int v5 = *(int *)v4;
	a1.resize(v5);
	int v6 = 4;
	for (int i = 0; i < v5; ++i)
	{
		CVisualSubField *v8 = &a1[i];
		memcpy(v8, &v4[v6], 0x214);
		v8->m_lpTVSF_Buffer_214 = 0;
		memcpy(v8->m_aTVSF_Alphabet_218, &v4[v6 + 0x218], 0x454);
		v6 += 0x66C;
		if (v8->m_nTVSF_Count_210)
		{
			unsigned v10 = v8->m_nTVSF_Count_210 * 256;
			v8->m_lpTVSF_Buffer_214 = new char[v10];
			for (int j = 0; j < v8->m_nTVSF_Count_210; j++)
			{
				memcpy(&v8->m_lpTVSF_Buffer_214[256 * j], &v4[v6], 256);
				v6 += 256;
			}
		}
	}

	return 0;
}

int CVisualSubFieldEx::save(ListSubField &, vector<uchar>&)
{
	return 0;
}