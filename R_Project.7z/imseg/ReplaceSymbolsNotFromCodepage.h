#pragma once
#include "imseg_interface.h"
#include "imseg/CTCHypoth.h"

namespace imseg
{
	class ReplaceSymbolsNotFromCodepage : public ICorrector
	{
	public:
		int m_nReplaceSymbolsNotFromCodepage_8;
		ReplaceSymbolsNotFromCodepage(int, ICorrector*);
		~ReplaceSymbolsNotFromCodepage();
		virtual void process_impl(vector<CTCHypoth> &);
	};
}