#include "FieldMaskEx.h"
#include "RSubFieldManager.h"

void FieldMaskEx::convertStaticToSubFields(string str_a1, string &str_a2)
{
	string strResult;
	for (uint i = 0; i < str_a1.size(); i++)
	{
		switch (str_a1[i])
		{
		case '&':
			i++;
			strResult += string("{&") + str_a1[i]  + string("}");
			continue;
		case 'A':
			strResult += "{A}";
			continue;
		case 'S':
		case 'C':
		case 'D':
			strResult += string("{") + str_a1[i] + string("}");
			continue;
		case 'W':
			strResult += "{W}";
			continue;
		case 'c':
			strResult += "{b}";
			continue;

		default:
			break;
		}

		if (str_a1[i] != '{')
		{
			strResult += str_a1[i];
			continue;
		}

		string str_48;
		while (i < str_a1.size())
		{
			i++;
			if (i >= str_a1.size()) break;
			if (str_a1[i] == '}') break;
			str_48 += str_a1[i];
		}

		string strSimpleSubField = FieldMaskEx::convertToSimpleSubFields(str_48);
		if (str_48 == strSimpleSubField)
			str_48 = '{' + str_48 + '}';

		strResult += str_48;
	}

	str_a2 = strResult;
}

string FieldMaskEx::convertToSimpleSubFields(string str_a2)
{
	string strTmp(str_a2);
	bool bFlag = false;
	int nFind1 = -1;

	if (!str_a2.empty())
	{
		char szChar = 0;
		string asc_FB43F9 = "\"[";
		for (int i = 0; i < 2; i++)
		{
			szChar = asc_FB43F9[i];
			if (str_a2[i] == szChar)
			{
				strTmp = string(str_a2, 0, i);
				bFlag = true;
				nFind1 = i;
				break;
			}
		}
	}

	ListSubField *pLSF = RSubFieldManager::subFields();
	int nIdx = pLSF->indexOf(strTmp.data());

	if (nIdx != -1)
	{
		CVisualSubField &pVSF = (*pLSF)[nIdx];
		string str_70(pVSF.m_szTVSF_110);
		vector<string> vstr_7C = { "STRING" , "TEXT" , "WORD" };

		bool bFind = false;
		for (uint i = 0; i < vstr_7C.size(); i++)
		{
			if (str_70.find(vstr_7C[i]))
			{
				bFind = true;
				break;
			}
		}

		if (!bFind)
		{
			if (!pVSF.m_nTVSF_Count_210)
			{
				string str_48;
				set<char> setChar_88;
				for (uint i = 0; i < str_70.length(); i++)
				{
					if (isalpha(str_70[i]))
					{
						setChar_88.insert(str_70[i]);
					}
				}

				if (setChar_88.size() > 1)
				{
					if (bFlag)
					{
						string str_54(str_a2, nFind1, -1);
						for (uint i = 0; i < str_70.length(); i++)
						{
							str_48 += string("{") + str_70[i] + string("}");
						}
					}

					if (str_48.empty())
						str_70 = str_48;
					strTmp = str_70;
				}
			}
		}
	}

	return strTmp;
}
