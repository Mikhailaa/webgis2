#pragma once

#include "pch.h"
#include "imgStructs.h"


class  CDocBarCodeField
{
public:
	CDocBarCodeField() {}
	~CDocBarCodeField() {}
	void load(CDocBarCodeField const&) {}

	void setRect(tagRECT) {}
	void setRect(int,int,int,int) {}


	int m_bCDBCF_ResultEmpty;
	int m_nCDBCF_DetectType;
	tagRECT m_xCDBCF_Rect;//0x08
	int field_18;
	int m_nCDBCF_field_1C;//0x1C
	int m_nCDBCF_ModuleCount;
	string m_strCDBCF_field_24;
	int m_nCDBCF_field_30;
	int m_nCDBCF_field_34;
	int m_nCDBCF_field_38;
	int m_nCDBCF_field_3C;
	int m_nCDBCF_field_40;
	int m_nCDBCF_field_44;
	char* m_szTVSF_48;
};

class CDocBarCodeInfo
{
public:
	CDocBarCodeInfo() {}
	~CDocBarCodeInfo() {}

	void free() {}

	int m_nCDBCIR_Count;
	CDocBarCodeField *m_pCDBCIR_FieldList;//0x04
	int m_nCDBCIR_field_8;
};


class CDocBarCodeInfoR : public CDocBarCodeInfo
{
public:
	CDocBarCodeInfoR() :CDocBarCodeInfo() {}
	~CDocBarCodeInfoR() {}

	CDocBarCodeField* operator[](int) { return 0; }

	int count() { return 0; }
	CDocBarCodeField *add() { return 0; }
};