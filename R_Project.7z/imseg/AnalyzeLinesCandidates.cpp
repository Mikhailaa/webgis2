#include "AnalyzeLinesCandidates.h"
#include "parameters.h"
#include "Analyse.h"
#include "common/common.h"
#include "LinesInfoAnalyze.h"
#include "Point.h"

int AnalyzeLinesCandidates::analize(VLinesCandidates &VLC_a1, FontDesc &FontDesc_a2, InitConstStructs &ICS_a3, LetterType LetterType_a4, vector<vector<tagRECT>>&vvtRECT_a5)
{
	int res, nTmp_C = 0, nTmp_10 = 0;
	LetterType LetterType_0 = 0;
	res = detectMiddleH(LetterType_a4, VLC_a1, (eHType)FontDesc_a2.m_xFontDescBase_0.m_nFDB_Field_0, FontDesc_a2.m_xFontDescBase_0.m_nFDB_Field_4, ICS_a3, nTmp_10, nTmp_C);
	if (!res)
	{
		FontDesc_a2.m_xFontDescBase_0.m_nFDB_Field_8 = nTmp_10;
		detectLinesUsingMiddleH(VLC_a1, (eHType)FontDesc_a2.m_xFontDescBase_0.m_nFDB_Field_0, nTmp_10, ICS_a3, LetterType_0, nTmp_10, vvtRECT_a5);
		res = 0;
	}
	return res;
}

void AnalyzeLinesCandidates::detectLinesUsingMiddleH(VLinesCandidates &xVLC_Param1, eHType eParam2, int &nParam3, InitConstStructs &xICS_Param4, LetterType eParam5, int &nParam6, vector<vector<tagRECT>>&vParam7)
{
	vParam7.resize(xVLC_Param1.m_vLinesCandidates.size());
	float v17 = (float)nParam6 * xICS_Param4.m_xTLineAnalyzeFirst_0.m_r_2C;
	float v14 = 0.25f, v15 = 1.5f;
	if (eParam2 == 5)
	{
		v14 = 3.0f;
		v15 = 2.5f;
	}
	if (v17 <= 3)
		v17 = 3;
	uint v20 = (((uint)v17 >> 1) << 1) + 1;
	uint v74 = (v20 >> 1), v75 = (v20 >> 1) + 1;
	for (size_t i = 0; i < xVLC_Param1.m_vLinesCandidates.size(); i++)
	{
		vector<int> vP2, vP3;
		multimap<int, int> mm4, mm5;
		LinesInfoAnalyze::getHistY(xVLC_Param1.m_vLinesCandidates[i].m_vTxPoints_0, vP2, vP3, &mm4, &mm5, 0, 0);
		vector<pair<int, int>> vPair;
		vector<int> vv94;
		RAnalyse::maxAprox(vP2, v20, vPair);
		while (1)
		{
			float f4 = 0.0f;
			int n5 = 0, n6 = 0;
			if (RAnalyse::maxAprox(vP2.data(), vP2.size(), v20, f4, n5, n6))
			{
				break;
			}
			float fTemp = f4 + 0.5f;
			uint v22 = v75 + n6;
			if (v22 > vP2.size())
				v22 = vP2.size();
			uint v23 = ((uint)n6 > v74) ? (n6 - v74) : 0;
			int n84 = 0, n83 = 0;
			LinesInfoAnalyze::getXPosition(mm4, v23, v22, n84, n83);
			vector<float> vF;
			updateProbs(n84, n83, vP2, mm4, vF);
			memset(&vP2[v23], 0, sizeof(int) * (v22 - v23));
			vector<int> vTemp(vP2.size());
			for (size_t j = 0; j < vP2.size(); j++)
			{
				vTemp[j] = int(vF[j] * vP2[j]);
			}
			uint n33 = v23 + nParam6 / 3;
			if (n33 > vP2.size())
				n33 = vP2.size();
			int n79 = 0;
			if (v22 > vTemp.size() - 1)
				v22 = vTemp.size() - 1;
			int n34 = RAnalyse::maxAprox(&vTemp[v22], n33 - v22, v20, f4, n79, n6);
			if ((n5 && !n34 && (float)n79 / n6 >= 0.3f) || (!n5 && !n34))
			{
				fTemp = f4 + v22 + 0.5f;
			}
			vv94.push_back((int)fTemp);
		}
		vector<int> vI;
		for (size_t j = 0; j < vv94.size(); j++)
		{
			uint v44 = uint(vv94[j] + nParam6 * 0.5f);
			if (v44 < vP3.size())
			{
				uint v45 = uint(vv94[j] + v15 * nParam6 + 1);
				if (v45 > vP3.size() - 1)
					v45 = vP3.size() - 1;
				if (v45 != v44)
				{
					vector<int> vTemp(vP3.begin() + v44, vP3.begin() + v45 + 1);
					vector<pair<int, int>> vPP;
					RAnalyse::maxAprox(vTemp, v20, vPP);
					if (vPP.empty())
					{
						break;
					}
					for (size_t k = 0; k < vPP.size(); k++)
					{
						vI.push_back(vPP[k].first + v44);
					}
				}
			}
		}
		while (1)
		{
			float v46 = 1e17f;
			tagRECT r = { 0, 0, 0, 0 };
			for (size_t j = 0; j < vv94.size(); j++)
			{
				for (size_t k = 0; k < vI.size(); k++)
				{
					if (vv94[j] < vI[k])
					{
						size_t l;
						for (l = 0; l < vParam7[i].size(); l++)
						{
							int v56 = vParam7[i][l].top;
							int v59 = vv94[j] - v56;
							if (v59 > 0)
							{
								v59 = vI[k] - v56;
							}
							int v57 = (v59 == 0);
							int v58 = (v59 < 0);
							if (v57 | (v58 ^ v59))
							{
								int v60 = vParam7[i][l].bottom;
								int v62 = (vv94[j] < v60) ? (vI[k] - v60) : (vv94[j] - v60);
								int v61 = (v62 < 0);
								if (!(v61 ^ v62))
									break;
							}
						}
						if (l == vParam7[i].size())
						{
							float v63 = fabsf((nParam6 + vv94[j] - vI[k]) / (float)nParam6);
							if (v63 < v46)
							{
								v46 = v63;
								r.bottom = vv94[j];
								r.top = vI[k];
							}
						}
					}
				}
			}
			if (v46 >= v14)
				break;
			vParam7[i].push_back(r);
		}
	}
}

int AnalyzeLinesCandidates::detectMiddleH(LetterType LetterType_a1, VLinesCandidates &VLC_a2, eHType eHType_a3, int & n_a4, InitConstStructs &ICS_a5, int &n_a6, int &n_a7)
{
	float rTmp_v10 = imseg::parameters::kHDeviation(ICS_a5.m_xTLineAnalyzeFirst_0, eHType_a3);
	float rTmp_v12 = rTmp_v10 * ICS_a5.m_xTLineAnalyzeFirst_0.m_r_30;
	float rTmp_v13 = n_a4 * 0.8f;
	if (LetterType_a1 << 30 < 0)
		rTmp_v13 = n_a4 * 0.4f;
	int nTmp_v14 = max(0, (int)rTmp_v13);
	int nlineCandidateCount = VLC_a2.lineCandidateCount();
	int nTmp_v19 = max(3, int(ICS_a5.m_xTLineAnalyzeFirst_0.m_r_2C * n_a4));
	nTmp_v19 = nTmp_v19 + (1 - nTmp_v19 % 2);
	vector<int> _vn_20; 
	VLC_a2.getHInfo(nTmp_v14, int(rTmp_v12 * n_a4), _vn_20);
	for (int j = 0; j < 2; j++)
	{
		vector<pair<int, int>> _vpairnn_14;
		vector<int> _vn_8(_vn_20);
		RAnalyse::maxAprox(_vn_8, nTmp_v19, _vpairnn_14);
		if (_vpairnn_14.empty())
			break;
		int nTmp_v29, nTmp_v25 = _vpairnn_14.size();
		int i;
		for (i = 0; i < nTmp_v25; i++)
		{
			nTmp_v29 = _vpairnn_14[i].first - n_a4;
			if (nTmp_v29 < 0)
				nTmp_v29 = -nTmp_v29;
			if (nTmp_v29 / n_a4 < rTmp_v10 - 1.0)
				break;
		}
		if (nTmp_v25 == i)
		{
			for (i = 0; i < nTmp_v25; ++i)
			{
				nTmp_v29 = _vpairnn_14[i].first - n_a4;
				if (nTmp_v29 < 0)
					nTmp_v29 = -nTmp_v29;
				if (nTmp_v29 / n_a4 < rTmp_v12 - 1.0)
					break;
			}
			if (nTmp_v25 == i)
				break;
		}
		n_a6 = _vpairnn_14[i].first;
		n_a7 = (int)((1.0 * _vpairnn_14[i].second / nlineCandidateCount) * 100);
		if (n_a7 < 9)
			break;
		int nTmp_v34 = max(3, int(ICS_a5.m_xTLineAnalyzeFirst_0.m_r_2C * n_a6));
		nTmp_v34 = nTmp_v34 + (1 - nTmp_v34 % 2);
		if (nTmp_v19 == nTmp_v34)
			return 0;
		nTmp_v19 = nTmp_v34;
	}
	return 1;
}

int AnalyzeLinesCandidates::findAngleUsingLines(vector<TPointEx>& vParam1, int nParam2, int nParam3, int nParam4, float fParam5, float & fParam6)
{
	fParam6 = 0.0;
	vector<int> vv(20 * nParam2);
	int v34 = 0;
	for (size_t i = 0; i < vParam1.size(); i++)
	{
		for (size_t j = i + 1; j < vParam1.size(); j++)
		{
			int v17 = abs(vParam1[i].nField_0 - vParam1[j].nField_0);
			if (v17 >= nParam3)
			{
				int v20 = max(vParam1[i].nField_C , vParam1[j].nField_C);
				int v21 = abs(vParam1[i].nField_C - vParam1[j].nField_C);
				if ((float)(v21 / v20) <= fParam5)
				{
					CPointF pp(vParam1[i].nField_0, vParam1[i].nField_4);
					CPointF ppp(vParam1[j].nField_0, vParam1[j].nField_4);
					CPointF pTemp;
					float fAngle = pp.getAngle(ppp, pTemp);
					if (fAngle - 360.0f > -fAngle)
						fAngle -= 360.0f;
					if (fabs(fAngle) < nParam2)
					{
						vv[int(fAngle + nParam2) * 10]++;
						v34++;
					}

					pp.fy = (float)vParam1[i].nField_8;
					ppp.fy = (float)vParam1[j].nField_8;
					fAngle = pp.getAngle(ppp, pTemp);
					if (fAngle - 360.0f > -fAngle)
						fAngle -= 360.0f;
					if (fabs(fAngle) < nParam2)
					{
						vv[int(fAngle + nParam2) * 10]++;
						v34++;
					}
				}
			}
		}
	}
	if (v34 >= 10)
	{
		float f = 0.0f;
		RAnalyse::maxAprox(vv, 7, f);
		fParam6 = f / 10.0f - nParam2;
		return false;
	}
	return true;
}


void AnalyzeLinesCandidates::updateProbs(int nParam1, int nParam2, vector<int>& vParam3, multimap<int, int>& mmParam4, vector<float>&vParam5)
{
	vParam5 = vector<float>(vParam3.size(), 0.0);
	vector<int> vKey = common::mapKeys(mmParam4);
	int v10 = (nParam2 - nParam1 <= 1) ? 1 : (nParam2 - nParam1);
	for (size_t i = 0; i < vKey.size(); i++)
	{
		vector<int> vVal = common::mapValues(mmParam4, vKey[i]);
		float v12 = 0.0f;
		for (size_t j = 0; j < vVal.size(); j++)
		{
			int v16 = vVal[j] - nParam2;
			int v17 = (vVal[j] < nParam1) ? (nParam1 - vVal[j]) : 0;
			if (v17 > v16)
				v16 = v17;
			v12 += (float)v16 / v10;
		}
		if (!vVal.empty())
			vParam5[vKey[i]] = (vVal.size() - v12) / vVal.size();
	}
}