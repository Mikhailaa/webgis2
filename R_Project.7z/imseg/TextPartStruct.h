#pragma once
#include "../pch.h"
#include "RecognizedTextDoc.h"
#include "TextPartLCIDInfo.h"
#include "CAlphabetF.h"
#include "SymbolResult.h"
#include "VisualSubField.h"
#include "TextPartStructPosition.h"

class TextPartStruct
{
public:
	TextPartStructPosition m_Position_0;
	CAlphabetF m_xCAlphatF_C;
	int m_nField_30;
	CVisualSubField *m_pCVisualSubField_34;
	bool m_bField_38;
	bool m_bField_39;
	bool m_bField_3A;
	//bool m_bField_3B;
	vector<uchar> m_vucharName_3C;
	vector<uchar> m_vuchar_48;
	vector<pair<int, int>> m_vpairnn_54;
	vector<CSymbolResult> m_vCSymbolResult_60;
	short m_sFieldType_6C;
	bool m_bField_6E;
	bool m_bField_6F;
	TextPartLCIDInfo m_xTextPartLCIDInfo_70;

	TextPartStruct();
	TextPartStruct(TextPartStruct const & a2);
	TextPartStruct(TextPartStruct && a2);
	~TextPartStruct();
	int fieldType();
	int fieldTypeFull();
	wstring getName();
	bool isSpace();
	void reset();
	TextPartStructPosition & position();
	vector<CSymbolResult>& text();

	TextPartStruct& operator=(const TextPartStruct& );
};