#pragma once
#include "imseg_interface.h"

namespace imseg
{
	class PostCorrectorNull : public  ITextLinesVisitor
	{
	public:
		PostCorrectorNull();
		virtual void visit(RichTextLines &);
	};
}