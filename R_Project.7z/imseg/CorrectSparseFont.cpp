#include "CorrectSparseFont.h"

imseg::CorrectSparseFont::CorrectSparseFont(ICorrector *pICorrector)
{
	m_pIC_4 = pICorrector;
}

imseg::CorrectSparseFont::~CorrectSparseFont()
{
}

int imseg::CorrectSparseFont::isFontIsSparse(vector<CTCHypoth>&vCTCHypoth)
{
	if (vCTCHypoth.size() < 5)
		return 0;
	for (size_t i = 0; i < vCTCHypoth.size() - 1; i += 2)
	{
		if (vCTCHypoth[i + 1].getUnicode() != ' ')
			return 0;
	}
	return 1;
}

void imseg::CorrectSparseFont::deleteAllSpaces(vector<CTCHypoth>&vCTCHypoth)
{
	// no check
	for (size_t i = 0; i < vCTCHypoth.size(); i++)
	{
		if (vCTCHypoth[i].getUnicode() == ' ')
		{
			vCTCHypoth.erase(vCTCHypoth.begin() + i);
			i--;
		}
	}
}

void imseg::CorrectSparseFont::process_impl(vector<CTCHypoth>&vCTCHypoth)
{
	if (isFontIsSparse(vCTCHypoth))
		deleteAllSpaces(vCTCHypoth);
}
