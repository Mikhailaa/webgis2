﻿#pragma once
#include "../pch.h"
#include "imsegStruct.h"
#include "FieldParam.h"

class IBaseFontsFilter
{
public:
};

class ISymbolsInfoByUnicode
{
public:
	virtual int type(int) = 0;
	virtual int wType(int) = 0;
	virtual int tailType(int) = 0;
	virtual void getkWHInfo(int, int, SymbolFontParam &) = 0;
};

class IAlphabetInfo
{
public:
	virtual int alphabet(int, vector<int> &) = 0;
	void addNumbers(vector<wchar_t> &);
};

class ISymbolsIndexMap
{
public:
	virtual int index(int) = 0;
};

class ConflictGroups;
class IBaseConflictGroups
{
public:
	virtual ConflictGroups& getConflictGroup(int, int, vector<int> &) = 0;
};

class AlphabetInfo;
class SymbolsInfoByUnicode;
class ISymbolsInfoEx
{
public:
	virtual AlphabetInfo& alphabetInfo() = 0;
	virtual SymbolsInfoByUnicode& symbolsInfo() = 0;
};

class Field;

namespace imseg
{
	class CTCHypoth;
	class ICorrector
	{
	public:
		virtual void process_impl(vector<CTCHypoth> &) = 0;
		void process(vector<CTCHypoth> &);

		ICorrector* m_pIC_4;
	};

	class IFieldMask
	{
	public:
		virtual void setPreviousPath(vector<CTCHypoth> const&) = 0;
		virtual bool isUnicodePossible(uint) = 0;
		virtual int getBeamWidth() = 0;
		virtual bool isAllSymbolsFound(vector<CTCHypoth> const&) = 0;
		virtual bool doNotDeleteSymbolsAfterMe() = 0;
	};

	class IFieldInfo
	{
	public:
		virtual int symbolsTails() = 0; //0x8
		virtual int symbolsType() = 0; //0xC
		virtual FieldParam& param() = 0; //0x10
	};

	class RichTextLines;
	class ITextLinesVisitor
	{
	public:
		virtual void visit(RichTextLines &) = 0;
	};

	class IImgNormalizer : public ITextLinesVisitor
	{
	public:
		static shared_ptr<ITextLinesVisitor> factory(uint const&, uint const&, cv::Size const&);;
	};

	class IPostCorrector : ITextLinesVisitor
	{
	public:
		static shared_ptr<ITextLinesVisitor> factory(FieldParam&);
	};

	class ITextDetector : public ITextLinesVisitor
	{
	public:
		shared_ptr<dnn::Net> m_spNet_4;
		Size m_xSize_C;
		float m_r_14;

	public:
		//virtual void visit(RichTextLines &);
		//~ITextDetector();
		//~ITextDetector();
		virtual Mat resize(Mat&, float&, float&) = 0;
		virtual vector<Rect> postprocDetections(Mat &xMat, vector<Rect>& vRect) = 0;

		RichTextLines detect(RichTextLines& xRichTextLines);

		void accept(ITextLinesVisitor &);
		vector<Rect> detect(Mat& xMat);
		static shared_ptr<ITextDetector> factory(uint un_a1, Size& xSize_a2, shared_ptr<dnn::Net>& spNet_a3);
		void standartizeImg(Mat &xMat);
		void visit(RichTextLines&);
	};

	class IVisitable
	{
	public:
		virtual void accept(ITextLinesVisitor &) = 0;
	};
}

class Text;
class IText
{
public:
	virtual void linesList(vector<Text *> &) = 0;
	virtual void linesList(vector<pair<Text *, Field *>> &) = 0;
	virtual void linesListWithText(vector<Text *> &) = 0;
};

namespace imseg
{
	namespace word_beam_search
	{
		class IMatrix
		{
		public:
			virtual double getAt(uint, uint) const = 0;
			virtual void setAt(uint, uint, double) const = 0;
			virtual int rows(void) const = 0;
			virtual int cols(void) const = 0;
		};
	}
}