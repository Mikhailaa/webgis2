#pragma once
#include "../pch.h"

class TextPartLCIDInfo
{
public:
	int m_nTPLCIDI_0;
	vector<int> m_vLcids_4;

public:
	TextPartLCIDInfo();
	TextPartLCIDInfo(TextPartLCIDInfo const&);
	TextPartLCIDInfo(TextPartLCIDInfo &&);
	~TextPartLCIDInfo();
	void addLcid(int);
	void init(string&);
	//bool isLcidInit(); no xref
	int lcid();
	vector<int> &lcids();
	TextPartLCIDInfo& operator=(TextPartLCIDInfo const&);
	void setAsMainLcid(int);
};