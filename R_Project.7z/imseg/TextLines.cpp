﻿#include "TextLines.h"
#include "rcvmat.h"
#include "Rect.h"
#include "RCv.h"

namespace imseg
{
	TextLines::TextLines()
	{
	}
	TextLines::TextLines(TextLines const&arg1)
	{
		m_xMat_4 = arg1.m_xMat_4;
		m_vRect_3C.assign(arg1.m_vRect_3C.begin(), arg1.m_vRect_3C.end());
		m_vvvSymCandidatWR_48.assign(arg1.m_vvvSymCandidatWR_48.begin(), arg1.m_vvvSymCandidatWR_48.end());
	}
	TextLines::TextLines(Field &x_Field_a2)
	{
		int nLeft, nTop, nRight, nBottom;
		Mat xImage = RCvMat::ref(x_Field_a2.m_xFieldImages_20.m_vCBufImg_20[0]);
		//flip하기전 화상은 찌그러졌는데 한다음에는 바로 되였다.왜?
		flip(xImage, m_xMat_4, 0);
		for (uint i = 0; i < x_Field_a2.m_vText_4C.size(); i++)
		{
			CRect rect(x_Field_a2.m_vText_4C[i].m_vimsegSymbol_0[0].m_xRECT_0);
			rect.reverseHeight(*xImage.size.p);
			nLeft = rect.left();
			nTop = rect.top();
			nRight = rect.right();
			nBottom = rect.bottom();
			m_vRect_3C.push_back(cv::Rect(Point(nLeft, nTop), Point(nRight, nBottom)));
		}
	}
	TextLines::~TextLines()
	{
	}
	float TextLines::calcMinProb()
	{
		float _minProb = 100;
		if (m_vvvSymCandidatWR_48.empty())
			return 0.0f;
		vector<vector<vector<SymbolCandidatWithRect>>>::iterator iter;
		vector<vector<SymbolCandidatWithRect>>::iterator iter1;
		vector<SymbolCandidatWithRect>::iterator iter2;

		for (iter = m_vvvSymCandidatWR_48.begin(); iter != m_vvvSymCandidatWR_48.end(); iter++)
		{
			for (iter1 = (*iter).begin(); iter1 != (*iter).end(); iter1++)
			{
				if (!(*iter1).empty())
				{
					iter2 = (*iter1).begin();
					if ((*iter2).m_xSymCandidat_0.m_rProv_4 < _minProb)
						_minProb = (*iter2).m_xSymCandidat_0.m_rProv_4;
				}
			}
		}
		return _minProb;
	}
	float TextLines::calcAvgProb()
	{
		float _sum = 0;
		int _cnt = 0;
		if (m_vvvSymCandidatWR_48.empty())
			return 0.0f;
		vector<vector<vector<SymbolCandidatWithRect>>>::iterator iter;
		vector<vector<SymbolCandidatWithRect>>::iterator iter1;
		vector<SymbolCandidatWithRect>::iterator iter2;

		for (iter = m_vvvSymCandidatWR_48.begin(); iter != m_vvvSymCandidatWR_48.end(); iter++)
		{
			for (iter1 = (*iter).begin(); iter1 != (*iter).end(); iter1++)
			{
				if (!(*iter1).empty())
				{
					iter2 = (*iter1).begin();
					_sum += (*iter2).m_xSymCandidat_0.m_rProv_4;
					_cnt++;
				}
			}
		}
		return _sum / _cnt;
	}
	vector<vector<vector<SymbolCandidatWithRect>>>& TextLines::getResults()
	{
		return m_vvvSymCandidatWR_48;
	}
	int TextLines::getLinesCount()
	{
		return m_vRect_3C.size();
	}
	int TextLines::getImgHeight()
	{
		return m_xMat_4.rows;
	}
	TextLines TextLines::operator=(TextLines const&arg1)
	{
		if (this == &arg1)
			return *this;
		m_xMat_4 = arg1.m_xMat_4;
		m_vRect_3C.assign(arg1.m_vRect_3C.begin(), arg1.m_vRect_3C.end());
		m_vvvSymCandidatWR_48.assign(arg1.m_vvvSymCandidatWR_48.begin(), arg1.m_vvvSymCandidatWR_48.end());
		return *this;
	}
	void TextLines::pushBackResults(vector<vector<SymbolCandidatWithRect>>&arg1)
	{
		m_vvvSymCandidatWR_48.push_back(arg1);
	}
}
