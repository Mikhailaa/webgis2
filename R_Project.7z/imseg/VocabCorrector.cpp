#include "VocabCorrector.h"

namespace imseg {
	VocabCorrector::VocabCorrector(VocabInfo& xVocabInfo, ICorrector*pICorrector)
		: m_xVocabInfo_8(xVocabInfo)
	{
		m_pIC_4 = pICorrector;
		ConfusedPair xConfusedPair_4;
		xConfusedPair_4.m_nField_0 = 1049;
		xConfusedPair_4.m_nField_4 = 1048;
		m_map_unvConfusedPair_18[1049].assign(1, xConfusedPair_4);
	}

	VocabCorrector::~VocabCorrector()
	{
	}

	bool VocabCorrector::isPresentInVocabulary(vector<CTCHypoth>&vCTCHypoth)//PKS
	{
		set<uint> _setun_24;
		_setun_24.emplace((uint)' ');
		_setun_24.emplace((uint)'.');
		CTCHypoth _xCTCHypoth_4C;
		int nUnicode;
		wstring _ws_30;
		vector<wstring> _vws_40;
		for (size_t i = 0; i < vCTCHypoth.size(); i++)
		{
			_xCTCHypoth_4C = CTCHypoth(vCTCHypoth[i]);
			nUnicode = _xCTCHypoth_4C.getUnicode();
			if (nUnicode == 0x10FFFF) continue;
			if (_setun_24.end() == _setun_24.find(nUnicode))
			{
				_ws_30.push_back(nUnicode);
				continue;
			}
			if (_ws_30.size() >= 3)
				_vws_40.push_back(_ws_30);
			_ws_30 = L"";
		}
		_vws_40.push_back(_ws_30);
		return 1;
	}

	void VocabCorrector::process_impl(vector<CTCHypoth>&vCTCHypoth)
	{
		map<uint, vector<ConfusedPair>>::iterator iter = m_map_unvConfusedPair_18.find(m_xVocabInfo_8.nCount_0);
		if (iter != m_map_unvConfusedPair_18.end())
			isPresentInVocabulary(vCTCHypoth);
	}
}

