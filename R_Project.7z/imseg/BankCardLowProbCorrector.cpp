#include "BankCardLowProbCorrector.h"

imseg::BankCardLowProbCorrector::BankCardLowProbCorrector(float r_a1, ICorrector *pICorrector)
{
	m_pIC_4 = pICorrector;
	m_rBankCardLowProbCorrector_8 = r_a1;
}

imseg::BankCardLowProbCorrector::~BankCardLowProbCorrector()
{
}

void imseg::BankCardLowProbCorrector::process_impl(vector<CTCHypoth>&vCTCHypoth)
{

	if (!vCTCHypoth.empty())
	{
		float m_rSum = 0.0f;
		for (size_t i = 0; i < vCTCHypoth.size(); i++)
			m_rSum += vCTCHypoth[i].m_fHandmade_14;
		m_rSum /= vCTCHypoth.size();
		if (m_rSum < m_rBankCardLowProbCorrector_8)
		{
			for (size_t i = 0; i < vCTCHypoth.size(); i++)
				vCTCHypoth[i].m_lstImCTCHy_18.clear();
			vCTCHypoth.clear();
		}
	}
}
