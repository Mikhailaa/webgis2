#pragma once
#include "../pch.h"
#include "Layer.h"
#include "common/resources.h"
#include "common/container/container.h"
#include "common/container/RclHolder.h"
#include "Json/Value.h"

#include "imseg_rect.h"

using namespace common::resources;
using namespace common::container;

namespace imseg
{
	namespace analyzelines
	{
		class TDetectedField
		{
		public:
			int field_0;
			tagRECT m_xtagRECT_4;
			vector<tagRECT> m_vtRECT_14;

			TDetectedField();
			TDetectedField(TDetectedField const&);
			TDetectedField(TDetectedField const&&);
			TDetectedField &operator=(TDetectedField &);
			TDetectedField &operator=(TDetectedField &&);
		};

		
		tagRECT CvRecttoRECT(cv::Rect const&);
		void layerToCoordinates(Layer_R &, float, vector<TDetectedField> &);
		cv::Rect preprocessLineCoordinates(cv::Rect &, tagRECT &, float, int);
		cv::Rect RECTtoCvRect(tagRECT const&);
		void rotateCoordinates(tagRECT, float, tagRECT &);
		tagRECT shiftLeftTopCoordinate(tagRECT, tagRECT);
		

	}
}