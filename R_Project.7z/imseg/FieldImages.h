#pragma once
#include "../pch.h"
#include "ImageControl.h"

class FieldImages
{
public:
	cv::Rect m_xRect_0;
	cv::Rect m_xRect_10;
	vector<CBufferImage> m_vCBufImg_20;

	FieldImages();
	FieldImages(FieldImages const &);
	~FieldImages();
	FieldImages operator=(FieldImages const &);
};
