#include "SymbolCandidatWithRect.h"

SymbolCandidatWithRect::SymbolCandidatWithRect()
{
}

SymbolCandidatWithRect::SymbolCandidatWithRect(SymbolCandidat const &xSymbolCandiate, cv::Rect const &xRect):
	m_xSymCandidat_0(xSymbolCandiate),
	m_xRect_14(xRect)
{
}

SymbolCandidatWithRect::SymbolCandidatWithRect(SymbolCandidatWithRect const & a2) :
	m_xSymCandidat_0(a2.m_xSymCandidat_0),
	m_xRect_14(a2.m_xRect_14)
{
}

SymbolCandidatWithRect::SymbolCandidatWithRect(SymbolCandidatWithRect && a2) :
	m_xSymCandidat_0(a2.m_xSymCandidat_0),
	m_xRect_14(a2.m_xRect_14)
{
}

SymbolCandidatWithRect::~SymbolCandidatWithRect()
{
}

SymbolCandidatWithRect & SymbolCandidatWithRect::operator=(SymbolCandidatWithRect &arg1)
{
	m_xSymCandidat_0 = arg1.m_xSymCandidat_0;
	m_xRect_14 = arg1.m_xRect_14;

	return *this;
}

SymbolCandidatWithRect & SymbolCandidatWithRect::operator=(SymbolCandidatWithRect && a2)
{
	m_xSymCandidat_0 = a2.m_xSymCandidat_0;
	m_xRect_14 = a2.m_xRect_14;
	return *this;
}