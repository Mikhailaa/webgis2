#pragma once
#include "pch.h"

class HParamPool
{
public:
	static float get(string const&, int);

	static int m_arbitraryLCID;
	static map<string, map<int, double>> m_nameToValue;
};

class HParam
{
public:
	HParam(float&,string&, int);
};

