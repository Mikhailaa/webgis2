#pragma once
#include "imseg_interface.h"
#include "SymbolCandidate.h"
#include "commonStruct.h"
#include "SymbolResult.h"
#include "BaseLines.h"

class Semantics
{
public:
	enum eLetterType
	{
		eLetterType_0 = 0,
		eLetterType_1 = 1,
		eLetterType_2 = 2,
		eLetterType_3 = 3,
		eLetterType_4 = 4,
		eLetterType_5 = 5,
		eLetterType_6 = 6,
		eLetterType_7 = 7,
		eLetterType_8 = 8
	};

	static bool candidatesContainString(CSymbolCandidate *, int, int, vector<uint>);
	static void caseTypeCandidats(ISymbolsInfoByUnicode &, CSymbolCandidate *, int, int &, int &, int &, int &, vector<Semantics::eLetterType> &);
	static void changeUnicodesWordByWord(map<pair<int, int>, int> &, map<int, vector<wchar_t>> const&, vector<vector<wchar_t>> const&, vector<int> &);
	static bool checkIfSymbolIsUnique(int, map<int, set<uint>> const&, int);
	static void convertToBigSmallLetters(ISymbolsInfoByUnicode &, CSymbolResult *, int, int, BaseLines &, bool);
	static void convertToNumber(ISymbolsInfoByUnicode &, eSymbolType, CSymbolResult *, int);
	static void convertToText(ISymbolsInfoByUnicode &, eSymbolType, CSymbolResult *, int, int, BaseLines &, bool);
	static bool correctCaseTypeForCandidates(Semantics::eLetterType, vector<Semantics::eLetterType> &, int &, int &);
	static void copyCasesForUnknown(vector<Semantics::eLetterType> &, vector<Semantics::eLetterType> &, int &, int &, int &);
	static void correctImpossibleLetters(ISymbolsInfoByUnicode &, CSymbolResult *, int, int, int);
	static void correctMixedLcids(vector<vector<wchar_t>> &, map<int, vector<wchar_t>> &, int, map<int, set<uint>> &, vector<int> &);
	static void correctWord(ISymbolsInfoByUnicode &, CSymbolResult *, int, int, eSymbolType, vector<int> &, int, int, BaseLines &, eWordType &, bool);
	static void fillSymbolsVector(vector<CSymbolResult> &, vector<vector<wchar_t>> &);
	static void getCaseType(ISymbolsInfoByUnicode &, CSymbolResult*, int, int, int, BaseLines &, vector<eLetterType> &, vector<eLetterType> &, bool);
	static void getCaseTypeByLines(int, int, int, eLetterType &);
	static int getLcidForUnicode(int a1, map<int, vector<wchar_t>> const& a2);
	static void getWordType(ISymbolsInfoByUnicode &, CSymbolResult *, int, int, int, eWordType &);
	static wstring reverseRightToLeftText(wstring &, vector<int> &);
	static void splitTextInWordsWithLcid(int const& a1, vector<vector<wchar_t>> const& a2, map<int, vector<wchar_t>> const& a3, map<int, set<uint>> const& a4, map<pair<int, int>, int> & a5);
	static void swapPosSymbol(ISymbolsInfoByUnicode &, CSymbolCandidate *, int, eWordType);
};