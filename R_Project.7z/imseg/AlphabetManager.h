#pragma once
#include "AlphabetContainer.h"
#include "Alphabet.h"

class CAlphabetManager
{
public:
	//static bool check(int , char); no xref
	static vector<int> convert(CAlphabet *, int);
	static void convert(CAlphabet *, vector<int> &);
	static void convert(CAlphabetContainer &, CAlphabet *);
	static void updatePartsStatus(CAlphabet *, vector<uchar> &);
};