#include "imseg_interface.h"

namespace imseg
{
	class FieldMaskLogicalOr : public IFieldMask
	{
	public:
		shared_ptr<IFieldMask> m_spIFieldMask_4;
		shared_ptr<IFieldMask> m_spIFieldMask_C;
		
	//	FieldMaskLogicalOr();
		FieldMaskLogicalOr(shared_ptr<IFieldMask> &, shared_ptr<IFieldMask> &);
		virtual void setPreviousPath(vector<CTCHypoth> const&);
		virtual bool isUnicodePossible(uint);
		virtual int getBeamWidth();
		virtual bool isAllSymbolsFound(vector<CTCHypoth> const&);
		virtual bool doNotDeleteSymbolsAfterMe();
	};
}