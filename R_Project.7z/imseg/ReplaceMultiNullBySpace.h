#pragma once
#include "imseg_interface.h"
#include "imseg/CTCHypoth.h"

namespace imseg
{
	class ReplaceMultiNullBySpace : public ICorrector
	{
	public:
		int m_nReplaceMultiNullBySpace_8;
		float m_rReplaceMultiNullBySpace_C;
		float m_rReplaceMultiNullBySpace_10;

		ReplaceMultiNullBySpace(int, ICorrector*);
		~ReplaceMultiNullBySpace();
		void calcDistsBtwSymbols(vector<CTCHypoth>&, float&, float&);
		virtual void process_impl(vector<CTCHypoth> &);
	};
}