#include "LCIDPriority.h"

using namespace imseg;

uint LCIDPriority::getTopPriorityLCID(set<uint> const &set_a2)
{
	if (set_a2.size())
	{
		for (uint i = 0; i < m_vunLCIDP_0.size(); i++)
		{
			if (set_a2.find(m_vunLCIDP_0[i]) != set_a2.end())
				return m_vunLCIDP_0[i];
		}
	}
	return 0;
}

void LCIDPriority::push_front(LCIDPriority const &arg1)
{
	m_vunLCIDP_0.insert(m_vunLCIDP_0.begin(), arg1.m_vunLCIDP_0.begin(), arg1.m_vunLCIDP_0.end());
}
