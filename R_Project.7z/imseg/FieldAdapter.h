#pragma once
#include "../pch.h"

#include "common/resources.h"
#include "common/container/container.h"
#include "common/container/RclHolder.h"
#include "Json/Value.h"
#include "Field.h"
#include "RecognizedTextDoc.h"
#include "TextPartStruct.h"


using namespace common::resources;
using namespace common::container;

namespace imseg
{
	class FieldAdapter
	{
	public:		
		FieldAdapter(Field *);
		~FieldAdapter();
		int getLogiclOrPartsCount();
		bool isInformative(TextPartStruct &);
		vector<vector<TextPartStruct>> getStrings(uint, uint);

		Field * m_pField_0;
	};
}