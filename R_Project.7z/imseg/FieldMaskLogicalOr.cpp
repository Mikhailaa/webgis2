#include "FieldMaskLogicalOr.h"

namespace imseg
{
	//FieldMaskLogicalOr::FieldMaskLogicalOr()
	//{
	//}

	FieldMaskLogicalOr::FieldMaskLogicalOr(shared_ptr<IFieldMask>&arg1, shared_ptr<IFieldMask>&arg2)
		:m_spIFieldMask_4(arg1)
		, m_spIFieldMask_C(arg2)
	{
	}
	void FieldMaskLogicalOr::setPreviousPath(vector<CTCHypoth> const &vCTCHypoth)
	{
		m_spIFieldMask_4.get()->setPreviousPath(vCTCHypoth);
		m_spIFieldMask_C.get()->setPreviousPath(vCTCHypoth);
	}
	bool FieldMaskLogicalOr::isUnicodePossible(uint nUnicode)
	{
		if (m_spIFieldMask_4.get()->isUnicodePossible(nUnicode))
			return 1;
		else
			return m_spIFieldMask_C.get()->isUnicodePossible(nUnicode);
	}
	int FieldMaskLogicalOr::getBeamWidth()
	{
		int v2 = m_spIFieldMask_4.get()->getBeamWidth();
		int v3 = m_spIFieldMask_4.get()->getBeamWidth();
		return MAX(v2, v3);
	}
	bool FieldMaskLogicalOr::isAllSymbolsFound(vector<CTCHypoth> const &vCTCHypoth)
	{
		if (m_spIFieldMask_4.get()->isAllSymbolsFound(vCTCHypoth))
			return 1;
		else
			return m_spIFieldMask_C.get()->isAllSymbolsFound(vCTCHypoth);
	}
	bool FieldMaskLogicalOr::doNotDeleteSymbolsAfterMe()
	{
		if (m_spIFieldMask_4.get()->doNotDeleteSymbolsAfterMe())
			return 1;
		else
			return m_spIFieldMask_C.get()->doNotDeleteSymbolsAfterMe();
	}
}