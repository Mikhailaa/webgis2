#pragma once
#include <sstream>
#include "../pch.h"
#include "common/resources.h"
#include "common/container/container.h"
#include "common/container/RclHolder.h"
#include "Json/Value.h"

#include "parameters.h"
#include "FacadeDNNOCR.h"
#include "InitConstStructs.h"
#include "Symbols.h"
#include "legacycommonlib.h"
#include "ListSubField.h"

using namespace common;
using namespace common::resources;
using namespace common::container;

class ImSegStatic
{
public:
	InitConstStructs m_xInitConstStructs_0;
	Symbols m_xSymbols_4C;
	SymbolInfoEx m_xSymbolInfoEx_C4;
	int field_CC;
	int field_D0;
	int field_D4;
	bool m_bField_D8;//byte
	int m_nBestSymbolH_DC;//byte
	fs::Path m_fsTmpPath_E0;
	int m_nSaveDebugInfo_F8;
	string m_s_FC; //"ImSeg.ini"
	istringstream m_xistrstream_108; //DNNOCR.dat
	istringstream m_xistrstream_194; //DNNOCRCN.dat
	istringstream m_xistrstream_220; //DNNOCRAS.dat
	istringstream m_xistrstream_2AC; //DNNOCRAR.dat
	istringstream m_xistrstream_338; //DNNOCRBC.dat
	int field_3C4;//byte
	vector<int> m_vn_3C8;
	FacadeDNNOCR m_xFacadeDNNOCR_3D4;
	bool m_bSaveFieldWithRandomNameInTmpFolder_3F8;//byte
	int field_3FC;
	Json::Value m_jsUnicodeSettings_400;
	Json::Value m_jsLCIDs_418;
	int field_430;
	legacycommonlib::FieldsLoadFilter m_xFieldsLoadFilter_434;
	int field_454;
	ImSegStatic();
	~ImSegStatic();

	int init();
	void initSubFields(ListSubField&);
	int initSubFieldsBin(vector<uchar>&);
	int initSubFieldsJson(string&);
	bool loadDNN(istringstream &);
	static void unload();
	static ImSegStatic *imsegStatic(bool);
	static ImSegStatic *obj();
	void reset();
};

