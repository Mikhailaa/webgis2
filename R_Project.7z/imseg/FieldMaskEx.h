#pragma once
#include "pch.h"

class FieldMaskEx
{
public:
	static void convertStaticToSubFields(string, string&);
	static string convertToSimpleSubFields(string);
};