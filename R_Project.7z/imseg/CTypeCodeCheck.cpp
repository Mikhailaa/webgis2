#include "CTypeCodeCheck.h"
namespace reader1D
{
	namespace CTypeCodeCheck
	{
		int getTypeCode3(cv::Mat &)
		{
			return 0;
		}
	}
}