#pragma once
#include "../pch.h"
#include "common/resources.h"
#include "common/container/container.h"
#include "common/container/RclHolder.h"
#include "SymbolCandidatWithRect.h"
#include "RecognizedTextDoc.h"
#include "Json/Value.h"
#include "commonStruct.h"

#include "FieldAdapter.h"
#include "TextPartStruct.h"
#include "CharPlace.h"

using namespace common;
using namespace common::resources;
using namespace common::container;
using namespace imseg;

namespace imseg
{	
	class TTAParams
	{
	public:
		float m_TTAParams_0;
		float m_TTAParams_4;
		float m_TTAParams_8;
	public:
		void augment(Rect&);
	};

	class CTCHypoth;
	vector<vector<vector<TextPartStruct>>> processMultistringness(Field &, uint);
	int alignStrings(string const&, string const&, vector<int> &);
	int alignStrings(wstring const&, wstring const&, vector<int> &);
	eProcessOptions convertProcessOption(string const&);
	bool operator==(CTCHypoth const&, CTCHypoth const&);
	bool operator<(CTCHypoth const&, CTCHypoth const&);
	string toString(vector<vector<vector<SymbolCandidatWithRect>>>&);
	
	namespace bindrects
	{
		vector<cv::Rect> getBindRectsForRemove(RclHolder &);
	}

	class ConfigByLCID
	{
	public:
		static bool isBankCardLcid(int);
	};

	namespace container
	{
		void addString(vector<vector<SymbolCandidatWithRect>>&, Text &, string &, FieldParam &, int, bool);
	}

	namespace docinfo
	{
		eRPRM_Lights getLightType(TVisualField &);
	}

	namespace field
	{
		void getAllFieldInfoVariants(Field &, set<pair<int, int>> &);
		void generateEmptyTextResults(Field &, int, CRecognizedTextDoc &);
	}
};

namespace ImSegNS
{
	namespace Error
	{
		int checkCodeError(int arg1);
	};
};