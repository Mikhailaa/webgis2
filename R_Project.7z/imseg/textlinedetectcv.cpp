#include "textlinedetectcv.h"

namespace imseg
{
	namespace textlinedetectcv
	{
		void detectWords(cv::Mat &Mat_a1, vector<cv::Rect>&vRect_a2)
		{
			Mat _Mat_344, _Mat_2D4, _Mat_30C;
			pyrDown(Mat_a1, _Mat_344);
			float v10 = (float)Mat_a1.rows / (float)_Mat_344.rows;
			if (_Mat_344.flags & 0xFF8)
			{
				cvtColor(_Mat_344, _Mat_2D4, 6);
				_Mat_2D4.copyTo(_Mat_30C);
			}
			else
				_Mat_344.copyTo(_Mat_30C);
			_Mat_2D4 = cv::Mat();
			Mat Mat_29C = getStructuringElement(2, Size(3, 3));
			morphologyEx(_Mat_30C, _Mat_2D4, 4, Mat_29C);
			Mat _Mat_260;
			threshold(_Mat_2D4, _Mat_260, 0, 255, 8);
			Mat_29C = getStructuringElement(0, Size(9, 1));
			Mat _Mat_228;
			morphologyEx(_Mat_260, _Mat_228, 3, Mat_29C);
			MatExpr _MatExpr_110 = cv::Mat::zeros(Size(0, 0), 0);
			Mat _Mat_1F0 = _MatExpr_110;
			vector<vector<Point>> _vvPoint_64;
			vector<Vec<int, 4>> _vVecInt4_58;
			findContours(_Mat_228, _vvPoint_64, _vVecInt4_58, 2, 2);
			v10 = 1.0f * Mat_a1.rows / _Mat_344.rows;
			for (int i = 0; i > -1; i = _vVecInt4_58[i][0])
			{
				Rect _Rect_80 = boundingRect(_vvPoint_64[i]);
				Mat _Mat_D8(_Mat_1F0, _Rect_80);
				Scalar _Scalar_B8;
				_Mat_D8 = _Scalar_B8;
				_Scalar_B8 = Scalar();
				drawContours(_Mat_1F0, _vvPoint_64, i, _Scalar_B8, -1);
				int nTmpNonZeroCnt = countNonZero(_Scalar_B8);
				if (_Rect_80.width >= 9  && _Rect_80.height >= 9 && nTmpNonZeroCnt / (_Rect_80.width * _Rect_80.height) > 0.45)
				{
					Rect RectTmp((int)(v10 * _Rect_80.x), (int)(v10 * _Rect_80.y), (int)(v10 * _Rect_80.width), (int)(v10 * _Rect_80.height));
					vRect_a2.push_back(RectTmp);
				}
			}
		}
		int findLines(cv::Mat &Mat_a1, int n_a2, float r_a3, vector<vector<cv::Rect>>&vvRect_a4)
		{
			for (size_t i = 0; i < vvRect_a4.size(); i++)
				vvRect_a4[i].clear();
			vvRect_a4.clear();
			vector<cv::Rect> _vRect_0, _vRect_C, _vRect_18;
			detectWords(Mat_a1, _vRect_18);
			for (size_t i = 0; i < _vRect_18.size(); i++)
			{
				if ((float)abs(_vRect_18[i].height - n_a2) / (float)n_a2 < r_a3)
					_vRect_C.push_back(_vRect_18[i]);
			}
			if (_vRect_C.empty())
				return 1;
			_vRect_0.push_back(_vRect_C.front());
			for (size_t i = 1; i < _vRect_C.size(); i++)
			{
				if (_vRect_C[i].y + _vRect_C[i].height / 2 > _vRect_C[i - 1].y)
					_vRect_0.push_back(_vRect_C[i]);
				else
				{
					vvRect_a4.push_back(_vRect_0);
					_vRect_0.clear();
					_vRect_0.push_back(_vRect_C[i]);
				}
			}

			if (vvRect_a4.empty())
				vvRect_a4.push_back(_vRect_0);
			return 0;
		}
	}
}