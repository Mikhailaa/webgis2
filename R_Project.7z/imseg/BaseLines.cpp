#include "BaseLines.h"

BaseLines::BaseLines()
{
	for (int i = 0; i < 13; i++)
	{
		m_nField_0[i] = 0x7FFFFFFF;
	}
}

BaseLines::~BaseLines()
{
}

void BaseLines::setLine(eBaseLinePos eBLP_a1, int n_a2)
{
	m_nField_0[eBLP_a1] = n_a2;
}

int BaseLines::line(eBaseLinePos a2)
{
	if (a2 == 2 && m_nField_0[2] == 0x7FFFFFFF)
	{
		if (m_nField_0[10] == 0x7FFFFFFF) return m_nField_0[2];
		return m_nField_0[10];
	}
	else if (a2 == 4 && m_nField_0[4] == 0x7FFFFFFF)
	{
		if (m_nField_0[9] == 0x7FFFFFFF)  m_nField_0[4];
		return m_nField_0[9];
	}

	return m_nField_0[a2];


}
