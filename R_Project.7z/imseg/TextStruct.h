#pragma once
#include "pch.h"
#include "TextPartStruct.h"
#include "CAlphabetF.h"

class TextStruct
{
public:
	vector<TextPartStruct> m_vTextPartStruct_0;
	int field_C;
	vector<uchar> m_vuc_10;
	bool m_bField_1C;
	bool m_bField_1D;
	bool m_bField_1E;
	bool m_bField_1F;
	vector<uchar> m_vuc_20;
	int m_nLineCount_2C;
	CAlphabetF m_xCAlphaF_30;

	float middleProb();
	bool addPart(TextPartStruct &);
	//int fieldTypeFull();
	TextStruct& operator=(TextStruct const&);
	TextStruct& operator=(TextStruct &&);
	bool setPart(int, vector<uchar> &);

	TextStruct();
	TextStruct(TextStruct const&);
	~TextStruct();
};

namespace SymbolConflictAnalize
{
	void resolveField(TextStruct&);
};

namespace LettersFilter
{
	void filterByLongSpace(TextStruct &, int, int);
};