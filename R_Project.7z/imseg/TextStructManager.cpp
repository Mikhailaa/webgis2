#include "TextStructManager.h"
#include "common/resources.h"
#include "common/common.h"
#include "imseg.h"
#include "common/StringUtils.h"
#include "AlphabetManager.h"
#include "SymbolsFilter.h"
#include "AlphabetFilter.h"
#include "common/UnicodeUtils.h"
#include "ImSegStatic.h"
#include "Semantics.h"
#include "VisualSubFieldEx.h"
#include <algorithm>
#include "RecognizedTextDoc.h"
#include "VisualField.h"
#include "TextPartStruct.h"

bool checkSubField(int a1, TextStruct &a2, Text &a3, int a4)
{
	vector<int> vint_30(a2.m_vTextPartStruct_0[a1].m_xCAlphatF_C.m_vAlphabet_0), vint_48;
	set<int> sint_3c, sint_54;
	for (size_t i = 0; i < vint_30.size(); i++)
		sint_3c.insert(sint_3c.end(), vint_30[i]);

	vint_48 = a3.m_vimsegSymbol_0[a4].m_xRecRes2_18.candidates(0.1f);

	for (size_t i = 0; i < vint_48.size(); i++)
		sint_54.insert(sint_54.end(), vint_48[i]);

	vector<int> vint_60(sint_3c.size());
	vector<int>::iterator iter = set_intersection(sint_3c.begin(), sint_3c.end(), sint_54.begin(), sint_54.end(), vint_60.begin());
	vint_60.erase(iter, vint_60.end());
	return !vint_60.empty();
}

void TextStructManager::getParamFromMask(string &strMask_a1, unordered_map<eProcessOptions, string>& unmapParam_a2)
{
	string strResult;

	unmapParam_a2.clear();

	int nIndex1 = strMask_a1.find("{_@");
	int nIndex2 = strMask_a1.find("@}");

	if (nIndex1 == -1 || nIndex2 == -1) return;

	string strTmp1(strMask_a1.begin() + nIndex1 + 3, strMask_a1.begin() + nIndex2);
	vector<string> vSplittedString = common::StringUtils::Split(strTmp1, ',');
	for (size_t i = 0; i < vSplittedString.size(); i++)
	{
		vector<string> vSplittedString2 = common::StringUtils::Split(vSplittedString[i], '(');
		if (vSplittedString2.size() >= 2)
			strResult = common::StringUtils::Replace(vSplittedString2[1], string(")"), string(""));
		eProcessOptions eProcOption = (eProcessOptions)common::StringUtils::toInt(vSplittedString2[0]);
		if (!eProcOption)
			eProcOption = convertProcessOption(vSplittedString2[0]);
		unmapParam_a2[eProcOption] = strResult;
	}

	strMask_a1.erase(strMask_a1.begin() + nIndex1, strMask_a1.begin() + nIndex2 + 2 - nIndex1);
}

vector<int> TextStructManager::getUnicFieldTypeList(TextStruct &xTextStruct_a1)
{
	vector<int> vnRet_a0;
	size_t j;
	for (size_t i = 0; i < xTextStruct_a1.m_vTextPartStruct_0.size(); i++)
	{
		TextPartStruct xTextStruct_r0 = xTextStruct_a1.m_vTextPartStruct_0[i];
		if (xTextStruct_r0.m_bField_38 && xTextStruct_r0.m_sFieldType_6C)
		{
			vector<uchar> vucharName_r1 = xTextStruct_r0.m_vucharName_3C;
			string strName_30(vucharName_r1.begin(), vucharName_r1.end());
			if (strName_30 == "SPACE") continue;
			int n_r0 = xTextStruct_r0.fieldTypeFull();
			if (n_r0)
			{
				for (j = 0; j < vnRet_a0.size(); j++)
				{
					if (vnRet_a0[j] == n_r0) break;
				}

				if (j == vnRet_a0.size()) vnRet_a0.push_back(n_r0);
			}
		}
	}

	return vnRet_a0;
}


void TextStructManager::initAlphabets(TextStruct &xTextStruct_a1, CVisualField &xFieldParam_a2, ISymbolsInfoEx &ISymbolsInfoEx_a3)
{
	for (size_t i = 0; i < xTextStruct_a1.m_vTextPartStruct_0.size(); i++)
	{
		vector<wchar_t> vwchar_34;
		if (xTextStruct_a1.m_vTextPartStruct_0[i].m_pCVisualSubField_34)
		{
			if (xTextStruct_a1.m_vTextPartStruct_0[i].m_pCVisualSubField_34->m_nTVSF_Count_210)
			{
				CAlphabetManager::convert(xTextStruct_a1.m_vTextPartStruct_0[i].m_pCVisualSubField_34->m_aTVSF_Alphabet_218,
					xTextStruct_a1.m_vTextPartStruct_0[i].m_xCAlphatF_C.m_vAlphabet_0);
			}
			else
			{
				vector<uchar> vuchar_40(4, 0);
				string str_50(xTextStruct_a1.m_vTextPartStruct_0[i].m_pCVisualSubField_34->m_szTVSF_110);
				if (str_50 == "TEXT" || str_50 == "WORD" || str_50 == "STRING" || str_50 == "STRINGS" || str_50 == "s")
				{
					vector<int> vint_90;
					CAlphabetManager::updatePartsStatus((CAlphabet*)xFieldParam_a2.xTVF_Alphabet, vuchar_40);

					vint_90 = CAlphabetManager::convert((CAlphabet*)xFieldParam_a2.xTVF_Alphabet, 3);
					xTextStruct_a1.m_vTextPartStruct_0[i].m_xCAlphatF_C.m_vchar_C.insert(xTextStruct_a1.m_vTextPartStruct_0[i].m_xCAlphatF_C.m_vchar_C.end(),
						vint_90.begin(), vint_90.end());
					if (str_50 != "WORD")
						vwchar_34.push_back(32);
					if (str_50 == "STRINGS")
						vwchar_34.push_back(94);
				}

				vector<int> vint_5c;
				CAlphabetManager::updatePartsStatus(xTextStruct_a1.m_vTextPartStruct_0[i].m_pCVisualSubField_34->m_aTVSF_Alphabet_218, vuchar_40);
				vint_5c = CAlphabetManager::convert((CAlphabet*)xTextStruct_a1.m_vTextPartStruct_0[i].m_pCVisualSubField_34->m_aTVSF_Alphabet_218, 3);
				xTextStruct_a1.m_vTextPartStruct_0[i].m_xCAlphatF_C.m_vchar_C.insert(
					xTextStruct_a1.m_vTextPartStruct_0[i].m_xCAlphatF_C.m_vchar_C.end(), vint_5c.begin(), vint_5c.end());
				vwchar_34.insert(vwchar_34.end(), xTextStruct_a1.m_vTextPartStruct_0[i].m_xCAlphatF_C.m_vchar_C.begin(),
					xTextStruct_a1.m_vTextPartStruct_0[i].m_xCAlphatF_C.m_vchar_C.end());

				vector<int> vint_68(xTextStruct_a1.m_vTextPartStruct_0[i].m_xTextPartLCIDInfo_70.m_vLcids_4);
				if (vint_68.empty())
					vint_68.push_back(0);

				int v31 = vuchar_40[1];
				int v32 = vuchar_40[2];
				int nFlags = (vuchar_40[0] & 1) | ((-v31) & 2) | ((-v32) & 4);

				for (size_t j = 0; j < vint_68.size(); j++)
				{
					vector<int> vint_74;
					vector<int> vint_80;
					AlphabetInfo alphabetInfo = ISymbolsInfoEx_a3.alphabetInfo();
					alphabetInfo.alphabet(vint_68[j],vint_74);
					SymbolsFilter::filterByType(ISymbolsInfoEx_a3.symbolsInfo(), vint_74, (eSymbolWidth)nFlags, vint_80);
					vector<wchar_t> vwchar_9c(vint_80.begin(), vint_80.end());
					xTextStruct_a1.m_vTextPartStruct_0[i].m_xCAlphatF_C.m_map_vchar_18.insert(pair<int, vector<wchar_t>>(vint_68[j], vwchar_9c));
					vwchar_34.insert(vwchar_34.end(), vint_80.begin(), vint_80.end());
				}

				if ((-vuchar_40[2]) & 4)
					ISymbolsInfoEx_a3.alphabetInfo().addNumbers(vwchar_34);

				xTextStruct_a1.m_vTextPartStruct_0[i].m_xCAlphatF_C.m_vAlphabet_0 = vector<int>(vwchar_34.begin(), vwchar_34.end());
			}
		}
		else
		{
			set<int> vintset;
			for (size_t j = 0; j < xTextStruct_a1.m_vTextPartStruct_0[i].m_vucharName_3C.size(); j++)
			{
				if (xTextStruct_a1.m_vTextPartStruct_0[i].m_vucharName_3C[j] != 32)
					vintset.insert(xTextStruct_a1.m_vTextPartStruct_0[i].m_vucharName_3C[j]);
			}

			vwchar_34 = vector<wchar_t>(vintset.begin(), vintset.end());;
			xTextStruct_a1.m_vTextPartStruct_0[i].m_xCAlphatF_C.m_vAlphabet_0 = vector<int>(vwchar_34.begin(), vwchar_34.end());
		}

		xTextStruct_a1.m_xCAlphaF_30.m_vAlphabet_0.insert(
			xTextStruct_a1.m_xCAlphaF_30.m_vAlphabet_0.end(),
			xTextStruct_a1.m_vTextPartStruct_0[i].m_xCAlphatF_C.m_vAlphabet_0.begin(),
			xTextStruct_a1.m_vTextPartStruct_0[i].m_xCAlphatF_C.m_vAlphabet_0.end());
	}
}




bool TextStructManager::isFix(TextStruct & TextStruct_a1, vector<uchar> & vuchar_a2, bool b_a3)
{
	for (size_t i = 0; i < TextStruct_a1.m_vTextPartStruct_0.size(); i++)
	{
		string str_30;
		string::iterator vchar_iter;

		if (TextStruct_a1.m_vTextPartStruct_0[i].m_bField_3A)
		{
			vuchar_a2.clear();
			return true;
		}

		if (TextStruct_a1.m_vTextPartStruct_0[i].m_pCVisualSubField_34)
		{
			str_30 = string(TextStruct_a1.m_vTextPartStruct_0[i].m_pCVisualSubField_34->m_szTVSF_110,
				strlen(TextStruct_a1.m_vTextPartStruct_0[i].m_pCVisualSubField_34->m_szTVSF_110));
			vector<uchar> tmp = vuchar_a2;
			tmp.insert(tmp.end(), str_30.begin(), str_30.end());
			vuchar_a2 = tmp;
			//vuchar_a2.insert(vuchar_a2.end(),str_30.begin(), str_30.end());
		}
		else
		{
			vector<uchar> vuchar_3c(TextStruct_a1.m_vTextPartStruct_0[i].m_vucharName_3C.begin(),
				TextStruct_a1.m_vTextPartStruct_0[i].m_vucharName_3C.end());
			vchar_iter = remove(str_30.begin(), str_30.end(), 32);
			str_30.erase(vchar_iter);
			vuchar_3c = vector<uchar>(str_30.begin(), str_30.end());

			if (b_a3)
			{
				for (size_t j = 0; j < vuchar_3c.size(); j++)
				{
					uchar nMask_3d = CAlphabetFilter::mask(vuchar_3c[j]);
					vuchar_a2.push_back(nMask_3d);
				}
			}
			else
				vuchar_a2.insert(vuchar_a2.end(), vuchar_3c.begin(), vuchar_3c.end());
		}
	}

	return false;
}

bool TextStructManager::isStructureReady(TextStruct & TextStruct_a1)
{
	for (size_t i = 0; i < TextStruct_a1.m_vTextPartStruct_0.size(); i++)
	{
		if (!TextStruct_a1.m_vTextPartStruct_0[i].m_Position_0.m_nStatus_0 && TextStruct_a1.m_vTextPartStruct_0[i].m_bField_38)
			return false;
	}

	return true;
}

void TextStructManager::lineCount(TextStruct & TextStruct_a1, int & n_a2)
{
	n_a2 = 1;
	bool bCmp = false;
	for (size_t i = 0; i < TextStruct_a1.m_vTextPartStruct_0.size(); i++)
	{
		if (TextStruct_a1.m_vTextPartStruct_0[i].m_nField_30)
		{
			string str_30(TextStruct_a1.m_vTextPartStruct_0[i].m_pCVisualSubField_34->m_szTVSF_110);
			bCmp = str_30 == "STRINGS";
		}
		else
		{
			for (size_t j = 0; j < TextStruct_a1.m_vTextPartStruct_0[i].m_vucharName_3C.size(); j++)
			{
				if (TextStruct_a1.m_vTextPartStruct_0[i].m_vucharName_3C[j] == '^')//94
				{
					n_a2++;
					break;
				}
			}
		}
	}

	if (bCmp)
		n_a2 = -1;
}

void TextStructManager::maskAnalize(TextStruct &xTextStruct_a0, FieldParam &xFieldParam_a1)
{
	xFieldParam_a1.m_nCount_4 = 0;
	bool b_r2 = false;
	int nCount_r12 = 0;
	for (size_t i = 0; i < xTextStruct_a0.m_vTextPartStruct_0.size(); i++)
	{
		TextPartStruct &xTextStruct_r4 = xTextStruct_a0.m_vTextPartStruct_0[i];
		if (xTextStruct_r4.m_nField_30)
			b_r2 = xTextStruct_r4.m_pCVisualSubField_34->m_sTVSF_fieldType == 106; //106
		for (size_t j = 0; j < xTextStruct_r4.m_vucharName_3C.size(); j++)
		{
			if (xTextStruct_r4.m_vucharName_3C[j] == '/') //47
			{
				xFieldParam_a1.m_nCount_4 = ++nCount_r12;
				break;
			}
		}
	}

	if (!b_r2) xFieldParam_a1.m_nCount_4 = 0;
}

void TextStructManager::numberOfError(TextStruct & TextStruct_a1, int & n_a2, int & n_a3)
{
	n_a2 = 0;
	n_a3 = 0;
	for (size_t i = 0; i < TextStruct_a1.m_vTextPartStruct_0.size(); i++)
	{
		for (size_t j = 0; j < TextStruct_a1.m_vTextPartStruct_0[i].m_vCSymbolResult_60.size(); j++)
		{
			n_a3++;
			if (TextStruct_a1.m_vTextPartStruct_0[i].m_vCSymbolResult_60[j].nTSR_CandidatesCount &&
				TextStruct_a1.m_vTextPartStruct_0[i].m_vCSymbolResult_60[j].get(0) == 42)
				n_a2++;
		}
	}
}

void TextStructManager::postProcessing(CRecognizedTextFieldSDK &recognizedTextFieldSDK_a0, eTextPostProcessing n_a1)
{
	for (int i = 0; i < recognizedTextFieldSDK_a0.nDVEF_StringsCount; i++)
	{
		for (size_t j = 0; j < recognizedTextFieldSDK_a0.pDVEF_StringsResult[i].nTSRS_SymbolsCount; j++)
		{
			for (size_t k = 0; k < recognizedTextFieldSDK_a0.pDVEF_StringsResult[i].pTSRS_StringResult[j].nTSR_CandidatesCount; k++)
			{
				int nCode_r5 = recognizedTextFieldSDK_a0.pDVEF_StringsResult[i].pTSRS_StringResult[j].xnTSR_Candidates[k].nTSC_SymbolCode;
				int n_r0;
				int nLcid = recognizedTextFieldSDK_a0.getLCID();


				switch (n_a1)
				{
				case eTextPostProcessing_3:
				{
					if (j)
					{
						nCode_r5 = recognizedTextFieldSDK_a0.pDVEF_StringsResult[i].pTSRS_StringResult[j - 1].xnTSR_Candidates[0].nTSC_SymbolCode;
						wstring wstrSpace_30(L" ");
						if (wstrSpace_30.find(nCode_r5, 0) == -1)
							n_r0 = common::unicode_convert::toLower(nCode_r5);
						else
							n_r0 = common::unicode_convert::toUpper(nCode_r5);
					}
					break;
				}
				case eTextPostProcessing_2:
				{
					n_r0 = common::unicode_convert::toLower(nCode_r5);
					break;
				}
				case eTextPostProcessing_1:
					n_r0 = common::unicode_convert::toUpper(nCode_r5);
					break;
				default:
					break;
				}

				recognizedTextFieldSDK_a0.pDVEF_StringsResult[i].pTSRS_StringResult[j].xnTSR_Candidates[k].nTSC_SymbolCode;
			}
		}
	}
}

void TextStructManager::splitByContent2(TextStruct & TextStruct_a1, Text & Text_a2)
{
	vector<pair<int, int>> vpair_20;
	bool b_21 = false;
	splitByContentR(TextStruct_a1, Text_a2, 0, vpair_20, b_21);
	if (b_21)
	{
		for (uint i = 0; i < TextStruct_a1.m_vTextPartStruct_0.size(); i++)
		{
			TextStruct_a1.m_vTextPartStruct_0[i].m_Position_0.m_nStatus_0 = 1;
			TextStruct_a1.m_vTextPartStruct_0[i].m_Position_0.m_nStartPos_4 = vpair_20[i].first;
			TextStruct_a1.m_vTextPartStruct_0[i].m_Position_0.m_nEndPos_8 = vpair_20[i].second;
		}
	}
}

void TextStructManager::splitByContentR(TextStruct & TextStruct_a1, Text & Text_a2, int n_a3, vector<pair<int, int>>& vpair_a4, bool & b_a5)
{
	int nTemp;
	if (Text_a2.m_vimsegSymbol_0.size() == n_a3)
	{
		if (TextStruct_a1.m_vTextPartStruct_0.size() == vpair_a4.size() + 1)
		{
			if (vpair_a4.empty())
				nTemp = 0;
			else
				nTemp = vpair_a4[vpair_a4.size() - 1].second + 1;

			if (!TextStruct_a1.m_vTextPartStruct_0[vpair_a4.size()].m_bField_3A)
			{
				if (TextStruct_a1.m_vTextPartStruct_0[vpair_a4.size()].m_pCVisualSubField_34)
				{
					int nMin = TextStruct_a1.m_vTextPartStruct_0[vpair_a4.size()].m_pCVisualSubField_34->minLen();
					int nMax = TextStruct_a1.m_vTextPartStruct_0[vpair_a4.size()].m_pCVisualSubField_34->maxLen();
					if (n_a3 - nTemp < nMin || n_a3 - nTemp - 1 >= nMax)
						return;
				}
			}

			vpair_a4.push_back(pair<int, int>(nTemp, n_a3 - 1));
			b_a5 = true;
		}
	}
	else
	{
		int nFlag1, nFlag2, nMin_34, nMax_30;
		if (TextStruct_a1.m_vTextPartStruct_0[vpair_a4.size()].m_bField_3A)
		{
			nFlag1 = 0;
			nFlag2 = 1;
		}
		else
		{
			if (TextStruct_a1.m_vTextPartStruct_0[vpair_a4.size()].m_pCVisualSubField_34)
			{
				nMin_34 = TextStruct_a1.m_vTextPartStruct_0[vpair_a4.size()].m_pCVisualSubField_34->minLen();
				nMax_30 = TextStruct_a1.m_vTextPartStruct_0[vpair_a4.size()].m_pCVisualSubField_34->maxLen();
			}
			else
			{
				nMin_34 = TextStruct_a1.m_vTextPartStruct_0[vpair_a4.size()].m_vucharName_3C.size();
				nMax_30 = TextStruct_a1.m_vTextPartStruct_0[vpair_a4.size()].m_vucharName_3C.size();
			}
			if (vpair_a4.empty())
				nTemp = n_a3 + 1;
			else
				nTemp = n_a3 - vpair_a4[vpair_a4.size() - 1].second;

			nFlag1 = 0;
			nFlag2 = 0;

			if (nTemp <= nMin_34)
				nFlag1 = 1;
			if (nTemp <= nMax_30)
				nFlag2 = 1;
		}

		if (n_a3 < 1 || nFlag1)
		{
			if (!nFlag2)
				return;
		}
		else
		{
			if (vpair_a4.end() - vpair_a4.begin() + 15 >= 0 && vpair_a4.size() + 1 < TextStruct_a1.m_vTextPartStruct_0.size() &&
				checkSubField(vpair_a4.size() + 1, TextStruct_a1, Text_a2, n_a3))
			{
				if (vpair_a4.end() - vpair_a4.begin())
					nTemp = vpair_a4[vpair_a4.size() - 1].second + 1;
				else
					nTemp = 0;
				vpair_a4.push_back(pair<int, int>(nTemp, n_a3 - 1));
				splitByContentR(TextStruct_a1, Text_a2, n_a3 + 1, vpair_a4, b_a5);
				if (b_a5)
					return;
				vpair_a4.erase(vpair_a4.end() - 1);
			}
			if (!nFlag2)
				return;
		}

		if (vpair_a4.end() - vpair_a4.begin() + 7 >= 0)
		{
			if (vpair_a4.size() < TextStruct_a1.m_vTextPartStruct_0.size())
			{
				if (checkSubField(vpair_a4.size(), TextStruct_a1, Text_a2, n_a3))
					splitByContentR(TextStruct_a1, Text_a2, n_a3 + 1, vpair_a4, b_a5);
			}
		}
	}
}


void TextStructManager::splitByNeighbor(TextStruct &xTextStruct_a0, Text &xText_a1, bool b_a2, bool b_a3, bool b_a4)
{
	int n_r2;
	int n_r6;
	int n_r8;
	int b_r12;
	string str_30;
	int n_r4 = 0x7FFFFFFF;

	for (size_t i = 0; i < xTextStruct_a0.m_vTextPartStruct_0.size(); i++)
	{
		TextPartStruct * pTPS = &xTextStruct_a0.m_vTextPartStruct_0[i];
		TextStructManager::updateSpacePosition(xTextStruct_a0);

		if (pTPS->m_Position_0.m_nStatus_0) continue;
		if (b_a3 && pTPS->m_bField_3A) continue;
		else if (pTPS->m_bField_3A)
		{
			n_r6 = -1;
		}
		else
		{
			CVisualSubField *pCVSF = pTPS->m_pCVisualSubField_34;
			if (pCVSF)
			{
				str_30 = string(pCVSF->m_szTVSF_110);
				n_r6 = str_30.size();
			}
			else
			{
				str_30 = string(pTPS->m_vucharName_3C.begin(), pTPS->m_vucharName_3C.end());
				string::iterator iter = remove(str_30.begin(), str_30.end(), ' ');
				str_30.erase(iter, str_30.end());
				n_r6 = str_30.size();
			}
		}

		if (!n_r6) continue;

		n_r8 = n_r4;
		if (i > 0 && (pTPS - 1)->m_Position_0.m_nStatus_0)
		{
			n_r8 = (pTPS - 1)->m_Position_0.m_nStartPos_4 + 1;
		}
		if (i + 1 < xTextStruct_a0.m_vTextPartStruct_0.size() && (pTPS + 1)->m_Position_0.m_nStatus_0)
		{
			n_r2 = (pTPS + 1)->m_Position_0.m_nStartPos_4 - 1;
			if (n_r8 != n_r4 && !pTPS->m_bField_3A && (pTPS + 1)->m_Position_0.m_nStartPos_4 - n_r8 != n_r6) continue;
		}
		else
		{
			if (n_r8 == n_r4)
			{
				b_r12 = true;
				n_r2 = n_r4;
				n_r8 = n_r4;
			}
			else if (pTPS->m_bField_3A)
			{
				b_r12 = true;
				n_r2 = n_r4;
			}
			else
			{
				n_r2 = n_r6 + n_r8 - 1;
				b_r12 = false;
				if (!pTPS->m_bField_3A) n_r8 = 1 - n_r6 + n_r2;
			}

			if (b_a4)
			{
				int n_r29 = n_r8 - 0x7fffffff;
				int b_r8 = (n_r8 == n_r4) ? 1 : 0;
				int b_r9 = b_r8 ? (n_r8 - 0x7fffffff) : 1;
				if (!(~b_r12 & b_r9))
				{
					if (!b_r8) n_r29 = n_r8;
					if (i == 0) n_r8 = n_r29;
					if (i + 1 == xTextStruct_a0.m_vTextPartStruct_0.size())
					{
						if (b_r12) n_r2 = xText_a1.m_vimsegSymbol_0.size() - 1;
					}
					if (!b_r8) b_r8 = n_r2 == n_r4;
					if (b_r8)
					{
						if (n_r8 != n_r4)
						{
							if (!pTPS->m_bField_3A)n_r2 = n_r6 + n_r8 - 1;
							n_r8 = 1 - n_r6 + n_r2;
						}
						else n_r2 = n_r4;
					}
				}
			}
		}
		if (n_r8<0 || n_r8 == n_r4 || n_r2 >= (int)xText_a1.m_vimsegSymbol_0.size()) continue;
		bool b_r10 = false, b_r11 = pTPS->m_bField_39;
		if (n_r2 >= n_r8) b_r10 = true;
		bool b_r13 = b_r10 | b_r11;
		if (b_a2)
		{
			vector<int>  vt_30(pTPS->m_xCAlphatF_C.m_vAlphabet_0);
			set<int> map_60;
			for (uint j = 0; j<vt_30.size(); j++)
			{
				map_60.insert(vt_30[i]);
			}
			n_r4 = 0x7fffffff;
			int n_r40 = n_r8;
			vector<int> vt_54;
			do
			{
				if (n_r40>n_r2) break;
				vector<int> vt_25 = xText_a1.m_vimsegSymbol_0[n_r40].m_xRecRes2_18.candidates(0.8f);
				set<int> map_55;
				for (size_t k = 0; k<vt_25.size(); k++)
				{
					map_55.insert(vt_25[i]);
				}
				vt_54.clear();
				vector<int>::iterator iter = set_intersection(map_60.begin(), map_60.end(), map_55.begin(), map_55.end(), vt_54.begin());
				vt_54.erase(iter, vt_54.end());
				b_r13 &= vt_54.size()>0;
				n_r40++;
			} while (vt_54.size());
		}
		else if (b_r13 || (b_r10 | b_r11))
		{
			pTPS->m_Position_0.m_nStatus_0 = 1;
			i = -1;
			pTPS->m_Position_0.m_nStartPos_4 = n_r8;
			pTPS->m_Position_0.m_nEndPos_8 = n_r2;
		}
	}
}


bool TextStructManager::splitBySpaceAttempt(vector<CSymbolResult>& vCSymbolResult_a1, TextPartStruct & TextPartStruct_a2,
	int & n_a3, int & n_a4, int n_a5, int n_a6, bool b_a7)
{
	bool bRet;
	if (b_a7)
	{
		int nSymbolCode = vCSymbolResult_a1[n_a3].get(0);
		if (nSymbolCode == ' ')
		{
			n_a4 = n_a3 + 1;
			bRet = true;
		}
		else
		{
			bRet = false;
			if (vCSymbolResult_a1[n_a3 + 1].get(0) == ' ')
			{
				TextPartStruct_a2.m_vpairnn_54.push_back(pair<int, int>(n_a4, n_a3));
				bRet = true;
				n_a4 = n_a3 + 2;
			}
		}
	}
	else
	{
		//no check
		bRet = false;
		if ((vCSymbolResult_a1[n_a3 + 1].xTSR_SymbolRect.left - vCSymbolResult_a1[n_a3].xTSR_SymbolRect.right) > (n_a6 + 1) * n_a5)
		{
			CSymbolResult xSR_68;
			xSR_68.addSymbolCandidate(32, 100, 0, 0);
			TextPartStruct_a2.m_vCSymbolResult_60.insert(TextPartStruct_a2.m_vCSymbolResult_60.begin() + n_a3 + 1, xSR_68);
			TextPartStruct_a2.m_vpairnn_54.push_back(pair<int, int>(n_a4, n_a3));
			n_a4 = n_a3++ + 2;
		}
	}

	return bRet;
}



void TextStructManager::correctEnums(TextStruct &xTextStruct_a0)
{
	wstring wstr_30;
	size_t j, t;

	for (size_t i = 0; i < xTextStruct_a0.m_vTextPartStruct_0.size(); i++)
	{
		TextPartStruct * pTPS = &xTextStruct_a0.m_vTextPartStruct_0[i];
		if (pTPS->m_bField_38)
		{
			CVisualSubField *pCVSF = pTPS->m_pCVisualSubField_34;
			if (pCVSF && pCVSF->m_nTVSF_Count_210)
			{
				//no check
				for (j = 0; j < pTPS->m_vCSymbolResult_60.size(); j++)
				{
					wstr_30.push_back(pTPS->m_vCSymbolResult_60[j].get(0));
				}

				vector<vector<pair<int, int>>> vvPair_nn_3C(pTPS->m_vCSymbolResult_60.size());

				for (j = 0; j < pTPS->m_vCSymbolResult_60.size(); j++)
				{
					for (size_t k = 0; k < pTPS->m_vCSymbolResult_60[j].nTSR_CandidatesCount; k++)
					{
						vvPair_nn_3C[j].push_back(pair<int, int>(pTPS->m_vCSymbolResult_60[j].get(k), pTPS->m_vCSymbolResult_60[j][k].nTSC_SymbolProbability));
					}
				}

				vector<wstring> vwstr_48;
				CVisualSubFieldEx::getVariantsFromSubField(*pTPS->m_pCVisualSubField_34, vwstr_48);
				for (j = 0; j < vwstr_48.size(); j++)
				{
					if (vwstr_48[j] == wstr_30) break;
				}

				if (j == vwstr_48.size())
				{
					wstring wstr_58;
					if (!CVisualSubFieldEx::findResultInEnum(vwstr_48, vvPair_nn_3C, wstr_58)
						|| !CVisualSubFieldEx::findResultInEnum2(vwstr_48, vvPair_nn_3C, wstr_58))
					{
						for (size_t k = 0; k < pTPS->m_vCSymbolResult_60.size(); k++)
						{
							if (pTPS->m_vCSymbolResult_60[k].get(0) != wstr_58[k])
							{
								for (t = 0; t < pTPS->m_vCSymbolResult_60[k].nTSR_CandidatesCount; t++)
								{
									if (pTPS->m_vCSymbolResult_60[k].get(t) != *((int*)wstr_58.data() + k))
									{
										CSymbolCandidate tmpSymbolCandidate = pTPS->m_vCSymbolResult_60[k][0];
										pTPS->m_vCSymbolResult_60[k][0] = pTPS->m_vCSymbolResult_60[k][t];
										pTPS->m_vCSymbolResult_60[k][t] = tmpSymbolCandidate;
										break;
									}
								}

								if (t == pTPS->m_vCSymbolResult_60[k].nTSR_CandidatesCount)
									pTPS->m_vCSymbolResult_60[k][0].set(wstr_58[k], 100, 0, 0);
							}
						}
					}
				}
			}
		}
	}
}

void TextStructManager::correctLcids(IAlphabetInfo &IAlphabetInfo_a0, ISymbolsIndexMap &ISymbolsIndexMap_a1, TextStruct &xTextStruct_a2)
{
	int j;
	for (size_t i = 0; i < xTextStruct_a2.m_vTextPartStruct_0.size(); i++)
	{
		TextPartStruct *pTPS = &xTextStruct_a2.m_vTextPartStruct_0[i];
		int n_v10 = pTPS->m_xTextPartLCIDInfo_70.m_vLcids_4.size();
		if (n_v10 >= 2 && pTPS->m_xTextPartLCIDInfo_70.m_nTPLCIDI_0 != 1)
		{
			//no check
			vector<vector<int>> vvn_30(n_v10);
			vector<vector<int>> vvn_3C(n_v10);

			for (j = 0; j < n_v10; j++)
			{
				IAlphabetInfo_a0.alphabet(xTextStruct_a2.m_vTextPartStruct_0[i].m_xTextPartLCIDInfo_70.m_vLcids_4[j], vvn_30[j]);

				for (size_t k = 0; k < vvn_30[j].size(); k++)
				{
					vvn_3C[j].push_back(ISymbolsIndexMap_a1.index(vvn_30[j][k]));
				}
			}

			vector<set<int>> vset_48(n_v10);
			for (j = 0; j < n_v10; j++)
			{
				set<int> set_54;
				for (size_t k = 0; k < vvn_3C[j].size(); k++)
					set_54.insert(set_54.begin(), vvn_3C[j][k]);

				vset_48[j] = set_54;

				for (int k = 0; k < n_v10; k++)
				{
					if (j != k)
					{
						set<int> set_60;
						for (size_t t = 0; t < vvn_3C[k].size(); t++)
							set_60.insert(set_60.begin(), vvn_3C[k][t]);

						vector<int> vn_r6(vset_48[j].size());
						vector<int>::iterator iter = set_difference(vset_48[j].begin(), vset_48[j].end(), set_60.begin(), set_60.end(), vn_r6.begin());
						vn_r6.erase(iter, vn_r6.end());

						vset_48[j] = set<int>(vn_r6.begin(), vn_r6.end());
					}
				}
			}

			vector<vector<int>> vvn_54(n_v10);
			for (j = 0; j < n_v10; j++)
			{
				for (size_t k = 0; k < vvn_3C[j].size(); k++)
				{
					set<int>::iterator iter = vset_48[j].begin();

					while (iter != vset_48[j].end())
					{
						if (*iter == vvn_3C[j][k])
						{
							vvn_54[j].push_back(vvn_30[j][k]);
							break;
						}
						iter++;
					}
				}
			}

			vector<int> vn_60(n_v10);
			for (j = 0; j < n_v10; j++)
			{
				int nCode__r11 = pTPS[i].m_vCSymbolResult_60[j].get(0);

				for (size_t k = 0; k < vset_48[j].size(); k++)
				{
					for (size_t t = 0; t < vvn_54[k].size(); t++)
					{
						if (vvn_54[k][t] == nCode__r11)
						{
							vn_60[k]++;
							break;
						}
					}
				}
			}

			int n_MaxIdx_r0 = 0;
			for (j = 0; j < n_v10; j++)
			{
				if (vn_60[j] > vn_60[n_MaxIdx_r0])
					n_MaxIdx_r0 = j;
			}

			if (n_MaxIdx_r0)
			{
				int nTmp = pTPS[i].m_xTextPartLCIDInfo_70.m_vLcids_4[0];
				pTPS[i].m_xTextPartLCIDInfo_70.m_vLcids_4[0] = pTPS[i].m_xTextPartLCIDInfo_70.m_vLcids_4[n_MaxIdx_r0];
				pTPS[i].m_xTextPartLCIDInfo_70.m_vLcids_4[n_MaxIdx_r0] = nTmp;
			}

			vector<wchar_t> vwchar_r0 = pTPS[i].m_xCAlphatF_C.m_map_vchar_18[pTPS[i].m_xTextPartLCIDInfo_70.m_vLcids_4[0]];
			pTPS[i].m_xCAlphatF_C.m_vAlphabet_0 = vector<int>(vwchar_r0.begin(), vwchar_r0.end());
			pTPS[i].m_xCAlphatF_C.m_vAlphabet_0.insert(pTPS[i].m_xCAlphatF_C.m_vAlphabet_0.end(), pTPS[i].m_xCAlphatF_C.m_vchar_C.begin(), pTPS[i].m_xCAlphatF_C.m_vchar_C.end());
		}
	}
}

void TextStructManager::checkSemantic(ISymbolsInfoByUnicode &ISymbolsInfoByUnicode_a0, TextStruct &xTextStruct_a1, InitConstStructs &xInitConstStructs_a2, BaseLines &xBaseLines_a3, bool b_a4)
{

}

void TextStructManager::deleteTrashDublicates(vector<vector<vector<SymbolCandidatWithRect>>>& vvvSymbolCandidatWithRect_a0)
{
	//no check
	for (size_t i = 0; i < vvvSymbolCandidatWithRect_a0.size(); i++)
	{
		if (vvvSymbolCandidatWithRect_a0[i].size() >= 2)
		{
			for (size_t j = 0; j + 1 < vvvSymbolCandidatWithRect_a0[i].size(); j++)
			{
				SymbolCandidatWithRect SymbolCandidatWithRect_r4 = vvvSymbolCandidatWithRect_a0[i][j][0];
				SymbolCandidatWithRect SymbolCandidatWithRect_r0 = vvvSymbolCandidatWithRect_a0[i][j + 1][0];

				if (SymbolCandidatWithRect_r4.m_xSymCandidat_0.m_wszCandiateCharacter_0 == 0x2020 &&
					SymbolCandidatWithRect_r0.m_xSymCandidat_0.m_wszCandiateCharacter_0 == 0x2020)
				{
					vvvSymbolCandidatWithRect_a0[i].erase(vvvSymbolCandidatWithRect_a0[i].begin() + j);
					j--;
				}
			}
		}
	}
}

void TextStructManager::generateResults(IFieldInfo &IFieldInfo_a0, TextStruct & xTextStruct_a1,
	CVisualField &xCVisualField_a2, CRecognizedTextDoc &xCRecTextDoc_a3, int n_a4, int n_a5, float r_a6)
{
	ImSegStatic *pImSegStatic_r0 = NULL;
	vector<vector<int>> vvn_180;
	vvn_180.push_back(vector<int>());

	vector<int> vFieldType_18C;
	vFieldType_18C.push_back(-1);

	xCVisualField_a2.u.s.sTVF_wLCID = xCVisualField_a2.xTVF_Font.m_sFF_LCID;

	vvn_180.push_back(vector<int>());

	int nFieldType_r0 = xCVisualField_a2.getType();
	vFieldType_18C.push_back(nFieldType_r0);

	int n_r2 = n_a4;
	int n_r0 = n_a4;
	if (n_a4)
		n_r0 = 1;
	if (n_a4 < 0)
		n_r2 = -n_a4;

	bool b_1F4 = n_r0 & (n_r2 == xCVisualField_a2.u.s.sTVF_wFieldType);
	bool bFlag_r8 = false;
	for (uint i = 0; i < xTextStruct_a1.m_vTextPartStruct_0.size(); i++)
	{
		if (b_1F4)
			vvn_180[0].push_back(i);

		if (xTextStruct_a1.m_vTextPartStruct_0[i].m_bField_38)
		{
			if (!xTextStruct_a1.m_vTextPartStruct_0[i].m_sFieldType_6C)
				xTextStruct_a1.m_vTextPartStruct_0[i].m_sFieldType_6C = xCVisualField_a2.u.s.sTVF_wFieldType;
			if (xTextStruct_a1.m_vTextPartStruct_0[i].m_xTextPartLCIDInfo_70.m_vLcids_4.empty())
			{
				xTextStruct_a1.m_vTextPartStruct_0[i].m_xTextPartLCIDInfo_70.addLcid(xCVisualField_a2.u.s.sTVF_wFieldType);
			}

			int nFieldTypeFull_r0 = xTextStruct_a1.m_vTextPartStruct_0[i].fieldTypeFull();

			uint j;
			for (j = 0; j < vFieldType_18C.size(); j++)
			{
				if (vFieldType_18C[j] == nFieldTypeFull_r0) break;
			}

			if (j == vFieldType_18C.size())
			{
				vvn_180.push_back(vector<int>());
				vFieldType_18C.push_back(nFieldTypeFull_r0);
			}
			else
			{
				vvn_180[j].push_back(i);
				if (j != 1 && xTextStruct_a1.m_vTextPartStruct_0[i].m_bField_6E)
					vvn_180[0].push_back(i);

				if (j == 1 && xTextStruct_a1.m_vTextPartStruct_0[i].m_nField_30 ||
					xTextStruct_a1.m_vTextPartStruct_0[i].m_bField_6E)
				{
					bFlag_r8 = true;
				}
			}
		}
	}

	vFieldType_18C[0] = xCVisualField_a2.getType();

	if (!bFlag_r8)
	{
		vFieldType_18C.erase(vFieldType_18C.begin() + 1, vFieldType_18C.begin() + 2);
		vvn_180.erase(vvn_180.begin() + 1);
	}

	if (!b_1F4)
	{
		vFieldType_18C.erase(vFieldType_18C.begin());
		vvn_180.erase(vvn_180.begin());
	}

	if (b_1F4 && bFlag_r8)
	{
		if (vvn_180[0].size() == vvn_180[1].size())
		{
			bool bSameFlag = true;
			for (uint i = 0; i < vvn_180[0].size(); i++)
			{
				if (vvn_180[0][i] != vvn_180[1][i])  bSameFlag = false;
			}

			if (bSameFlag)
			{
				vFieldType_18C.erase(vFieldType_18C.begin());
				vvn_180.erase(vvn_180.begin());
			}
		}
	}

	for (uint i = 0; i < vvn_180.size(); i++)
	{
		CRecognizedTextFieldSDK recognizedTextFieldSDK_16C;
		common::field::setFieldType(recognizedTextFieldSDK_16C, (eVisualFieldType)vFieldType_18C[i]);
		recognizedTextFieldSDK_16C.setComparison(xCVisualField_a2.nTVF_InComparison);
		int nLightType_r0 = xCVisualField_a2.getLightType();

		vector<uchar> vuchar_198;
		vector<CSymbolResult*> vCSymbolResult_1A4;
		for (uint j = 0; j < vvn_180[i].size(); j++)
		{
			TextPartStruct &xTextPartStruct = xTextStruct_a1.m_vTextPartStruct_0[vvn_180[i][j]];
			if (xTextPartStruct.m_nField_30)
			{
				vuchar_198.push_back('{');
				if (xTextPartStruct.m_vuchar_48.empty())
					vuchar_198.insert(vuchar_198.end(), xTextPartStruct.m_vucharName_3C.begin(), xTextPartStruct.m_vucharName_3C.end());
				vuchar_198.push_back('}');
			}
			else
			{
				//no check
				string str1F0 = "^";
				vector<uchar> vuchar_1B0(str1F0.begin(), str1F0.end());
				bool bFalg = false;

				if (vuchar_198.empty())
				{
					if (xTextPartStruct.m_vucharName_3C.size() == vuchar_1B0.size())
					{
						for (uint k = 0; k < xTextPartStruct.m_vucharName_3C.size(); k++)
						{
							if (xTextPartStruct.m_vucharName_3C[k] != vuchar_1B0[k])
							{
								bFalg = true;
								break;
							}
						}
					}
				}

				if (bFalg)
				{
					vuchar_198.insert(vuchar_198.end(), xTextPartStruct.m_vucharName_3C.begin(), xTextPartStruct.m_vucharName_3C.end());
				}
			}

			if (xTextPartStruct.m_xTextPartLCIDInfo_70.m_vLcids_4.size() == 2 &&
				xTextPartStruct.m_xTextPartLCIDInfo_70.m_nTPLCIDI_0 == 1)
			{
				// no check
				vector<vector<wchar_t>> vvwchar_1B0;
				Semantics::fillSymbolsVector(xTextPartStruct.m_vCSymbolResult_60, vvwchar_1B0);
				if (vvwchar_1B0.empty())
				{
					map<int, vector<wchar_t>>::iterator iter = xTextPartStruct.m_xCAlphatF_C.m_map_vchar_18.begin();
					map<int, set<uint>> map_1C0;
					while (iter != xTextPartStruct.m_xCAlphatF_C.m_map_vchar_18.end())
					{
						pImSegStatic_r0 = ImSegStatic::obj();
						vector<int> vn_1D0;
						pImSegStatic_r0->m_xSymbols_4C.m_xAlphabetInfo_10.alphabet(iter->first, vn_1D0);


						set<uint> set_1E0;
						for (uint k = 0; k < vn_1D0.size(); k++)
							set_1E0.insert(set_1E0.begin(), vn_1D0[k]);

						map_1C0.emplace(pair<int, set<uint>>(iter->first, set_1E0));
						iter++;
					}

					vector<int> vn_1D0(vvwchar_1B0.size());
					Semantics::correctMixedLcids(vvwchar_1B0, xTextPartStruct.m_xCAlphatF_C.m_map_vchar_18,
						xTextPartStruct.m_xTextPartLCIDInfo_70.m_vLcids_4[0], map_1C0, vn_1D0);

					for (uint k = 0; k < xTextPartStruct.m_vCSymbolResult_60.size(); k++)
					{
						int nTmp1 = xTextPartStruct.m_vCSymbolResult_60[k].nTSR_CandidatesCount;
						int nTmp2 = xTextPartStruct.m_vCSymbolResult_60[k].xnTSR_Candidates[0].nTSC_SymbolProbability;
						xTextPartStruct.m_vCSymbolResult_60[k].nTSR_CandidatesCount = xTextPartStruct.m_vCSymbolResult_60[vn_1D0[k]].nTSR_CandidatesCount;
						xTextPartStruct.m_vCSymbolResult_60[k].xnTSR_Candidates[0].nTSC_SymbolProbability = xTextPartStruct.m_vCSymbolResult_60[vn_1D0[k]].xnTSR_Candidates[0].nTSC_SymbolProbability;
						xTextPartStruct.m_vCSymbolResult_60[vn_1D0[k]].nTSR_CandidatesCount = nTmp1;
						xTextPartStruct.m_vCSymbolResult_60[vn_1D0[k]].xnTSR_Candidates[0].nTSC_SymbolProbability = nTmp2;
					}
				}
			}

			for (uint k = 0; k < xTextPartStruct.m_vCSymbolResult_60.size(); k++)
			{
				int  nCode = xTextPartStruct.m_vCSymbolResult_60[k].get(0);
				if (!xTextPartStruct.m_vCSymbolResult_60[k].nTSR_CandidatesCount)
				{
					if (nCode == ' ')
						xTextPartStruct.m_vCSymbolResult_60[k].nTSR_CandidatesCount = 1;
					else if (!xTextPartStruct.m_vCSymbolResult_60[k].nTSR_CandidatesCount && !xTextPartStruct.isSpace())
						continue;
				}

				if (nCode != '!' && nCode != '^' &&
					vCSymbolResult_1A4.empty() || vCSymbolResult_1A4.back()->get(0) != ' ' || nCode != ' ' || nCode >= ' ')
				{
					if (vCSymbolResult_1A4.empty() && nCode == ' ') continue;
					vCSymbolResult_1A4.push_back(&xTextPartStruct.m_vCSymbolResult_60[k]);
				}
			}
		}


		if (!vCSymbolResult_1A4.empty())
		{
			while ((vCSymbolResult_1A4.back()->get(0) == ' '))
			{
				vCSymbolResult_1A4.erase(vCSymbolResult_1A4.end() - 1);
				if (!vCSymbolResult_1A4.size()) break;
			}
		}

		if (!recognizedTextFieldSDK_16C.nDVEF_StringsCount)
			recognizedTextFieldSDK_16C.addString(vCSymbolResult_1A4.size());

		TSymbolResult * pSymbolResult_r4 = recognizedTextFieldSDK_16C.pDVEF_StringsResult[recognizedTextFieldSDK_16C.nDVEF_StringsCount - 1].pTSRS_StringResult;
		for (uint j = 0; j < vCSymbolResult_1A4.size(); j++)
		{
			memcpy(&pSymbolResult_r4[j], vCSymbolResult_1A4[j], sizeof(CSymbolResult));
			pSymbolResult_r4[j].xTSR_SymbolRect.top = n_a5 - pSymbolResult_r4[j].xTSR_SymbolRect.top;
			pSymbolResult_r4[j].xTSR_SymbolRect.bottom = n_a5 - pSymbolResult_r4[j].xTSR_SymbolRect.bottom;
		}

		FieldParam fieldParam = IFieldInfo_a0.param();
		vector<uchar> vuchar_1981 = fieldParam.param(PROCESS_OPTION_4);
		vuchar_198.insert(vuchar_198.begin(), vuchar_1981.begin(), vuchar_1981.end());
		fieldParam = IFieldInfo_a0.param();
		vector<uchar> vuchar_1F0 = fieldParam.paramValue(PROCESS_OPTION_7);
		if (!vuchar_1F0.empty())
			vuchar_198.insert(vuchar_198.end(), vuchar_1F0.begin(), vuchar_1F0.end());

		string strReault_1B0(vuchar_198.begin(), vuchar_198.end());

		strReault_1B0 = common::StringUtils::Replace(strReault_1B0, string("{SPACE}{SPACE}"), string("{SPACE}"));
		string strSpace_1C0 = "{SPACE}";
		if (!strReault_1B0.compare(0, strSpace_1C0.length(), strSpace_1C0))
			strReault_1B0.erase(0, strSpace_1C0.length());

		if (strReault_1B0.length() > strSpace_1C0.length())
		{
			if (!strReault_1B0.compare(strReault_1B0.length() - strSpace_1C0.length(),
				strReault_1B0.length(), strSpace_1C0))
			{
				strReault_1B0.erase(strReault_1B0.length() - strSpace_1C0.length(), strSpace_1C0.length());
			}
		}
		
		recognizedTextFieldSDK_16C.setMask(strReault_1B0.data());
		TextStructManager::postProcessing(recognizedTextFieldSDK_16C, (eTextPostProcessing)xCVisualField_a2.sTVF_postProcessing);

		int bFalg_r4 = false;
		if (recognizedTextFieldSDK_16C.symbolCount() >= 1)
		{
			wstring wstr_1D0 = recognizedTextFieldSDK_16C.generateUnicodeTextFromSymbols();
			if (recognizedTextFieldSDK_16C.getLCID() == 0x40D)//RLO
			{
				vector<int> vn_1F0;
				pImSegStatic_r0 = ImSegStatic::obj();
				pImSegStatic_r0->m_xSymbols_4C.m_xAlphabetInfo_10.alphabet(0x40D, vn_1F0);
				wstring wstr_1E0 = Semantics::reverseRightToLeftText(wstr_1D0, vn_1F0);
				wstr_1D0 = wstr_1E0;
			}

			string str_1E0 = common::UnicodeUtils::WStrToUtf8(wstr_1D0);
			recognizedTextFieldSDK_16C.updateString(str_1E0.data(), str_1E0.length());

			CRecognizedTextFieldSDK * pRecTextFieldSDK_r0 = (i || !b_1F4) ? xCRecTextDoc_a3.add() : xCRecTextDoc_a3.field(0);
			if (xCVisualField_a2.xTVF_Font.m_cFF_emptyFieldToResult && xCRecTextDoc_a3.find(eVisualFieldType(recognizedTextFieldSDK_16C.getTypeFull() || pRecTextFieldSDK_r0)))
			{
				pRecTextFieldSDK_r0->set(&recognizedTextFieldSDK_16C);
				pRecTextFieldSDK_r0->u.xDVEF_FieldRect = xCVisualField_a2.getRegion();

				for (int j = 0; j < pRecTextFieldSDK_r0->nDVEF_StringsCount; j++)
				{
					for (uint k = 0; k < pRecTextFieldSDK_r0->pDVEF_StringsResult[j].nTSRS_SymbolsCount; k++)
					{
						pRecTextFieldSDK_r0->pDVEF_StringsResult[j].pTSRS_StringResult[k].xTSR_SymbolRect.left = (int)(pRecTextFieldSDK_r0->pDVEF_StringsResult[j].pTSRS_StringResult[k].xTSR_SymbolRect.left / r_a6);
						pRecTextFieldSDK_r0->pDVEF_StringsResult[j].pTSRS_StringResult[k].xTSR_SymbolRect.top = (int)(pRecTextFieldSDK_r0->pDVEF_StringsResult[j].pTSRS_StringResult[k].xTSR_SymbolRect.top / r_a6);
						pRecTextFieldSDK_r0->pDVEF_StringsResult[j].pTSRS_StringResult[k].xTSR_SymbolRect.right = (int)(pRecTextFieldSDK_r0->pDVEF_StringsResult[j].pTSRS_StringResult[k].xTSR_SymbolRect.right / r_a6);
						pRecTextFieldSDK_r0->pDVEF_StringsResult[j].pTSRS_StringResult[k].xTSR_SymbolRect.bottom = (int)(pRecTextFieldSDK_r0->pDVEF_StringsResult[j].pTSRS_StringResult[k].xTSR_SymbolRect.bottom / r_a6);
					}
				}
			}
			else bFalg_r4 = 10;
		}

		if (bFalg_r4 != 10 && !bFalg_r4) break;
	}
}

void TextStructManager::generateWordsInString(TextStruct & TextStruct_a1, int n_a2, int n_a3, bool b_a4)
{
	for (size_t i = 0; i < TextStruct_a1.m_vTextPartStruct_0.size(); i++)
	{
		if (!TextStruct_a1.m_vTextPartStruct_0[i].m_pCVisualSubField_34)
			continue;

		string str_30(TextStruct_a1.m_vTextPartStruct_0[i].m_pCVisualSubField_34->m_szTVSF_110);
		if (str_30 == "STRING" || str_30 == "STRINGS" || str_30 == "WORD")
		{
			int n_34 = 0;
			TextStruct_a1.m_vTextPartStruct_0[i].m_vpairnn_54.clear();
			if (str_30 != "WORD")
			{
				for (int j = 0; j < (int)TextStruct_a1.m_vTextPartStruct_0[i].m_vCSymbolResult_60.size() - 1; j++)
				{
					if (TextStruct_a1.m_vTextPartStruct_0[i].m_vCSymbolResult_60[j + 1].get(0) != '^' &&
						TextStruct_a1.m_vTextPartStruct_0[i].m_vCSymbolResult_60[j].get(0) != '!' &&
						TextStruct_a1.m_vTextPartStruct_0[i].m_vCSymbolResult_60[j + 1].get(0) != '!' &&
						TextStruct_a1.m_vTextPartStruct_0[i].m_vCSymbolResult_60[j + 1].get(0) != '.' &&
						TextStruct_a1.m_vTextPartStruct_0[i].m_vCSymbolResult_60[j + 1].get(0) != ',')
					{
						if (TextStruct_a1.m_vTextPartStruct_0[i].m_vCSymbolResult_60[j].get(0) != '^' &&
							TextStruct_a1.m_vTextPartStruct_0[i].m_vCSymbolResult_60[j + 1].get(0) != '!')
						{
							splitBySpaceAttempt(TextStruct_a1.m_vTextPartStruct_0[i].m_vCSymbolResult_60,
								TextStruct_a1.m_vTextPartStruct_0[i], j, n_34, n_a2, n_a3, b_a4);
						}
						else
						{
							TextStruct_a1.m_vTextPartStruct_0[i].m_vpairnn_54.push_back(pair<int, int>(n_34, j));
							n_34 = j + 1;
						}
					}
				}

				TextStruct_a1.m_vTextPartStruct_0[i].m_vpairnn_54.push_back(pair<int, int>(n_34, TextStruct_a1.m_vTextPartStruct_0[i].m_vCSymbolResult_60.size() - 1));
			}
			else
				TextStruct_a1.m_vTextPartStruct_0[i].m_vpairnn_54.push_back(pair<int, int>(0, TextStruct_a1.m_vTextPartStruct_0[i].m_vCSymbolResult_60.size() - 1));
		}
	}
}



bool TextStructManager::splitMask(string & str_a1, CVisualField & CVisualField_a2, TextStruct & TextStruct_a3)
{
	TextStruct_a3.m_vTextPartStruct_0.clear();
	string str_30(str_a1);
	str_30 = common::StringUtils::Replace(str_30, string("  "), string(" "));
	TextStruct_a3.m_vuc_10 = vector<uchar>(str_30.begin(),str_30.end());

	TextPartStruct xTps_d0;
	string str_40;
	bool bRet;
	for (size_t i = 0; i < str_30.size(); i++)
	{
		if (str_30[i] == '!' || str_30[i] == '{' || str_30[i] == '^')
		{
			if (str_40.size())
			{
				if (str_40 == " ")
					xTps_d0.m_bField_39 = true;

				xTps_d0.m_vucharName_3C = vector<uchar>(str_40.begin(), str_40.end());
				TextStruct_a3.addPart(xTps_d0);

				int nSize = TextStruct_a3.m_vTextPartStruct_0.size() - 1;
				if (TextStruct_a3.m_vTextPartStruct_0[nSize].m_xTextPartLCIDInfo_70.m_vLcids_4.empty())
					TextStruct_a3.m_vTextPartStruct_0[nSize].m_xTextPartLCIDInfo_70.addLcid(CVisualField_a2.xTVF_Font.m_sFF_LCID);

				if (!TextStruct_a3.m_vTextPartStruct_0[nSize].m_sFieldType_6C)
					TextStruct_a3.m_vTextPartStruct_0[nSize].m_sFieldType_6C = CVisualField_a2.u.s.sTVF_wFieldType;
				xTps_d0.reset();
				str_40 = "";
			}

			switch (str_30[i])
			{
			case '!':
				xTps_d0.m_bField_38 = false;
				break;

			case '{':
			{
				bRet = true;
				xTps_d0.m_nField_30 = 1;
				int nTemp = str_30.find('}', i);
				if (nTemp == -1)
					return bRet;
				string str_50 = string(str_30, i + 1, nTemp  - i - 1 );

				if (str_50.size() == 2)
				{
					if (str_50[0] == '&')
					{
						xTps_d0.m_vuchar_48 = vector<uchar>(str_50.begin(), str_50.end());
						string strNumber("0123456789");
						if (strNumber.find(str_50[1], 0) == -1)
							str_50.assign("C");
						else
							str_50.assign("D");
					}
				}

				int nFirst = str_50.find("[", 0);
				int nEnd = str_50.find("]", 0);

				if (nFirst != -1 && nEnd != -1)
				{
					string strTemp(str_50.begin() + nFirst + 1, str_50.begin() + nEnd);
					while (strTemp.find('+', 0) != -1)
					{
						int nIndex = strTemp.find('+', 0);
						strTemp.erase(nIndex);
					}
					while (strTemp.find(',', 0) != -1)
					{
						int nIndex = strTemp.find(',', 0);
						strTemp.erase(nIndex);
					}

					size_t j;
					for (j = 0; j < strTemp.size(); j++)
					{
						if (!std::char_traits<char>::find("0123456789", 10, strTemp[j]))
							break;
					}

					if (j == strTemp.size())
					{
						xTps_d0.m_xTextPartLCIDInfo_70.init(string(str_50, nFirst + 1, nEnd));
						str_50.erase(nFirst, nEnd - nFirst + 1);
					}
				}

				nFirst = str_50.find('"', 0);
				if (nFirst != -1)
				{
					int nEnd = str_50.find('"', nFirst + 1);
					string strTemp;

					if (nEnd != -1)
					{
						strTemp = string(str_50,nFirst + 1, nEnd);
						if (strTemp[strTemp.size() - 1] == '+')
							xTps_d0.m_bField_6E = true;
					}

					xTps_d0.m_sFieldType_6C = common::StringUtils::toInt(strTemp);
					str_50.erase(nFirst, nEnd - nFirst + 1);
				}

				xTps_d0.m_vucharName_3C = vector<uchar>(str_50.begin(), str_50.end()); 
				if (TextStruct_a3.addPart(xTps_d0))
					return bRet;

				int nSize = TextStruct_a3.m_vTextPartStruct_0.size() - 1;
				if (TextStruct_a3.m_vTextPartStruct_0[nSize].m_xTextPartLCIDInfo_70.m_vLcids_4.empty())
					TextStruct_a3.m_vTextPartStruct_0[nSize].m_xTextPartLCIDInfo_70.addLcid(CVisualField_a2.xTVF_Font.m_sFF_LCID);

				if (!TextStruct_a3.m_vTextPartStruct_0[nSize].m_sFieldType_6C)
					TextStruct_a3.m_vTextPartStruct_0[nSize].m_sFieldType_6C = CVisualField_a2.u.s.sTVF_wFieldType;
				xTps_d0.reset();
				i = nTemp;
				break;
			}

			case '^':
				xTps_d0.reset();
				xTps_d0.m_vucharName_3C.push_back('^');
				xTps_d0.m_bField_38 = true;
				TextStruct_a3.addPart(xTps_d0);
				xTps_d0.reset();
				break;
			}
		}
		else
			str_40.push_back(str_30[i]);
	}

	if (str_40.size())
	{
		if (str_40 == " ")
			xTps_d0.m_bField_39 = true;
		xTps_d0.m_vucharName_3C = vector<uchar>(str_40.begin(), str_40.end());

		TextStruct_a3.addPart(xTps_d0);
		int nSize = TextStruct_a3.m_vTextPartStruct_0.size() - 1;
		if (TextStruct_a3.m_vTextPartStruct_0[nSize].m_xTextPartLCIDInfo_70.m_vLcids_4.empty())
			TextStruct_a3.m_vTextPartStruct_0[nSize].m_xTextPartLCIDInfo_70.addLcid(CVisualField_a2.xTVF_Font.m_sFF_LCID);

		if (!TextStruct_a3.m_vTextPartStruct_0[nSize].m_sFieldType_6C)
			TextStruct_a3.m_vTextPartStruct_0[nSize].m_sFieldType_6C = CVisualField_a2.u.s.sTVF_wFieldType;
		xTps_d0.reset();
	}

	TextStruct_a3.m_bField_1C = isFix(TextStruct_a3, TextStruct_a3.m_vuc_20, 1) == 0;
	lineCount(TextStruct_a3, TextStruct_a3.m_nLineCount_2C);
	bRet = false;

	return bRet;
}

void TextStructManager::updateSpacePosition(TextStruct & TextStruct_a1)
{
	for (size_t i = 0; i < TextStruct_a1.m_vTextPartStruct_0.size(); i++)
	{
		if (!TextStruct_a1.m_vTextPartStruct_0[i].m_Position_0.m_nStatus_0 && TextStruct_a1.m_vTextPartStruct_0[i].isSpace())
		{
			if (i == 0)
			{
				TextStruct_a1.m_vTextPartStruct_0[i].m_Position_0.m_nStatus_0 = 2;
				TextStruct_a1.m_vTextPartStruct_0[i].m_Position_0.m_nStartPos_4 = 0;
			}
			else if (TextStruct_a1.m_vTextPartStruct_0[i - 1].m_Position_0.m_nStatus_0)
			{
				TextStruct_a1.m_vTextPartStruct_0[i].m_Position_0.m_nStatus_0 = 2;
				TextStruct_a1.m_vTextPartStruct_0[i].m_Position_0.m_nStartPos_4 = TextStruct_a1.m_vTextPartStruct_0[i - 1].m_Position_0.m_nStartPos_4 + 1;
				TextStruct_a1.m_vTextPartStruct_0[i].m_Position_0.m_nEndPos_8 = TextStruct_a1.m_vTextPartStruct_0[i - 1].m_Position_0.m_nEndPos_8;
			}
			else if (i == TextStruct_a1.m_vTextPartStruct_0.size() - 1)
			{
				TextStruct_a1.m_vTextPartStruct_0[i].m_Position_0.m_nStatus_0 = 2;
				TextStruct_a1.m_vTextPartStruct_0[i].m_Position_0.m_nStartPos_4 = TextStruct_a1.m_vTextPartStruct_0.size();
				TextStruct_a1.m_vTextPartStruct_0[i].m_Position_0.m_nEndPos_8 = TextStruct_a1.m_vTextPartStruct_0.size() - 1;
			}
			else if (TextStruct_a1.m_vTextPartStruct_0[i + 1].m_Position_0.m_nStatus_0)
			{
				TextStruct_a1.m_vTextPartStruct_0[i].m_Position_0.m_nStatus_0 = 2;
				TextStruct_a1.m_vTextPartStruct_0[i].m_Position_0.m_nStartPos_4 = TextStruct_a1.m_vTextPartStruct_0[i + 1].m_Position_0.m_nStartPos_4;
				TextStruct_a1.m_vTextPartStruct_0[i].m_Position_0.m_nEndPos_8 = TextStruct_a1.m_vTextPartStruct_0[i + 1].m_Position_0.m_nStartPos_4 - 1;
			}
		}
	}
}
