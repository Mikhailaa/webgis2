#pragma once
#include "pch.h"
#include "common/resources.h"
#include "common/container/container.h"
#include "common/container/RclHolder.h"
#include "Json/Value.h"
#include "TLineAnalyzeFirst.h"
#include "commonStruct.h"

using namespace common::resources;
using namespace common::container;

namespace imseg
{
	namespace parameters
	{
		//get_UseIppImProc No XRef
		//get_useColorFoneRemove No XRef
		bool  get_UseOnlyWhiteImage();
		float kHDeviation(TLineAnalyzeFirst &, eHType);

		class Configuration
		{
		public:
			int m_nDocId;
			int field_4;
			Json::Value m_xJsonValue_8;			

			Configuration();
			~Configuration();
			static Configuration *obj();
		};
	}
}