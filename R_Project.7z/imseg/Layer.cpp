#include "Layer.h"
#include "common/StringUtils.h"

	Layer_R::Layer_R()
	{
		this->clear();
		m_vTextEx_8C.clear();
		field_98 = false;
	}

	Layer_R::~Layer_R()
	{
	}

	void Layer_R::linesList(vector<Text*>& a1)
	{
		a1.clear();
		for (size_t i = 0; i < size(); i++)
		{
			for (size_t j = 0; j < at(i).m_vText_4C.size(); j++)
				a1.push_back(&at(i).m_vText_4C[j]);
		}
	}

	void Layer_R::linesList(vector<pair<Text *, Field *>> &a1)
	{
		a1.clear();
		for (size_t i = 0; i < size(); i++)
		{
			for (size_t j = 0; j < at(i).m_vText_4C.size(); j++)
				a1.push_back(pair<Text *, Field *>(&at(i).m_vText_4C[j], &at(i)));
		}
	}

	void Layer_R::linesListWithText(vector<Text*>& a1)
	{
		a1.clear();
		for (size_t i = 0; i < size(); i++)
		{
			size_t j, k;
			if (at(i).m_pCVisualF_70->getType() != 6 &&
				at(i).m_pCVisualF_70->getType() != 17 &&
				at(i).m_pCVisualF_70->getType() != 39 &&
				at(i).m_pCVisualF_70->getType() != 69)
			{
				for (j = 0; j < at(i).m_vTextStruct_58.size(); j++)
				{

					for (k = 0; k < at(i).m_vTextStruct_58[j].m_vTextPartStruct_0.size(); k++)
					{
						if (at(i).m_vTextStruct_58[j].m_vTextPartStruct_0[k].m_nField_30)
						{
							string str_30(at(i).m_vTextStruct_58[j].m_vTextPartStruct_0[k].m_pCVisualSubField_34->m_szTVSF_110);
							if (!common::StringUtils::contains(str_30, string("STRING")) &&
								!common::StringUtils::contains(str_30, string("STRINGS")) &&
								!common::StringUtils::contains(str_30, string("WORD")))
								break;
						}
					}

					if (k != at(i).m_vTextStruct_58[j].m_vTextPartStruct_0.size())
						break;
				}
			}

			if (k != at(i).m_vTextStruct_58[j].m_vTextPartStruct_0.size())
				continue;

			for (size_t l = 0; l < at(i).m_vText_4C.size(); l++)
				a1.push_back(&at(i).m_vText_4C[l]);
		}
	}

	vector<vector<CBufferImage *>> Layer_R::images()
	{
		vector<vector<CBufferImage *>> vRet(this->size());

		for (size_t i = 0; i < this->size(); i++)
		{
			for (int j = 0; j < 5; j++)
			{
				Field &field = at(i);
				if (field.m_xFieldImages_20.m_vCBufImg_20[j].width())
				{
					if (field.m_xFieldImages_20.m_vCBufImg_20[j].ownData())
						vRet[i].push_back(&field.m_xFieldImages_20.m_vCBufImg_20[j]);
				}
			}
		}

		return vRet;
	}
	void Layer_R::setRecognizeMeAllwaysWithoutTextDetection(bool a1)
	{
		field_98 = a1;
	}
	bool Layer_R::recognizeMeAllwaysWithoutTextDetection()
	{
		return field_98;
	}
