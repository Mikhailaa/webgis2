#include"Symbol.h"

namespace imseg
{
	Symbol::Symbol()
	{
		m_xRecRes2_18.m_vSymCandidat.clear();
		m_xRECT_40.left = 0;
		m_xRECT_40.top = 0;
		m_xRECT_40.right = 0;
		m_xRECT_40.bottom = 0;
		field_50 = 0;
		field_14 = 0;
		reset();
	}

	Symbol::Symbol(Symbol const &a2)
	{
		m_xRECT_0 = a2.m_xRECT_0;
		m_nLine_10 = a2.m_nLine_10;
		m_xRecRes2_18.m_vSymCandidat = a2.m_xRecRes2_18.m_vSymCandidat;
		memcpy(&field_24, &a2.field_24, 0x30);
	}

	Symbol::Symbol(tagRECT &a2)
	{
		m_xRecRes2_18.m_vSymCandidat.clear();
		m_xRECT_40.left = 0;
		m_xRECT_40.top = 0;
		m_xRECT_40.right = 0;
		m_xRECT_40.bottom = 0;
		field_50 = 0;
		reset();
		m_xRECT_0 = a2;
	}
	//Symbol::Symbol(Symbol &&arg1)
	//	: m_xRecRes2_18(arg1.m_xRecRes2_18)
	//{
	//	m_xRECT_0 = move(arg1.m_xRECT_0);
	//	m_nLine_10 = move(arg1.m_nLine_10);
	//	field_14 = move(arg1.field_14);
	//	field_24 = move(arg1.field_24);
	//	field_28 = move(arg1.field_28);
	//	field_2C = move(arg1.field_2C);
	//	field_30 = move(arg1.field_30);
	//	field_34 = move(arg1.field_34);
	//	field_38 = move(arg1.field_38);
	//	field_3C = move(arg1.field_3C);
	//	m_xRECT_40 = move(arg1.m_xRECT_40);
	//	field_50 = move(arg1.field_50);
	//	field_51 = move(arg1.field_51);
	//	field_52 = move(arg1.field_52);
	//	field_53 = move(arg1.field_53);
	//}

	tagRECT Symbol::rect()
	{
		return m_xRECT_0;
	}

	void Symbol::reset()
	{
		m_xRECT_0.left = 0;
		m_xRECT_0.top = 0;
		m_xRECT_0.right = 0;
		m_xRECT_0.bottom = 0;
		m_nLine_10 = 0;
		m_xRecRes2_18.m_vSymCandidat.clear();
		field_24 = 0;
		field_28 = 7;
		field_2C = 0x100;
		field_30 = 0;

		//????????
		field_34 = 0;
		field_38 = 0;
		field_3C = 0;
	}
	Symbol& Symbol::operator=(Symbol &arg1)
	{
		if (this == &arg1)
			return *this;
		m_xRECT_0 = arg1.m_xRECT_0;
		m_nLine_10 = arg1.m_nLine_10;
		field_14 = arg1.field_14;
		m_xRecRes2_18.m_vSymCandidat.assign(
			arg1.m_xRecRes2_18.m_vSymCandidat.begin(),
			arg1.m_xRecRes2_18.m_vSymCandidat.end()
		);
		field_24 = arg1.field_24;
		field_28 = arg1.field_28;
		field_2C = arg1.field_2C;
		field_30 = arg1.field_30;
		field_34 = arg1.field_34;
		field_38 = arg1.field_38;
		field_3C = arg1.field_3C;
		m_xRECT_40 = arg1.m_xRECT_40;
		field_50 = arg1.field_50;
		field_51 = arg1.field_51;
		field_52 = arg1.field_52;
		field_53 = arg1.field_53;
		return *this;
	}
	bool Symbol::isRecogn()
	{
		return !m_xRecRes2_18.m_vSymCandidat.empty();
	}
	bool Symbol::isNewLine()
	{
		return m_nLine_10 == -1;
	}
	int Symbol::prob(int arg1)
	{
		return m_xRecRes2_18.prob(arg1);
	}
	float Symbol::probF(int arg1)
	{
		return m_xRecRes2_18.probF(arg1);
	}
	int Symbol::width()
	{
		return m_xRECT_0.right - m_xRECT_0.left;
	}
	int Symbol::height()
	{
		return m_xRECT_0.top - m_xRECT_0.bottom;
	}
	float Symbol::kWH()
	{
		return (float)(m_xRECT_0.right - m_xRECT_0.left) / (m_xRECT_0.top - m_xRECT_0.bottom);
	}

	Symbol::~Symbol()
	{
	}

}
