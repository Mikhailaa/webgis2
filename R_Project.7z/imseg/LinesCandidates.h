#pragma once              

#include "commonStruct.h"
#include "ImageControl.h"
#include "FontDesc.h"
#include "InitConstStructs.h"
#include "FieldParam.h"

class LinesCandidates
{
public:
	LinesCandidates();
	~LinesCandidates();
	LinesCandidates(LinesCandidates &&);
	void rotatePoints(float, tagPOINT &);
	int generatePoints(CBufferImage &, FontDesc &, FieldParam &, InitConstStructs &);
	static int findAllSymbols(CBufferImage &, FontDesc &, InitConstStructs &, FieldParam &, vector<TPointEx> &);
	static int filterSymbols(vector<TPointEx> &, InitConstStructs &, vector<TPointEx> &, int &);

	vector<TPointEx> m_vTxPoints_0;
};