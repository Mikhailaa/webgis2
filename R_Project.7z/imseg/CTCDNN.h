#pragma once
#include "DecoderCTC.h"
#include "RichTextLines.h"
#include "dbgInfoSaver.h"


#include "dnn/MTDNN.h"

using namespace cv::dnn;


namespace imseg
{
	class CTCDNN : public ITextLinesVisitor
	{
	public:
		CTCDNN();
		virtual ~CTCDNN();
		virtual void visit(RichTextLines &xRTL);

		shared_ptr<IFieldMask> *getMaskAnyWay(uint);
		int getOutputWidth2InputWidthRatio();
		cv::Size getSize();
		void io_generic(cv::dnn::DnnReader &);
		void setMasks(vector<shared_ptr<IFieldMask>> const&);
		//test(); No xref
		//updateTextRect(int const&, Rect_<int> &); No Xref


		//int m_nCTCDNN_vft_0;
		cv::Size m_xCTCDNN_Size_4;//4
		int m_nCTCDNN_field_C;
		int m_nCTCDNN_field_10;
		MTDNN m_xCTCDNN_mtDNN_14;
		DecoderCTC m_nCTCDNN_DecorderCTC_24;
		vector<shared_ptr<IFieldMask>> m_vCTCDNN_sptrIFieldMask_40;
		shared_ptr<IFieldMask> m_sptrCTCDNN_IFieldMask_4C;
	};
}