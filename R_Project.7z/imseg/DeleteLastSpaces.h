#pragma once
#include "imseg_interface.h"
#include "CTCHypoth.h"

namespace imseg
{
	class DeleteLastSpaces : public ICorrector
	{
	public:
		DeleteLastSpaces(ICorrector*);
		~DeleteLastSpaces();
		virtual void process_impl(vector<CTCHypoth> &);
	};
}