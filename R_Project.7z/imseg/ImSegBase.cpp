﻿#include "ImSegBase.h"
#include "description.h"
#include "debug.h"
#include "test.h"
#include "textlinedetectcv.h"
#include "ParsedMaskBuilder.h"
#include "fieldpreprocess.h"
#include "imseg.h"
#include "analyzelines.h"
#include "rcvmat.h"
#include "common/common.h"
#include "common/StringUtils.h"
#include "TextStructManager.h"
#include "FieldMaskEx.h"
#include "AlphabetContainer.h"
#include "SymbolsFilter.h"
#include "TextProcess.h"
#include "RSubFieldManager.h"
#include "VisualField.h"
#include "VLinesCandidates.h"
#include "RCv.h"
#include "Analyse.h"
#include "AnalyzeLinesCandidates.h"
#include "LineDetect.h"
#include "legacycommonlib.h"
#include "rclhelp.h"
#include "common/UnicodeUtils.h"
#include "imseg_rect.h"
#include "common/container/jsoncpp.h"
#include "common/StringUtils.h"
#include "Log.h"


using namespace common;
using namespace imseg::analyzelines;
using namespace imseg::Base;
using namespace imseg::debug::fieldsinfo;
using namespace imseg::description;
using namespace imseg::field;
using namespace imseg::parameters;
using namespace imseg::fieldpreprocess;
using namespace imseg::test;
using namespace imseg::textlinedetectcv;
using namespace imseg;

///////
string gastrMonths_Ccc[] = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
string gastrMonths[] = { "JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC" };
void formatDateString(string &strDate, int nDay, int nMonth, int nYear)
{
	strDate = common::StringUtils::toString(nMonth);
	strDate += "/";
	strDate += common::StringUtils::toString(nDay);
	strDate += "/";
	strDate += common::StringUtils::toString(nYear);
}
bool ConverteDateFormat(string &strMask, string &strResult)
{
	string strReverse = "";
	int nDay = -1, nMonth = -1, nYear = -1;
	string strTemp = strResult;
	strTemp = common::StringUtils::RemoveExtraSymbols(strTemp);
	strTemp = common::StringUtils::Replace(strTemp, string("/"), string(""));
	strTemp = common::StringUtils::Replace(strTemp, string("-"), string(""));
	strTemp = common::StringUtils::Replace(strTemp, string(" "), string(""));
	if (strMask == "{_@DNN@}{DAY} {MONTH}!/!{MONTH_FRA} {YEAR}")//06 SEP/SEPT 2022
	{

		if (strTemp.length() < 9) {
			//strResult = "";
			return false;
		}
		nDay = common::StringUtils::toInt(strTemp.substr(0, 2));
		for (int i = 0; i < 12; i++)
		{
			if (strTemp.substr(2, 3) == gastrMonths[i])
			{
				nMonth = i + 1;
				break;
			}
		}
		nYear = common::StringUtils::toInt(strTemp.substr(strTemp.size() - 5, 4));
		nYear -= nYear / 100 * 100;
	}
	if (strMask == "{_@DNN@}{DAY}.{MONTH_DD}.{YEAR}")
	{
		for (int i = 0; i < strTemp.length(); i++) {
			if (strTemp[i] < '0' || strTemp[i] > '9') {
				strTemp.erase(strTemp.begin() + i);
				i--;
			}
		}
		if (strTemp.length() < 8) {
			//strResult = "";
			return false;
		}
		nDay = common::StringUtils::toInt(strTemp.substr(0, 2));
		nMonth = common::StringUtils::toInt(strTemp.substr(2, 2));
		nYear = common::StringUtils::toInt(strTemp.substr(4, 4));
		nYear -= nYear / 100 * 100;
	}
	if (strMask == "{_@DNN@}{DAY}/{MONTH_DD}/{YEAR}")//16/01/2020		
	{		
		for (int i = 0; i < strTemp.length(); i++) {
			if (strTemp[i] < '0' || strTemp[i] > '9') {
				strTemp.erase(strTemp.begin() + i);
				i--;
			}
		}
		if (strTemp.length() < 8) {
			//strResult = "";
			return false;
		}
		nDay = common::StringUtils::toInt(strTemp.substr(0, 2));
		nMonth = common::StringUtils::toInt(strTemp.substr(2, 2));
		nYear = common::StringUtils::toInt(strTemp.substr(4, 4));
		nYear -= nYear / 100 * 100;
	}
	if (strMask == "{_@DNN@}{DAY}/{MONTH_DD}/{YEAR} !- {TEXT\"6\"}|{DAY}/{MONTH_DD}/{YEAR}! {TEXT\"6\"}")//11/02/1979 - TEHRAN
	{
		if (strResult.size() < 8) 
			return false;
		strReverse = strResult.substr(8, strResult.size() - 8);
		for (int i = 0; i < strTemp.length(); i++) {
			if (strTemp[i] < '0' || strTemp[i] > '9') {
				strTemp.erase(strTemp.begin() + i);
				i--;
			}
		}
		if (strResult.size() < 8)
			return false;
		nDay = common::StringUtils::toInt(strTemp.substr(0, 2));
		nMonth = common::StringUtils::toInt(strTemp.substr(2, 2));
		nYear = common::StringUtils::toInt(strTemp.substr(4, 4));
		nYear -= nYear / 100 * 100;
	}
	if (strMask == "{_@DNN@}{DAY} {MONTH} {YEAR_DD}|{DAY} {Month_Ccc} {YEAR_DD}")//10 MAR 92
	{
		if (strTemp.length() < 7) {
			//strResult = "";
			return false;
		}
		nDay = common::StringUtils::toInt(strTemp.substr(0, 2));
		for (int i = 0; i < 12; i++)
		{
			if (strTemp.substr(2, 3) == gastrMonths[i])
			{
				nMonth = i + 1;
				break;
			}
		}
		nYear = common::StringUtils::toInt(strTemp.substr(5, 2));
	}
	if (strMask == "{_@DNN@}{DAY_D_DD} {Month_Ccc} {YEAR}")//09 Mar 1997
	{
		if (strTemp.length() < 8) {
			//strResult = "";
			return false;
		}
		if (strTemp.length() == 8) {
			nDay = common::StringUtils::toInt(strTemp.substr(0, 1));
			for (int i = 0; i < 12; i++)
			{
				if (strTemp.substr(1, 3) == gastrMonths_Ccc[i])
				{
					nMonth = i + 1;
					break;
				}
			}
			nYear = common::StringUtils::toInt(strTemp.substr(4, 4));
			nYear -= nYear / 100 * 100;
		}
		else {
			nDay = common::StringUtils::toInt(strTemp.substr(0, 2));
			for (int i = 0; i < 12; i++)
			{
				if (strTemp.substr(2, 3) == gastrMonths_Ccc[i])
				{
					nMonth = i + 1;
					break;
				}
			}
			nYear = common::StringUtils::toInt(strTemp.substr(5, 4));
			nYear -= nYear / 100 * 100;
		}
			
	}
	if (strMask == "{_@DNN@}{DAY} {Month_Ccc} {YEAR}")//09 Mar 1997
	{
		if (strTemp.length() < 9) {
			//strResult = "";
			return false;
		}
		nDay = common::StringUtils::toInt(strTemp.substr(0, 2));
		for (int i = 0; i < 12; i++)
		{
			if (strTemp.substr(2, 3) == gastrMonths_Ccc[i])
			{
				nMonth = i + 1;
				break;
			}
		}
		nYear = common::StringUtils::toInt(strTemp.substr(5, 4));
		nYear -= nYear / 100 * 100;
	}
	if (strMask == "{_@DNN@}{DAY} {MONTH} {YEAR}" || strMask == "{_@DNN@}{DAYS_VARIOUS} {MONTH} {YEAR}" || strMask == "{_@DNN@}{DAYS_LZ} {MONTH} {YEAR}")//11 JUN 1992
	{
		if (strTemp.length() < 9) {
			//strResult = "";
			return false;
		}
		nDay = common::StringUtils::toInt(strTemp.substr(0, 2));
		for (int i = 0; i < 12; i++)
		{
			if (strTemp.substr(2, 3) == gastrMonths[i])
			{
				nMonth = i + 1;
				break;
			}
		}
		nYear = common::StringUtils::toInt(strTemp.substr(5, 4));
		nYear -= nYear / 100 * 100;
	}
	if (strMask == "{_@DNN@}{DAY}{MONTH}{YEAR}")//30DEC2019
	{
		if (strTemp.length() < 9) {
			//strResult = "";
			return false;
		}
		nDay = common::StringUtils::toInt(strTemp.substr(0, 2));
		for (int i = 0; i < 12; i++)
		{
			if (strTemp.substr(2, 3) == gastrMonths[i])
			{
				nMonth = i + 1;
				break;
			}
		}
		nYear = common::StringUtils::toInt(strTemp.substr(5, 4));
		nYear -= nYear / 100 * 100;
	}	
	if (strMask == "{_@DNN@}{YEAR}.{MONTH_DD}.{DAY}" || strMask == "{_@DNN@}{YEAR}.{MONTH_DD}.{DAY}|{YEAR}-{MONTH_DD}-{DAY}")
	{
		for (int i = 0; i < strTemp.length(); i++) {
			if (strTemp[i] < '0' || strTemp[i] > '9') {
				strTemp.erase(strTemp.begin() + i);
				i--;
			}
		}
		if (strTemp.length() < 8) {
			//strResult = "";
			return false;
		}
		nYear = common::StringUtils::toInt(strTemp.substr(0, 4));
		nMonth = common::StringUtils::toInt(strTemp.substr(4, 2));
		nDay = common::StringUtils::toInt(strTemp.substr(6, 2));
		nYear -= nYear / 100 * 100;
	}
	if (strMask == "{_@DNN@}{YEAR}.{MONTH_DD}.{DAY}|{YEAR}-{MONTH_DD}-{DAY}")
	{
		for (int i = 0; i < strTemp.length(); i++) {
			if (strTemp[i] < '0' || strTemp[i] > '9') {
				strTemp.erase(strTemp.begin() + i);
				i--;
			}
		}
		if (strTemp.length() < 8) {
			//strResult = "";
			return false;
		}
		nYear = common::StringUtils::toInt(strTemp.substr(0, 4));
		nMonth = common::StringUtils::toInt(strTemp.substr(4, 2));
		nDay = common::StringUtils::toInt(strTemp.substr(6, 2));
		nYear -= nYear / 100 * 100;
	}
	if (strMask == "{_@DNN@}{DAY}-{MONTH_DD}-{YEAR}")//13-02-1982
	{
		for (int i = 0; i < strTemp.length(); i++) {
			if (strTemp[i] < '0' || strTemp[i] > '9') {
				strTemp.erase(strTemp.begin() + i);
				i--;
			}
		}
		if (strTemp.length() < 8) {
			//strResult = "";
			return false;
		}
		nDay = common::StringUtils::toInt(strTemp.substr(0, 2));
		nMonth = common::StringUtils::toInt(strTemp.substr(2, 2));
		nYear = common::StringUtils::toInt(strTemp.substr(4, 4));
		nYear -= nYear / 100 * 100;
	}	
	if (strMask == "{_@DNN@}{DAY}.{MONTH_DD}.{YEAR_DD}|{STRINGS}" || strMask == "{_@DNN,CBR@}{DAY}.{MONTH_DD}.{YEAR_DD}|{STRINGS}" 
		|| strMask == "{_@DNN@}{DAY}.{MONTH_DD}.{YEAR_DD}")//26.07.16
	{
		for (int i = 0; i < strTemp.length(); i++) {
			if (strTemp[i] < '0' || strTemp[i] > '9') {
				strTemp.erase(strTemp.begin() + i);
				i--;
			}
		}
		if (strTemp.length() < 6) {
			//strResult = "";
			return false;
		}
		nDay = common::StringUtils::toInt(strTemp.substr(0, 2));
		nMonth = common::StringUtils::toInt(strTemp.substr(2, 2));
		nYear = common::StringUtils::toInt(strTemp.substr(4, 2));
	}		
	if (nMonth == -1)
		return false;
	else
	{
		formatDateString(strResult, nDay, nMonth, nYear);
		strResult += strReverse;
		return true;
	}
}
///////
void setTextRectEqualFullImgRect(FieldImages & xFieldImage_a1, Field &xField_a2)
{

}

struct ImsegResult //For Imseg result ou
{
	int nFieldType;
	wstring strData;
};


ImSeg::ImSeg()
{
	m_nfield_F4 = 0;
}

ImSeg::~ImSeg()
{
}

int ImSeg::initField(CVisualField &xVisualField_a1, InitConstStructs &xInitConstructs_a2, Field &xField_a3)
{
	ImSegStatic* pImSegStatic = ImSegStatic::obj();
	xField_a3.m_pCVisualF_70 = &xVisualField_a1;
	xField_a3.field_AC = 1;
	xField_a3.m_vTextStruct_58.clear();
	string strMask(xVisualField_a1.szTVF_Mask);

	TextStructManager::getParamFromMask(strMask, xField_a3.m_xFieldParam_4.m_umap_FP_4);
	xField_a3.m_strMask_B0 = strMask;
	vector<string> vSplittedMask = common::StringUtils::Split(strMask, '|');
	if (vSplittedMask.empty()) return 1;
	xField_a3.m_nField_68 = 0;


	bool bFlag_130 = true;
	for (size_t i = 0; i < vSplittedMask.size(); i++)
	{
		string str_48(vSplittedMask[i]);
		FieldMaskEx::convertStaticToSubFields(str_48, vSplittedMask[i]);
		if (xField_a3.param().contain(PROCESS_OPTION_8))
			vSplittedMask[i] = common::StringUtils::Replace(vSplittedMask[i], string(" "), string("{SPACE}"));
		TextStruct xTextStruct;
		if (TextStructManager::splitMask(vSplittedMask[i], xVisualField_a1, xTextStruct))
			return true;

		if (xTextStruct.m_vTextPartStruct_0.size() == 1)
		{
			if (xTextStruct.m_vTextPartStruct_0[0].m_pCVisualSubField_34)
			{
				string str_58(xTextStruct.m_vTextPartStruct_0[0].m_pCVisualSubField_34->m_szTVSF_110);
				if (str_58.find(' ', 0) != -1)
				{
					xTextStruct = TextStruct();
					FieldMaskEx::convertStaticToSubFields(str_58, str_58);
					memcpy(xVisualField_a1.szTVF_Mask, str_58.data(), str_58.size());
					xVisualField_a1.szTVF_Mask[str_58.size()] = 0;

					if (TextStructManager::splitMask(str_58, xVisualField_a1, xTextStruct))
						return 1;
				}
			}
		}

		if (!xTextStruct.m_vTextPartStruct_0.empty())
		{
			string strTmp_r5;
			TextStructManager::initAlphabets(xTextStruct, xVisualField_a1, pImSegStatic->m_xSymbolInfoEx_C4);

			for (size_t j = 0; j < xTextStruct.m_vTextPartStruct_0.size(); j++)
			{
				TextPartLCIDInfo &xTextPartLCIDInfo = xTextStruct.m_vTextPartStruct_0[j].m_xTextPartLCIDInfo_70;
				xTextPartLCIDInfo.setAsMainLcid(xField_a3.m_pCVisualF_70->xTVF_Font.m_sFF_LCID);

				int nLcid = xTextPartLCIDInfo.lcid();
				if (xTextStruct.m_vTextPartStruct_0[j].m_bField_38 && nLcid)
				{
					size_t k;
					for (k = 0; k < xField_a3.m_vnLcid_A0.size(); k++)
						if (xField_a3.m_vnLcid_A0[k] == nLcid) break;

					if (k == xField_a3.m_vnLcid_A0.size())
						xField_a3.m_vnLcid_A0.push_back(nLcid);
				}
			}

			xField_a3.m_vTextStruct_58.push_back(xTextStruct);
			if (xField_a3.m_nField_68 != -1 && xTextStruct.m_nLineCount_2C != -1 && xField_a3.m_nField_68 < xTextStruct.m_nLineCount_2C)
				xField_a3.m_nField_68 = xTextStruct.m_nLineCount_2C;
			else xField_a3.m_nField_68 = -1;

			if (bFlag_130)
				bFlag_130 = xTextStruct.m_bField_1D == 0;
		}

		if (!bFlag_130)
			xField_a3.m_pCVisualF_70->xTVF_Font.m_sFF_LongSpace = 10;

		if (xField_a3.m_vTextStruct_58.size() == 1)
			TextStructManager::maskAnalize(xField_a3.m_vTextStruct_58[0], xField_a3.m_xFieldParam_4);

		if (xField_a3.m_vTextStruct_58.empty()) return 1;

		if (xField_a3.m_vnLcid_A0.empty())
			xField_a3.m_vnLcid_A0.push_back(0);

		vector<int> vAlphabet;
		CAlphabetContainer xAlphabetContainer;
		for (size_t j = 0; j < xField_a3.m_vTextStruct_58.size(); j++)
			xAlphabetContainer.append(xField_a3.m_vTextStruct_58[j].m_xCAlphaF_30.m_vAlphabet_0);
		xAlphabetContainer.get(vAlphabet);

		xField_a3.m_xCAlphaF_74.initByUnicode(vAlphabet);

		SymbolsFilter::symbolsType(pImSegStatic->m_xSymbols_4C.m_xSymbolsInfoByUnicode_4C,
			xField_a3.m_xCAlphaF_74.m_vAlphabet_0, xField_a3.m_nsymbolType_9C, xField_a3.m_nsymbolsTails_98);
		xField_a3.field_AC = 0;
	}

	return false;
}

int ImSeg::process(CVisualField &xCVF_a1, LayerParam &xLP_a2, Field &xField_a3, FontDesc &xFD_a4, bool b_a5)
{
	int res = 0;
	CBufferImage _xCBufImg_84;
	set<int> _setn_38;
	Text _Text_A4;
	vector<Text*> _vpText_54;
	vector<int> _vn_60, _vn_6C;

	xField_a3.m_nTextStructIdx_64 = -1;
	_Text_A4.init(xField_a3.m_vText_4C);

	if (xField_a3.m_vnLcid_A0.empty())
		_Text_A4.m_nLcid_18 = xField_a3.m_pCVisualF_70->xTVF_Font.m_sFF_LCID;
	else
		_Text_A4.m_nLcid_18 = xField_a3.m_vnLcid_A0.front();

	_xCBufImg_84.load(xField_a3.m_xFieldImages_20.m_vCBufImg_20.front());
	vector<CRecognizedTextDoc> _vCRTD_78(xField_a3.m_vTextStruct_58.size());
	xField_a3.linesList(_vpText_54);
	
	int v25;
	for (size_t i = 0; i < _vCRTD_78.size(); i++)
	{
		if (!TextProcess::generateFieldStructDnn(_Text_A4, xField_a3.m_vTextStruct_58[i]))
		{
			_vn_6C.push_back(i);
			set<int> _setn_48;
			TextInfo::alphabets(xField_a3.m_vTextStruct_58[i], _setn_48);
			for (size_t j = 0; j < xField_a3.m_vTextStruct_58[i].m_xCAlphaF_30.m_vAlphabet_0.size(); j++)
				_setn_38.emplace(xField_a3.m_vTextStruct_58[i].m_xCAlphaF_30.m_vAlphabet_0[j]);

			vector<int> _vn_2C;
			vector<int>::iterator iter = set_difference(_setn_48.begin(), _setn_48.end(), _setn_38.begin(), _setn_38.end(), _vn_2C.begin());
			_vn_2C.erase(iter, _vn_2C.end());
			if (_vn_2C.empty())
				_vn_60.push_back(i);
		}
	}

	if (_vn_6C.empty())
	{
		//no check
		if (xField_a3.m_vTextStruct_58.empty())
			return 1;

		//LOG "ImSeg.dll" "ImSeg::process STRINGS_DEF"
		ListSubField *_pListSubField = RSubFieldManager::subFields();
		if (_pListSubField->indexOf("STRINGS_DEF") == -1)
			return 1;

		string _str_48("{STRINGS_DEF}");
		if (TextStructManager::splitMask(_str_48, xCVF_a1, xField_a3.m_vTextStruct_58[0]))
			return 1;

		xField_a3.m_vTextStruct_58[0].m_xCAlphaF_30 = xField_a3.m_xCAlphaF_74;
		for (size_t k = 0; k < xField_a3.m_vTextStruct_58[0].m_vTextPartStruct_0.size(); k++)
			xField_a3.m_vTextStruct_58[0].m_vTextPartStruct_0[k].m_xCAlphatF_C = xField_a3.m_xCAlphaF_74;
		if (!TextProcess::generateFieldStruct(_xCBufImg_84, _Text_A4, xField_a3.m_vTextStruct_58[0]))
			_vn_6C.push_back(0);

		return 1;
	}

	
	if (!_vn_60.empty())
	{
		v25 = _vn_6C[0];
		int v21 = 0, v22 = 0, v23 = 0;
		float v20 = 0;
		for (size_t j = 0; j < _vn_60.size(); j++)
		{
			int _n_38 = 0;
			int _n_48 = 0;
			TextStructManager::numberOfError(xField_a3.m_vTextStruct_58[j], _n_38, _n_48);
			float fProb = xField_a3.m_vTextStruct_58[_vn_60[j]].middleProb();
			if ((_n_48 > v21 && v22 >= _n_38) || (fProb > v20 && _n_48 == v21))
			{
				v20 = fProb;
				v21 = _n_48;
				v22 = _n_38;
				v23 = j;
			}
		}
		v25 = _vn_60[v23];
	}
	xField_a3.m_nTextStructIdx_64 = v25;

	TextStructManager::correctLcids(ImSegStatic::obj()->m_xSymbols_4C.m_xAlphabetInfo_10, ImSegStatic::obj()->m_xSymbols_4C, xField_a3.m_vTextStruct_58[v25]);
	SymbolConflictAnalize::resolveField(xField_a3.m_vTextStruct_58[v25]);
	TextStructManager::correctEnums(xField_a3.m_vTextStruct_58[v25]);
	if (!b_a5)
	{
		//no check
		int v30 = MAX(xLP_a2.m_xFontDesc.m_xFontDescBase_0.m_nFDB_Field_8, xLP_a2.m_xFontDesc.m_xFontDescBase_0.m_nFDB_Field_24);
		LettersFilter::filterByLongSpace(xField_a3.m_vTextStruct_58[v25], v30, xCVF_a1.xTVF_Font.m_sFF_LongSpace);
	}
	TextStructManager::generateWordsInString(xField_a3.m_vTextStruct_58[v25], xFD_a4.m_xFontDescBase_0.m_nFDB_Field_0, 0, b_a5);
	TextStructManager::checkSemantic(ImSegStatic::obj()->m_xSymbols_4C.m_xSymbolsInfoByUnicode_4C, xField_a3.m_vTextStruct_58[v25], ImSegStatic::obj()->m_xInitConstStructs_0, xLP_a2.m_xFontDesc.m_xBaseLines_38, b_a5);
	return 1;
}

int ImSeg::processList(TResultContainerList &xRCL_a2, const char *psz_a3, TResultContainerList **ppRCL_a4, char **ppsz_a5)
{
	RclHolder xRclH;
	DocDescObj docDescObj;
	vector<TResultContainer*> vResultContainer;
	string strVal = "";
	string strSamplePath;
	ImSegStatic *pImsegStatic = ImSegStatic::obj();
	CDocInfo *pDocInfo = NULL;
	TDocVisualExtendedInfo *pTDocVExtInfo = NULL;
	int nRet = 0;

	m_xRclH_18.clear();
	xRclH.addNoCopy(xRCL_a2);
	if (psz_a3) strVal = string(psz_a3);
	if (getDocInfo(xRclH, strVal, docDescObj, m_xPSCtrl_50.isPSC_field_54, &pImsegStatic->m_xFieldsLoadFilter_434)
		|| (pDocInfo = docDescObj.m_pDocInfo_0) == NULL)
	{
		nRet = -3001;
		m_xPSCtrl_50.resetSeries();
	}
	else
	{
		vResultContainer = xRclH.getRcList(71);
		if (vResultContainer.empty())
		{
			strSamplePath = docDescObj.m_xJsonValue_8["samplePath"].asString();
			if (!strSamplePath.empty())
				xRclH.addNewNoCopy<char>(71, (char*)strSamplePath.data());
		}
		else if (!docDescObj.m_xJsonValue_8.isMember("samplePath"))
		{
			if (vResultContainer[0]->u.pTRC_obj)
			{
				strSamplePath = string((char*)vResultContainer[0]->u.pTRC_obj);
				Json::Value jstrSamplePath = strSamplePath;
				docDescObj.m_xJsonValue_8["samplePath"] = Json::Value(jstrSamplePath);
			}
		}

		char* pszTmp = NULL;
		if (!ppsz_a5)
		{
			vResultContainer = xRclH.getRcList(69);
			ppsz_a5 = &pszTmp;
		}

		processList(*pDocInfo, xRclH.m_xTRCL, &pTDocVExtInfo, (char **)ppsz_a5);

		if (pTDocVExtInfo)
		{
			m_xRclH_18.addNewNoCopy<TDocVisualExtendedInfo>(17, pTDocVExtInfo);
			*ppRCL_a4 = &m_xRclH_18.m_xTRCL;
		}

		//Log("ImSeg.dll Fields info generate start");
		getSplitFieldInfo(*pDocInfo, m_s_44);
		if (!m_s_44.empty())
			m_xRclH_18.addNewNoCopy<unsigned char>(52, (unsigned char*)m_s_44.data());
		//Log("ImSeg.dll Fields info generate stop");
		vResultContainer = xRclH.getRcList(69);
		if (!vResultContainer.empty())
		{
			strSamplePath = "";
			if (ppsz_a5)
				strSamplePath = string(*ppsz_a5);

			createTestSample(xRclH, strSamplePath);
		}

	}

	return 0;
}

int ImSeg::processList(CDocInfo &xDocInfo_a1, TResultContainerList &xRCL_a2, TDocVisualExtendedInfo **ppTDocVExtInfo_a3, char **ppsz_a4)
{
	//Log("ImSeg.dll ImSeg::processList start");
	CVisualField *pxVisualField;
	int nDocId = xDocInfo_a1.id();
	ImSegStatic *pImsegStatic = ImSegStatic::obj();
	Configuration* pConfiguration = Configuration::obj();
	RclHolder xRclH;
	vector<TResultContainer*> vResultContainer;
	vector<CVisualField*> vpVisualField;
	multimap<int, int> multimap_nn;
	vector<int> vnKey;

	pConfiguration->m_nDocId = nDocId;
	xRclH.addNoCopy(xRCL_a2);
	vResultContainer = xRclH.getRcList(1); //화상들을 얻는다.
	m_xRecognizedTextDoc_2C.reset(); //m_xRecognizedTextDoc_2C를 초기화한다.
	*ppTDocVExtInfo_a3 = (TDocVisualExtendedInfo *)&m_xRecognizedTextDoc_2C;
	pImsegStatic->m_bField_D8 = 0;
	if (xDocInfo_a1.nTDI_DocType <= -1)
	{
		pImsegStatic->m_bField_D8 = 1;
		m_xRecognizedTextDoc_2C.add();
	}

	m_xPSCtrl_50.m_mapnn_5C.clear();
	for (int i = 0; i < xDocInfo_a1.count(); i++)
	{
		pxVisualField = xDocInfo_a1.get(i);
		if (pxVisualField->isPerforation())
		{
			int nType = pxVisualField->getType();
			m_xPSCtrl_50.m_mapnn_5C[nType] = i;
			if (pxVisualField->sTVF_status)
				vpVisualField.push_back(pxVisualField);
		}
		else if (pxVisualField->sTVF_status)
		{
			pair<int, int> item(pxVisualField->xTVF_Font.m_nFF_layer, i);
			if (!item.first) item.first = i + 100;
			multimap_nn.insert(item);
		}
	}

	vnKey = mapKeys<int, int>(multimap_nn);
	sort(vnKey.begin(), vnKey.end());

	vector<Layer_R> vLayer_160(vnKey.size());
	vector<float> vf_16C(vnKey.size(), 1.0f);
	vector<int> vn_178(vnKey.size(), 0);
	vector<uint> vun_184(vnKey.size());
	vector<cv::Rect> vRect_190;
	for (size_t i = 0; i < vnKey.size(); i++)
	{
		FontDescBase &xFontDescBase = vLayer_160[i].m_xParam_14.m_xFontDesc.m_xFontDescBase_0;
		//Log("ImSeg.dll ImSeg::processList Layer = %d" ,vnKey[i]);
		vector<int> vnValue = mapValues<int, int>(multimap_nn, vnKey[i]);
		vun_184[i] = i;
		sort(vnValue.begin(), vnValue.end(), greater<int>());
		if (!vnValue.empty())
		{
			vLayer_160[i].m_pSymboInfoEx_10 = &pImsegStatic->m_xSymbolInfoEx_C4;
			pxVisualField = xDocInfo_a1.get(vnValue[0]);
			int nHeightAbs = pxVisualField->xTVF_Font.m_nFF_HeightAbs;
			if (pImsegStatic->m_nBestSymbolH_DC && nHeightAbs > pImsegStatic->m_nBestSymbolH_DC)
			{
				float r_v24 = (float)pImsegStatic->m_nBestSymbolH_DC / (float)nHeightAbs;
				vf_16C[i] = r_v24;
				nHeightAbs = int(r_v24 * (float)nHeightAbs);
			}
			xFontDescBase.m_nFDB_Field_4 = nHeightAbs;
			if (!nHeightAbs) return 1;
			xFontDescBase.m_nFDB_Field_0 = pxVisualField->xTVF_Font.m_cFF_VarHeight;
		}

		for (size_t j = 0; j < vnValue.size(); j++)
		{
			if (xFontDescBase.m_nFDB_Field_30 < xDocInfo_a1.get(vnValue[j])->xTVF_Font.m_sFF_LongSpace)
				xFontDescBase.m_nFDB_Field_30 = xDocInfo_a1.get(vnValue[j])->xTVF_Font.m_sFF_LongSpace;
		}

		vLayer_160[i].resize(vnValue.size());
		for (size_t j = 0; j < vLayer_160[i].size(); j++)
		{
			if (xDocInfo_a1.get(vnValue[j])->xTVF_Font.m_nFF_HeightAbs)
			{
				InitConstStructs xInitConstruncts;//unsuesd
				initField(*xDocInfo_a1.get(vnValue[j]), xInitConstruncts, vLayer_160[i][j]);
			}
		}

		for (size_t j = 0; j < vLayer_160[i].size(); j++)
		{
			pxVisualField = xDocInfo_a1.get(vnValue[j]);
			//vLayer_160[i][j].m_xFieldImages_20에 TextLines에 들어가는 화상,vRect_190에는 령역
			int n_ret = imseg::fieldpreprocess::process(xRCL_a2, *pxVisualField,
				vLayer_160[i][j].m_xFieldImages_20, vf_16C[i], vRect_190, 0);
			vn_178[i] = n_ret;

			if (ConfigByLCID::isBankCardLcid(pxVisualField->u.s.sTVF_wFieldType))
				vLayer_160[i].setRecognizeMeAllwaysWithoutTextDetection(1);
			if (!vn_178[i] && pxVisualField->xTVF_Font.m_cFF_emptyFieldToResult)
			{
				int nLightType = pxVisualField->getLightType();
				//no check
				generateEmptyTextResults(vLayer_160[i][j], nLightType, m_xRecognizedTextDoc_2C);
			}
		}
	}


	updateFieldsOrder(vLayer_160, vnKey, vun_184);
	vector<vector<TDetectedField>> vvDetectedField_19C(vLayer_160.size());
	bool b_v340 = false;
	Json::Value jstrResult;
	string strResult;

	vector<ImsegResult> vImsegResult;

	for (size_t i = 0; i < vun_184.size(); i++)
	{
		if (vResultContainer.empty())
		{
			string strResult;
			generateFieldGenerateInfo(vLayer_160[vun_184[i]], jstrResult);
			//common::container::jsoncpp::convert(jstrResult, strResult);
			break;
		}
		vector<int> vn_1A8 = common::mapValues<int, int>(multimap_nn, vnKey[vun_184[i]]);
		sort(vn_1A8.begin(), vn_1A8.end(), greater<int>());

		if (vn_1A8.empty()) continue;

		int n_v51;
		if (vnKey[vun_184[i]] > 98) n_v51 = i + 1;
		else n_v51 = vun_184.size();
		//Layer_R &xLayer = vLayer_160[vun_184[i]];
		//FontDesc &xFontDesc = xLayer.m_xParam_14.m_xFontDesc;
		VLinesCandidates xVLineCandidates_A0;

		if (!b_v340)
		{
			b_v340 = 0;
			for (int j = i; j < n_v51; j++)
			{
				vector<int> vn_25C = common::mapValues<int, int>(multimap_nn, vnKey[vun_184[j]]);
				sort(vn_25C.begin(), vn_25C.end());
				if (vn_25C.empty()) continue;


				Field* pField = NULL;

				for (size_t k = 0; k < vLayer_160[vun_184[j]].size(); k++)
				{
					pField = &vLayer_160[vun_184[j]][k];
					if (vn_178[vun_184[j]])
					{
						pField->m_bField_6C = true;
						continue;
					}
					if (!vRect_190.empty())
						removeRectsFromImage(vRect_190, vf_16C[vun_184[j]], vLayer_160[vun_184[j]][k]);
					if (!vLayer_160[vun_184[j]].recognizeMeAllwaysWithoutTextDetection())
					{
						pxVisualField = xDocInfo_a1.get(vn_25C[k]);
						vector<int> vHist(257, 0);

						CBufferImage &xImg = pField->m_xFieldImages_20.m_vCBufImg_20[0];
						RCvMat::histogramRange(xImg, 256, &vHist[0]);
						float r_v78 = pxVisualField->xTVF_Font.m_rFF_HeightRel * (pxVisualField->xTVF_Font.m_rFF_HeightRel / 3.0f);
						int nImgWidth = xImg.width();
						int nImgHeight = xImg.height();

						int n_vA0 = 0;
						int n_v298;
						int n_v2C8;
						if (RAnalyse::dynamicRange(&vHist[0], 256, (int)r_v78, int((nImgHeight * nImgWidth) * 0.05f), n_vA0, n_v298, n_v2C8))
						{
							pField->m_bField_6C = 1;
							continue;
						}
					}

					vector<TextStruct> vTextStruct = pField->m_vTextStruct_58;
					if (!vTextStruct.empty())
					{
						vector<int> vUnicFieldTypeList = TextStructManager::getUnicFieldTypeList(vTextStruct[0]);
						for (size_t t = 0; t < vUnicFieldTypeList.size(); t++)
						{
							m_xPSCtrl_50.m_mapnn_5C[vUnicFieldTypeList[t]] = vn_25C[k];
							if (pField->m_xFieldParam_4.contain(PROCESS_OPTION_8))
								m_xPSCtrl_50.m_vn_68.push_back(vUnicFieldTypeList[t]);
						}
					}
				}
				//Line 626      
				xVLineCandidates_A0.m_vLinesCandidates.resize(vn_25C.size());
				for (size_t k = 0; k < xVLineCandidates_A0.m_vLinesCandidates.size(); k++)
				{
					if (k < vLayer_160[vun_184[j]].size())
					{
						pField = &vLayer_160[vun_184[j]][k];
						if (!pField->m_bField_6C && !pField->m_vTextStruct_58.empty())
						{
							CBufferImage &xImg = pField->m_xFieldImages_20.m_vCBufImg_20[1];
							xVLineCandidates_A0.m_vLinesCandidates[k].generatePoints(xImg,
								vLayer_160[vun_184[j]].m_xParam_14.m_xFontDesc, pField->m_xFieldParam_4, pImsegStatic->m_xInitConstStructs_0);
						}
					}
				}

				float rAngle = 0.0;
				xVLineCandidates_A0.findAngle(pImsegStatic->m_xInitConstStructs_0, vLayer_160[vun_184[j]].m_xParam_14.m_xFontDesc, rAngle);
				vector<vector<CBufferImage *>> vImages = vLayer_160[vun_184[j]].images();
				xVLineCandidates_A0.rotate(vImages);

				int nSymbolsTails = 0;
				for (size_t k = 0; k < vLayer_160[vun_184[j]].size(); k++)
					nSymbolsTails |= vLayer_160[vun_184[j]][k].symbolsTails();
				if (nSymbolsTails & 0x30)
					pImsegStatic->m_xInitConstStructs_0.m_xTLineAnalyzeFirst_0.m_r_30 = 1.5;

				int nSymbolsType = 0;
				for (size_t k = 0; k < vLayer_160[vun_184[j]].size(); k++)
					nSymbolsType |= vLayer_160[vun_184[j]][k].symbolsType();

				int nTmp_100 = 0;
				int nTmp_298 = 0;

				int nDetectMidH = AnalyzeLinesCandidates::detectMiddleH(nSymbolsType & 2, xVLineCandidates_A0,
					(eHType)vLayer_160[vun_184[j]].m_xParam_14.m_xFontDesc.m_xFontDescBase_0.m_nFDB_Field_0,
					vLayer_160[vun_184[j]].m_xParam_14.m_xFontDesc.m_xFontDescBase_0.m_nFDB_Field_4,
					pImsegStatic->m_xInitConstStructs_0, nTmp_100, nTmp_298);
				vn_178[vun_184[j]] = nDetectMidH;

				if (!nDetectMidH)
				{
					vLayer_160[vun_184[j]].m_xParam_14.m_xFontDesc.m_xFontDescBase_0.m_nFDB_Field_8 = nTmp_100;
					vLayer_160[vun_184[j]].m_xParam_14.m_xFontDesc.m_xFontDescBase_0.m_nFDB_Field_C = nTmp_298;
				}
				if (m_nfield_F4 == 1)
				{
					//no check
					int nHeight = vLayer_160[vun_184[j]].m_xParam_14.m_xFontDesc.m_xFontDescBase_0.m_nFDB_Field_4;
					if (vLayer_160[vun_184[j]].m_xParam_14.m_xFontDesc.m_xFontDescBase_0.m_nFDB_Field_8)
						nHeight = vLayer_160[vun_184[j]].m_xParam_14.m_xFontDesc.m_xFontDescBase_0.m_nFDB_Field_8;
					for (size_t k = 0; k < vLayer_160[vun_184[j]].size(); k++)
					{
						Mat xFiledImage_100 = RCvMat::ref(vLayer_160[vun_184[j]][k].m_xFieldImages_20.m_vCBufImg_20[0]);
						addFieldInfo(xRclH, xFiledImage_100, xDocInfo_a1, *vLayer_160[vun_184[j]][k].m_pCVisualF_70, nHeight);
					}
				}
				else if (m_nfield_F4 == 2)
				{
					//no check
					CRecognizedTextDoc xRecognizedTextDoc_2D4;
					CRecognizedTextFieldSDK *pFieldSDK = NULL;
					pxVisualField = vLayer_160[vun_184[j]][i].m_pCVisualF_70;
					for (size_t k = 0; k < vLayer_160[vun_184[j]].size(); k++)
					{
						pFieldSDK = xRecognizedTextDoc_2D4.add();
						common::field::setFieldType(*pFieldSDK, (eVisualFieldType)pxVisualField->u.s.sTVF_wFieldType);
						pFieldSDK->u0.s0.wLCID = pxVisualField->u.s.sTVF_wLCID;
						pFieldSDK->u.xDVEF_FieldRect = pxVisualField->xTVF_Region;

						Mat xMatTmp = RCvMat::ref(vLayer_160[vun_184[j]][i].m_xFieldImages_20.m_vCBufImg_20[0], 0);
						vector<uchar> vucData;
						vector<int> vTmp_240;
						imencode(".jpg", xMatTmp, vucData, vTmp_240);
						pFieldSDK->pszDVEF_Buf_Text = new char[vucData.size()];
						pFieldSDK->nDVEF_Buf_Length = vucData.size();
						pFieldSDK->nDVEF_Reserved2 = true;
						memcpy(pFieldSDK->pszDVEF_Buf_Text, vucData.data(), vucData.size());
					}
				}
				else
				{
					bool bNotFastCv = m_xJsonValue_0["DetectLineType"] != Json::Value("FastCv");
					if (bNotFastCv)
					{
						vector<vector<tagRECT>> vvRect;
						int n_ret = AnalyzeLinesCandidates::analize(xVLineCandidates_A0, vLayer_160[vun_184[j]].m_xParam_14.m_xFontDesc,
							pImsegStatic->m_xInitConstStructs_0, nSymbolsType & 2, vvRect);
						vn_178[vun_184[j]] = n_ret;
						for(size_t k1 = 0; k1 < vvRect.size(); k1++){
							for (size_t k2 = 0; k2 < vvRect[k1].size(); k2++) {
								for (size_t k3 = 0; k3 < k2; k3++) {
									if ((vvRect[k1][k3].bottom < vvRect[k1][k2].top) && (vvRect[k1][k3].bottom > vvRect[k1][k2].bottom)
										|| (vvRect[k1][k3].top < vvRect[k1][k2].top) && (vvRect[k1][k3].top > vvRect[k1][k2].bottom)
										|| (vvRect[k1][k2].top < vvRect[k1][k3].top) && (vvRect[k1][k2].top > vvRect[k1][k3].bottom)
										|| (vvRect[k1][k2].bottom < vvRect[k1][k3].top) && (vvRect[k1][k2].bottom > vvRect[k1][k3].bottom))
									{
										vvRect[k1].erase(vvRect[k1].begin() + k2);
										k2--;
										break;
									}
								}
							}
						}
						if (!n_ret)
						{
							for (size_t k = 0; k < vLayer_160[vun_184[j]].size(); k++)
							{
								LineDetect::sortingLines(vvRect[k]);
								LineDetect::checkRectSize(vLayer_160[vun_184[j]][k].m_xFieldImages_20.m_vCBufImg_20[0], vvRect[k]);
								LineDetect::filterLines(vvRect[k], vLayer_160[vun_184[j]][k].m_nField_68,
									vLayer_160[vun_184[j]][k].m_xFieldImages_20.m_vCBufImg_20[0].height());
								LineDetect::locateLineX(vLayer_160[vun_184[j]][k].m_xFieldImages_20.m_vCBufImg_20[0],
									vLayer_160[vun_184[j]][k].m_xFieldParam_4.m_nFP_0, vvRect[k]);
								vLayer_160[vun_184[j]][k].init(vvRect[k]);
							}
						}

					}
					else
					{
						for (size_t k = 0; k < vLayer_160[vun_184[j]].size(); k++)
						{
							Mat xMatTmp = RCvMat::ref(vLayer_160[vun_184[j]][k].m_xFieldImages_20.m_vCBufImg_20[0]);
							vector<vector<cv::Rect>> vvRect;
							findLines(xMatTmp, vLayer_160[vun_184[j]].m_xParam_14.m_xFontDesc.m_xFontDescBase_0.m_nFDB_Field_8, 0.3f, vvRect);
							vLayer_160[vun_184[j]][k].init(vvRect);
						}
					}

					vvDetectedField_19C[vun_184[j]].resize(vLayer_160[vun_184[j]].size());
					imseg::analyzelines::layerToCoordinates(vLayer_160[vun_184[j]], vf_16C[vun_184[j]], vvDetectedField_19C[vun_184[j]]);
					if (vnKey[vun_184[i]] < 99) 
						b_v340 = 1;
					else  
						b_v340 = 0;
				}
			}
		}

		if (!vvDetectedField_19C[vun_184[i]].empty())
		{
			if (!vn_178[vun_184[i]] || vLayer_160[vun_184[i]].recognizeMeAllwaysWithoutTextDetection())
			{
				int n_v58 = vLayer_160[vun_184[i]].m_xParam_14.m_xFontDesc.m_xFontDescBase_0.m_nFDB_Field_8;
				vLayer_160[vun_184[i]].m_xParam_14.m_xFontDesc.m_xFontDescBase_0.m_nFDB_Field_10 = float(n_v58 * 0.1);
				vLayer_160[vun_184[i]].m_xParam_14.m_xFontDesc.m_xFontDescBase_0.m_nFDB_Field_14 = float(n_v58 * 2.0);
				vLayer_160[vun_184[i]].m_xParam_14.m_xFontDesc.m_xFontDescBase_0.m_nFDB_Field_18 = float(n_v58 * 0.7);
				vLayer_160[vun_184[i]].m_xParam_14.m_xFontDesc.m_xBaseLines_38.setLine(eBaseLinePos_9, 0);
				vLayer_160[vun_184[i]].m_xParam_14.m_xFontDesc.m_xBaseLines_38.setLine(eBaseLinePos_A, n_v58);
				if (pImsegStatic->m_bSaveFieldWithRandomNameInTmpFolder_3F8)
				{
					for (size_t j = 0; j < vLayer_160[vun_184[i]].size(); j++)
					{
						Mat xMatTmp = RCvMat::ref(vLayer_160[vun_184[i]][j].m_xFieldImages_20.m_vCBufImg_20[0]);
						saveFieldWithRandomNameInTmpFolder(xMatTmp, xDocInfo_a1, *vLayer_160[vun_184[i]][j].m_pCVisualF_70, vLayer_160[vun_184[i]][j]);
					}
				}

				vector<int> vn_1CC;
				for (size_t j = 0; j < vLayer_160[vun_184[i]].size(); j++)
				{
					if (!vLayer_160[vun_184[i]][j].m_bField_6C)
					{
						vn_1CC.push_back(j);
					}
				}

				if (!vn_1CC.empty())
				{
					for (size_t j = 0; j < vn_1CC.size(); j++)
					{
						Field* pField = &vLayer_160[vun_184[i]][vn_1CC[j]];
						if (vLayer_160[vun_184[i]].recognizeMeAllwaysWithoutTextDetection())
							setTextRectEqualFullImgRect(pField->m_xFieldImages_20, *pField);

						string strParam;
						TextLines xTextLines(*pField);
						vector<TResultContainer*> vResultContainer1 = xRclH.getRcList(71); //getSamplePath
						if (!vResultContainer1.empty())
						{
							Json::Value jstrParam;
							Json::Value jstrSamplePath((char*)vResultContainer1[0]->u.pTRC_obj);
							jstrParam["samplePath"] = Json::Value(jstrSamplePath);
							Json::Value jstrFieldType(pField->m_pCVisualF_70->u.nTVF_type);
							jstrParam["fieldType"] = Json::Value(jstrFieldType);
							Json::Value jstrLcid(pField->m_pCVisualF_70->u.s.sTVF_wLCID);
							jstrParam["lcid"] = Json::Value(jstrFieldType);
							common::container::jsoncpp::convert(jstrParam, strParam);
						}

						TVocList xTVL = pField->m_pCVisualF_70->getVocList();
						VocabInfo xVocInfo;
						xVocInfo.nCount_0 = pField->m_pCVisualF_70->xTVF_Font.m_sFF_LCID;
						xVocInfo.vData_4 = vector<int>(&xTVL.nnTVL_VocIDList[0], &xTVL.nnTVL_VocIDList[xTVL.nTVL_VocCount]);
						int nLinesCount = xTextLines.getLinesCount();
						string strMask(pField->m_pCVisualF_70->szTVF_Mask);

						ParsedMask xParsedMask;
						ParsedMaskBuilder::buildParsedMask(xParsedMask, *pField, strMask, nLinesCount);
						DbgFolder xDbgH;

						xDbgH.m_xCfsPath_0 = common::fs::Path(pImsegStatic->m_fsTmpPath_E0);

						pImsegStatic->m_xFacadeDNNOCR_3D4.recognize(xTextLines,
							xVocInfo, xParsedMask, (char*)strParam.data(), xDbgH, *pField);

						vector<vector<vector<SymbolCandidatWithRect>>> vvvSysmbolCandidatWidthRect = xTextLines.getResults();
						strMask = xParsedMask.getStringMask();
						if (strMask.find("TRASH") != -1)
							TextStructManager::deleteTrashDublicates(vvvSysmbolCandidatWidthRect);

						TDetectedField xTDetectedField(vvDetectedField_19C[vun_184[i]][vn_1CC[j]]);
						FieldParam xFieldParam = pField->param();
						if (xFieldParam.contain(PROCESS_OPTION_10))
						{
							//no check
							for (size_t k = 0; k < xTDetectedField.m_vtRECT_14.size(); k++)
							{
								cv::Rect rect = imseg::analyzelines::RECTtoCvRect(xTDetectedField.m_vtRECT_14[i]);
								vRect_190.push_back(imseg::rect::addShift(rect, 1));
							}
						}

						/*if (vvvSysmbolCandidatWidthRect.size() > 2)
						{
							vector<vector<SymbolCandidatWithRect>> vvTmp = vvvSysmbolCandidatWidthRect[0];
							for (size_t k = 1; k < vvvSysmbolCandidatWidthRect.size(); k++)
							{
								if (vvvSysmbolCandidatWidthRect[k].size() > vvTmp.size())
								{
									vvTmp = vvvSysmbolCandidatWidthRect[k];
								}
							}

							vvvSysmbolCandidatWidthRect.clear();
							vvvSysmbolCandidatWidthRect.push_back(vvTmp);
						}*/

						strResult = "";
						for (size_t k = 0,t=0; k < vvvSysmbolCandidatWidthRect.size(); k++)
						{
							if (vvvSysmbolCandidatWidthRect[k].empty())
							{
								pField->m_vText_4C.erase(pField->m_vText_4C.begin() + t);
							}
							else
							{
								string strTmp;
								pField->m_vText_4C[t].m_vimsegSymbol_0.clear();
								
								int nHeight = xTextLines.getImgHeight();
								imseg::container::addString(vvvSysmbolCandidatWidthRect[k],
									pField->m_vText_4C[t], strTmp, xFieldParam, nHeight, 0);
								if (!strResult.empty()) strResult += " ";

								int nFind = strTmp.find("C1SSS");
								if (nFind != -1)
								{
									strTmp.erase(nFind, 5);
								}
								nFind = strTmp.find("/");
								if (nFind == strTmp.size() - 1)
								{
									strTmp.erase(nFind, 1);
								}
								if (strTmp == "CS")
									strTmp = "C";
								nFind = strTmp.find("0UL");
								if (nFind != -1)
								{
									strTmp.erase(nFind, 1);
									strTmp.insert(nFind, " J");
								}
								

								strResult += strTmp;
								t++;
							}
						}

//////////////////////////////////////////////////////////////////////////////////////////////////////
						ImsegResult imsegRes;
						imsegRes.nFieldType = pField->m_pCVisualF_70->u.s.sTVF_wFieldType;
						string strRsltMask = pField->m_pCVisualF_70->szTVF_Mask;
						ConverteDateFormat(strRsltMask, strResult);
						imsegRes.strData = common::UnicodeUtils::Utf8ToWStr(strResult);
						vImsegResult.push_back(imsegRes);
//////////////////////////////////////////////////////////////////////////////////////////////////////
						
					}
				}

				for (size_t j = 0; j < MIN(vn_1A8.size(), vLayer_160[vun_184[i]].size()); j++)
				{
					pxVisualField = xDocInfo_a1.get(vn_1A8[j]);
					pxVisualField->u.s.sTVF_wLCID = pxVisualField->xTVF_Font.m_sFF_LCID;
					//process(xVisualField, vLayer_160[vun_184[i]].m_xParam_14, vLayer_160[vun_184[i]][j], vLayer_160[vun_184[i]].m_xParam_14.m_xFontDesc, 1);
				}

				for (size_t j = 0; j < MIN(vn_1A8.size() , 100); j++)
				{
					pxVisualField = xDocInfo_a1.get(vn_1A8[j]);
					int nIdx = vLayer_160[vun_184[i]][j].m_nTextStructIdx_64;
					if (nIdx != -1)
					{
						int nHeight = vLayer_160[vun_184[i]][j].m_xFieldImages_20.m_vCBufImg_20[0].height();
						//TextStructManager::generateResults(vLayer_160[vun_184[i]][j], vLayer_160[vun_184[i]][j].m_vTextStruct_58[nIdx],
						//	xVisualField, m_xRecognizedTextDoc_2C, pImsegStatic->m_bField_D8, nHeight, vf_16C[vun_184[i]]);
					}
				}
				
				if (pImsegStatic->m_xFieldsLoadFilter_434.field_18 != -1)
				{
					//no check
					CRecognizedTextFieldSDK * pCRecognizedTextFieldSDK_v150 = m_xRecognizedTextDoc_2C.add();
					pCRecognizedTextFieldSDK_v150->set(strResult, 9999, VisualFieldType_32);
				}
			}
		}
	}

	fwprintf(g_log.m_fpLog, L"==================== Imseg Results ====================\r\n");

	for (uint i = 0; i < vImsegResult.size(); i++)
	{
		string strFieldName = common::field::textFieldName((eVisualFieldType)vImsegResult[i].nFieldType);
		wstring wstrFieldName = common::UnicodeUtils::Utf8ToWStr(strFieldName);

		fwprintf(g_log.m_fpLog, L"%s : %s\r\n", wstrFieldName.data(), vImsegResult[i].strData.data());
	}

	if (ppsz_a4 && vResultContainer.empty())
	{
		common::container::jsoncpp::convert(jstrResult, m_strResult);
		*ppsz_a4 = (char *)m_strResult.data();
	}
	else
	{
		readPerforationText(vpVisualField, xRCL_a2, m_xRecognizedTextDoc_2C);
		if (ppTDocVExtInfo_a3)
			postcorrect::SymbolFix(*ppTDocVExtInfo_a3);
		if (ppsz_a4)
		{
			Json::Value jstrResult;
			legacycommonlib::jsoncpp::convert(m_xRecognizedTextDoc_2C, jstrResult, 1);
			common::container::jsoncpp::convert(jstrResult, m_strResult);
			*ppsz_a4 = (char *)m_strResult.data();
		}

		//Log("ImSeg.dll ImSeg::processList stop");
	}


	return 0;
}

int ImSeg::processSeries(TResultContainerList &arg1, const char *arg2, TResultContainerList **arg3, char **arg4)
{
	int res = 0;
	map<int, bool> _mapnb_E4;
	m_xPSCtrl_50.m_xRclHolder_28.clear();
	if (arg4)
	{
		Json::Value _xJsonValue_128(0);
		_xJsonValue_128["Result"] = Json::Value(0);
		common::container::jsoncpp::convert(_xJsonValue_128, m_strResult);
		*arg4 = (char *)m_strResult.data();
	}

	RclHolder _xRclHolder_FC(arg1, 1);
	int _nPageIndex_28 = rclhelp::getPage(_xRclHolder_FC.m_xTRCL);
	description::DocDescObj _xDocDescObj_128;
	string m_s_F0(arg2, strlen(arg2));
	bool v17 = description::getDocInfo(_xRclHolder_FC, m_s_F0, _xDocDescObj_128, m_xPSCtrl_50.isPSC_field_54, &ImSegStatic::obj()->m_xFieldsLoadFilter_434);
	CDocInfo *v21 = _xDocDescObj_128.m_pDocInfo_0;
	if (v17 || (!v21))
	{
		m_xPSCtrl_50.resetSeries();
		return -3001;
	}
	m_xPSCtrl_50.isPSC_field_54 = _xDocDescObj_128.field_28;
	Base::resetLayers(*v21);
	bool v23 = m_xPSCtrl_50.m_mapnn_74.empty();
	if (v23)
		v23 = m_xPSCtrl_50.isPSC_field_58 == 0;
	if (!v23)
	{
		for (int i = 0; i < v21->count(); i++)
			v21->get(i)->sTVF_status = 0;
		map<int, int>::iterator iter;
		for (iter = m_xPSCtrl_50.m_mapnn_74.begin(); iter != m_xPSCtrl_50.m_mapnn_74.end(); iter++)
		{
			if (iter->second >= 0 && iter->second < v21->count())
				v21->get(iter->second)->sTVF_status = 1;
		}
		_mapnb_E4 = glare::getFieldGlaresIntersectionMap(*v21, _xRclHolder_FC.m_xTRCL);
	}

	if (arg2)
	{
		Json::Value _xJsonValue_158 = common::container::jsoncpp::convert(arg2);
		if (_xJsonValue_158.isMember("imSegParam"))
		{
			if (_xJsonValue_158["imSegParam"].isMember("seriesProcess"))
			{
				m_xJsonValue_0 = Json::Value(_xJsonValue_158["imSegParam"]["seriesProcess"]);
				series::updateParams(m_xPSCtrl_50, m_xJsonValue_0);
			}
		}
	}

	CRecognizedTextDoc *_pCRecognizedTextDoc_C4 = 0;
	int v12 = processList(*v21, _xRclHolder_FC.m_xTRCL, (TDocVisualExtendedInfo **)_pCRecognizedTextDoc_C4, 0);
	//Log	"ImSeg.dll", "ImSeg::processSeries processList hr = v12"
	//arg2 = (char *)_s_158; Log 결과로 생성된 문자렬
	if (_pCRecognizedTextDoc_C4)
	{
		//Log	"ImSeg.dll"
	}

	bool v36 = 0;
	bool v35 = m_xPSCtrl_50.m_mapnn_74.empty();
	if (v35)
		v35 = m_xPSCtrl_50.isPSC_field_58 == 0;
	if (v35)
	{
		m_xPSCtrl_50.m_mapnn_74 = m_xPSCtrl_50.m_mapnn_5C;
		m_xPSCtrl_50.m_vn_8C.assign(m_xPSCtrl_50.m_vn_68.begin(), m_xPSCtrl_50.m_vn_68.end());
		m_xPSCtrl_50.m_mapnn_80.clear();
		v36 = 1;
	}
	else
		v36 = 0;

	bool v38;
	if (m_xPSCtrl_50.m_nfieldTypeForControlSeries_C == -1)
		v38 = 1;
	else
	{
		bool b158 = 0;
		v38 = series::checkSeries(m_xPSCtrl_50.m_nfieldTypeForControlSeries_C, _pCRecognizedTextDoc_C4, v36, b158);
		if (b158)
		{
			m_xPSCtrl_50.resetSeries();
			return 0;
		}
	}

	map<int, int> _mapnn_B8;
	if (!v12 && _pCRecognizedTextDoc_C4 && v38)
	{
		map<int, int>::iterator iter = m_xPSCtrl_50.m_mapnn_74.begin();
		while (iter != m_xPSCtrl_50.m_mapnn_74.end())
		{
			bool v42 = 0;
			if (m_xPSCtrl_50.m_setn_1C.size())
				v42 = common::contains(m_xPSCtrl_50.m_setn_1C, iter->first);

			if (!v42 && (_pCRecognizedTextDoc_C4->find((eVisualFieldType)iter->first) == 0))
				m_xPSCtrl_50.m_mapnn_80[iter->first] += 1;
			else
				m_xPSCtrl_50.m_mapnn_80[iter->first] = 0;
			iter++;
		}

		string _s_158;
		arg2 = (char *)_s_158.data();
		CRecognizedTextFieldSDK *v49;
		for (int j = 0; j < _pCRecognizedTextDoc_C4->nDVEI_Fields; j++)
		{
			v49 = (CRecognizedTextFieldSDK *)&_pCRecognizedTextDoc_C4->pDVEI_ArrayFields[j];
			int v50 = v49->getTypeFull();
			if (m_xPSCtrl_50.m_xCRecognizedTextDoc_48.find((eVisualFieldType)v50))
				continue;
			if (m_xPSCtrl_50.m_nminTextLenForResult_10)
			{
				if (v49->nDVEF_Buf_Length < m_xPSCtrl_50.m_nminTextLenForResult_10)
					continue;
				_s_158 = string(v49->pszDVEF_FieldMask);
				if (_s_158 == "{STRINGS_DEF}")
					continue;
			}

			int v57 = v49->getTypeFull();
			CVisualField *v58 = v21->find(v57);
			bool v59 = 0;
			if (v58)
				v59 = v58->isPerforation();
			else
				v59 = 0;
			vector<shared_ptr<CRecognizedTextFieldSDK>> *v60 = &m_xPSCtrl_50.m_mapnvspCRecognizedTextFieldSDK_98[v57];
			bool v23 = v59 == 0;
			bool LABEL_167 = 0;
			if (v23)
			{
				int v62 = v49->getTypeFull();
				vector<int>::iterator iter2 = m_xPSCtrl_50.m_vn_8C.begin();
				bool v66, v66_ = 0;
				for (; iter2 != m_xPSCtrl_50.m_vn_8C.end(); iter2++)
				{
					if (*iter2 == v62)
					{
						v66_ = 1;
						break;
					}
				}
				if (v66_)
					v66 = series::checkReadyFieldDnn(*v60, *v49, _mapnb_E4, m_xPSCtrl_50.m_nconfirmResultCount_14, m_xPSCtrl_50.m_nminProbThresholdDnn_14);
				else
					v66 = series::checkReadyFieldDnnOff(*v49, (float)m_xPSCtrl_50.m_nMinProbForFieldRecogn_0);
				if (!v66)
				{
					shared_ptr<CRecognizedTextFieldSDK> _spCRecognizedTextFieldSDK;
					_spCRecognizedTextFieldSDK.get()->set(v49);
					v60->push_back(_spCRecognizedTextFieldSDK);
					//Log	"ImSeg.dll", "ImSegNS::ProcessCommand::processSeries fields variants (%d)(%d): %d"
				}
				else
					LABEL_167 = 1;
			}

			if (!v23 || LABEL_167)
			{//LABEL_167
				CRecognizedTextFieldSDK *v67 = m_xPSCtrl_50.m_xCRecognizedTextDoc_48.add();
				v67->set(v49);
				v60->clear();
				arg2 = (char *)_s_158.data();
			}
			//Log	"ImSeg.dll", "ImSegNS::ProcessCommand::processSeries fields variants (%d)(%d): %d"

		}
	}

	//Lable_97
	map<int, int>::iterator iter;
	string _s_A8;
	for (iter = m_xPSCtrl_50.m_mapnn_74.begin(); iter != m_xPSCtrl_50.m_mapnn_74.end(); iter++)
	{
		if ((m_xPSCtrl_50.m_mapnn_80[iter->first] <= 1) &&
			(!m_xPSCtrl_50.m_xCRecognizedTextDoc_48.find((eVisualFieldType)iter->first) || m_xPSCtrl_50.m_nfieldTypeForControlSeries_C == iter->first))
		{
			_mapnn_B8.emplace(pair<int, int>(iter->first, iter->second));
			CVisualField *v84 = v21->get(iter->second);
			string _s_158 = StringUtils::toString<ushort>(v84->u.s.sTVF_wFieldType);
			_s_A8.append(_s_158.data(), _s_158.size());
			_s_A8.append(",");
		}
	}
	//Log "ImSeg.dll" "ImSegNS::ProcessCommand::processSeries: Not ready fields (%d): %s"
	map<int, int>* _pmapnn_2C;
	_pmapnn_2C = &_mapnn_B8;
	if (m_xPSCtrl_50.m_mapnn_74.size() <= 3)
	{
		map<int, int>::iterator iter;
		for (iter = m_xPSCtrl_50.m_mapnn_74.begin(); iter != m_xPSCtrl_50.m_mapnn_74.end(); iter++)
		{
			//Log "ImSeg.dll" "ImSegNS::ProcessCommand::processSeries: field = %d , candidates = %d "
		}
		if (m_xPSCtrl_50.m_mapnn_74.empty())
			m_xPSCtrl_50.isPSC_field_58 = 1;
	}
	m_xPSCtrl_50.m_xCRecognizedTextDoc_3C = m_xPSCtrl_50.m_xCRecognizedTextDoc_48;
	map<int, vector<shared_ptr<CRecognizedTextFieldSDK>>>::iterator iter1 = m_xPSCtrl_50.m_mapnvspCRecognizedTextFieldSDK_98.begin();
	for (; iter1 != m_xPSCtrl_50.m_mapnvspCRecognizedTextFieldSDK_98.end(); iter1++)
	{
		vector<shared_ptr<CRecognizedTextFieldSDK>> *_vspCRTFSDK = &iter1->second;
		if (!_vspCRTFSDK->empty())
		{
			int _v102 = common::indexOf<vector<int>, int>(m_xPSCtrl_50.m_vn_8C, iter1->first);
			CRecognizedTextFieldSDK *v102 = 0;
			if (_v102 == -1)
				v102 = series::chooseMostProbableResultDnnOff(iter1->second, float(m_xPSCtrl_50.m_nMinProbForFieldRecognLastStep_4));
			else
				v102 = series::chooseMostProbableResultDnn(iter1->second);
			if (v102)
			{
				CRecognizedTextFieldSDK *v104 = m_xPSCtrl_50.m_xCRecognizedTextDoc_3C.add();
				v104->set(v102);
			}
		}
	}

	if (arg3)
	{
		CRecognizedTextDoc _xCRecognizedTextDoc_98;
		Base::removeFields(m_xPSCtrl_50.m_xCRecognizedTextDoc_3C, _xCRecognizedTextDoc_98, ImSegStatic::obj()->m_vn_3C8);
		CRecognizedTextDoc _xCRecognizedTextDoc_88;
		vector<int> _vn_70;
		int byte_1079128[6] = { 8, 9, 0x81, 0xC, 5, 2 };
		for (int i = 0; i < 6; i++)
			_vn_70.push_back(byte_1079128[i]);
		Base::sortFields(_xCRecognizedTextDoc_98, _xCRecognizedTextDoc_88, _vn_70);
		if (_xCRecognizedTextDoc_88.count())
		{
			//Log "ImSeg.dll"
			m_xPSCtrl_50.m_xRclHolder_28.addNewCopy<CRecognizedTextDoc>(17, &_xCRecognizedTextDoc_88, 0);
		}
		//debug::fieldsinfo::getSplitFieldInfo(*v21, m_s_44);
		if (m_s_44.size())
			m_xPSCtrl_50.m_xRclHolder_28.addNewNoCopy<uchar>(52, (uchar*)m_s_44.data(), m_s_44.size());
		m_xPSCtrl_50.m_xRclHolder_28.setPageIndex(_nPageIndex_28);
		*arg3 = &m_xPSCtrl_50.m_xRclHolder_28.m_xTRCL;
	}

	if (m_xPSCtrl_50.isPSC_field_58)
	{
		//Log	"ImSeg.dll", "ImSegNS::ProcessCommand::processSeries FINISH series!"
		if (arg4)
		{
			Json::Value _xJsonValue_158(0);
			_xJsonValue_158["Result"] = Json::Value(1);
			common::container::jsoncpp::convert(_xJsonValue_158, m_strResult);
			*arg4 = (char *)m_strResult.data();
		}
		res = 0;
	}
	else
		res = -3326;
	return res;
}

void ImSeg::readPerforationText(vector<CVisualField *> &arg1, TResultContainerList &arg2, CRecognizedTextDoc &arg3)
{
	/*Field _xField_84;
	vector<Rect> _vRect_74;
	int _n_80;
	Mat _Mat_140;
	for (int i = 0; i < arg1.size(); i++)
	{
		fieldpreprocess::process(arg2, *arg1[i], _xField_84.m_xFieldImages_20, 1.0, _vRect_74, &_n_80);
		_Mat_140 = RCvMat::ref(_xField_84.m_xFieldImages_20.m_vCBufImg_20[i]);
		unique_ptr<TRawImageContainer, TRawImageContainer*(*)(TRawImageContainer*)> uniq_6C = common::container::copyMatToRic(_Mat_140, _n_80, _n_80);
		RclHolder _RclHolder_140;
		_RclHolder_140.addNewWithOwnership<TRawImageContainer>(1, uniq_6C.get(), RPRM_Lights_0);
		_RclHolder_140.m_xTRCL.pTRCL_TRC->nTRC_light = RPRM_Lights_6;
		RclHolder _RclHolder_58;
		string _s_28, _s_48;
		//                                 0x3391
		int v13 = 0;// moduleprocessgl::process(13201, &_Mat_140, (char *)&_s_28, (void **)&_RclHolder_58, (char **)&_s_48);
		if (!v13)
		{
			vector<TResultContainer*> _vpTResultContainer_3C = _RclHolder_58.getRcList(17);
			CRecognizedTextDoc *v13;
			bool v14 = 0;
			if (!_vpTResultContainer_3C.empty())
			{
				v13 = (CRecognizedTextDoc *)_vpTResultContainer_3C.front()->u.pTRC_obj;
				v14 = v13 == 0;
			}
			if (!v14)
			{
				CRecognizedTextFieldSDK *_pCRecognizedTextFieldSDK_14 = arg3.add();
				_pCRecognizedTextFieldSDK_14 = v13->at(0);
				eVisualFieldType v17 = arg1[i]->getType();
				common::field::setFieldType(*_pCRecognizedTextFieldSDK_14, v17);
				_pCRecognizedTextFieldSDK_14->u.xDVEF_FieldRect = arg1[i]->getRegion();
				if (!(ImSegStatic::obj()->m_bField_D8 + arg1[i]->u.s.sTVF_wFieldType))
				{
					CRecognizedTextFieldSDK *v20 = arg3.field(0);
					v20 = _pCRecognizedTextFieldSDK_14;
				}
			}

			if (uniq_6C.get())
				uniq_6C.get_deleter();

		}
	}*/
}

void postcorrect::SymbolFix(TDocVisualExtendedInfo *pTDVEInfo)
{
	typedef tuple<string, string, string> triplestr;
	vector<triplestr> _vtuple_sss_7C;
	if (pTDVEInfo)
	{
		triplestr _tuple1("ы", "ьі", "ь");
		_vtuple_sss_7C.push_back(_tuple1);
		triplestr _tuple2("Ы", "ЬІ", "Ь");
		_vtuple_sss_7C.push_back(_tuple2);

		TDocVisualExtendedField *pCRTFSDK_i, *pCRTFSDK_j;
		for (int i = 0; i < pTDVEInfo->nDVEI_Fields; i++)
		{
			pCRTFSDK_i = &pTDVEInfo->pDVEI_ArrayFields[i];
			if (pCRTFSDK_i->u0.s0.wLCID == 1059 && pCRTFSDK_i->pszDVEF_Buf_Text)
			{
				for (int j = 0; j < pTDVEInfo->nDVEI_Fields; j++)
				{
					pCRTFSDK_j = &pTDVEInfo->pDVEI_ArrayFields[j];
					if (pCRTFSDK_j->u0.s0.wFieldType == pCRTFSDK_i->u0.s0.wFieldType && pCRTFSDK_j->u0.s0.wLCID == 1049 && pCRTFSDK_j->pszDVEF_Buf_Text)
					{
						string _s_58((char*)pCRTFSDK_j->pszDVEF_Buf_Text);
						string _s_48((char*)pCRTFSDK_i->pszDVEF_Buf_Text);
						string _s_3C, _s_30, _s_24;
						for (size_t k = 0; k < _vtuple_sss_7C.size(); k++)
						{
							_s_3C = get<0>(_vtuple_sss_7C[k]);
							_s_30 = get<1>(_vtuple_sss_7C[k]);
							_s_24 = get<2>(_vtuple_sss_7C[k]);

							int nSearchPos_v20;
							if (_s_3C.size())
								nSearchPos_v20 = _s_48.find(_s_3C);
							else
								nSearchPos_v20 = 0;

							int nSearchPos_v27;
							if (_s_24.size())
								nSearchPos_v27 = _s_58.find(_s_3C);
							else
								nSearchPos_v27 = 0;

							bool bTmp_v18 = nSearchPos_v20 == -1;
							if (nSearchPos_v20 != -1)
								bTmp_v18 = nSearchPos_v27 == -1;
							if (!bTmp_v18)
							{
								//PKS_!!!
								if (1)
								{
									_s_48.replace(nSearchPos_v20, _s_3C.size(), _s_30.data(), _s_30.size());
									delete [] pCRTFSDK_i->pszDVEF_Buf_Text;
									pCRTFSDK_i->nDVEF_Buf_Length = _s_48.size();
									pCRTFSDK_i->pszDVEF_Buf_Text = new char[_s_48.size()];
									strcpy(pCRTFSDK_i->pszDVEF_Buf_Text, _s_48.data());
									break;
								}
							}

						}
					}
				}
			}
		}
	}
}
