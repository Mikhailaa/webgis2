#pragma once
#include "TLineAnalyzeFirst.h"
#include "Json/Value.h"
class InitConstStructs
{
public:
	TLineAnalyzeFirst m_xTLineAnalyzeFirst_0;
	int minSpace;
	int threshMinSymbolPr;
	int threshDiffProb;
	int dinRange;

	void initFromIni(Json::Value &);
	InitConstStructs();
};