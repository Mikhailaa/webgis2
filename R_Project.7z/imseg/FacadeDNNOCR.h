#pragma once
#include "imseg_interface.h"
#include "Ensemble.h"
#include "LCIDPriority.h"
#include "VocabInfo.h"
#include "ParsedMask.h"
#include "Field.h"
#include "Seq2MaskAligner.h"
#include "SeqConfidenceVouter.h"
#include "ImgNormalizer.h"
#include "ImgNormalizerTTA.h"

namespace imseg
{
	class FacadeDNNOCR
	{
	public:
		FacadeDNNOCR();
		~FacadeDNNOCR();
		vector<uint> addNumberToAlphabet(string const&, vector<uint> const&);
		Ensemble* getMostSuitableEnsemble(uint);
		ITextDetector* getMostSuitableTextDetector(uint);
		uint getTopPriorityLCID(ParsedMask &);
		//load(string &);
		void recognize(TextLines &, VocabInfo const&, ParsedMask &, char const*, DbgFolder const&, Field &);
		RichTextLines refineTextDetection(uint, RichTextLines &);

		int load(istringstream &);

		map<uint, Ensemble> m_tFDNNO_field_0;
		map<uint, shared_ptr<ITextDetector>> m_tFDNNO_field__C;
		LCIDPriority m_xFDNNO_LCIDP__18;
	};

}