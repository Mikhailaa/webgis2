#pragma once
#include "imseg_interface.h"
#include "CTCHypoth.h"

namespace imseg
{
	class Idx
	{
	public:
		vector<int> m_vn_0;
		float m_rIdx_C;

		Idx();
		Idx(Idx const&);
		Idx&operator=(Idx const&);
	};

	class LuhnCheckSumCorrector : public ICorrector
	{
	public:
		int m_nLuhnCheckSumCorrector_8;
		int m_nLuhnCheckSumCorrector_C;

		LuhnCheckSumCorrector(ICorrector*);
		~LuhnCheckSumCorrector();
		void calcProb(vector<CTCHypoth>&, Idx&);
		vector<int> idxToNumbers(vector<CTCHypoth>&, Idx&);
		list<Idx> incrementEach(vector<CTCHypoth>&, Idx&);
		void initIdxs(vector<CTCHypoth>&, vector<int>&);
		bool isCheckSumCorrect(vector<int>&);
		void setNumbers(vector<int>&, vector<CTCHypoth>&);
		virtual void process_impl(vector<CTCHypoth> &);
	};
}