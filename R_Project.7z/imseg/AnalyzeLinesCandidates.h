#pragma once 
#include "commonStruct.h"
#include "FontDesc.h"
#include "InitConstStructs.h"
#include "VLinesCandidates.h"


class AnalyzeLinesCandidates
{
public:
	static int analize(VLinesCandidates &, FontDesc &, InitConstStructs &, LetterType, vector<vector<tagRECT>> &);
	static void detectLinesUsingMiddleH(VLinesCandidates &, eHType, int &, InitConstStructs &, LetterType, int &, vector<vector<tagRECT>> &);//ToDo
	static int detectMiddleH(LetterType, VLinesCandidates &, eHType, int &, InitConstStructs &, int &, int &);
	static int findAngleUsingLines(vector<TPointEx> &, int, int, int, float, float &);//ToDo
	//static void isOnlyBigLetter(int &, int &, VLinesCandidates &, InitConstStructs &);
	static void updateProbs(int, int, vector<int> &, multimap<int, int>&, vector<float>&);//ToDo
};