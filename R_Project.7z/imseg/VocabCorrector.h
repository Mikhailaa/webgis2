#pragma once
#include "imseg_interface.h"
#include "CTCHypoth.h"
#include "VocabInfo.h"

namespace imseg
{
	struct ConfusedPair
	{
		int m_nField_0;
		int m_nField_4;
	};

	class VocabCorrector : public ICorrector
	{
	public:
		VocabInfo m_xVocabInfo_8;
		map<uint, vector<ConfusedPair>> m_map_unvConfusedPair_18;

		VocabCorrector(VocabInfo&, ICorrector*);
		~VocabCorrector();
		static bool isPresentInVocabulary(vector<CTCHypoth> &);
		virtual void process_impl(vector<CTCHypoth> &);
	};
}