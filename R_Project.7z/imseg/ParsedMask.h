#pragma once
#include "pch.h"
#include "common/resources.h"
#include "common/container/container.h"
#include "common/container/RclHolder.h"
#include "Json/Value.h"
#include "CharPlace.h"
#include "imseg_interface.h"
#include "FieldMaskArbitrarySymbols.h"
#include "FieldMaskConstrained.h"
#include "FieldMaskLogicalOr.h"

using namespace common::resources;
using namespace common::container;

namespace imseg
{
	class ParsedMask
	{
	public:
		bool m_bLineBreaksDoesNotMatter;
		vector<vector<vector<CharPlace>>> m_vvvCharPlace_4;
		vector<vector<CharPlace>> m_vvCharPlace_10;
		set<uint> m_setn_FoundLCIDs_1C;
		vector<unsigned int> m_vun_28;
		vector<shared_ptr<IFieldMask>> m_vsp_IFieldMasks_34;
		unordered_map<eProcessOptions, string> m_umap_ns_40;
		string m_strStringMask_54;

		ParsedMask();
		ParsedMask(ParsedMask &);
		~ParsedMask();
		void addToSingleString(vector<vector<CharPlace>>);
		void appendString(vector<vector<CharPlace>> &);
		vector<uint> getAdditionalAlphabet() ;
		vector<shared_ptr<IFieldMask>>& getFieldMasks() ;
		set<uint> getFoundLCIDs() ;
		vector<vector<CharPlace>> getParsedMaskAnyWay(uint);
		string getStringMask();
		void setAdditionalAlphabet(vector<int>&);
		void setStringMask(string&);
		void insertLCIDs(set<uint>&);
		void buildIFieldMask();
		shared_ptr<IFieldMask> buildMaskWithAlternative(vector<CharPlace> &);
		void finalize();
		bool isBankCardName() ;
		bool isBankCardNumber() ;
		bool isBankCardValidThru() ;
		bool isLineBreaksDoesNotMatter() ;
	};
}