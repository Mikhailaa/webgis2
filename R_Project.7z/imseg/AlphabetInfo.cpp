#include "AlphabetInfo.h"

AlphabetInfo::AlphabetInfo()
{
}

AlphabetInfo::~AlphabetInfo()
{
}

int AlphabetInfo::alphabet(int n_a1, vector<int> &vn_a2)
{
	vn_a2.clear();
	vector<int>::iterator iter;
	int v3 = 0;
	for (iter = m_vn_4.begin(); ; iter++)
	{
		if (iter == m_vn_4.end())
			return -1;
		if (*iter == n_a1)
			break;
		v3++;
	}
	if (vn_a2 != m_vvn_10[v3])
		vn_a2 = m_vvn_10[v3];
	return 0;
}

void AlphabetInfo::reset()
{
	m_vn_4.clear();
	m_vvn_10.clear();
}
