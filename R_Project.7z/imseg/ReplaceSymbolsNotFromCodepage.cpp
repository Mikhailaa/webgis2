#include "ReplaceSymbolsNotFromCodepage.h"

imseg::ReplaceSymbolsNotFromCodepage::ReplaceSymbolsNotFromCodepage(int n_a1, ICorrector*pICorrector)
{
	m_pIC_4 = pICorrector;
	m_nReplaceSymbolsNotFromCodepage_8 = n_a1;
}

imseg::ReplaceSymbolsNotFromCodepage::~ReplaceSymbolsNotFromCodepage()
{

}

void imseg::ReplaceSymbolsNotFromCodepage::process_impl(vector<CTCHypoth>&vCTCHypoth)
{
	if (m_nReplaceSymbolsNotFromCodepage_8 == 1068)
	{
		for (size_t i = 0; i < vCTCHypoth.size(); i++)
		{
			if (vCTCHypoth[i].getUnicode() == 1240)
				vCTCHypoth[i].setUnicode(0x18F);
			if (vCTCHypoth[i].getUnicode() == 1241)
				vCTCHypoth[i].setUnicode(0x259);
		}
	}
}
