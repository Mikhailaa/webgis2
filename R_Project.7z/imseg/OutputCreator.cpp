#include "OutputCreator.h"

using namespace imseg;

OutputCreator::OutputCreator()
{
}

OutputCreator::~OutputCreator()
{
}

void OutputCreator::createOutput(Rect_<int> const &xRect_a1, vector<CTCHypoth> &vCTCHy_a2,
	vector<vector<SymbolCandidatWithRect>>& vvSCWR_a3)
{
	vector<Rect_<int>> vSymbolRects = findSymbolRects(xRect_a1, vCTCHy_a2);
	CTCHypothToOutput(vCTCHy_a2, vSymbolRects, vvSCWR_a3);
}

void OutputCreator::CTCHypothToOutput(vector<CTCHypoth> &vCTCHy_a1, vector<Rect_<int>> const &vRect_a2,
	vector<vector<SymbolCandidatWithRect>>& vvSCWR_a3)
{
	vvSCWR_a3.clear();
	for (size_t i = 0; i < vCTCHy_a1.size(); i++)
	{
		SymbolCandidat xSymbol = vCTCHy_a1[i].getSymbol();
		SymbolCandidatWithRect xSCWR(xSymbol, vRect_a2[i]);
		vector<SymbolCandidatWithRect> vSCWR(1, xSCWR);

		list<CTCHypoth>::iterator Iter;

		for (Iter = vCTCHy_a1[i].m_lstImCTCHy_18.begin(); Iter != vCTCHy_a1[i].m_lstImCTCHy_18.end(); Iter++)
		{
			SymbolCandidat xSymbol1 = Iter->getSymbol();
			SymbolCandidatWithRect xSCWR1(xSymbol1 ,vRect_a2[i]);
			vSCWR.push_back(xSCWR1);
		}

		vvSCWR_a3.push_back(vSCWR);
	}
}

vector<Rect_<int>> OutputCreator::findSymbolRects(Rect_<int> const &xRect_a1, vector<CTCHypoth> const &vCTCHy_a2)
{
	vector<Rect_<int>> vRect_ret;
	for (size_t i = 0; i < vCTCHy_a2.size(); i++)
	{
		Rect_<int> rect((int)(vCTCHy_a2[i].m_fcalcX_10 + xRect_a1.x), xRect_a1.y, xRect_a1.height / 2, xRect_a1.height);
		vRect_ret.push_back(rect);
	}
	makeRectsPlausible(vRect_ret);
	return vRect_ret;
}

void OutputCreator::increaseAllProbsInOrderToNotAllowSymbolDeleting(vector<CTCHypoth>&vCTChy_a2)
{
	for (size_t i = 0; i < vCTChy_a2.size(); i++)
	{
		if (vCTChy_a2[i].m_fHandmade_14 < 0.9)
			vCTChy_a2[i].m_fHandmade_14 = 0.9f;
	}
}

void OutputCreator::makeRectsPlausible(vector<Rect_<int>>& vRect_a1)
{
	if (vRect_a1.size() >= 2)
	{
		for (size_t i = 0; i < vRect_a1.size() - 1; i++)
			vRect_a1[i + 1].x = vRect_a1[i].x + vRect_a1[i].width;
	}
}
