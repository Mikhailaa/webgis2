#include "LuhnCheckSumCorrector.h"
using namespace imseg;

imseg::LuhnCheckSumCorrector::LuhnCheckSumCorrector(ICorrector*pICorrector)
{
	m_pIC_4 = pICorrector;
	m_nLuhnCheckSumCorrector_8 = -2;
	m_nLuhnCheckSumCorrector_C = -1;
}

imseg::LuhnCheckSumCorrector::~LuhnCheckSumCorrector()
{
}

void imseg::LuhnCheckSumCorrector::calcProb(vector<CTCHypoth>&vCTCHypoth, Idx &xIdx)
{
	float nTmpSum = 0;
	float nTmp = 0.0f;
	for (size_t i = 0; i < xIdx.m_vn_0.size(); i++)
	{
		if (xIdx.m_vn_0[i] != m_nLuhnCheckSumCorrector_8)
		{
			if (xIdx.m_vn_0[i] == m_nLuhnCheckSumCorrector_C)
				nTmp = vCTCHypoth[i].m_fHandmade_14;
			else
			{
				list<CTCHypoth>::iterator iter = vCTCHypoth[i].m_lstImCTCHy_18.begin();
				int v7 = xIdx.m_vn_0[i];
				if (v7 > -1)
				{
					while (v7 >= 1)
					{
						iter++;
						v7--;
					}
				}
				else
				{
					while (v7 <= -1)
					{
						iter--;
						v7++;
					}
				}
				nTmp = (*iter).m_fHandmade_14;
			}
			nTmpSum += nTmp;
		}
	}
	xIdx.m_rIdx_C = (float)nTmpSum;
}

vector<int> imseg::LuhnCheckSumCorrector::idxToNumbers(vector<CTCHypoth>&vCTCHypoth, Idx &xIdx)
{
	vector<int> vnRes;
	int nNumber = 0;
	for (size_t i = 0; i < xIdx.m_vn_0.size(); i++)
	{
		if (xIdx.m_vn_0[i] == m_nLuhnCheckSumCorrector_C)
		{
			nNumber = vCTCHypoth[i].getUnicode() - '0';
			vnRes.push_back(nNumber);
			break;
		}

		if (xIdx.m_vn_0[i] == m_nLuhnCheckSumCorrector_8)
			break;

		xIdx.m_vn_0.erase(xIdx.m_vn_0.begin() + i);

		nNumber = vCTCHypoth[i].getUnicode() - '0';
		vnRes.push_back(nNumber);
	}

	return vnRes;
}

list<Idx> imseg::LuhnCheckSumCorrector::incrementEach(vector<CTCHypoth>&vCTCHypoth, Idx &xIdx)
{
	list<Idx> lst_res;
	vector<int> _vn_14(xIdx.m_vn_0);
	for (size_t i = 0; i < _vn_14.size(); i++)
	{
		if (_vn_14[i] != m_nLuhnCheckSumCorrector_8
			&& _vn_14[i] + 1 < (int)vCTCHypoth[i].m_lstImCTCHy_18.size())
		{
			Idx _xIdx_4(xIdx);
			_xIdx_4.m_vn_0.clear();
			_xIdx_4.m_vn_0.assign(_vn_14.begin(), _vn_14.end());
			_xIdx_4.m_vn_0[i]++;
			lst_res.push_back(_xIdx_4);
		}
	}
	return lst_res;
}

void imseg::LuhnCheckSumCorrector::initIdxs(vector<CTCHypoth>&vCTCHypoth, vector<int>&vn)
{
	for (size_t i = 0; i < vCTCHypoth.size(); i++)
	{
		if (vCTCHypoth[i].getUnicode() == ' ')
			vn.push_back(m_nLuhnCheckSumCorrector_8);
		else
			vn.push_back(m_nLuhnCheckSumCorrector_C);
	}
}

bool imseg::LuhnCheckSumCorrector::isCheckSumCorrect(vector<int>&vn)
{
	if (vn.size() < 2)
		return 0;
	int nTmpSum = 0;
	for (size_t i = 0; i < vn.size() - 1; i++)
	{
		if (i)
			nTmpSum += vn[i];
		else
			nTmpSum += vn[i] / 5 + (2 * vn[i] % 10);
	}
	int nTmpRest = nTmpSum % 10;
	if (nTmpRest)
		nTmpRest = 10 - nTmpRest;
	return nTmpRest == vn.back();
}

void imseg::LuhnCheckSumCorrector::setNumbers(vector<int>&vn, vector<CTCHypoth>&vCTCHypoth)
{
	int j = 0, nUnicode = 0;
	for (size_t i = 0; i < vCTCHypoth.size(); i++)
	{
		if (vCTCHypoth[i].getUnicode() != ' ')
		{
			nUnicode = vn[j] + '0';
			vCTCHypoth[i].setUnicode(nUnicode);
			j++;
		}
	}
}

void imseg::LuhnCheckSumCorrector::process_impl(vector<CTCHypoth>&vCTCHypoth)
{
	if (vCTCHypoth.size() < 2)
		return;
	vector<CTCHypoth> _vCTCHypoth_68(vCTCHypoth);
	for (size_t i = 0; i < _vCTCHypoth_68.size(); i++)
	{
		CTCHypoth _xCTCHypoth_44;
		_xCTCHypoth_44.field_0 = 0x10FFFF;
		_xCTCHypoth_44.m_wcUnicode_4 = 0x10FFFF;
		_xCTCHypoth_44.field_8 = -1;
		_xCTCHypoth_44.m_nIndex_C = 0;
		_xCTCHypoth_44.m_fcalcX_10 = 0.0;
		_xCTCHypoth_44.m_fHandmade_14 = -1.0;
		list<CTCHypoth>::iterator new_end;
		new_end = remove(_vCTCHypoth_68[i].m_lstImCTCHy_18.begin(), _vCTCHypoth_68[i].m_lstImCTCHy_18.end(), _xCTCHypoth_44);
		_vCTCHypoth_68[i].m_lstImCTCHy_18.erase(new_end, _vCTCHypoth_68[i].m_lstImCTCHy_18.end());
	}
	Idx _xIdx_44;
	initIdxs(_vCTCHypoth_68, _xIdx_44.m_vn_0);
	Idx _xIdx_74(_xIdx_44);
	list<Idx> _lstIdx_38(1, _xIdx_74);
	list<Idx> _lstIdx_2C(1, _xIdx_74);

	while (_lstIdx_2C.size() && _lstIdx_2C.size() <= 8 * 124)
	{
		list<Idx> _lstIdx_20;
		list<Idx>::iterator iter;
		for (iter = _lstIdx_2C.begin(); iter != _lstIdx_2C.end(); iter++)
		{
			Idx _xIdx_74(*iter);
			list<Idx> _lstIdx_14 = incrementEach(_vCTCHypoth_68, _xIdx_74);
			_lstIdx_20.insert(_lstIdx_20.end(), _lstIdx_14.begin(), _lstIdx_14.end());
		}
		_lstIdx_38.insert(_lstIdx_38.end(), _lstIdx_20.begin(), _lstIdx_20.end());
		_lstIdx_2C.assign(_lstIdx_20.begin(), _lstIdx_20.end());
	}

	list<Idx>::iterator iter;
	for (iter = _lstIdx_38.begin(); iter != _lstIdx_38.end(); iter++)
		calcProb(_vCTCHypoth_68, (*iter));
	for (iter = _lstIdx_38.begin(); iter != _lstIdx_38.end(); iter++)
	{
		Idx _xIdx_74(*iter);
		vector<int> vnTmp_v14 = idxToNumbers(_vCTCHypoth_68, _xIdx_74);
		if (isCheckSumCorrect(vnTmp_v14))
		{
			setNumbers(vnTmp_v14, vCTCHypoth);
			break;
		}
	}
}

imseg::Idx::Idx()
{
}

imseg::Idx::Idx(Idx const &xIdx)
	: m_vn_0(xIdx.m_vn_0)
	, m_rIdx_C(xIdx.m_rIdx_C)
{

}

Idx & imseg::Idx::operator=(Idx const &xIdx)
{
	if (m_vn_0 != xIdx.m_vn_0)
		m_vn_0.assign(xIdx.m_vn_0.begin(), xIdx.m_vn_0.end());
	m_rIdx_C = xIdx.m_rIdx_C;
	return *this;
}
