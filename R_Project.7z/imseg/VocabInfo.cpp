#include "VocabInfo.h"

imseg::VocabInfo::VocabInfo()
{
	nCount_0 = 0;
}
