#include"RichTextLines.h"
#include "dbgInfoSaver.h"
#include "OutputCreator.h"

using namespace imseg;

RichTextLines::RichTextLines(RichTextLines const &arg1):
	TextLines(arg1),
	m_vn_5C(arg1.m_vn_5C),
	m_vDbgF_68(arg1.m_vDbgF_68),
	m_vvImCTCHy_74(arg1.m_vvImCTCHy_74),
	m_vMat_80(arg1.m_vMat_80),
	m_vf_8C(arg1.m_vf_8C),
	m_vRichTLs_98(arg1.m_vRichTLs_98),
	m_vRichTLs_A4(arg1.m_vRichTLs_A4)
{
	m_nTopPriority_58 = arg1.m_nTopPriority_58;
}

RichTextLines::RichTextLines(TextLines const &a1, vector<uint> const &a2, DbgFolder const &a3, uint a4):
	TextLines(a1)
{
	m_vn_5C = a2;
	//m_vDbgF_68 = a3;
	//imseg::dbgInfoSaver::mkDirForDbg
	m_vf_8C = vector<float>(m_vRect_3C.size(), 1.0f);
	m_nTopPriority_58 = a4;

}

void RichTextLines::accept(ITextLinesVisitor &a2)
{
	a2.visit(*this);
}

RichTextLines::~RichTextLines()
{
}

RichTextLines &RichTextLines::operator=(RichTextLines &&arg1)
{
	*(TextLines*)(this) = move(*(TextLines*)(&arg1));
	m_nTopPriority_58 = move(arg1.m_nTopPriority_58);
	m_vn_5C.assign(move(arg1.m_vn_5C).begin(), move(arg1.m_vn_5C).end());
	m_vDbgF_68.assign(move(arg1.m_vDbgF_68).begin(), move(arg1.m_vDbgF_68).end());
	m_vvImCTCHy_74.assign(move(arg1.m_vvImCTCHy_74).begin(), move(arg1.m_vvImCTCHy_74).end());
	m_vMat_80.assign(move(arg1.m_vMat_80).begin(), move(arg1.m_vMat_80).end());
	m_vf_8C.assign(move(arg1.m_vf_8C).begin(), move(arg1.m_vf_8C).end());
	m_vRichTLs_98.assign(move(arg1.m_vRichTLs_98).begin(), move(arg1.m_vRichTLs_98).end());
	m_vRichTLs_A4.assign(move(arg1.m_vRichTLs_A4).begin(), move(arg1.m_vRichTLs_A4).end());
	return *this;
}

RichTextLines &RichTextLines::operator=(RichTextLines const &arg1)
{
	if (this == &arg1)
		return *this;
	*(TextLines*)(this) = *(TextLines*)(&arg1);
	m_nTopPriority_58 = arg1.m_nTopPriority_58;
	m_vn_5C.assign(arg1.m_vn_5C.begin(), arg1.m_vn_5C.end());
	m_vDbgF_68.assign(arg1.m_vDbgF_68.begin(), arg1.m_vDbgF_68.end());
	m_vvImCTCHy_74.assign(arg1.m_vvImCTCHy_74.begin(), arg1.m_vvImCTCHy_74.end());
	m_vMat_80.assign(arg1.m_vMat_80.begin(), arg1.m_vMat_80.end());
	m_vf_8C.assign(arg1.m_vf_8C.begin(), arg1.m_vf_8C.end());
	m_vRichTLs_98.assign(arg1.m_vRichTLs_98.begin(), arg1.m_vRichTLs_98.end());
	m_vRichTLs_A4.assign(arg1.m_vRichTLs_A4.begin(), arg1.m_vRichTLs_A4.end());
	return *this;
}

void RichTextLines::operator>>(TextLines &xTLs_a2)
{
	// TODO: insert return statement here
	*(TextLines*)(&xTLs_a2) = *(TextLines*)(this);
	//vector<DbgFolder> &vDbgH = this->m_vDbgF_68;

	
	for (uint i = 0; i < MIN(m_vvImCTCHy_74.size(), m_vRect_3C.size()); i++)
	{
		vector<vector<SymbolCandidatWithRect>> vvSCWR_a3;
		//dbgInfoSaver::saveAfterAlignment(vDbgH[i], m_vvImCTCHy_74[i]);
		OutputCreator::increaseAllProbsInOrderToNotAllowSymbolDeleting(m_vvImCTCHy_74[i]);
		OutputCreator::createOutput(m_vRect_3C[i], m_vvImCTCHy_74[i], vvSCWR_a3);
		xTLs_a2.pushBackResults(vvSCWR_a3);
	}
}

void RichTextLines::append(vector<CTCHypoth>&arg1)
{
	m_vvImCTCHy_74.push_back(arg1);
}

void RichTextLines::augment(TTAParams &xTTAParams)
{
	int nTmp_x, nTmp_y, nTmp_Right, nTmp_Width, nTmp_Height, nTmp_Bottom;
	for (uint i = 0; i < m_vRect_3C.size(); i++)
	{
		xTTAParams.augment(m_vRect_3C[i]);
		nTmp_x = MAX(m_vRect_3C[i].x, 0);
		nTmp_y = MAX(m_vRect_3C[i].y, 0);
		nTmp_Right = MIN(m_xMat_4.size().width, m_vRect_3C[i].x + m_vRect_3C[i].width);
		nTmp_Width = nTmp_Right - nTmp_x;
		nTmp_Bottom = MIN(m_xMat_4.size().height, m_vRect_3C[i].y + m_vRect_3C[i].height);
		nTmp_Height = nTmp_Bottom - nTmp_y;
		m_vRect_3C[i].x = nTmp_x;
		m_vRect_3C[i].y = nTmp_y;
		m_vRect_3C[i].width = nTmp_Width;
		m_vRect_3C[i].height = nTmp_Height;
		if (nTmp_Width < 1 || nTmp_Height < 1)
		{
			m_vRect_3C[i].x = 0;
			m_vRect_3C[i].y = 0;
			m_vRect_3C[i].width = 0;
			m_vRect_3C[i].height = 0;
		}
	}
}

void RichTextLines::setAugmentedVersions(vector<RichTextLines> const &arg1)
{
	m_vRichTLs_A4 = arg1;
}

void RichTextLines::setNormalizedImgs(vector<cv::Mat> const &arg1)
{
	m_vMat_80 = arg1;
}

void RichTextLines::setTextROIs(vector<cv::Rect> const &arg1)
{
	if (m_vRect_3C != arg1)
		m_vRect_3C.assign(arg1.begin(), arg1.end());
	while (m_vf_8C.size() < m_vRect_3C.size())
	{
		m_vf_8C.push_back(1.0);
	}

	if (m_vDbgF_68.size() < m_vRect_3C.size())
	{
		DbgFolder _imDbgF_28(m_vDbgF_68.back());
		fs::Path _fsPath_10 = _imDbgF_28.m_xCfsPath_0.getPathBase();
		//imseg::dbgInfoSaver
	}

}

void RichTextLines::setVotingSeqs(vector<RichTextLines> const &arg1)
{
	m_vRichTLs_98 = arg1;
}

bool RichTextLines::hasAugmentedVersions()
{
	return !m_vRichTLs_A4.empty();
}

vector<RichTextLines>& RichTextLines::getVotingSeqs()
{
	return m_vRichTLs_98;
}

uint RichTextLines::getTopPriorityLCID()
{
	return m_nTopPriority_58;
}

vector<cv::Rect>& RichTextLines::getTextROIs()
{
	return m_vRect_3C;
}

cv::Rect& RichTextLines::getTextROI(uint arg1)
{
	return m_vRect_3C[arg1];
}

vector<vector<CTCHypoth>>& RichTextLines::getSeqs()
{
	return m_vvImCTCHy_74;
}

float& RichTextLines::getScale(uint arg1)
{
	return m_vf_8C[arg1];
}

vector<cv::Mat>& RichTextLines::getNormalizedImgs()
{
	return m_vMat_80;
}

int RichTextLines::getMaxWidth()
{
	int res = 0;
	if (m_vRect_3C.empty())
		return 0;
	for (uint i = 0; i < m_vRect_3C.size(); i++)
	{
		if (m_vRect_3C[i].width > res)
			res = m_vRect_3C[i].width;
	}
	return res;
}

cv::Mat& RichTextLines::getImg()
{
	return m_xMat_4;
}

vector<DbgFolder>& RichTextLines::getDbgFolders()
{
	return m_vDbgF_68;
}

vector<RichTextLines>& RichTextLines::getAugmentedVersions()
{
	return m_vRichTLs_A4;
}

set<uint> RichTextLines::getAlphabetSet()
{
	set<uint> res;
	res.clear();
	vector<uint>::iterator iter;
	for (iter = m_vn_5C.begin(); iter != m_vn_5C.end(); iter++)
	{
		res.emplace(*iter);
	}
	return res;
}

vector<uint>& RichTextLines::getAlphabet()
{
	return m_vn_5C;
}

bool RichTextLines::empty()
{
	return m_vRect_3C.empty();
}

