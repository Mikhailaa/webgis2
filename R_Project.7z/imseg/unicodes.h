#pragma once
#include "pch.h"
namespace imseg
{
	namespace unicodes//Done
	{
		vector<uint> getVisualIdenticalSetForUnicode(uint const&);
		set<uint>* getUnicodesForProbabilityTransfer(uint);
	};
}

