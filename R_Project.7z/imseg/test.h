#pragma once
#include "common/container/RclHolder.h"
using namespace common::container;
namespace imseg
{
	namespace test
	{
		void createTestSample(RclHolder &,string &);
	}
}