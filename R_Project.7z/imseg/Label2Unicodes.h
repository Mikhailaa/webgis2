#pragma once 

#include "pch.h"

namespace imseg
{
	class Label2Unicodes
	{
	public:
		Label2Unicodes(vector<uint> const& vLabels, set<uint> const&);
		~Label2Unicodes() {};

		uint unicode2Label(uint) const;
		void deleteForbiddenSymbols(cv::Mat &);
		vector<uint> getIdxsForProbabilityTransfer(uint);
		bool isInExtendedAlphabet(uint) const;
		vector<uint>  operator()(uint const&) const;
		uint size(void) const;

		vector<vector<uint>> m_vL2U_field_0;
		vector<uint> m_vL2U_field_C;
		map<uint, uint> m_tL2U_field_18;
		set<uint> m_sL2U_field_24;

		static vector<uint>m_nullCode;
	};
}