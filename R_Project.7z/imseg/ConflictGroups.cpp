#include "ConflictGroups.h"

ConflictGroups::ConflictGroups()
{
	m_n_0 = 0;
}
