#pragma once

#include "../pch.h"

typedef int LetterType;

typedef struct _SymbolFontParam
{
	float m_r_0;
	float m_r_4;
} SymbolFontParam;

typedef struct _TPointEx
{
	int nField_0;
	int nField_4;
	int nField_8;
	int nField_C;
	int nField_10;
} TPointEx;

enum eHType
{
	eHType_0,
	eHType_1,
	eHType_2
};

enum eBaseLinePos
{
	eBaseLinePos_2 = 2,
	eBaseLinePos_3 = 3,
	eBaseLinePos_4 = 4,
	eBaseLinePos_9 = 9,
	eBaseLinePos_A = 0xA
};

enum eWordType
{
	eWordType_0 = 0,
	eWordType_1 = 1,
	eWordType_2 = 2
};

enum eTails {
	Tails_0 = 0,
	Tails_0x200 = 0x200,
};

enum eSymbolWidth {
	SymbolWidth0
};

enum eSymbolType {
	SymbolType_0 = 0,
	SymbolType_1 = 1,
};

enum eTextPostProcessing
{
	eTextPostProcessing_1 = 1,
	eTextPostProcessing_2 = 2,
	eTextPostProcessing_3 = 3
};
