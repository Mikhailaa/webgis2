#include "parameters.h"

namespace imseg
{
	namespace parameters
	{
		Configuration::Configuration()
			:m_xJsonValue_8()
		{
		}
		Configuration::~Configuration()
		{
		}
		Configuration *Configuration::obj()
		{
			static Configuration objSt;
			return &objSt;
		}

		bool get_UseOnlyWhiteImage()
		{
			Configuration* pConfiguration = Configuration::obj();
			if (!pConfiguration->m_xJsonValue_8["Main"].isMember("useOnlyWhiteImage"))
				return false;
			return pConfiguration->m_xJsonValue_8["Main"]["useOnlyWhiteImage"].asBool();
		}
		float kHDeviation(TLineAnalyzeFirst &a1, eHType a2)
		{
			float res = 0.0;
			if (unsigned(a2 - 4) < 2 || a2 == 2)
				res = a1.m_r_28;
			else if (a2 == 1)
				res = a1.m_r_24;
			else
				res = a1.m_r_20;
			return res;
		}
	}
}