#pragma once

#include "imseg_interface.h"


namespace imseg
{
	class FieldMaskArbitrarySymbols : public IFieldMask
	{
	public:
		FieldMaskArbitrarySymbols();
		virtual ~FieldMaskArbitrarySymbols();
		virtual void setPreviousPath(vector<CTCHypoth, allocator<CTCHypoth>> const&);
		virtual bool isUnicodePossible(uint);
		virtual int getBeamWidth();
		virtual bool isAllSymbolsFound(vector<CTCHypoth, allocator<CTCHypoth>> const&);
		virtual bool doNotDeleteSymbolsAfterMe();

		//int m_nFMAS_vft_0;
	};
}

