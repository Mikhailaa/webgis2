#pragma once
#include "pch.h"
#include "common/resources.h"
#include "common/container/container.h"
#include "common/container/RclHolder.h"
#include "Json/Value.h"
#include "commonStruct.h"
#include "DocInfo.h"

using namespace common::resources;
using namespace common::container;

namespace imseg
{
	namespace glare
	{
		map<int, bool> getFieldGlaresIntersectionMap(CDocInfo&, TResultContainerList&);
	}
}