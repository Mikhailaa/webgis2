#pragma once
#include "pch.h"
#include "common/resources.h"
#include "common/container/container.h"
#include "common/container/RclHolder.h"
#include "Json/Value.h"
#include "RecognResult2.h"

using namespace common;
using namespace common::resources;
using namespace common::container;

namespace imseg
{
	class Symbol
	{
	public:
		tagRECT m_xRECT_0;
		int m_nLine_10;
		int field_14;
		RecognResult2 m_xRecRes2_18;
		int field_24;
		int field_28;
		int field_2C;
		int field_30;
		int field_34;
		int field_38;
		int field_3C;
		tagRECT m_xRECT_40;
		char field_50;
		char field_51;
		char field_52;
		char field_53;

		Symbol();
		Symbol(Symbol const&);
		Symbol(tagRECT&);
		//Symbol(Symbol&&);
		tagRECT rect();
		void reset();
		Symbol &operator=(Symbol &);

		bool isRecogn();
		bool isNewLine();
		int prob(int);
		float probF(int);
		int width();
		int height();
		float kWH();
		~Symbol();
	};
}
