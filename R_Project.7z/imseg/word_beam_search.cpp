#include "word_beam_search.h"
#include "unicodes.h"
#include "HParam.h"
#include "SeqConfidenceVouter.h"
#include "Beam.h"
#include "LanguageModel.h"
#include "Label2Unicodes.h"

namespace imseg
{
	namespace word_beam_search
	{
		vector<CTCHypoth> beam2HypothSeq(shared_ptr<Beam> const & a2, shared_ptr<LanguageModel> const & a3, Label2Unicodes const & a4)
		{
			vector<CTCHypoth> a1;
			vector<uint> v1a(a2->getText());
			vector<float> v31(a2->getCharProbs());
			vector<uint> v30(a2->getCharXs());
			vector<uint> v29;
			v29.reserve(v1a.size());

			for (size_t i = 0; i < v1a.size(); i++)
			{
				v29.push_back(a3->labelToUnicode(v1a[i]));
			}

			uint n24 = min(min(v29.size(), v30.size()), v31.size());
			int n = -1;

			for (size_t i = 0; i < n24; i++)
			{
				CTCHypoth x28;
				x28.field_0 = v29[i];
				x28.m_wcUnicode_4 = v29[i];
				x28.field_8 = a4.unicode2Label(v29[i]);
				x28.m_nIndex_C = v30[i];
				x28.m_fHandmade_14 = v31[i];
				x28.m_fcalcX_10 = 0.0;

				if (n == v29[i])
				{
					CTCHypoth x2a;
					x2a.field_0 = 0x10FFFF;
					x2a.m_wcUnicode_4 = 0x10FFFF;
					x2a.field_8 = -1;
					x2a.m_nIndex_C = v30[i] + 1;
					x2a.m_fHandmade_14 = 1.0;
					x2a.m_fcalcX_10 = 0.0;
					a1.push_back(x2a);
					x2a.m_lstImCTCHy_18.clear();
				}

				a1.push_back(x28);
				x28.m_lstImCTCHy_18.clear();

				n = v29[i];
			}

			return vector<CTCHypoth>();
		}

		vector<uint> calcLM2VisualLabels(shared_ptr<LanguageModel> const & a2, Label2Unicodes const & a3)
		{
			vector<uint> a1(a2->getAllChars().size());

			for (size_t i = 0; i < a1.size(); i++)
			{
				int n15 = a2->labelToUnicode(i);
				uint n8 = a3.unicode2Label(n15), n9;

				if (n8 >= a3.size())
				{
					vector<uint> v1a = unicodes::getVisualIdenticalSetForUnicode(n15);

					size_t j;
					for (j = 0; j < v1a.size(); j++)
					{
						n9 = a3.unicode2Label(v1a[j]);

						if (n9 < a3.size())
						{
							break;
						}
					}

					if (j == v1a.size())
					{
						n9 = n8;
					}
				}
				else
				{
					n9 = n8;
				}

				a1[i] = n9;
			}
			
			return a1; 
		}

		vector<Char> getBestChars(double a2, Label2Unicodes const & a3, vector<uint> const & a4, shared_ptr<LanguageModel> const & a5, IMatrix const & a6, uint a7)
		{
			vector<Char> a1;
			Char x22;

			for (size_t i = 0; i < a4.size(); i++)
			{
				if (a4[i] < (uint)a6.cols())
				{
					if (a6.getAt(a7, a4[i]) > a2 && a3.isInExtendedAlphabet(a5->labelToUnicode(i)))
					{						
						x22.nChar_0 = i;
						x22.rChar_4 = (float)a6.getAt(a7, a4[i]);
						a1.push_back(x22);
					}
				}
			}

			double d18 = a6.getAt(a7, a6.cols() - 1);

			if (d18 > a2)
			{
				x22.nChar_0 = -1;
				x22.rChar_4 = (float)d18;
				a1.push_back(x22);
			}

			return vector<Char>();
		}

		bool comp(shared_ptr<Beam> a1, shared_ptr<Beam> a2)
		{
			return a1->getAvgWordProb() > a2->getAvgWordProb();
		}

		vector<CTCHypoth> wordBeamSearch(IMatrix const& a2, Label2Unicodes const& a3, shared_ptr<LanguageModel> const& a4, LanguageModelType a5)
		{
			static double dbl_112A2B0 = HParamPool::get("minLanguageCharProb", -1);
			int n39 = a2.rows();
			a2.cols();
			vector<uint> v52 = calcLM2VisualLabels(a4, a3);
			bool f48, f49, f50;
			f50 = 0;
			if ((uint)(a5 - 1) < 3)
			{
				f50 = 1;
			}

			f49 = (a5 == LANGUAGEMODELTYPE_2 || a5 == LANGUAGEMODELTYPE_3);
			f48 = (a5 == LANGUAGEMODELTYPE_3);

			shared_ptr<Beam> sp47 = make_shared<Beam>(a4, f50, f49, f48);

			BeamList x2a;
			x2a.addBeam(sp47);

			for (int i = 0; i < n39; i++)
			{
				vector<shared_ptr<Beam>> v1a = x2a.getBestBeams(10);
				vector<Char> v44 = getBestChars(0.000001, a3, v52, a4, a2, i);

				BeamList x13;

				for (size_t j = 0; j < v1a.size(); j++)
				{
					map<int, Char> m43 = v1a[i]->getNextChars();

					for (size_t k = 0; k < v44.size(); k++)
					{
						map<int, Char>::iterator iter = m43.find(v44[k].nChar_0);

						double d21 = 0.0;

						if (iter != m43.end())
						{
							d21 = iter->second.rChar_4 * 3.0;
						}

						if (v44[k].nChar_0 == -1)
						{
							d21 = 1.0;
						}

						if (d21 < dbl_112A2B0)
						{
							d21 = dbl_112A2B0;
						}

						d21 *= v44[k].rChar_4;

						x13.addBeam(v1a[j]->createChildBeam(v1a[j]->m_dBeam_0 * d21, v44[k].nChar_0, (float)d21, i));
					}
				}

				x2a.m_umBL_0 = x13.m_umBL_0;
			}

			vector<shared_ptr<Beam>> v46 = x2a.getBestBeams(5);

			stable_sort(v46.begin(), v46.end(), comp);

			vector<CTCHypoth> a1;
			SeqConfidenceVouter x42;

			shared_ptr<Beam> sp43 = v46[0];

			if (!v46.empty())
			{
				vector<CTCHypoth> v1a = beam2HypothSeq(sp43, a4, a3);
				a1 = x42.vote(a1, v1a);
			}

			return a1;
		}
	}
}
