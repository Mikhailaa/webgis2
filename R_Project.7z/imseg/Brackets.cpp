#include "Brackets.h"
#include "Semantics.h"

void Brackets::analyzePairSymbols(ISymbolsInfoByUnicode &a1, vector<CSymbolResult>&a2, vector<int>&a3,
	vector<Brackets::eBracketState>&a4, vector<CSymbolResult>&a5)
{
	if (a2.empty() && a4.empty()) return;

	string str_B8(" ,^");
	unordered_map<int, CSymbolResult> uordmp_A8;
	unordered_map<int, int> uordmp_90;
	vector<pair<int, Brackets::eBracketState>> vPair_C4, vPair_D0;
	bool b_r5,b_r3;
		
	for (size_t i = 0; i < a3.size(); i++)
	{
		uordmp_A8.insert(pair<int, CSymbolResult>(a3[i], a2[i]));
	}


	vector<pair<int, int>> vPair_7C;
	vector<pair<Brackets::eBracketState, Brackets::eBracketState>> vPair_DC;
	for (size_t i = 0; i < a3.size(); i++)
	{
		vector<int> vn_70;
		if (a2[i].get(0) == '(')
			vPair_C4.push_back(pair<int, Brackets::eBracketState>(a3[i], a4[i]));
		else if (a2[i].get(0) == ')')
			vPair_D0.push_back(pair<int, Brackets::eBracketState>(a3[i], a4[i]));

		if (!vPair_C4.empty() && !vPair_D0.empty())
		{
			for (size_t j = 0; j < vPair_C4.size(); j++)
			{
				for (size_t k = 0; k < vPair_C4.size(); k++)
				{
					if (vPair_C4[k].first < 0) break;
					if (vPair_C4[k].first > vPair_D0[j].first) break;

					b_r5 = true;
					if (vPair_C4[k].first)
					{
						size_t t;
						for (t = 0; t < str_B8.length(); t++)
							if (str_B8[t] == a5.back().get(0)) break;

						b_r5 = false;
						if (t != str_B8.size()) b_r5 = 1;
					}

					if (vPair_C4[k].second == a5.size())
					{
						b_r3 = true;
					}
					else
					{
						size_t t;
						for (t = 0; t < str_B8.length(); t++)
							if (a5[vPair_C4[k].second].get(0) == str_B8[t]) break;

						b_r3 = false;
						if (t != str_B8.size()) b_r3 = 1;
					}

					bool b_r0 = (b_r3 && b_r5);
					if (vPair_C4[k].second == eBracketState_3)
					{
						bool b_r2 = false;
						if (vPair_D0[j].second != eBracketState_2) b_r2 = true;

						if ((b_r0 | b_r2) != 1 || vPair_D0[j].second == eBracketState_3) break;
					}
					else if (vPair_D0[j].second == eBracketState_3)
					{
						b_r0 = false;
						if (vPair_C4[k].second != eBracketState_2) b_r0 = true;
						if (!b_r0) break;
					}
					else
					{
						b_r0 = false;
						if (vPair_D0[k].second != eBracketState_2) b_r0 = true;
						if (vPair_C4[k].second == eBracketState_2 && !b_r0) break;
					}

					int t;
					for (t = vPair_C4[k].first + 1; t < vPair_C4[k].second; t++)
					{
						if (a5[t].get(0) == '^') break;
					}
					if (t < vPair_C4[k].second) break;

					vPair_7C.push_back(pair<int,int>(vPair_C4[k].first, vPair_D0[k].first));
					vPair_DC.push_back(pair<Brackets::eBracketState, Brackets::eBracketState>(vPair_C4[k].second, vPair_D0[k].second));
				}

				if (!vPair_7C.empty())
				{
					Brackets::eBracketState nTmp = vPair_DC[0].first;
					if (vPair_7C.size() >= 2)
					{
						for (size_t k = 1; k < vPair_7C.size(); k++)
						{
							if (vPair_DC[k].first == nTmp)
							{
								int  n_r12 = vPair_7C[0].second - nTmp;
								Brackets::eBracketState n_r6 = vPair_DC[k].first;
								if(vPair_DC[k].second - vPair_DC[k].first <= 1)
									n_r6 = nTmp;
								if (vPair_DC[k].second - vPair_DC[k].first < n_r12)
									nTmp = n_r6;
							}
							else
							{
								nTmp = vPair_DC[k].first;
							}
						}
					}

					uordmp_90.insert(pair<int, int>(vPair_7C[0].second, nTmp));

					unordered_map<int, int>::iterator iter = uordmp_90.begin();
					while(iter != uordmp_90.end())
					{
						if (iter->second == nTmp)
							vn_70.push_back(iter->first);
						iter++;
					}

					if (vn_70.size() >= 2)
					{
						if(vn_70[1] <= vn_70[0]) 
							iter = uordmp_90.find(vn_70[0]);
						else 
							iter = uordmp_90.find(vn_70[1]);

						uordmp_90.erase(iter);
					}
				}
			}
		}
	}
}

void Brackets::checkPairSymbols(ISymbolsInfoByUnicode &a1, unordered_map<int, int>&a2, unordered_map<int, CSymbolResult>&a3, vector<CSymbolResult>&a4)
{
	if (a2.begin()->second)
	{
		unordered_map<int, int>::iterator iter = a2.begin();
		while (iter != a2.end())
		{
			if (iter->first >= 1)
			{
				if (iter->second + 1 < (int)a4.size())
				{
					int nType_r10 = a1.type(a4[iter->second + 1].get(0));
					int nType_r0 = a1.type(a4[iter->first - 1].get(0));
					int n_r1 = iter->first - iter->second;
					if (n_r1 >= 2 && (nType_r10 <= 4 &&
						(1 << nType_r10) & 0x16 && nType_r0 <= 4 && (1 << nType_r0) & 0x16 || n_r1 >= 3))
					{
						a4[iter->second] = a3[iter->second];
						a4[iter->first] = a3[iter->first];
					}
				}
			}
			iter++;
		}
	}
}

void Brackets::findPairSymbols(ISymbolsInfoByUnicode &a1, CSymbolResult *a2, int a3, eWordType a4, int a5, vector<CSymbolResult>& a6, vector<int>& a7, vector<Brackets::eBracketState>& a8)
{
	for (int i = 0; i < a3; i++)
	{
		for (uint j = 0; j < a2[i].nTSR_CandidatesCount; j++)
		{
			if (a2[i].xnTSR_Candidates[j].nTSC_SymbolCode == '(')
			{
				CSymbolResult SymRes_68 = a2[i];
				TSymbolCandidate tmpSymCand= SymRes_68.xnTSR_Candidates[j];
				SymRes_68.xnTSR_Candidates[j].nTSC_SymbolProbability = SymRes_68.xnTSR_Candidates[0].nTSC_SymbolProbability;
				SymRes_68.xnTSR_Candidates[j].sTSC_Class = SymRes_68.xnTSR_Candidates[0].sTSC_Class;
				SymRes_68.xnTSR_Candidates[j].sTSC_SubClass = SymRes_68.xnTSR_Candidates[0].sTSC_SubClass;

				SymRes_68.xnTSR_Candidates[0].nTSC_SymbolProbability = tmpSymCand.nTSC_SymbolProbability;
				SymRes_68.xnTSR_Candidates[0].sTSC_Class = tmpSymCand.sTSC_Class;
				SymRes_68.xnTSR_Candidates[0].sTSC_SubClass = tmpSymCand.sTSC_SubClass;

				a6.push_back(SymRes_68);
				a7.push_back(a5 + i);

				eBracketState n_r2 = eBracketState_0;

				if (a2[i].nTSR_CandidatesCount != 1)
				{
					if (!i&&abs(SymRes_68.at(0)->nTSC_SymbolProbability - SymRes_68.at(1)->nTSC_SymbolProbability) >= 4 ||
						abs(SymRes_68.at(i)->nTSC_SymbolProbability - SymRes_68.at(0)->nTSC_SymbolProbability) >= 4 ||
						SymRes_68.at(i)->nTSC_SymbolProbability > SymRes_68.at(0)->nTSC_SymbolProbability && SymRes_68.at(i)->nTSC_SymbolProbability >= 96)
					{
						n_r2 = eBracketState_1;
					}
					else if (abs(SymRes_68.at(0)->nTSC_SymbolProbability - SymRes_68.at(1)->nTSC_SymbolProbability) <= 3)
					{
						n_r2 = eBracketState_2;
					}
					else
					{
						n_r2 = eBracketState_3;
					}

					a8.push_back(n_r2);
				}
			}
		}
	}

	for (int i = 0; i < a3; i++)
	{
		if (a2[i].xnTSR_Candidates[0].nTSC_SymbolCode == '(')
		{
			Semantics::swapPosSymbol(a1, a2[i].at(0), a2[i].nTSR_CandidatesCount, a4);
		}
	}
}
