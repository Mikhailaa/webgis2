#pragma once

#include "ParsedMask.h"
#include "RichTextLines.h"
#include "imseg.h"

namespace imseg
{
	class SeqConfidenceVouter : public ITextLinesVisitor
	{
	public:
		SeqConfidenceVouter();
		void deleteLowProbableSymbols(vector<CTCHypoth> &);
		void insertNewOrUpdateOld(list<CTCHypoth> &, list<CTCHypoth> &);
		void liftUpHighProbSecondaryHypoth(vector<CTCHypoth> &);
		void moveProbsFromSecondaryToPrimaryHypoths(vector<CTCHypoth> &);
		wstring seq2Str(vector<CTCHypoth> const&);
		virtual void visit(RichTextLines &);
		vector<CTCHypoth> vote(vector<CTCHypoth>&, vector<CTCHypoth> &);
	};
}