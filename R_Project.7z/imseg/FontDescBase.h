#pragma once
#include "commonStruct.h"

class FontDescBase
{
public:
	FontDescBase();
	~FontDescBase();

	int m_nFDB_Field_0;
	int m_nFDB_Field_4;
	int m_nFDB_Field_8;
	int m_nFDB_Field_C;
	float m_nFDB_Field_10;
	float m_nFDB_Field_14;
	float m_nFDB_Field_18;
	int m_nFDB_Field_1C;
	int m_nFDB_Field_20;
	int m_nFDB_Field_24;
	int m_nFDB_Field_28;
	int m_nFDB_Field_2C;
	int m_nFDB_Field_30;
	int m_nFDB_Field_34;
};

