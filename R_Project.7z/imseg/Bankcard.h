#pragma once
#include "imseg_interface.h"
#include "LuhnCheckSumCorrector.h"
#include "PostCorrectorNull.h"

namespace imseg
{
	namespace bankcard
	{
		//---------------------public ITextDetector---------------------//
		class TextDetectorBankCardDummy : public ITextDetector
		{
		public:
			float m_rTextDetectorBankCardDummy_C;
			float m_rTextDetectorBankCardDummy_10;
			float m_rTextDetectorBankCardDummy_14;
		public:
			TextDetectorBankCardDummy();
			~TextDetectorBankCardDummy();
			virtual vector<Rect> postprocDetections(Mat&, vector<Rect>&);
			//virtual RichTextLines& detect(RichTextLines&);
			virtual Mat resize(Mat&, float&, float&);
		};

		class TextDetectorBankCardName : public ITextDetector
		{
		public:
			Size m_xSize_C;
			float m_r_14;
			float m_r_18;
		public:
			TextDetectorBankCardName(Size&, shared_ptr<dnn::Net> &);
			~TextDetectorBankCardName();
			virtual vector<Rect> postprocDetections(Mat&, vector<Rect>&);
			virtual Mat resize(Mat&, float&, float&);
			vector<Rect> findTextLines(vector<Rect>&);

		};

		class TextDetectorBankCardValidThru : public ITextDetector
		{
		public:
			Size m_xSize_C;
			float m_r_14;
			float m_r_18;
			float m_r_1C;
		public:
			TextDetectorBankCardValidThru(Size&, shared_ptr<dnn::Net> &);
			~TextDetectorBankCardValidThru();
			virtual vector<Rect> postprocDetections(Mat&, vector<Rect>&);
			virtual Mat resize(Mat&, float&, float&);
		};

		class BankCardDatePostCorrector : public ITextLinesVisitor
		{
		public:
			BankCardDatePostCorrector();
			virtual void visit(RichTextLines &);
		};

		class BankCardExtractNameStringPostCorrector : public ITextLinesVisitor
		{
		public:
			BankCardExtractNameStringPostCorrector();
			virtual void visit(RichTextLines &);
		};

		class BankCardNumberPostCorrector : public  ITextLinesVisitor
		{
		public:
			BankCardNumberPostCorrector();
			virtual void visit(RichTextLines &);

			int m_nBCNPC_vft_0;
			shared_ptr<ICorrector> m_spIC_BCNPC_4;
		};
	}
}

