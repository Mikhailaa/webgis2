﻿#include "imseg.h"
#include "CTCHypoth.h"
#include "rclhelp.h"
#include "parameters.h"
#include "common/UnicodeUtils.h"
static const char *byte_1066C40 = "Ijifmlokn";

struct PAlign_Config
{
	int PAC_filed_0;
	int PAC_filed_4;
	int PAC_filed_8;
	char* PAC_filed_C;
	int PAC_filed_10;
};

struct PEdlib_Align
{
	int PEA_filed_0;
	int PEA_filed_4;
	int* PEA_filed_8;
	int* PEA_filed_C;
	int PEA_filed_10;
	char* PEA_filed_14;
	uint PEA_filed_18;
	uint PEA_filed_1C;
};

struct MYSTRUCT
{
	int64 nMS_0;
	int64 nMS_8;
	int nMS_10;
	//int nMS_14;
};

void edlibNewAlignConfig(PAlign_Config& a1, int a2, int a3, int a4, char* a5, int a6)
{
	a1.PAC_filed_0 = a2;
	a1.PAC_filed_4 = a3;
	a1.PAC_filed_8 = a4;
	a1.PAC_filed_C = a5;
	a1.PAC_filed_10 = a6;
}

string sub_4B85A0(set<wchar_t>& a2, wstring a3)
{
	string a1;
	for (size_t i = 0; i < a3.length(); i++)
	{
		set<wchar_t>::iterator iterFound = a2.find(a3[i]);
		set<wchar_t>::iterator iter = a2.begin();
		int v12 = 0;
		while (iter != iterFound)
		{
			iter++;
			v12++;
		}
		a1.push_back(v12);
	}
	return a1;
}

class EqualityDefinition
{
public:
	char m_data[256][256];

	EqualityDefinition(string & a2, char* a3, int a4)
	{
		for (uint i = 0; i < a2.size(); i++)
		{
			for (uint j = 0; j < a2.size(); j++)
			{
				m_data[i][j] = (i == j) ? 1 : 0;
			}
		}
		if (a3)
		{
			for (int i = 0; i < a4; i++)
			{
				int v16 = a2.find(a3[2 * i], 0);
				int v17 = a2.find(a3[2 * i + 1], 0);
				if (v16 != string::npos && v17 != string::npos)
				{
					m_data[v17][v16] = 1;
					m_data[v16][v17] = 1;
				}
			}
		}
	}
};

class AlignmentData
{
public:
	int64 * m_pnAD_0, *m_pnAD_4;
	int *m_pnAD_8, *m_pnAD_C, *m_pnAD_10;

	AlignmentData(int a2, int a3)
	{
		m_pnAD_0 = new int64[a3 * a2];
		m_pnAD_4 = new int64[a3 * a2];
		m_pnAD_8 = new int[a3 * a2];
		m_pnAD_C = new int[a3];
		m_pnAD_10 = new int[a3];
	}
	~AlignmentData()
	{
		if (m_pnAD_0)
			delete[] m_pnAD_0;
		if (m_pnAD_4)
			delete[] m_pnAD_4;
		if (m_pnAD_8)
			delete[] m_pnAD_8;
		if (m_pnAD_C)
			delete[] m_pnAD_C;
		if (m_pnAD_10)
			delete[] m_pnAD_10;
	}
};

int64 * sub_6297CD10(size_t a1, uchar *a2, size_t a3, EqualityDefinition &a4)
{
	size_t v6 = a3 / 64;
	if (a3 & 0x3F)
		v6++;
	int64* result = new int64[v6 * (a1 + 1)];
	for (size_t i = 0; i <= a1; i++)
	{
		uchar v13 = (uchar)i;
		for (size_t j = 0; j < v6; j++)
		{
			int64 v18;
			if (i >= a1)
			{
				v18 = -1;
			}
			else
			{
				size_t v17 = (j << 6) | 0x3F;
				v18 = 0;
				while (v17 >= j << 6)
				{
					v18 *= 2;
					if (v17 >= a3)
					{
						v18 |= 1;
					}
					else if (a4.m_data[a2[v17]][v13])
					{
						v18 |= 1;
					}
					--v17;
				}
			}
			result[i * v6 + j] = v18;
		}
	}
	return result;
}

int sub_6297E578(int64 a1, int64 a3, int64 a5, int a7, int64 *a8, int64 *a9)
{
	int v9 = (a7 >> 2) & 1;
	int64 v10 = a5 | a3;
	int64 v11 = (v9 | a5) & a1;
	v11 += a1;
	int64 v12 = v11 ^ a1 | a5 | v9;
	int64 v13 = a3 | ~(a1 | v12);
	int64 v14 = 2 * v13 | ((a7 + 1) >> 1);
	int64 v16 = v12 & a1;
	*a8 = v9 | 2 * v16 | ~(v14 | v10);
	*a9 = v14 & v10;
	return (v13 >> 63) - (v16 >> 63);
}

vector<int> sub_6297E684(int64 a3, int64 a5, int a7)
{
	vector<int> result(64);
	uint64 v8 = 0x8000000000000000;
	int v10 = a7;
	for (int i = 0; i < 63; i++)
	{
		result[i] = v10;
		if (v8 & a3)
			--v10;
		if (v8 & a5)
			++v10;
		v8 >>= 1;
	}
	result[63] = v10;
	return result;
}

int sub_6297D1E0(int64 *a0, int a1, int a2, int a3, uchar *a4, int a5, int a6, int *a7, int *a8, int a9, AlignmentData **a10, int a11)
{
	if (a11 >= 0 && a9)
		return 1;
	int v13 = a5;
	int v14 = a5 - a3;
	if (a5 - a3 < 0)
		v14 = a3 - a5;
	if (v14 > a6)
	{
		*a8 = -1;
		*a7 = -1;
		return 0;
	}
	int v15 = a3 - a5;
	if (a3 > a5)
		v13 = a3;
	if (v13 > a6)
		v13 = a6;
	int v16 = v13;
	if (v13 >= (v15 + v13) / 2)
		v13 = (v15 + v13) / 2;
	int v24 = (v13 + 1) / 64;
	if ((v13 + 1) & 0x3F)
		v24++;
	if (v24 > a2)
		v24 = a2;
	MYSTRUCT* v25 = new MYSTRUCT[a2];
	for (int i = 0; i < v24; i++)
	{
		v25[i].nMS_10 = (i + 1) * 64;
		v25[i].nMS_0 = -1;
		v25[i].nMS_8 = 0;
	}
	if (a9)
	{
		*a10 = new AlignmentData(a2, a5);
	}
	else if (a11 >= 0)
	{
		*a10 = new AlignmentData(a2, 1);
	}
	else
		*a10 = 0;
	int v32 = v24 - 1;
	int v96 = a2 - 1;
	int v102 = 0;
	for (int i = 0; i < a5; i++)
	{
		int v35 = 1;
		for (int j = v102; j <= v32; j++)
		{
			v35 = sub_6297E578(v25[j].nMS_0, v25[j].nMS_8, a0[j + a2 * a4[i]], v35, &v25[j].nMS_0, &v25[j].nMS_8);
			v25[j].nMS_10 += v35;
		}
		int v42 = a3 - ((v32 + 1) << 6);
		if (a5 - i - 1 > v42)
			v42 = a5 - i - 1;
		if (v32 == v96)
			v42 += a1;
		int v43 = min(v16, v42 + v25[v32].nMS_10);
		int v101 = v43;
		if (v32 + 1 < a2)
		{
			if (((v32 + 1) << 6) - 1 <= a3 + i + 126 - a5 - v25[v32].nMS_10 + v43)
			{
				v25[v32 + 1].nMS_0 = -1;
				v25[v32 + 1].nMS_8 = 0;
				int v49 = sub_6297E578(-1, 0, a0[a2 * a4[i] + v32 + 1], v35, &v25[v32 + 1].nMS_0, &v25[v32 + 1].nMS_8);
				++v32;
				v25[v32 + 1].nMS_10 = v49 + 64 - v35 + v25[v32].nMS_10;
			}
		}
		int v50 = (v32 << 6) - 1;
		int v51 = (v32 << 6) | 0x3F;
		v16 = v43;
		int v52 = v102;
		int v53 = v101 + 64;
		while (v32 >= v102)
		{
			if (v25[v32].nMS_10 < v53 && v51 <= a3 + i + 127 - a5 + v101 - v25[v32].nMS_10)
				break;
			v50 -= 64;
			v51 -= 64;
			--v32;
		}
		int v55 = (v102 << 6) | 0x3F;
		int v57 = a3 + i - a5 - v101;
		while (v52 <= v32 && (v25[v52].nMS_10 >= v53 || v55 < v25[v52].nMS_10 + v57))
		{
			v55 += 64;
			++v52;
		}
		if (!(i << 21))
		{
			int v58 = a3 + i + 1 - a5 + v101;
			bool fBreak = false;
			while (1)
			{
				if (v32 < v52)
					break;
				v16 = v101;
				vector<int> v107 = sub_6297E684(v25[v32].nMS_0, v25[v32].nMS_8, v25[v32].nMS_10);
				int v60 = 64;
				if (v32 == v96)
					v60 = 64 - a1;
				int v61 = v60 + v50;
				int v62 = 64 - v60;
				while (v62 <= 63)
				{
					if (v101 >= v107[v62] && v61 <= v58 - v107[v62])
					{
						fBreak = true;
						break;
					}
					v62++;
					v61--;
				}
				if (fBreak) break;
				v50 -= 64;
			}
			fBreak = false;
			while (v52 <= v32)
			{
				vector<int> v107 = sub_6297E684(v25[v52].nMS_0, v25[v52].nMS_8, v25[v52].nMS_10);
				int v66 = 64;
				if (v52 == v96)
					v66 = 64 - a1;
				int v67 = v66 + (v52 << 6);
				int v68 = 64 - v66;
				while (v68 <= 63)
				{
					if (v107[v68] <= v16 && v67 > v107[v68] + v57)
					{
						fBreak = true;
						break;
					}
					++v68;
					--v67;
				}
				if (fBreak) break;
				++v52;
			}
		}
		if (v32 < v52)
		{
			*a8 = -1;
			*a7 = -1;
			delete[] v25;
			return 0;
		}
		v102 = v52;
		if (a9)
		{
			int v71 = v52;
			while (v71 <= v32)
			{
				AlignmentData* v74 = *a10;
				v74->m_pnAD_0[a2 * i + v71] = v25[v71].nMS_0;
				v74->m_pnAD_4[a2 * i + v71] = v25[v71].nMS_8;
				v16 = v101;
				v74->m_pnAD_8[a2 * i + v71] = v25[v71].nMS_10;
				v74->m_pnAD_C[i] = v102;
				v74->m_pnAD_10[i] = v32;
				v71++;
			}
		}
		if (i == a11)
		{
			int v83 = v102;
			while (v83 <= v32)
			{
				AlignmentData* v86 = *a10;
				v86->m_pnAD_0[v83] = v25[v83].nMS_0;
				v86->m_pnAD_4[v83] = v25[v83].nMS_8;
				v86->m_pnAD_8[v83] = v25[v83].nMS_10;
				*v86->m_pnAD_C = v102;
				*v86->m_pnAD_10 = v32;
				v83++;
			}
			*a7 = -1;
			*a8 = a11;
			delete[] v25;
			return 0;
		}
	}
	if (v32 != v96)
	{
		*a8 = -1;
		*a7 = -1;
		delete[] v25;
		return 0;
	}
	vector<int> v106 = sub_6297E684(v25[v96].nMS_0, v25[v96].nMS_8, v25[v96].nMS_10);
	int v80 = v106[a1];
	if (v80 > v16)
	{
		*a8 = -1;
		*a7 = -1;
		delete[] v25;
		return 0;
	}
	*a7 = v80;
	*a8 = a5 - 1;
	delete[] v25;
	return 0;
}

int sub_6297E624(int64 a1, int64 a2, int a3, int a5)
{
	vector<int> v9 = sub_6297E684(a1, a2, a3);
	for (int i = 0; i <= 0x3F; i++)
	{
		if (v9[i] <= a5)
		{
			return 0;
		}
	}
	return 1;
}

void sub_6297CDF0(int64 *a1, int a2, int a3, int a4, uchar *a5, int a6, int a7, int a8, int *a9, int **a10, int *a11)
{
	int v11 = a4;
	int v111 = a7;
	int v18 = (a7 + 1) / 64;
	if ((a7 + 1) & 0x3F)
		v18++;
	if (v18 >= a3)
		v18 = a3;
	*a10 = 0;
	*a11 = 0;
	MYSTRUCT *v58 = new MYSTRUCT[a3];
	MYSTRUCT *v19 = v58;
	for (int i = 0; i < v18; i++)
	{
		v19->nMS_10 = 64 * (i + 1);
		v19->nMS_0 = -1;
		v19->nMS_8 = 0;
		++v19;
	}
	int v201 = 0;
	vector<int> v67;
	if (a8 == 2 && a4 < a7)
		v111 = v11;
	v11 = -1;
	int v23 = v18 - 1;
	int v57 = (a8 != 2) ? 1 : 0;
	for (int i = 0; i < a6; i++)
	{
		v19 = &v58[v201];
		int v28 = v57;
		for (int j = v201; j <= v23; j++)
		{
			v28 = sub_6297E578(v19->nMS_0, v19->nMS_8, a1[a3 * a5[i] + j], v28, &v19->nMS_0, &v19->nMS_8);
			v19->nMS_10 += v28;
			++v19;
		}
		if (v23 < a3 - 1
			&& (v58[v23].nMS_10 - v28 <= v111)
			&& (v28 < 0 || (a1[a3 * a5[i] + v23 + 1] & 1)))
		{
			v19->nMS_0 = -1;
			v19->nMS_8 = 0;
			v19->nMS_10 = sub_6297E578(-1LL, 0LL, a1[a3 * a5[i] + v23 + 1], v28, &v19->nMS_0, &v19->nMS_8) + v58[v23].nMS_10 - v28 + 64;
			++v23;
		}
		else
		{
			while (v23 >= v201 && v58[v23].nMS_10 >= v111 + 64)
			{
				--v23;
			}
			v19 = &v58[v23];
		}
		if (!(i & 0x7FF))
		{
			while (v23 >= v201)
			{
				if (!sub_6297E624(v19->nMS_0, v19->nMS_8, v19->nMS_10, v111))
				{
					break;
				}
				--v19;
				--v23;
			}
		}
		if (a8 == 2)
		{
			v23 &= ~(v23 >> 31);
		}
		else
		{
			while (v201 <= v23 && v58[v201].nMS_10 >= v111 + 64)
			{
				++v201;
			}
			if (!(i & 0x7FF))
			{
				while (v201 <= v23
					&& sub_6297E624(v58[v201].nMS_0, v58[v201].nMS_8, v58[v201].nMS_10, v111))
				{
					++v201;
				}
			}
		}
		if (v23 < v201)
			break;
		if (v23 == a3 - 1)
		{
			if (v19->nMS_10 <= v111 && (v11 == -1 || v19->nMS_10 <= v11))
			{
				if (v19->nMS_10 != v11)
				{
					v11 = v19->nMS_10;
					v111 = v19->nMS_10;
					v67.clear();
				}
				v67.push_back(i - a2);
			}
		}
	}
	if (v23 == a3 - 1)
	{
		vector<int> v66 = sub_6297E684(v19->nMS_0, v19->nMS_8, v19->nMS_10);

		for (int i = 0; i < a2; i++)
		{
			int v46 = 0;
			if (v66[i + 1] > v11)
				v46 = 1;
			if (v66[i + 1] <= v111 && (v66[i + 1] <= v11 || v11 == -1))
			{
				if (v66[i + 1] != v11)
				{
					v11 = v66[i + 1];
					v111 = v66[i + 1];
					v67.clear();
				}
				v67.push_back(a6 - a2 + i);
			}
		}
	}
	*a9 = v11;
	if (v11 != -1)
	{
		*a10 = (int*)malloc(v67.size() * sizeof(int));
		*a11 = v67.size();
		if (v67.size())
			memmove(*a10, v67.data(), v67.size() * sizeof(int));
	}
	delete[] v58;
}

uchar* sub_6297D778(uchar *a1, int a2)
{
	uchar* result = new uchar[a2];
	for (int i = 0; i < a2; ++i)
	{
		result[i] = a1[a2 - i - 1];
	}
	return result;
}

int sub_6297D79C(uchar *a1, uchar *a2, size_t a3, uchar *a4, uchar *a5, int a6, EqualityDefinition &a7, size_t a8, int a9, char *& a10, uint &a11)
{
	if (a3 == 0 || a6 == 0)
	{
		a11 = a3 + a6;
		a10 = (char *)malloc(a11);
		char v17 = 1;
		if (!a3)
			v17 = 2;
		for (uint i = 0; i < a11; i++)
		{
			a10[i] = v17;
		}
		return 0;
	}
	size_t v19 = a3 / 64;
	if (a3 & 0x3F)
		v19++;
	size_t v208 = (v19 << 6) - a3;
	if ((20 * v19 + 8) * a6 > 0xFFFFF)
	{
		int64* v89 = sub_6297CD10(a8, a1, a3, a7);
		int64* v90 = sub_6297CD10(a8, a2, a3, a7);
		int v229, v228;
		AlignmentData* v227 = 0;
		int v91 = sub_6297D1E0(v89, (v19 << 6) - a3, v19, a3, a4, a6, a9, &v229, &v228, 0, &v227, a6 / 2 - 1);
		int v190 = a6 - a6 / 2;
		AlignmentData* v226 = 0;
		int v92 = sub_6297D1E0(v90, (v19 << 6) - a3, v19, a3, a5, a6, a9, &v229, &v228, 0, &v226, v190 - 1);
		delete[] v89;
		delete[] v90;
		if (v91 == 1 || v92 == 1)
		{
			if (v227)
			{
				delete v227;
			}
			if (v226)
			{
				delete v226;
			}
		}
		else
		{
			int v181 = a6 / 2;
			int v98 = *v227->m_pnAD_C;
			int v971 = *v227->m_pnAD_10;
			int a0b = v971;
			v971 = ((v971 - v98) * 64) + 64;
			int* v205 = new int[v971];
			for (int i = v98; i <= a0b; i++)
			{
				int64 v104 = v227->m_pnAD_4[i];
				int64 v105 = v227->m_pnAD_0[i];
				int v107 = v227->m_pnAD_8[i];
				uint64 v112 = 0x8000000000000000;
				for (int j = 63; j > 0; j--)
				{
					v205[64 * (i - v98) + j] = v107;
					if (v112 & v105)
						--v107;
					if (v112 & v104)
						++v107;
					v112 >>= 1;
				}
				v205[64 * (i - v98)] = v107;
			}
			int v115 = *v226->m_pnAD_C;
			int v116 = *v226->m_pnAD_10;
			size_t v176 = v208;
			int v177 = (v116 - v115) * 64 + 64;
			if (a0b != (v19 - 1))
				v176 = 0;
			int* v211 = new int[v177];
			while (v116 >= v115)
			{
				uint64 v119 = 0x8000000000000000;
				int64 v120 = v226->m_pnAD_4[v115];
				int64 v121 = v226->m_pnAD_0[v115];
				int v122 = v226->m_pnAD_8[v115];
				for (int j = 0; j < 63; j++)
				{
					v211[64 * (v116 - v115) + j] = v122;
					if (v119 & v121)
						--v122;
					if (v119 & v120)
						++v122;
					v119 >>= 1;
				}
				v211[64 * (v116 - v115) + 63] = v122;
				++v115;
			}
			int v129 = (int)a3 - (v116 * 64) - 64;
			int* v212 = v211;
			int a3e = 0;
			if (v129 < 0)
			{
				v212 = &v211[v208];
				a3e = (int)v208;
			}
			if (v227)
			{
				delete v227;
			}
			int v132 = a3e + v129;
			int v133 = v98 * 64;
			if (v226)
			{
				delete v226;
			}
			int v135 = v971 + 64 * v98 - v176;
			int v136 = v132 - 1;
			int v137 = v177 + v129;
			int v138 = v177 + v129 - 2;
			if (v135 - 1 < v138)
				v138 = v135 - 1;
			if (v98 * 64 > v136)
				v136 = v98 * 64;
			int* v139 = &v212[v136 + (v116 << 6) + 65 - (a3e + a3)];
			bool v140;
			while (1)
			{
				if (v136 > v138)
				{
					v140 = false;
					if (v98 == 0 && v132 == 0)
					{
						v133 = a6 / 2;
						v129 = v211[a3e];
						if (v129 + v181 == a9)
						{
							v136 = -1;
							v140 = true;
						}
					}
					if (v137 == (int)a3)
					{
						if (v135 == (int)a3 && !v140)
						{
							v129 = a6 - a6 / 2;
							v133 = v205[v971 - v176 - 1];
							if (v133 + v190 == a9)
							{
								v136 = (int)a3 - 1;
								v140 = true;
							}
						}
					}
					break;
				}
				v133 = v205[v136 - 64 * v98];
				v129 = *v139;
				++v139;
				v136++;
				if (v129 + v133 == a9)
				{
					--v136;
					v140 = true;
					break;
				}
			}
			delete[] v205;
			delete[] v211;
			if (v140)
			{
				char* ptr = 0;
				size_t v157 = (size_t)v136 + 1;
				uint v224;
				int v158 = sub_6297D79C(a1, &a2[a3 - v157], v157, a4, &a5[v190], v181, a7, a8, v133, ptr, v224);
				char* arg14a = 0;
				uint v222;
				int v159 = sub_6297D79C(&a1[v157], a2, a3 - v157, &a4[v181], a5, v190, a7, a8, v129, arg14a, v222);
				if (v158 != 1 && v159 != 1)
				{
					a11 = v222 + v224;
					a10 = (char *)malloc(a11);
					memcpy(a10, ptr, v224);
					memcpy(&a10[v224], arg14a, v222);
					free(ptr);
					free(arg14a);
					return 0;
				}
				free(ptr);
				free(arg14a);
			}
		}
		return 1;
	}
	AlignmentData* v227 = 0;
	int v22 = a9;
	int64* v178 = sub_6297CD10(a8, a1, a3, a7);
	int v229, v228;
	sub_6297D1E0(v178, v208, v19, a3, a4, a6, a9, &v229, &v228, 1, &v227, -1);
	int v231 = a6 - 1;
	int v23 = v19 - 1;
	int v24 = a6 - 1 + a3;
	size_t v25 = v19 - 1 + v19 * (a6 - 1);
	a10 = (char *)malloc(v24);
	a11 = 0;
	bool v197 = false;
	int64 v28 = v227->m_pnAD_4[v25];
	int64 v206 = v227->m_pnAD_0[v25];
	int64 v30 = 0;
	int64 v32 = 0;
	if (a6 >= 2)
	{
		if ((int)v19 > v227->m_pnAD_C[a6 - 2] && v23 <= v227->m_pnAD_10[a6 - 2])
		{
			v197 = true;
			v30 = v227->m_pnAD_0[v23 + v19 * (a6 - 2)];
			v32 = v227->m_pnAD_4[v23 + v19 * (a6 - 2)];
		}
	}
	int64 v35 = v28 << v208; // HIDWORD(v195), HIDWORD(v204)
	int64 v39 = v206 << v208; // LODWORD(v195), LODWORD(v204)
	int v43 = v231;
	int v44 = -1;
	int a3b = 63 - v208;
	int v45 = -1;
	int v202 = -1;
	while (1)
	{
		if (!v43)
		{
			v197 = true;
			v45 = a3b + (v23 << 6);
			v44 = v45 + 1;
		}
		v231 = v43;
		int v74 = v44;
		if (v44 == -1 && v197)
		{
			v74 = v227->m_pnAD_8[v23 + (v43 - 1) * v19];
			for (int j = 0; j < 63 - a3b; j++)
			{
				if (v30 < 0) v74--;
				if (v32 < 0) v74++;
				v32 *= 2;
				v30 *= 2;
			}
		}
		if (v45 == -1)
		{
			if (v74 == -1)
			{
				if (v231 < 1)
				{
					v45 = -1;
				}
				else
				{
					if (v23 > v227->m_pnAD_C[v231 - 1] && v23 - 1 <= v227->m_pnAD_10[v231 - 1])
						v45 = v227->m_pnAD_8[v23 - 1 + (v231 - 1) * v19];
					else
						v45 = -1;
				}
			}
			else
			{
				v45 = v74;
				if (v30 < 0) v45--;
				if (v32 < 0) v45++;
			}
		}
		int a0a = v45;
		int v69 = v202;
		if (v202 == -1)
		{
			v69 = v22;
			if (v39 < 0) v69--;
			if (v35 < 0) v69++;
			v35 *= 2; // HIDWORD(v195), v83
			v39 *= 2; // LODWORD(v195), v82
		}
		int v49;
		if (v69 == -1 || v69 + 1 != v22)
		{
			if (v74 != -1 && v74 + 1 == v22)
			{
				if (!v231)
				{
					a10[a11++] = 2;
					for (int j = 0; j <= a3b + (v23 << 6); j++)
					{
						a10[a11++] = 1;
					}
					break;
				}
				v35 = v32;
				v39 = v30;
				if (v231 >= 2
					&& v23 >= v227->m_pnAD_C[v231 - 2]
					&& v23 <= v227->m_pnAD_10[v231 - 2])
				{
					v49 = -1;
					int v70 = v23 + (v231 - 2) * v19;
					v30 = v227->m_pnAD_0[v70];
					v32 = v227->m_pnAD_4[v70];
					v44 = -1;
					v197 = true;
				}
				else
				{
					if (v231 == 1)
					{
						v197 = true;
						v49 = a3b + (v23 << 6);
						v44 = v49 + 1;
					}
					else
					{
						v49 = -1;
						v197 = false;
						v44 = -1;
					}
				}
				a10[a11++] = 2;
				v202 = v45;
				v69 = v74;
				v43 = v231 - 1;
				v45 = v49;
				v22 = v69;
				continue;
			}
			if (v45 == -1)
				break;
			int v52 = v45 - v22;
			if (v45 != v22)
				v52 = 3;
			if (v231)
			{
				int v53 = v23;
				int v199 = v231 - 1;
				int v55 = a3b - 1;
				v35 = v32 * 2;
				v39 = v30 * 2;
				if (!a3b)
				{
					if (!v23)
					{
						a10[a11++] = v52;
						for (int j = 0; j < v231; j++)
						{
							a10[a11++] = 2;
						}
						break;
					}
					v53 = v23 - 1;
					int v64 = v23 - 1 + v199 * v19;
					v39 = v227->m_pnAD_0[v64];
					v35 = v227->m_pnAD_4[v64];
					v55 = 63;
				}
				v23 = v53;
				a3b = v55;
				if (v231 >= 2
					&& v53 >= v227->m_pnAD_C[v231 - 2]
					&& v53 <= v227->m_pnAD_10[v231 - 2])
				{
					v197 = true;
					v49 = -1;
					int v71 = v53 + (v231 - 2) * v19;
					v30 = v227->m_pnAD_0[v71];
					v32 = v227->m_pnAD_4[v71];
					v44 = -1;
				}
				else
				{
					if (v231 == 1)
					{
						v49 = v55 + (v53 << 6);
						v197 = true;
						v44 = v49 + 1;
					}
					else
					{
						v197 = false;
						v44 = -1;
						v49 = -1;
					}
				}
				v202 = -1;
				a10[a11++] = v52;
				v69 = a0a;
				v43 = v199;
				v45 = v49;
				v22 = v69;
				continue;
			}
			a10[a11++] = v52;
			a11 = a11;
			for (int j = 0; j < a3b + (v23 << 6); j++)
			{
				a10[a11++] = 1;
			}
			break;
		}
		if (a3b)
		{
			--a3b;
			v43 = v231;
			v32 *= 2;
			v30 *= 2;
		}
		else
		{
			if (!v23)
			{
				a10[a11++] = 1;
				for (int j = 0; j <= v231; j++)
				{
					a10[a11++] = 2;
				}
				break;
			}
			int v59 = v23 - 1;
			int v60 = v23 - 1 + v231 * v19;
			v43 = v231;
			v39 = v227->m_pnAD_0[v60];
			v35 = v227->m_pnAD_4[v60];
			if (v231 < 1)
			{
				v197 = false;
				a3b = 63;
				v23 = v23 - 1;
			}
			else
			{
				if (v23 > v227->m_pnAD_C[v231 - 1] && v59 <= v227->m_pnAD_10[v231 - 1])
				{
					v197 = true;
					int v72 = v59 + (v231 - 1) * v19;
					v32 = v227->m_pnAD_4[v72];
					v30 = v227->m_pnAD_0[v72];
					a3b = 63;
				}
				else
				{
					a3b = 63;
					v197 = false;
				}
				v23 = v23 - 1;
				v43 = v231;
			}
		}
		v49 = -1;
		a10[a11++] = 1;
		v202 = -1;
		v44 = v45;
		v45 = v49;
		v22 = v69;
	}
	a10 = (char *)realloc(a10, a11);
	if (a11)
	{
		char* v172 = a10;
		for (char* j = &v172[a11 - 1]; v172 < j; --j)
		{
			char v174 = *v172;
			*v172++ = *j;
			*j = v174;
		}
	}
	if (v227)
	{
		delete v227;
	}
	delete[] v178;
	return 0;
}

void edlibAlign(PEdlib_Align *a1, const char *a2, size_t a3, const char *a4, size_t a5, int a6, int a7, int a8, char *a9, int a10)
{
	a1->PEA_filed_8 = 0;
	a1->PEA_filed_C = 0;
	a1->PEA_filed_10 = 0;
	a1->PEA_filed_14 = 0;
	a1->PEA_filed_0 = 0;
	a1->PEA_filed_1C = 0;
	a1->PEA_filed_4 = -1;
	a1->PEA_filed_18 = 0;
	uchar* ptr = (uchar*)malloc(a3);
	uchar* v62 = (uchar*)malloc(a5);
	string v67;
	uchar v68[256];
	uchar v69[256];

	for (int i = 0; i < 256; i++)
		v69[i] = 0;
	for (int i = 0; i < (int)a3; ++i)
	{
		uchar v19, v18 = (uchar)a2[i];
		if (v69[v18])
		{
			v19 = v68[v18];
		}
		else
		{
			v69[v18] = 1;
			v19 = (uchar)v67.size();
			v68[v18] = v19;
			v67 += v18;
		}
		ptr[i] = v19;
	}
	for (int i = 0; i < (int)a5; ++i)
	{
		uchar v23, v22 = (uchar)a4[i];
		if (v69[v22])
		{
			v23 = v68[v22];
		}
		else
		{
			v69[v22] = 1;
			v23 = (uchar)v67.size();
			v68[v22] = v23;
			v67 += v22;
		}
		v62[i] = v23;
	}
	a1->PEA_filed_1C = v67.size();
	EqualityDefinition ed(v67, a9, a10);
	size_t v27 = v67.size();
	size_t v28 = a3 / 64;
	if (a3 & 0x3F)
		v28++;
	int64* v60 = sub_6297CD10(v27, ptr, a3, ed);
	int v29 = a6;
	AlignmentData* v66 = 0;
	if (a6 < 0)
		v29 = 64;
	do
	{
		if ((uint)(a7 - 1) > 1)
			sub_6297D1E0(v60, (v28 << 6) - a3, v28, a3, v62, a5, v29, &a1->PEA_filed_4, (int*)v69, 0, &v66, -1);
		else
			sub_6297CDF0(v60, (v28 << 6) - a3, v28, a3, v62, a5, v29, a7, &a1->PEA_filed_4, &a1->PEA_filed_8, &a1->PEA_filed_10);
		if (a6 > -1)
			break;
		v29 *= 2;
	} while (a1->PEA_filed_4 == -1);
	if (a1->PEA_filed_4 >= 0)
	{
		if (!a7)
		{
			a1->PEA_filed_8 = (int*)malloc(sizeof(int));
			*a1->PEA_filed_8 = a5 - 1;
			a1->PEA_filed_10 = 1;
		}
		if ((uint)(a8 - 1) <= 1)
		{
			a1->PEA_filed_C = (int*)malloc(a1->PEA_filed_10 * sizeof(int));
			if (a7 == 2)
			{
				uchar* v35 = sub_6297D778(v62, a5);
				uchar* v36 = sub_6297D778(ptr, a3);
				int64* v53 = sub_6297CD10(v67.size(), v36, a3, ed);
				for (int i = 0; i < a1->PEA_filed_10; i++)
				{
					int v65, v64;
					int* v63;
					sub_6297CDF0(v53, (v28 << 6) - a3, v28, a3, v35 + a5 - 1 - a1->PEA_filed_8[i], a1->PEA_filed_8[i] + 1, a1->PEA_filed_4, 1, &v65, &v63, &v64);
					a1->PEA_filed_C[i] = a1->PEA_filed_8[i] - v63[v64 - 1];
					free(v63);
				}
				delete[] v35;
				delete[] v36;
				delete[] v53;
			}
			else
			{
				for (int k = 0; k < a1->PEA_filed_10; ++k)
					a1->PEA_filed_C[k] = 0;
			}
			if (a8 == 2)
			{
				int v44 = *a1->PEA_filed_C;
				int v46 = *a1->PEA_filed_8 - v44 + 1;
				uchar* v47 = sub_6297D778(&v62[v44], v46);
				uchar* v48 = sub_6297D778(ptr, a3);
				sub_6297D79C(ptr, v48, a3, &v62[v44], v47, v46, ed, v67.size(), a1->PEA_filed_4, a1->PEA_filed_14, a1->PEA_filed_18);
				delete[] v47;
				delete[] v48;
			}
		}
	}
	operator delete[](v60);
	free(ptr);
	free(v62);
	if (v66)
	{
		delete v66;
	}
}

void edlibFreeAlignResult(int a1, int a2, void *ptr, void *a4, int a5, void *p)
{
	if (ptr)
		free(ptr);
	if (a4)
		free(a4);
	if (p)
		free(p);
}

namespace imseg
{
	CharPlace Chars({}, { 0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38 , 0x39 }, CharPlace::CHARPLACETYPE_0);
	CharPlace Dash({ 0x2D }, {}, CharPlace::CHARPLACETYPE_0);
	CharPlace Digits({ 0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38 , 0x39 }, {}, CharPlace::CHARPLACETYPE_0);
	CharPlace Dot({ 0x2E }, {}, CharPlace::CHARPLACETYPE_0);
	CharPlace Slash({ 0x2F }, {}, CharPlace::CHARPLACETYPE_0);
	CharPlace Space({ 0x20 }, {}, CharPlace::CHARPLACETYPE_0);
	CharPlace Wild({}, { 0x20, 0x2E, 0x2F, 0x2D }, CharPlace::CHARPLACETYPE_0);

	

	vector<vector<vector<TextPartStruct>>> processMultistringness(Field &arg1, uint arg2)
	{
		vector<vector<vector<TextPartStruct>>> RES_vvvTextPartStruct;
		FieldAdapter _xFieldAdapter_30(&arg1);
		for (int i = 0; i < _xFieldAdapter_30.getLogiclOrPartsCount(); i++)
		{
			vector<vector<TextPartStruct>> _vvTextPartStruct_24 = _xFieldAdapter_30.getStrings(i, arg2);
			if (!_vvTextPartStruct_24.empty())
			{
				if (RES_vvvTextPartStruct.empty())
				{
					for (size_t j = 0; j < _vvTextPartStruct_24.size(); j++)
					{
						vector<vector<TextPartStruct>> _vvTextPartStruct_C;
						_vvTextPartStruct_C.push_back(_vvTextPartStruct_24[j]);
						RES_vvvTextPartStruct.push_back(_vvTextPartStruct_C);
					}
				}
				else if (_vvTextPartStruct_24.size() == RES_vvvTextPartStruct.size())
				{
					for (size_t j = 0; j < _vvTextPartStruct_24.size(); ++j)
						RES_vvvTextPartStruct[j].push_back(_vvTextPartStruct_24[j]);
				}
			}			
		}
		return RES_vvvTextPartStruct;
	}

	int alignStrings(string const& a1, string const& a2, vector<int>& a3)
	{
		PEdlib_Align edAlign;
		PAlign_Config AlignConfig;
		edlibNewAlignConfig(AlignConfig, -1, 0, 2, 0, 0);
		edlibAlign(&edAlign, a1.data(), a1.size(), a2.data(), a2.size(), AlignConfig.PAC_filed_0, AlignConfig.PAC_filed_4, AlignConfig.PAC_filed_8, AlignConfig.PAC_filed_C, AlignConfig.PAC_filed_10);
		a3 = vector<int>(edAlign.PEA_filed_18, -1);
		for (uint i = 0; i < edAlign.PEA_filed_18; i++)
		{
			a3[i] = edAlign.PEA_filed_14[i];
		}
		int v13 = edAlign.PEA_filed_4;
		edlibFreeAlignResult(edAlign.PEA_filed_0, edAlign.PEA_filed_4, edAlign.PEA_filed_8, edAlign.PEA_filed_C, edAlign.PEA_filed_10, edAlign.PEA_filed_14);
		return v13;
	}

	int alignStrings(wstring const&ws_a1, wstring const&ws_a2, vector<int> &vn_a3)
	{
		int v9 = ws_a1.size();
		int v13 = ws_a2.size();
		if (ws_a1.empty() || ws_a2.empty()) return max(v9, v13);

		set<wchar_t> setwchar_30;

		wstring ws_40[2] = { ws_a1 , ws_a2 };
		for (int i = 0; i < 2; i++)
		{
			for (size_t j = 0; j < ws_40[i].length(); j++)
			{
				setwchar_30.insert(ws_40[i][j]);
			}
		}

		string s_38 = sub_4B85A0(setwchar_30, ws_a1);
		string s_39 = sub_4B85A0(setwchar_30, ws_a2);
		return alignStrings(s_38, s_39, vn_a3);
	}

	eProcessOptions convertProcessOption(string const &arg1)
	{
		if (arg1.size() == 3)
		{
			if (!arg1.compare(0, -1, "DNN", 3))
				return PROCESS_OPTION_8;
		}

		if (arg1.size() == 21)
		{
			if (!arg1.compare(0, -1, "ColorBackgroundRemove", 21))
				return PROCESS_OPTION_9;
		}

		if (arg1.size() == 3)
		{
			if (!arg1.compare(0, -1, "CBR", 3))
				return PROCESS_OPTION_9;
		}

		if (arg1.size() == 3)
		{
			if (!arg1.compare(0, -1, "FRV", 3))
				return PROCESS_OPTION_10;
		}

		if (arg1.size() == 3)
		{
			if (!arg1.compare(0, -1, "LCT", 3))
				return PROCESS_OPTION_11;
		}

		if (arg1.size() == 8)
		{
			if (!arg1.compare(0, -1, "BCNUMBER", 8))
				return PROCESS_OPTION_12;
		}

		if (arg1.size() == 6)
		{
			if (!arg1.compare(0, -1, "BCDATE", 6))
				return PROCESS_OPTION_13;
		}

		if (arg1.size() == 6)
		{
			if (!arg1.compare(0, -1, "BCNAME", 6))
				return PROCESS_OPTION_14;
		}

		return PROCESS_OPTION_0;
	}

	bool operator==(CTCHypoth const &xCTCHy_a1, CTCHypoth const &xCTCHy_a2)
	{
		return xCTCHy_a1.m_wcUnicode_4 == xCTCHy_a2.m_wcUnicode_4;
	}

	bool operator<(CTCHypoth const &xCTCHy_a1, CTCHypoth const &xCTCHy_a2)
	{
		if (xCTCHy_a1.m_fHandmade_14 < xCTCHy_a2.m_fHandmade_14) return 1;
		return 0;
	}

	string toString(vector<vector<vector<SymbolCandidatWithRect>>> &vvvSymbolCandidatWithRect_a1)
	{
		string res_str;
		stringstream _xStringstream_18;
		vector<SymbolCandidatWithRect> vSymbolCandidatWithRect_C;
		if (!vvvSymbolCandidatWithRect_a1.empty())
		{
			for (size_t i = 0; i < vvvSymbolCandidatWithRect_a1.front().size(); i++)
			{
				vSymbolCandidatWithRect_C = move(vvvSymbolCandidatWithRect_a1.front()[i]);
				_xStringstream_18 << (char)vSymbolCandidatWithRect_C.front().m_xSymCandidat_0.m_wszCandiateCharacter_0;
			}
		}
		res_str = _xStringstream_18.str();
		return res_str;
	}

	vector<cv::Rect> imseg::bindrects::getBindRectsForRemove(RclHolder &arg1)
	{
		vector<cv::Rect> res;
		Rect _cvRect_4;
		tagSIZE _xtagSIZE_2C = rclhelp::imageSize(arg1.m_xTRCL);
		vector<TResultContainer*> _vpTResultContainer = arg1.getRcList(70);
		if (!_vpTResultContainer.empty())
		{
			if (_vpTResultContainer[0]->u.pTRC_obj)
			{
				TBindingResultsList *v4 = (TBindingResultsList *)_vpTResultContainer[0]->u.pTRC_obj;
				if (v4)
				{
					for (int i = 0; i< MIN(v4->nBRL_Layers, 3); i++)
					{
						for (int j = 0; j< v4->pxBRL_ArrayResults[i].nTBR_countPosition; j++)
						{
							if (v4->pxBRL_ArrayResults[i].pxTBR_position)
							{
								TBindingPosition *v9 = &v4->pxBRL_ArrayResults[i].pxTBR_position[j];
								if (v9->rTBP_probability >= 0.6f)
								{
									_cvRect_4.width = v9->xTBP_rect.right - v9->xTBP_rect.left;
									_cvRect_4.height = v9->xTBP_rect.bottom - v9->xTBP_rect.top;
									_cvRect_4.x = v9->xTBP_rect.left + v9->nTBP_shiftX;
									_cvRect_4.y = _xtagSIZE_2C.cy - v9->xTBP_rect.bottom - v9->nTBP_shiftY;
									res.push_back(_cvRect_4);
								}
							}
						}
					}
				}
			}
		}
		return res;
	}

	bool ConfigByLCID::isBankCardLcid(int arg1)
	{
		return arg1 == 10001 || (arg1 | 2) == 10002;
	}

	namespace container
	{
		void addString(vector<vector<SymbolCandidatWithRect>> &arg1, Text &arg2, string &arg3, FieldParam &arg4, int nHeight, bool arg6)
		{
			arg2.m_vimsegSymbol_0.resize(arg1.size());
			wstring _ws_20;
			vector<SymbolCandidatWithRect>::iterator iter;

			int nIdx = 0;
			for (size_t i = 0; i < arg1.size(); i++)
			{
				if (!arg6 || arg1[i].empty() || arg1[i].front().m_xSymCandidat_0.m_wszCandiateCharacter_0 != ' ')
				{
					arg2.m_vimsegSymbol_0[nIdx] = Symbol();

					arg2.m_vimsegSymbol_0[nIdx].m_xRECT_0.left = arg1[i].front().m_xRect_14.x;
					arg2.m_vimsegSymbol_0[nIdx].m_xRECT_0.top = arg1[i].front().m_xRect_14.y + arg1[i].front().m_xRect_14.height;
					arg2.m_vimsegSymbol_0[nIdx].m_xRECT_0.right = arg1[i].front().m_xRect_14.x + arg1[i].front().m_xRect_14.width;
					arg2.m_vimsegSymbol_0[nIdx].m_xRECT_0.bottom = arg1[i].front().m_xRect_14.y;

					if (nHeight)
					{
						arg2.m_vimsegSymbol_0[nIdx].m_xRECT_0.top = nHeight - arg1[i].front().m_xRect_14.y;
						arg2.m_vimsegSymbol_0[nIdx].m_xRECT_0.bottom = nHeight - (arg1[i].front().m_xRect_14.y + arg1[i].front().m_xRect_14.height);
					}

					arg2.m_vimsegSymbol_0[nIdx].field_50 = 1;
					arg2.m_vimsegSymbol_0[nIdx].m_xRECT_40 = arg2.m_vimsegSymbol_0[i].m_xRECT_0;

					if (arg4.contain(PROCESS_OPTION_2))
					{
						// no check
						if (arg1[i].front().m_xSymCandidat_0.m_wszCandiateCharacter_0 == 'O') //4F
						{
							if (arg1[i].size() >= 2)
							{
								for (size_t j = 1; j < arg1[i].size(); j++)
								{
									if (arg1[i][j].m_xSymCandidat_0.m_wszCandiateCharacter_0 == '0') 
									{
										SymbolCandidatWithRect _tmp = arg1[i].front();
										arg1[i].front() = arg1[i][j];
										arg1[i][j] = _tmp;
										break;
									}
								}
							}
						}
					}

					for (size_t j = 0; j < arg1[i].size(); j++)
					{
						arg2.m_vimsegSymbol_0[nIdx].m_xRecRes2_18.m_vSymCandidat.push_back(arg1[i][j].m_xSymCandidat_0);
						if (!j)
							_ws_20.push_back(arg1[nIdx].front().m_xSymCandidat_0.m_wszCandiateCharacter_0);
						if (arg1[i].front().m_xSymCandidat_0.m_wszCandiateCharacter_0 == ' ') break;
					}

					nIdx++;
				}
			}

			arg2.m_vimsegSymbol_0.resize(nIdx);
			arg3 = common::UnicodeUtils::WStrToUtf8(_ws_20);
		}
	}

	namespace field
	{
		void getAllFieldInfoVariants(Field &arg1, set<pair<eVisualFieldType, int>>&arg2)
		{
			for (size_t i = 0; i < arg1.m_vTextStruct_58.size(); i++)
			{
				for (size_t j = 0; j < arg1.m_vTextStruct_58[i].m_vTextPartStruct_0.size(); j++)
				{
					if (arg1.m_vTextStruct_58[i].m_vTextPartStruct_0[j].m_bField_38)
					{
						vector<int> vLcid = arg1.m_vTextStruct_58[i].m_vTextPartStruct_0[j].m_xTextPartLCIDInfo_70.lcids();

						eVisualFieldType v15 = eVisualFieldType(0);
						int v16 = 0;
						pair<eVisualFieldType, int> _pair;
						for (uint k = 0; k < vLcid.size(); k++)
						{
							v15 = (eVisualFieldType)arg1.m_vTextStruct_58[i].m_vTextPartStruct_0[j].fieldType();
							v16 = vLcid[k];
							_pair = make_pair(v15, v16);
							arg2.emplace(_pair);
							if (arg1.m_vTextStruct_58[i].m_vTextPartStruct_0[j].m_xTextPartLCIDInfo_70.m_nTPLCIDI_0 == 1)
								break;
						}
					}
				}
			}
		}

		void generateEmptyTextResults(Field &arg1, int arg2, CRecognizedTextDoc &arg3)
		{
			set<pair<eVisualFieldType, int>> _set_pairnn_4;
			getAllFieldInfoVariants(arg1, _set_pairnn_4);
			set <pair<eVisualFieldType, int>>::iterator iter = _set_pairnn_4.begin();
			while (iter != _set_pairnn_4.end())
			{
				CRecognizedTextFieldSDK *_pCRTFSDK = arg3.add();
				_pCRTFSDK->setMask("{STRINGS_DEF}");
				_pCRTFSDK->u0.s0.wFieldType = (*iter).first;
				_pCRTFSDK->u0.s0.wLCID = (*iter).second;
				_pCRTFSDK->nDVEF_Reserved3 = arg2;
				iter++;
			}
		}
	}

	void TTAParams::augment(Rect &xRect)
	{
		float oheight = (float)xRect.height;
		xRect.x += int(m_TTAParams_8 * oheight);
		xRect.height += int(2 * m_TTAParams_0 * oheight);
		xRect.y += int(m_TTAParams_4 * xRect.height - m_TTAParams_0 * oheight);
	}

};

namespace ImSegNS
{
	namespace Error
	{
		int checkCodeError(int arg1)
		{
			if (arg1 >= 2 && (arg1 + 3999) >> 3 > 124)
				arg1 = -3000;
			return arg1;
		}
	};
};

eRPRM_Lights imseg::docinfo::getLightType(TVisualField &xTVisualField_a1)
{
	bool bUseOnlyWiteImage = imseg::parameters::get_UseOnlyWhiteImage();
	if (bUseOnlyWiteImage) return RPRM_Lights_6;
	return (eRPRM_Lights)xTVisualField_a1.nTVF_lightType;
}
