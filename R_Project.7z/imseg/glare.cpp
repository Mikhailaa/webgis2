#include "glare.h"
#include "common/GlaresHolder.h"

namespace imseg
{
	namespace glare
	{
		map<int, bool> getFieldGlaresIntersectionMap(CDocInfo &arg1, TResultContainerList &arg2)
		{
			map<int, bool> res;
			RclHolder _xRclHolder_2C(arg2, 1);
			common::GlaresHolder xGlaresHolder_20(_xRclHolder_2C);
			CVisualField *v5;
			tagRECT _xtagRECT_10;
			for (int i = 0; i < arg1.nTDI_nFields; i++)
			{
				v5 = arg1.get(i);
				_xtagRECT_10 = v5->getRegion();
				bool v6 = xGlaresHolder_20.isAreaContainsGlares(_xtagRECT_10, 0.1);
				res[v5->u.nTVF_type] = v6;
			}
			return res;
		}
	}
}