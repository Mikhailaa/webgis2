#pragma once

#include "pch.h"
#include "CharPlace.h"
#include "CostMat.h"

using namespace imseg;

namespace imseg {
	class NeedlemanWulschAlg
	{
	public:
		//imseg::NeedlemanWulschAlg::min(float const&, float const&, float const&); no xref
		static float alignSeqs(vector<CTCHypoth> &, vector<CharPlace> &, CostMat &, vector<CTCHypoth>&, vector<CharPlace>&);
	};
}
