#pragma once
#include "imseg_interface.h"
#include "CTCHypoth.h"

namespace imseg
{
	class DeleteLowProbableSymbols : public ICorrector
	{
	public:
		float m_rDeleteLowProbableSymbols_field_8;
		int m_nDeleteLowProbableSymbols_field_C;
		DeleteLowProbableSymbols(int, ICorrector*);
		~DeleteLowProbableSymbols();
		int mustBeDeleted(CTCHypoth&);
		virtual void process_impl(vector<CTCHypoth> &);
	};
}