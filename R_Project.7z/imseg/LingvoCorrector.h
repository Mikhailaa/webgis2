#pragma once
#include "imseg_interface.h"
#include "CTCHypoth.h"

namespace imseg
{
	class LingvoCorrector : public ICorrector
	{
	public:
		int m_nLingvoCorrector_8;
		LingvoCorrector(int, ICorrector*);
		~LingvoCorrector();
		virtual void process_impl(vector<CTCHypoth> &);
	};
}