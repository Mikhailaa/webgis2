#include "DeleteLastSpaces.h"

imseg::DeleteLastSpaces::DeleteLastSpaces(ICorrector*pICorrector)
{
	m_pIC_4 = pICorrector;
}

imseg::DeleteLastSpaces::~DeleteLastSpaces()
{
}

void imseg::DeleteLastSpaces::process_impl(vector<CTCHypoth>&vCTCHypoth)
{
	if (vCTCHypoth.size())
	{
		for (int i = vCTCHypoth.size() - 1; i >= 0; i--)
		{
			if (vCTCHypoth[i].getUnicode() != ' ')
				break;
			vCTCHypoth.erase(vCTCHypoth.begin() + i);
		}
		for (size_t i = 0; i < vCTCHypoth.size(); i++)
		{
			if (vCTCHypoth[i].getUnicode() != ' ')
				break;
			vCTCHypoth.erase(vCTCHypoth.begin() + i);
		}
	}
}
