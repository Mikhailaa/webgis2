#pragma once
#include "Label2Unicodes.h"
#include "CTCHypoth.h"
#include "imseg_interface.h"

namespace imseg
{
	namespace word_beam_search
	{
		class Beam;
		class LanguageModel;

		enum LanguageModelType
		{
			LANGUAGEMODELTYPE_0,
			LANGUAGEMODELTYPE_1,
			LANGUAGEMODELTYPE_2,
			LANGUAGEMODELTYPE_3
		};

		struct Char
		{
			int   nChar_0;
			float rChar_4;
		};

		struct HashFunction
			: public unary_function<vector<uint>, size_t>
		{
			int operator()(const vector<uint> &__v) const noexcept
			{
				int nres = __v.size();

				for (size_t i = 0; i < __v.size(); i++)
				{
					nres ^= (__v[i] + (nres << 6) + (nres >> 2) - 0x61C88647);
				}

				return nres;
			}
		};

		vector<CTCHypoth> beam2HypothSeq(shared_ptr<Beam> const&, shared_ptr<LanguageModel> const&, Label2Unicodes const&);
		vector<uint> calcLM2VisualLabels(shared_ptr<LanguageModel> const&, Label2Unicodes const&);
		vector<Char> getBestChars(double, Label2Unicodes const&, vector<uint> const&, shared_ptr<LanguageModel> const&, IMatrix const&, uint);
		vector<CTCHypoth> wordBeamSearch(IMatrix const&, Label2Unicodes const&, shared_ptr<LanguageModel> const&, LanguageModelType);
	}
}