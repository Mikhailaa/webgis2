﻿#include "NeedlemanWulschAlg.h"
#include "imseg.h"
using namespace cv;

namespace imseg
{
	extern CharPlace Wild;
}


float NeedlemanWulschAlg::alignSeqs(vector<CTCHypoth> &a1, vector<CharPlace> &a2, CostMat & a3, vector<CTCHypoth>&a4, vector<CharPlace>&a5)
{

	Mat_<float> fMat_8C(a1.size() + 1, a2.size() + 1);

	float r_s16 = 0.0;
	float r_r5, r_s18, r_s20, r_s0, r_s2, r_s4, r_r4, r_s22, r_r6, r_s26, r_s24;

	for (size_t col = 0; col <= a2.size(); col++)
	{
		fMat_8C(0, col) = r_s16;  
		if (col < a2.size())
			r_s16 += a3.getDeletingCost(a2[col]);
	}

	r_s16 = 0.0;
	for (size_t row = 0; row <= a1.size(); row++)
	{
		fMat_8C(row, 0) = r_s16; 
		if (row < a1.size())
			r_s16 += a3.getDeletingCost(a1[row]);
	}

	for (size_t row = 0; row < a1.size(); row++)
	{
		for (size_t col = 0; col < a2.size(); col++)
		{
			r_s16 = fMat_8C(row, col);
			r_r5 = a3.getMatchingCost(a1[row], a2[col]);//0.1
			r_s18 = fMat_8C(row, col + 1);
			r_s2 = a3.getDeletingCost(a1[row]);
			r_s20 = fMat_8C(row + 1, col);  //hhh
			r_s4 = a3.getDeletingCost(a2[col]);
			r_s2 = r_s18 + r_s2;
			r_s0 = r_s16 + r_r5;
			if (r_s20 + r_s4 < r_s2)
				r_s2 = r_s20 + r_s4;
			if (r_s2 < r_s0)
				r_s0 = r_s2;
			fMat_8C(row + 1, col + 1) = r_s0;
		}
	}

	
	CharPlace chPlace(imseg::Wild);
	CTCHypoth ctcHypoth_E4;
	ctcHypoth_E4.field_0 = 0x10FFFF;
	ctcHypoth_E4.m_wcUnicode_4 = 0x10FFFF;
	ctcHypoth_E4.field_8 = -1;
	ctcHypoth_E4.m_nIndex_C = 0;
	ctcHypoth_E4.m_fcalcX_10 = 0.0f;
	ctcHypoth_E4.m_fHandmade_14 = -1.0f;
	list<CTCHypoth> lstCTCHy_98;
	list<CharPlace> lstChPlace_A4;

	int row = a1.size(), col = a2.size();
	while (row > 0 || col > 0)
	{
		if (col > 0 && row > 0)
		{
			chPlace = a2[col - 1];
			ctcHypoth_E4 = a1[row - 1];
			
			r_s16 = fMat_8C(row - 1, col);
			r_s18 = fMat_8C(row, col);
			r_r4 = a3.getDeletingCost(ctcHypoth_E4);
			r_s20 = fMat_8C(row, col - 1);
			r_s22 = fMat_8C(row, col);
			r_r6 = a3.getDeletingCost(chPlace);
			r_s26 = fMat_8C(row - 1, col - 1);
			r_s24 = fMat_8C(row, col);
			r_s26 = r_s26 + a3.getMatchingCost(ctcHypoth_E4, chPlace);
			

			if (fMat_8C(row, col) == fMat_8C(row - 1, col - 1) && a3.getMatchingCost(ctcHypoth_E4, chPlace) == 0.0f)
			{
				lstCTCHy_98.push_front(a3.getMatchingHypoth(ctcHypoth_E4, chPlace));
				lstChPlace_A4.push_front(chPlace);
				row--;
				col--;
				continue;
			}
			if (r_s24 == r_s26)
			{
				if (a3.getMatchingCost(ctcHypoth_E4, chPlace) == 0.0f)
				{
					row--;
					col--;
					continue;
				}
				set<uint> setun_r4 = chPlace.getPossibleUnicodes();
				set<uint> setun_114;
				for (set<uint>::iterator iter = setun_r4.begin(); iter != setun_r4.end(); iter++)
				{
					setun_114.emplace(*iter);
				}
				if (!setun_114.empty())
				{
					set<uint>::iterator iter1 = setun_114.begin();
					iter1++;
					CTCHypoth CTCHy_108;
					CTCHy_108.field_0 = *(setun_114.begin());
					CTCHy_108.m_wcUnicode_4 = CTCHy_108.field_0;
					CTCHy_108.field_8 = -1;
					CTCHy_108.m_nIndex_C = 0;
					CTCHy_108.m_fHandmade_14 = 1.0f;
					CTCHy_108.m_fcalcX_10 = 0.0f;

					while (iter1 != setun_114.end())
					{
						CTCHypoth CTCHy_138;
						CTCHy_138.field_0 = *iter1;
						CTCHy_138.m_wcUnicode_4 = CTCHy_138.field_0;
						CTCHy_138.field_8 = -1;
						CTCHy_138.m_nIndex_C = 0;
						CTCHy_138.m_fcalcX_10 = 0.0f;
						CTCHy_138.m_fHandmade_14 = 0.9f;

						CTCHy_108.m_lstImCTCHy_18.push_back(CTCHy_138);
						iter1++;
					}
					lstCTCHy_98.push_front(CTCHy_108);
				}
				lstChPlace_A4.push_front(chPlace);
				row--;
				col--;
				continue;
			}
			if (r_s18 == r_s16 + r_r4)
			{
				lstChPlace_A4.push_front(chPlace);
				row--;
				col--;
				continue;
			}
			if (r_s22 != r_s20 + r_r6)
			{
				continue;
			}
		}
		else
		{
			bool v55 = false;
			if (col < 1 && row > 0)
			{
				ctcHypoth_E4 = a1[row - 1];
				v55 = true;
			}
			if (!(col > 0 && row < 1))
			{
				if (v55)
				{
					lstChPlace_A4.push_front(chPlace);
					col--;
					row--;
				}
				continue;
			}
			chPlace = a2[col - 1];
		}
		if (a3.getDeletingCost(chPlace) != 0.0f)
		{
			set<uint> setun_r4 = chPlace.getPossibleUnicodes();
			set<uint> setun_114;
			for (set<uint>::iterator iter = setun_r4.begin(); iter != setun_r4.end(); iter++)
			{
				setun_114.emplace(*iter);
			}
			if (!setun_114.empty())
			{
				set<uint>::iterator iter1 = setun_114.begin();
				iter1++;
				CTCHypoth CTCHy_108;
				CTCHy_108.field_0 = *(setun_114.begin());
				CTCHy_108.m_wcUnicode_4 = CTCHy_108.field_0;
				CTCHy_108.field_8 = -1;
				CTCHy_108.m_nIndex_C = 0;
				CTCHy_108.m_fHandmade_14 = 1.0f;
				CTCHy_108.m_fcalcX_10 = 0.0f;

				while (iter1 != setun_114.end())
				{
					CTCHypoth CTCHy_138;
					CTCHy_138.field_0 = *iter1;
					CTCHy_138.m_wcUnicode_4 = CTCHy_138.field_0;
					CTCHy_138.field_8 = -1;
					CTCHy_138.m_nIndex_C = 0;
					CTCHy_138.m_fcalcX_10 = 0.0f;
					CTCHy_138.m_fHandmade_14 = 0.9f;

					CTCHy_108.m_lstImCTCHy_18.push_back(CTCHy_138);
					iter1++;
				}
				lstCTCHy_98.push_front(CTCHy_108);
			}
		}
		col--;
	}

	for (int r = row; r > 0; r--)
	{
		lstCTCHy_98.push_front(a1[r - 1]);
	}
	for (int c = col; c > 0; c--)
	{
		lstChPlace_A4.push_front(a2[c - 1]);
	}
	a4 = vector<imseg::CTCHypoth>(lstCTCHy_98.begin(), lstCTCHy_98.end());
	a5 = vector<imseg::CharPlace>(lstChPlace_A4.begin(), lstChPlace_A4.end());

	return fMat_8C(a1.size(), a2.size());
}
