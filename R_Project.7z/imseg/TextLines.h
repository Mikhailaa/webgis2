#pragma once

#include "pch.h"
#include "../common/resources.h"
#include "../common/container/container.h"
#include "../common/container/RclHolder.h"
#include "SymbolCandidatWithRect.h"
#include "Field.h"

using namespace common;
using namespace common::resources;
using namespace common::container;

namespace imseg
{
	class TextLines
	{
	public:
		cv::Mat m_xMat_4;
		vector<cv::Rect> m_vRect_3C;//���� ȭ�󿡼��� ��ǥ
		vector<vector<vector<SymbolCandidatWithRect>>> m_vvvSymCandidatWR_48;
		TextLines();
		TextLines(TextLines const&);
		TextLines(Field &);
		~TextLines();
		float calcMinProb();
		float calcAvgProb();
		vector<vector<vector<SymbolCandidatWithRect>>>& getResults();
		int getLinesCount();
		int getImgHeight();
		TextLines operator=(TextLines const&);
		void pushBackResults(vector<vector<SymbolCandidatWithRect>>&);
	};
}
