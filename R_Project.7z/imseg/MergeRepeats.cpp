#include "MergeRepeats.h"

using namespace imseg;

imseg::MergeRepeats::MergeRepeats()
{
	m_pIC_4 = NULL;
	m_bFlag_8 = false;
}

MergeRepeats::MergeRepeats(bool b_a2, ICorrector* a3)
{
	m_bFlag_8 = b_a2;
	m_pIC_4 = a3;
}

MergeRepeats::~MergeRepeats()
{
}

//void MergeRepeats::process(vector<CTCHypoth>&)
//{
//}

void MergeRepeats::process_impl(vector<CTCHypoth>& v_CTCHy_a2)
{
	if (v_CTCHy_a2.empty()) return;

	vector<CTCHypoth> vCTCHy;
	uint nUnicode = 0xFFFFFFFF;

	for (size_t i = 0; i < v_CTCHy_a2.size(); i++)
	{
		if (v_CTCHy_a2[i].getUnicode() == 0x10FFFF && !m_bFlag_8 ||
		v_CTCHy_a2[i].getUnicode() != nUnicode && v_CTCHy_a2[i].getUnicode() != 0x10FFFF)
		{
			vCTCHy.push_back(v_CTCHy_a2[i]);
		}

		nUnicode = v_CTCHy_a2[i].getUnicode();
	}

	v_CTCHy_a2 = vCTCHy;
}