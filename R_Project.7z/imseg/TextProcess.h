#pragma once
#include "pch.h"
#include "ImageControl.h"
#include "Text.h"
#include "TextStruct.h"
#include "TextStructManager.h"

class TextProcess
{
public:
	static bool generateFieldStructDnn(Text&, TextStruct&);
	static bool generateFieldStruct(CBufferImage &CBufImg_a1, Text& xText_a2, TextStruct &xTStruct_a3);
	static bool updateSymbolPosition(Text& a1, TextStruct& a2);
};