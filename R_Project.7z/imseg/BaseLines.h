#pragma once
#include "commonStruct.h"

class BaseLines
{
public:
	
	BaseLines();
	~BaseLines();
	void setLine(eBaseLinePos, int);
	int line(eBaseLinePos);

	int m_nField_0[13];
};