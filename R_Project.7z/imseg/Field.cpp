#include "Field.h"

Field::Field()
{
	m_pCVisualF_70 = 0;
	m_nField_68 = 0;
	m_bField_6C = 0;
	field_AC = 0;
	m_nTextStructIdx_64 = -1;
	m_xFieldImages_20.m_vCBufImg_20.resize(5);
	m_nsymbolsTails_98 = Tails_0;
	m_nsymbolType_9C = SymbolType_0;
}

Field::Field(Field const &a2)
{
	m_xFieldParam_4 = a2.m_xFieldParam_4;
	m_xFieldImages_20 = a2.m_xFieldImages_20;
	m_vText_4C = a2.m_vText_4C;
	m_vTextStruct_58 = a2.m_vTextStruct_58;
	m_nTextStructIdx_64 = a2.m_nTextStructIdx_64;
	m_nField_68 = a2.m_nField_68;
	m_bField_6C = a2.m_bField_6C;
	m_pCVisualF_70 = a2.m_pCVisualF_70;
	m_xCAlphaF_74 = a2.m_xCAlphaF_74;
	m_nsymbolsTails_98 = a2.m_nsymbolsTails_98;
	m_nsymbolType_9C = a2.m_nsymbolType_9C;
	m_vnLcid_A0 = a2.m_vnLcid_A0;
	field_AC = a2.field_AC;
	m_strMask_B0 = a2.m_strMask_B0;
}

Field::~Field()
{
}

int Field::symbolsTails()
{
	return m_nsymbolsTails_98;
}

int Field::symbolsType()
{
	return m_nsymbolType_9C;
}

FieldParam & Field::param()
{
	return m_xFieldParam_4;
}

void Field::init(vector<tagRECT>& a2)
{
	m_vText_4C.resize(a2.size());
	for (size_t i = 0; i < m_vText_4C.size(); i++)
	{
		m_vText_4C[i].init(a2[i]);

		int n_r0;
		if (m_vnLcid_A0.empty())
			n_r0 = m_pCVisualF_70->xTVF_Font.m_sFF_LCID;
		else
			n_r0 = m_vnLcid_A0[0];
		m_vText_4C[i].m_nLcid_18 = n_r0;
	}
}

void Field::init(vector<vector<cv::Rect>> & a2)
{
	m_vText_4C.resize(a2.size());
	for (size_t i = 0; i < m_vText_4C.size(); i++)
	{
		m_vText_4C[i].init(a2[i]);
		int n_r0;
		if (m_vnLcid_A0.empty())
			n_r0 = m_pCVisualF_70->xTVF_Font.m_sFF_LCID;
		else
			n_r0 = m_vnLcid_A0[0];
		m_vText_4C[i].m_nLcid_18 = n_r0;
	}
}

void Field::linesList(vector<Text*>& a2)
{
	a2.clear();
	for (size_t i = 0; i < m_vText_4C.size(); i++)
	{
		a2.push_back(&m_vText_4C[i]);
	}
}

