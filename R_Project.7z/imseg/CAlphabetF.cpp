#include "CAlphabetF.h"

CAlphabetF::CAlphabetF()
{
}

CAlphabetF::CAlphabetF(CAlphabetF const &xCAlphabetF)
	: m_vAlphabet_0(xCAlphabetF.m_vAlphabet_0)
	, m_vchar_C(xCAlphabetF.m_vchar_C)
	,m_map_vchar_18(xCAlphabetF.m_map_vchar_18)
{
}

CAlphabetF::CAlphabetF(CAlphabetF &&xCAlphabetF)
	: m_vAlphabet_0(move(xCAlphabetF.m_vAlphabet_0))
	, m_vchar_C(move(xCAlphabetF.m_vchar_C))
	, m_map_vchar_18(move(xCAlphabetF.m_map_vchar_18))
{

}

CAlphabetF & CAlphabetF::operator=(CAlphabetF const &xCAlphabetF)
{
	m_vAlphabet_0 = xCAlphabetF.m_vAlphabet_0;
	m_vchar_C = xCAlphabetF.m_vchar_C;
	m_map_vchar_18 = xCAlphabetF.m_map_vchar_18;
	return *this;
}

CAlphabetF & CAlphabetF::operator=(CAlphabetF &&xCAlphabetF)
{
	m_vAlphabet_0 = move(xCAlphabetF.m_vAlphabet_0);
	m_vchar_C = move(xCAlphabetF.m_vchar_C);
	m_map_vchar_18 = move(xCAlphabetF.m_map_vchar_18);
	return *this;
}

CAlphabetF::~CAlphabetF()
{
}

void CAlphabetF::initByUnicode(vector<int> const &vAlphabet_a2)
{
	m_vAlphabet_0 = vAlphabet_a2;
}
