#include "SubField.h"

SubField::SubField()
{
	m_nLCID_0 = 0;
	m_wsMask_4 = L"";
}

SubField::SubField(SubField const &xSubField)
	: m_nLCID_0(xSubField.m_nLCID_0)
	, m_wsMask_4(xSubField.m_wsMask_4)
	, m_map_wchar_setun_10(xSubField.m_map_wchar_setun_10)
	, m_setun_1C(xSubField.m_setun_1C)
{

}

SubField::SubField(wstring &ws_a1, map<wchar_t, set<uint>> &map_wchar_setun_a2, uint un_a3)
	: m_nLCID_0(un_a3)
	, m_wsMask_4(ws_a1)
	, m_map_wchar_setun_10(map_wchar_setun_a2)
{
	map<wchar_t, set<uint>>::iterator mbiter = m_map_wchar_setun_10.begin();
	map<wchar_t, set<uint>>::iterator meiter = m_map_wchar_setun_10.end();
	set<uint>::iterator sbiter;
	for (; mbiter != meiter; mbiter++)
	{
		for (sbiter = (*mbiter).second.begin(); sbiter != (*mbiter).second.end(); sbiter++)
			m_setun_1C.insert(*sbiter);
	}
	m_map_wchar_setun_10['W'] = m_setun_1C;
}

SubField & SubField::operator=(SubField &&xSubField)
{
	m_nLCID_0 = move(xSubField.m_nLCID_0);
	m_wsMask_4 = move(xSubField.m_wsMask_4);
	m_map_wchar_setun_10 = move(xSubField.m_map_wchar_setun_10);
	m_setun_1C = move(xSubField.m_setun_1C);
	return *this;
}

int SubField::getLCID()
{
	return m_nLCID_0;
}

wstring * SubField::getMask()
{
	return &m_wsMask_4;
}
