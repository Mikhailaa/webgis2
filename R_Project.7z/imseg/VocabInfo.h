#pragma once
#include "pch.h"

namespace imseg
{
	class VocabInfo
	{
	public:
		VocabInfo();
		VocabInfo(VocabInfo &other)
		{
			nCount_0 = other.nCount_0;
			vData_4 = other.vData_4;
		}

	public:
		int nCount_0;
		vector<int> vData_4;
	};
}