#include "CTCBeamNode.h"
using namespace imseg;

CTCBeamNode::CTCBeamNode(shared_ptr<CTCBeamNode>& spCTCBN_a2, shared_ptr<CTCHypoth>& sp_CTCHy_a3)
{
	m_spCTCBN_CTCHy_0 = sp_CTCHy_a3;
	m_spCTCBN_CTCBN_8 = spCTCBN_a2;
	m_rCTCBN_LogProb_10 = logf(m_spCTCBN_CTCHy_0.get()->m_fHandmade_14);
	if (spCTCBN_a2.get())
		m_rCTCBN_LogProb_10 += m_spCTCBN_CTCBN_8->m_rCTCBN_LogProb_10;
}

CTCBeamNode::~CTCBeamNode()
{
}

vector<CTCHypoth> CTCBeamNode::calcPath()
{
	// TODO: insert return statement here

	vector<CTCHypoth> vRet;
	list <shared_ptr<CTCHypoth>> l_spCTChy;
	l_spCTChy.push_back(m_spCTCBN_CTCHy_0);

	if (m_spCTCBN_CTCBN_8.get())
	{
		//no check
		shared_ptr<CTCBeamNode> sp_tmp = m_spCTCBN_CTCBN_8;

		while (sp_tmp.get())
		{
			l_spCTChy.push_back(sp_tmp->m_spCTCBN_CTCHy_0);
			sp_tmp = sp_tmp->m_spCTCBN_CTCBN_8;
		}
	}
	

	vRet.reserve(l_spCTChy.size());

	list <shared_ptr<CTCHypoth>>::iterator Iter;
	for (Iter = l_spCTChy.end(); Iter != l_spCTChy.begin();)
	{
		Iter--;
		vRet.push_back(*(Iter->get()));
	}
	
	return vRet;
}

float CTCBeamNode::getLogProb()
{
	return m_rCTCBN_LogProb_10;
}
