#pragma once

#include "pch.h"

namespace imseg
{
	class TopResultSet
	{
	public:
		TopResultSet(uint);
		~TopResultSet();
		void addPoint(float, uint, uint);

		vector<uint> m_vTRS_field_0;
		vector<uint> m_vTRS_field_C;
		vector<float> m_vTRS_field_18;
		int m_nVRT_Size_24;
		int m_nVRT_field_28;
		float m_rVRT_field_2C;
	};
}