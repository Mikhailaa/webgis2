#include"DbgFolder.h"

using namespace imseg;

DbgFolder::DbgFolder(DbgFolder &&arg1)
{
	fs::Path _tPath(move(arg1.m_xCfsPath_0));
	m_xCfsPath_0 = _tPath;
	field_18 = move(arg1.field_18);
}

DbgFolder::DbgFolder(DbgFolder const &arg1)
{
	fs::Path _tPath(arg1.m_xCfsPath_0);
	m_xCfsPath_0 = _tPath;
	field_18 = arg1.field_18;
}

DbgFolder DbgFolder::operator=(DbgFolder const &arg1)
{
	m_xCfsPath_0 = arg1.m_xCfsPath_0;
	field_18 = arg1.field_18;
	return *this;
}
