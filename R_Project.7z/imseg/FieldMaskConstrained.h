#pragma once
#include "../pch.h"
#include "CharPlace.h"
#include "CTCHypoth.h"
#include "imseg_interface.h"
#include "MergeRepeats.h"
#include "DeleteSequentialSpaces.h"

namespace imseg
{
	class FieldMaskConstrained : public IFieldMask
	{
	public:
		vector<CharPlace> m_vCharPlace_4;
		shared_ptr<ICorrector> m_spICorrector_10;
		vector<CTCHypoth> m_vCTCHypoth_18;
		bool m_b_24;

		FieldMaskConstrained(vector<CharPlace> &);

		virtual void setPreviousPath(vector<CTCHypoth> const&);
		virtual bool isUnicodePossible(uint);
		virtual int getBeamWidth();
		virtual bool isAllSymbolsFound(vector<CTCHypoth> const&);
		virtual bool doNotDeleteSymbolsAfterMe();
	};
}