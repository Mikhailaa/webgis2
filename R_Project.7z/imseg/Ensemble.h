#pragma once

#include "CTCDNN.h"


namespace imseg
{
	class Ensemble : public ITextLinesVisitor
	{
	public:
		Ensemble();
		virtual ~Ensemble();
		virtual void visit(RichTextLines &xRTL);

		cv::Size getSize();
		void io_generic(cv::dnn::DnnReader &);
		Ensemble &operator=(Ensemble const&);
		void setMasks(vector<shared_ptr<IFieldMask>> &);

		//int m_nEsm_vft_0;
		vector<shared_ptr<CTCDNN>> m_vEsm_sptrCTCDNN_4;
	};
}