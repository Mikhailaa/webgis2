#include "CTCHypoth.h"
#include "imseg.h"

using namespace imseg;

CTCHypoth::CTCHypoth()
{
}

CTCHypoth::CTCHypoth(CTCHypoth const&arg1)
{
	field_0 = arg1.field_0;
	m_wcUnicode_4 = arg1.m_wcUnicode_4;
	field_8 = arg1.field_8;
	m_nIndex_C = arg1.m_nIndex_C;
	m_fcalcX_10 = arg1.m_fcalcX_10;
	m_fHandmade_14 = arg1.m_fHandmade_14;
	m_lstImCTCHy_18 = arg1.m_lstImCTCHy_18;
}

CTCHypoth::CTCHypoth(CTCHypoth &&arg1)
{
	field_0 = move(arg1.field_0);
	m_wcUnicode_4 = move(arg1.m_wcUnicode_4);
	field_8 = move(arg1.field_8);
	m_nIndex_C = move(arg1.m_nIndex_C);
	m_fcalcX_10 = move(arg1.m_fcalcX_10);
	m_fHandmade_14 = move(arg1.m_fHandmade_14);
	m_lstImCTCHy_18= move(arg1.m_lstImCTCHy_18);
}

CTCHypoth & CTCHypoth::operator=(CTCHypoth const&arg1)
{
	field_0 = arg1.field_0;
	m_wcUnicode_4 = arg1.m_wcUnicode_4;
	field_8 = arg1.field_8;
	m_nIndex_C = arg1.m_nIndex_C;
	m_fcalcX_10 = arg1.m_fcalcX_10;
	m_fHandmade_14 = arg1.m_fHandmade_14;

	m_lstImCTCHy_18.clear();
	m_lstImCTCHy_18 = arg1.m_lstImCTCHy_18;
	return *this;
}

CTCHypoth & CTCHypoth::operator=(CTCHypoth &&arg1)
{
	field_0 = move(arg1.field_0);
	m_wcUnicode_4 = move(arg1.m_wcUnicode_4);
	field_8 = move(arg1.field_8);
	m_nIndex_C = move(arg1.m_nIndex_C);
	m_fcalcX_10 = move(arg1.m_fcalcX_10);
	m_fHandmade_14 = move(arg1.m_fHandmade_14);
	m_lstImCTCHy_18 = move(arg1.m_lstImCTCHy_18);
	return *this;
}

bool imseg::CTCHypoth::operator==(CTCHypoth const &a1)
{
	return m_wcUnicode_4 == a1.m_wcUnicode_4;
}

bool imseg::CTCHypoth::operator<(CTCHypoth const &a2)
{
	return m_fHandmade_14 < a2.m_fHandmade_14;
}

bool imseg::CTCHypoth::operator>(CTCHypoth const &a2)
{
	return m_fHandmade_14 > a2.m_fHandmade_14;
}


void CTCHypoth::sortSecondaryHypothByProb()
{
	m_lstImCTCHy_18.sort(greater<>());
}

void CTCHypoth::setUnicode(uint const &arg1)
{
	field_0 = arg1;
	m_wcUnicode_4 = arg1;
}

uint CTCHypoth::getUnicode() const
{
	return m_wcUnicode_4;
}

void CTCHypoth::calcXOnImage(float const & arg1)
{
	m_fcalcX_10 = arg1 * m_nIndex_C;
}

bool CTCHypoth::isHandmade()
{
	return (m_fHandmade_14 == -1);
}

int CTCHypoth::getIndex()
{
	return m_nIndex_C;
}

SymbolCandidat CTCHypoth::getSymbol() const
{
	return SymbolCandidat(m_wcUnicode_4, m_fHandmade_14, 0, 0, 0);
}
