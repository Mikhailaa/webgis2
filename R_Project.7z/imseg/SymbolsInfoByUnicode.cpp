#include "SymbolsInfoByUnicode.h"

SymbolsInfoByUnicode::SymbolsInfoByUnicode()
	:m_uomap_nSymbolInfo_4()
	,m_uomap_nuomap_nSymbolFontParam_18()
{
	m_uomap_nSymbolInfo_4.clear();
	m_uomap_nuomap_nSymbolFontParam_18.clear();
	m_uomap_nuomap_nSymbolFontParam_18[0x3C7E85E3][1067] = { 1.0f, 0.1f };
	m_uomap_nuomap_nSymbolFontParam_18[0xC06B7062][72] = { 0.78f, 0.1f };
}

SymbolsInfoByUnicode::~SymbolsInfoByUnicode()
{
}

int SymbolsInfoByUnicode::type(int a1)
{
	int result;
	if (isCorrectInx(a1))
		result = m_uomap_nSymbolInfo_4.at(a1).nField_0;
	else
		result = 0;
	return result;
}

int SymbolsInfoByUnicode::wType(int a1)
{
	int result;
	if (isCorrectInx(a1))
		result = m_uomap_nSymbolInfo_4.at(a1).nField_8;
	else
		result = 7;
	return result;
}

int SymbolsInfoByUnicode::tailType(int a1)
{
	int result;
	if (isCorrectInx(a1))
		result = m_uomap_nSymbolInfo_4.at(a1).nField_4;
	else
		result = 9;
	return result;
}

void SymbolsInfoByUnicode::getkWHInfo(int a1, int a2, SymbolFontParam &a3)
{
	a3.m_r_0 = 0.0f;
	a3.m_r_4 = 0.0f;
	unordered_map<int, unordered_map<int, SymbolFontParam>>::iterator iter;
	iter = m_uomap_nuomap_nSymbolFontParam_18.find(a2);
	if (iter != m_uomap_nuomap_nSymbolFontParam_18.end())
	{
		unordered_map<int, SymbolFontParam>::iterator iter1;
		iter1 = iter->second.find(a1);
		if (iter1 != iter->second.end())
			a3 = iter1->second;
	}
}

bool SymbolsInfoByUnicode::isCorrectInx(int n_a1)
{
	return m_uomap_nSymbolInfo_4.find(n_a1) != m_uomap_nSymbolInfo_4.end();
}
