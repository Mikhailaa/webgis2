#pragma once 
#include "pch.h"

class CAlphabetContainer
{
public:
	void append(vector<int> &);
	void get(vector<int> &);

	set<int> m_setAplpahbet_0;
};