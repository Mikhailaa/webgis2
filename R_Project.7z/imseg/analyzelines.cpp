#include"analyzelines.h"
#include "VisualField.h"
#include "imseg_rect.h"

namespace imseg
{
	namespace analyzelines
	{
		cv::Rect RECTtoCvRect(tagRECT const&arg1)
		{
			cv::Rect res;
			res.x = arg1.left;
			res.y = arg1.top;
			res.width = arg1.right - arg1.left;
			res.height = arg1.top - arg1.bottom;
			return res;
		}

		tagRECT CvRecttoRECT(cv::Rect const&arg1)
		{
			tagRECT res;
			res.left = arg1.x;
			res.top = arg1.y;
			res.right = arg1.x + arg1.width;
			res.bottom = arg1.y + arg1.height;
			return res;
		}

		void layerToCoordinates(Layer_R &arg1, float arg2, vector<TDetectedField>&arg3)
		{
			Field *_pField;
			CVisualField *_pCVisualF;
			cv::Mat _Mat_7C;
			cv::Rect _cvRect_3C;
			TDetectedField _xTDetectedField;

			for (size_t i = 0; i < arg1.size(); i++)
			{
				_pField = &arg1[i];
				_pCVisualF = _pField->m_pCVisualF_70;
				if (_pCVisualF)
				{
					cv::Rect v34 = _pField->m_xFieldImages_20.m_xRect_0;
					int v10 = (int)_pCVisualF->getProcParams().rTPP_Orientation;
					vector<tagRECT> _vtagRECT_4C(_pField->m_vText_4C.size());

					for (size_t j = 0; j < _pField->m_vText_4C.size(); j++)
					{
						tagRECT v37 = arg1[i].m_vText_4C[j].m_vimsegSymbol_0[0].rect();
						_cvRect_3C = preprocessLineCoordinates(v34, v37, arg2, v10);
						_vtagRECT_4C[j] = CvRecttoRECT(_cvRect_3C);
					}
					_xTDetectedField.field_0 = v10;
					_xTDetectedField.m_xtagRECT_4 = CvRecttoRECT(v34);
					_xTDetectedField.m_vtRECT_14 = _vtagRECT_4C;
					arg3[i] = _xTDetectedField;
				}
			}
		}

		cv::Rect preprocessLineCoordinates(cv::Rect &arg2, tagRECT &arg3, float arg4, int arg5)
		{
			tagRECT _tagRECT_34;
			_tagRECT_34.left = arg3.left;
			_tagRECT_34.top = arg3.bottom;
			_tagRECT_34.right = arg3.right;
			_tagRECT_34.bottom = arg3.top;

			const cv::Rect _cvRect_44 = imseg::rect::scale(arg2, arg4);
			rotateCoordinates(CvRecttoRECT(_cvRect_44), (float)arg5, _tagRECT_34);
			cv::Rect _cvRect_24 = rect::scale(RECTtoCvRect(_tagRECT_34), 1.0f / arg4);
			tagRECT _tagRECTes = shiftLeftTopCoordinate(CvRecttoRECT(_cvRect_24), CvRecttoRECT(arg2));			
			return RECTtoCvRect(_tagRECTes);
		}

		tagRECT shiftLeftTopCoordinate(tagRECT arg1, tagRECT arg2)
		{
			tagRECT res;
			res.left = arg1.left + arg2.left;
			res.top = arg1.top + arg2.top;
			res.right = arg1.right + arg2.left;
			res.bottom = arg1.bottom + arg2.top;
			return res;
		}

		void rotateCoordinates(tagRECT arg1, float arg2, tagRECT &arg3)
		{
			int _width = arg1.right - arg1.left;
			int _height = arg1.top - arg1.bottom;
			
			tagRECT _tagRECT = arg3;
			if (arg2 == 90)
			{
				arg3.left = _width - _tagRECT.bottom;
				arg3.top = _tagRECT.left;
				arg3.right = _width - _tagRECT.top;
				arg3.bottom = _tagRECT.right;
			}
			
			if (arg2 == 180)
			{
				arg3.left = _width - _tagRECT.right;
				arg3.top = _height - _tagRECT.bottom;
				arg3.right = _width - _tagRECT.left;
				arg3.bottom = _height - _tagRECT.top;
			}

			if (arg2 == 270)
			{
				arg3.left = _tagRECT.top;
				arg3.top = _height - _tagRECT.right;
				arg3.right = _tagRECT.bottom;
				arg3.bottom = _height - _tagRECT.left;
			}
		}

		TDetectedField::TDetectedField()
		{
			memclr(this, sizeof(TDetectedField));
		}

		TDetectedField::TDetectedField(TDetectedField const &arg1)
			:m_vtRECT_14(arg1.m_vtRECT_14)
		{
			field_0 = arg1.field_0;
			m_xtagRECT_4 = arg1.m_xtagRECT_4;
		}

		TDetectedField::TDetectedField(TDetectedField const &&arg1)
			:m_vtRECT_14(move(arg1.m_vtRECT_14))
		{
			field_0 = move(arg1.field_0);
			m_xtagRECT_4 = move(arg1.m_xtagRECT_4);
		}
		TDetectedField & TDetectedField::operator=(TDetectedField &arg1)
		{
			field_0 = arg1.field_0;
			m_xtagRECT_4 = arg1.m_xtagRECT_4;
			m_vtRECT_14 = arg1.m_vtRECT_14;
			return *this;
		}
		TDetectedField & TDetectedField::operator=(TDetectedField &&arg1)
		{
			field_0 = move(arg1.field_0);
			m_xtagRECT_4 = move(arg1.m_xtagRECT_4);
			m_vtRECT_14 = move(arg1.m_vtRECT_14);
			return *this;
		}
	}
}