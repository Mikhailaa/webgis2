#include "FieldAdapter.h"

namespace imseg
{
	FieldAdapter::FieldAdapter(Field *arg1)
	{
		m_pField_0 = arg1;
	}

	FieldAdapter::~FieldAdapter()
	{
	}

	int FieldAdapter::getLogiclOrPartsCount()
	{
		return m_pField_0->m_vTextStruct_58.size();
	}
	bool FieldAdapter::isInformative(TextPartStruct &arg1)
	{
		if (arg1.m_vucharName_3C.size() == 1 && (arg1.m_vucharName_3C.front() == 0x9F || arg1.m_vucharName_3C.front() == 0x94))
				return false;
		return true;
	}

	vector<vector<TextPartStruct>> FieldAdapter::getStrings(uint arg1, uint arg2)
	{
		vector<TextPartStruct> _vTextPartStruct_1C;
		vector<vector<TextPartStruct>> _vvTextPartStruct_28, Res_vvTextPartStruct;
		TextStruct _xTextStruct_34(m_pField_0->m_vTextStruct_58[arg1]);

		for (size_t i = 0; i < _xTextStruct_34.m_vTextPartStruct_0.size(); i++)
		{
			TextPartStruct _xTextPartStruct_88(_xTextStruct_34.m_vTextPartStruct_0[i]);
			if (_xTextPartStruct_88.m_vucharName_3C.size() == 1 && _xTextPartStruct_88.m_vucharName_3C.front() == '^')
			{
				_vvTextPartStruct_28.push_back(_vTextPartStruct_1C);
				
			}
			else if (isInformative(_xTextPartStruct_88))
			{
				_vTextPartStruct_1C.push_back(_xTextPartStruct_88);
			}
		}

		if (!_vTextPartStruct_1C.empty())
			_vvTextPartStruct_28.push_back(_vTextPartStruct_1C);
		
		if (signed(arg2 - _vvTextPartStruct_28.size()) <= -1)
			return Res_vvTextPartStruct;

		if (arg2 != _vvTextPartStruct_28.size())
		{
			for (size_t v14 = 0; v14 < _vvTextPartStruct_28.size(); v14++)
			{
				for (size_t i = 0; i < _vvTextPartStruct_28[v14].size(); i++)
				{
					wstring _ws_88 = _vvTextPartStruct_28[v14][i].getName();
					if (_ws_88==L"STRINGS")
					{
						for (size_t j = 0; j < arg2 - _vvTextPartStruct_28.size(); j++)
						{
							TextPartStruct _xTextPartStruct_88(_vvTextPartStruct_28[v14][i]);								
							vector<TextPartStruct> _vTextPartStruct_10;
							_vTextPartStruct_10.push_back(_xTextPartStruct_88);
							_vvTextPartStruct_28.insert(_vvTextPartStruct_28.begin(), _vTextPartStruct_10);
						}
						break;
					}
				}
			}

		}

		if (arg2 == _vvTextPartStruct_28.size())
			return _vvTextPartStruct_28;
		return Res_vvTextPartStruct;
	}
}