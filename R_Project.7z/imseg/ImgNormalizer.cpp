﻿#include "ImgNormalizer.h"
#include "dbgInfoSaver.h"

using namespace imseg;
using namespace  common::fs;

set<int> g_set_112A2D0;
pair<int, int> gPairII_4D9D80[9] =
{
	{1046,2},
	{1081,2},
	{2070,2},
	{1115,4},
	{1097,4},
	{1054,2},
	{10000,100000},
	{2117,2},
	{ 12746740,12912046 },
};

ImgNormalizer::ImgNormalizer(cv::Size const &xSize_a2, int n_a3)
{
	m_nIN_4 = 4;
	m_nIN_8 = 4;
	m_xIN_size_C = xSize_a2;
	m_nIN_14 = n_a3;
}

void ImgNormalizer::visit(RichTextLines &x_RTLs_a2)
{
	cv::Mat &xImg = x_RTLs_a2.getImg();

	//int nMaxWidth = x_RTLs_a2.getMaxWidth(); ? 돌림값을 리용하지 않음
	//vector<DbgFolder> vDbgH= x_RTLs_a2.getDbgFolders();
	vector<cv::Mat> vMat;
	for (int i = 0; i < x_RTLs_a2.getLinesCount(); i++)
	{
		cv::Rect_<int> &rectROI = x_RTLs_a2.getTextROI(i);
		cv::Mat mat_ret = process(rectROI, m_xIN_size_C, xImg, m_nIN_14, x_RTLs_a2.getScale(i));
		/*imshow("dd", mat_ret);
		waitKey();*/
		vMat.push_back(mat_ret);
		//dbgInfoSaver::saveImage(mat_ret, cv::Rect_<int>(0,0,0,0), (*pvDbgH)[i].m_xCfsPath_0, "normalizedImg.jpg");
	}

	x_RTLs_a2.setNormalizedImgs(vMat);
}

int ImgNormalizer::getBaseLineMargin(int n_a2)
{
	map<int, int> mTmp;
	for (int i = 0; i < 9; i++)
	{
		mTmp.insert(gPairII_4D9D80[i]);
	}
	if (g_set_112A2D0.find(n_a2) == g_set_112A2D0.end())
	{
		if (mTmp.find(n_a2) == mTmp.end()) return m_nIN_8;
		return mTmp[n_a2];
	}
	return 2;
}

cv::Mat ImgNormalizer::makeVerticalBorder(int n_a3, int n_a4, int n_a5, int n_a6, cv::Mat const &xMat_a7, int &n_a8, int n_a9)
{
	cv::Mat xRetMat;
	int n_v14;
	int n_v15;
	int n_v16;
	int nBaseLineMargin = getBaseLineMargin(n_a9);
	n_a8 = (n_a5 - (n_a3 - n_a4)) & ~((n_a5 - (n_a3 - n_a4)) >> 31);
	xRetMat = xMat_a7.colRange(cv::Range(n_a8, MIN(xMat_a7.cols, n_a3 - n_a4 + n_a6)));
	n_v14 = (n_a3 - n_a4) / nBaseLineMargin;
	n_v15 = n_a4 - n_v14;
	n_v16 = n_a3 + n_v14;
	if (n_a4 - n_v14 > 0)
	{
		xRetMat = xRetMat.rowRange(cv::Range(n_v15, xRetMat.rows));
		n_v16 -= n_v15;
	}
	if (n_v16 < xRetMat.rows)
	{
		xRetMat = xRetMat.rowRange(cv::Range(0, n_v16));
	}
	int nTop = n_v16 + 1 - xRetMat.rows;
	if (n_v16 < xRetMat.rows)
		nTop = n_v16 + 1 - xRetMat.rows;
	copyMakeBorder(xRetMat, xRetMat, nTop, -n_v15 & (n_v15 >> 31), 0, 0, 1);
	return xRetMat;
}

cv::Mat ImgNormalizer::process(cv::Rect_<int>& xRect_a3, cv::Size const & xSize_a4, cv::Mat const &xMat_a5, int n_a6, float &r_a7)
{
	cv::Mat ret_xRet;
	int nTmp = 0;
	cv::Mat xMat = makeVerticalBorder(xRect_a3.y + xRect_a3.height, xRect_a3.y, xRect_a3.x,
		xRect_a3.x + xRect_a3.width, xMat_a5, nTmp, n_a6);


	xRect_a3.width -= xRect_a3.x - nTmp;
	xRect_a3.x = nTmp;

	resizeKeepProportionsInHeight(xMat,xSize_a4, ret_xRet);
	r_a7 *= ((float)xMat.rows / (float)ret_xRet.rows);
	copyMakeBorder(ret_xRet, ret_xRet, 0, 0, 0, ret_xRet.cols / m_nIN_4, 1);

	if (xSize_a4.width - ret_xRet.cols >= 1)
		copyMakeBorder(ret_xRet, ret_xRet, 0, 0, 0, xSize_a4.width - ret_xRet.cols, 1);
	standartizeImg(ret_xRet);
	return ret_xRet;
}


void ImgNormalizer::resizeKeepProportionsInHeight(cv::Mat const &xMat_a2, cv::Size const &xSize_a3, cv::Mat &xMat_a4)
{
	float nHeight = (float)xMat_a2.cols / ((float)xMat_a2.rows / (float)xSize_a3.height);
	resize(xMat_a2, xMat_a4, cv::Size((int)nHeight, xSize_a3.height));
}

void ImgNormalizer::standartizeImg(cv::Mat &xMat_a2)
{
	cv::Matx<double, 4, 1> mat_mean, mat_stddev;
	//, mat_stddev;
	Ptr<CLAHE> ptrCLAHE = createCLAHE(1.0, Size_<int>(MAX(1, xMat_a2.cols / 48), MAX(1, xMat_a2.rows / 48)));
	ptrCLAHE->apply(xMat_a2, xMat_a2);
	meanStdDev(xMat_a2, mat_mean, mat_stddev);
	xMat_a2.convertTo(xMat_a2, 5,1.0, -mat_mean(0,0));
	xMat_a2.convertTo(xMat_a2, -1, 1.0 / 128.0, 0.0);
	normalize(xMat_a2, xMat_a2, 0.0, 255.0, 32);
	Scalar xScalar_60 = mean(xMat_a2);
	Scalar xScalar_80;
	xScalar_80[0] = xScalar_60[0];
	subtract(xMat_a2, xScalar_80, xMat_a2);
	xMat_a2.convertTo(xMat_a2, -1, 1.0 / 128.0, 0.0);
}
