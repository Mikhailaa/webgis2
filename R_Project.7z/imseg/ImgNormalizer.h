#pragma once

#include "RichTextLines.h"

namespace imseg
{
	class ImgNormalizer : public ITextLinesVisitor
	{
	public:
		ImgNormalizer(cv::Size const&xSize_a2, int n_a3);
		//~ImgNormalizer();
		virtual void visit(RichTextLines &);
		int getBaseLineMargin(int);
		cv::Mat makeVerticalBorder(int, int, int, int, cv::Mat const&, int &, int);
		cv::Mat process(cv::Rect_<int> &, cv::Size const&, cv::Mat const&, int, float &);
		void resizeKeepProportionsInHeight(cv::Mat const&, cv::Size const&, cv::Mat&);
		//shiftRectHorizontally(int, Rect_<int> &);
		void standartizeImg(cv::Mat &);

		//int m_nIN_vft_0;
		int m_nIN_4;
		int m_nIN_8;
		cv::Size m_xIN_size_C;	
		int m_nIN_14;
	};
}

