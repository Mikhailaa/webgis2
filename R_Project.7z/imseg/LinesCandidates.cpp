#include "LinesCandidates.h"
#include "Analyse.h"
#include "rcvmat.h"
#include "RCv.h"

LinesCandidates::LinesCandidates()
{

}

LinesCandidates::~LinesCandidates()
{

}

LinesCandidates::LinesCandidates(LinesCandidates && xParam)
{
	m_vTxPoints_0 = xParam.m_vTxPoints_0;
}

void LinesCandidates::rotatePoints(float fParam1, tagPOINT & xParam2)
{
	float angle = (float)(fParam1 * PI / (-180.0f));
	float f15 = xParam2.y - (cosf(angle) * xParam2.y + sinf(angle) * xParam2.x);
	vector<TPointEx> vOld = m_vTxPoints_0;
	for (size_t i = 0; i < m_vTxPoints_0.size(); i++)
	{
		m_vTxPoints_0[i].nField_4 = int(f15 + cosf(angle) * vOld[i].nField_4 + sinf(angle) * vOld[i].nField_0 + 0.5f);
		m_vTxPoints_0[i].nField_8 = int(f15 + cosf(angle) * vOld[i].nField_8 + sinf(angle) * vOld[i].nField_0 + 0.5f);
		m_vTxPoints_0[i].nField_C = abs(m_vTxPoints_0[i].nField_8 - m_vTxPoints_0[i].nField_4);
	}
}

int LinesCandidates::generatePoints(CBufferImage & xCBI_Param1, FontDesc & xFD_Param2, FieldParam & xFP_Param3, InitConstStructs & xICS_Param4)
{
	int res = 1;
	vector<TPointEx> vP;
	findAllSymbols(xCBI_Param1, xFD_Param2, xICS_Param4, xFP_Param3, vP);
	if (!vP.empty())
	{
		filterSymbols(vP, xICS_Param4, m_vTxPoints_0, xFP_Param3.m_nFP_0);
		res = m_vTxPoints_0.empty();
	}
	return res;
}

int LinesCandidates::filterSymbols(vector<TPointEx> & vParam1, InitConstStructs & xICS_Param2, vector<TPointEx> & vParam3, int & nParam4)
{
	vParam3.clear();
	int v10 = 0;
	for (size_t i = 0; i < vParam1.size(); i++)
	{
		if (vParam1[v10].nField_10 < vParam1[i].nField_10)
			v10 = i;
	}
	int v13 = 0, v16 = 0;
	for (size_t i = 0; i < vParam1.size(); i++)
	{
		if (vParam1[i].nField_10 > vParam1[v10].nField_10 - xICS_Param2.m_xTLineAnalyzeFirst_0.m_n_18)
		{
			v13 += vParam1[i].nField_10;
			v16++;
		}
	}
	if (v16)
	{
		int avr = v13 / v16;
		nParam4 = ((avr - xICS_Param2.m_xTLineAnalyzeFirst_0.m_n_1C) > 0) ? (avr - xICS_Param2.m_xTLineAnalyzeFirst_0.m_n_1C) : 0;
		for (size_t i = 0; i < vParam1.size(); i++)
		{
			if (vParam1[i].nField_10 > nParam4)
			{
				vParam3.push_back(vParam1[i]);
			}
		}
	}
	return 0;
}

int LinesCandidates::findAllSymbols(CBufferImage & xCBI_Param1, FontDesc & xFD_Param2, InitConstStructs & xICS_Param3, FieldParam & xFP_Param4, vector<TPointEx> & vParam5)
{
	vParam5.clear();
	int w1 = xCBI_Param1.width() - 1, h1 = xCBI_Param1.height() - 1;
	tagRECT r = { -1, 0, -1, h1 };
	bool v11 = xFP_Param4.contain(PROCESS_OPTION_11), v73 = !v11;
	int v8 = xFD_Param2.m_xFontDescBase_0.m_nFDB_Field_4;
	if (2 * v8 < w1)
		w1 = 2 * v8;
	int i = 0;
	vector<TPointEx> vTP;
	while (v8 * i + w1 < xCBI_Param1.width())
	{
		r.right = v8 * i + w1;
		r.left = v8 * i;
		TPointEx pTemp;
		pTemp.nField_0 = (r.right + r.left) / 2;
		CBufferImage cbi;
		cbi.ref(xCBI_Param1, r);
		vector<uchar> vv(cbi.height());
		RAnalyse::getProjectionV_LineWidth(cbi, int(v8 * 0.1f), vv);
		CBufferImage cbi1;
		cbi1.ref(cbi.height(), 1, vv.data(), -1, 8, 1);
		vector<int> vvv(257);
		RCvMat::histogramRange(cbi1, 0x100, vvv.data());
		vector<float> vTemp(2);
		vTemp.push_back(0.2f);
		vTemp.push_back(0.0f);
		for (int j = v73; j < 2; j++)
		{
			CBufferImage cbi2;
			cbi2.ref((int)((1.0f - 2 * vTemp[j]) * cbi.height()), 1, &vv[(int)(vTemp[j] * cbi.height())], -1, 8, 1);
			Mat m = RCvMat::ref(cbi2);
			RCvMat::histogramRange(cbi2, 0x100, vvv.data());
			int a6, a7, a8;
			if (!RAnalyse::dynamicRange(vvv.data(), 0x100, (int)(xICS_Param3.m_xTLineAnalyzeFirst_0.noiseLower * cbi.height()),
				(int)(xICS_Param3.m_xTLineAnalyzeFirst_0.noiseUpper * cbi.height()), a6, a7, a8))
			{
				int v22 = xICS_Param3.m_xTLineAnalyzeFirst_0.stopHistogram;
				if (v22 > a6)
					v22 = a6 + 1;
				a6++;

				float f3, f81;
				if (!RAnalyse::histogramCenter(vvv.data(), f3, 0, v22) &&
					!RAnalyse::histogramCenter(vvv.data(), f81, --a7, 256) &&
					f81 - f3 >= xICS_Param3.m_xTLineAnalyzeFirst_0.m_n_C &&
					((int)((f81 + f3) / 2)))
				{
					int v23 = int((f81 + f3) / 2.0);
					if (v23)
					{
						vector<pair<int, int> > vP;
						RAnalyse::findUpDown(vv.data(), 0, vv.size(), v23, vP);
						vector<TPointEx> vPoint;
						for (size_t k = 0; k < vP.size(); k++)
						{
							int v27 = vP[k].first;
							int v28 = cbi.height() - 1;
							if (cbi.height() < v27)
								v27 = v28;
							int v30 = (v27 > 0) ? v27 : 0;
							vP[k].first = v30;
							if (cbi.height() > vP[k].second)
								v28 = vP[k].second;
							int v31 = (v28 > 0) ? v28 : 0;
							vP[k].second = v31;
							if (v30 > 1)
							{
								if (v31 <= xCBI_Param1.height() - 2)
								{
									int v44 = vP[k].first;
									int v45 = vP[k].second;
									int v46 = v45 - v44;
									pTemp.nField_C = v46;
									if (v45 - v44 >= xICS_Param3.m_xTLineAnalyzeFirst_0.threshLineH &&
										abs(v46 - v8) / v8 <= 0)
									{
										int s = 0;
										pTemp.nField_4 = v44;
										pTemp.nField_8 = v45;
										for (int l = v44; l <= v45; l++)
										{
											s += vv[l];
										}
										pTemp.nField_10 = v11 ? 255 : (s / v46);
										vPoint.push_back(pTemp);
										vParam5.push_back(pTemp);
									}
								}
								else if (xFD_Param2.m_xFontDescBase_0.m_nFDB_Field_0 == 1)
								{
									if (v8 + vP[k].first < xCBI_Param1.height())
									{
										int s = 0;
										pTemp.nField_C = v8;
										int v37 = vP[k].first;
										pTemp.nField_4 = v37;
										pTemp.nField_8 = v37 + v8;
										for (int l = 0; l <= v8; l++)
										{
											s += vv[v37 + l];
										}
										pTemp.nField_10 = v11 ? 255 : (s / v8);
										vTP.push_back(pTemp);
									}
								}
							}
							else if (v31 > v8 && xFD_Param2.m_xFontDescBase_0.m_nFDB_Field_0 == 1)
							{
								pTemp.nField_8 = v31;
								pTemp.nField_C = v8;
								pTemp.nField_4 = v31 - v8;
								vTP.push_back(pTemp);
								int s = 0;
								for (int l = 0; l < v8; l++)
								{
									s += vv[l + pTemp.nField_4];
								}
								pTemp.nField_10 = v11 ? 255 : (s / v8);
							}
						}
					}
				}
			}
		}
		i++;
	}
	if (xFD_Param2.m_xFontDescBase_0.m_nFDB_Field_0 == 1)
	{
		if (vParam5.size() < vTP.size() / 2)
		{
			vParam5 = vTP;
		}
	}
	return 0;
}
