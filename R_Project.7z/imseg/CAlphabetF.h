#pragma once
#include "pch.h"
class CAlphabetF
{
public:
	CAlphabetF();
	CAlphabetF(CAlphabetF const&);
	CAlphabetF(CAlphabetF &&);
	CAlphabetF& operator=(CAlphabetF const&);
	CAlphabetF& operator=(CAlphabetF &&);
	~CAlphabetF();
	void initByUnicode(vector<int> const&);
public:
	vector<int> m_vAlphabet_0;
	vector<wchar_t> m_vchar_C;
	map<int, vector<wchar_t>> m_map_vchar_18;
};
