﻿#include "Semantics.h"
#include "unicodes.h"
#include "common/common.h"
#include "common/UnicodeUtils.h"
#include "common/resources.h"
#include "common/StringUtils.h"

namespace imseg
{
	namespace unicodes
	{
		extern set<uint> defaultSymbols;
	}
}


bool Semantics::candidatesContainString(CSymbolCandidate *xCSymbolCandidate_a0, int n_a1, int n_a2, vector<uint> vuint_3)
{
	size_t i;
	while (n_a2 < n_a1)
	{
		for (i = 0; i < vuint_3.size(); i++)
		{
			if (vuint_3[i] == xCSymbolCandidate_a0->nTSC_SymbolCode) break;
		}
		n_a2++;
		if (i != vuint_3.size())
			return true;
	}
	return false;
}

void Semantics::caseTypeCandidats(ISymbolsInfoByUnicode &a0, CSymbolCandidate *a1, int a2, int &a3, int &a4, int &a5, int &a6, vector<Semantics::eLetterType> &a7)
{
	for (int i = 0; i < a2; ++i)
	{
		if (a0.type(a1->nTSC_SymbolCode) == eLetterType_8 || a0.type(a1->nTSC_SymbolCode) == eLetterType_0)
		{
			if (!i)
			{
				a7.push_back(eLetterType_0);
				return;
			}
		}
		if (a0.type(a1->nTSC_SymbolCode) == eLetterType_1)
		{
			if (!i)
				a7.push_back(eLetterType_2);

			a3++;
			if ((int)a1->nTSC_SymbolProbability > a5)
				a5 = a1->nTSC_SymbolProbability;
		}
		if (a0.type(a1->nTSC_SymbolCode) == eLetterType_2)
		{
			if (!i)
				a7.push_back(eLetterType_1);

			a4++;
			if ((int)a1->nTSC_SymbolProbability > a6)
				a6 = a1->nTSC_SymbolProbability;
		}
		a1++;
	}
}

void Semantics::changeUnicodesWordByWord(map<pair<int, int>, int> &map_pairnn_a0, map<int, vector<wchar_t>> const &map_nv_a1, vector<vector<wchar_t>> const &vvWchar_a2, vector<int>&vint_a3)
{
	map<pair<int,int>,int>::iterator iter = map_pairnn_a0.begin();
	vector<uint> vun_3C;
	while (iter != map_pairnn_a0.end())
	{
		int n_60 = iter->first.first;
		int n_64 = iter->first.second;
		set<uint> set_30;
		vector<wchar_t> vwchar_r4 = map_nv_a1.at(iter->second);
		for (size_t i = 0; i < vwchar_r4.size(); i++)
			set_30.insert(set_30.end(), vwchar_r4[i]);

		for (int i = n_60; i < n_64; i++)
		{
			if (!vvWchar_a2.empty())
			{
				vun_3C = imseg::unicodes::getVisualIdenticalSetForUnicode(vvWchar_a2[i][0]);
				if (!vun_3C.empty())
				{
					set<uint> set_54;
					for (size_t j = 0; j < vun_3C.size(); j++)
						set_54.insert(set_54.begin(), vun_3C[j]);

					vector<uint> vuint_48(set_54.size());
					vector<uint>::iterator iter1 = set_intersection(set_54.begin(), set_54.end(), set_30.begin(), set_30.end(), vuint_48.begin());
					vuint_48.erase(iter1, vuint_48.end());

					if (vuint_48.size() != vun_3C.size())
					{	
						for (size_t j = 0; j < vvWchar_a2[i].size(); j++)
							if (vvWchar_a2[i][j] == vuint_48[0]) break;
					}
				}
			}
		}
		iter++;
	}
}

bool Semantics::checkIfSymbolIsUnique(int n_a0, map<int, set<uint>> const&map_nsetn_a1, int n_a2)
{
	vector<uint> vuint_34 = imseg::unicodes::getVisualIdenticalSetForUnicode(n_a0);
	if (vuint_34.empty()) return true;

	set<uint> setun_4C;
	for (size_t i = 0; i < vuint_34.size(); i++)
		setun_4C.insert(setun_4C.begin(), vuint_34[i]);

	vector<uint> vuint_40(setun_4C.size());
	vector<uint>::iterator iter = set_intersection(setun_4C.begin(), setun_4C.end(), map_nsetn_a1.at(n_a2).begin(), map_nsetn_a1.at(n_a2).end(), vuint_40.begin());
	vuint_40.erase(iter, vuint_40.end());

	if (vuint_40.size() == setun_4C.size()) return true;

	map<int, set<uint>>::const_iterator iter1 = map_nsetn_a1.begin();
	while (iter1 != map_nsetn_a1.end())
	{
		if (iter1->first != n_a2)
		{
			vuint_40.clear();
			iter = set_intersection(setun_4C.begin(), setun_4C.end(), map_nsetn_a1.at(iter1->first).begin(), map_nsetn_a1.at(iter1->first).end(), vuint_40.begin());
			vuint_40.erase(iter, vuint_40.end());
			if (!vuint_40.empty()) return false;
		}
		iter1++;
	}

	return true;
}

void Semantics::convertToBigSmallLetters(ISymbolsInfoByUnicode &ISymbolsInfoByUnicode_a0, CSymbolResult *pSymRes_a1, 
	int n_a2, int n_a3, BaseLines &xBaseLine_a4, bool b_a5)
{
	if (n_a2 < 2) return;
	size_t i, j, k;
	vector<Semantics::eLetterType>  veLetterType_2C;
	vector<Semantics::eLetterType>  veLetterType_38;

	int nCodePage = common::unicode_convert::codePage(n_a3);
	int n_r3 = 85;
	if (b_a5)
		n_r3 = 1;

	Semantics::getCaseType(	ISymbolsInfoByUnicode_a0, pSymRes_a1, n_a2,	n_r3, 4, xBaseLine_a4, veLetterType_2C, veLetterType_38, b_a5);
	
	vector<int> vint_44;
	for (size_t i = 0; i < veLetterType_38.size(); i++)
		vint_44.push_back(veLetterType_38[i]);

	if (veLetterType_2C.empty() && veLetterType_38.empty()) return;
	if (veLetterType_38.size() == veLetterType_2C.size())
	{
		vector<uint>  vuint_50;
		vuint_50.push_back('I'); //73
		vuint_50.push_back('l'); //108

		for (i = 0; i < veLetterType_38.size(); i++)
		{
			int nCode_r0 = pSymRes_a1[i].get(0);
			for (j = 0; j < vuint_50.size(); j++)
			{
				if (vuint_50[j] == nCode_r0) break;
			}

			vector<uint> vuint_5C(vuint_50);
			
			bool b_r5 =Semantics::candidatesContainString(pSymRes_a1[i].at(0), pSymRes_a1[i].nTSR_CandidatesCount, 1, vuint_5C);

			if (veLetterType_38[i] != veLetterType_2C[i])
			{
				if (((j == vuint_50.size()) | b_r5 ^ 1) != 1 || pSymRes_a1[i].at(0)->nTSC_SymbolProbability - pSymRes_a1[i].at(1)->nTSC_SymbolProbability <= 3)
				{
					CSymbolCandidate* pSymCand_r8 = (CSymbolCandidate*)pSymRes_a1[i].xnTSR_Candidates;
					if (pSymRes_a1[0].xnTSR_Candidates[0].nTSC_SymbolCode != 223)
					{
						if (veLetterType_38[i] == eLetterType_1)
						{
							for (k = 1; k < pSymRes_a1[0].xnTSR_Candidates[0].nTSC_SymbolCode; k++)
							{
								if (ISymbolsInfoByUnicode_a0.type(pSymRes_a1->xnTSR_Candidates[k].nTSC_SymbolCode) == eLetterType_2
									&& (n_a3 != 1049 || common::unicode_convert::toUpper(pSymRes_a1->xnTSR_Candidates[k].nTSC_SymbolCode) == pSymCand_r8->nTSC_SymbolCode))
								{
									break;
								}
							}
						}
						else if (veLetterType_38[i] == eLetterType_2)
						{
							for (k = 1; k < pSymRes_a1[0].xnTSR_Candidates[0].nTSC_SymbolCode; k++)
							{
								if (ISymbolsInfoByUnicode_a0.type(pSymRes_a1->xnTSR_Candidates[k].nTSC_SymbolCode) == eLetterType_2
									&& (n_a3 != 1049 || common::unicode_convert::toLower(pSymRes_a1->xnTSR_Candidates[k].nTSC_SymbolCode) == pSymCand_r8->nTSC_SymbolCode))
								{
									break;
								}
							}
						}

						if (k && k != pSymRes_a1[0].xnTSR_Candidates[0].nTSC_SymbolCode)
						{
							short sTmp = pSymRes_a1->xnTSR_Candidates[k].sTSC_Class;
							pSymRes_a1->xnTSR_Candidates[k].sTSC_Class = pSymCand_r8->sTSC_Class;
							pSymCand_r8->sTSC_Class = sTmp;
						}
					}
				}
			}
		}
	}
}

void Semantics::convertToNumber(ISymbolsInfoByUnicode &ISymbolsInfoByUnicode_a0, eSymbolType eSymbolType_a1, CSymbolResult *pCSymbolResult_a2, int n_a3)
{
	for (int i = 0; i < n_a3; i++)
	{
		for (uint j = 0; j < pCSymbolResult_a2[i].nTSR_CandidatesCount; j++)
		{
			if (ISymbolsInfoByUnicode_a0.type(pCSymbolResult_a2->xnTSR_Candidates[i].nTSC_SymbolCode) == eLetterType_4 ||
				pCSymbolResult_a2[i].get(0) - pCSymbolResult_a2[i].get(j) <= eLetterType_3)
			{
				CSymbolCandidate *pTmpCand = pCSymbolResult_a2[i].at(j);
				pCSymbolResult_a2[i].xnTSR_Candidates[0].nTSC_SymbolCode = pCSymbolResult_a2[i].xnTSR_Candidates[j].nTSC_SymbolCode;
				pCSymbolResult_a2[i].xnTSR_Candidates[0].sTSC_Class = pCSymbolResult_a2[i].xnTSR_Candidates[j].sTSC_Class;
				pCSymbolResult_a2[i].xnTSR_Candidates[0].sTSC_SubClass = pCSymbolResult_a2[i].xnTSR_Candidates[j].sTSC_SubClass;

				pCSymbolResult_a2[i].xnTSR_Candidates[j].nTSC_SymbolCode = pTmpCand->nTSC_SymbolCode;
				pCSymbolResult_a2[i].xnTSR_Candidates[j].sTSC_Class = pTmpCand->sTSC_Class;
				pCSymbolResult_a2[i].xnTSR_Candidates[j].sTSC_SubClass = pTmpCand->sTSC_SubClass;
			}

		}
	}
}

void Semantics::convertToText(ISymbolsInfoByUnicode &ISymbolsInfoByUnicode_a0, eSymbolType eSymbolType_a1, CSymbolResult *pCSymbolResult_a2, int n_a3,
	int n_a4, BaseLines & xBaseLines_a5, bool b_a6)
{
	if (!b_a6)
	{
		for (int i = 0; i < n_a3; i++)
		{
			for (uint j = 0; j < pCSymbolResult_a2[i].nTSR_CandidatesCount && 
				pCSymbolResult_a2[i].xnTSR_Candidates[0].nTSC_SymbolCode != '!'; j++)
			{
				if (ISymbolsInfoByUnicode_a0.type(pCSymbolResult_a2->xnTSR_Candidates[i].nTSC_SymbolCode) == eLetterType_1 ||
					ISymbolsInfoByUnicode_a0.type(pCSymbolResult_a2->xnTSR_Candidates[i].nTSC_SymbolCode) == eLetterType_2)
				{
					CSymbolCandidate *pTmpCand = pCSymbolResult_a2[i].at(j);
					pCSymbolResult_a2[i].xnTSR_Candidates[0].nTSC_SymbolCode = pCSymbolResult_a2[i].xnTSR_Candidates[j].nTSC_SymbolCode;
					pCSymbolResult_a2[i].xnTSR_Candidates[0].sTSC_Class = pCSymbolResult_a2[i].xnTSR_Candidates[j].sTSC_Class;
					pCSymbolResult_a2[i].xnTSR_Candidates[0].sTSC_SubClass = pCSymbolResult_a2[i].xnTSR_Candidates[j].sTSC_SubClass;

					pCSymbolResult_a2[i].xnTSR_Candidates[j].nTSC_SymbolCode = pTmpCand->nTSC_SymbolCode;
					pCSymbolResult_a2[i].xnTSR_Candidates[j].sTSC_Class = pTmpCand->sTSC_Class;
					pCSymbolResult_a2[i].xnTSR_Candidates[j].sTSC_SubClass = pTmpCand->sTSC_SubClass;
				}
			}
		}
	}
}

bool Semantics::correctCaseTypeForCandidates(Semantics::eLetterType a1, vector<Semantics::eLetterType>& a2, int &a3, int &a4)
{
	for (size_t i = 0; i < a2.size(); i++)
	{
		if (a2[i] == eLetterType_3)
		{
			a2[i] = a1;
			++a3;
		}
	}

	a4 = a2[0] == eLetterType_3;
	return a2[0] == eLetterType_3;
}

void Semantics::copyCasesForUnknown(vector<Semantics::eLetterType>& veLetterTyp_a0, vector<Semantics::eLetterType>& veLetterTyp_a1,
	int &n_a2, int &n_a3, int &n_a4)
{
	for (size_t i = 1; i < veLetterTyp_a1.size(); i++)
	{
		if (veLetterTyp_a1[i] == eLetterType_3)
		{
			veLetterTyp_a1[i] = veLetterTyp_a0[i];

			if(veLetterTyp_a0[i] == eLetterType_2) n_a3++; 
			else if (veLetterTyp_a0[i] == eLetterType_1) n_a2++;
		}
	}

	n_a4 = 0;
}

void Semantics::correctImpossibleLetters(ISymbolsInfoByUnicode &ISymbolsInfoByUnicode_a0, CSymbolResult *pCSymbolResult_a1,
	int n_a2, int n_a3, int n_a4)
{
	size_t j,k = 0;
	int nCodePge_r0 = common::unicode_convert::codePage(n_a4);

	if (n_a2 < 1 || nCodePge_r0 != 1251 || !pCSymbolResult_a1[0].nTSR_CandidatesCount) return;
	string str_30("А, У, О, Ы, И, Э, Я, Ю, Ё, Е");

	int nSymbolType_r0 = ISymbolsInfoByUnicode_a0.type(pCSymbolResult_a1[n_a2].xnTSR_Candidates[0].nTSC_SymbolCode);
	int n_r1 = 1;
	if (nSymbolType_r0 == 8)
		n_r1 = 2;
	int n_r10 = n_a2 - n_r1;

	if (n_a2 - n_r1 >= 0)
	{
		if (pCSymbolResult_a1[n_r10].get(0) == 1066)
		{
			for (k = 1; k < pCSymbolResult_a1[n_r10].nTSR_CandidatesCount; k++)
			{
				if (pCSymbolResult_a1[n_r10].get(k) == 1068 &&
					(pCSymbolResult_a1[n_r10].get(0) - pCSymbolResult_a1[n_r10].get(k)) <= n_a3) break;
			}
		}
		else if (pCSymbolResult_a1[n_r10].get(0) == 1098)
		{
			for (k = 1; k < pCSymbolResult_a1[n_r10].nTSR_CandidatesCount; ++k)
			{
				if (pCSymbolResult_a1[n_r10].get(k) == 1100 &&
					(pCSymbolResult_a1[n_r10].get(0) - pCSymbolResult_a1[n_r10].get(k)) <= n_a3) break;
			}
		}
		else
		{
			for (n_r10 = 1; n_r10 < n_a2; n_r10++)
			{
				if (pCSymbolResult_a1[n_r10].get(0) == 1049)
				{
					for (j = 0; j < str_30.length(); j++)
						if (pCSymbolResult_a1[n_r10 - 1].at(0)->nTSC_SymbolCode == str_30[j]) break;

					if (j == str_30.length())
					{
						for (k = 1; k < pCSymbolResult_a1[n_r10].nTSR_CandidatesCount; k++)
						{
							if (pCSymbolResult_a1[n_r10].get(n_r10) == 1048 &&
								(pCSymbolResult_a1[n_r10].get(0) - pCSymbolResult_a1[n_r10].get(n_r10)) <= n_a3) break;
						}
					}
				}
			}

			if (n_r10 >= n_a2)
			{
				for (int i = 1; i < n_a2; ++i)
				{
					if (pCSymbolResult_a1[i].get(0) == 1081)
					{
						for (j = 0; j < str_30.length(); j++)
							if (pCSymbolResult_a1[i - 1].at(0)->nTSC_SymbolCode == str_30[j]) break;

						if (j == str_30.length())
						{
							for (k = 1; k < pCSymbolResult_a1[n_r10].nTSR_CandidatesCount; k++)
							{
								if (pCSymbolResult_a1[n_r10].get(j) == 1048 &&
									(pCSymbolResult_a1[n_r10].get(0) - pCSymbolResult_a1[n_r10].get(j)) <= n_a3) break;
							}
						}
					}
				}
			}
		}

		CSymbolCandidate *pTmpCand = pCSymbolResult_a1[n_r10].at(k);
		pCSymbolResult_a1[n_r10].at(k)->nTSC_SymbolCode = pCSymbolResult_a1[n_r10].at(0)->nTSC_SymbolCode;
		pCSymbolResult_a1[n_r10].at(k)->sTSC_Class = pCSymbolResult_a1[n_r10].at(0)->sTSC_Class;
		pCSymbolResult_a1[n_r10].at(k)->sTSC_SubClass = pCSymbolResult_a1[n_r10].at(0)->sTSC_SubClass;

		pCSymbolResult_a1[n_r10].at(0)->nTSC_SymbolCode = pTmpCand->nTSC_SymbolCode;
		pCSymbolResult_a1[n_r10].at(0)->sTSC_Class = pTmpCand->sTSC_Class;
		pCSymbolResult_a1[n_r10].at(0)->sTSC_SubClass = pTmpCand->sTSC_SubClass;
	}
}


void Semantics::correctMixedLcids(vector<vector<wchar_t>> & a1, map<int, vector<wchar_t>> & a2, int a3, map<int, set<uint>> &a4, vector<int> &a5)
{
	map<pair<int, int>, int> v1;
	splitTextInWordsWithLcid(a3, a1, a2, a4, v1);
	changeUnicodesWordByWord(v1, a2, a1, a5);
}

void Semantics::correctWord(ISymbolsInfoByUnicode & a1, CSymbolResult * a2, int a3, int a4, eSymbolType a5,
	vector<int> &a6, int a7, int a8, BaseLines & a9, eWordType & a10, bool a11)
{
	if (a3 < 1)
		return;
	a10 = eWordType_0;

	if ((a5 & 3) && !(a5 & 4))
	{
		if ((a5 & 3) == 3)
			convertToBigSmallLetters(a1, a2, a3, a4, a9, a11);
		correctImpossibleLetters(a1, a2, a3, 4, a4);
		a10 = eWordType_1;
		return;
	}
	if ((a5 & 7) == 4)
	{
		a10 = eWordType_2;
		return;
	}

	int nFlag1 = 0, nFlag2 = 0, nFlag3, nFlag4;
	for (int i = 0; i < a3; i++)
	{
		if (a2[i].xnTSR_Candidates[0].nTSC_SymbolCode == 'O' || a2[i].xnTSR_Candidates[0].nTSC_SymbolCode == '0')
			nFlag1 = 1;
	}

	if (a3 > 2)
		nFlag2 = 1;
	if (!((nFlag1 | nFlag2) << 31))
	{
		correctImpossibleLetters(a1, a2, a3, 4, a4);
		return;
	}

	if (a11)
		nFlag3 = 0;
	else
	{
		getWordType(a1, a2, a3, 80, 4, a10);
		nFlag3 = a10;
		a11 = 0;
	}

	nFlag4 = a3 == 2;
	if (nFlag4)
		nFlag4 = nFlag3 == 0;

	if (nFlag4)
	{
		if (a1.type(a2[1].get(0)) == 4 && a2[0].get(0) == 'O')
			convertToNumber(a1, SymbolType_0, a2, 2);
		if (a1.type(a2[1].get(0)) == 2 || a1.type(a2[1].get(0)) == 1 && a2[0].get(0) == '0')
			convertToText(a1, a5, a2, 2, a10, a9, a11);

		if (a1.type(a2[0].get(0)) == 4 && a2[1].get(0) == 'O')
			convertToNumber(a1, SymbolType_0, a2, 2);

		if (a1.type(a2[0].get(0)) == 2 || a1.type(a2[0].get(0)) == 1 && a2[1].get(0) == '0')
			convertToText(a1, a5, a2, 2, a10, a9, a11);

		a10 = eWordType_0;
		correctImpossibleLetters(a1, a2, a3, 4, a4);
		return;
	}

	if (nFlag3 == 2)
	{
		convertToNumber(a1, a5, a2, a3);
		return;
	}

	if (nFlag3 == 1)
		convertToText(a1, a5, a2, a3, a10, a9, a11);

	correctImpossibleLetters(a1, a2, a3, 4, a4);
}


void Semantics::fillSymbolsVector(vector<CSymbolResult>&a1, vector<vector<wchar_t>>&a2)
{
	for (size_t i = 0; i < a1.size(); i++)
	{
		vector<wchar_t> vwchar_2c;
		for (uint j = 0; j < a1[i].nTSR_CandidatesCount; j++)
		{
			CSymbolCandidate xSymCan = a1[i][j];
			vwchar_2c.push_back(xSymCan.nTSC_SymbolCode);
		}
		a2.push_back(vwchar_2c);
	}
}


void Semantics::getCaseType(ISymbolsInfoByUnicode & a1, CSymbolResult * a2, int a3, int a4, int a5, BaseLines & a6,
	vector<eLetterType>& a7, vector<eLetterType>& a8, bool a9)
{
	int n5 = 0, n8 = 0, n9 = 0, n10 = 0, n11 = 0, nTotal = 0, nTemp;
	eLetterType letterType;
	int n1 = 0, n2 = 0, n3 = 0, n4 = 0;

	for (int i = 0; i < a3; i++)
	{
		if (a2[i].nTSR_CandidatesCount)
		{
			CSymbolCandidate *symCan = a2[i].at(0);
			caseTypeCandidats(a1, symCan, a2[i].nTSR_CandidatesCount, n1, n2, n3, n4, a7);

			if (i != a7.size() - 1)
				return;

			if (a7[i])
			{
				int nFlag = 0, nFlag1, nSub;
				if (n4 - n3 > 5)
					n5++;
				nSub = n3 - n4;
				if (n3 - n4 > 5)
					nFlag = 1;
				nFlag1 = n1 == 0;
				if (n1)
					nFlag1 = n2 == 0;

				if (!nFlag1)
				{
					if (nSub < 0)
						nSub = n4 - n3;
					if (n4 < a4 || n3 < a4 || nSub < a5)
					{
						letterType = eLetterType_3;
						n8++;

						if (n3 <= n4)
						{
							letterType = eLetterType_1;
							n9++;
						}
						a8.push_back(letterType);
					}
					else
					{
						a8.push_back(eLetterType_2);
						n10++;
					}
				}

				nTotal += ((i != 0) & nFlag);

				if (n1 && !n2)
				{
					n10++;
					a8.push_back(eLetterType_2);
				}

				if (!n1)
				{
					n9++;
					a8.push_back(eLetterType_1);
				}
			}
			else
			{
				a8.push_back(eLetterType_0);
				n11++;
			}
		}
	}

	if (!a8.empty())
	{
		if (n8 && !n5 && nTotal)
			correctCaseTypeForCandidates(eLetterType_2, a8, n10, n8);
		if (n5 && !nTotal && n8)
			correctCaseTypeForCandidates(eLetterType_1, a8, n9, n8);

		if (n8)
		{
			if (a9)
			{
				if (a3 - n11 < 3)
					copyCasesForUnknown(a7, a8, n9, n10, n8);
				else
				{
					if (nTotal >= n5)
					{
						letterType = eLetterType_2;
						nTemp = n10;
					}
					else
					{
						nTemp = n9;
						letterType = eLetterType_1;
					}
					correctCaseTypeForCandidates(letterType, a8, nTemp, n8);
				}
			}
			else
			{
				for (size_t i = 0; i < a8.size(); i++)
				{
					if (a8[i] == eLetterType_3)
					{
						letterType = eLetterType_3;
						int nType = a1.tailType(a2[i].xnTSR_Candidates->nTSC_SymbolCode);
						if (nType != 9 && nType != 2 && nType != 4 && nType != 65 && nType != 64)
							a8[i] = eLetterType_3;
						else
						{
							getCaseTypeByLines(a2[i].xTSR_SymbolRect.top - a2[i].u.nTSTR_Reserved, a6.line(eBaseLinePos_2), a6.line(eBaseLinePos_3), letterType);
							n8--;
							a8[i] = letterType;
							if (letterType == 1)
								n9++;
							else if (letterType == 2)
								n10++;
						}
					}
				}
			}

			int v1 = 0, v2;
			if (!n8)
			{
				if (a3 == a8.size())
				{
					int nFlag3 = n9;
					if (n9)
						nFlag3 = 1;
					if ((n10 == 0) != nFlag3)
					{
						if (n10 && n9)
						{
							if (n10 != 1 || a7[0] != eLetterType_2)
							{
								for (int j = 1; j < a3; j++)
								{
									if (a8[j] == eLetterType_2 && !a8[j - 1])
										v1++;
								}
							}
						}
					}
				}
			}

			if (a8[0] == eLetterType_2)
			{
				if (a8.size() < 3)
					return;
				n10--;
			}
			else if (a8[0] == eLetterType_1)
			{
				if (a8.size() == 2)
				{
					a8[1] = eLetterType_1;
					return;
				}
			}

			v2 = 0;
			if (n10 == n9)
			{
				if (a8[0] == eLetterType_2)
					v2 = 3;
			}
			if (n10 != n9 || a8[0] != eLetterType_3)
			{
				if (n10 > n9)
					v2 = 3;
				if (n10 < n9)
					v2 = 2;
				if (a8[0] != 2 && v2 == 3)
					a8[0] = eLetterType_2;

				for (size_t j = 0; j < a8.size(); j++)
				{
					if (a8[j] && a8[j + 1])
					{
						if (v2 == 3 && a8[j + 1] != 2)
							a8[j + 1] = eLetterType_2;
						else if (v2 == 2 && a8[j + 1] != 1)
							a8[j + 1] = eLetterType_1;
					}
				}
			}
		}
	}
}



void Semantics::getCaseTypeByLines(int a1, int a2, int a3, eLetterType & a4)
{
	eLetterType v1;
	if (a1)
	{
		v1 = eLetterType_2;
		if (a3)
		{
			if (a3 <= a2)
			{
				v1 = eLetterType_2;
				if ((float)a3 * 100.0f / a1 > (float)a1 * 100.0f / a2)
					v1 = eLetterType_1;
			}
		}
		a4 = v1;
	}
}

int Semantics::getLcidForUnicode(int a1, map<int, vector<wchar_t>> const& a2)
{
	if (a2.empty()) return 0;

	map<int, vector<wchar_t>>::const_iterator iter = a2.begin();
	while (iter != a2.end())
	{
		for (size_t i = 0; i < iter->second.size(); i++)
		{
			if (iter->second[i] == a1) break;
		}
		iter++;
	}
	return iter->first;
}

void Semantics::getWordType(ISymbolsInfoByUnicode & a1, CSymbolResult * a2, int a3, int a4, int a5, eWordType & a6)
{
	int nFlag1 = 0, nFlag2 = 0, nTemp = 0, n6 = -1, n9 = 0;
	int nTotal1 = 0, nTotal2 = 0;
	for (int i = 0; i < a3; i++)
	{
		int j = 0, k = 0, nSymProb4 = 0, n4 = 0, n12 = 0, nSymProb12 = 0;
		while (j < (int)a2[i].nTSR_CandidatesCount && (int)a2[i].xnTSR_Candidates[k].nTSC_SymbolProbability >= a4 &&
			a1.type(a2[i].xnTSR_Candidates[0].nTSC_SymbolCode) != 8)
		{
			if (a1.type(a2[i].xnTSR_Candidates[k].nTSC_SymbolCode) == 4)
			{
				if ((int)a2[i].xnTSR_Candidates[k].nTSC_SymbolProbability > nSymProb4)
					nSymProb4 = a2[i].xnTSR_Candidates[k].nTSC_SymbolProbability;
				n4++;
			}
			if (a1.type(a2[i].xnTSR_Candidates[k].nTSC_SymbolCode) == 1 || a1.type(a2[i].xnTSR_Candidates[k].nTSC_SymbolCode) == 2)
			{
				n12++;
				if ((int)a2[i].xnTSR_Candidates[k].nTSC_SymbolProbability > nSymProb12)
					nSymProb12 = a2[i].xnTSR_Candidates[k].nTSC_SymbolProbability;
			}
			j++; k++;
		}

		if (nSymProb4 | nSymProb12)
		{
			int nSymSub = nSymProb12 - nSymProb4, n10 = n4;
			if (nSymSub < 0)
				nSymSub = nSymProb12 - nSymProb4;
			if (nSymSub >= 100 - a4)
			{
				if (nSymProb12 <= nSymProb4)
					nFlag1 |= 1;
				if (nSymProb12 > nSymProb4)
					nFlag2 |= 1;
			}

			int n1 = 0, n2 = 0, n3, n5 = 0, n7, n8;
			if (nSymSub > a5)
				n2 = 1;
			if (nSymSub > nTemp)
				n1 = 1;
			n3 = n2 & n1;
			if (nSymProb12 > nSymProb4)
				n5 = 1;
			if (n3 != 0)
			{
				n6 = n5;
				nTemp = nSymSub;
			}
			n7 = n12 == 0;
			n8 = ((n12 == 0) | (n4 == 0)) ^ 1 | n9;
			if (n12)
				n7 = n4 == 0;
			if (n7 || nSymSub <= a5)
				n9 = n8;
			else if (nSymProb12 > nSymProb4)
				n10 = 0;
			else
				n12 = 0;

			nTotal1 += (n12 != 0) && (n10 == 0);
			nTotal2 += (n12 == 0) && (n10 != 0);
		}
	}
	if ((nFlag2 & nFlag1) << 31)
		return;

	int n11 = 0, n13;
	if (nTemp <= a5)
		n11 = 1;
	if (!((n11 | ~n9) << 31))
	{
		if (!nTotal2 && nTotal1 && n6 == 1)
			a6 = eWordType_1;
		if (nTotal1 || !nTotal2)
			return;
		n13 = n6;
		if (nTotal2)
			n13 = nTotal1;
		if (!n13)
			a6 = eWordType_2;
		return;
	}

	if (!nTotal2 && nTotal1)
	{
		a6 = eWordType_1;
		return;
	}
}


wstring Semantics::reverseRightToLeftText(wstring & a2, vector<int>& a3)
{
	wstring wstr_ret;
	set<int> sint_3c;
	for (size_t i = 0; i < a3.size(); i++)
		sint_3c.insert(sint_3c.end(), a3[i]);

	sint_3c.insert(sint_3c.end(), 28);
	sint_3c.insert(sint_3c.end(), 29);

	vector<wstring> vstr_2c, vstr_48, vstr_54;
	vstr_2c = common::StringUtils::Split(a2, '^');

	for (size_t i = 0; i < vstr_2c.size(); i++)
	{
		wstring str_60;
		vstr_54 = common::StringUtils::Split(vstr_2c[i], 32);
		for (int j = vstr_54.size() - 1; j >= 0; j--)
		{
			wstring str_6c(vstr_54[j]);
			set<int> sint_84;

			for (size_t k = 0; k < vstr_54[j].size(); k++)
				sint_84.insert(sint_84.end(), str_6c[k]);

			vector<int> vint_78(sint_84.size());
			vector<int>::iterator iter  = set_difference(sint_84.begin(), sint_84.end(), sint_3c.begin(), sint_3c.end(), vint_78.begin());
			vint_78.erase(iter, vint_78.end());
			if (!vint_78.size())
			{
				for (size_t k = 0; k < str_6c.size() / 2; k++)
				{
					wchar_t wszTemp = str_6c[k];
					str_6c[k] = str_6c[str_6c.size() - 1 - k];
					str_6c[str_6c.size() - 1 - k] = wszTemp;
				}
			}

			for (size_t k = 0; k < str_6c.size(); k++)
			{
				if (str_6c[k] == ')')
					str_6c[k] = '(';

				if (str_6c[k] == '(')
					str_6c[k] = ')';
			}

			if (j != vstr_54.size() - 1)
				str_60.push_back(32);

			str_60.append(str_6c);
		}

		str_60.push_back(8207);
		if (i == vstr_2c.size() - 1)
			str_60.push_back('^');
		vstr_48.push_back(str_60);
	}

	for (uint i = 0; i < vstr_48.size(); i++)
		wstr_ret.append(vstr_48[i]);

	return wstr_ret;
}

void Semantics::splitTextInWordsWithLcid(int const& a1, vector<vector<wchar_t>> const& a2, map<int, vector<wchar_t>> const&  a3,
	map<int, set<uint>> const&  a4, map<pair<int, int>, int> & a5)
{
	int nFirst = 0, nSecond, nTemp = a1;
	bool bFlag = false;

	for (uint i = 0; i < a2.size(); i++)
	{
		if (a2[i].empty())
			continue;

		if (imseg::unicodes::defaultSymbols.find(a2[i][0]) != imseg::unicodes::defaultSymbols.end() ||
			i == a2.size() - 1)
		{
			nSecond = a2.size();
			if (i != nSecond - 1)
				nSecond = i;

			a5.insert(pair<pair<int, int>, int>(pair<int, int>(nFirst, nSecond), nTemp));
			nFirst = i + 1;
			bFlag = 0;
			nTemp = a1;
		}
		else
		{
			if (!bFlag)
			{
				int nLcid = getLcidForUnicode(a2[i][0], a3);
				bFlag = checkIfSymbolIsUnique(a2[i][0], a4, nLcid);
				if (bFlag)
					nTemp = nLcid;
			}
		}

		bFlag = 1;
	}
}


void Semantics::swapPosSymbol(ISymbolsInfoByUnicode & a1, CSymbolCandidate * a2, int a3, eWordType a4)
{
	int i;
	switch (a4)
	{
	case 2:
		for (i = 1; i < a3; i++)
		{
			if (a1.type(a2[i].nTSC_SymbolCode) == 4)
			{
				CSymbolCandidate symTemp = a2[i];
				a2[i] = a2[0];
				a2[0] = symTemp;
				break;
			}
		}
		break;
	case 1:
		for (i = 1; i < a3; i++)
		{
			if (a1.type(a2[i].nTSC_SymbolCode) == 1 || a1.type(a2[i].nTSC_SymbolCode) == 2)
			{
				CSymbolCandidate symTemp = a2[i];
				a2[i] = a2[0];
				a2[0] = symTemp;
				break;
			}
		}
		break;
	case 0:
		for (i = 1; i < a3; i++)
		{
			if (a1.type(a2[i].nTSC_SymbolCode) != 8)
			{
				CSymbolCandidate symTemp = a2[i];
				a2[i] = a2[0];
				a2[0] = symTemp;
				break;
			}
		}
		break;
	}	
}
