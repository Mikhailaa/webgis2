#include "LineDetect.h"
#include "rcvmat.h"
#include "RCv.h"
#include "Analyse.h"

void LineDetect::checkRectSize(CBufferImage &a1, vector<tagRECT>&a2)
{
	for (size_t i = 0; i < a2.size(); i++)
	{
		a2[i].bottom = MAX(a2[i].bottom, 0);
		a2[i].top = MIN(a1.height() - 1, a2[i].top);
	}
}

int LineDetect::filterLines(vector<tagRECT>&a1, int a2, int a3)
{
	vector<tagRECT> _vtagRECT;
	vector<tagRECT>::iterator iter;
	uint v11, v7;
	uint v5;
	if (a1.empty())
		return -1;
	if (a2 == 1)
	{
		v5 = 0x7FFFFFFF;
		iter = a1.begin();
		for (size_t i = 0; i < a1.size(); i++)
		{
			v11 = abs(a3 - (a1[i].top + a1[i].bottom));
			if (v11 < v5)
			{
				v7 = i;
				v5 = v11;
			}
		}
		_vtagRECT = vector<tagRECT>(1, a1[v7]);
		a1 = _vtagRECT;
	}
	return 0;
}

void LineDetect::locateLineX(CBufferImage &a1, int a2, vector<tagRECT>&a3)
{
	CBufferImage _xCBufImg_24, _xCBufImg_44;
	RCvMat::normalize(a1, _xCBufImg_44, 0.01f, 0.01f, 1);

	for (size_t j = 0; j < a3.size(); j++)
	{
		a3[j].left = 0;
		a3[j].right = a1.width();
		_xCBufImg_24.ref(_xCBufImg_44, a3[j]);
		vector<uchar> _vuchar_18(a1.width());
		RAnalyse::getProjection_LineWidth(_xCBufImg_24, int((a3[j].top - a3[j].bottom) * 0.1f), _vuchar_18);
		int v14 = a3[j].right - 1;
		int v15 = 0, v16 = 0;
		for (int k = 0; k < v14; k++)
		{
			if (a2 - 50 >= _vuchar_18[k])
				v15 = 0;
			else
			{
				if (v15 >= 1)
				{
					v16 = k - 3;
					int v17 = 0;
					for (int i = a3[j].right - 1; i > v16; i--)
					{
						if (a2 - 50 >= _vuchar_18[i])
							v17 = 0;
						else
						{
							if (v17 >= 1)
							{
								v14 = i + 3;
								break;
							}
							v17++;
						}
					}

					if (a1.width() <= v16)
						v16 = a1.width() - 1;
					a3[j].left = MAX(0, v16);

					if (a1.width() <= v14)
						v14 = a1.width() - 1;
					a3[j].right = MAX(0, v14);
					break;
				}
				v15++;
			}
			v16 = 0;
		}
	}

}

void LineDetect::sortingLines(vector<tagRECT>&a1)
{
	if (a1.size() >= 2)
	{
		for (size_t i = 0; i < a1.size(); i++)
		{
			for (size_t j = i; j < a1.size() - 1; j++)
			{
				tagRECT _tagRECT;
				if (a1[j + 1].bottom > a1[i].bottom)
				{
					_tagRECT = a1[j + 1];
					a1[j + 1] = a1[i];
					a1[i] = _tagRECT;
				}
			}
		}
	}
}