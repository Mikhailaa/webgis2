#pragma once
#include "imseg_interface.h"
#include "CTCHypoth.h"

namespace imseg
{
	class CorrectSparseFont : public ICorrector
	{
	public:
		CorrectSparseFont(ICorrector *);
		~CorrectSparseFont();

		int isFontIsSparse(vector<CTCHypoth> &);
		void deleteAllSpaces(vector<CTCHypoth> &);
		virtual void process_impl(vector<CTCHypoth> &);
	};
}