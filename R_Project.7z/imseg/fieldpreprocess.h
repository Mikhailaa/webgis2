#pragma once
#include "pch.h"
#include "common/resources.h"
#include "common/container/container.h"
#include "common/container/RclHolder.h"
#include "Json/Value.h"
#include "imseg_rect.h"
#include "FieldImages.h"
#include "Field.h"


using namespace common::resources;
using namespace common::container;

namespace imseg
{
	namespace fieldpreprocess
	{
		namespace base
		{
			int process(TResultContainerList &, TVisualField &, FieldImages &, float, int *, vector<cv::Rect> &);
		}
		int process(TResultContainerList &, TVisualField &, FieldImages &, float, vector<cv::Rect> &, int *);
		void removeRectsFromImage(vector<cv::Rect> &, float, Field &);
		void removeRects(cv::Mat const &, Rect const &, vector<cv::Rect> const &, cv::Mat &);
		void toGrayColorRemove(cv::Mat &, cv::Mat &);
		void setDark(Rect const&, cv::Mat&);
		void blurBorders(Rect const&, cv::Mat const&, cv::Mat&);
		void toGrayColorRemove(cv::Mat&, cv::Mat&);
	}
}