#pragma once
class TextEx
{
public:
	TextEx();
	~TextEx();
};
