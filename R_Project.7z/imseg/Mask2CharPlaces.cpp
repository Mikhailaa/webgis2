#include "Mask2CharPlaces.h"
#include "common/UnicodeUtils.h"
#include "imseg.h"



namespace imseg
{
	extern CharPlace Digits;
	extern CharPlace Chars;
	extern CharPlace Space;
	extern CharPlace Wild;
	extern CharPlace Dot;
	extern CharPlace Slash;
	extern CharPlace Dash;

	namespace unicodes
	{
		extern set<uint> defaultSymbols;
	}
}

namespace imseg
{	
	namespace Mask2CharPlaces
	{
		map<wchar_t, CharPlace> elementaryParticlesRepeatable = {
			pair<wchar_t, CharPlace>(68, imseg::Digits),
			pair<wchar_t, CharPlace>(67, imseg::Chars),
			pair<wchar_t, CharPlace>(32, imseg::Space),
			pair<wchar_t, CharPlace>(87, imseg::Wild),
			pair<wchar_t, CharPlace>(46, imseg::Dot),
			pair<wchar_t, CharPlace>(47, imseg::Slash),
			pair<wchar_t, CharPlace>(45, imseg::Dash),
		};

		vector<CharPlace> buidCharPlacesFrom(SubField &arg1, vector<int> &arg2)
		{
			vector<CharPlace> RES_vCharPlace;
			set<uint> _setun_10, _setun_1C, _setun_28, _setun_34;
			int v15 = 0, v18 = 0, v21 = 0, v22 = 0;

			wstring _ws_40(*arg1.getMask());
			for (size_t i = 0; i < arg2.size(); i++)
				_setun_34.emplace(arg2[i]);
			if (_ws_40 == L"WORD")
			{
				CharPlace _xCharPlace_4C(_setun_34, _setun_28, CharPlace::CHARPLACETYPE_1);
				RES_vCharPlace.push_back(_xCharPlace_4C);		
				return RES_vCharPlace;
			}

			if (_ws_40 == L"STRINGS")
					v15 = 1;
			if (_ws_40 == L"STRING")
					v18 = 1;
			if (_ws_40 == L"TEXT")
					v21 = 1;
			if (_ws_40 == L"TEXT_c")
					v22 = 1;
			if ((v15 || v18 || v21 || v22) == 1)
			{
				set<uint>::iterator iter;
				for (iter = imseg::unicodes::defaultSymbols.begin(); iter != imseg::unicodes::defaultSymbols.end(); iter++)
					_setun_34.insert(*iter);
				CharPlace _xCharPlace_4C(_setun_34, _setun_28, CharPlace::CHARPLACETYPE_1);
				RES_vCharPlace.push_back(_xCharPlace_4C);
				return RES_vCharPlace;
			}

			for (size_t i = 0; i < arg2.size(); i++)
				_setun_1C.emplace(arg2[i]);
			for (size_t j = 0; j < _ws_40.size(); j++)
			{
				CharPlace _xCharPlace_4C(_setun_1C, _setun_10, CharPlace::CHARPLACETYPE_0);
				RES_vCharPlace.push_back(_xCharPlace_4C);
			}
			return RES_vCharPlace;
		}

		vector<CharPlace> buildCharPlacesFrom(map<wstring, SubField>& arg1, TextPartStruct &arg2, set<uint> &arg3)
		{
			vector<CharPlace>  _vCharPlace;
			vector<int> _vn_8(arg2.m_xCAlphatF_C.m_vAlphabet_0);
			_vn_8.insert(_vn_8.end(), arg2.m_xCAlphatF_C.m_vchar_C.begin(), arg2.m_xCAlphatF_C.m_vchar_C.end());
			_vCharPlace = atom2UnicodeSeq(arg2, arg1, _vn_8, arg3);
			return _vCharPlace;
		}

		vector<CharPlace> atom2UnicodeSeq(TextPartStruct &arg1, map<wstring, SubField>&arg2, vector<int>&arg3, set<uint>&arg4)
		{
			vector<CharPlace> RES_vCharPlace;			
			string _s_38(arg1.m_vucharName_3C.begin(), arg1.m_vucharName_3C.end());
			wstring _ws_2C = common::UnicodeUtils::Utf8ToWStr(_s_38);
			if (_ws_2C == L"TRASH")
			{
				set<uint> _setun_20, _setun_14;
				_setun_20.emplace(0x2020);
				CharPlace _xCharPlace_5C(_setun_20, _setun_14, CharPlace::CHARPLACETYPE_2);
				RES_vCharPlace.push_back(_xCharPlace_5C);
				return RES_vCharPlace;
			}

			if (_ws_2C==L"SPACE")
			{
				CharPlace _xCharPlace_5C(Space);
				RES_vCharPlace.push_back(_xCharPlace_5C);
				return RES_vCharPlace;
			}

			map<wstring, SubField>::iterator iter;
			iter = arg2.find(_ws_2C);
			if (arg1.m_nField_30 && iter != arg2.end())
			{
				vector<CharPlace> _vCharPlace_5C = buidCharPlacesFrom(iter->second, arg3);
				RES_vCharPlace = move(_vCharPlace_5C);
				arg4.insert(iter->second.getLCID());
				return RES_vCharPlace;
			}

			//no check
			for (size_t i = 0; i < _ws_2C.size(); i++)
			{
				map<wchar_t, CharPlace>::iterator iter;
				iter = elementaryParticlesRepeatable.find(_ws_2C[i]);
				if (iter == elementaryParticlesRepeatable.end())
				{
					if (_ws_2C[i] == '&')
					{
						_ws_2C[i] = _ws_2C[i + 1];
						i++;
						set<uint> _setun_20, _setun_14;
						for (size_t j = 0; j < arg3.size(); j++)
							_setun_20.insert(arg3[j]);
						CharPlace _xCharPlace_5C(_setun_20, _setun_14, CharPlace::CHARPLACETYPE_0);
						RES_vCharPlace.push_back(_xCharPlace_5C);
					}
					else
					{
						set<uint> _setun_20, _setun_14;
						_setun_20.insert(_ws_2C[i]);
						CharPlace _xCharPlace_5C(_setun_20, _setun_14, CharPlace::CHARPLACETYPE_0);
						RES_vCharPlace.push_back(_xCharPlace_5C);
					}
				}
				else
					RES_vCharPlace.push_back(iter->second);
			}
			
			return RES_vCharPlace;
		}
	}
}

