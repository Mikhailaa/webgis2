#include "Corrector.h"
#include "DbgFolder.h"
#include "dbgInfoSaver.h"
#include "TwinSymbolsCorrector.h"	
#include "ReplaceMultiNullBySpace.h"
#include "DeleteLowProbableSymbols.h"
#include "DeleteSequentialSpaces.h"
#include "DeleteLastSpaces.h"
#include "LingvoCorrector.h"
#include "CorrectSparseFont.h"
#include "DeleteFalseSymbolsAtEdges.h"
#include "DeleteFalseSpaces.h"
#include "LuhnCheckSumCorrector.h"
#include "BankCardLowProbCorrector.h"
#include "ReplaceSymbolsNotFromCodepage.h"
#include "VocabCorrector.h"

namespace imseg {

	Corrector::Corrector(uint const & a1, vector<shared_ptr<IFieldMask>> const & a2, FieldParam & a3)
	{
		m_nField_4 = 10;
		m_pVIC_8 = NULL;
		m_spCr_IC_24 = make_shared<MergeRepeats>(true, nullptr);

		imseg::ICorrector * correct = NULL;

		for (uint i = 0; i < a2.size(); i++)
		{			
			VocabInfo vocInfo;
			vocInfo.nCount_0 = a1;

			if (a2[i].get()->doNotDeleteSymbolsAfterMe())
			{
				imseg::TwinSymbolsCorrector * twin = new imseg::TwinSymbolsCorrector(0);
				imseg::ReplaceMultiNullBySpace * space = new imseg::ReplaceMultiNullBySpace(a1, twin);
				imseg::MergeRepeats * merge =  new imseg::MergeRepeats(true, space);
				imseg::DeleteSequentialSpaces * delspace = new imseg::DeleteSequentialSpaces(merge);
				imseg::DeleteLastSpaces *dellast = new imseg::DeleteLastSpaces(delspace);
				imseg::LingvoCorrector * lingvo = new imseg::LingvoCorrector(a1, dellast);
				imseg::VocabCorrector * vocab = new imseg::VocabCorrector(vocInfo, lingvo);
				correct = vocab;
			}
			else
			{
				imseg::TwinSymbolsCorrector * twin = new imseg::TwinSymbolsCorrector(NULL);
				imseg::ReplaceMultiNullBySpace * space = new imseg::ReplaceMultiNullBySpace(a1, twin);
				imseg::DeleteLowProbableSymbols * delsym = new imseg::DeleteLowProbableSymbols(a1, space);
				imseg::MergeRepeats * merge = new imseg::MergeRepeats(true, delsym);
				imseg::DeleteSequentialSpaces * delseq = new imseg::DeleteSequentialSpaces(merge);
				imseg::DeleteLastSpaces *dellast = new imseg::DeleteLastSpaces(delseq);
				imseg::CorrectSparseFont * corfont = new imseg::CorrectSparseFont(dellast);
				imseg::DeleteFalseSymbolsAtEdges * deledge = new imseg::DeleteFalseSymbolsAtEdges(corfont);
				imseg::LingvoCorrector *lingvo = new imseg::LingvoCorrector(a1, deledge);
				imseg::VocabCorrector *vocab = new imseg::VocabCorrector(vocInfo, lingvo);
				imseg::DeleteFalseSpaces * delspace = new imseg::DeleteFalseSpaces(a1, vocab);
				correct = delspace;
			}

			if (a3.contain(PROCESS_OPTION_12))
			{
				imseg::LuhnCheckSumCorrector * luhn = new imseg::LuhnCheckSumCorrector(correct);
				imseg::BankCardLowProbCorrector * bank = new imseg::BankCardLowProbCorrector(0.8f, luhn);
				correct = bank;
			}

			if (a3.contain(PROCESS_OPTION_13))
			{
				imseg::BankCardLowProbCorrector * bank = new imseg::BankCardLowProbCorrector(0.75f, correct);
				correct = bank;
			}

			if (a1 == 1068)
			{
				imseg::ReplaceSymbolsNotFromCodepage * replaceSNFC = new imseg::ReplaceSymbolsNotFromCodepage(1068, correct);
				correct = replaceSNFC;
			}

			m_vspCr_IC_18.push_back(shared_ptr<imseg::ICorrector>(correct));
		}
	}

	void Corrector::visit(RichTextLines & a1)
	{
		vector<vector<CTCHypoth>> &vpCTC = a1.getSeqs();
		vector<DbgFolder> &vpDbg = a1.getDbgFolders();

		for (size_t i = 0; i < vpCTC.size(); i++)
		{
			bool bFlag = i >= m_vspCr_IC_18.size();
			shared_ptr<ICorrector> shareICorrect = m_spCr_IC_24;
			if (!bFlag)
				shareICorrect = m_vspCr_IC_18[i];

			correctLogicaly(shareICorrect, vpCTC[i]);
			//imseg::dbgInfoSaver::saveAfterLogicalCorrection(vpDbg[i], vpCTC[i]);
			calcXOnImageOf(a1.getScale(i), vpCTC[i]);
		}

		vector<RichTextLines> &vRTL = a1.getVotingSeqs();
		for (size_t i = 0; i < vRTL.size(); i++)
			visit(vRTL[i]);
	}

	void Corrector::calcXOnImageOf(float const & a1, vector<imseg::CTCHypoth>& a2)
	{
		for (size_t i = 0; i < a2.size(); i++)
			a2[i].calcXOnImage(a1);
	}

	void Corrector::correctLogicaly(shared_ptr<imseg::ICorrector>& a1, vector<imseg::CTCHypoth>& a2)
	{
		vector<vector<imseg::CTCHypoth>> vRet;
		vRet = replaceUnConfidentNullsBySecondCandidate(a2);
		a1.get()->process(a2);
		if (!VocabCorrector::isPresentInVocabulary(a2))
		{
			for (size_t i = 0; i < vRet.size(); i++)
			{
				// no check
				a1.get()->process(vRet[i]);
				if (m_pVIC_8->isPresentInVocabulary(a2))
					a2 = vRet[i];
			}
		}
	}

	bool Corrector::replaceFirstUnConfidentNullsBySecondCandidate(vector<imseg::CTCHypoth>& a1, vector<vector<imseg::CTCHypoth>>& a2)
	{
		//no check
		for (size_t i = 0; i < a1.size(); i++)
		{
			if (a1[i].field_8 == 0x10FFFF && a1[i].m_lstImCTCHy_18.size())
			{
				vector<imseg::CTCHypoth> vCTC_2c(a1);
				list<imseg::CTCHypoth> lCTC_38(a1[i].m_lstImCTCHy_18);
				imseg::CTCHypoth xCTC(lCTC_38.front());
				vCTC_2c[i] = xCTC;
				lCTC_38.pop_front();
				vCTC_2c[i].m_lstImCTCHy_18 = lCTC_38;
				a2.push_back(vCTC_2c);
			}
		}

		return !a2.empty();
	}

	vector<vector<imseg::CTCHypoth>> Corrector::replaceUnConfidentNullsBySecondCandidate(vector<imseg::CTCHypoth> const & a1)
	{
		vector<vector<imseg::CTCHypoth>> vRet;
		vector <vector<imseg::CTCHypoth>> vvCTC_2C;
		deque<vector<imseg::CTCHypoth>> dCTC_5C(1, a1);

		while (dCTC_5C.size())
		{
			vector<imseg::CTCHypoth> vCTC(dCTC_5C.back());
			dCTC_5C.pop_back();
			if (replaceFirstUnConfidentNullsBySecondCandidate(vCTC, vvCTC_2C))
			{
				for (size_t i = 0; i < vvCTC_2C.size(); i++)
				{
					vRet.push_back(vvCTC_2C[i]);
					if (vRet.size() <= (size_t)m_nField_4)
					{
						dCTC_5C.push_back(vvCTC_2C[i]);
					}
					else
					{
						vRet.clear();
						break;
					}
				}
			}
		}

		return vRet;
	}

}
