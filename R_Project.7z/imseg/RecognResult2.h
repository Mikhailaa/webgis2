#pragma once
#include "pch.h"
#include "SymbolCandidat.h"

class RecognResult2
{
public:
	RecognResult2();
	RecognResult2(RecognResult2 &&);
	vector<int> candidates(float);
	int candidate(int);
	void candidates(int ,vector<int>&);
	int prob(int);
	float probF(int);
	RecognResult2& operator=(RecognResult2 &);
	vector<SymbolCandidat> m_vSymCandidat;
};