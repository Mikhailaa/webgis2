#pragma once
#include "CTCHypoth.h"
#include "CharPlace.h"
#include "CTCHypoth.h"

namespace imseg
{
	class CostMat
	{
	public:
		float m_rCostMatField_0;
		float m_rCostMatField_4;
		float m_rCostMatField_8;
		float m_rCostMatField_C;
		float m_rCostMatField_10;
		int m_nCostMatField_14;

		imseg::CTCHypoth getMatchingHypoth(imseg::CTCHypoth&, imseg::CharPlace&);
		float getMatchingCost(imseg::CTCHypoth&, imseg::CharPlace&);
		float getDeletingCost(imseg::CharPlace&);
		float getDeletingCost(imseg::CTCHypoth&);
		CostMat();
	};
}

