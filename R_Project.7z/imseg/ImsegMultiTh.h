#pragma once
#include "../pch.h"
#include "common/resources.h"
#include "common/common.h"
#include "common/container/container.h"
#include "common/container/RclHolder.h"
#include "Json/Value.h"
#include "FieldAdapter.h"
#include "imseg.h"
#include "ImSegBase.h"
#include "moduleprocessgl.h"

using namespace common;
using namespace common::resources;
using namespace common::container;

namespace imseg
{	
	class ImsegMultiTh : public moduleprocessgl::IProcessFunction
	{
	public:		
		UniqueObjectByIndex<UniqueObjectByIndex<ImSeg>> m_xUOBIUOBI_ImSeg_4;
		UniqueObjectByIndex<RclHolder> m_xUOBI_RH_1C;
		string m_s_34;
		Json::Value m_xJV_40;

		ImsegMultiTh();
		~ImsegMultiTh();
		vector<int> getCommands();
		int process(int, void *, const char *, void **, char **);
	};
};
