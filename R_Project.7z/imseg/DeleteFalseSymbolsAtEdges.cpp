#include "DeleteFalseSymbolsAtEdges.h"
//                 s0        r0      r0+4     r0[2][3]  r1  
bool sub_4D211C(float s0, float a1,float a2,float a3, float a4)
{
	int R0 = 0;
	int R1 = 0;
	int R2 = 0;
	if (a4 < a3) R1 = 1;
	if (a1 < s0) R2 = 1;
	if (a2 < s0) R0 = 1;
	return (R0 || R1 && R2);
}

imseg::DeleteFalseSymbolsAtEdges::DeleteFalseSymbolsAtEdges(ICorrector*pICorrector)
{
	m_pIC_4 = pICorrector;
	m_rDeleteFalseSymbolsAtEdges_8 = 6.0f;
	m_rDeleteFalseSymbolsAtEdges_C = 0.9f;
	m_rDeleteFalseSymbolsAtEdges_10 = 12.0f;
}

imseg::DeleteFalseSymbolsAtEdges::~DeleteFalseSymbolsAtEdges()
{
}

void imseg::DeleteFalseSymbolsAtEdges::process_impl(vector<CTCHypoth>&vCTCHypoth)
{
	int size = vCTCHypoth.size();
	if (size >= 5)
	{
		float rTmp_v11 = fabs(float(vCTCHypoth[size - 2].m_nIndex_C - vCTCHypoth[1].m_nIndex_C) / float(size - 2));
		int v8 = vCTCHypoth[size - 2].m_nIndex_C;
		float r_a2 = m_rDeleteFalseSymbolsAtEdges_8 * rTmp_v11;
		float r_a1 = m_rDeleteFalseSymbolsAtEdges_10 * rTmp_v11;
		float S0 = (float)vCTCHypoth[0].m_nIndex_C - (float)vCTCHypoth[1].m_nIndex_C;
		if (sub_4D211C(S0, r_a1, r_a2, m_rDeleteFalseSymbolsAtEdges_C, vCTCHypoth[0].m_fHandmade_14))
		{
			vCTCHypoth.erase(vCTCHypoth.begin());
			v8 = vCTCHypoth[vCTCHypoth.size() - 2].m_nIndex_C;
		}

		S0 = (float)abs(vCTCHypoth[size - 1].m_nIndex_C - v8);
		if (sub_4D211C(S0, r_a1, r_a2, m_rDeleteFalseSymbolsAtEdges_C, vCTCHypoth[size - 1].m_fHandmade_14))
			vCTCHypoth.erase(vCTCHypoth.begin() + vCTCHypoth.size() - 1);
	}
}
