#pragma once
#include "pch.h"
#include "common/resources.h"
#include "common/container/container.h"
#include "common/container/RclHolder.h"
#include "Json/Value.h"

#include "imseg.h"
#include "ParsedMask.h"
#include "MaskStringUtils.h"
#include "Mask2CharPlaces.h"

using namespace common::resources;
using namespace common::container;

namespace imseg
{
	class ParsedMaskBuilder
	{
	public:
		static void buildParsedMask(ParsedMask &res, Field &, string, uint);
		static bool isLineBreaksDoNotMatter(wstring);
	};
}