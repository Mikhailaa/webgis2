#include "unicodes.h"

namespace imseg
{
	namespace unicodes
	{
		
		set<uint> allVisuallyIdenticalUnicodes;
		
		vector<vector<uint>> visuallyIdenticalUnicodes =
		{
			{ 65, 913, 1040 },
		{ 66, 914, 1042 },
		{ 99, 1089 },
		{ 67, 1057 },
		{ 69, 917, 1045 },
		{ 72, 1053, 919 },
		{ 73, 921, 1030 },
		{ 74, 1032 },
		{ 107, 1082, 954 },
		{ 75, 922, 1050 },
		{ 77, 924, 1052 },
		{ 78, 925 },
		{ 111, 1086 },
		{ 79, 927, 959, 1054, 48 },
		{ 80, 929, 1056 },
		{ 112, 1088 },
		{ 83, 115 },
		{ 84, 932, 1058 },
		{ 85, 117 },
		{ 86, 118 },
		{ 87, 119 },
		{ 120, 935, 1093 },
		{ 88, 1061 },
		{ 89, 933, 1059 },
		{ 90, 122, 918 },
		{ 97, 1072 },
		{ 101, 1077 },
		{ 105, 1110 },
		{ 106, 1112 },
		{ 121, 1091 },
		{ 203, 1025 },
		{ 207, 938, 1031 },
		{ 538, 354 },
		{ 539, 355 },
		{ 536, 350 },
		{ 537, 351 },
		{ 110, 1087 },
		{ 399, 1240 },
		{ 601, 1241 },
		};


		set<uint> defaultSymbols =
		{
			0x20, 0x2A, 0x22, 0x2F, 0x28, 0x29, 0x2C, 0x2D, 0x2E,
			0x3A, 0x3B, 0xAB, 0xBB, 0x5E
		};

		vector<pair<set<uint>, set<uint> > > g_vpair_setnsetn_1129DC8 =
		{
			pair<set<uint>, set<uint> >({ 0x4F, 0x6F, 0x41E, 0x43E },{ 0x30 }),
			pair<set<uint>, set<uint> >({ 0x69, 0x49 },{ 0x31 })
		};

		vector<uint> getVisualIdenticalSetForUnicode(uint const&n_a2)
		{
			//g_vpair_setnsetn_1129DC8
			vector<uint> vRet;
			if (allVisuallyIdenticalUnicodes.find(n_a2) != allVisuallyIdenticalUnicodes.end())
			{
				for (uint i = 0; i < visuallyIdenticalUnicodes.size(); i++)
				{
					vRet = visuallyIdenticalUnicodes[i];
					for (uint j = 0; j < vRet.size(); j++)
					{
						if (vRet[j] == n_a2) return vRet;
					}
				}
			}

			return vRet;
		}

		set<uint>* getUnicodesForProbabilityTransfer(uint un_a1)
		{
			if (g_vpair_setnsetn_1129DC8.empty())
				return NULL;

			uint i;
			for (i = 0; i < g_vpair_setnsetn_1129DC8.size(); i++)
			{
				if (g_vpair_setnsetn_1129DC8[i].first.find(un_a1) != g_vpair_setnsetn_1129DC8[i].first.end())
					return &g_vpair_setnsetn_1129DC8[i].second;
				if (g_vpair_setnsetn_1129DC8[i].second.find(un_a1) != g_vpair_setnsetn_1129DC8[i].second.end())
					return &g_vpair_setnsetn_1129DC8[i].first;
			}

			return NULL;
		}

	}
}