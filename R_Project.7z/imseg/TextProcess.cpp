#include "TextProcess.h"
#include "TextPartStructPosition.h"
#include "RecognResult2.h"
using namespace imseg;

bool TextProcess::generateFieldStructDnn(Text& a1, TextStruct& a2) 
{
	TextStructManager::splitByContent2(a2, a1);
	if (!TextStructManager::isStructureReady(a2)) return true;
	updateSymbolPosition(a1, a2);
	return false;
}

//uncomplete
bool TextProcess::generateFieldStruct(CBufferImage &CBufImg_a1, Text& xText_a2, TextStruct &xTStruct_a3)
{
	if (!(xTStruct_a3.m_bField_1C) || (xTStruct_a3.m_vuc_20.size() != xText_a2.m_vimsegSymbol_0.size()))
	{
		for (uint i = 0; i < xTStruct_a3.m_vTextPartStruct_0.size(); i++)
		{
			TextPartStruct *pTPS_v7 = &xTStruct_a3.m_vTextPartStruct_0[i];
			unordered_map<int, int> _uomap_nn_30;
			if (!pTPS_v7->m_nField_30)
			{
				string _s_20(pTPS_v7->m_vucharName_3C.begin(), pTPS_v7->m_vucharName_3C.end());
				string::iterator new_end = remove(_s_20.begin(), _s_20.end(), ' ');
				_s_20.erase(new_end - _s_20.begin(), _s_20.end() - new_end);
				vector<uchar> _vuchar_14(_s_20.begin(), _s_20.end());
				for (uint j = 0; j < _vuchar_14.size(); j++)
					_uomap_nn_30[_vuchar_14[j]] ++;
			}

		}
	}
	return 0;
}

bool TextProcess::updateSymbolPosition(Text& a1, TextStruct& a2)
{
	for (uint v3 = 0; v3< a2.m_vTextPartStruct_0.size(); v3++)
	{
		TextPartStruct &v61 = a2.m_vTextPartStruct_0.at(v3);
		if (v61.m_bField_38)
		{
			TextPartStructPosition v5 = v61.position();
			if (v61.m_nField_30 && v61.m_Position_0.isReady())
			{
				int v6 = v5.len();
				vector<CSymbolResult> &v7 = v61.text();
				v7.resize(v6);
				tagRECT rt;
				for (int i = 0; i<v6; i++)
				{
					int v10 = a1.m_vimsegSymbol_0.size();
					int v11 = v5.m_nStartPos_4 + i;
					if (v10 <= v11) return true;
					if (a1.m_vimsegSymbol_0[v11].field_50)
					{
						rt = a1.m_vimsegSymbol_0[v11].m_xRECT_40;
					}
					else
					{
						rt = a1.m_vimsegSymbol_0[v11].rect();
					}
					v7.at(i).xTSR_SymbolRect = rt;
					BaseLines v21 = a1.baseLine(v5.m_nStartPos_4 + i);
					v7.at(i).u.s.sTSTR_BaseLineTop = v21.line(eBaseLinePos_4);
					v7.at(i).u.s.sTSTR_BaseLineBottom = v21.line(eBaseLinePos_2);
					for (uint v26 = 0; v26<a1.m_vimsegSymbol_0[v11].m_xRecRes2_18.m_vSymCandidat.size(); v26++)
					{
						int v27 = a1.m_vimsegSymbol_0[v11].m_xRecRes2_18.candidate(v26);
						int j = 0;
						int v28 = v61.m_xCAlphatF_C.m_vAlphabet_0.size();
						for (; j<v28; j++)
						{ 
							if (v61.m_xCAlphatF_C.m_vAlphabet_0[j] == v27) break;
						}
						if (v28 != j || v27 == '^' || v27 == ' ')
						{
							SymbolCandidat v31 = a1.m_vimsegSymbol_0[v11].m_xRecRes2_18.m_vSymCandidat[v26];
							int v32 = a1.m_vimsegSymbol_0[v11].m_xRecRes2_18.prob(v26);
							v7.at(i).addSymbolCandidate(v31.m_wszCandiateCharacter_0, v32, v31.field_8, v31.field_C);
						}
					}
					if (!v7.at(i).nTSR_CandidatesCount)
					{
						v7.at(i).addSymbolCandidate('*', 85, 0, 0);
					}
				}
			}
			else
			{
				vector<CSymbolResult> v36 = v61.text();
				v36.resize(v61.m_vucharName_3C.size());
				int v39 = 0;
				for (uint v40 = 0; v40<v61.m_vucharName_3C.size(); v40++)
				{
					if (a1.m_vimsegSymbol_0.size() <= v5.m_nStartPos_4 + v40) return 1;
					v36.at(v40).addSymbolCandidate(v61.m_vucharName_3C[v40], 'd', 0, 0);
					bool v44 = v61.m_vucharName_3C[v40] == ' ';
					int v43;
					if (!v44)
					{
						v43 = v5.m_nStartPos_4;
						v44 = v43 == -1;
					}
					if (!v44)
					{
						int v46 = a1.m_vimsegSymbol_0[v40 + v43].m_xRecRes2_18.prob(0);
						char v47 = a1.m_vimsegSymbol_0[v40 + v43].m_xRecRes2_18.candidate(0);
						if (v47 != v61.m_vucharName_3C[v40]) v46 -= 5;
						v36.at(v40).xnTSR_Candidates[0].nTSC_SymbolProbability = (uint)v46;
						imseg::Symbol v49 = a1.m_vimsegSymbol_0[v5.m_nStartPos_4 + v39];
						v39++;
						v36.at(v40).xTSR_SymbolRect.left = v49.m_xRECT_0.left;
						v36.at(v40).xTSR_SymbolRect.right = v49.m_xRECT_0.right;
					}
				}
			}
		}
	}

	return false;
}
