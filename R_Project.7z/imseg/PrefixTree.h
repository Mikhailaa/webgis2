#pragma once
#include "word_beam_search.h"

namespace imseg
{
	namespace word_beam_search
	{
		class PrefixTree
		{
			class Node
			{
			public:
				vector<pair<uint, shared_ptr<Node> > > m_vNode_0;
				vector<uint>                           m_vNode_C;
				int                                    m_nNode_18;

				~Node() {};
			};

		public:
			shared_ptr<Node>                    m_spPT_0;
			map<int, vector<vector<uint> > >    m_mPT_8;

		public:
			PrefixTree();
			~PrefixTree();

			void addWord(vector<uint> const&);
			void allWordsAdded(void);
			map<int, Char> getNextChars(vector<uint> const&);
			vector<vector<uint>> getNextWords(vector<uint> const&);
			shared_ptr<Node> getNode(vector<uint> const&);
			void io(cv::dnn::DnnReader & a2, shared_ptr<Node> & a3);
			void io_generic(cv::dnn::DnnReader &);
			bool isWord(vector<uint> const&);
		};
	}
}