#pragma once
#include "pch.h"
#include "common/resources.h"
#include "common/container/container.h"
#include "common/container/RclHolder.h"
#include "Json/Value.h"

using namespace common::resources;
using namespace common::container;

namespace imseg
{
	class CharPlace
	{
	public:
		enum CharPlaceType
		{
			CHARPLACETYPE_0 = 0,
			CHARPLACETYPE_1 = 1,
			CHARPLACETYPE_2 = 2,
			CHARPLACETYPE_3 = 3
		};

		set<uint> m_setun_0;
		set<uint> m_setun_C;
		CharPlaceType m_nCharPlaceType_18;

		CharPlace();
		CharPlace(CharPlace const&);
		CharPlace(set<uint> const&, set<uint> const&, CharPlaceType);
		~CharPlace();

		set<uint>& getPossibleUnicodes();
		CharPlace &operator=(const CharPlace&);
		bool operator==(CharPlace&);
		bool isOptional();
		bool isTrash();
		bool is_possible(uint);
		void makeObligatory(void);
	};
};