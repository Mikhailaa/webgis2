#pragma once
#include "pch.h"
#include "common/resources.h"
#include "common/container/container.h"
#include "common/container/RclHolder.h"
#include "common/fs.h"

using namespace common;
using namespace common::resources;
using namespace common::container;

namespace imseg
{
	class DbgFolder
	{
	public:
		common::fs::Path m_xCfsPath_0;
		int field_18;

		DbgFolder() {};
		DbgFolder(DbgFolder&&);
		DbgFolder(DbgFolder const&);
		DbgFolder operator=(DbgFolder const&);
	};
}
