#pragma once
#include "../pch.h"
#include "common/resources.h"
#include "common/container/container.h"
#include "common/container/RclHolder.h"
#include "Json/Value.h"
#include "Base.h"
#include "description.h"
#include "FieldAdapter.h"
#include "glare.h"
#include "ImSegStatic.h"
#include "series.h"
#include "FieldAdapter.h"
#include <algorithm>
#include <tuple>

using namespace imseg;
using namespace common;
using namespace common::resources;
using namespace common::container;

class ImSeg
{
public:
	Json::Value m_xJsonValue_0;
	RclHolder m_xRclH_18;
	CRecognizedTextDoc m_xRecognizedTextDoc_2C;
	string m_strResult;
	string m_s_44;
	imseg::series::ProcessSeriesControl m_xPSCtrl_50;
	int m_nfield_F4; //unknown

	ImSeg();
	~ImSeg();
	int initField(CVisualField &, InitConstStructs &, Field &);
	int process(CVisualField &, LayerParam &, Field &, FontDesc &, bool);
	int processList(TResultContainerList &, const char *, TResultContainerList **, char **);
	int processList(CDocInfo &, TResultContainerList &, TDocVisualExtendedInfo **, char **);
	int processSeries(TResultContainerList &, const char *, TResultContainerList**, char **);
	void readPerforationText(vector<CVisualField *> &, TResultContainerList &, CRecognizedTextDoc &);
};

namespace postcorrect
{
	void SymbolFix(TDocVisualExtendedInfo *);
}