#include "TwinSymbolsCorrector.h"

vector<pair<uint, uint>> imseg::TwinSymbolsCorrector::m_twins = { pair<uint, uint>(40, 41) };
int imseg::TwinSymbolsCorrector::m_twinsIdentical = 0x22;

imseg::TwinSymbolsCorrector::TwinSymbolsCorrector(ICorrector *a1)
{
	m_pIC_4 = a1;
}

imseg::TwinSymbolsCorrector::~TwinSymbolsCorrector()
{
}

void imseg::TwinSymbolsCorrector::insertInMostProbablePlace(vector<CTCHypoth>::iterator iCTCHypoth1, vector<CTCHypoth>::iterator iCTCHypoth2, uint n_a3)
{
	vector<CTCHypoth>::iterator iterCTCHypoth1 = iCTCHypoth1;
	vector<CTCHypoth>::iterator iterCTCHypoth2 = iCTCHypoth2;
	vector<CTCHypoth>::iterator iterTmpCTCHypoth2 = iCTCHypoth2;
	float rThreshold = 0.0f;
	while (iterCTCHypoth2 != iterCTCHypoth1)
	{
		if ((*iterCTCHypoth1).getUnicode() == 0x10FFFF)
		{
			int nTmpUnicode = 0;
			list<CTCHypoth>::iterator iter;
			bool v12 = 0, v13 = 0;
			for (iter = (*iterCTCHypoth1).m_lstImCTCHy_18.begin(); iter != (*iterCTCHypoth1).m_lstImCTCHy_18.end(); iter++)
			{
				nTmpUnicode = (*iter).getUnicode();
				v13 = nTmpUnicode == n_a3;
				if ((*iter).m_fHandmade_14 > rThreshold)
					v12 = 1;
				if (v13 & v12)
				{
					rThreshold = (*iter).m_fHandmade_14;
					iterTmpCTCHypoth2 = iterCTCHypoth1;
				}
			}
		}
		iterCTCHypoth1++;
	}
	if (iterCTCHypoth2 != iterTmpCTCHypoth2)
		(*iterTmpCTCHypoth2).setUnicode(n_a3);
}

void imseg::TwinSymbolsCorrector::process_impl(vector<CTCHypoth>& vCTCHypoth)
{
	vector<CTCHypoth>::iterator iterCTCHypoth1 = vCTCHypoth.end();
	for (vector<CTCHypoth>::iterator i = vCTCHypoth.begin(); i != vCTCHypoth.end(); i++)
	{
		if (m_twins[0].first == (*i).getUnicode())
		{
			iterCTCHypoth1 = i;
			break;
		}
	}
	vector<CTCHypoth>::iterator iterCTCHypoth2 = vCTCHypoth.end();
	for (vector<CTCHypoth>::iterator i = vCTCHypoth.begin(); i != vCTCHypoth.end(); i++)
	{
		if (m_twins[0].second == (*i).getUnicode())
		{
			iterCTCHypoth2 = i;
			break;
		}
	}
	if (iterCTCHypoth1 != vCTCHypoth.end() && iterCTCHypoth2 == vCTCHypoth.end())
		insertInMostProbablePlace(iterCTCHypoth1, vCTCHypoth.end(), m_twins[0].second);
	if (iterCTCHypoth1 == vCTCHypoth.end() && iterCTCHypoth2 != vCTCHypoth.end())
		insertInMostProbablePlace(vCTCHypoth.end(), iterCTCHypoth2, m_twins[0].first);
}
