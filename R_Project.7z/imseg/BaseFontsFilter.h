#include "SymbolFontFilter.h"
#include "imseg_interface.h"
#pragma once

class BaseFontsFilter : public IBaseFontsFilter
{
public:
	vector<SymbolFontFilter> m_vSymbolFontFilter_4;
	vector<int> fontFilter(int, int);
	~BaseFontsFilter();
};