#include "TextStruct.h"
#include "RSubFieldManager.h"
#include "VisualSubFieldEx.h"

float TextStruct::middleProb()
{
	float rProb = 0.0f;
	int nCount = 0;
	for (size_t i = 0; i < m_vTextPartStruct_0.size(); i++)
	{
		for (size_t j = 0; j < m_vTextPartStruct_0[i].m_vCSymbolResult_60.size(); j++)
		{
			if(m_vTextPartStruct_0[i].m_vCSymbolResult_60[j].nTSR_CandidatesCount)
			{
				nCount++;
				rProb += m_vTextPartStruct_0[i].m_vCSymbolResult_60[j].xnTSR_Candidates[0].nTSC_SymbolProbability;
			}
		}
	}

	if(!nCount) return 0.0f;
	return rProb / (float)nCount;
	
}

bool TextStruct::addPart(TextPartStruct &a1)
{
	m_vTextPartStruct_0.push_back(a1);
	return setPart(m_vTextPartStruct_0.size() - 1, a1.m_vucharName_3C);
}

TextStruct & TextStruct::operator=(TextStruct const&a2)
{
	if (this == &a2)
	{
		this->field_C = a2.field_C;
		this->m_bField_1C = a2.m_bField_1C;
	}
	else
	{
		m_vTextPartStruct_0 = a2.m_vTextPartStruct_0;
		this->field_C = a2.field_C;
		m_vuc_10 = a2.m_vuc_10;
		m_bField_1C = a2.m_bField_1C;
		m_bField_1D = a2.m_bField_1D;
		m_vuc_20 = a2.m_vuc_20;
	}
	this->m_nLineCount_2C = a2.m_nLineCount_2C;
	m_xCAlphaF_30 = a2.m_xCAlphaF_30;

	return *this;
}

TextStruct& TextStruct::operator=(TextStruct &&a2)
{
	m_vTextPartStruct_0 = move(a2.m_vTextPartStruct_0);
	this->field_C = a2.field_C;
	m_vuc_10 = move(a2.m_vuc_10);
	m_bField_1C = a2.m_bField_1C;
	m_bField_1D = a2.m_bField_1D;
	m_vuc_20 = move(a2.m_vuc_20);
	this->m_nLineCount_2C = a2.m_nLineCount_2C;
	m_xCAlphaF_30 = move(a2.m_xCAlphaF_30);
	return *this;
}

bool TextStruct::setPart(int a2, vector<uchar>& a3)
{
	if (a2 >= (int)m_vTextPartStruct_0.size()) return 1;

	ListSubField* pLSF = RSubFieldManager::subFields();
	string str_28(a3.begin(),a3.end());
	int nIdx = pLSF->indexOf(str_28.data());
	if (nIdx == -1) return true;
	m_vTextPartStruct_0[a2].m_pCVisualSubField_34 = &(*pLSF)[nIdx];
	m_vTextPartStruct_0[a2].m_bField_3A = CVisualSubFieldEx::isDynamic(*m_vTextPartStruct_0[a2].m_pCVisualSubField_34);
	if (!m_vTextPartStruct_0[a2].m_bField_3A)
	{
		m_bField_1D = true;
		if (m_vTextPartStruct_0[a2].m_xTextPartLCIDInfo_70.m_vLcids_4.empty() &&
			m_vTextPartStruct_0[a2].m_pCVisualSubField_34->m_sTVSF_lcid)//Lcid
		{
			m_vTextPartStruct_0[a2].m_xTextPartLCIDInfo_70.addLcid(m_vTextPartStruct_0[a2].m_pCVisualSubField_34->m_sTVSF_lcid);
		}
	}
	return false;
}

TextStruct::TextStruct()
{
	field_C = 0;
	m_bField_1C = 0;
	m_bField_1D = 0;
	m_bField_1E = 0;
	m_bField_1F = 0;
	m_nLineCount_2C = 0;
	field_C = 0x101;
}

TextStruct::TextStruct(TextStruct const &a2):
	m_xCAlphaF_30(a2.m_xCAlphaF_30)
{
	m_vTextPartStruct_0 = a2.m_vTextPartStruct_0;
	field_C = a2.field_C;
	m_vuc_10  = a2.m_vuc_10;
	m_bField_1C = a2.m_bField_1C;
	m_bField_1D = a2.m_bField_1D;
	m_vuc_20 = a2.m_vuc_20;
	m_nLineCount_2C = a2.m_nLineCount_2C;
}

TextStruct::~TextStruct()
{
}

void SymbolConflictAnalize::resolveField(TextStruct &a2)
{
	for (size_t i = 0; i < a2.m_vTextPartStruct_0.size(); i++)
	{
		for (size_t j = 0; j < a2.m_vTextPartStruct_0[i].text().size(); j++)
		{
			for (size_t k = 0; k < a2.m_vTextPartStruct_0[i].text()[j].nTSR_CandidatesCount; k++)
			{
				int v7 = a2.m_vTextPartStruct_0[i].text()[j].get(k);
				size_t l = 0;
				for (; l < a2.m_vTextPartStruct_0[i].m_xCAlphatF_C.m_vAlphabet_0.size(); l++)
				{
					if (a2.m_vTextPartStruct_0[i].m_xCAlphatF_C.m_vAlphabet_0[l] == v7)
						break;
				}
				if (l == a2.m_vTextPartStruct_0[i].m_xCAlphatF_C.m_vAlphabet_0.size())
				{
					a2.m_vTextPartStruct_0[i].text()[j].removeCandidat(k--);
				}
			}
		}
	}
}

void LettersFilter::filterByLongSpace(TextStruct & a1, int a2, int a3)
{
	//if(!m_bField_1C)
	//{
	//	vector<CSymbolResult*> vSym_38;
	//	vector<vector<CSymbolResult*>> vSym_2C;
	//	for(int i = 0; i < a1.m_vTextPartStruct_0.size(); i++)
	//	{
	//
	//	}
	//}
}

