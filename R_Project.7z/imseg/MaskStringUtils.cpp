#include "MaskStringUtils.h"
#include "common/UnicodeUtils.h"
#include <algorithm>
#include <iterator>
#include "common/StringUtils.h"

namespace imseg
{
	wchar_t MaskStringUtils::removableChars = L'!';
}


void imseg::MaskStringUtils::replaceSubstring(wstring &arg1, wstring &arg2, wstring &arg3)
{
	int v4 = 0;
	while (1)
	{
		if ((size_t)v4 > arg1.size())
			break;
		if (arg2.size())
		{
			v4 = arg1.find(arg2, v4);
			if (v4 == -1)
				return;
			wstring _ws_24(arg1, 0, v4);
			_ws_24.append(arg3);
			wstring _ws_18(arg1, v4 + arg2.size());
			_ws_24.append(_ws_18);
			arg1.assign(_ws_24);
			v4 += arg3.size();
		}
	}
}

int imseg::MaskStringUtils::replaceAmpersandByWild(wstring &arg1)
{
	int res = 0, i;
	for (i = arg1.find('&', 0); ; i = arg1.find('&', 0))
	{
		res = i + 1;
		if (i == -1)
			break;
		arg1.erase(i, 1);
		arg1[i] = 'W';
	}
	return 0;
}

void imseg::MaskStringUtils::deleteAllLcidsAndFieldTypes(wstring &arg1, set<uint>&arg2)
{
	set<uint> *_psetun_10, _setun_68;
	wstring _ws_48, _ws_58;
	vector<wstring> _vws_30, _vws_48;
	_psetun_10 = &arg2;
	
	while (deleteAllBeetween(arg1, '[', ']', _ws_58))
	{
		splitStrBy(_vws_48, _ws_58, ',');

		for (size_t i = 0; i < _vws_48.size(); i++)
		{
			wstring _ws_3C(_vws_48[i]);
			splitStrBy(_vws_30, _ws_3C, '+');
			for (size_t j = 0; j < _vws_30.size(); j++)
			{
				wstring _ws_24(_vws_30[j]);
				string _s_18 = UnicodeUtils::WStrToUtf8(_ws_24);
				int _n_14 = StringUtils::toSize(_s_18);
				_setun_68.emplace(_n_14);
			}
		}

		while (deleteAllBeetween(arg1, '"', '"', _ws_48));
	}
}

void imseg::MaskStringUtils::splitStrBy(vector<wstring> &arg1, wstring &arg2, wchar_t arg3)
{
	int v6 = 0, v7;	
	while (v6 != -1)
	{
		v7 = arg2.find(arg3, v6);
		if (v7 == -1)
		{
			wstring _ws_8(arg2, v6, -1);
			arg1.push_back(_ws_8);
			return;
		}
		wstring _ws_8(arg2, v6, v7 - v6);
		arg1.push_back(_ws_8);
		v6 = v7 + 1;
	}

}

bool imseg::MaskStringUtils::deleteAllBeetween(wstring &arg1, wchar_t arg2, wchar_t arg3, wstring &arg4)
{
	int v8, v11;
	arg4.assign(L"");
	v8 = arg1.find(arg2, 0);
	if (v8 == -1)
		return false;
	v11 = arg1.find(arg3, v8 + 1);
	if (v11 == -1)
		return false;
	wstring _ws_20(arg1, v8 + 1, v11 + ~v8);

	arg4.assign(_ws_20);
	wstring _ws_14(arg1, 0, v8);
	wstring _ws_8(arg1, v11 + 1, -1);
	_ws_14.append(_ws_8.data(), _ws_8.size());
	arg1.assign(_ws_14);
	return true;
}

wstring imseg::MaskStringUtils::stripMask(wstring const &arg1, set<uint>&arg2)
{
	wstring res(arg1);
	wstring _ws_28;
	deleteAllBeetween(res, '@', '@', _ws_28);
	wstring _ws_18(L"{_}");
	wstring _ws_8(L"");
	replaceSubstring(res, _ws_18, _ws_8);

	basic_string<wchar_t>::iterator iter = remove(res.begin(), res.end(), removableChars);
	res.erase(iter);
	
	replaceAmpersandByWild(res);
	deleteAllLcidsAndFieldTypes(res, arg2);	
	return res;
}
