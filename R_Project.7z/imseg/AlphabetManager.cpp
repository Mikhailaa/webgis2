#include "AlphabetManager.h"
#include "common/UnicodeUtils.h"

vector<int> CAlphabetManager::convert(CAlphabet *a1, int a2)
{
	vector<int> vn_ret;
	if (a1[a2].m_bCA_HasData_0)
	{
		string str_38(a1[a2].m_szCA_Alphabet);
		wstring wstr_28 = common::UnicodeUtils::Utf8ToWStr(str_38);
		for (uint i = 0; i < wstr_28.length(); i++)
		{
			vn_ret.push_back(wstr_28[i]);
		}
	}
	return vn_ret;
}

void CAlphabetManager::convert(CAlphabet *a2, vector<int>&a3)
{
	for (int i = 0; i < 4; i++)
	{
		if (a2[i].m_bCA_HasData_0)
		{
			string str_38(a2[i].m_szCA_Alphabet);
			wstring wstr_28 = common::UnicodeUtils::Utf8ToWStr(str_38);
			for (uint j = 0; j < wstr_28.length(); j++)
			{
				a3.push_back(wstr_28[j]);
			}
		}
	}
}

void CAlphabetManager::convert(CAlphabetContainer &a1, CAlphabet *a2)
{
	vector<int> vn_34;
	vector<wstring> vwchar_28(4);
	a1.get(vn_34);

	for (uint i = 0; i < vn_34.size(); i++)
	{
		if (iswalpha(vn_34[i]))
		{
			if (iswupper(vn_34[i])) vwchar_28[0].push_back(vn_34[i]);
			else vwchar_28[1].push_back(vn_34[i]);
		}
		else if (iswdigit(vn_34[i])) vwchar_28[2].push_back(vn_34[i]);
		else  vwchar_28[3].push_back(vn_34[i]);
	}

	a2[0].m_bCA_HasData_0 = 0x43;
	a2[1].m_bCA_HasData_0 = 0x63;
	a2[2].m_bCA_HasData_0 = 0x44;
	a2[3].m_bCA_HasData_0 = 0x53;

	for (int i = 0; i < 4; i++)
	{
		sort(vwchar_28[i].begin(), vwchar_28[i].end());
		string str_40 = common::UnicodeUtils::WStrToUtf8(vwchar_28[i]);
		str_40.push_back(0);
		a2[i].init(str_40);
	}

}

void CAlphabetManager::updatePartsStatus(CAlphabet *a1, vector<uchar>& a2)
{
	for (int i = 0; i != 4; ++i)
	{
		if (a1[i].m_bCA_HasData_0)
			a2[i] = 1;
	}
}
