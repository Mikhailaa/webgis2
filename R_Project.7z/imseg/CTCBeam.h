#pragma once


#include "Label2Unicodes.h"
#include "CTCHypoth.h"
#include "CTCBeamNode.h"
#include "TopResultSet.h"
#include "MergeRepeats.h"

namespace imseg
{
	class CTCBeam
	{
	public:
		CTCBeam(shared_ptr<IFieldMask> &, uint);
		//~CTCBeam();
		void deleteDuplicatePaths(list<shared_ptr<CTCBeamNode>> &);;
		void deleteLowProbPaths(list<shared_ptr<CTCBeamNode>> &);
		void deleteUnfinishedPathsIfFinishedPathExist();
		//draw(cv::Mat const&);
		bool empty();
		vector<CTCHypoth> getMostProbableSeq();
		void pushBackUpdatedNodes(shared_ptr<CTCBeamNode> &, float const*, int, Label2Unicodes const&, int, list<shared_ptr<CTCBeamNode>> &);
		void update(float const*, int, Label2Unicodes const&, int);


		float m_rCBCT_0;
		int m_nCBCT_field_4;
		shared_ptr<IFieldMask> m_sptr_CBCT_IFM_8;
		int m_nCBCT_Width_10;
		list<shared_ptr<CTCBeamNode>> m_lCTCB_sptrCTCB_14;
		shared_ptr<ICorrector> m_sptrCTCB_IC_20;
	};
}