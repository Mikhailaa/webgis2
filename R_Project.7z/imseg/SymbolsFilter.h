#pragma once
#include "imseg_interface.h"
#include "commonStruct.h"

class SymbolsFilter
{
public:
   static void filterByType(ISymbolsInfoByUnicode &,vector<int> &,eSymbolWidth,vector<int> &);
   static void filterByType(ISymbolsInfoByUnicode &,vector<int> &,eTails,eTails,vector<int> &);
   static void filterByType(ISymbolsInfoByUnicode &,vector<int> const&,eSymbolType,vector<int>&);
   static void symbolsType(ISymbolsInfoByUnicode &,vector<int> &,eSymbolType &);
   static void symbolsType(ISymbolsInfoByUnicode &,vector<int> &,eSymbolType &,eTails &);
};