#pragma once
#include "imseg_interface.h"
#include "CTCHypoth.h"

namespace imseg
{
	class DeleteSequentialSpaces : public ICorrector
	{
	public:
		static set<uint> m_canNotBeSequential;
		bool canNotBeSequential(uint);
		DeleteSequentialSpaces(ICorrector *);
		virtual void process_impl(vector<CTCHypoth> &);
	};
}