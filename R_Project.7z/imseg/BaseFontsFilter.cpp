#include "BaseFontsFilter.h"

vector<int> BaseFontsFilter::fontFilter(int arg1, int arg2)
{
	int i = 0;
	vector<int>::iterator iter = m_vSymbolFontFilter_4[arg1].m_vn_0.begin();
	while (iter != m_vSymbolFontFilter_4[arg1].m_vn_0.end())
	{
		if (*iter == arg2)
			return m_vSymbolFontFilter_4[arg1].m_vvn_C[i];
		iter++;
		i++;
	}
	return m_vSymbolFontFilter_4[arg1].m_vvn_C[i];
}

BaseFontsFilter::~BaseFontsFilter()
{
}
