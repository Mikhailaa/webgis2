#pragma once
class TLineAnalyzeFirst
{
public:
	float noiseLower;
	float noiseUpper;
	int stopHistogram;
	int m_n_C;
	int threshLineH;
	int maxAngle;
	int m_n_18;
	int m_n_1C;
	float m_r_20;
	float m_r_24;
	float m_r_28;
	float m_r_2C;
	float m_r_30;
	int m_n_34;
	float m_r_38;

	TLineAnalyzeFirst();
};