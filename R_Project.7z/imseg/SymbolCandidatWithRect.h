#pragma once
#include "pch.h"
#include "SymbolCandidat.h"
class SymbolCandidatWithRect
{
public:
	SymbolCandidat m_xSymCandidat_0;
	cv::Rect m_xRect_14;

	SymbolCandidatWithRect();
	SymbolCandidatWithRect(SymbolCandidat const&, cv::Rect const&);
	SymbolCandidatWithRect(SymbolCandidatWithRect const&);
	SymbolCandidatWithRect(SymbolCandidatWithRect&&);
	~SymbolCandidatWithRect();
	SymbolCandidatWithRect &operator=(SymbolCandidatWithRect&);
	SymbolCandidatWithRect &operator=(SymbolCandidatWithRect&&);
};