#include "SymbolFontFilter.h"

SymbolFontFilter::SymbolFontFilter()
	:m_vn_0()
	, m_vvn_C()
{
}

SymbolFontFilter::~SymbolFontFilter()
{
}
