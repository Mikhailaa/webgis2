#include "ParsedMask.h"
#include "imseg.h"

namespace imseg
{
	extern CharPlace Space;
	ParsedMask::ParsedMask()
	{
		m_bLineBreaksDoesNotMatter = false;
	}

	ParsedMask::ParsedMask(ParsedMask  &arg1)
		:m_bLineBreaksDoesNotMatter(arg1.m_bLineBreaksDoesNotMatter)
		,m_vvvCharPlace_4(arg1.m_vvvCharPlace_4)
		, m_vvCharPlace_10(arg1.m_vvCharPlace_10)
		, m_setn_FoundLCIDs_1C(arg1.m_setn_FoundLCIDs_1C)
		, m_vun_28(arg1.m_vun_28)
		, m_vsp_IFieldMasks_34(arg1.m_vsp_IFieldMasks_34)
		, m_umap_ns_40(arg1.m_umap_ns_40)
		, m_strStringMask_54(arg1.m_strStringMask_54)
	{
		
	}
	ParsedMask::~ParsedMask()
	{
	}

	void ParsedMask::addToSingleString(vector<vector<CharPlace>> arg1)
	{
		if (m_vvvCharPlace_4.empty())
			appendString(arg1);
		else
			m_vvvCharPlace_4[0].insert(m_vvvCharPlace_4[0].end(), arg1.begin(), arg1.end());
			
	}
	void ParsedMask::appendString(vector<vector<CharPlace>>& arg1)
	{
		m_vvvCharPlace_4.push_back(arg1);
	}
	vector<uint> imseg::ParsedMask::getAdditionalAlphabet() 
	{
		return vector<uint>(m_vun_28);
	}
	vector<shared_ptr<IFieldMask>>& ParsedMask::getFieldMasks() 
	{
		// TODO: insert return statement here
		return m_vsp_IFieldMasks_34;
	}

	set<uint> ParsedMask::getFoundLCIDs()
	{
		return m_setn_FoundLCIDs_1C;
	}

	vector<vector<CharPlace>> ParsedMask::getParsedMaskAnyWay(uint a2)
	{
		if (m_vvvCharPlace_4.size() > a2)
		{
			return m_vvvCharPlace_4[a2];
		}

		return m_vvCharPlace_10;
	}

	string ParsedMask::getStringMask()
	{
		return m_strStringMask_54;
	}
	void ParsedMask::setAdditionalAlphabet(vector<int>&arg1)
	{
		m_vun_28.insert(m_vun_28.end(), arg1.begin(), arg1.end());
	}
	void ParsedMask::setStringMask(string &arg1)
	{
		m_strStringMask_54 = arg1;
	}
	void ParsedMask::insertLCIDs(set<uint>&arg1)
	{
		set<uint>::iterator iter;
		for (iter = arg1.begin(); iter != arg1.end(); iter++)
			m_setn_FoundLCIDs_1C.insert(m_setn_FoundLCIDs_1C.begin(), *iter);
	}
	void ParsedMask::buildIFieldMask()
	{
		
		vector<vector<vector<CharPlace>>>::iterator iter = m_vvvCharPlace_4.begin();
		while (iter != m_vvvCharPlace_4.end())
		{
			vector<vector<CharPlace>> _vvCharPlace_34(*iter);
			shared_ptr<IFieldMask> _sp_IFieldMask_2C;
			
			if (_vvCharPlace_34.empty())
			{
				_sp_IFieldMask_2C = make_shared<FieldMaskArbitrarySymbols>();
			}
			else
			{
				vector<vector<CharPlace>>::iterator iter1 = _vvCharPlace_34.begin();
				while (iter1 != _vvCharPlace_34.end())
				{
					vector<CharPlace> _vCharPlace_34(*iter1);
					vector<CharPlace>::iterator iter2 = _vCharPlace_34.begin();
					while (iter2 != _vCharPlace_34.end())
					{
						if ((*iter2).isOptional())
						{
							_sp_IFieldMask_2C = make_shared<FieldMaskArbitrarySymbols>();
							goto LABEL_END;
						}
						iter2++;
					}

					iter1++;
				}

				_sp_IFieldMask_2C = buildMaskWithAlternative(_vvCharPlace_34[0]);
				for (size_t i = 1; i < _vvCharPlace_34.size(); i++)
				{
					shared_ptr<IFieldMask> spTmp = buildMaskWithAlternative(_vvCharPlace_34[i]);
					_sp_IFieldMask_2C = make_shared<FieldMaskLogicalOr>(_sp_IFieldMask_2C, spTmp);
				}
			}

			LABEL_END:
			m_vsp_IFieldMasks_34.push_back(_sp_IFieldMask_2C);
			iter++;
		}
	}
	shared_ptr<IFieldMask> ParsedMask::buildMaskWithAlternative(vector<CharPlace>&arg1)
	{
		shared_ptr<IFieldMask> res;
		vector<CharPlace> _vCharPlace_3C, _vCharPlace_30;
		for (size_t i = 0; i < arg1.size(); i++)
		{
			CharPlace _xCharPlace_14(arg1[i]);
			_vCharPlace_3C.push_back(_xCharPlace_14);
			if (!(_xCharPlace_14 == imseg::Space))
				_vCharPlace_30.push_back(_xCharPlace_14);
		}
		if (_vCharPlace_3C.size() == _vCharPlace_30.size())
			res = make_shared<imseg::FieldMaskConstrained>(_vCharPlace_3C);
		else
		{
			//auto _sp_C = make_shared<IFieldMask>(_vCharPlace_3C);
			shared_ptr<IFieldMask> _sp_C = make_shared<FieldMaskConstrained>(_vCharPlace_3C);
			//auto _sp_8 = make_shared<IFieldMask>(_vCharPlace_30);
			shared_ptr<IFieldMask> _sp_8 = make_shared<FieldMaskConstrained>(_vCharPlace_30);
			res = make_shared<FieldMaskLogicalOr>(_sp_C, _sp_8);
		}
		return res;
	}
	void ParsedMask::finalize()
	{
		buildIFieldMask();
	}
	bool ParsedMask::isBankCardName() 
	{
		return m_umap_ns_40.find(PROCESS_OPTION_14) != m_umap_ns_40.end();
	}

	bool ParsedMask::isBankCardNumber() 
	{
		return m_umap_ns_40.find(PROCESS_OPTION_12) != m_umap_ns_40.end();
	}

	bool ParsedMask::isBankCardValidThru() 
	{
		return m_umap_ns_40.find(PROCESS_OPTION_13) != m_umap_ns_40.end();
	}

	bool ParsedMask::isLineBreaksDoesNotMatter() 
	{
		return m_bLineBreaksDoesNotMatter;
	}
}