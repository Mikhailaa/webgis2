﻿#include "fieldpreprocess.h"
#include "docinfo.h"
#include "regula.h"
#include "rcvmat.h"
#include "imseg.h"
#include "TextStructManager.h"
#include "imagemanipulation.h"
#include "rclhelp.h"
#include "RCv.h"
#include "imseg_rect.h"

using namespace imseg::docinfo;
using namespace regula::light;

void sub_4D12D8(cv::Mat const&arg1, int arg2, int arg3, cv::Mat &arg4)
{
	int v7 = arg3;
	if (arg1.empty())
		return;

	if (arg3 < 1 || arg1.size().height / 2 <= arg3)
		v7 = 30;
	else
	{
		if (arg1.size().width / 2 <= arg3)
			v7 = 30;
	}
	int v10 = 0, v11 = 0, v12 = 0, v13 = 0, v54 = 0;
	switch (arg2 - 1)
	{
	case 0:
	case 3:
		v54 = 7 * v7 / 2;
		v12 = v54 % 2 + v54;
		v11 = v12 / 2;
		v13 = 1;
		v10 = 0;
		break;
	case 1:
	case 7:
		v11 = 1;
		v13 = 2 * v7 | 1;
		v12 = 3;
		v10 = v7;
		break;
	case 2:
	case 4:
	case 5:
	case 6:
		break;
	default:
		break;
	}

	Size _Size_58(v12, v13);
	Point _Point_50(v11, v10);
	Mat _Mat_148 = getStructuringElement(0, _Size_58, _Point_50);
	Mat _Mat_110, _Mat_D8, _Mat_60;
	morphologyEx(arg1, _Mat_110, 3, _Mat_148);
	bitwise_not(_Mat_110, _Mat_D8);
	Scalar _Scalar_B8, _Scalar_98;
	meanStdDev(_Mat_D8, _Scalar_B8, _Scalar_98);
	subtract(_Mat_D8, _Scalar_B8, _Mat_60);
	add(_Mat_60, arg1, arg4);
}

int lineDeleter(cv::Mat const&Mat_a1, int nlinesType_a2, int n_a3, cv::Mat& Mat_a4)
{
	bool v8 = 0;
	Mat MatV10;
	int nV11;
	if (Mat_a1.empty())
		return -1;
	if (nlinesType_a2 <= 0xC)
	{
		v8 = ((1 << nlinesType_a2) & 0x12) == 0;
		if (v8)
			v8 = ((1 << nlinesType_a2) & 0x104) == 0;
		if (v8)
		{
			v8 = ((1 << nlinesType_a2) & 0x1008) == 0;
			if (v8)
				return 0;
			sub_4D12D8(Mat_a1, 1, n_a3, Mat_a4);
			MatV10 = Mat_a4;
			nV11 = 2;
		}
		else
		{
			MatV10 = Mat_a1;
			nV11 = nlinesType_a2;
		}
		sub_4D12D8(MatV10, nV11, n_a3, Mat_a4);
	}
	return 0;
}

namespace imseg
{

	namespace fieldpreprocess
	{
		namespace base
		{
			int process(TResultContainerList &xRcl_a1, TVisualField &xVisualField_a2, FieldImages &xFieldImage_a3, float r_a4, int *pn_a5, vector<cv::Rect>& vRect_a6)
			{
				eRPRM_Lights nLightType;
				RclHolder xRclH;
				TRawImageContainer *pTRawImageContainer = NULL;
				vector<eRPRM_Lights> veLights;
				FieldParam xFieldParam;

				xRclH.addNoCopy(xRcl_a1);
				nLightType = getLightType(xVisualField_a2);
				if (!(pTRawImageContainer = findImageUsingLightGroup(xRcl_a1, nLightType, 0, 0, 0)))
				{
					veLights = irGroup();
					if (contains(veLights, (eRPRM_Lights)xVisualField_a2.nTVF_lightType))
						pTRawImageContainer = findImageUsingLightGroup(xRcl_a1, RPRM_Lights_6, 0, xVisualField_a2.xTVF_ProcParams.nTPP_TypeResultColor < 2, 0);
					if (!pTRawImageContainer) return 1;
				}

				Mat xImage = RCvMat::ref(*(RawImageContainerR*)pTRawImageContainer);
				Rect rect;
				rect.x = MAX(0, xVisualField_a2.xTVF_Region.left);
				rect.y = MAX(0, xImage.rows - xVisualField_a2.xTVF_Region.bottom);
				rect.width = MIN(xVisualField_a2.xTVF_Region.right, xImage.cols) - rect.x;
				rect.height = MIN(xImage.rows - xVisualField_a2.xTVF_Region.top, xImage.rows) - rect.y;

				if (rect.width > 0 && rect.height > 0)
				{
					Mat xRectImage(xImage, rect);
					if (xRectImage.rows * r_a4 && xRectImage.cols * r_a4)
					{
						Mat xMat(xRectImage);
						if (xRectImage.flags & 0xFF8)
						{
							string strMask(xVisualField_a2.szTVF_Mask);
							//카드양식화일에서 mask가 입력됨
							//"{_@DNN@}DD",0
							//"{_@DNN@}{TEXT}"
							//"{_@DNN@}{C}{C}{C}{W_GBR}{W_GBR}{D}{D}{D}{D}{D}{D}{W}{W}{W}{W}{W}"
							//"{_@DNN@}{TEXT}"
							//"{_@DNN@}{DAY}.{MONTH_DD}.{YEAR}",0
							//"{_@DNN@}{DAY}.{MONTH_DD}.{YEAR}",0
							//"{_@DNN@}{DAY}.{MONTH_DD}.{YEAR}",0
							//"{_@DNN@}{Surname_ENG}", 0
							//"{_@DNN@}{Given_Name_ENG}",0
							//"{_@DNN@}{STRINGS}",0
							//"{_@DNN@}{TEXT_NOSEM}",0
							TextStructManager::getParamFromMask(strMask, xFieldParam.m_umap_FP_4);

							if (xFieldParam.contain(PROCESS_OPTION_9))
							{
								toGrayColorRemove(xRectImage, xMat);
							}
							else
							{
								imagemanipulation::convertImage24to8ByFieldDesc(xRectImage, xMat, xVisualField_a2.xTVF_ProcParams.nTPP_TypeResultColor);
							}
						}
						if (xMat.empty()) return 1;

						Mat resizedImage;
						resize(xMat, resizedImage, Size(int(xRectImage.cols * r_a4), int(xRectImage.rows * r_a4)), 0.0f, 0.0f, 3);
						if (!xVisualField_a2.xTVF_ProcParams.nTPP_Positive)
						{
							Scalar_<double> CvScalar = Scalar_<double>::all(255.0);
							Mat m = CvScalar - resizedImage;
							//가상함수호출 디바그로 확인!
						}

						vRect_a6 = imseg::bindrects::getBindRectsForRemove(xRclH);
						Rect _xRect_50 = imseg::rect::scale(rect, r_a4);
						///////////////////////////////////
						xFieldImage_a3.m_xRect_0 = rect;
						xFieldImage_a3.m_xRect_10 = _xRect_50;
						Mat _Mat_140;
						RCvMat::rotate_90n(resizedImage, _Mat_140, -90 * int(float((xVisualField_a2.xTVF_ProcParams.rTPP_Orientation) / 90.0f)));

						Mat _Mat_108;
						if (xVisualField_a2.xTVF_ProcParams.sTPP_AutoSwitchIRtoWHITE)
							lineDeleter(_Mat_140, xVisualField_a2.xTVF_ProcParams.sTPP_AutoSwitchIRtoWHITE, int((float)xVisualField_a2.xTVF_Font.m_nFF_HeightAbs * r_a4), _Mat_108);
						else
							_Mat_140.copyTo(_Mat_108);

						CBufferImage _CBufferImage_D0;
						if (ushort(xVisualField_a2.xTVF_ProcParams.sTPP_AutoSwitchIRtoWHITE - 1) > 2)
							RCv::ref(_Mat_140, _CBufferImage_D0);
						else
							RCv::ref(_Mat_108, _CBufferImage_D0);

						//char szNaem[256] = "";
						//static int k = 0;
						//sprintf(szNaem, "C:\\TMP\\Field_%2d.bmp", k++);
						//imwrite(szNaem, _Mat_108);

						
						xFieldImage_a3.m_vCBufImg_20[0].load(_CBufferImage_D0);
						xFieldImage_a3.m_vCBufImg_20[2].ref(xFieldImage_a3.m_vCBufImg_20[0]);
						Mat _Mat_D0;
						cv::blur(_Mat_108, _Mat_D0, Size(3, 3));
						xFieldImage_a3.m_vCBufImg_20[1].create(xFieldImage_a3.m_vCBufImg_20[2].width(), xFieldImage_a3.m_vCBufImg_20[2].height(), 8, 1);
						Mat _Mat_98 = RCvMat::ref(xFieldImage_a3.m_vCBufImg_20[1]);
						normalize(_Mat_D0, _Mat_98, 0.0f, 255.0f, 0x20);

						if (pn_a5)
						{
							if (pTRawImageContainer)
								*pn_a5 = pTRawImageContainer->pxRIC_bmi->bmiHeader.biSizeImage;
							else
								*pn_a5 = 0;
						}
					}
				}

				return 0;
			}
		}

		int process(TResultContainerList &xRcl_a1, TVisualField &xVisualField_a2, FieldImages &xFieldImage_a3, float r_a4, vector<cv::Rect>& vRect_a6, int *pn_a5)
		{
			return base::process(xRcl_a1, xVisualField_a2, xFieldImage_a3, r_a4, pn_a5, vRect_a6);
		}
		void removeRectsFromImage(vector<cv::Rect> &arg1, float arg2, Field& arg3)
		{
			Rect _xRect_4, _xRect_30;
			Mat _xMat_30;
			vector<cv::Rect> _vRect_24;
			_vRect_24 = imseg::rect::scale(arg1, arg2);
			for (size_t i = 0; i < _vRect_24.size(); i++)
			{
				_xRect_4 = _vRect_24[i] & arg3.m_xFieldImages_20.m_xRect_10;
				if (_xRect_4.width >= 1 && _xRect_4.height >= 1)
				{
					for (int j = 0; j <= 4; j++)
					{
						IImageControlRef *v12 = &arg3.m_xFieldImages_20.m_vCBufImg_20[j];
						if ((CBufferImage *)v12->width())
						{
							_xMat_30 = RCvMat::ref(*v12);
							int angle = (int)arg3.m_pCVisualF_70->getProcParams().rTPP_Orientation;
							if (angle != 0)
								RCvMat::rotate_90n(_xMat_30, _xMat_30, angle);
							removeRects(_xMat_30, arg3.m_xFieldImages_20.m_xRect_10, _vRect_24, _xMat_30);
							angle = (int)arg3.m_pCVisualF_70->getProcParams().rTPP_Orientation;
							if (angle != 0)
							{
								RCvMat::rotate_90n(_xMat_30, _xMat_30, 360 - angle);
								CBufferImage v16;
								_xMat_30 = RCvMat::ref(v16);
								arg3.m_xFieldImages_20.m_vCBufImg_20[j].load(v16);
							}
						}
					}
				}
			}
		}

		void removeRects(cv::Mat const &arg1, Rect const &arg2, vector<cv::Rect> const &arg3, cv::Mat &arg4)
		{
			Rect _xRect_10, _xRect_20;
			arg1.copyTo(arg4);
			for (size_t i = 0; i < arg3.size(); i++)
			{
				_xRect_20 = arg3[i];
				_xRect_10 = _xRect_20 & arg2;
				_xRect_20 = _xRect_10;
				if (_xRect_10.width >= 1 && _xRect_10.height >= 1)
				{
					_xRect_20.y = _xRect_10.y - arg2.y;
					_xRect_20.x = _xRect_10.x - arg2.x;
					setDark(_xRect_20, arg4);
					blurBorders(_xRect_20, arg1, arg4);
				}
			}
		}

		void setDark(Rect const &arg1, cv::Mat &arg2)
		{
			int v20 = 0, v21 = 0, v22 = 0;
			int v3, v4;
			float _r_4C = 0;
			vector<int> _vn_5C;
			Mat _Mat_E4(arg2, arg1);
			Mat _Mat_AC;
			Scalar _Scalar_68, _Scalar_88;

			if (!_Mat_E4.empty())
			{
				rcvmat::RCVMat::calcHist(_Mat_E4, _vn_5C, 256, 0, 256);
				v3 = _Mat_E4.total();
				v4 = _Mat_E4.total();
				rcvmat::RCVMat::dynamicRange(_vn_5C, (int)(v3 * 0.001f), (int)(v4 * 0.01f), v22, v21, v20);
				rcvmat::RCVMat::histCenter(_vn_5C, _r_4C, (v22 + v20 / 2), 256);
				inRange(_Mat_E4, _Scalar_88, _Scalar_68, _Mat_AC);
				_Scalar_88[0] = _r_4C;
				_Mat_E4.setTo(_Scalar_88, _Mat_AC);
			}
		}

		void blurBorders(Rect const &arg1, cv::Mat const &arg2, cv::Mat &arg3)
		{
			Rect base(-3, -3, 6, 6);
			Rect _Rect_50(base.x + arg1.x, base.y + arg1.y, base.width + arg1.width, base.height + arg1.height);
			Rect _Rect_40(0, 0, arg2.size().width, arg2.size().height);
			_Rect_50 = _Rect_50 & _Rect_40;
			Mat _Mat_60(arg3, _Rect_50);
			if (_Mat_60.rows && _Mat_60.cols)
			{
				Size _Size_18(3, 3);
				GaussianBlur(_Mat_60, _Mat_60, _Size_18, 0);
			}
		}

		void toGrayColorRemove(cv::Mat &arg1, cv::Mat &arg2)
		{
			cv::Mat v95;
			cv::Mat v87;
			cv::Mat v79;
			cv::Mat v3;
			vector<cv::Mat> v46;
			cv::Scalar v78;
			cv::Size szV0(25, 25);
			cv::Size szV1(3, 3);
			vector<int> vHist;

			cv::cvtColor(arg1, v95, 40, 0);
			cv::split(v95, v46);
			cv::GaussianBlur(v46[2], v87, szV0, 0.0);
			v78 = cv::mean(v87);
			cv::subtract(v87, v78, v87);
			cv::subtract(v46[2], v87, v79);
			cv::blur(v79, v3, szV1);
			rcvmat::RCVMat::calcHist(v3, vHist, 256, 0, 256);

			int n1 = 0, n2 = 0, n3 = 0;
			rcvmat::RCVMat::dynamicRange(vHist, (int)(v3.total() * 0.001f), (int)(v3.total() * 0.01f), n1, n2, n3);

			float r1 = 0.0f;
			rcvmat::RCVMat::histCenter(vHist, r1, n1 + n3 / 2, 256);

			cv::Scalar v62(0, 0), v58(0, 0);
			cv::Mat m62;
			cv::inRange(v95, v62, v58, m62);

			v3.setTo(v62, m62);

			cv::Mat m60;
			cv::inRange(v3, v62, v58, m60);

			cv::Mat m48;
			cv::erode(m60, m60, m48);

			cv::Mat m28;
			arg2.copyTo(m28);

			m28.setTo(cv::Scalar(r1, r1), m60);
			cv::cvtColor(m28, arg2, 6);

		}
	}
}