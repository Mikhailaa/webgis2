#pragma once
class SymbolCandidat
{
public:
	SymbolCandidat();
	SymbolCandidat(SymbolCandidat const&);
	SymbolCandidat(int, float, int, int, int);
	~SymbolCandidat();
	SymbolCandidat &operator=(SymbolCandidat&);

	int m_wszCandiateCharacter_0;//wchar
	float m_rProv_4;
	int field_8;
	int field_C;
	int field_10;
};