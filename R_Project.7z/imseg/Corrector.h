#pragma once
#include "imseg_interface.h"
#include "MergeRepeats.h"
#include "VocabCorrector.h"
#include "RichTextLines.h"

namespace imseg
{
	class Corrector : public ITextLinesVisitor
	{
	public:
		Corrector(uint const&, vector<shared_ptr<IFieldMask>> const&, FieldParam &);
		~Corrector() {};
		virtual void visit(RichTextLines &);

		void calcXOnImageOf(float const &, vector<imseg::CTCHypoth> &);
		void correctLogicaly(shared_ptr<imseg::ICorrector> &, vector<imseg::CTCHypoth> &);
		bool replaceFirstUnConfidentNullsBySecondCandidate(vector<imseg::CTCHypoth> &, vector<vector<imseg::CTCHypoth>> &);
		vector<vector<imseg::CTCHypoth>> replaceUnConfidentNullsBySecondCandidate(vector<imseg::CTCHypoth> const &);

	public:
		int m_nField_4;
		VocabCorrector *m_pVIC_8;
		vector<int> m_vnCr_C;
		vector<shared_ptr<ICorrector>> m_vspCr_IC_18;
		shared_ptr<MergeRepeats> m_spCr_IC_24;
	};
}