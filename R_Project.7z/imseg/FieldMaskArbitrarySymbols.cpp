#include "FieldMaskArbitrarySymbols.h"
using namespace imseg;


FieldMaskArbitrarySymbols::FieldMaskArbitrarySymbols()
{
}

FieldMaskArbitrarySymbols::~FieldMaskArbitrarySymbols()
{
}

void FieldMaskArbitrarySymbols::setPreviousPath(vector<CTCHypoth, allocator<CTCHypoth>> const &)
{
}

bool FieldMaskArbitrarySymbols::isUnicodePossible(uint)
{
	return true;
}

int FieldMaskArbitrarySymbols::getBeamWidth()
{
	return 1;
}

bool FieldMaskArbitrarySymbols::isAllSymbolsFound(vector<CTCHypoth> const &)
{
	return true;
}

bool FieldMaskArbitrarySymbols::doNotDeleteSymbolsAfterMe()
{
	return false;
}
