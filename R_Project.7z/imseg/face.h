#pragma once
//#include "../../common/all/Json.h"
#include "../json/Value.h"
#include "../commonStruct.h"

namespace procmgr {

	namespace face {

		void printFacePosition(Json::Value &);
		void rotateFaceMetadata(Json::Value &, eRPRM_Orientation, tagSIZE const&);
	}
}
