#include "description.h"
#include "rclhelp.h"
#include "legacycommonlib.h"

using namespace legacycommonlib::jsoncpp;
using namespace legacycommonlib;
using namespace imseg::description;

namespace imseg
{
	namespace ocrfree
	{
		bool updateDescByImageParam(common::container::RclHolder &arg1, CDocInfo *arg2)
		{
			tagSIZE _tagSIZE_0;
			int a3 = 0;
			bool res = 0;
			rclhelp::imageParameters(arg1.m_xTRCL, a3, _tagSIZE_0);
			if (arg2 && _tagSIZE_0.cx && _tagSIZE_0.cy)
			{
				TVisualField *_pCVisualField = arg2->get(0);
				_pCVisualField->xTVF_Region.left = 0;
				_pCVisualField->xTVF_Region.top = 0;
				_pCVisualField->xTVF_Region.right = _tagSIZE_0.cx;
				_pCVisualField->xTVF_Region.bottom = _tagSIZE_0.cy - 1;
				_pCVisualField->xTVF_Font.m_nFF_HeightAbs = int(_tagSIZE_0.cy * 0.3);
			}
			else
				res = 1;
			return res;
		}
	}

	namespace description
	{
		bool getDocInfo(RclHolder &arg1, string const &arg2, description::DocDescObj &arg3, int arg4, legacycommonlib::FieldsLoadFilter *arg5)
		{
			bool res = legacycommonlib::jsoncpp::tryToGetDocInfo(arg1, arg2.data(), arg3.m_xJsonValue_8, &arg3.m_pDocInfo_0);
			if (!res)
			{
				if (!arg3.m_pDocInfo_0)
				{
					if (arg3.m_xJsonValue_8.isMember("document"))
					{
						arg3.m_spCDocInfo_20 = make_shared<CDocInfo>();
						Json::Value v18 = arg3.m_xJsonValue_8["document"];
						legacycommonlib::jsoncpp::convert(v18, *arg3.m_spCDocInfo_20.get(), arg5);
						arg3.m_pDocInfo_0 = arg3.m_spCDocInfo_20.get();
						int v20 = arg3.m_pDocInfo_0->id();
						if (v20 == 1)
							ocrfree::updateDescByImageParam(arg1, arg3.m_pDocInfo_0);
						else
							Base::updateImgParams(arg1, arg3.m_pDocInfo_0);
					}
					if (arg3.m_pDocInfo_0 == 0)
						return 1;
				}
				int v23 = rclhelp::docdesc::docID(*arg3.m_pDocInfo_0, arg3.m_xJsonValue_8);
				arg3.field_28 = v23;
				if (!v23)
					return 1;
				if (arg4 && v23 != arg4)
				{
					//Log "ImSeg.dll", "ImSegNS::ProcessCommand::ePC_Process Change docID in one series!"
					return 1;
				}
				//Log "ImSeg.dll", "ImSegNS::ProcessCommand::ePC_Process doc info: field count = "
				Base::updateDocInfoWithBind(arg1, arg2.data(), *arg3.m_pDocInfo_0);
				res = 0;
			}
			return res;
		}

		DocDescObj::DocDescObj()
			: m_xJsonValue_8(0)
			, m_spCDocInfo_20()
		{
			m_pDocInfo_0 = 0;
			field_28 = 0;
		}
		DocDescObj::~DocDescObj()
		{
		}
	}
}