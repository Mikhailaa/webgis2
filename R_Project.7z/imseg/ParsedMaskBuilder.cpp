#include "ParsedMaskBuilder.h"
#include "RSubFieldManager.h"
#include "common/UnicodeUtils.h"

namespace imseg
{
	void ParsedMaskBuilder::buildParsedMask(ParsedMask &res,Field &arg1, string strMask, uint nLinesCount)
	{
		set<uint> _setun_11C;
		wstring _ws_110, _ws_38;
		res.m_umap_ns_40 = arg1.m_xFieldParam_4.m_umap_FP_4;

		for (size_t i = 0; i < arg1.m_vnLcid_A0.size(); i++)
			_setun_11C.emplace(arg1.m_vnLcid_A0[i]);

		_ws_110 = UnicodeUtils::Utf8ToWStr(strMask);
		_ws_38 = MaskStringUtils::stripMask(_ws_110, _setun_11C);
		_ws_110.clear();
		_ws_110 = _ws_38;
		map<wstring, SubField> *_pmap_wsSubField = RSubFieldManager::getName2SubfieldMap();
		map<wstring, SubField> _map_wsSubField_104;
		map<wstring, SubField>::iterator iter;
			
		for (iter = _pmap_wsSubField->begin(); iter != _pmap_wsSubField->end(); iter++)
			_map_wsSubField_104.insert(_map_wsSubField_104.end(), *iter);
		wstring _ws_F8(_ws_110);
		bool v15 = isLineBreaksDoNotMatter(_ws_F8);
		if (v15)
			res.m_bLineBreaksDoesNotMatter = true;
			
		vector<vector<vector<TextPartStruct>>> _vvvTextPartStruct_EC = processMultistringness(arg1, nLinesCount);
		vector<vector<CharPlace>> _vvCharPlace_D4;
		for (size_t i = 0; i < _vvvTextPartStruct_EC.size(); i++)
		{
			vector<vector<TextPartStruct>> _vvTextPartStruct_E0(_vvvTextPartStruct_EC[i]);
			for (size_t j = 0; j < _vvTextPartStruct_E0.size(); j++)
			{
				vector<CharPlace> _vCharPlace_BC;
				vector<TextPartStruct> _vTextPartStruct_C8(_vvTextPartStruct_E0[j]);
				for (size_t k = 0; k < _vTextPartStruct_C8.size(); k++)
				{
					TextPartStruct _xTextPartStruct_38(_vTextPartStruct_C8[k]);
					vector<CharPlace> _vCharPlace_2C = Mask2CharPlaces::buildCharPlacesFrom(_map_wsSubField_104, _xTextPartStruct_38, _setun_11C);
					_vCharPlace_BC.insert(_vCharPlace_BC.end(), _vCharPlace_2C.begin(), _vCharPlace_2C.end());
				}
				_vvCharPlace_D4.push_back(_vCharPlace_BC);
			}
			if (v15)
			{
				vector<vector<CharPlace>> _vvCharPlace_20(_vvCharPlace_D4);
				res.addToSingleString(_vvCharPlace_20);
			}
			else
				res.appendString(_vvCharPlace_D4);
		}
		res.insertLCIDs(_setun_11C);
		res.setStringMask(strMask);
		res.setAdditionalAlphabet(arg1.m_xCAlphaF_74.m_vAlphabet_0);
		res.finalize();
	}

	bool ParsedMaskBuilder::isLineBreaksDoNotMatter(wstring arg1)
	{
		int v6 = arg1.find(L"STRINGS");
		int v15 = arg1.find(L"TEXT");
		int v17 = arg1.find('^');

		return (v6 != string::npos && v6 != 0) && ((v15 == string::npos) || (v17 == string::npos));
	}
}