#pragma once
#include <unordered_map>
#include "pch.h"
#include "imseg_interface.h"

struct SymbolInfo
{
	int nField_0;
	int nField_4;
	int nField_8;
};

class SymbolsInfoByUnicode : public ISymbolsInfoByUnicode
{
public:
	//vft_0
	unordered_map<int, SymbolInfo> m_uomap_nSymbolInfo_4;
	unordered_map<int, unordered_map<int, SymbolFontParam>> m_uomap_nuomap_nSymbolFontParam_18;

	SymbolsInfoByUnicode();
	virtual  ~SymbolsInfoByUnicode();
	virtual int type(int);
	virtual int wType(int);
	virtual int tailType(int);
	virtual void getkWHInfo(int, int, SymbolFontParam &);
	bool isCorrectInx(int);
};