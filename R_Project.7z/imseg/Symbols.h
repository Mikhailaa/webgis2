#pragma once
#include <map>
#include "pch.h"
#include "AlphabetInfo.h"
#include "BaseFontsFilter.h"
#include "SymbolsInfoByUnicode.h"
#include "ConflictGroups.h"

#include "Json/Value.h"

class SymbolsIndexMap : public set<int>, public ISymbolsIndexMap
{
public:
	int index(int);
};

class BaseConflictGroups : public IBaseConflictGroups,public vector<ConflictGroups>
{
public:
	virtual ConflictGroups& getConflictGroup(int, int, vector<int> &);
};

class Symbols : public SymbolsIndexMap
{
public:
	map<int, int> m_mapnn_4;
	AlphabetInfo m_xAlphabetInfo_10;
	BaseConflictGroups m_xBaseConflictGroups_2C;
	BaseFontsFilter m_xBaseFontsFilter_3C;
	SymbolsInfoByUnicode m_xSymbolsInfoByUnicode_4C;

	Symbols();
	~Symbols();
	void reset();
};


class SymbolInfoEx : public ISymbolsInfoEx
{
public:
	virtual AlphabetInfo& alphabetInfo();
	virtual SymbolsInfoByUnicode&  symbolsInfo();
public:
	//int m_nField_0;vft
	Symbols *m_pSymbols_4;
};

namespace SymbolBaseLoad
{
	int load(Json::Value&, Json::Value&, Symbols&);
	void readCodePages(Json::Value& a2, set<int>& a3, Symbols& a4);
	void readLCIDs(Json::Value& a1, AlphabetInfo& a2);
};