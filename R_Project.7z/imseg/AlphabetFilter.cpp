#include "AlphabetFilter.h"

uchar CAlphabetFilter::mask(char)
{
	return 0;
}
