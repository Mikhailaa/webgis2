#include "CharPlace.h"

namespace imseg
{
	CharPlace::CharPlace()
	{
	}

	CharPlace::CharPlace(CharPlace const&arg1)
		:m_setun_0(arg1.m_setun_0)
		, m_setun_C(arg1.m_setun_C)
	{
		m_nCharPlaceType_18 = arg1.m_nCharPlaceType_18;
	}

	CharPlace::CharPlace(set<uint> const&arg1, set<uint> const&arg2, imseg::CharPlace::CharPlaceType arg3)
		:m_setun_0(arg1)
		, m_setun_C(arg2)
	{		
		m_nCharPlaceType_18 = arg3;
	}

	CharPlace::~CharPlace()
	{		
	}
	set<uint>& CharPlace::getPossibleUnicodes()
	{
		// TODO: insert return statement here
		return m_setun_0;
	}
	CharPlace &CharPlace::operator=(const CharPlace &arg1)
	{
		m_setun_0 = arg1.m_setun_0;
		m_setun_C = arg1.m_setun_C;
		m_nCharPlaceType_18 = arg1.m_nCharPlaceType_18;
		return *this;
	}
	bool CharPlace::operator==(CharPlace &arg1)
	{
		return (m_setun_0 == arg1.m_setun_0 && m_setun_C == arg1.m_setun_C);
	}
	bool CharPlace::isOptional()
	{
		return (m_nCharPlaceType_18 != CHARPLACETYPE_3 && m_nCharPlaceType_18 != CHARPLACETYPE_0);
	}
	bool CharPlace::isTrash()
	{
		return (m_nCharPlaceType_18 | CHARPLACETYPE_1) == CHARPLACETYPE_3;
	}

	bool CharPlace::is_possible(uint arg1)
	{
		if (m_setun_0.size())
			return m_setun_0.end() != m_setun_0.find(arg1);
		if (m_setun_C.size())
			return m_setun_C.end() != m_setun_C.find(arg1);
		return 1;
	}

	void CharPlace::makeObligatory(void)
	{
		if (m_nCharPlaceType_18 == CHARPLACETYPE_1)
		{
			m_nCharPlaceType_18 = CHARPLACETYPE_0;
		}
		else
		{
			if (m_nCharPlaceType_18 != CHARPLACETYPE_2)
				return;
			m_nCharPlaceType_18 = CHARPLACETYPE_3;
		}
	}


}