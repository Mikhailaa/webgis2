#pragma once
#include "pch.h"
#include "common/resources.h"
#include "common/container/container.h"
#include "common/container/RclHolder.h"
#include "Json/Value.h"

using namespace common;
using namespace common::resources;
using namespace common::container;

extern wchar_t *dword_112A1D4;

namespace imseg
{
	class MaskStringUtils
	{
	public:
		//count(std::__ndk1::basic_string<wchar_t,std::__ndk1::char_traits<wchar_t>,std::__ndk1::allocator<wchar_t>> const&,std::__ndk1::basic_string<wchar_t,std::__ndk1::char_traits<wchar_t>,std::__ndk1::allocator<wchar_t>> const&) No Xref		
		static bool deleteAllBeetween(wstring &, wchar_t, wchar_t, wstring &);
		static void deleteAllLcidsAndFieldTypes(wstring &, set<uint> &);
		static int replaceAmpersandByWild(wstring &);
		static void replaceSubstring(wstring &, wstring &, wstring &);// __search_substring
		static void splitStrBy(vector<wstring> &, wstring &, wchar_t);
		static wstring stripMask(wstring const&, set<uint> &);		
		
		static wchar_t removableChars;
	};
}
