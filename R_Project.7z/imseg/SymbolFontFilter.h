#pragma once
#include "pch.h"

class SymbolFontFilter
{
public:
	vector<int> m_vn_0;
	vector<vector<int>> m_vvn_C;

	SymbolFontFilter();
	~SymbolFontFilter();
};