#include "ReplaceMultiNullBySpace.h"
#include "imseg/HParam.h"
#include "MergeRepeats.h"
#include "CTCHypoth.h"

imseg::ReplaceMultiNullBySpace::ReplaceMultiNullBySpace(int n_a1, ICorrector*pICorrector)
{
	m_pIC_4 = pICorrector;
	m_nReplaceMultiNullBySpace_8 = n_a1;
	string _s_0("m_sigmaCoeff");
	HParam::HParam(m_rReplaceMultiNullBySpace_C, _s_0, n_a1);
	_s_0 = string("m_sigmaCoeff2");
	HParam::HParam(m_rReplaceMultiNullBySpace_10, _s_0, n_a1);
}

imseg::ReplaceMultiNullBySpace::~ReplaceMultiNullBySpace()
{
}

float sub_4C1016(list<float> rlst, int pos)
{
	list<float>::iterator iter;
	if (pos > -1)
	{
		iter = rlst.begin();
		while (pos >= 1)
		{
			iter++;
			pos--;
		}
	}
	else
	{
		iter = rlst.end();
		while (pos <= -1)
		{
			iter--;
			pos++;
		}
	}
	return *iter;
}

void imseg::ReplaceMultiNullBySpace::calcDistsBtwSymbols(vector<CTCHypoth>&vCTCHypoth, float &r_1, float &r_2)
{
	vector<float> _vr_20;
	size_t i;
	int _nTmp_v7 = 0;
	r_1 = 0.0f;
	r_2 = 0.0f;
	for (i = 0; i < vCTCHypoth.size() - 1; i++)
	{
		if (vCTCHypoth[i].getUnicode() != 0x10FFFF)
		{
			_nTmp_v7++;
			if (vCTCHypoth[i].getUnicode() != vCTCHypoth[i + 1].getUnicode())
			{
				_vr_20.push_back(i + _nTmp_v7 * 0.5f);
				_nTmp_v7 = 0;
			}
		}
	}
	if (vCTCHypoth.back().getUnicode() != 0x10FFFF)
		_vr_20.push_back(i + (_nTmp_v7 + 1) * 0.5f);
	if (_vr_20.size() >= 3)
	{
		list<float> _rlst_14(_vr_20.size() - 1);
		list<float>::iterator iter;
		int j = 0;
		for (iter = _rlst_14.begin(); iter != _rlst_14.end(); iter++)
		{
			(*iter) = _vr_20[j + 1] - _vr_20[j];
			j++;
		}
		_rlst_14.sort();
		int fTmpSize = _rlst_14.size() > 0;
		float rTmp1 = sub_4C1016(_rlst_14, _rlst_14.size() - fTmpSize - 1);
		float rTmp2 = sub_4C1016(_rlst_14, fTmpSize);
		r_2 = rTmp1 - rTmp2;
		r_1 = sub_4C1016(_rlst_14, _rlst_14.size() >> 1);
	}
}

bool sub_4C1068(imseg::CTCHypoth& xCTCHypoth)
{
	return xCTCHypoth.getUnicode() != 0x10FFFF;
}

void imseg::ReplaceMultiNullBySpace::process_impl(vector<CTCHypoth>&vCTCHypoth)
{
	if (vCTCHypoth.size() < 2)
		return;
	auto _spMergeRepeats_50 = make_shared<MergeRepeats>(false, nullptr);
	_spMergeRepeats_50.get()->process(vCTCHypoth);
	float _r_74, _r_78;
	calcDistsBtwSymbols(vCTCHypoth, _r_78, _r_74);
	if (_r_78 == 0.0f)
		return;
	int v3 = max(int(_r_78 * m_rReplaceMultiNullBySpace_10), 1);
	int v9 = max(int(_r_78 * m_rReplaceMultiNullBySpace_C), 1);
	int v2 = v9 + (int)_r_78;
	if (v2 < 2)
		return;
	CTCHypoth _xCTCHypoth_50;
	_xCTCHypoth_50.field_0 = 0x10FFFF;
	_xCTCHypoth_50.m_wcUnicode_4 = 0x10FFFF;
	_xCTCHypoth_50.field_8 = -1;
	_xCTCHypoth_50.m_fcalcX_10 = 0.0;
	_xCTCHypoth_50.m_fHandmade_14 = 1.0;
	vector<CTCHypoth> _vCTCHypoth_44(v2, _xCTCHypoth_50);
	vector<CTCHypoth> _vCTCHypoth_38(v2 + v3, _xCTCHypoth_50);
	vector<CTCHypoth>::iterator iter1, iter2, search_pos1, search_pos2;
	for (iter1 = vCTCHypoth.begin(); iter1 != vCTCHypoth.end() && !sub_4C1068(*iter1); iter1++) {}
	for (iter2 = vCTCHypoth.end(); iter2 != vCTCHypoth.begin(); ) {
		iter2--;
		if (sub_4C1068(*iter2))
		{
			iter2++;
			break;
		}
	}
	while (iter1 != iter2)
	{
		iter1 = search(iter1, iter2, _vCTCHypoth_44.begin(), _vCTCHypoth_44.end());
		if (iter1 != iter2)
		{
			search_pos2 = search(iter1, iter2, _vCTCHypoth_38.begin(), _vCTCHypoth_38.end());
			int nTmp_v3 = 0;
			list<imseg::CTCHypoth>::iterator list_iter = iter1->m_lstImCTCHy_18.begin();
			search_pos1 = iter1;

			for (size_t k = 0; k < _vCTCHypoth_44.size(); k++)
			{
				if (search_pos1->m_lstImCTCHy_18.size() && search_pos1->m_lstImCTCHy_18.begin()->getUnicode() == ' ')
				{
					nTmp_v3 = 1;
					break;
				}
				search_pos1++;
			}

			if (search_pos2 >= iter1 || nTmp_v3)
			{
				iter1 += _vCTCHypoth_44.size() - 1;
				CTCHypoth xCTCHypoth_14;
				xCTCHypoth_14.field_0 = 32;
				xCTCHypoth_14.m_wcUnicode_4 = 32;
				xCTCHypoth_14.field_8 = -1;
				xCTCHypoth_14.m_nIndex_C = (*iter1).m_nIndex_C;
				xCTCHypoth_14.m_fcalcX_10 = 0.0;
				xCTCHypoth_14.m_fHandmade_14 = 1.0;
				(*iter1) = xCTCHypoth_14;
			}
			else
				iter1 += _vCTCHypoth_44.size() - 1;
		}
	}
}
