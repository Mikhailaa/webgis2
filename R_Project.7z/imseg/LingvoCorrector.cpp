#include "LingvoCorrector.h"

imseg::LingvoCorrector::LingvoCorrector(int n_a1, ICorrector*pICorrector)
{
	m_pIC_4 = pICorrector;
	m_nLingvoCorrector_8 = n_a1;
}

imseg::LingvoCorrector::~LingvoCorrector()
{
}

void imseg::LingvoCorrector::process_impl(vector<CTCHypoth>&)
{
}
