#include "Text.h"
#include "Symbol.h"

Text::Text()
{
	m_nLcid_18 = 0;
	field_1C = 0;
	field_20 = 0;
}

Text::Text(Text const &xText_a2)
{
}

Text::Text(Text &&a2)
{
	m_vimsegSymbol_0 = move(a2.m_vimsegSymbol_0);
	m_vBaseLines_C = move(a2.m_vBaseLines_C);
	m_nLcid_18 = a2.m_nLcid_18;
	field_1C = a2.field_1C;
	field_20 = a2.field_20;
}

Text::~Text()
{
}

void Text::init(vector<cv::Rect>& a2)
{
	m_vimsegSymbol_0.resize(a2.size());
	for (uint i = 0; i < a2.size(); i++)
	{
		tagRECT rect;
		rect.left = a2[i].x;
		rect.top = a2[i].y + a2[i].height;
		rect.right = a2[i].x + a2[i].width;
		rect.bottom = a2[i].y;
		m_vimsegSymbol_0[i] = imseg::Symbol(rect);
	}

	m_vBaseLines_C.resize(1);
	m_vBaseLines_C[0].setLine(eBaseLinePos_9, a2[0].y);
	m_vBaseLines_C[0].setLine(eBaseLinePos_A, a2[0].y + a2[0].height);
}

void Text::init(vector<Text>& a1)
{
	m_vimsegSymbol_0.clear();

	for(uint i = 0; i < a1.size(); i++)
	{
		int n = m_vBaseLines_C.size();
		for(uint j = 0; j < a1[i].m_vBaseLines_C.size(); j++)
			m_vBaseLines_C.push_back(a1[i].m_vBaseLines_C[j]);

		for(uint j = 0; j < a1[i].m_vimsegSymbol_0.size(); j++)
		{
			m_vimsegSymbol_0.push_back(a1[i].m_vimsegSymbol_0[j]);
			m_vimsegSymbol_0.back().m_nLine_10 += n;
		}

		if (!m_vimsegSymbol_0.empty())
		{
			m_vimsegSymbol_0.push_back(imseg::Symbol());

			int nSymbolCount = m_vimsegSymbol_0.size();
			m_vimsegSymbol_0[nSymbolCount - 1] = m_vimsegSymbol_0[nSymbolCount - 2];
			m_vimsegSymbol_0[nSymbolCount - 1].m_xRECT_0.left = m_vimsegSymbol_0[nSymbolCount - 2].m_xRECT_0.right + 2;
			m_vimsegSymbol_0[nSymbolCount - 1].m_xRECT_0.right = m_vimsegSymbol_0[nSymbolCount - 1].m_xRECT_0.left + 6;
			m_vimsegSymbol_0[nSymbolCount - 1].m_nLine_10 = m_vBaseLines_C.size();
			m_vimsegSymbol_0[nSymbolCount - 1].m_xRecRes2_18.m_vSymCandidat.resize(1);
			m_vimsegSymbol_0[nSymbolCount - 1].m_xRecRes2_18.m_vSymCandidat[0].m_wszCandiateCharacter_0 = L'^';
			m_vimsegSymbol_0[nSymbolCount - 1].m_xRecRes2_18.m_vSymCandidat[0].m_rProv_4 = 0.95f;
		}
	}

	if (!m_vimsegSymbol_0.empty())
		m_vimsegSymbol_0.erase(m_vimsegSymbol_0.end() - 1);
}

void Text::init(tagRECT &a2)
{
	m_vimsegSymbol_0.resize(1, imseg::Symbol(a2));
	m_vBaseLines_C.resize(1);
	m_vBaseLines_C[0].setLine(eBaseLinePos_9, a2.bottom);
	m_vBaseLines_C[0].setLine(eBaseLinePos_A, a2.top);
}

BaseLines & Text::baseLine(int a2)
{
	// TODO: insert return statement here
	int nLineIndex = baseLineIndex(a2);
	return m_vBaseLines_C[nLineIndex];
}

int Text::baseLineIndex(int a2)
{
	return m_vimsegSymbol_0[a2].m_nLine_10;
}

Text & Text::operator=(Text const &a2)
{
	// TODO: insert return statement here
	m_vimsegSymbol_0 = a2.m_vimsegSymbol_0;
	m_vBaseLines_C = a2.m_vBaseLines_C;
	m_nLcid_18 = a2.m_nLcid_18;
	field_1C = a2.field_1C;
	field_20 = a2.field_20;
	return *this;
}
Text & Text::operator=(Text &&a2)
{
	// TODO: insert return statement here
	m_vimsegSymbol_0 = a2.m_vimsegSymbol_0;
	m_vBaseLines_C = a2.m_vBaseLines_C;
	m_nLcid_18 = a2.m_nLcid_18;
	field_1C = a2.field_1C;
	field_20 = a2.field_20;
	return *this;
}


namespace TextInfo
{
	void alphabets(TextStruct& a1, set<int>& a2)
	{
		a2.clear();
		for (size_t i = 0; i < a1.m_vTextPartStruct_0.size(); i++)
		{
			if (!a1.m_vTextPartStruct_0[i].m_bField_39)
			{
				vector<CSymbolResult> vCSR = a1.m_vTextPartStruct_0[i].text();
				for (size_t j = 0; j < vCSR.size(); j++)
				{
					a2.emplace(vCSR[j].get(0));
				}
			}
		}
	}
};