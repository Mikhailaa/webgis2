#include "dbgInfoSaver.h"

using namespace imseg;

void dbgInfoSaver::saveAfterAlignment(DbgFolder const &, vector<CTCHypoth> const &)
{
}

void imseg::dbgInfoSaver::saveAfterLogicalCorrection(imseg::DbgFolder const &, vector<imseg::CTCHypoth> const &)
{
}

void dbgInfoSaver::saveBeforLogicalCorrection(DbgFolder const &, vector<CTCHypoth> const &, cv::Mat const &, vector<uint> const &)
{
}

void dbgInfoSaver::saveInputs(RichTextLines &, string, VocabInfo const &, char const *)
{
}

void dbgInfoSaver::saveImage(cv::Mat const &, cv::Rect_<int> const &, common::fs::Path, string const &)
{
}
