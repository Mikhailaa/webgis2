#include "CostMat.h"

namespace imseg
{

CTCHypoth CostMat::getMatchingHypoth(CTCHypoth&arg1, CharPlace &arg2)
{
	CTCHypoth res;
	if (arg2.isTrash())
	{
		res = CTCHypoth(arg1);
		res.setUnicode((const uint)"  ");
	}
	else
	{
		uint v8 = arg1.getUnicode();
		if (arg2.is_possible(v8))
		{
			res = CTCHypoth(arg1);
			return res;
		}
		else
		{
			list<CTCHypoth>::iterator iter;
			for (iter = arg1.m_lstImCTCHy_18.begin(); iter != arg1.m_lstImCTCHy_18.end(); iter++)
			{
				if (arg1.m_fHandmade_14 != (*iter).m_fHandmade_14)
					break;
				uint v13 = (*iter).getUnicode();
				if (arg2.is_possible(v13))
				{
					res = CTCHypoth(*iter);
					return res;
				}
			}
			res.field_0 = 0x10FFFF;
			res.m_wcUnicode_4 = 0x10FFFF;
			res.field_8 = -1;
			res.m_nIndex_C = 0;
			res.m_fcalcX_10 = 0.0f;
			res.m_fHandmade_14 = -1.0;
			res.m_lstImCTCHy_18.clear();
			return res;
		}
	}
	return res;
}

float CostMat::getMatchingCost(CTCHypoth &arg1, CharPlace &arg2)
{
	CTCHypoth xCTCHypoth_0;
	float res = 0.0f;
	if (arg2.isTrash())
		res = arg1.m_fHandmade_14 / m_nCostMatField_14;
	else
	{
		xCTCHypoth_0 = getMatchingHypoth(arg1, arg2);
		if (xCTCHypoth_0.isHandmade() || !arg2.is_possible(xCTCHypoth_0.getUnicode()))
			res = m_rCostMatField_10;
		else res = m_rCostMatField_0;
		xCTCHypoth_0.m_lstImCTCHy_18.clear();
	}
	return res;
}

float CostMat::getDeletingCost(CharPlace &arg1)
{
	if (arg1.isTrash() && (!arg1.isOptional()))
		return m_rCostMatField_C;
	else if (!arg1.isOptional())
		return m_rCostMatField_8;
	return m_rCostMatField_0;
}

float CostMat::getDeletingCost(CTCHypoth &arg1)
{
	return m_rCostMatField_4 + arg1.m_fHandmade_14;
}

CostMat::CostMat()
	: m_rCostMatField_0(0)
	, m_rCostMatField_4(0)
	, m_rCostMatField_8(2.0f)
	, m_rCostMatField_C(0.1f)
	, m_rCostMatField_10(5.0f)
	, m_nCostMatField_14(3)
{

}
}