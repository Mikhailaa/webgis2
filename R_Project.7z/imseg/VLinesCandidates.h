#pragma once
#include "pch.h"
#include "LinesCandidates.h"
#include "ImageControl.h"
#include "InitConstStructs.h"
#include "FontDesc.h"


class VLinesCandidates
{
public:
	bool findAngle(InitConstStructs &, FontDesc &, float &);
	void getHInfo(int, int, vector<int> &);
	int lineCandidateCount();
	bool rotate(vector<vector<CBufferImage *>>);

	vector<LinesCandidates> m_vLinesCandidates;
	float m_rAngle_C;
};


