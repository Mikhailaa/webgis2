#include "SymbolsFilter.h"

void SymbolsFilter::filterByType(ISymbolsInfoByUnicode & xISIBU_Param1, vector<int> & vParam2, eSymbolWidth eParam3, vector<int>& vParam4)
{
	vParam4.clear();
	for (uint i = 0; i < vParam2.size(); i++)
	{
		if (xISIBU_Param1.type(vParam2[i]) & eParam3)
		{
			vParam4.push_back(vParam2[i]);
		}
	}
}

void SymbolsFilter::filterByType(ISymbolsInfoByUnicode &, vector<int>&, eTails, eTails, vector<int>&)
{
}

void SymbolsFilter::filterByType(ISymbolsInfoByUnicode & xISIBU_Param1, vector<int> const& vParam2, eSymbolType eParam3, vector<int>& vParam4)
{
	vParam4.clear();
	for (uint i = 0; i < vParam2.size(); i++)
	{
		if (xISIBU_Param1.type(vParam2[i]) & eParam3)
		{
			vParam4.push_back(vParam2[i]);
		}
	}
}

void SymbolsFilter::symbolsType(ISymbolsInfoByUnicode & xISIBU_Param1, vector<int> &vParam2, eSymbolType &eParam3)
{
	eParam3 = SymbolType_0;
	for (uint i = 0; i < vParam2.size(); i++)
	{
		eParam3 = (eSymbolType)(eParam3 | xISIBU_Param1.type(vParam2[i]));
	}
}

void SymbolsFilter::symbolsType(ISymbolsInfoByUnicode &xISIBU_Param1, vector<int> &vParam2, eSymbolType &eParam3, eTails &eParam4)
{
	eParam3 = SymbolType_0;
	eParam4 = Tails_0;
	uint i;
	for (i = 0; i < vParam2.size(); i++)
	{
		if (vParam2[i] == 44)
			break;
	}
	if (i != vParam2.size())
		eParam4 = Tails_0x200;
	for (i = 0; i < vParam2.size(); i++)
	{
		eParam3 = (eSymbolType)(eParam3 | xISIBU_Param1.type(vParam2[i]));
		eParam4 = (eTails)(eParam4 | xISIBU_Param1.tailType(vParam2[i]));
	}
}
