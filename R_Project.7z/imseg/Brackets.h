#pragma once
#include "imseg_interface.h"
#include "SymbolResult.h"

class Brackets
{
public:
	enum eBracketState
	{
		eBracketState_0 = 0,
		eBracketState_1 = 1,
		eBracketState_2 = 2,
		eBracketState_3 = 3
	};

	void analyzePairSymbols(ISymbolsInfoByUnicode &, vector<CSymbolResult> &, vector<int> &, vector<Brackets::eBracketState> &, vector<CSymbolResult> &);
	void checkPairSymbols(ISymbolsInfoByUnicode &, unordered_map<int, int> &, unordered_map<int, CSymbolResult> &, vector<CSymbolResult> &);
	void findPairSymbols(ISymbolsInfoByUnicode &, CSymbolResult *, int, eWordType, int, vector<CSymbolResult> &, vector<int> &, vector<Brackets::eBracketState> &);
};