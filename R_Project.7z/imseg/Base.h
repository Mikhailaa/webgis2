#pragma once
#include "pch.h"
#include "RecognizedTextDoc.h"
#include "common/resources.h"
#include "common/container/container.h"
#include "common/container/RclHolder.h"
#include "Json/Value.h"
#include "Layer.h"
#include "DocInfo.h"

using namespace common::resources;
using namespace common::container;

namespace imseg
{
	namespace Base//--- complete ---
	{
		void removeFields(CRecognizedTextDoc &, CRecognizedTextDoc &, vector<int> const &);
		void sortFields(CRecognizedTextDoc &, CRecognizedTextDoc &, vector<int> const &);
		void resetLayers(CDocInfo &);
		void updateFieldsOrder(vector<Layer_R> &, vector<int> &, vector<unsigned int> &);
		bool updateImgParams(common::container::RclHolder &, CDocInfo *);
		bool updateDocInfoWithBind(common::container::RclHolder &, char const*, CDocInfo &);
	}
}