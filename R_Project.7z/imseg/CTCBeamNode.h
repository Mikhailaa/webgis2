#pragma once


#include "Label2Unicodes.h"
#include "CTCHypoth.h"

namespace imseg
{
	class CTCBeamNode
	{
	public:
		CTCBeamNode(shared_ptr<CTCBeamNode> &,shared_ptr<CTCHypoth> &);
		~CTCBeamNode();
		vector<CTCHypoth> calcPath();
		float getLogProb();


		shared_ptr<CTCHypoth> m_spCTCBN_CTCHy_0;
		shared_ptr<CTCBeamNode> m_spCTCBN_CTCBN_8;
		float m_rCTCBN_LogProb_10;
	};
}