#pragma once
#include "commonStruct.h"
#include "SubField.h"
#include "ListSubField.h"


extern recursive_mutex g_Mutex_1141D40;
extern ListSubField g_LSF_1141D44;

class RSubFieldManager
{
public:
	static map<wstring, SubField> *getName2SubfieldMap();
	static ListSubField *subFields();
	static int init(ListSubField &);
	static map<wchar_t, set<uint> > getAlphabets(TVisualSubField &);
};