#pragma once
#include "imseg_interface.h"

class AlphabetInfo : public IAlphabetInfo
{
public:
	vector<int> m_vn_4;
	vector<vector<int>> m_vvn_10;

	AlphabetInfo();
	~AlphabetInfo();
	int alphabet(int, vector<int>&);
	void reset();
};