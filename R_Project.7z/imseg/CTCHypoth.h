#pragma once
#include "pch.h"
#include "common/resources.h"
#include "common/container/container.h"
#include "common/container/RclHolder.h"
#include "SymbolCandidat.h"

using namespace common;
using namespace common::resources;
using namespace common::container;

namespace imseg
{
	class CTCHypoth
	{
	public:
		uint field_0;
		uint m_wcUnicode_4;
		int field_8;
		int m_nIndex_C;
		float m_fcalcX_10;
		float m_fHandmade_14;
		list<CTCHypoth> m_lstImCTCHy_18;

		CTCHypoth();
		CTCHypoth(CTCHypoth const&);
		CTCHypoth(CTCHypoth&&);
		CTCHypoth &operator=(CTCHypoth const&);
		CTCHypoth &operator=(CTCHypoth &&);
		bool operator==(CTCHypoth const&);
		bool operator<(CTCHypoth const&);
		bool operator>(CTCHypoth const&);

		void sortSecondaryHypothByProb();

		void setUnicode(uint const&);
		uint getUnicode() const;
		void calcXOnImage(float const &arg1);
		bool isHandmade();
		int getIndex();
		SymbolCandidat getSymbol() const;
	};
}