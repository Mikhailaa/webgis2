#pragma once
#include "pch.h"
#include "BaseLines.h"
#include "FontDescBase.h"
#include <map>
class LetterParam
{
public:
	LetterParam();
	~LetterParam();
};
class FontDesc
{
public:
	FontDescBase m_xFontDescBase_0;
	BaseLines m_xBaseLines_38;
	map<int, LetterParam> m_mapLetterParam_6C;

	FontDesc();
	~FontDesc();
	FontDesc &operator=(FontDesc const&);
};

class LayerParam
{
public:
	LayerParam();
	LayerParam(LayerParam&);

	FontDesc m_xFontDesc;
};

