#include "FieldParam.h"
#include "common/StringUtils.h"

FieldParam::FieldParam()
{
	m_nFP_0 = 0;
	m_nCount_4 = 0;
}

FieldParam::FieldParam(FieldParam &a2)
{
	m_nFP_0 = a2.m_nFP_0;
	m_nCount_4 = a2.m_nCount_4;
	m_umap_FP_4 = a2.m_umap_FP_4;
}

FieldParam::~FieldParam()
{
}

bool FieldParam::contain(eProcessOptions eProcOpt)
{
	return m_umap_FP_4.find(eProcOpt) != m_umap_FP_4.end();
}

FieldParam & FieldParam::operator=(FieldParam const &a2)
{
	// TODO: insert return statement here
	m_nFP_0 = a2.m_nFP_0;
	m_nCount_4 = a2.m_nCount_4;
	m_umap_FP_4 = a2.m_umap_FP_4;
	return *this;
}

vector<uchar> FieldParam::param(eProcessOptions a3)
{
	unordered_map<eProcessOptions, string>::iterator iter = m_umap_FP_4.find(a3);
	string str_38;
	if (iter != m_umap_FP_4.end())
	{
		string str_2C = iter->second;
		if (!str_2C.empty())
		{
			string str_B8 = common::StringUtils::toString(a3);
			str_B8.insert(0, "{_@");
			str_B8 += "(";
			str_B8 += str_2C;
			str_B8 += ")@}";
			str_38 = str_B8;
		}
		else
		{
			string str_68 = common::StringUtils::toString<int>(a3);
			str_68.insert(0, "{_@");
			str_68 += "@}";
			str_38 = str_68;
		}
	}
	return vector<uchar>(str_38.begin(), str_38.end());
}

vector<uchar> FieldParam::paramValue(eProcessOptions a3)
{
	unordered_map<eProcessOptions, string>::iterator iter = m_umap_FP_4.find(a3);
	string str_38;
	if (iter != m_umap_FP_4.end())
	{
		return vector<uchar>(iter->second.begin(), iter->second.end());
	}
	return vector<uchar>();
}