﻿#include "SeqConfidenceVouter.h"

using namespace imseg;

SeqConfidenceVouter::SeqConfidenceVouter()
{
}

void SeqConfidenceVouter::deleteLowProbableSymbols(vector<CTCHypoth>& vCTCHy_a2)
{
	vector<float> vrTmp;
	vrTmp.reserve(vCTCHy_a2.size());
	for (uint i = 0; i < vCTCHy_a2.size(); i++)
	{
		vrTmp.push_back(vCTCHy_a2[i].m_fHandmade_14);
	}

	nth_element(vrTmp.begin(), vrTmp.begin() + vrTmp.size() / 2, vrTmp.end());

	if (!vCTCHy_a2.empty())
	{
		uint  i;
		for (i=0; i < vCTCHy_a2.size(); i++)
		{
			if (vCTCHy_a2[i].m_fHandmade_14 < 0.01)
			{
				for (uint j = i + 1; j < vCTCHy_a2.size(); j++)
				{
					if (vCTCHy_a2[j].m_fHandmade_14 >= 0.01f)
					{
						vCTCHy_a2[i] = vCTCHy_a2[j];
					}
				}
				break;
			}
		}
		vCTCHy_a2.erase(vCTCHy_a2.begin() + i, vCTCHy_a2.end());
	}
}

void SeqConfidenceVouter::insertNewOrUpdateOld(list<CTCHypoth>& lstCTCHy_a2, list<CTCHypoth> &lstCTCHy_a3)
{
	list<CTCHypoth>::iterator Iter2;
	list<CTCHypoth>::iterator Iter3;
	for (Iter2 = lstCTCHy_a2.begin();Iter2 != lstCTCHy_a2.end(); Iter2++)
	{
		for (Iter3 = lstCTCHy_a3.begin(); Iter3 != lstCTCHy_a3.end(); Iter3++)
		{
			if ((*Iter3) == (*Iter2))
			{
				Iter3->m_fHandmade_14 += Iter2->m_fHandmade_14;
				break;
			}
		}

		if (Iter3 == lstCTCHy_a3.end()) lstCTCHy_a2.push_back(*Iter2);
	}

	lstCTCHy_a2.sort();
}

void SeqConfidenceVouter::liftUpHighProbSecondaryHypoth(vector<CTCHypoth>& vCTCHy_a2)
{
	for (uint i = 0; i < vCTCHy_a2.size(); i++)
	{
		vCTCHy_a2[i].sortSecondaryHypothByProb();
		list<CTCHypoth>::iterator Iter = vCTCHy_a2[i].m_lstImCTCHy_18.begin();
		while (Iter != vCTCHy_a2[i].m_lstImCTCHy_18.end())
		{
			if (Iter->m_fHandmade_14 > vCTCHy_a2[i].m_fHandmade_14)
			{
				vCTCHy_a2[i].setUnicode(Iter->getUnicode());
				vCTCHy_a2[i].m_fHandmade_14 = Iter->m_fHandmade_14;
				vCTCHy_a2[i].field_8 = Iter->field_8;
			}
			Iter++;
		}
	}
}

void SeqConfidenceVouter::moveProbsFromSecondaryToPrimaryHypoths(vector<CTCHypoth>& vCTCHy_a2)
{
	for (uint i = 0; i < vCTCHy_a2.size(); i++)
	{
		list<CTCHypoth>::iterator Iter = vCTCHy_a2[i].m_lstImCTCHy_18.begin();
		while (Iter != vCTCHy_a2[i].m_lstImCTCHy_18.end())
		{
			if (vCTCHy_a2[i].field_8 == Iter->field_8)
			{
				vCTCHy_a2[i].m_fHandmade_14 += Iter->m_fHandmade_14;
				Iter = vCTCHy_a2[i].m_lstImCTCHy_18.erase(Iter);
			}
			else
			{
				Iter++;
			}
		}
	}
}

wstring SeqConfidenceVouter::seq2Str(vector<CTCHypoth> const &a3)
{
	wstring ret;

	for (uint i = 0; i < a3.size(); i++)
	{
		ret.push_back(a3[i].getUnicode());
	}
	return ret;
}

void SeqConfidenceVouter::visit(RichTextLines &xRTLs_a2)
{
	vector<RichTextLines> &vRTLs = xRTLs_a2.getVotingSeqs();

	if(!vRTLs.empty())
	{
		int nLineCount = vRTLs[0].getLinesCount();
		vector<vector<CTCHypoth>> vvCTCHy(nLineCount);
		for (uint i = 0; i < vRTLs.size(); i++)
		{
			vector<vector<CTCHypoth>> vvCTCHyTmp(vRTLs[i].getSeqs());
			for (uint j = 0; j < vvCTCHyTmp.size(); j++)
			{
				if (vvCTCHy[j].empty())
					vvCTCHy[j] = vvCTCHyTmp[j];
				else
					vvCTCHy[j] = vote(vvCTCHy[j], vvCTCHyTmp[j]);
			}
		}

		for (size_t i = 0; i < vvCTCHy.size(); i++)
		{
			for (size_t j = 0; j < vvCTCHy[i].size(); j++)
			{
				if (vvCTCHy[i][j].getUnicode() == 0x10FFFF)
				{
					vvCTCHy[i].erase(vvCTCHy[i].begin() + j);
					j--;
				}
			}

			if (vRTLs.size() != 1)
			{
				// no check
				moveProbsFromSecondaryToPrimaryHypoths(vvCTCHy[i]);
				liftUpHighProbSecondaryHypoth(vvCTCHy[i]);
				deleteLowProbableSymbols(vvCTCHy[i]);
			}
		}

		for (uint i = 0; i < vvCTCHy.size(); i++)
			xRTLs_a2.append(vvCTCHy[i]);
	}

	
}

vector<CTCHypoth> SeqConfidenceVouter::vote(vector<CTCHypoth> &vCTCHy_a3, vector<CTCHypoth> &vCTCHy_a4)
{
	//no check
	if (vCTCHy_a3.empty())
		return vCTCHy_a4;
	if(vCTCHy_a4.empty())
		return vCTCHy_a3;

	wstring str_a3 = seq2Str(vCTCHy_a3);
	wstring str_a4 = seq2Str(vCTCHy_a4);
	vector<int> vTmp;
	vector<CTCHypoth> vCTCHy;
	alignStrings(str_a3, str_a4, vTmp);
	for (uint i = 0, j = 0, k = 0; i < vTmp.size(); i++)
	{
		switch (vTmp[i])
		{
		case 0:
		{
			CTCHypoth xCTCHy(vCTCHy_a3[j]);
			xCTCHy.m_fHandmade_14 += vCTCHy_a4[k].m_fHandmade_14;
			insertNewOrUpdateOld(xCTCHy.m_lstImCTCHy_18, vCTCHy_a4[k].m_lstImCTCHy_18);
			vCTCHy.push_back(xCTCHy);
			k++;
			j++;
			break;
		}
		case 1:
		{
			vCTCHy.push_back(vCTCHy_a3[j]);
			j++;
			break;
		}
		case 2:
		{
			vCTCHy.push_back(vCTCHy_a4[k]);
			k++;
			break;
		}
		case 3:
		{
			CTCHypoth xCTCHy_1(vCTCHy_a3[j]);
			CTCHypoth xCTCHy_2(vCTCHy_a4[k]);
			if (xCTCHy_1.m_fHandmade_14 > xCTCHy_2.m_fHandmade_14)
			{
				CTCHypoth xCTCHy_Tmp = xCTCHy_1;
				xCTCHy_1 = xCTCHy_2;
				xCTCHy_2 = xCTCHy_Tmp;
			}

			//list<CTCHypoth> lstCTCHy(xCTCHy_1, 1);
			//함수의 동작과정을 보면 아래의 구축자의 기능과 같다.
			list<CTCHypoth> lstCTCHy(1,xCTCHy_1);
			insertNewOrUpdateOld(xCTCHy_2.m_lstImCTCHy_18, lstCTCHy);
			insertNewOrUpdateOld(xCTCHy_2.m_lstImCTCHy_18, xCTCHy_1.m_lstImCTCHy_18);
			vCTCHy.push_back(xCTCHy_2);
			k++;
			j++;
			break;
		}
		default:
			break;
		}
	}
	
	return vCTCHy;
}
