#pragma once
#include "pch.h"
#include "PrefixTree.h"
#include "word_beam_search.h"

namespace imseg
{
	namespace word_beam_search
	{
		class LanguageModel
		{
			struct Bigram
			{

			};

			class Unigram
			{
			public:
				uint                                              m_nUg_0;
				int                                               m_nUg_4;
				double                                            m_dUg_8;
				unordered_map<vector<uint>, Bigram, HashFunction> m_umUg_10;
			public:
				Unigram();
				Unigram(Unigram const&);
				Unigram& operator=(Unigram const&);
				Unigram& operator=(Unigram&&);
			};

		public:
			unordered_map<vector<uint>, Unigram, HashFunction> m_umLM_0;
			int                                                m_nLM_14;
			int                                                m_nLM_18;
			int                                                m_nLM_1C;
			PrefixTree                                         m_xLM_20;
			vector<uint>                                       m_vLM_34;
			unordered_map<uint, uint>                          m_umLM_40;
			set<uint>                                           m_setLM_54;
			set<uint>                                           m_setLM_60;
			set<uint>                                           m_setLM_6C;
		public:
			LanguageModel();
			~LanguageModel();
			unordered_map<uint, uint> codepointToLabelMapping(vector<uint> const&);
			set<uint> & getAllChars(void);
			map<int, Char> getNextChars(vector<uint> const&);
			vector<vector<uint>> getNextWords(vector<uint> const&);
			set<uint> getNonWordChars(void);
			double getUnigramProb(vector<uint> const&);
			set<uint> getWordChars(void);
			void io_generic(cv::dnn::DnnReader &);
			uint labelToUnicode(uint);
		};

	}
}