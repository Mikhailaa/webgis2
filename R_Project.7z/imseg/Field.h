#pragma once
#include "../pch.h"
#include "CAlphabetF.h"
#include "FieldParam.h"
#include "FieldImages.h"
#include "Text.h"
#include "TextStruct.h"
#include "imseg_interface.h"
#include "VisualField.h"

using namespace imseg;

class Field : public IFieldInfo
{
public:
	Field();
	Field(Field const &a2);

	virtual ~Field();
	virtual int symbolsTails();
	virtual int symbolsType();
	virtual FieldParam& param();
	void init(vector<tagRECT> &);
	void init(vector<vector<cv::Rect>> &);
	void linesList(vector<Text *> &);

	//int m_Vft_0;
	FieldParam m_xFieldParam_4;
	FieldImages m_xFieldImages_20;
	vector<Text> m_vText_4C;
	vector<TextStruct> m_vTextStruct_58;
	int m_nTextStructIdx_64;
	int m_nField_68;
	bool m_bField_6C;
	//gap 3 byte
	CVisualField *m_pCVisualF_70;
	CAlphabetF m_xCAlphaF_74;
	eTails m_nsymbolsTails_98;
	eSymbolType m_nsymbolType_9C;
	vector<int> m_vnLcid_A0;
	int field_AC;
	string m_strMask_B0;	
};