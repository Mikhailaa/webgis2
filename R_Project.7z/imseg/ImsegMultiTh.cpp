﻿#include "ImsegMultiTh.h"
#include "CTCHypoth.h"
#include "rclhelp.h"
#include "moduleprocessgl.h"
#include "common/resources.h"
#include "RSubFieldManager.h"
#include "common/container/jsoncpp.h"
#include "common/ModuleOrchestrator.h"
static const char *byte_1066C40 = "Ijifmlokn";

namespace imseg
{
	struct gImSegExternal_global_registrator {
		shared_ptr<imseg::ImsegMultiTh> gImSegExternal;
		gImSegExternal_global_registrator() {
			gImSegExternal = common::getModuleOrchestrator()->addModule<imseg::ImsegMultiTh>();
		}
	} gImSegExternal_global_registrator_;


	ImsegMultiTh::ImsegMultiTh()
	{
		m_xJV_40 = Json::Value(Json::json_type_null);
		string _stemp = "{\"document\":{\"chipPage\":0,\"number\":1,\"dType\":50,\"dOrientation\":0,\"textRects\":[{\"number\":1,\"lightType\""
			":6,\"layer\":-1,\"relRect\":\"0,0,0,0\",\"colorType\":1,\"fieldType\":50,\"fontLayer\":0,\"inComparison\":0,\"varHei"
			"ght\":2,\"lcid\":0,\"useDNN\":true,\"mask\":\"{TEXT[0+1049]}\",\"h\":0,\"alphabet\":{\"99\":\"99\",\"68\":\"68\",\"8"
			"3\":\"-,.:\\/\\u2116\\\"()<>\\\\_\"}}]}}";
		common::container::jsoncpp::convert(_stemp, m_xJV_40);
	}

	ImsegMultiTh::~ImsegMultiTh()
	{
	}

	vector<int> ImsegMultiTh::getCommands()
	{
		static vector<int> vv = { 0x2FAD, 0x2FB1, 0x13A, 0x13B, 0x3E8, 0xCD, 0xCE, 0x130, 0x12C, 0x134, 0x133, 0x131, 0x12E, 0x12F, 0x132, 0x135, 0x136, 0x137, 0x138, 0x139 };

		return vv;
	}

	istringstream loadImsegDnn(string strPath)
	{
		string data;
		common::resources::getFile(strPath, data);
		if (!data.empty())
			return istringstream(data, ios_base::binary);
		
		return istringstream();
	}

	int ImsegMultiTh::process(int a1, void *a2, const char *a3, void **a4, char **a5)
	{
		vector<TResultContainer *> vpTResultContainer_D0;
		RclHolder rclH_34;
		bool bFlag_r5 = false;

		if (a1 == 1000)
		{
			TRawImageContainer *pRIC = (TRawImageContainer *)a2;
			if (pRIC->pxRIC_bmi && pRIC->pRIC_data)
			{
				rclH_34.addNewNoCopy<TRawImageContainer>(1, pRIC, RPRM_Lights_0);
			}
		}
		else if(a2)
		{
			rclH_34.addNoCopy(*(TResultContainerList *)a2);
			bFlag_r5 = true;
		}

		vpTResultContainer_D0 = rclH_34.getRcList(1);
		if (vpTResultContainer_D0.empty())
		{
			TResultContainerList *ppTRCL = NULL;
			processgl(13101, NULL, a3, (void**)&ppTRCL, NULL);
			if (ppTRCL)
				rclH_34.addCopy(*ppTRCL);
		}

		Json::Value jv_50 = common::container::jsoncpp::convert(a3);
		if (rclhelp::documentIDRecogn(rclH_34.m_xTRCL) == 1 && m_xJV_40.isMember("document"))
		{
			if (jv_50.isMember("processParam"))
			{
				if (jv_50["processParam"].isMember("customParams"))
				{
					if (jv_50["processParam"]["customParams"].isMember("ocrFree"))
					{
						Json::Value v17 = jv_50["processParam"]["customParams"]["ocrFree"];
						if (v17.isMember("mask"))
							m_xJV_40["document"]["textRects"][0]["mask"] = Json::Value(v17["mask"]);
						if (v17.isMember("lcid"))
							m_xJV_40["document"]["textRects"][0]["lcid"] = Json::Value(v17["lcid"]);
					}
				}
			}
			rclH_34.addNewNoCopy<void>(63, (void*)&m_xJV_40);
		}

		common::UniqueObjectByIndex<ImSeg> *pUOBI_ImSeg_r4 = m_xUOBIUOBI_ImSeg_4.getObject(0);
		ImSegStatic* pObj = ImSegStatic::obj();
		
		if ((unsigned int)(a1 - 314) < 2 || a1 == 12205 || a1 == 12209)
		{
			pObj->reset();
			pUOBI_ImSeg_r4->m_xUOBI_map.clear();
			pObj->field_430 = 0;
		}

		ImSeg *pImseg_r0 = pUOBI_ImSeg_r4->getObject(0);
		pImseg_r0->m_nfield_F4 = 0;
		int n_v38 = 1;
		int nRet = 0;

		unsigned int swch = a1 - 300;
		switch (swch)
		{
		case 1:
		case 8:
			nRet = 1;
			break;
		case 2:
		case 5:
			if (!a4)
			{
				nRet = 2;
			}
			else
			{
				pUOBI_ImSeg_r4->m_xUOBI_map.clear();
				pObj->field_430 = 0;
				RclHolder *pRclH_r4 = m_xUOBI_RH_1C.getObject(0);
				pRclH_r4->clear();
				vector<shared_ptr<RclHolder>> vspRclHolder_B0 = rclhelp::splitByPage(rclH_34);
				for (size_t i = 0; i < vspRclHolder_B0.size(); i++)
				{
					vpTResultContainer_D0 = vspRclHolder_B0[i]->getRcList(1);
					if(!vpTResultContainer_D0.empty())
					{ 
						int nPage = rclhelp::getPage(vspRclHolder_B0[i]->m_xTRCL);
						ImSeg *_pImSeg45 = pUOBI_ImSeg_r4->getObject(nPage);
						TResultContainerList *pTRCL_F0 = NULL;
						char *pszResult_E0 = NULL;
						_pImSeg45->m_xPSCtrl_50.resetSeries();
						_pImSeg45->processList(vspRclHolder_B0[i]->m_xTRCL, a3, &pTRCL_F0, &pszResult_E0);
						if (pTRCL_F0)
						{
							RclHolder rclH_D0(pTRCL_F0, true);
							rclH_D0.setPageIndex(nPage);
							pRclH_r4->addNoCopy(rclH_D0.m_xTRCL);
						}

						if (a5)
						{
							*a5 = pszResult_E0;
						}
					}
				}

				*a4 = pRclH_r4;
				nRet = 0;
			}
			break;
		case 3:
		case 4:
			break;
		case 6:
			n_v38 = a4 == 0;
			if (!bFlag_r5 || n_v38)
			{
				nRet = 2;
			}
			else
			{
				//Log("imseg processSeries");
				pObj->field_430++;
				vector<shared_ptr<RclHolder>> vspRclHolder_B0 = rclhelp::splitByPage(rclH_34);
				int nOldRet_100 = 0;
				for (size_t i = 0; i < vspRclHolder_B0.size(); i++)
				{
					vector<TResultContainer*>vpTResultContainer_E0 = vspRclHolder_B0[i]->getRcList(1);

					if (!vpTResultContainer_E0.empty())
					{
						int nPage = rclhelp::getPage(vspRclHolder_B0[i]->m_xTRCL);
						ImSeg *_pImSeg95 = pUOBI_ImSeg_r4->getObject(nPage);
						//Log("start process page: %d",nPage);
						TResultContainerList *pTRCL_E4 = NULL;
						char *pszResult_F0 = NULL;
						int nSeriesRet = _pImSeg95->processSeries(vspRclHolder_B0[i]->m_xTRCL, a3, &pTRCL_E4, &pszResult_F0);

						//Log("end process page, result: %d",nSeriesRet);
						if (!nSeriesRet)
						{
							if (nOldRet_100) continue;
						}
						*a5 = pszResult_F0;
						nOldRet_100 = nSeriesRet;
					}
				}

				RclHolder *pRclH_r4 = m_xUOBI_RH_1C.getObject(0);
				pRclH_r4->clear();
				vector<ulonglong> vIds = pUOBI_ImSeg_r4->getIds();
				for (size_t i = 0; i < vIds.size(); i++)
				{
					ImSeg* pImSeg_r2 = pUOBI_ImSeg_r4->getObject(vIds[i]);
					if (pImSeg_r2->m_xPSCtrl_50.isPSC_field_54)
					{
						pRclH_r4->addNoCopy(pImSeg_r2->m_xPSCtrl_50.m_xRclHolder_28.m_xTRCL);
						if (!pImSeg_r2->m_xPSCtrl_50.isPSC_field_58)
						{
							//Log("page not ready: %d",vIds[i]);
							nRet = -3326;
						}
					}
				}
				*a4 = pRclH_r4;
			}
			break;
		case 7:
		{
			string str_F8;
			if (a3) str_F8 = string(a3);
			nRet = pObj->initSubFieldsJson(str_F8);
			break;
		}
		case 9:
		{
			Json::Value jv_D0;
			if (a3)
			{
				if (common::container::jsoncpp::convert(string(a3), jv_D0))
				{
					return 1;
				}
			}
			
			if (jv_D0.isMember("useOnlyWhiteImage"))
			{
				imseg::parameters::Configuration::obj()->m_xJsonValue_8["Main"]["useOnlyWhiteImage"] = Json::Value(jv_D0["useOnlyWhiteImage"]);
			}

			if (jv_D0.isMember("fieldTypesFilter"))
			{
				pObj->m_xFieldsLoadFilter_434.m_vn_0.clear();
				Json::Value jv(jv_D0["fieldTypesFilter"]);
				for (size_t i = 0; i < jv.size(); i++)
				{
					pObj->m_xFieldsLoadFilter_434.m_vn_0.push_back(jv[i].asInt());
				}
			}

			if (jv_D0.isMember("lcidFilter"))
			{
				pObj->m_xFieldsLoadFilter_434.m_vn_C.clear();
				Json::Value jv(jv_D0["lcidFilter"]);
				for (size_t i = 0; i < jv.size(); i++)
				{
					pObj->m_xFieldsLoadFilter_434.m_vn_C.push_back(jv[i].asInt());
				}
			}

			if (jv_D0.isMember("numberFilter"))
			{
				pObj->m_xFieldsLoadFilter_434.field_18 = jv_D0["numberFilter"].asInt();
			}

			if (jv_D0.isMember("statusFilter"))
			{
				pObj->m_xFieldsLoadFilter_434.field_1C = jv_D0["statusFilter"].asInt();
			}

			nRet = 0;
			break;
		}
		case 10:
			pImseg_r0->m_nfield_F4 = n_v38;
			if (a3)
			{
				//imseg::debug::fieldsinfo::getSplitFieldInfo(string(a3), m_s_34);
			}
		case 11:
		case 12:
			break;
		default:
		{
			if (a1 == 0 || a1 == 205)
			{
				string strB0;
				strB0 = pObj->m_xistrstream_108.rdbuf()->str();
				if (strB0.empty())
				{
					pObj->m_xistrstream_108 = loadImsegDnn("DNNOCR.dat");
					//common::resources::getFile(strB0,pObj->m_xistrstream_108.rdbuf()->str());
				}

				strB0 = pObj->m_xistrstream_194.rdbuf()->str();
				if (strB0.empty())
				{
					pObj->m_xistrstream_194 = loadImsegDnn("DNNOCRCN.dat");
					//common::resources::getFile(strB0, pObj->m_xistrstream_194.rdbuf()->str());
				}

				strB0 = pObj->m_xistrstream_220.rdbuf()->str();
				if (strB0.empty())
				{
					pObj->m_xistrstream_220 = loadImsegDnn("DNNOCRAS.dat");
					//common::resources::getFile(strB0, pObj->m_xistrstream_220.rdbuf()->str());
				}

				strB0 = pObj->m_xistrstream_2AC.rdbuf()->str();
				if (strB0.empty())
				{
					pObj->m_xistrstream_2AC = loadImsegDnn("DNNOCRAR.dat");
					//common::resources::getFile(strB0, pObj->m_xistrstream_2AC.rdbuf()->str());
				}

				strB0 = pObj->m_xistrstream_338.rdbuf()->str();
				if (strB0.empty())
				{
					pObj->m_xistrstream_338 = loadImsegDnn("DNNOCRBC.dat");
					//common::resources::getFile(strB0, pObj->m_xistrstream_338.rdbuf()->str());
				}

				strB0 = pObj->m_s_FC;
				if (strB0.empty())
				{
					string strOut;
					common::resources::getFile((TResultContainerList*)a2, "ImSeg.ini", strOut);
					pObj->m_s_FC = strOut;
				}

				if (pObj->init())
				{
					nRet = 2;
				}
				else 
				{
					ListSubField* pLSF = RSubFieldManager::subFields();
					if (!pLSF->count())
					{
						string strOut;
						common::resources::getFile((TResultContainerList*)a2, "SubFields.json", strOut);
						if (!pObj->initSubFieldsJson(strOut))
						{
							nRet = 0;
							break;
						}
						common::resources::getFile((TResultContainerList*)a2, "SubFields.dat", strOut);
						nRet = 2;
						vector<uchar> vuch;
						if (pObj->initSubFieldsBin(vuch))
						{
							nRet = 2;
						}
						else
						{
							nRet = 0;
						}
					}
				}
			}
			else if(a1 == 206)
			{
				nRet = 0;
				pObj->unload();
			}
			else if (a1 != 1000)
			{
				nRet = 1;
			}

			
			break;
		}
		}
		
		return ImSegNS::Error::checkCodeError(nRet);
	}

	

};