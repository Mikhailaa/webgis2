#include "TextEx.h"

TextEx::TextEx()
{
}

TextEx::~TextEx()
{
}
