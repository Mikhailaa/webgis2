#include "series.h"

namespace imseg
{
	namespace result
	{
		bool hasValueConfirmByMask(CRecognizedTextFieldSDK &arg1)
		{
			if (arg1.pszDVEF_FieldMask)
			{
				string _s_8(arg1.pszDVEF_FieldMask, strlen(arg1.pszDVEF_FieldMask));
				if (_s_8.size() != 13 || _s_8.compare(0, -1, "{STRINGS_DEF}", 13))
				{
					char *v5 = arg1.getData_pointer();
					return  v5 != 0;
				}
			}
			return 0;
		}
	}

	namespace series
	{
		int m_n_1129D6C = 0;
		string m_s_1129D94 = "";

		ProcessSeriesControl::ProcessSeriesControl()
			: m_setn_1C()
			, m_xRclHolder_28()
			, m_xCRecognizedTextDoc_3C()
			, m_xCRecognizedTextDoc_48()
			, m_mapnn_5C()
			, m_vn_68()
			, m_mapnn_74()
			, m_mapnn_80()
			, m_vn_8C()
			, m_mapnvspCRecognizedTextFieldSDK_98()
		{
			isPSC_field_58 = 0;
			resetSeries();
		}
		ProcessSeriesControl::~ProcessSeriesControl()
		{
		}
		void ProcessSeriesControl::resetSeries()
		{
			m_nMinProbForFieldRecognLastStep_8 = 5;
			m_nfieldTypeForControlSeries_C = -1;
			m_nminTextLenForResult_10 = 0;
			m_nconfirmResultCount_14 = 2;
			m_nminProbThresholdDnn_14 = 94;
			m_setn_1C.clear();
			m_xCRecognizedTextDoc_3C.reset();
			m_xCRecognizedTextDoc_48.reset();
			isPSC_field_54 = 0;
			isPSC_field_58 = 0;
			m_mapnn_80.clear();
			m_vn_8C.clear();
			m_mapnvspCRecognizedTextFieldSDK_98.clear();
		}
		void updateParams(ProcessSeriesControl &arg1, Json::Value &arg2)
		{
			Json::Value v10, v11;
			v10 = Json::Value(arg1.m_nMinProbForFieldRecogn_0);
			v11 = arg2.get("MinProbForFieldRecogn", v10);
			arg1.m_nMinProbForFieldRecogn_0 = v11.asInt();
			v10 = Json::Value(arg1.m_nMinProbForFieldRecognLastStep_4);
			v11 = arg2.get("MinProbForFieldRecognLastStep", v10);
			arg1.m_nMinProbForFieldRecognLastStep_4 = v11.asInt();
			v10 = Json::Value(arg1.m_nMinProbForFieldRecognLastStep_8);
			v11 = arg2.get("ProcessImageCountLastStep", v10);
			arg1.m_nMinProbForFieldRecognLastStep_8 = v11.asInt();
			v10 = Json::Value(arg1.m_nfieldTypeForControlSeries_C);
			v11 = arg2.get("fieldTypeForControlSeries", v10);
			arg1.m_nfieldTypeForControlSeries_C = v11.asInt();
			v10 = Json::Value(arg1.m_nminTextLenForResult_10);
			v11 = arg2.get("minTextLenForResult", v10);
			arg1.m_nminTextLenForResult_10 = v11.asInt();
			v10 = Json::Value(arg1.m_nconfirmResultCount_14);
			v11 = arg2.get("confirmResultCount", v10);
			arg1.m_nconfirmResultCount_14 = v11.asInt();
			v10 = Json::Value(arg1.m_nminProbThresholdDnn_14);
			v11 = arg2.get("minProbThresholdDnn", v10);
			arg1.m_nminProbThresholdDnn_14 = v11.asInt();
			if (arg2.isMember("necessaryFieldType"))
			{
				if (arg2["necessaryFieldType"].isArray())
				{
					Json::Value v5 = arg2["necessaryFieldType"];
					int v8;
					for (size_t i = 0; i < v5.size(); i++)
					{
						v8 = v5[i].asInt();
						arg1.m_setn_1C.emplace(v8);
					}
				}
			}
		}
		bool checkSeries(int arg1, TDocVisualExtendedInfo const *arg2, bool arg3, bool &arg4)
		{
			string _s_0;
			CRecognizedTextDoc *v5 = (CRecognizedTextDoc*)arg2;
			bool res = arg3;
			if (res)
				m_s_1129D94.clear();
			res = 0;
			arg4 = 0;
			CRecognizedTextFieldSDK *v4 = v5->find((eVisualFieldType)arg1);
			if (v4)
			{
				if (m_s_1129D94.size())
				{
					char *v10 = v4->getData_pointer();
					_s_0 = string(v10, strlen(v10));
					int vr4 = v4->minProb();
					char *v5 = (char *)m_s_1129D94.data();
					if (_s_0.size() == m_s_1129D94.size() && strcmp(_s_0.data(), m_s_1129D94.data()) == 0)
					{
						v5 = (char *)_s_0.data();
						res = 1;
					}
					else
					{
						if (m_n_1129D6C < vr4)
						{
							m_s_1129D94 = _s_0;
							m_n_1129D6C = vr4;
							arg4 = 1;
						}
						res = 0;
					}
					return res;
				}

				if (v4->minProb() >= 90)
				{
					char *v18 = v4->getData_pointer();
					arg4 = 0;
					_s_0 = string(v18, strlen(v18));
					m_s_1129D94 = _s_0;
					m_n_1129D6C = v4->minProb();
				}
				res = 1;
			}
			return res;
		}
		bool checkReadyFieldDnn(vector<shared_ptr<CRecognizedTextFieldSDK>>&arg1, CRecognizedTextFieldSDK &arg2, map<int, bool> &arg3, int arg4, int arg5)
		{
			bool res = 0;
			string _s_18;
			if ((int)arg2.minProb() >= arg5)
				return 1;
			map<int, bool>::iterator iter = arg3.find(arg2.u0.s0.wFieldType);
			bool v11 = arg3.end() == iter;
			if (!v11)
				v11 = iter->second == 0;
			if (v11)
			{
				if (arg2.getData_pointer())
				{
					char *v13 = arg2.getData_pointer();
					string _s_8(v13, strlen(v13));
					_s_18 = _s_8;
				}
				int v17 = 1;
				vector<shared_ptr<CRecognizedTextFieldSDK>>::iterator iter1 = arg1.begin();
				for (; iter1 != arg1.end(); iter1++)
				{
					if (result::hasValueConfirmByMask(*(*iter1).get()) && (*iter1).get()->getData_pointer())
					{
						char *v13 = (*iter1).get()->getData_pointer();
						string _s_8(v13, strlen(v13));
						int v28 = _s_18.compare(_s_8) == 0;
						v17 += v28;
					}
				}
				if (v17 >= arg4)
					res = 1;
			}
			else
				res = 0;
			return res;
		}

		bool checkReadyFieldDnnOff(CRecognizedTextFieldSDK &arg1, float arg2)
		{
			int v3 = arg1.minProb();
			if (v3 > arg2)
				return 1;
			return 0;
		}
		CRecognizedTextFieldSDK * chooseMostProbableResultDnnOff(vector<shared_ptr<CRecognizedTextFieldSDK>>&vspCRTFSDK_a1, float r_a2)
		{
			vector<shared_ptr<CRecognizedTextFieldSDK>>::iterator iter;
			if (vspCRTFSDK_a1.empty())
				return nullptr;
			int minProb = 0, min1 = 0, min2 = 0;
			CRecognizedTextFieldSDK *pCRTFSDK_, *res;
			for (iter = vspCRTFSDK_a1.begin(); iter != vspCRTFSDK_a1.end(); iter++)
			{
				minProb = (*iter).get()->minProb();
				if (result::hasValueConfirmByMask(*(*iter).get()))
				{
					if (min1 < minProb)
					{
						pCRTFSDK_ = (*iter).get();
						min1 = minProb;
					}
				}
				else if (min2 < minProb)
				{
					res = (*iter).get();
					min2 = minProb;
				}
			}

			if (pCRTFSDK_)
				res = pCRTFSDK_;
			else
				min1 = min2;
			if (min1 < r_a2)
				res = nullptr;
			return res;
		}
		CRecognizedTextFieldSDK * chooseMostProbableResultDnn(vector<shared_ptr<CRecognizedTextFieldSDK>>&vspCRTFSDK_a1)
		{
			vector<shared_ptr<CRecognizedTextFieldSDK>>::iterator iter;
			if (vspCRTFSDK_a1.empty())
				return nullptr;
			float middleProb = 0.0f, middle1 = 0.0f, middle2 = 0.0f;
			CRecognizedTextFieldSDK *pCRTFSDK_, *res;
			for (iter = vspCRTFSDK_a1.begin(); iter != vspCRTFSDK_a1.end(); iter++)
			{
				middleProb = (*iter).get()->middleProb();
				if (result::hasValueConfirmByMask(*(*iter).get()))
				{
					if (middle1 < middleProb)
					{
						pCRTFSDK_ = (*iter).get();
						middle1 = middleProb;
					}
				}
				else if (middle2 < middleProb)
				{
					res = (*iter).get();
					middle2 = middleProb;
				}
			}

			if (pCRTFSDK_)
				res = pCRTFSDK_;
			return res;
		}
	};
}
