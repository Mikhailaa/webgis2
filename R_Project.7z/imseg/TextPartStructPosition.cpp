#include "TextPartStructPosition.h"


TextPartStructPosition::TextPartStructPosition()
{
	m_nStatus_0 = 0;
	m_nStartPos_4 = -1;
	m_nEndPos_8 = -1;
}

TextPartStructPosition::TextPartStructPosition(TextPartStructPosition const&a1)
{
	m_nStatus_0 = a1.m_nStatus_0;
	m_nStartPos_4 = a1.m_nStartPos_4;
	m_nEndPos_8 = a1.m_nEndPos_8;
}

TextPartStructPosition::~TextPartStructPosition()
{
}

int TextPartStructPosition::status()
{
	return m_nStatus_0;
}

void TextPartStructPosition::setPosition(int a1, int a2)
{
	m_nStatus_0 = 1;
	m_nStartPos_4 = a1;
	m_nEndPos_8 = a2;
}


void TextPartStructPosition::setAsOutSide(int a1, int a2)
{
	m_nStatus_0 = 2;
	m_nStartPos_4 = a1;
	m_nEndPos_8 = a2;
}

int TextPartStructPosition::len()
{
	if(m_nStatus_0 == 1)
		return m_nEndPos_8 - m_nStartPos_4 + 1;
	return 0;
}

bool TextPartStructPosition::isReady()
{
	return m_nStatus_0 != 0;
}

TextPartStructPosition& TextPartStructPosition::operator=(TextPartStructPosition const & a1)
{
	m_nStatus_0 = a1.m_nStatus_0;
	m_nStartPos_4 = a1.m_nStartPos_4;
	m_nEndPos_8 = a1.m_nEndPos_8;
	return *this;
}

