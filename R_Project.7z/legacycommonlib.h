#pragma once

#include "pch.h"
#include "sdk/DocInfo.h"
#include "common/container/RclHolder.h"
#include "field/ListSubField.h"
#include "field/VisualField.h"
#include "sdk/RecognizedTextDoc.h"

namespace legacycommonlib
{
	class FieldsLoadFilter
	{
	public:
		vector<int> m_vn_0;
		vector<int> m_vn_C;
		int field_18;
		int field_1C;

		FieldsLoadFilter();
		~FieldsLoadFilter();
		FieldsLoadFilter & operator=(FieldsLoadFilter &arg1);
		FieldsLoadFilter& operator=(FieldsLoadFilter &&arg1);
	};

	namespace jsoncpp
	{
		namespace realrect
		{
			void convert(Json::Value const &xJV_Param1, tagRECTF &xParam2);
		}

		bool tryToGetDocInfo(common::container::RclHolder &xRH_Param1, const char *pcParam2, Json::Value &xJV_Param3, CDocInfo **ppCDI_Param4);
		int convert(string const &strParam1, CDocInfo &xCDI_Param2, FieldsLoadFilter *pFLF_Param3);
		int convert(string &strParam1, ListSubField &xLSF_Param2);
		void convert(Json::Value const &xJV_Param1, TVocList &xTVL_Param2);
		void convert(Json::Value const &xJV_Param1, TProcParams &xTPP_Param2);
		void convert(Json::Value const&xJV_Param1, CAlphabet *pCA_Param2);
		void convert(Json::Value const &xJV_Param1, ListSubField &xLSF_Param2);
		void convert(Json::Value const &xJV_Param1, CFieldFont &xCFF_Param2);
		int convert(Json::Value const &xJV_Param1, CVisualField &xCVF_Param2, FieldsLoadFilter *pFLF_Param3);
		void convert(Json::Value const &xJV_Param1, CDocInfo &xCDI_Param2, FieldsLoadFilter *pFLF_Param3);
		void convert(CRecognizedTextDoc &xCRTD_Param1, Json::Value &xJV_Param2, int nParam3);
	};
};