#pragma once
#include "pch.h"
#include <jpeglib.h>

namespace imaging
{
	enum eRI_Commands
	{
		RI_Commands_0 = 0,
		RI_Commands_1,
		RI_Commands_2,
		RI_Commands_3,
		RI_Commands_4,
		RI_Commands_5,
		RI_Commands_6,
		RI_Commands_7,
		RI_Commands_8,
		RI_Commands_9,
		RI_Commands_A,
		RI_Commands_B,
		RI_Commands_C,
		RI_Commands_D,
		RI_Commands_E,
		RI_Commands_F,
		RI_Commands_10,
		RI_Commands_11,
		RI_Commands_12,
		RI_Commands_13,
	};

	enum eRI_ImageFormats
	{
		RI_ImageFormats_0 = 0,
		RI_ImageFormats_1,
		RI_ImageFormats_FF = 0xFF,
	};

	enum eRI_FlipModes
	{
		RI_FLIPMODES_1 = 1,
		RI_FLIPMODES_2,
		RI_FLIPMODES_3,
	};

	enum eRI_Rotations
	{
		RI_Rotations_0 = 0,
		RI_Rotations_1,
		RI_Rotations_2,
		RI_Rotations_3
	};

	enum eRI_Density_Units
	{
		RI_Density_Units_0,
		RI_Density_Units_1,
		RI_Density_Units_2
	};

	struct RI_SaveFileParameters
	{
		int nSFP_0;
		int nSFP_4;
		TResultContainer *pxSFP_8;
		int nSFP_C;
		uchar **ppSFP_10;
		uint *pnSFP_14;
	};

	struct RI_Parameters
	{
		void* pRIP_0;
		void* pRIP_4;
	};

	struct RI_ImageInfo
	{

	};

	namespace angle {
		eRI_Rotations convert(eRPRM_Orientation a1);
		eRI_Rotations convert(int);
		eRPRM_Orientation convert(eRI_Rotations);
	}

	class ThreadResourcesHolder
	{
	public:
		recursive_mutex m_xTRH_mtx;
		map<__thread_id, list<uchar *>> m_xTRH_map;
		ThreadResourcesHolder() {};
		~ThreadResourcesHolder() 
		{
			CleanupAllThreadResources();
		}

		bool CleanupCurrentThreadResources()
		{
			bool fRet = false;
			m_xTRH_mtx.lock();
			size_t size = m_xTRH_map.size();
			if (size)
			{
				__thread_id id = pthread_self();
				map<__thread_id, list<uchar *>>::iterator iter = m_xTRH_map.find(id);
				if (iter != m_xTRH_map.end())
				{
					list<uchar *> v8 = iter->second;
					for (list<uchar *>::iterator iter1 = v8.begin(); iter1 != v8.end(); iter1++)
					{
						delete[] (*iter1);
						*iter1 = 0;
					}
					v8.clear();
					m_xTRH_map.erase(id);
					if (m_xTRH_map.size() != size)
						fRet = true;
				}
			}
			m_xTRH_mtx.unlock();
			return fRet;
		}

		bool CleanupAllThreadResources()
		{
			bool fRet = false;
			m_xTRH_mtx.lock();
			if (!m_xTRH_map.empty())
			{
				for (map<__thread_id, list<uchar *>>::iterator iter = m_xTRH_map.begin(); iter != m_xTRH_map.end(); iter++)
				{
					for (list<uchar *>::iterator iter1 = iter->second.begin(); iter1 != iter->second.end(); iter1++)
					{
						delete[](*iter1);
						*iter1 = 0;
					}
				}
				m_xTRH_map.clear();
				fRet = true;
			}
			m_xTRH_mtx.unlock();
			return fRet;
		}

		bool CleanupThreadResources(uchar const*a2)
		{
			bool fRet = false;
			m_xTRH_mtx.lock();
			if (!m_xTRH_map.empty())
			{
				for (map<__thread_id, list<uchar *>>::iterator iter = m_xTRH_map.begin(); iter != m_xTRH_map.end(); iter++)
				{
					for (list<uchar *>::iterator iter1 = iter->second.begin(); iter1 != iter->second.end(); iter1++)
					{
						if (*iter1 == a2)
						{
							delete[](*iter1);
							*iter1 = 0;
							list<uchar *>::iterator iter2 = iter1;
							iter2++;
							for (; iter2 != iter->second.end(); iter2 ++)
							{
								if (*iter2 != a2) break;
								delete[](*iter2);
								*iter2 = 0;
							}
							iter1 = iter->second.erase(iter1, iter2);
							if (iter1 == iter->second.end()) break;
						}
					}
				}
				fRet = true;
			}
			m_xTRH_mtx.unlock();
			return fRet;
		}

		void FreeMemory(uchar *a2)
		{
			if (a2)
				CleanupThreadResources(a2);
		}

		bool PointerAlreadyOwned(uchar *a2)
		{
			for (map<__thread_id, list<uchar *>>::iterator iter = m_xTRH_map.begin(); iter != m_xTRH_map.end(); iter++)
			{
				for (list<uchar *>::iterator iter1 = iter->second.begin(); iter1 != iter->second.end(); iter1++)
				{
					if (*iter1 == a2)
					{
						return true;
					}
				}
			}
			return false;
		}

		bool AddThreadResources(uchar *a2)
		{
			if (!a2) return false;
			m_xTRH_mtx.lock();
			if (!PointerAlreadyOwned(a2))
			{
				__thread_id id = pthread_self();
				map<__thread_id, list<uchar *>>::iterator iter = m_xTRH_map.find(id);
				if (iter == m_xTRH_map.end())
				{
					m_xTRH_map[id].assign(1, a2);
				}
				else
				{
					m_xTRH_map[id].push_back(a2);
				}
			}
			m_xTRH_mtx.unlock();
			return true;
		}

		uchar* AllocateMemory(ulong a2)
		{
			uchar* v4 = new uchar[a2];
			AddThreadResources(v4);
			memclr(v4, a2);
			return v4;
		}
	};

	class CImageCodec
	{
	public:
		CImageCodec() {};
		virtual ~CImageCodec() {};
		virtual int ReadFile(wchar_t const*, TResultContainer *);
		virtual int ReadBuffer(uchar *, uint, TResultContainer *) = 0;
		virtual int WriteFile(wchar_t const*, int, TRawImageContainer *);
		virtual int WriteFile(char const*, int, TRawImageContainer *);
		virtual int WriteBuffer(uchar **, uint *, int, TRawImageContainer *) = 0;
		virtual int GetFileImageInfo(wchar_t const*, imaging::RI_ImageInfo *);
		virtual int GetBufferImageInfo(uchar *, uint, imaging::RI_ImageInfo *) = 0;
		virtual int QuickDetectFormat(uchar *, uint);

		int MapFile(wchar_t const*, uchar **, uint *);
		int UnmapFile(uchar **, uint *);
		static uint CalculateRowStride(uint, uint, uint);
		static TRawImageContainer* AllocateRawImageContainer(uint, int, int, int, int, int);
		static TRawImageContainer* AllocateRawImageContainer(uint, uint, int, int, int, int, int);
		static bool Make24bits(tagBITMAPINFO *, uchar *, tagBITMAPINFO *, uchar *);
		static bool MakeGrayscale(tagBITMAPINFO *, uchar *, tagBITMAPINFO *, uchar *);
		static ushort GetDensity(int, imaging::eRI_Density_Units);
		void SwapRedBlue(uchar *, uint, uint, uint);
	};

	class CJpg2KImageCodec : public CImageCodec
	{
	public:
		CJpg2KImageCodec() {};
		virtual ~CJpg2KImageCodec() {};
		int ReadFile(wchar_t const*, TResultContainer *);
		int ReadBuffer(uchar *, uint, TResultContainer *);
		int WriteFile(wchar_t const*, int, TRawImageContainer *);
		int WriteBuffer(uchar **, uint *, int, TRawImageContainer *);
		int GetFileImageInfo(wchar_t const*, imaging::RI_ImageInfo *);
		int GetBufferImageInfo(uchar *, uint, imaging::RI_ImageInfo *);
		int QuickDetectFormat(uchar *, uint);
	};

	class CJpegImageCodec : public CImageCodec
	{
	public:
		CJpegImageCodec() {};
		virtual ~CJpegImageCodec() {};
		int ReadFile(wchar_t const*, TResultContainer *);
		int ReadBuffer(uchar *, uint, TResultContainer *);
		//int WriteFile(wchar_t const*, int, TRawImageContainer *);
		int WriteBuffer(uchar **, uint *, int, TRawImageContainer *);
		int GetFileImageInfo(wchar_t const*, imaging::RI_ImageInfo *);
		int GetBufferImageInfo(uchar *, uint, imaging::RI_ImageInfo *);
		int QuickDetectFormat(uchar *, uint);
		int WriteJpegHelper(jpeg_compress_struct *, int, TRawImageContainer *);
	};

	class CBmpImageCodec : public CImageCodec
	{
	public:
		CBmpImageCodec() {};
		virtual ~CBmpImageCodec() {};
		int ReadFile(wchar_t const*, TResultContainer *);
		int ReadBuffer(uchar *, uint, TResultContainer *);
		int WriteFile(wchar_t const*, int, TRawImageContainer *);
		int WriteBuffer(uchar **, uint *, int, TRawImageContainer *);
		int GetFileImageInfo(wchar_t const*, imaging::RI_ImageInfo *);
		int GetBufferImageInfo(uchar *, uint, imaging::RI_ImageInfo *);
		int QuickDetectFormat(uchar *, uint);
	};

	int ExecuteCommand(imaging::eRI_Commands, imaging::RI_Parameters *);
	int WriteToBuffer(imaging::RI_SaveFileParameters *, TResultContainer const&);
	bool CleanupCurrentThreadResources();
	void FreeMemory(uchar *);
	uchar* AllocateMemory(ulong);
};

