#include "procmgrdefault.h"
#include "rclhelp.h"
#include "common/container/jsoncpp.h"
#include "common/common.h"
#include "imagemanipulation.h"
#include "sdk/SecurityFeatureCheck.h"
#include "sdk/AuthenticityCheckResult.h"
#include "status.h"
#include "xml/XmlSerializerInternal.h"
#include "packageversion.h"
#include "common/UnicodeUtils.h"
#include "common/container/DePersonalizer.h"

namespace procmgrdefault
{
	struct gProcMgr_global_registrator {
		shared_ptr<ProcMgrDefault> gProcMgr;
		gProcMgr_global_registrator() {
			gProcMgr = common::getModuleOrchestrator()->addModule<ProcMgrDefault>();
		}
	} gProcMgr_global_registrator_;

	namespace jsonResponse
	{
		namespace def
		{
			string notReady()
			{
				return string("{\"ProcessingFinished\":0}");
			}
		}
		int getProcessingFinishedStatus(Json::Value const& a1, int a2)
		{
			return a1.get("ProcessingFinished", Json::Value(a2)).asInt();
		}
	}

	namespace jsonRequest
	{
		string getScenario(Json::Value &a2)
		{
			string ret;
			if (a2.isMember("processParam"))
			{
				ret = a2["processParam"]["scenario"].asString();
			}
			return ret;
		}

		processmanagerdefault::scenario::eProcessScenario getScenarioType(Json::Value &a1)
		{
			if (a1.isMember("processParam") && a1["processParam"].isMember("scenario") && a1["processParam"]["scenario"].isString())
				return processmanagerdefault::scenario::convert(a1["processParam"]["scenario"].asString());
			return processmanagerdefault::scenario::ProcessScenario_0;
		}

		bool getMRZProcessAsImage(Json::Value &a1)
		{
			if (a1["processParam"]["customParams"]["boundsParam"].isMember("checkVariants"))
			{
				return true;
			}
			return a1["boundsParam"].isMember("checkVariants");
		}
	}

	namespace utils
	{
		void flipResults(common::container::RclHolder & a1, tagSIZE & a2, ProcessParamsHolder & a3)
		{
			if (a3.m_fPPH_doExtendProcessingMode)
			{
				TRawImageContainer *pRIC = (TRawImageContainer *)rclhelp::getContainerContent(&a1.m_xTRCL, 1);

				if (pRIC && pRIC->pxRIC_bmi && pRIC->pRIC_data && pRIC->pxRIC_bmi->bmiHeader.biHeight && a2.cy)
				{
					for (size_t i = 0; i < a1.m_xTRCL.nTRCL_Count; i++)
					{
						if (a1.m_xTRCL.pTRCL_TRC[i].u.pTRC_CHAR)
						{
							int n10 = a1.m_xTRCL.pTRCL_TRC[i].nTRC_result_type;
							if (n10 == 85 || n10 == 62 || n10 == 61)
							{
								TSDKProcessingClass::FlipPointY(a1.m_xTRCL.pTRCL_TRC[i].u.pTRC_TBR->xTBR_Center, a2);
								TSDKProcessingClass::FlipPointY(a1.m_xTRCL.pTRCL_TRC[i].u.pTRC_TBR->xTBR_LeftTop, a2);
								TSDKProcessingClass::FlipPointY(a1.m_xTRCL.pTRCL_TRC[i].u.pTRC_TBR->xTBR_LeftBottom, a2);
								TSDKProcessingClass::FlipPointY(a1.m_xTRCL.pTRCL_TRC[i].u.pTRC_TBR->xTBR_RightTop, a2);
								TSDKProcessingClass::FlipPointY(a1.m_xTRCL.pTRCL_TRC[i].u.pTRC_TBR->xTBR_RightBottom, a2);
							}
							else if (n10 == 6)
							{
								TDocGraphicsInfo* pDGI = a1.m_xTRCL.pTRCL_TRC[i].u.pTRC_DGI;
								if (pDGI->nDGI_nFields && pDGI->pDGI_pArrayFields)
								{
									for (uint j = 0; j < pDGI->nDGI_nFields; j++)
									{
										TSDKProcessingClass::FlipRectY(pDGI->pDGI_pArrayFields[j].xDGF_FieldRect, a2);
									}
								}
							}
						}
					}
				}
			}
		}
		void getModulesAndScenariosInfo(vector<processmanagerdefault::IModuleStatus*>& a1, string& a2)
		{
			using namespace processmanagerdefault::scenario;
			eRPRM_Capabilities cap = RPRM_Capabilities_0;
			/*if (licensing::getLicense())
			{
				cap = licensing::getLicense().getCapabilities();
			}*/
			vector<eProcessScenario> vecScenarios = getAvailableScenarios(cap);
			vector<processmanagerdefault::IModuleStatus *> vecModules = filterModulesByInitStatus(a1);
			vector<eProcessScenario> vecFilterScenario = filterScenarioByModules(vecScenarios, getModulesType(vecModules));
			Json::Value jv0(Json::json_type_array);
			for (vector<eProcessScenario>::iterator iterScenario = vecFilterScenario.begin(); vecFilterScenario.end() != iterScenario; iterScenario ++)
			{
				//Log("ready for use: \"%s\"", convert(*iterScenario).data());
				Json::Value jv1(Json::json_type_null);
				jv1["name"] = Json::Value(convert(*iterScenario));
				jv1["frameOrientation"] = Json::Value(getOrientation(*iterScenario));
				jv1["frameKWHLandscape"] = Json::Value(getProportionLandscape(*iterScenario));
				jv1["frameKWHPortrait"] = Json::Value(getProportionPortrait(*iterScenario));
				jv1["frameKWHDoublePageSpreadLandscape"] = Json::Value(getProportionLandscapeDoublePageSpread(*iterScenario));
				jv1["frameKWHDoublePageSpreadPortrait"] = Json::Value(getProportionPortraitDoublePageSpread(*iterScenario));
				int nMode = getBarcodeExtMode(*iterScenario);
				if (nMode)
				{
					jv1["barcodeExt"] = Json::Value(nMode);
				}
				nMode = getFaceExtMode(*iterScenario);
				if (nMode)
				{
					jv1["faceExt"] = Json::Value(nMode);
				}
				nMode = getMultiPageOffMode(*iterScenario);
				if (nMode)
				{
					jv1["multiPageOff"] = Json::Value(nMode);
				}
				if (isSupportSeriesProcessMode(*iterScenario))
				{
					jv1["seriesProcessMode"] = Json::Value(true);
				}
				if (getUVTorch(*iterScenario))
				{
					jv1["UVTorch"] = Json::Value(true);
				}
				if (getManualCrop(*iterScenario))
				{
					jv1["manualCrop"] = Json::Value(true);
				}
				string strDesc = getDescription(*iterScenario);
				if (strDesc.size())
				{
					jv1["desc"] = Json::Value(strDesc);
				}
				string strCaption = getCaptionForScenario(*iterScenario);
				if (strCaption.size())
				{
					jv1["caption"] = Json::Value(strCaption);
				}
				jv0.append(jv1);
			}
			Json::Value jv2(Json::json_type_null);
			jv2["scenario"] = Json::Value(jv0);
			for (vector<processmanagerdefault::IModuleStatus *>::iterator iter = vecModules.begin(); iter != vecModules.end(); ++iter)
			{
				string strType = processmanagerdefault::convert((*iter)->type());
				if (strType.size())
				{
					jv2["initialized"][strType] = Json::Value(true);
				}
			}
			jv2["coreInfo"]["CoreMode"] = Json::Value(packageversion::getCoreMode());
			jv2["coreInfo"]["CoreVersion"] = Json::Value(packageversion::getCoreVersion());
			jv2["coreInfo"]["DocList"] = Json::Value(packageversion::getDocList());
			common::container::jsoncpp::convert(jv2, a2);
		}
	}

	ContainerTypeContol::ContainerTypeContol()
	{
		m_vCTC_C = { 1, 0x10, 6, 0x61, 0x55, 9, 0x11, 0xF, 0x24, 0x25, 0x21 ,7, 3, 0x3D, 0x42, 0x57, 5, 0x12, 0x13, 0x3E, 0x14 ,0x1E, 0x22, 0x65, 0x66, 0x67, 0x68, 0x69 };
		m_vCTC_0.assign(m_vCTC_C.begin(), m_vCTC_C.end());
		m_vCTC_18.assign(m_vCTC_C.begin(), m_vCTC_C.end());
	}
	ContainerTypeContol::~ContainerTypeContol()
	{

	}

	ProcMgrDefault::ProcMgrDefault()
		: m_xPMD_C0(""), m_xPMD_E0(""), m_xPMD_4A0(""), m_xPMD_4C0(""), m_xPMD_4E0("")
	{
		m_nPMD_88 = 0;
		m_nPMD_8C = 0;
		m_nPMD_90 = 0;
		m_fPMD_94 = false;
		m_fPMD_95 = false;
		m_fPMD_96 = true;

		m_fPMD_B0 = false;

		m_nPMD_3A4 = 0;
		m_fPMD_3A8 = false;

		m_nPMD_498 = 0;
		m_ePMD_470 = processmanagerdefault::scenario::ProcessScenario_0;

		m_vPMD_464 = { &m_xPMD_ImageQuality, &m_xPMD_DocBoundLocator, &m_xPMD_MrzDetector, &m_xPMD_Lex, &m_xPMD_RecPass, &m_xPMD_Bind, &m_xPMD_ImSegger, &m_xPMD_Id3Rus, &m_xPMD_BarcodesMT, &m_xPMD_ExtBarcodeReader, &m_xPMD_CodeConverter, &m_xPMD_GraphicFieldCropper, /*&m_xPMD_2B0,*//* &m_xPMD_CanDetector,*/ &m_xPMD_CreditCard, &m_xPMD_Authenticity, &m_xPMD_ExtPortraitProcessor, &m_xPMD_FaceDetector };

		vector<processmanagerdefault::IModuleStatus*> vpI2 = { &m_xPMD_RecPass };
		m_xPMD_ImSegger.m_vIMS_field_4 = processmanagerdefault::ScenarioRelations::setRelations(vpI2);

		for (size_t i = 0; i < m_vPMD_464.size(); i++)
		{
			m_vPMD_458.push_back(m_vPMD_464[i]);
			m_vPMD_464[i]->m_pTSDKPC_RH_field_1C = &m_xPMD_18;
		}

		Clear();
	}

	ProcMgrDefault::~ProcMgrDefault()
	{
		free();
	}

	void ProcMgrDefault::AddVisualFieldsFilter(ProcessParamsHolder & a2)
	{
		TDwordArray xTDA4;

		if (!a2.m_vPPH_fieldTypesFilter.empty())
		{
			xTDA4.nTDA_count = a2.m_vPPH_fieldTypesFilter.size();
			xTDA4.pnTDA_array = (uint*)a2.m_vPPH_fieldTypesFilter.data();
			m_xPMD_4.addNewCopy(77, &xTDA4, 0);
		}
	}

	void ProcMgrDefault::analyzeAuthResult(common::container::RclHolder & a2, string& a3)
	{
		TResultContainer * pTRC5 = rclhelp::findFirstContainer(a2.m_xTRCL, 20);
		if (pTRC5)
		{
			TAuthenticityCheckList* pACL = pTRC5->u.pTRC_ACL;
			TAuthenticityCheckResult* pACR = 0;
			bool v9 = false;
			for (int i = 0; i < pACL->nACL_Count; i ++)
			{
				if (pACL->ppACL_List[i]->nACR_Type == 1)
				{
					pACR = pACL->ppACL_List[i];
				}
				else
				{
					if (pACL->ppACL_List[i]->nACR_Type == 4 && pACL->ppACL_List[i]->nACR_Result == 1)
					{
						if (pACL->ppACL_List[i]->nACR_Count == 1)
						{
							int* v13 = (int*)*pACL->ppACL_List[i]->ppACR_List;
							if (!v13[10] || v13[1] != 0x80)
								break;
						}
						v9 = true;
					}
				}
			}
			if (!v9)
			{
				if (pACR)
				{
					for (int i = 0; i < pACR->nACR_Count; ++i)
					{
						int* v16 = (int*)pACR->ppACR_List[i];
						if (!v16[1])
						{
							*v16 = 0x350000;
							pACR->nACR_Result = 0;
						}
					}
				}
				else
				{
					TAuthenticityCheckList acl;
					acl.nACL_Count = pACL->nACL_Count + 1;
					vector<TAuthenticityCheckResult *> v28(acl.nACL_Count);
					acl.ppACL_List = v28.data();
					for (int i = 0; i < pACL->nACL_Count; ++i)
					{
						acl.ppACL_List[i] = pACL->ppACL_List[i];
					}
					SecurityFeatureCheck sfc;
					sfc.setElementDiagnose(CheckDiagnose_35);
					sfc.setElementResult(CheckResult_0);
					sfc.setFeatureType(0);
					tagSIZE sz = rclhelp::imageSize(a2.m_xTRCL);
					if (sz.cx && sz.cy)
					{
						tagRECT rc;
						rc.right = sz.cx - 1;
						rc.bottom = sz.cy - 1;
						rc.left = 0;
						rc.top = 0;
						sfc.setRect(rc);
					}
					AuthenticityCheckResult acr;
					acr.nACR_Type = 1;
					acr.add(sfc);
					acr.generateCommonResult();
					acl.ppACL_List[acl.nACL_Count - 1] = common::container::Duplicate(&acr, 0);
					a2.remove(20);
					a2.addNewCopy(20, &acl, RPRM_Lights_0);
				}
				a3 = a2.toJson();				
			}
		}
	}

	int ProcMgrDefault::checkTimeout(void)
	{
		if (!m_xPMD_4A0.m_fTimer_C || !m_nPMD_498)
		{
			return 0;
		}

		if (m_nPMD_498 < m_xPMD_4A0.getTimeDeltaMs())
		{
			return 1;
		}
		return 0;
	}

	void ProcMgrDefault::Clear(void)
	{
		for (size_t i = 0; i < m_vPMD_464.size(); i++)
		{
			m_vPMD_464[i]->StartNewDocument();
		}

		m_xPMD_2C.clear();
		m_bsPMD_7C.clear();
		m_vPMD_98.clear();
		m_nPMD_88 = 0;
		m_nPMD_3A4 = 0;
		m_fPMD_3A8 = false;
		m_fPMD_94 = 0;
		m_fPMD_95 = 0;
		m_xPMD_C0.clear();
		m_xPMD_E0.clear();
		StartNewPage(true);
	}
	void ProcMgrDefault::free(void)
	{
		Clear();

		for (size_t i = 0; i < m_vPMD_464.size(); i++)
		{
			m_vPMD_464[i]->Free(false);
		}
		m_xPMD_18.clear();
		m_xPMD_2C.clear();
		m_xPMD_68.clear();
	}
	void ProcMgrDefault::generateResult(int a2, Json::Value const & a3, ProcessParamsHolder & a4, string& a5, void ** a6)
	{
		string v95;
		if (a3["trans_id"].isString())
		{
			v95 = a3["trans_id"].asString();
		}
		int v13 = 1;
		if (a2 != 12204)
		{
			if (a2 != 12213 && a2 != 12500)
			{
				if (m_nPMD_500 || processmanagerdefault::scenario::isProcessFinished(m_ePMD_470, m_vPMD_458, false))
				{
					v13 = 1;
				}
				else
				{
					v13 = isNeedStopByTimers(a3) ? 2 : 0;
				}
			}
		}
		//if (v13) Log("statusFinish: READY!!!");
		//else Log("statusFinish: not ready");
		Json::Value jv(Json::json_type_null);
		jv["ProcessingFinished"] = Json::Value(v13);
		jv["elapsedTime"] = Json::Value((uint)m_xPMD_C0.getTimeDeltaMs());
		if (m_xPMD_E0.getTimeDeltaMs())
			jv["elapsedTimeRFID"] = Json::Value((uint)m_xPMD_E0.getTimeDeltaMs());
		m_xPMD_4.remove(1, RPRM_Lights_2000000);
		m_xPMD_4.remove(97);
		m_xPMD_18.remove(85);
		common::container::RclHolder rh;
		vector<TResultContainer*> vecTRC = m_xPMD_4.getRcList();
		for (uint i = 0; i < vecTRC.size(); i++)
		{
			vector<TResultContainer> vec = rclhelp::filter(rclhelp::filterByPage(m_xPMD_18.getContainers(), (int)vecTRC[i]->nTRC_page_idx), (eRPRM_ResultType)vecTRC[i]->nTRC_result_type);
			if (vec.empty()) rh.addNoCopy(*vecTRC[i]);
			else if (vecTRC[i]->nTRC_result_type != 20 && vecTRC[i]->nTRC_result_type != 87)
			{
				m_xPMD_18.remove(vec);
				rh.addNoCopy(*vecTRC[i]);
			}
		}
		m_xPMD_18.addCopy(rh.m_xTRCL);
		m_xPMD_40.clear();
		if (v13)
		{
			m_xPMD_2C.addCopy(m_xPMD_18.getRcList());
			m_xPMD_C0.stop();
		}
		else
		{
			common::container::RclHolder rh1(m_xPMD_18);
			rh1.remove(1);
			rh1.remove(16);
			m_xPMD_40.addCopy(rh1.m_xTRCL);
		}
		m_xPMD_40.addNoCopy(m_xPMD_2C);
		rclhelp::page::sortByFaceMrz(m_xPMD_40);
		rclhelp::page::updatePageIndexFrom0Step1(m_xPMD_40);
		common::container::generateImagesContainer(m_xPMD_40, m_xPMD_40);
		m_xPMD_54.clear();
		m_xPMD_54.addNoCopy(m_xPMD_40.getRcList(v13 ? m_xPMD_474.m_vCTC_0 : m_xPMD_474.m_vCTC_C));
		status::StatusGenerator sg;
		sg.generateStatus(m_xPMD_54, a4, m_xPMD_54);
		vector<int> v98 = { 0xF, 0x24, 0x25, 0x21, 0x62, 0x5F };
		rclhelp::page::setPageIndex(m_xPMD_54.getRcList(v98), 0);
		rclhelp::page::setPageIndex(m_xPMD_54.getRcList(common::container::rfidContainerTypes()), 0);
		if (v13)
		{
			common::container::DePersonalizer dp((Json::Value)a3);
			if (dp.IsActive())
				dp.Process(m_xPMD_54);
		}
		if (a4.m_fPPH_xmlResults)
		{
			XmlSerializerInternal xsi;
			xsi.bXSI_field_7C = true;
			xsi.wsXSI_field_70 = common::UnicodeUtils::UncheckedUtf8ToWStr(packageversion::getCoreVersion());
			xsi.wsXSI_field_40 = common::UnicodeUtils::UncheckedUtf8ToWStr(packageversion::getCoreVersion());
			xsi.wsXSI_field_4C = wstring(L"Virtual Reader");
			xsi.bXSI_field_7E = true;
			xsi.xXSI_TGF = TGraphicFormats::CreateById(ImageFormat_1, 0);
			xsi.bXSI_field_7D = false;
			if (v95.size())
				xsi.sXSI_field_34 = v95;
			xsi.makeXML(m_xPMD_54.m_xTRCL);
		}
		if (a6)
			*a6 = &m_xPMD_54;
		if (v13)
		{
			if (!m_xPMD_2C.getRcList(3).empty())
			{
				if (!rclhelp::bounds::getBoundsResult(m_xPMD_2C, BoundsResultStatus_2).empty())
					m_fPMD_94 = true;
			}
			int nVal = 0;
			updateUnprocessedDocIdListForDoc(nVal);
			jv["morePagesAvailable"] = Json::Value(nVal);
		}
		else
		{
			jv["morePagesAvailable"] = Json::Value(-1);
			updateDocIdListForCurrentFramesSeries(a4.getOption(processparams::PROCESSMODE_doublePageSpread));
			if (m_fPMD_96) updateStatusFrameSeriesWithoutMrz();
		}
		int v46;
		if (m_fPMD_3A8)
		{
			v46 = 1;
		}
		else
		{
			bool v50 = false;
			TDocVisualExtendedInfo* v47 = (TDocVisualExtendedInfo*)rclhelp::getContainerContent(&m_xPMD_4.m_xTRCL, 18);
			if (v47)
			{
				v50 = common::textdoc::getValue(*v47, VisualFieldType_33).size() ? true : false;
			}
			if (m_xPMD_MrzDetector.isResultReady())
				m_fPMD_3A8 = true;
			else
				m_fPMD_3A8 = v50 | m_xPMD_CanDetector.isResultReady();
			v46 = m_fPMD_3A8;
		}
		if (v13)
		{
			if (m_nPMD_3A4 == 1) v46 = 1;
			else
			{
				if ((a4.m_nPPH_processParam & 0x20) && m_xPMD_RecPass.m_bTSDKPC_IsResReady)
					v46 = m_xPMD_RecPass.m_nTRP_field_2C;
				m_nPMD_3A4 = v46;
			}
		}
		else
		{
			v46 = this->m_nPMD_3A4;
		}
		jv["ChipPage"] = Json::Value(v46);
		pair<processmanagerdefault::eResolutionType, vector<eRPRM_Lights>> pa;
		if (!a4.getOption(processparams::PROCESSMODE_switchToUvProcessImage))
		{
			vector<processmanagerdefault::eModuleType> v83;
			if (a2 != 12204 && a2 != 12213 && a2 != 12500)
				processmanagerdefault::scenario::isProcessFinished(m_ePMD_470, m_vPMD_458, v83);
			vector<pair<processmanagerdefault::eResolutionType, vector<eRPRM_Lights>>> v85 =
				processmanagerdefault::scenario::needRequirements(m_vPMD_464, v83);
			if (!v83.empty())
				pa = processmanagerdefault::scenario::getPriorityRequirements(v85);
		}
		else
		{
			jv["cmdProcess"] = Json::Value("imageProcess");
			vector<eRPRM_Lights> v85 = { RPRM_Lights_6, RPRM_Lights_80, RPRM_Lights_0 };
			pa.first = processmanagerdefault::ResolutionType_0;
			pa.second = v85;
		}
		if (!pa.second.empty())
		{
			jv["resolutionType"] = Json::Value((int)pa.first);
			for (uint i = 0; i < pa.second.size(); i ++)
			{
				jv["lightType"].append(Json::Value(pa.second[i]));
			}
		}
		common::container::jsoncpp::convert(jv, a5);
		if (v13)
			m_fPMD_B0 = true;
	}

	vector<int> ProcMgrDefault::getCommands(void)
	{
		static vector<int> vi_1129908 = {0x2FAB, 0x2FAC, 0x2FA9, 0x2FAA, 0x2FAE, 0x2FAD, 0x2FB1 ,0x2FB4, 0x2FB5, 0x30D4, 0x2FB2, 0x2FB6, 0xCD, 0xCE};
		return vi_1129908;
	}
	
	void ProcMgrDefault::init(void * a2, char * a3)
	{
		for (size_t i = 0; i < m_vPMD_464.size(); i++)
		{
			m_vPMD_464[i]->Init(a2, a3);
		}
	}
	
	bool ProcMgrDefault::isNeedStopByTimers(Json::Value const& a2)
	{
		int n5 = a2["processParam"].get("timeoutFromFirstDocType", 0).asInt();
		int n7 = a2["processParam"].get("timeoutFromFirstDetect", 0).asInt();
		if (n5 && m_xPMD_4E0.m_fTimer_C && n5 < m_xPMD_4E0.getTimeDeltaMs())
			return true;
		if (n7 && m_xPMD_4C0.m_fTimer_C && n7 < m_xPMD_4C0.getTimeDeltaMs())
			return true;
		int n10 = a2["processParam"].get("timeout", 0).asInt();
		if (n10 && m_xPMD_4A0.m_fTimer_C && n10 < m_xPMD_4A0.getTimeDeltaMs())
			return true;
		return false;
	}

	int ProcMgrDefault::process(int a2, void * a3, const char * a4, void ** a5, char ** a6)
	{
		TResultContainerList *pRCL8 = (TResultContainerList *)a3;
		
		if (a2 == 0x2FB6)
			return checkTimeout();
		
		string bs240;

		if (a4)
		{
			bs240 = string(a4);
		}

		Json::Value jv258(Json::json_type_null);
		common::container::jsoncpp::convert(bs240, jv258);
		m_ePMD_470 = processmanagerdefault::scenario::convert(jv258["processParam"]["scenario"].asString());

		if (a2 == 0x2FAC && m_ePMD_470 == processmanagerdefault::scenario::ProcessScenario_Id3Rus)
		{
			jv258["processParam"]["scenario"] = Json::Value(processmanagerdefault::scenario::convert(processmanagerdefault::scenario::ProcessScenario_FullProcess));
			common::container::jsoncpp::convert(jv258, bs240);
		}

		int n274 = 1;
		common::container::RclHolder rh288(pRCL8, true);
		if (a2 == 0x2FA9)
		{
			rh288.setPageIndex(m_nPMD_88);
		}

		if (jv258["processParam"].isMember("timeout"))
		{
			m_nPMD_498 = jv258["processParam"]["timeout"].asInt();
		}

		if (jv258["processParam"].isMember("deviceId"))
		{
			TDeviceType xDT3a;
			xDT3a.nTDT_devType = 0;
			xDT3a.nTDT_cameraIndex = 0;
			xDT3a.nTDT_bayerMatrix = 0;
			xDT3a.nTDT_flip = 0;
			xDT3a.nTDT_resultLightType = 0;
			xDT3a.nTDT_devClass = 0;
			xDT3a.nTDT_execLightCompensation = 0;
			xDT3a.nTDT_execColorCompensation = 0;
			xDT3a.nTDT_execContrastEnhancement = 0;
			xDT3a.nTDT_execGrayFromColor = 0;
			xDT3a.nTDT_lightOVDLevel = 0;
			xDT3a.nTDT_2C = 0;
			xDT3a.nTDT_30 = 0;
			xDT3a.nTDT_devType = jv258["processParam"]["deviceId"].asInt();
			rh288.addNewCopy(82, &xDT3a, 0);
		}

		RclHolder rh29C;

		if (a2 == 0x2FAC && rh288.hasRc(1, RPRM_Lights_80))
		{
			vector<TResultContainer> vrc3a = rclhelp::filter(rh288.getContainers(), RT_TRawImageContainer_1);
			vector<TResultContainer> vrc2a = rclhelp::filterByExposure(vrc3a, 1);

			if (!vrc2a.empty())
			{
				vector<TResultContainer> vrc0 = rclhelp::filter(rclhelp::filterByExposure(vrc3a, 0), RPRM_Lights_80);
				rh29C.addNoCopy(vrc2a);
				rh29C.addNoCopy(vrc0);
				rh288.remove(vrc2a);
				rh288.remove(vrc0);
			}
		}
		else
		{
			rh288.remove(1, RPRM_Lights_80);
		}

		ProcessParamsHolder pph210(bs240);

		if (a2 == 0x2FA9 || a2 == 0x2FAA || a2 == 0x2FAC || a2 == 0x30D4)
		{
			m_ePMD_470 = processmanagerdefault::scenario::convert(pph210.m_sPPH_scenario);

			if (m_ePMD_470)
			{
				processmanagerdefault::scenario::convertScenario(m_ePMD_470, m_xPMD_2C, pph210);
			}

			setProcessParamsByLoadedModules(pph210);

			if (!m_ePMD_470)
			{
				m_ePMD_470 = processmanagerdefault::scenario::convert(pph210);
			}

			if ((pph210.m_nPPH_processParam & 0x10) && m_ePMD_470 != processmanagerdefault::scenario::ProcessScenario_0 && m_ePMD_470 != processmanagerdefault::scenario::ProcessScenario_Locate && 
				m_ePMD_470 != processmanagerdefault::scenario::ProcessScenario_MrzOrLocate && m_ePMD_470 != processmanagerdefault::scenario::ProcessScenario_CreditCard)
			{
				pph210.SetMode(RPRM_GetImage_Modes_4, 1);
			}
		}

		RclHolder rh2B0;
		TRawImageContainer* pRIC;

		switch (a2)
		{
		case 0x2FA9:
		case 0x2FAA:
		case 0x2FAC:
		{
			if (!m_xPMD_4A0.m_fTimer_C)
			{
				m_xPMD_4A0.reset();
			}

			bool f_r6 = true;

			if (a2 == 0x2FAC)
			{
				if (m_ePMD_470 == processmanagerdefault::scenario::ProcessScenario_FullAuth)
				{
					if (rh288.size() + rh29C.size() <= 3)
					{
						if (!rclhelp::filterByExposure(rclhelp::filter(rh288.getContainers(), RT_TRawImageContainer_1), 1).empty())
						{
							break;
						}
					}
				}
				f_r6 = false;
			}

			if (!m_xPMD_C0.m_fTimer_C)
			{
				m_xPMD_C0.start();
			}

			m_nPMD_8C++;

			if (m_ePMD_470 == processmanagerdefault::scenario::ProcessScenario_Id3Rus)
			{
				m_xPMD_2C.clear();
				moduleprocessgl::process(0x28F, 0, (char*)bs240.data(), 0, 0);
				m_xPMD_Id3Rus.Process(&rh288.m_xTRCL, m_xPMD_2C, m_bsPMD_B4, f_r6);
				string bs196;
				n274 = m_xPMD_GraphicFieldCropper.Process(&m_xPMD_2C.m_xTRCL, m_xPMD_2C, bs196);
				int n41 = jsonResponse::getProcessingFinishedStatus(common::container::jsoncpp::convert(m_bsPMD_B4), 0);

				m_fPMD_B0 = n41 ? true : false;
				Json::Value xJV196(Json::json_type_null);
				xJV196["ContainerList"] = Json::Value(common::container::jsoncpp::convert(common::container::json::ToJson(m_xPMD_2C.m_xTRCL)));
				xJV196["ProcessingFinished"] = Json::Value(n41);
				xJV196["ChipPage"] = Json::Value(0);
				common::container::jsoncpp::convert(xJV196, m_bsPMD_7C);

				if (a5)
				{
					if (!m_xPMD_2C.getRcList(1).empty())
					{
						*a5 = &m_xPMD_2C;
					}
				}

				if (a6)
				{
					if (m_bsPMD_7C.length())
					{
						*a6 = (char*)m_bsPMD_7C.data();
					}
				}

				if (a2 == 0x2FAC)
				{
					n274 = 0;
				}
				
				return n274;
			}

			if (!pph210.NeedProcess() || m_fPMD_B0)
			{
				n274 = 3;
				break;
			}

			StartNewFrame();

			m_xPMD_RecPass.resetForceDocIds();

			if (jv258["processParam"].isMember("forceDocID"))
			{
				m_xPMD_RecPass.setForceDocId(jv258["processParam"]["forceDocID"].asInt());
			}

			tagSIZE tsz159 = rclhelp::imageSize(rh288.m_xTRCL);
			rclhelp::generateWhiteGray(rh288);
			AddVisualFieldsFilter(pph210);
			m_xPMD_FaceDetector.AddFaceDetection(tsz159, jv258, rh288, m_xPMD_4, m_nPMD_88);

			vector<int> vi160(m_vPMD_A4);

			if (vi160.empty() && !m_vPMD_98.empty())
			{
				vi160 = m_vPMD_98;
			}

			if (vi160.empty() && !pph210.m_vPPH_documentIdList.empty())
			{
				vi160 = pph210.m_vPPH_documentIdList;
			}

			if (!vi160.empty())
			{
				rclhelp::docinfo::addMainDocumentInfo(vi160, m_xPMD_4);
				if (!m_xPMD_MrzDetector.m_bTSDKPC_IsFinished && !rclhelp::docdesc::isDocsHasMrz(vi160, true))
				{
					m_xPMD_MrzDetector.m_bTSDKPC_IsFinished = true;
				}
			}

			uniteRcl_Frame_sourceRcl(rh2B0, &rh288.m_xTRCL);

			if (m_xPMD_ExtBarcodeReader.NeedProcess(pph210, rh2B0.m_xTRCL))
			{
				n274 = m_xPMD_ExtBarcodeReader.Process(&rh288.m_xTRCL, m_xPMD_4, m_bsPMD_B4);
				if (!n274)
				{
					uniteRcl_Frame_sourceRcl(rh2B0, &rh288.m_xTRCL);
				}
			}

			bool f_r4 = jv258["processParam"].get("forceReadMrzAfterLocate", false).asBool() || rh2B0.hasRc(85);
			bool f38C = procmgrdefault::jsonRequest::getMRZProcessAsImage(jv258);

			if (a2 == 0x2FA9)
			{
				if ((m_xPMD_MrzDetector.m_bTSDKPC_IsResReady && !f_r4) || f38C)
				{
					m_xPMD_MrzDetector.m_bTSDKPC_IsFinished = false;
					m_xPMD_MrzDetector.m_bTMD_IsResReady = false;
				}
			}

			if (!jv258["processParam"].get("mrzDetect", true).asBool() || f_r4)
			{
				m_xPMD_MrzDetector.m_bTSDKPC_IsFinished = true;
			}

			if (!isProcessFinished(m_ePMD_470, m_vPMD_458, true) && m_xPMD_MrzDetector.NeedProcess(pph210, rh2B0.m_xTRCL))
			{
				if (m_fPMD_95)
				{
					m_xPMD_MrzDetector.m_bTSDKPC_IsFinished = true;
				}
				else
				{
					string bs0_0;
					common::container::jsoncpp::convert(jv258, bs0_0);
					n274 = m_xPMD_MrzDetector.ReadMrzWithDetector(f38C ? 0x2FAC : a2, &rh2B0.m_xTRCL, (char*)bs240.data(), m_xPMD_4, m_bsPMD_B4);

					if (a2 == 0x2FA9 && m_ePMD_470 == processmanagerdefault::scenario::ProcessScenario_MrzAndLocate && !m_xPMD_MrzDetector.isResultReady())
					{
						m_xPMD_MrzDetector.m_bTSDKPC_IsFinished = false;
						m_xPMD_MrzDetector.m_bTMD_IsResReady = false;
					}

					if (!m_xPMD_MrzDetector.isResultReady() && pph210.m_fPPH_doDetectCan)
					{
						if (m_xPMD_DocBoundLocator.NeedProcess(pph210, rh2B0.m_xTRCL))
						{
							n274 = m_xPMD_DocBoundLocator.FindDocumentLocation(a2, rh2B0, m_xPMD_4, bs240);
							TResultContainer* prc85 = rclhelp::findFirstContainer(m_xPMD_4.m_xTRCL, 85);
							if (prc85 && prc85->u.pTRC_CHAR)
							{
								rh2B0.addNoCopy(*prc85);
							}

							TResultContainer* prc86 = rclhelp::findFirstContainer(rh2B0.m_xTRCL, 85);
							if (prc86)
							{
								CDocFormat* pDF87 = (CDocFormat*)prc86->u.pTRC_CHAR;
								if (pDF87 && *pDF87 == DOCFORMAT_0)
								{
									n274 = m_xPMD_CanDetector.ReadCanWithDetector(&rh2B0.m_xTRCL, m_xPMD_4, m_bsPMD_B4);
								}
							}
						}
					}
				}
			}

			bool f88 = true;
			if (m_ePMD_470 == processmanagerdefault::scenario::ProcessScenario_MrzAndLocate)
			{
				if (f_r6)
				{
					if (!pph210.getOption(processparams::PROCESSMODE_multipageProcessing))
					{
						f88 = m_xPMD_MrzDetector.isResultReady();
					}
				}
			}
			bool f_r5 = isProcessFinished(m_ePMD_470, m_vPMD_458, true);
			uniteRcl_Frame_sourceRcl(rh2B0, &rh288.m_xTRCL);
			bool f384 = false;
			if (f88 && !f_r5 && m_xPMD_DocBoundLocator.NeedProcess(pph210, rh2B0.m_xTRCL))
			{
				if (rh2B0.hasRc(85))
				{
					f384 = true;
					m_xPMD_DocBoundLocator.m_bTSDKPC_IsFinished = true;
				}
				else
				{
					n274 = m_xPMD_DocBoundLocator.FindDocumentLocation(a2, rh2B0, m_xPMD_4, bs240);

					if (m_ePMD_470 == processmanagerdefault::scenario::ProcessScenario_MrzAndLocate)
					{
						if (!rclhelp::bounds::getBoundsResult(m_xPMD_4, BoundsResultStatus_2).empty())
						{
							rclhelp::bounds::removeBoundsResultWithoutMrz(m_xPMD_4);
						}
					}

					rclhelp::page::updateMrzContainerPageByBoundsResult(m_xPMD_4);

					m_xPMD_FaceDetector.RemoveUnsafeContainer(m_xPMD_4);
					m_xPMD_FaceDetector.RemoveUnsafeContainer(m_xPMD_18);
					m_xPMD_FaceDetector.RemoveUnsafeContainer(m_xPMD_2C);
					updateWorkDpi(jv258, rh288);

					if (m_xPMD_4.hasRc(9))
					{
						m_xPMD_MrzDetector.m_bTSDKPC_IsFinished = true;
					}
				}
			}

			uniteRcl_Frame_sourceRcl(rh2B0, &rh288.m_xTRCL);

			bool f91 = isProcessFinished(m_ePMD_470, m_vPMD_458, true);

			m_fPMD_96 = true;
			bool f_r11 = false;

			if (m_xPMD_DocBoundLocator.NeedCrop(pph210, rh2B0.m_xTRCL))
			{
				if (!m_xPMD_4C0.m_fTimer_C)
				{
					m_xPMD_4C0.reset();
				}

				n274 = m_xPMD_ImageQuality.LocateAndCheck(&rh2B0.m_xTRCL, m_xPMD_4, m_bsPMD_B4, (m_xPMD_DocBoundLocator.m_bTDBL_IsResReady == 0));

				f_r5 = rclhelp::qa::isInFocus(m_xPMD_4, false);

				if (!f_r5)
				{
					//Log("imageQualityResult: focus problem");
				}
				if (!rclhelp::qa::hasNoGlares(m_xPMD_4, false))
				{
					//Log("imageQualityResult: glares problem");
				}

				if (!pph210.getOption(processparams::PROCESSMODE_disableFocusingCheck))
				{
					m_fPMD_96 = f_r5;

					if (!f_r5)
					{
						m_xPMD_DocBoundLocator.m_bTSDKPC_IsFinished = false;
						//Log("imageQualityResult: block candidate by focus status");
						f_r11 = true;
					}
				}

				uniteRcl_Frame_sourceRcl(rh2B0, &rh288.m_xTRCL);
			}

			f_r5 = false;
			f38C = false;
			bool f394 = false;
						
			if (m_xPMD_DocBoundLocator.m_bTSDKPC_IsFinished && pph210.getOption(processparams::PROCESSMODE_manualCrop))
			{
				m_nPMD_500 = 1;
				f_r11 = true;
			}
			else if (!f_r11)
			{
				if (m_xPMD_4.hasRc(85))
				{
					setDPIFromBoundsResult(rh2B0);
				}

				if (!f91 && !m_xPMD_MrzDetector.NeedProcess(pph210, rh2B0.m_xTRCL)
					&& !m_xPMD_RecPass.NeedProcess(pph210, rh2B0.m_xTRCL)
					&& !m_xPMD_ImSegger.NeedProcess(pph210, rh2B0.m_xTRCL)
					&& !m_xPMD_BarcodesMT.NeedProcess(pph210, rh2B0.m_xTRCL))
				{
					m_xPMD_4.remove(1, RPRM_Lights_2000000);
					uniteRcl_Frame_sourceRcl(rh2B0, &rh288.m_xTRCL);
				}

				if (m_xPMD_DocBoundLocator.NeedCrop(pph210, rh2B0.m_xTRCL))
				{
					if (!m_xPMD_DocBoundLocator.m_bTDBL_IsResReady)
					{
						RclHolder rh50;

						if (rh29C.empty())
						{
							uniteRcl_Frame_sourceRcl(rh2B0, &rh288.m_xTRCL);
							cv::Size sz;
							n274 = m_xPMD_DocBoundLocator.locate(rh2B0, rh50, 0.0f, sz);
							if (jv258["processParam"].get("integralImage", false).asBool())
							{
								rh50.addNoCopy(m_xPMD_18);
								imagemanipulation::generateIntegralImage(rh50, m_xPMD_3AC);

								if (!m_xPMD_3AC.m_xiI_0.empty())
								{
									vector<TResultContainer *> vprc0_0 = rh50.getRcList(1);
									int n98 = 0;
									if (!vprc0_0.empty())
									{
										n98 = vprc0_0[0]->nTRC_page_idx;
									}
									rh50.remove(1);
									rh50.addNewWithOwnership(1, copyMatToRic(m_xPMD_3AC.m_xiI_0).release(), RPRM_Lights_18)->nTRC_page_idx = n98;
								}
							}
						}
						else
						{
							rh288.addNoCopy(rh29C.m_xTRCL);
							uniteRcl_Frame_sourceRcl(rh2B0, &rh288.m_xTRCL);
							rh2B0.remove(1, RPRM_Lights_2000000);
							f38C = imagemanipulation::checkBackgroundLight(rh2B0);
							RclHolder rh2C8;
							cv::Size sz;
							n274 = m_xPMD_DocBoundLocator.locate(rh2B0, rh2C8, 0.05f, sz);
							n274 = imagemanipulation::replaceUVByDiff(rh2C8, rh50, 0.05f, "");

							if (n274 == 2)
							{
								f394 = true;
							}

							if (n274 == 3)
							{
								f_r5 = true;
							}
						}

						rclhelp::generateWhiteGray(rh50);
						rh288.remove(1);
						m_xPMD_4.addCopy(rh50.getRcList(1));
						uniteRcl_Frame_sourceRcl(rh2B0, &rh288.m_xTRCL);

						if (!isProcessFinished(m_ePMD_470, m_vPMD_458, true) && (!f_r6 || m_fPMD_96))
						{
							if (pph210.getOption(processparams::PROCESSMODE_multipageProcessing))
							{
								m_nPMD_90++;

								if (m_xPMD_MrzDetector.NeedProcess(pph210, rh2B0.m_xTRCL))
								{
									n274 = m_xPMD_MrzDetector.ReadMrzWithDetector(a2, &rh2B0.m_xTRCL, (char*)bs240.data(), m_xPMD_4, m_bsPMD_B4);
									uniteRcl_Frame_sourceRcl(rh2B0, &rh288.m_xTRCL);
								}

								if (a2 == 0x2FA9 && !m_xPMD_MrzDetector.isResultReady() && m_ePMD_470 == processmanagerdefault::scenario::ProcessScenario_MrzAndLocate)
								{
									m_xPMD_MrzDetector.m_bTSDKPC_IsFinished = false;
									m_xPMD_MrzDetector.m_bTSDKPC_IsResReady = false;
								}

								if (!m_xPMD_MrzDetector.m_bTSDKPC_IsFinished && m_nPMD_90 >= 2 && rclhelp::docFormatFromDocumentPosition(rh2B0) != 2)
								{
									m_xPMD_MrzDetector.m_bTSDKPC_IsFinished = true;
								}
							}
						}
					}
				}
			}

			uniteRcl_Frame_sourceRcl(rh2B0, &rh288.m_xTRCL);

			if (!f_r11)
			{
				if (pph210.getOption(processparams::PROCESSMODE_creditcard))
				{
					if ((m_xPMD_DocBoundLocator.m_bTDBL_IsResReady || !pph210.m_fPPH_doExtendProcessingMode) && !m_xPMD_CreditCard.isResultReady())
					{
						n274 = m_xPMD_CreditCard.Process(&rh2B0.m_xTRCL, m_xPMD_4, m_bsPMD_B4);
						uniteRcl_Frame_sourceRcl(rh2B0, &rh288.m_xTRCL);
					}
				}
			}

			if (!isProcessFinished(m_ePMD_470, m_vPMD_458, 1) && !f_r11
				&& (pph210.m_nPPH_processParam & 0x20)
				&& (m_xPMD_DocBoundLocator.m_bTDBL_IsResReady || !pph210.m_fPPH_doExtendProcessingMode)
				&& !pph210.m_fPPH_stopOnMrz && m_xPMD_MrzDetector.m_bTSDKPC_IsFinished)
			{
				if (f_r4 && !m_xPMD_RecPass.m_bTSDKPC_IsResReady)
				{
					RclHolder xRH0_0;
					xRH0_0.addNoCopy(rh2B0.getRcListByPage(0));

					m_xPMD_MrzDetector.m_bTSDKPC_IsFinished = 0;
					m_xPMD_MrzDetector.m_bTSDKPC_IsResReady = 0;

					int n103 = rclhelp::imageResolution(xRH0_0.m_xTRCL);
					rclhelp::setResolution(xRH0_0.m_xTRCL, 0);
					n274 = m_xPMD_MrzDetector.ReadMrzWithDetector(12204, &xRH0_0.m_xTRCL, (char*)bs240.data(), m_xPMD_4, m_bsPMD_B4);
					rclhelp::setResolution(xRH0_0.m_xTRCL, n103);

					if (f384)
					{
						tagPOINT tpt185 = rclhelp::mrz::getMrzCenter(m_xPMD_4);
						if (tpt185.x && tpt185.y)
						{
							if (tpt185.y > rclhelp::imageSize(xRH0_0.m_xTRCL).cy / 2)
							{
								common::images::RotateImage(xRH0_0.m_xTRCL, imaging::RI_Rotations_2);
							}
						}
					}

					uniteRcl_Frame_sourceRcl(rh2B0, &rh288.m_xTRCL);
				}

				n274 = m_xPMD_RecPass.Recognize(a2, &rh2B0.m_xTRCL, bs240, m_xPMD_4, m_bsPMD_B4, m_nPMD_88);
				uniteRcl_Frame_sourceRcl(rh2B0, &rh288.m_xTRCL);

				if (n274 == 22)
				{
					m_xPMD_4.remove(98);
				}

				if (!n274 && m_xPMD_Bind.m_bTSDKPC_IsInitial)
				{
					if (!m_xPMD_4E0.m_fTimer_C)
					{
						m_xPMD_4E0.reset();
					}
					n274 = m_xPMD_Bind.Process(&rh2B0.m_xTRCL, m_xPMD_4, m_bsPMD_B4);
					uniteRcl_Frame_sourceRcl(rh2B0, &rh288.m_xTRCL);
				}
			}

			if (a2 == 0x2FA9)
			{
				if (!f_r11)
				{
					if (pph210.getOption(processparams::PROCESSMODE_uvTorchPresent) && m_xPMD_RecPass.m_bTSDKPC_IsResReady && m_ePMD_470 == processmanagerdefault::scenario::ProcessScenario_FullAuth)
					{
						pph210.setOption(processparams::PROCESSMODE_switchToUvProcessImage, true);
						f_r11 = true;
					}
				}
			}

			if (!isProcessFinished(m_ePMD_470, m_vPMD_458, true) && !f_r11
				&& m_xPMD_ImSegger.NeedProcess(pph210, rh2B0.m_xTRCL)
				&& m_xPMD_DocBoundLocator.m_bTDBL_IsResReady
				&& (m_xPMD_RecPass.m_bTSDKPC_field_17 || !pph210.m_fPPH_doExtendProcessingMode))
			{
				if (rh2B0.hasRc(1, RPRM_Lights_18))
				{
					rh2B0.remove(1, RPRM_Lights_18);
				}

				n274 = m_xPMD_ImSegger.Process(a2, &rh2B0.m_xTRCL, m_xPMD_4, bs240);
				uniteRcl_Frame_sourceRcl(rh2B0, &rh288.m_xTRCL);
			}

			if (!isProcessFinished(m_ePMD_470, m_vPMD_458, true) && !f_r11 && m_xPMD_BarcodesMT.NeedProcess(pph210, rh2B0.m_xTRCL))
			{
				if (m_ePMD_470 != processmanagerdefault::scenario::ProcessScenario_FullProcess || m_xPMD_RecPass.m_bTSDKPC_field_17)
				{
					n274 = m_xPMD_BarcodesMT.ReadBarcode(a2, &rh2B0.m_xTRCL, m_xPMD_4, bs240);
					uniteRcl_Frame_sourceRcl(rh2B0, &rh288.m_xTRCL);
				}
			}

			if (!f_r11 && m_xPMD_CodeConverter.NeedProcess(pph210, rh2B0.m_xTRCL))
			{
				n274 = m_xPMD_CodeConverter.Process(&rh2B0.m_xTRCL, bs240, m_xPMD_4, m_bsPMD_B4);
				uniteRcl_Frame_sourceRcl(rh2B0, &rh288.m_xTRCL);
			}

			if (m_xPMD_Lex.NeedProcess(pph210, rh2B0.m_xTRCL))
			{
				m_xPMD_Lex.setParams(bs240);

				int n109[2] = { 0xF , 0x24 };

				for (int i = 0; i < 2; i++)
				{
					m_xPMD_4.remove(n109[i]);
					m_xPMD_18.remove(n109[i]);
					m_xPMD_2C.remove(n109[i]);
				}

				uniteRcl_Frame_sourceRcl(rh2B0, &rh288.m_xTRCL);
				rh2B0.addNoCopy(m_xPMD_18.m_xTRCL);
				rh2B0.addNoCopy(m_xPMD_2C.m_xTRCL);
				n274 = m_xPMD_Lex.Process(&rh2B0.m_xTRCL, m_xPMD_4, m_bsPMD_B4);
				uniteRcl_Frame_sourceRcl(rh2B0, &rh288.m_xTRCL);
			}

			if (m_xPMD_DocBoundLocator.m_bTDBL_IsResReady && (m_xPMD_68.empty() || m_fPMD_96))
			{
				m_xPMD_68.remove(16);
				vector<TResultContainer *> vprc0_0 = rh288.getRcList(16);
				if (!vprc0_0.empty())
				{
					m_xPMD_68.addCopy(vprc0_0);
				}

				vector<shared_ptr<RclHolder>> vsp182 = rclhelp::splitByPage(m_xPMD_4);
				for (size_t i = 0; i < vsp182.size(); i++)
				{
					vector<TResultContainer *> vprc181 = vsp182[i]->getRcList(1);
					if (vprc181.empty())
						continue;
						
					vector<TResultContainer> vrc155 = rclhelp::filterByPage(m_xPMD_68.getContainers(), rclhelp::getPage(vsp182[i]->m_xTRCL));
					if (!rclhelp::filter(vrc155, RT_TOneCandidate_9).empty())
					{
						if (vsp182[i]->getRcList(9).empty())
							continue;
					}
					m_xPMD_68.remove(rclhelp::filter(vrc155, RT_TRawImageContainer_1));

					for (size_t j = 0; j < vprc181.size(); j++)
					{
						if (vprc181[j]->nTRC_light != RPRM_Lights_2000000)
						{
							m_xPMD_68.addCopy(*vprc181[j]);
						}
					}
				}
				if (a2 == 0x2FA9)
				{
					if (rclhelp::getPages(m_xPMD_68.m_xTRCL).size() >= 2)
					{
						m_xPMD_68.remove(rclhelp::filter(rclhelp::filterByPage(m_xPMD_68.getContainers(), 0), RT_TRawImageContainer_1));
					}
				}
			}

			if (m_xPMD_68.empty())
			{
				if (pph210.m_nPPH_processParam & 8)
				{
					if (m_xPMD_4.getRcList(1).empty())
					{
						m_xPMD_4.addCopy(rh288.getRcList(1));
					}
				}
			}
			else
			{
				m_xPMD_4.remove(1);
				m_xPMD_4.remove(16);
				m_xPMD_18.remove(1);
				m_xPMD_18.remove(16);
				m_xPMD_18.addNoCopy(m_xPMD_68.m_xTRCL);
			}

			if (pph210.m_nPPH_processParam & 4)
			{
				RclHolder xRH0_0;
				uniteRcl_Frame_sourceRcl(xRH0_0, &m_xPMD_18.m_xTRCL);

				if (m_xPMD_GraphicFieldCropper.NeedProcess(pph210, xRH0_0.m_xTRCL) && (a2 == 0x2FAC || isProcessFinished(m_ePMD_470, m_vPMD_458, 1)))
				{
					vector<RclHolder *> vrh184 = { &m_xPMD_18, &m_xPMD_4 };
					m_xPMD_FaceDetector.DetectFacesAndReplace(xRH0_0, m_xPMD_18, vrh184);
					uniteRcl_Frame_sourceRcl(xRH0_0, &m_xPMD_18.m_xTRCL);
					n274 = m_xPMD_GraphicFieldCropper.Process(&xRH0_0.m_xTRCL, m_xPMD_18, m_bsPMD_B4);
				}
			}

			if (a2 != 0x2FAC || f_r11 || m_ePMD_470 != processmanagerdefault::scenario::ProcessScenario_FullAuth)
			{
				uniteRcl_Frame_sourceRcl(rh2B0, &rh288.m_xTRCL);
			}
			else
			{
				if (f38C || f394)
				{
					m_xPMD_Authenticity.addSecurityResultForDarkEnvironment(m_xPMD_18);
					m_xPMD_Authenticity.m_bTSDKPC_IsFinished = true;
				}

				rh2B0.clear();
				rh2B0.addUniqueNoCopy(m_xPMD_18.m_xTRCL);
				rh2B0.addUniqueNoCopy(m_xPMD_4.m_xTRCL);

				if (m_xPMD_Authenticity.NeedProcess(pph210, rh2B0.m_xTRCL))
				{
					if (pph210.getOption(processparams::PROCESSMODE_uvTorchPresent))
					{
						moduleprocessgl::process(0x3A8, 0, "true", 0, 0);
					}
					else
					{
						moduleprocessgl::process(0x3A8, 0, "false", 0, 0);
					}

					m_xPMD_Authenticity.Process(&rh2B0.m_xTRCL, pph210.ToString(), m_xPMD_18, m_bsPMD_B4);

					if (f_r5)
					{
						analyzeAuthResult(m_xPMD_18, m_bsPMD_B4);
					}
				}
			}

			procmgrdefault::utils::flipResults(rh2B0, tsz159, pph210);
			break;
		}
		case 0x2FAB:
			StartNewFrame();
			init(a3, (char*)a4);
			procmgrdefault::utils::getModulesAndScenariosInfo(m_vPMD_458, m_bsPMD_7C);
			if (a6)
			{
				if (m_bsPMD_7C.length())
				{
					*a6 = (char*)m_bsPMD_7C.data();
				}
			}
			n274 = 0;
			break;
		case 0x2FAD:
			StartNewDocument();
			n274 = 0;
			break;
		case 0x2FAE:
		case 0x2FAF:
		case 0x2FB0:
		case 0x2FB3:
			return 1;
		case 0x2FB1:
			StartNewPage(0);
			n274 = 0;
			break;
		case 0x2FB2:
			free();
			n274 = 0;
			break;
		case 0x2FB4:
			StartNewPage(1);
			n274 = 0;
			break;
		case 0x2FB5:
			rh2B0.clear();
			rh2B0.addCopy(m_xPMD_2C.m_xTRCL);
			pRIC = (TRawImageContainer*)rclhelp::getContainerContent(&rh288.m_xTRCL, 1);
			if (pRIC)
			{
				TDocGraphicsInfo xDGI0_0;
				TDocGraphicField xDGF3a;
				memset(&xDGF3a, 0, sizeof(TDocGraphicField));
				xDGF3a.nDGF_FieldType = GFT_Portrait;
				xDGF3a.xDGF_image = *pRIC;
				xDGI0_0.nDGI_nFields = 1;
				xDGI0_0.pDGI_pArrayFields = &xDGF3a;
				rh2B0.addNewCopy(32, &xDGI0_0, 0);
			}
			m_xPMD_ExtPortraitProcessor.Process(&rh2B0.m_xTRCL, jv258, m_xPMD_2C, m_bsPMD_7C);
			n274 = 0;
			break;
		case 0xCD:
			n274 = 0;
			break;
		case 0xCE:
			n274 = 0;
			free();
			break;
		case 0x30D4:
		{
			m_xPMD_E0.reset();
			StartNewPage(0);
			StartNewFrame();
			vector<int> vi3a = rfidContainerTypes();
			for (size_t i = 0; i < vi3a.size(); i++)
			{
				m_xPMD_2C.remove(vi3a[i]);
			}

			char *ch3a = 0;
			TResultContainerList *pRCL0_0 = 0;
			n274 = moduleprocessgl::process(0x30D5, 0, a4, (void**)&pRCL0_0, &ch3a);
			m_xPMD_2C.addNoCopy(pRCL0_0);
			if (pph210.m_fPPH_debugSaveRFIDSession)
			{
				moduleprocessgl::process(0x30E3, 0, a4, 0, 0);
			}
			m_xPMD_2C.remove(15);
			m_xPMD_2C.remove(36);
			m_xPMD_2C.remove(37);
			m_xPMD_2C.remove(33);
			m_xPMD_Lex.setParams(bs240);
			uniteRcl_Frame_sourceRcl(rh2B0, &m_xPMD_2C.m_xTRCL);
			m_xPMD_Lex.Process(&rh2B0.m_xTRCL, m_xPMD_4, m_bsPMD_B4);
			m_fPMD_B0 = true;
			m_xPMD_E0.stop();
			break;
		}
		default:
			return 1;
		}

		if (m_xPMD_18.getRcList(95).empty())
		{
			int n59 = rclhelp::docFormatFromRecognizeResult(m_xPMD_4.m_xTRCL);
			if (n59 != 3)
			{
				rclhelp::documentFormatUpdate(m_xPMD_18, (CDocFormat)n59);
			}
		}
		if (a2 == 0x2FA9 || a2 == 0x2FAA || a2 == 0x2FAC || a2 == 0x30D4)
		{
			generateResult(a2, rclhelp::getProcessParams(rh288, bs240), pph210, m_bsPMD_7C, a5);
			if (a6 && m_bsPMD_7C.length())
			{
				*a6 = (char*)m_bsPMD_7C.data();
			}
		}
		if (a2 == 0x2FAC)
		{
			n274 = 0;
		}

		return n274;
	}
	void ProcMgrDefault::StartNewDocument(void)
	{
		Clear();
	}
	void ProcMgrDefault::StartNewFrame(void)
	{
		for (size_t i = 0; i < m_vPMD_464.size(); i++)
		{
			m_vPMD_464[i]->Reset();
		}

		m_xPMD_4.clear();
		m_bsPMD_B4.clear();
		m_xPMD_18.remove(1);
		m_xPMD_18.remove(16);
		m_xPMD_4.addCopy(m_xPMD_18.getRcList(95));
		m_fPMD_96 = 1;
	}
	void ProcMgrDefault::StartNewPage(bool a2)
	{
		m_fPMD_B0 = 0;
		m_xPMD_18.clear();
		m_xPMD_68.clear();
		if (!a2)
		{
			m_nPMD_88++;
		}
		m_nPMD_8C = 0;
		m_nPMD_90 = 0;

		for (size_t i = 0; i < m_vPMD_464.size(); i++)
		{
			m_vPMD_464[i]->StartNewPage();
		}

		m_xPMD_2C.remove(85);
		m_vPMD_A4.clear();

		m_xPMD_18.addCopy(m_xPMD_2C.getRcList(95));

		m_fPMD_95 = m_fPMD_94;
		m_nPMD_498 = 0;
		m_xPMD_4A0.stop();
		m_xPMD_4C0.stop();
		m_xPMD_4E0.stop();
		m_nPMD_500 = 0;
		m_xPMD_3AC.clear();
		StartNewFrame();
	}
	void ProcMgrDefault::setDPIFromBoundsResult(common::container::RclHolder & a1)
	{
		if (!rclhelp::imageResolution(a1.m_xTRCL))
		{
			CDocFormat *pCDF2 = (CDocFormat *)rclhelp::getContainerContent(&a1.m_xTRCL, 85);
			if (pCDF2)
			{
				int n4 = (int)common::docsize::widthMM(*pCDF2);
				if (n4 > 0)
				{
					vector<TResultContainer *> vrc12 = a1.getRcList(1);
					int n6 = 1000 * pCDF2[1] / n4;
					for (size_t i = 0; i < vrc12.size(); i++)
					{
						TRawImageContainer *pTRIC9 = vrc12[i]->u.pTRC_RIC;
						if (pTRIC9)
						{
							pTRIC9->pxRIC_bmi->bmiHeader.biXPelsPerMeter = n6;
							pTRIC9->pxRIC_bmi->bmiHeader.biYPelsPerMeter = n6;
						}
					}
				}
			}
		}
	}
	void ProcMgrDefault::setProcessParamsByLoadedModules(ProcessParamsHolder & a2)
	{
		if (a2.m_nPPH_processParam & 0x20)
		{
			a2.SetMode(RPRM_GetImage_Modes_20, m_xPMD_RecPass.m_bTSDKPC_IsInitial);
		}

		if (a2.m_nPPH_processParam & 0x40)
		{
			a2.SetMode(RPRM_GetImage_Modes_40, m_xPMD_MrzDetector.m_bTSDKPC_IsInitial);
		}

		if (a2.m_nPPH_processParam & 0x4)
		{
			a2.SetMode(RPRM_GetImage_Modes_4, m_xPMD_GraphicFieldCropper.m_bTSDKPC_IsInitial);
		}

		if (a2.m_nPPH_processParam & 0x100)
		{
			bool v5;
			if (m_xPMD_BarcodesMT.m_bTSDKPC_IsInitial)
			{
				v5 = true;
			}
			else
			{
				v5 = m_xPMD_ExtBarcodeReader.m_bTSDKPC_IsInitial;
			}
			a2.SetMode(RPRM_GetImage_Modes_100, v5);
		}

		if (a2.m_nPPH_processParam & 0x10000)
		{
			a2.SetMode(RPRM_GetImage_Modes_10000, m_xPMD_ImageQuality.m_bTSDKPC_IsInitial);
		}

		if (a2.m_nPPH_processParam & 0x80)
		{
			a2.SetMode(RPRM_GetImage_Modes_80, m_xPMD_ImSegger.m_bTSDKPC_IsInitial);
		}

		if (a2.m_nPPH_processParam & 0x10)
		{
			a2.SetMode(RPRM_GetImage_Modes_10, m_xPMD_DocBoundLocator.m_bTSDKPC_IsInitial);
		}

		if (a2.m_nPPH_processParam & 0x200)
		{
			a2.SetMode(RPRM_GetImage_Modes_200, m_xPMD_Authenticity.m_bTSDKPC_IsInitial);
		}

		if ((a2.m_nPPH_processParam & 0x1C0) || a2.m_fPPH_doLex)
		{
			a2.m_fPPH_doLex = m_xPMD_Lex.m_bTSDKPC_IsInitial;
		}
	}
	void ProcMgrDefault::uniteRcl_Frame_sourceRcl(common::container::RclHolder & a2, TResultContainerList * a3)
	{
		a2.clear();
		if (a3)
		{
			a2.addUniqueNoCopy(*a3);
		}
		a2.addUniqueNoCopy(m_xPMD_4.m_xTRCL);
	}
	void ProcMgrDefault::updateDocIdListForCurrentFramesSeries(bool a2)
	{
		vector<int> vi6 = rclhelp::getDocIds(m_xPMD_18);

		if (!vi6.empty())
		{
			m_vPMD_A4 = vi6;
			if (a2 && m_vPMD_A4.size() == 1)
			{
				vector<int> vi1;
				rclhelp::docdesc::getPairPageDocList(vi6[0], vi1);
				common::unit(m_vPMD_A4, vi1);
			}
		}
	}
	void ProcMgrDefault::updateStatusFrameSeriesWithoutMrz(void)
	{
		if (m_fPMD_95)
			return;
		
		if (!m_vPMD_A4.empty())
		{
			if (m_xPMD_18.getRcList(3).empty())
			{
				vector<int> vi1 = rclhelp::getDocIds(m_xPMD_18);

				if (vi1.size() == 1)
				{
					if (!rclhelp::docdesc::isDocsHasMrz(common::substract(m_vPMD_A4, vi1), true))
						m_fPMD_95 = true;
				}
				else if (vi1.size() == 2)
				{
					m_fPMD_95 = true;
				}
			}
		}
	}
	void ProcMgrDefault::updateUnprocessedDocIdListForDoc(int & a2)
	{
		m_vPMD_98.clear();
		a2 = 0;
		if (getMultiPageOffMode(m_ePMD_470))
		{
			return;
		}

		int n6 = rclhelp::documentFormat(m_xPMD_18.m_xTRCL);
		vector<int> vi3 = rclhelp::getDocIds(m_xPMD_2C);
		if (vi3.empty())
		{
			if (!m_nPMD_88)
			{
				if (n6 == 0 || rclhelp::documentFormatFromCLMix(m_xPMD_2C.m_xTRCL, 0) == DOCFORMAT_0)
					a2 = 1;
			}
			return;
		}

		vector<int> vi2a;
		vector<TResultContainer *> vprc31 = m_xPMD_2C.getRcList(63);
		vector<int> vi30;

		for (size_t i = 0; i < vprc31.size(); i++)
		{
			Json::Value *pJV9 = vprc31[i]->u.pTRC_JV;
			if (!pJV9) continue;

			vector<int> vi29;
			rclhelp::docdesc::getChildDocList(*pJV9, vi29);
			int n12 = (*pJV9)["document"].get("number", 0).asInt();
			if (n12)
			{
				vi29.push_back(n12);
			}

			int n15 = (*pJV9)["document"].get("recognTag", 0).asInt();
			if (n15)
			{
				vi30.assign(vi29.begin(), vi29.end());
			}
			else
			{
				if (!vi2a.empty())
				{
					if (vi2a.size() <= vi29.size())
					{
						continue;
					}
				}

				vi2a.assign(vi29.begin(), vi29.end());
			}
		}

		if (vi2a.empty())
		{
			vi2a.assign(vi30.begin(), vi30.end());
		}

		m_vPMD_98 = common::substract(vi2a, vi3);

		vector<TResultContainer *> vprc26 = m_xPMD_2C.getRcList(1);
		RclHolder xRH1(vprc26, true);

		vector<int> vi26 = rclhelp::getPages(xRH1.m_xTRCL);

		a2 = m_vPMD_98.size();

		if (n6 <= 1 && m_vPMD_98.size() && vi26.size() == 2)
		{
			a2 = 0;
		}
	}
	void ProcMgrDefault::updateWorkDpi(Json::Value const & a2, common::container::RclHolder & a3)
	{
		int n6 = a2["processParam"].get("imageDpiOutMax", -1).asInt();
		int n7;
		if (n6 < 1)
		{
			n7 = 0x7FFFFFFF;
		}
		else
		{
			n7 = (int)(100 * n6 / 2.54f);
		}

		if (m_xPMD_4.hasRc(1))
		{
			RclHolder xRH1;
			vector<int> vi23;
			vector<shared_ptr<RclHolder>> vsr22 = rclhelp::splitByPage(m_xPMD_4);

			for (size_t i = 0; i < vsr22.size(); i++)
			{
				if (vsr22[i]->hasRc(85))
				{
					if (rclhelp::bounds::updateBoundsResultByDpi(*vsr22[i], 4000, n7, 0.05f, rclhelp::imageResolution(vsr22[i]->m_xTRCL)))
					{
						int n20 = rclhelp::getPage(vsr22[i]->m_xTRCL);
						vi23.push_back(n20);
						vsr22[i]->remove(1);
						vsr22[i]->addNoCopy(a3.getRcList(1));
						vsr22[i]->setPageIndex(n20);

						TResultContainerList *pRCL2a = 0;

						if (!moduleprocessgl::process(519, vsr22[i].get(), 0, (void**)&pRCL2a, 0))
						{
							xRH1.addCopy(pRCL2a);
						}
					}
				}
			}

			for (size_t i = 0; i < vi23.size(); i++)
			{
				m_xPMD_4.remove(rclhelp::convertToContainers(m_xPMD_4.getRcList(1, vi23[i])));
			}
			m_xPMD_4.addCopy(xRH1.m_xTRCL);
			a3.remove(1);
			m_xPMD_DocBoundLocator.m_bTDBL_IsResReady = true;
			m_xPMD_DocBoundLocator.updateMrzCoordinates(m_xPMD_4);
			m_xPMD_RecPass.setForceDocIds(m_xPMD_4);
		}
		else
		{
			rclhelp::bounds::updateBoundsResultByDpi(m_xPMD_4, 4000, n7, 0.05f, 0);
		}
	}
}