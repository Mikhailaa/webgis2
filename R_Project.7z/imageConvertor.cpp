#include "imageConvertor.h"
#include "Json/Value.h"
#include "common/container/container.h"
#include "rclhelp.h"

namespace imageConvertor
{
	void convert(Json::Value const&a1, ImageParams &a2)
	{
		memclr(&a2, sizeof(ImageParams));
		a2.nIP_height = a1["imageInputParam"]["height"].asInt();
		a2.nIP_width = a1["imageInputParam"]["width"].asInt();
		a2.nIP_type = a1["imageInputParam"]["type"].asInt();
		a2.nIP_light = 6;
		if (a1["imageInputParam"].isMember("light"))
		{
			a2.nIP_light = a1["imageInputParam"]["light"].asInt();
		}
	}

	void fromBytesToContainer(ImageParams const&a1, void *a2, common::container::RclHolder &a3)
	{
		Mat v30(a1.nIP_height, a1.nIP_width, 16);
		switch (a1.nIP_type)
		{
		case 0xFC:
			{
				Mat v29(a1.nIP_height, a1.nIP_width, 0, a2, 0);
				vector<int> v26 = { 0, 0, 0, 1, 0, 2 };
				cv::mixChannels(&v29, 1, &v30, 1, v26.data(), 3);
			}
			break;
		case 0xFD:
			{
				Mat v29(a1.nIP_height, a1.nIP_width, 16, a2, 0);
				v29.copyTo(v30);
			}
			break;
		case 0xFE:
			{
				Mat v29(a1.nIP_height, a1.nIP_width, 24, a2, 0);
				cv::cvtColor(v29, v30, COLOR_RGBA2BGR);
			}
			break;
		case 0xFF:
			{
				Mat v29(a1.nIP_height, a1.nIP_width, 24, a2, 0);
				cv::cvtColor(v29, v30, COLOR_BGRA2BGR);
			}
			break;
		case 0x100:
			{
				Mat v29(a1.nIP_height, a1.nIP_width, 24, a2, 0);
				vector<int> v26 = { 3, 0, 2, 1, 1, 2 };
				cv::mixChannels(&v29, 1, &v30, 1, v26.data(), 3);
			}
			break;
		case 0x11:
			{
				Mat v29(a1.nIP_height + a1.nIP_height / 2, a1.nIP_width, 0, a2, 0);
				cv::cvtColor(v29, v30, COLOR_YUV2BGR_NV21);
			}
			break;
		default:
			break;
		}
		unique_ptr<TRawImageContainer, TRawImageContainer*(*)(TRawImageContainer*)> v29 = common::container::copyMatToRic(v30);
		TResultContainer* v23 = a3.addNewWithOwnership(1, v29.release(), RPRM_Lights_0);
		v23->nTRC_light = (eRPRM_Lights)a1.nIP_light;
		v23->nTRC_page_idx = a1.nIP_pageIndex;
		rclhelp::setExposure(*v23, a1.nIP_exposure);
	}

	void fromBytesToContainer(Json::Value const&a1, void *a2, common::container::RclHolder &a3)
	{
		ImageParams v6;
		memclr(&v6, sizeof(ImageParams));
		convert(a1, v6);
		fromBytesToContainer(v6, a2, a3);
	}
}
