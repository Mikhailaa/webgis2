#pragma once

#include "common/container/RclHolder.h"
#include "ProcessParamsHolder.h"

class TSDKProcessingClass;

namespace processmanagerdefault
{
	enum eModuleType
	{
		ModuleType_0,
		ModuleType_MrzDetector,
		ModuleType_ExtBarcodeReader,
		ModuleType_3,
		ModuleType_BarcodesMT,
		ModuleType_DocBoundLocator,
		ModuleType_RecPass,
		ModuleType_Bind,
		ModuleType_ImSegger,
		ModuleType_CanDetector,
		ModuleType_GraphicFieldCropper,
		ModuleType_CreditCard,
		ModuleType_ImageQuality,
		ModuleType_RFID,
		ModuleType_Id3Rus,
		ModuleType_Authenticity,
		ModuleType_ExtPortraitProcessor,
	};

	enum eResolutionType
	{
		ResolutionType_0,
		ResolutionType_1,
	};

	class IModuleStatus
	{
	public:
		virtual processmanagerdefault::eModuleType type() { return processmanagerdefault::ModuleType_0; };
		virtual bool isInitialized() = 0;
		virtual bool isProcessed() = 0;
		virtual bool isFinished() = 0;
		virtual bool isResultReady() = 0;
		virtual void ForceReady(bool) = 0;

	public:
		vector<IModuleStatus *> m_vIMS_field_4;
	};

	class IModuleRequirements
	{
	public:
		virtual vector<eRPRM_Lights> lights();
		virtual eResolutionType resolutionType();
	};

	namespace scenario
	{
		enum eProcessScenario
		{
			ProcessScenario_0,
			ProcessScenario_Mrz,  //MRZ
			ProcessScenario_Barcode,  //Barcode
			ProcessScenario_Locate,  //Locate
			ProcessScenario_Ocr,  //Visual OCR
			ProcessScenario_DocType,  //Document Type
			ProcessScenario_MrzOrBarcode,  //MRZ or Barcode
			ProcessScenario_MrzOrLocate,  //MRZ or Locate
			ProcessScenario_MrzAndLocate,  //MRZ and Locate
			ProcessScenario_MrzOrOcr,  //MRZ or Visual OCR
			ProcessScenario_MrzOrBarcodeOrOcr,  //MRZ or Visual OCR or Barcode
			ProcessScenario_LocateVisual_And_MrzOrOcr,  //MRZ or Visual OCR (with images)
			ProcessScenario_CreditCard,  //Credit Card
			ProcessScenario_FullProcess,  //Full Process
			ProcessScenario_Id3Rus,  //Russian ID3 (fast)
			ProcessScenario_FullAuth,  //Full Process + Authenticity
			ProcessScenario_RusStamp, //Free OCR
			ProcessScenario_OcrFree,
			ProcessScenario_Capture
		};

		eProcessScenario convert(string const&);
		eProcessScenario convert(ProcessParamsHolder &);
		string convert(eProcessScenario);
		void convertScenario(eProcessScenario, common::container::RclHolder &, ProcessParamsHolder &);

		bool isSupportSeriesProcessMode(eProcessScenario);
		bool isProcessFinished(eProcessScenario, vector<IModuleStatus *> const&, bool);
		bool isProcessFinished(eProcessScenario, vector<IModuleStatus *> const&, vector<eModuleType> &);

		vector<eProcessScenario> getScenarioWithDocTypeRequired(void);
		void getScenarioDependence(eProcessScenario, vector<eModuleType> &);
		vector<eModuleType> getModulesNotFinished(vector<IModuleStatus *> const&);
		int getMultiPageOffMode(eProcessScenario);

		vector<IModuleStatus *> filterModulesByInitStatus(vector<IModuleStatus *> const&);
		vector<IModuleStatus *> filterModulesByType(vector<IModuleStatus *> const&, vector<eModuleType> const&);
		vector<eProcessScenario> filterScenarioByModules(vector<eProcessScenario> const&, vector<eModuleType> const&);

		vector<eProcessScenario> getAvailableScenarios(eRPRM_Capabilities);
		int getBarcodeExtMode(eProcessScenario);
		eRPRM_Capabilities getCapabilities(eProcessScenario);
		string getCaptionForScenario(eProcessScenario);
		string getDescription(eProcessScenario);
		int getFaceExtMode(eProcessScenario);
		bool getManualCrop(eProcessScenario);
		vector<eModuleType> getModulesType(vector<IModuleStatus *> const&);
		int getOrientation(eProcessScenario);
		pair<eResolutionType, vector<eRPRM_Lights>> getPriorityRequirements(vector<pair<eResolutionType, vector<eRPRM_Lights>>> &);
		double getProportionLandscape(eProcessScenario);
		double getProportionLandscapeDoublePageSpread(eProcessScenario);
		double getProportionPortrait(eProcessScenario);
		double getProportionPortraitDoublePageSpread(eProcessScenario);
		bool getUVTorch(eProcessScenario);
		vector<pair<eResolutionType, vector<eRPRM_Lights>>> needRequirements(vector<TSDKProcessingClass *> const&, vector<eModuleType> const&);
	}

	namespace ScenarioRelations
	{
		bool isRelationsBlocked(vector<IModuleStatus *> &);
		vector<IModuleStatus *> setRelations(vector<IModuleStatus *> &);
	}

	string convert(eModuleType);
}