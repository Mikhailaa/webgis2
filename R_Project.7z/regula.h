#pragma once
#include "pch.h"

namespace regula
{
	class ProcessParameters
	{
		struct RequestProp
		{
			int nPP_RP_mode;
			int nPP_RP_cap;
		};

	public:
		map<string, RequestProp> m_xPP_0;
		vector<string> m_xPP_C;

		ProcessParameters();
		~ProcessParameters();
		int getCapabilities(string const&);
		vector<string> getFullRequestsList(void);
		int getImageModes(string const&);
	};

	namespace light
	{
		bool contains(vector<eRPRM_Lights> const&, eRPRM_Lights);
		TRawImageContainer *findImageUsingLightGroup(TResultContainerList &, eRPRM_Lights, bool, bool, bool);
		vector<eRPRM_Lights>& irGroup(void);
		vector<eRPRM_Lights> lightGroup(eRPRM_Lights);
		vector<eRPRM_Lights> unite(vector<eRPRM_Lights> const&, vector<eRPRM_Lights> const&);
		vector<eRPRM_Lights>& whiteAndIrGroup(void);
		vector<eRPRM_Lights>& whiteGroup(void);
	}
}

