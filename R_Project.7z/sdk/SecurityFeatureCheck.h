#pragma once

#include "../pch.h"

class SecurityFeatureCheck : TSecurityFeatureCheck
{
public:
	SecurityFeatureCheck();
	~SecurityFeatureCheck();
	void setElementDiagnose(eCheckDiagnose);
	void setElementResult(eCheckResult);
	void setFeatureType(int);
	void setRect(tagRECT);
	eCheckResult getElementResult() { return (eCheckResult)this->u.s.sSFC_ElementResult; };
	void removeAllAreas();
	void reset();
	int setResult(eCheckResult);
};