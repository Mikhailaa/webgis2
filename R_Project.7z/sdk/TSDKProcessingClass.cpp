#include "TSDKProcessingClass.h"
#include "../rclhelp.h"
#include "../moduleprocessgl.h"

TSDKProcessingClass::TSDKProcessingClass()
{
	m_bTSDKPC_IsInitial = false;
	m_bTSDKPC_IsFinished = false;
	m_bTSDKPC_IsResReady = false;
	m_bTSDKPC_field_17 = false;
	m_nTSDKPC_result = 0;
	m_pTSDKPC_RH_field_1C = 0;
}

TSDKProcessingClass::~TSDKProcessingClass()
{
	m_bTSDKPC_IsInitial = false;
	m_bTSDKPC_IsFinished = false;
	m_bTSDKPC_field_17 = false;
}

int TSDKProcessingClass::ProcessGeneric(eProcessGlCommands a2, TResultContainerList *a3, common::container::RclHolder &a4, string &a5)
{
	const char* v7 = 0;
	m_nTSDKPC_result = 1;
	if (a5.size()) v7 = a5.data();
	void* v8 = 0;
	char* v9 = 0;
	m_nTSDKPC_result = moduleprocessgl::process(a2, a3, v7, &v8, &v9);
	if (v8)
	{
		a4.addCopy(*(TResultContainerList*)v8);
	}
	return m_nTSDKPC_result;
}

const Json::Value& TSDKProcessingClass::GetDocumentDescriptionValue(TResultContainerList const &a2, string const &a3)
{
	Json::Value* pVal = (Json::Value*)rclhelp::getContainerContent(&a2, 63);
	if (pVal && !pVal->isNull() && pVal->isObject())
		return (*pVal)[a3];
	return Json::Value::nullSingleton();
}

void TSDKProcessingClass::FlipPointY(tagPOINT & a1, tagSIZE & a2)
{
	a1.y = a2.cy - a1.y;
}

void TSDKProcessingClass::FlipRectY(tagRECT & a1, tagSIZE & a2)
{
	int n2 = a1.top;
	a1.top = a2.cy - a1.bottom;
	a1.bottom = a2.cy - n2;
}

void TSDKProcessingClass::Reset()
{
	StartNewFrame();
	m_nTSDKPC_result = 0;
}

void TSDKProcessingClass::Free(bool)
{
	m_bTSDKPC_IsInitial = false;
	StartNewFrame();
}

void TSDKProcessingClass::StartNewFrame()
{
	m_bTSDKPC_field_17 = false;
	m_bTSDKPC_IsFinished = false;
}

void TSDKProcessingClass::StartNewPage()
{
	StartNewFrame();
	m_bTSDKPC_IsResReady = false;
}

void TSDKProcessingClass::StartNewDocument()
{
	StartNewPage();
}