#include "SymbolResult.h"

CSymbolResult::CSymbolResult()
{
	memset(this, 0, sizeof(CSymbolResult));
}

CSymbolResult::~CSymbolResult()
{
}

int CSymbolResult::get(int a1)
{
	return (a1 <= 3) ? xnTSR_Candidates[a1].nTSC_SymbolCode : xnTSR_Candidates[0].nTSC_SymbolCode;
}

CSymbolCandidate *CSymbolResult::at(int a1)
{
	return (a1 <= 3) ? &((CSymbolCandidate *)xnTSR_Candidates)[a1] : &((CSymbolCandidate *)xnTSR_Candidates)[0];
}

int CSymbolResult::addSymbolCandidate(int a1, int a2, int a3, int a4)
{
	if (nTSR_CandidatesCount == 4)
		return 1;
	int index = (nTSR_CandidatesCount <= 3) ? nTSR_CandidatesCount : 0;
	((CSymbolCandidate *)xnTSR_Candidates)[index].set(a1, a2, a3, a4);
	nTSR_CandidatesCount++;
	return 0;
}

void CSymbolResult::removeCandidat(int a1)
{
	for (uint i = a1; i < nTSR_CandidatesCount - 1; i++)
	{
		xnTSR_Candidates[i] = xnTSR_Candidates[i + 1];
	}
	nTSR_CandidatesCount--;
}

CSymbolCandidate& CSymbolResult::operator[](int a1)
{
	return ((a1 <= 3) ? ((CSymbolCandidate *)xnTSR_Candidates)[a1] : ((CSymbolCandidate *)xnTSR_Candidates)[0]);
}
