#include "TRecPass.h"
#include "../imaging.h"
#include "../common/resources.h"
#include "../common/StringUtils.h"
#include "../common/common.h"
#include "../common/container/jsoncpp.h"
#include "../Log.h"

TRecPass::TRecPass()
{
	m_mTRP_field_20.clear();
	m_nTRP_field_2C = 0;
	StartNewDocument();
}

void TRecPass::Init(void * pParam1, char * pParam2)
{
	if (!m_bTSDKPC_IsInitial)
	{
		bool bRes;
		if (moduleprocessgl::isCommandSupported(PGC_TRecPass_2501))
			bRes = moduleprocessgl::isCommandSupported(PGC_TRecPass_2700);
		else
			bRes = 0;
		m_bTSDKPC_IsInitial = bRes;
	}
}

bool TRecPass::IsProcessingFinished(ProcessParamsHolder &)
{
	return m_bTSDKPC_IsFinished;
}

bool TRecPass::NeedProcess(ProcessParamsHolder & xPPH_Param1, TResultContainerList & xTRCL_Param2)
{
	bool bRes;
	if (m_bTSDKPC_IsInitial && (xPPH_Param1.m_nPPH_processParam & 0x20))
		bRes = (rclhelp::getContainerContent(&xTRCL_Param2, 9) == 0);
	else
		bRes = 0;
	return bRes;
}

bool TRecPass::isFinished()
{
	return m_bTSDKPC_IsFinished;
}

bool TRecPass::isResultReady()
{
	return m_bTSDKPC_IsResReady;
}

void TRecPass::StartNewFrame()
{
	TSDKProcessingClass::StartNewFrame();
	m_xRH_field_30.clear();
}

void TRecPass::StartNewPage()
{
	TSDKProcessingClass::StartNewPage();
	StartNewFrame();
	m_mTRP_field_20.clear();
	m_xRH_field_30.clear();
}

void TRecPass::StartNewDocument()
{
	TSDKProcessingClass::StartNewDocument();
	m_nTRP_field_2C = -1;
}

void TRecPass::setForceDocId(int nParam)
{
	common::container::RclHolder rh;
	TOneCandidate toc = { 0 };
	toc.nTOC_ID = nParam;
	rh.addNewCopy<TOneCandidate>(9, &toc, 0);
	setForceDocIds(rh);
}

void TRecPass::setForceDocIds(common::container::RclHolder & xRH_Param)
{
	m_xRH_field_30.clear();
	vector<TResultContainer*> v = xRH_Param.getRcList(9);
	if (v.size())
	{
		m_bTSDKPC_field_17 = 1;
		m_xRH_field_30.addCopy(v);
	}
}

void TRecPass::resetForceDocIds()
{
	m_xRH_field_30.clear();
}

int TRecPass::Recognize(int nParam1, TResultContainerList * pTRCL_Param2, string const & strParam3,
	common::container::RclHolder & xRH_Param4, string & strParam5, int nParam6)
{
	int res = 13;
	string strTemp("TRecPass::Recognize()");
	// common::ScopeLogHelper::ScopeLogHelper
	if (m_bTSDKPC_IsInitial)
	{
		xRH_Param4.remove(9);
		xRH_Param4.remove(8);
		TResultContainerList *pTRCL = 0;
		if (m_xRH_field_30.empty())
		{
			int nCmd = 2505;
			if (nParam1 == 12204)
				nCmd = 2504;
			moduleprocessgl::process(nCmd, pTRCL_Param2, strParam3.data(), (void **)&pTRCL, 0);
		}
		else
		{
			pTRCL = &m_xRH_field_30.m_xTRCL;
		}
		if (pTRCL)
			xRH_Param4.addCopy(pTRCL);
		vector<TResultContainer *> vv = xRH_Param4.getRcList(9);
		vector<TResultContainer> vvv = rclhelp::convertToContainers(vv);
		if (vvv.size())
		{
			for (uint i = 0; i < vvv.size(); i++)
			{
				TOneCandidate *pTOC = vvv[i].u.pTRC_TOC;
				if (pTOC && (uint)(pTOC->nTOC_ID + 1) >= 2)
				{
					uint npi = vvv[i].nTRC_page_idx;
					//Log("docID = %d", pTOC->nTOC_ID);
					m_bTSDKPC_field_17 = 1;
					m_bTSDKPC_IsFinished = m_bTSDKPC_IsResReady = 1;
					if (pTOC->nTOC_ID == 1)
						m_nTRP_field_2C = 0;
					string str1;
					common::resources::getDocDesc(pTOC->nTOC_ID, str1);
					if (str1.length())
					{
						GenericValue<UTF8<char>> gv1;
						GenericDocument<UTF8<char>> gd = common::container::json::ReadString(str1);
						if(m_nTRP_field_2C < 0) m_nTRP_field_2C = 0;
						if (gd.HasMember("document"))
						{
							gv1 = gd["document"];
							if (gv1.HasMember("chipPage"))
							{
								int np = gv1["chipPage"].GetInt();
								if (m_nTRP_field_2C < np)
									m_nTRP_field_2C = np;
							}
						}
						if (gd.GetParseError())
						{
							str1 = common::StringUtils::Replace(str1, string("\\"), string("\\\\"));
						}
						TResultContainer trc;
						memset(&trc, 0, sizeof(TResultContainer));
						trc.nTRC_result_type = 68;
						trc.u.pTRC_CHAR = (char*)str1.data();
						trc.nTRC_buf_length = str1.length() + 1;
						trc.nTRC_page_idx = npi;
						xRH_Param4.addCopy(trc);
						Json::Value& jv = m_mTRP_field_20[npi];
						if (!common::container::jsoncpp::convert(str1, jv))
						{
							memset(&trc, 0, sizeof(TResultContainer));
							trc.nTRC_buf_length = sizeof(Json::Value);
							trc.u.pTRC_JV = &jv;
							trc.nTRC_result_type = 63;
							trc.nTRC_page_idx = npi;
							xRH_Param4.addCopy(trc);
						}
						strParam5 = common::container::json::MergeJson(strParam5, str1);
						string strName = Json::rapid::getDocumentName(gv1);
						//Log("document name: %s", strName.data());
						fwprintf(g_log.m_fpLog, L"==================== RecPass Results ====================\r\n");
						fwprintf(g_log.m_fpLog, L"document name: %S\r\n", strName.data());
						if (!pTOC->pszTOC_DocumentName)
						{
							pTOC->pszTOC_DocumentName = common::container::Duplicate(strName.data());
						}
						if (pTOC->sTOC_Rotated180 == 1)
						{
							common::container::RclHolder rh;
							rh.addNoCopy(pTRCL_Param2);
							vector<TResultContainer*> vTRC = rh.getRcList(1, npi);
							for (uint j = 0; j < vTRC.size(); j++)
							{
								TRawImageContainer *pTRIC = vTRC[j]->u.pTRC_RIC;
								if (pTRIC)
									common::images::FlipImage(*pTRIC, imaging::RI_FLIPMODES_3);
							}
						}
						if (!gv1.IsNull() && !pTOC->pxTOC_FDSIDList)
						{
							pTOC->pxTOC_FDSIDList = new TFDSIDList;
							memset(pTOC->pxTOC_FDSIDList, 0, sizeof(TFDSIDList));
							if (gv1.HasMember("isoCodes"))
							{
								strTemp = gv1["isoCodes"][0].GetString();
								if (strTemp.length() <= 3)
								{
									strcpy(pTOC->pxTOC_FDSIDList->szFDSIDL_ICAOCode, strTemp.data());
								}
							}
							if (gv1.HasMember("dFDSID"))
							{
								vector<uint> vid;
								common::container::json::ArrayFromJson(gv1, vid, "dFDSID");
								if (vid.size())
								{
									pTOC->pxTOC_FDSIDList->nFDSIDL_Count = vid.size();
									pTOC->pxTOC_FDSIDList->pnFDSIDL_List = new uint[vid.size()];
									for (uint j = 0; j < vid.size(); j++)
									{
										pTOC->pxTOC_FDSIDList->pnFDSIDL_List[j] = vid[j];
									}
								}
							}
							common::container::json::uint32FromJson(gv1, pTOC->pxTOC_FDSIDList->nFDSIDL_dType, "dType");
							common::container::json::uint32FromJson(gv1, pTOC->pxTOC_FDSIDList->nFDSIDL_dFormat, "dFormat");
							if (!common::container::json::boolFromJson(gv1, pTOC->pxTOC_FDSIDList->bFDSIDL_dMRZ, "dMRZ"))
							{
								uint dMRZ;
								if(common::container::json::uint32FromJson(gv1, dMRZ, "dMRZ"))
									pTOC->pxTOC_FDSIDList->bFDSIDL_dMRZ = dMRZ ? true : false;
							}
							pTOC->pxTOC_FDSIDList->pszFDSIDL_dYear = common::container::json::charArrayFromJson(gv1, "dYear");
							pTOC->pxTOC_FDSIDList->pszFDSIDL_dCountryName = common::container::json::charArrayFromJson(gv1, "country");
							if (gv1.HasMember("stateCodes"))
							{
								pTOC->pxTOC_FDSIDList->pszFDSIDL_dStateCode = common::container::Duplicate(gv1["stateCodes"][0].GetString());
							}
						}
					}
				}
			}
			res = 0;
		}
	}

	return res;
}