#pragma once

#include "../moduleprocessgl.h"
#include "TSDKProcessingClass.h"
#include "../ProcessParamsHolder.h"
#include "../rclhelp.h"

class TCodeConverter : public TSDKProcessingClass
{
public:
	TCodeConverter();
	~TCodeConverter();
	virtual void Init(void * pParam1, char * pParam2);
	virtual bool IsProcessingFinished(ProcessParamsHolder &);
	virtual bool NeedProcess(ProcessParamsHolder &, TResultContainerList &);
	bool hasNewBarcodeFC(common::container::RclHolder &, TResultContainerList *);
	int Process(TResultContainerList *, string, common::container::RclHolder &, string &);
};