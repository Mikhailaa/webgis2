#pragma once

#include "../moduleprocessgl.h"
#include "TSDKProcessingClass.h"
#include "../ProcessParamsHolder.h"
#include "../rclhelp.h"

class TExtBarcodeReader : public TSDKProcessingClass
{
public:
	TExtBarcodeReader();
	~TExtBarcodeReader();
	processmanagerdefault::eModuleType type() { return processmanagerdefault::ModuleType_ExtBarcodeReader; };
	virtual void Init(void * pParam1, char * pParam2);
	virtual bool IsProcessingFinished(ProcessParamsHolder &);
	virtual bool NeedProcess(ProcessParamsHolder &, TResultContainerList &);
	int Process(TResultContainerList *, common::container::RclHolder &, string &);
};