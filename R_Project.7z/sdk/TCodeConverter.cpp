#include "TCodeConverter.h"

TCodeConverter::TCodeConverter()
{

}

TCodeConverter::~TCodeConverter()
{

}

void TCodeConverter::Init(void * pParam1, char * pParam2)
{
	m_bTSDKPC_IsInitial = moduleprocessgl::isCommandSupported(PGC_TCodeConverter);	// 1100
}

bool TCodeConverter::IsProcessingFinished(ProcessParamsHolder & xPPH_Param1)
{
	bool bRes;
	if (m_bTSDKPC_IsInitial && (xPPH_Param1.m_nPPH_processParam & 0x100))
		bRes = (m_bTSDKPC_IsFinished != 0);
	else
		bRes = true;
	return bRes;
}

bool TCodeConverter::NeedProcess(ProcessParamsHolder & xPPH_Param1, TResultContainerList & xTRCL_Param2)
{
	bool bRes;
	if (m_bTSDKPC_IsInitial && (xPPH_Param1.m_nPPH_processParam & 0x100) && rclhelp::getContainerContent(&xTRCL_Param2, 5))
		bRes = (rclhelp::getContainerContent(&xTRCL_Param2, 18) == 0);
	else
		bRes = false;
	return bRes;
}

bool TCodeConverter::hasNewBarcodeFC(common::container::RclHolder & xRH_Param1, TResultContainerList *pTRCL_Param2)
{
	TAuthenticityCheckResult *pTACR1 = rclhelp::getAuthenticityContent(&xRH_Param1.m_xTRCL, RPRM_Authenticity_10000);	// 0x10000
	TAuthenticityCheckResult *pTACR2 = rclhelp::getAuthenticityContent(pTRCL_Param2, RPRM_Authenticity_10000);
	if (!pTACR2)
		return 0;
	if (pTACR1 && pTACR1->nACR_Count == pTACR2->nACR_Count && pTACR1->nACR_Result == pTACR2->nACR_Result)
	{
		for (int i = 0; i < pTACR1->nACR_Count; i++)
		{
			if (memcmp(pTACR1->ppACR_List[i], pTACR2->ppACR_List[i], sizeof(int) * 6))
				return true;
		}
		return false;
	}
	return true;
}

int TCodeConverter::Process(TResultContainerList *pTRCL_Param1, string strParam2, common::container::RclHolder & xRH_Param3, string & strParam4)
{
	int res = 1;
	string strTemp("TCodeConverter::Process()");
	xRH_Param3.remove(19);
	xRH_Param3.remove(18);
	strTemp = "Executing ePC_CodeConvertor_ProcessBarcode...";
	TResultContainerList *pTRCL = 0;
	char *pC = 0;
	res = moduleprocessgl::process(1102, pTRCL_Param1, strParam2.data(), (void **)&pTRCL, &pC);
	strTemp = "ePC_CodeConvertor_CheckBarcodeFormat: %s (%d)";
	string strRes("Ok");
	if (res)
		strRes = "Failed";
	if (!res && pTRCL)
	{
		if (hasNewBarcodeFC(xRH_Param3, pTRCL))
			rclhelp::mergeResults(xRH_Param3, pTRCL);
		for (uint i = 0; i < pTRCL->nTRCL_Count; i++)
		{
			if (pTRCL->pTRCL_TRC[i].nTRC_result_type != 20)
				xRH_Param3.addCopy(pTRCL->pTRCL_TRC[i]);
		}
		m_bTSDKPC_IsFinished = true;
	}
	return res;
}