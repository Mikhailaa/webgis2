#include "TAuthenticity.h"
#include "SecurityFeatureCheck.h"
#include "AuthenticityCheckResult.h"
#include "AuthenticityCheckList.h"

TAuthenticity::TAuthenticity()
{
	m_nTA_field_2C = 2;
	m_nTA_field_30 = 0;
	m_fTA_field_34 = false;
}

TAuthenticity::~TAuthenticity()
{

}

void TAuthenticity::Init(void * pParam1, char * pParam2)
{
	m_bTSDKPC_IsInitial = moduleprocessgl::isCommandSupported(PGC_TAuthenticity);	// 13500
	m_nTA_field_30 = m_nTA_field_2C;
	m_fTA_field_34 = true;
}

bool TAuthenticity::IsProcessingFinished(ProcessParamsHolder & xPPH_Param1)
{
	bool bRes;
	if (m_bTSDKPC_IsInitial && (xPPH_Param1.m_nPPH_processParam & 0x200))
		bRes = (m_bTSDKPC_IsFinished != 0);
	else
		bRes = true;
	return bRes;
}

bool TAuthenticity::NeedProcess(ProcessParamsHolder & xPPH_Param1, TResultContainerList & xTRCL_Param2)
{
	bool bRes;
	common::container::RclHolder rh;
	rh.addNoCopy(xTRCL_Param2);
	if (m_bTSDKPC_IsInitial && (xPPH_Param1.m_nPPH_processParam & 0x200))
		bRes = (m_bTSDKPC_IsFinished == 0);
	else
		bRes = false;
	return bRes;
}

bool TAuthenticity::isFinished()
{
	return m_bTSDKPC_IsFinished;
}

void TAuthenticity::Free()
{
	if (m_bTSDKPC_IsInitial)
	{
		moduleprocessgl::process(13502, 0, 0, 0, 0);
		m_nTA_field_30 = m_nTA_field_2C;
		m_fTA_field_34 = true;
		m_vTA_field_20.clear();
	}
}

void TAuthenticity::StartNewPage()
{
	Free();
}

vector<eRPRM_Lights> TAuthenticity::lights()
{
	vector<eRPRM_Lights> v;
	v.push_back(RPRM_Lights_6);	// 6
	v.push_back(RPRM_Lights_80);	// 128
	return v;
}

processmanagerdefault::eResolutionType TAuthenticity::resolutionType()
{
	return processmanagerdefault::ResolutionType_0;
}

void TAuthenticity::addNecessaryContainers(common::container::RclHolder const& xRH_Param1, common::container::RclHolder & xRH_Param2)
{
	vector<TResultContainer *> vTRC = xRH_Param1.getRcList(23, RPRM_Lights_6);
	if (!vTRC.size())
	{
		vTRC = xRH_Param1.getRcList(1, RPRM_Lights_6);
		if (vTRC.size())
			xRH_Param2.addNoCopy(vTRC);
	}
	else
	{
		TRawImageContainer *pTRIC = rclhelp::convertPointerToRawImage(vTRC[0]);
		if (pTRIC)
			xRH_Param2.addNewNoCopy(1, pTRIC, RPRM_Lights_6);
	}
	vTRC = xRH_Param1.getRcList(23, RPRM_Lights_80);
	if (!vTRC.size())
	{
		vTRC = xRH_Param1.getRcList(1, RPRM_Lights_80);
		if (vTRC.size())
			xRH_Param2.addNoCopy(vTRC);
	}
	else
	{
		TRawImageContainer *pTRIC = rclhelp::convertPointerToRawImage(vTRC[0]);
		if (pTRIC)
			xRH_Param2.addNewNoCopy(1, pTRIC, RPRM_Lights_80);
	}
	vTRC = xRH_Param1.getRcList();
	for (uint i = 0; i < vTRC.size(); i++)
	{
		if ((vTRC[i]->nTRC_result_type != 23 && vTRC[i]->nTRC_result_type != 1) || 
			(vTRC[i]->nTRC_light != RPRM_Lights_6 && vTRC[i]->nTRC_light != RPRM_Lights_80))
		{
			xRH_Param2.addNoCopy(*vTRC[i]);
		}
	}
}

void TAuthenticity::addSecurityResultForDarkEnvironment(common::container::RclHolder & xRH_Param)
{
	SecurityFeatureCheck sfc;
	sfc.setElementDiagnose(CheckDiagnose_19);
	sfc.setElementResult(CheckResult_0);
	sfc.setFeatureType(0);
	tagSIZE s = rclhelp::imageSize(xRH_Param.m_xTRCL);
	if (s.cx && s.cy)
	{
		tagRECT r;
		r.left = 0;
		r.top = 0;
		r.right = s.cx - 1;
		r.bottom = s.cy - 1;
		sfc.setRect(r);
	}
	AuthenticityCheckResult acr;
	acr.nACR_Type = 1;
	acr.add(sfc);
	acr.generateCommonResult();
	AuthenticityCheckList acl;
	acl.add((TAuthenticityCheckResult *)&acr);
	xRH_Param.addNewCopy(20, &acl, 0);
}

int TAuthenticity::Process(TResultContainerList *pTRCL_Param1, string strParam2, common::container::RclHolder & xRH_Param3, string & strParam4)
{
	int res = 1;
	string strTemp("TAuthenticity::Process()");
	// common::ScopeLogHelper::ScopeLogHelper
	if (rclhelp::getContainerContent(pTRCL_Param1, 1))
	{
		common::container::RclHolder rh1, rh2;
		rh1.addNoCopy(*pTRCL_Param1);
		addNecessaryContainers(rh1, rh2);
		TResultContainerList *pTRCL = 0;
		res = moduleprocessgl::process(13501, &rh2, strParam2.data(), (void **)&pTRCL, 0);
		if ((res || !pTRCL) && m_nTA_field_30)
			m_nTA_field_30--;
		else
		{
			rclhelp::mergeResults(xRH_Param3, &rh2.m_xTRCL);
			rclhelp::mergeResults(xRH_Param3, pTRCL);
			m_bTSDKPC_IsFinished = true;
			strParam4 = xRH_Param3.toJson();
			res = 0;
		}
		strTemp = "counter %d, result %d";
		// common::ScopeLogHelper::AppendToLog<int,int>
	}
	else
	{
		strTemp = "no image containers";
		// common::ScopeLogHelper::AppendToLog<>
	}
	return res;
}