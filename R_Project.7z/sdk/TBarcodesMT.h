#pragma once

#include "../moduleprocessgl.h"
#include "TSDKProcessingClass.h"
#include "../ProcessParamsHolder.h"
#include "../rclhelp.h"
#include "../processmanagerdefault.h"

class TBarcodesMT : public TSDKProcessingClass
{
public:
	TBarcodesMT();
	~TBarcodesMT();
	processmanagerdefault::eModuleType type() { return processmanagerdefault::ModuleType_BarcodesMT; };
	virtual void Init(void * pParam1, char * pParam2);
	virtual bool IsProcessingFinished(ProcessParamsHolder &);
	virtual bool NeedProcess(ProcessParamsHolder &, TResultContainerList &);
	bool isFinished();
	bool isResultReady();
	void StartNewPage();
	bool HaveValidField(TResultContainerList &);
	int ReadBarcode(int, TResultContainerList *, common::container::RclHolder &, string &);

public:
	int m_nTBMT_field_20;
};