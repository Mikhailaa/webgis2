#pragma once
#include "SymbolCandidate.h"
#include "../commonStruct.h"

class CSymbolResult : public TSymbolResult
{
public:
	CSymbolResult();
	~CSymbolResult();

	int get(int);
	CSymbolCandidate *at(int);
	int addSymbolCandidate(int, int, int, int);
	void removeCandidat(int);
	CSymbolCandidate &operator[](int);
};