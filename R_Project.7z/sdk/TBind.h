#pragma once
#include "../pch.h"
#include "TSDKProcessingClass.h"

class TBind : public TSDKProcessingClass
{
public:
	TBind();
	~TBind();
	processmanagerdefault::eModuleType type() { return processmanagerdefault::ModuleType_Bind; };
	void Init(void * , char * );
	bool IsProcessingFinished(ProcessParamsHolder &);
	bool NeedProcess(ProcessParamsHolder &, TResultContainerList &);
	int Process(TResultContainerList *, common::container::RclHolder &, string &);
};