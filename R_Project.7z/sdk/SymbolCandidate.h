#pragma once
#include "../commonStruct.h"

class CSymbolCandidate : public TSymbolCandidate
{
public:
	CSymbolCandidate();
	~CSymbolCandidate();
	void set(int, int, int, int);
	void operator=(CSymbolCandidate);
};