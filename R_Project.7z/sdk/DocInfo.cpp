#include "DocInfo.h"

CDocInfo::CDocInfo()
{
	memset(this, 0, sizeof(CDocInfo));
	reset();
}

CDocInfo::~CDocInfo()
{
	reset();
}

void CDocInfo::reset()
{
	memset(szTDI_pDocName, 0, 0x100);
	memset(szTDI_DocTxtID, 0, 0x100);
	nTDI_nFields = 0;
	if (pxTDI_Fields)
		delete []pxTDI_Fields;
	pxTDI_Fields = 0;
}

int CDocInfo::count()
{
	return nTDI_nFields;
}

int CDocInfo::id()
{
	return nTDI_DocID;
}

CVisualField* CDocInfo::get(int a1)
{
	if (a1 < 0 || a1 >= nTDI_nFields) return 0;
	return (CVisualField *)&pxTDI_Fields[a1];
}

CVisualField *CDocInfo::find(int a1)
{
	for (int i = 0; i < nTDI_nFields; i++)
	{
		if (((CVisualField *)&pxTDI_Fields[i])->getType() == a1)
			return (CVisualField *)&pxTDI_Fields[i];
	}
	return 0;
}

void CDocInfo::resize(int a1)
{
	nTDI_nFields = a1;
	pxTDI_Fields = new CVisualField[a1];
}

void CDocInfo::reverseH(int a1)
{
	for (int i = 0; i < nTDI_nFields; i++)
	{
		pxTDI_Fields[i].xTVF_Region.bottom = a1 - pxTDI_Fields[i].xTVF_Region.bottom;
		pxTDI_Fields[i].xTVF_Region.top = a1 - pxTDI_Fields[i].xTVF_Region.top;
	}
}

void CDocInfo::updateDPI(int a1)
{
	for (int i = 0; i < nTDI_nFields; i++)
	{
		pxTDI_Fields[i].xTVF_Region.left = (int)(a1 * pxTDI_Fields[i].xTVF_RelRegion.left);
		pxTDI_Fields[i].xTVF_Region.top = (int)(a1 * pxTDI_Fields[i].xTVF_RelRegion.top);
		pxTDI_Fields[i].xTVF_Region.right = (int)(a1 * pxTDI_Fields[i].xTVF_RelRegion.right);
		pxTDI_Fields[i].xTVF_Region.bottom = (int)(a1 * pxTDI_Fields[i].xTVF_RelRegion.bottom);
		pxTDI_Fields[i].xTVF_Font.m_nFF_HeightAbs = (int)(pxTDI_Fields[i].xTVF_Font.m_rFF_HeightRel * a1);
	}
}

int CDocInfo::addShift(TBindingResultsList &a1)
{
	for (int i = 0; i < nTDI_nFields; i++)
	{
		CVisualField *pCVF = (CVisualField *)&pxTDI_Fields[i];
		if (pCVF->bindLayer() >= 0 && pCVF->bindLayer() < a1.nBRL_Layers)
		{
			int v10 = a1.pxBRL_ArrayResults[pCVF->bindLayer()].nTBR_shiftX;
			int v14 = a1.pxBRL_ArrayResults[pCVF->bindLayer()].nTBR_shiftY;
			pCVF->xTVF_Region.left += v10;
			pCVF->xTVF_Region.right += v10;
			pCVF->xTVF_Region.top += v14;
			pCVF->xTVF_Region.bottom += v14;
		}
	}
	return nTDI_nFields;
}