#include "TBarcodesMT.h"

TBarcodesMT::TBarcodesMT()
{
	m_nTBMT_field_20 = 0;
}

TBarcodesMT::~TBarcodesMT()
{

}

void TBarcodesMT::Init(void * pParam1, char * pParam2)
{
	m_bTSDKPC_IsInitial = moduleprocessgl::isCommandSupported(PGC_TBarcodesMT);	// 2280
}

bool TBarcodesMT::IsProcessingFinished(ProcessParamsHolder & xPPH_Param1)
{
	bool bRes;
	if (m_bTSDKPC_IsInitial && (xPPH_Param1.m_nPPH_processParam & 0x100))
		bRes = m_bTSDKPC_IsFinished;
	else
		bRes = true;
	return bRes;
}

bool TBarcodesMT::NeedProcess(ProcessParamsHolder & xPPH_Param1, TResultContainerList & xTRCL_Param2)
{
	if (!m_bTSDKPC_IsInitial || !(xPPH_Param1.m_nPPH_processParam & 0x100) || HaveValidField(xTRCL_Param2))
		return false;
	if (!rclhelp::findFirstContainer(xTRCL_Param2, 63))
		return true;
	Json::Value jv = GetDocumentDescriptionValue(xTRCL_Param2, "document");
	if (!jv.isNull() || !jv["barcodeRects"].isNull())
		return true;
	
	m_bTSDKPC_IsFinished = true;
	return false;
}

bool TBarcodesMT::isFinished()
{
	return m_bTSDKPC_IsFinished;
}

bool TBarcodesMT::isResultReady()
{
	return m_bTSDKPC_IsResReady;
}

void TBarcodesMT::StartNewPage()
{
	TSDKProcessingClass::StartNewPage();
	StartNewFrame();
	m_nTBMT_field_20 = 3;
}

bool TBarcodesMT::HaveValidField(TResultContainerList & xTRCL_Param)
{
	TResultContainer *pTRC = rclhelp::findFirstContainer(xTRCL_Param, 5);
	if (pTRC && pTRC->u.pTRC_DBCI)
	{
		TDocBarCodeInfo *pTDBCI = pTRC->u.pTRC_DBCI;
		if (pTDBCI->pDBCI_pArrayFields)
		{
			for (uint i = 0; i < pTDBCI->nDBCI_nFields; i++)
			{
				if ((pTDBCI->pDBCI_pArrayFields[i].nDBCF_bcType_DECODE == 5 ||
					pTDBCI->pDBCI_pArrayFields[i].nDBCF_bcType_DECODE == 14 ||
					pTDBCI->pDBCI_pArrayFields[i].nDBCF_bcType_DECODE == 15 ||
					pTDBCI->pDBCI_pArrayFields[i].nDBCF_bcType_DECODE == 16) &&
					!pTDBCI->pDBCI_pArrayFields[i].nDBCF_bcCodeResult)
				{
					return true;
				}
				if (!pTDBCI->pDBCI_pArrayFields[i].nDBCF_bcCodeResult &&
					pTDBCI->pDBCI_pArrayFields[i].nDBCF_bcType_DETECT == 1)
				{
					return true;
				}
			}
		}
	}
	return 0;
}

int TBarcodesMT::ReadBarcode(int nParam1, TResultContainerList *pTRCL_Param2, common::container::RclHolder & xRH_Param3, string & strParam4)
{
	int res = 1;
	string strTemp("TBarcodesMT::Process()");
	// common::ScopeLogHelper::ScopeLogHelper
	xRH_Param3.remove(5);
	xRH_Param3.remove(19);
	xRH_Param3.remove(18);
	if (nParam1 == 12204)
	{
		strTemp = "Executing ePC_BarcodesMT_ReadDoc...";
		// common::ScopeLogHelper::AppendToLog<>
		res = ProcessGeneric(PGC_TBarcodesMT_ReadDoc, pTRCL_Param2, xRH_Param3, strParam4);	// 2281
		strTemp = "ePC_BarcodesMT_ReadDoc: %s (%d)";
		string strRes("Ok");
		if (res)
			strRes = "Failed";
		// common::ScopeLogHelper::AppendToLog<char const*,int>
	}
	else
	{
		strTemp = "Executing ePC_BarcodesMT_ReadFrame...";
		// common::ScopeLogHelper::AppendToLog<>
		res = ProcessGeneric(PGC_TBarcodesMT_ReadFrame, pTRCL_Param2, xRH_Param3, strParam4);	// 2282
		strTemp = "ePC_BarcodesMT_ReadFrame: %s (%d)";
		string strRes("Ok");
		if (res)
			strRes = "Failed";
		// common::ScopeLogHelper::AppendToLog<char const*,int>
	}
	if (!res && HaveValidField(xRH_Param3.m_xTRCL))
	{
		m_bTSDKPC_IsFinished = 1;
		m_bTSDKPC_IsResReady = 1;
		strTemp = "Successful reading!!!";
		// common::ScopeLogHelper::AppendToLog<>
	}
	if (nParam1 != 12204 && m_bTSDKPC_IsFinished)
	{
		if (rclhelp::findFirstContainer(pTRCL_Param2, 63))
		{
			Json::Value jv = GetDocumentDescriptionValue(*pTRCL_Param2, "document");
			if (!jv.isNull())
			{
				TDocBarCodeInfo *pTDVCI = (TDocBarCodeInfo *)rclhelp::getContainerContent(&xRH_Param3.m_xTRCL, 5);
				m_bTSDKPC_IsFinished = false;
				if (pTDVCI && jv["barcodeRects"].size() == xRH_Param3.m_xTRCL.nTRCL_Count)
					m_bTSDKPC_IsFinished = true;
			}
			if (!m_bTSDKPC_IsFinished)
			{
				m_nTBMT_field_20--;
				if (m_nTBMT_field_20 <= 0)
					m_bTSDKPC_IsFinished = true;
			}
		}
	}
	strTemp = "TBarcodesMT::Process() exit";
	// common::ScopeLogHelper::AppendToLog<>
	return res;
}