#pragma once

#include "../moduleprocessgl.h"
#include "TSDKProcessingClass.h"
#include "../ProcessParamsHolder.h"
#include "../rclhelp.h"

class TDocBoundLocator : public TSDKProcessingClass
{
public:
	TDocBoundLocator();
	~TDocBoundLocator();
	processmanagerdefault::eModuleType type() { return processmanagerdefault::ModuleType_DocBoundLocator; };
	virtual void Init(void * pParam1, char * pParam2);
	virtual bool IsProcessingFinished(ProcessParamsHolder &);
	virtual bool NeedProcess(ProcessParamsHolder &, TResultContainerList &);
	bool isFinished();
	bool isResultReady();
	void StartNewFrame();
	bool NeedCrop(ProcessParamsHolder &, TResultContainerList &);
	int FindDocumentLocation(int, common::container::RclHolder &, common::container::RclHolder &, string &);
	int locate(common::container::RclHolder &, common::container::RclHolder &, float, Size &);
	int updateMrzCoordinates(common::container::RclHolder &);
	int updateFacePosition(common::container::RclHolder &);

public:
	bool m_bTDBL_IsResReady;
};