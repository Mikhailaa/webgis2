#pragma once

#include "../moduleprocessgl.h"
#include "TSDKProcessingClass.h"
#include "../ProcessParamsHolder.h"
#include "../rclhelp.h"
#include "../processmanagerdefault.h"

class TAuthenticity : public TSDKProcessingClass
{
public:
	TAuthenticity();
	~TAuthenticity();
	processmanagerdefault::eModuleType type() { return processmanagerdefault::ModuleType_Authenticity; };
	virtual void Init(void * pParam1, char * pParam2);
	virtual bool IsProcessingFinished(ProcessParamsHolder &);
	virtual bool NeedProcess(ProcessParamsHolder &, TResultContainerList &);
	void Free();
	bool isFinished();
	void StartNewPage();
	virtual vector<eRPRM_Lights> lights();
	virtual processmanagerdefault::eResolutionType resolutionType();
	void addNecessaryContainers(common::container::RclHolder const&, common::container::RclHolder &);
	void addSecurityResultForDarkEnvironment(common::container::RclHolder &);
	int Process(TResultContainerList *, string, common::container::RclHolder &, string &);

public:
	vector<shared_ptr<int> > m_vTA_field_20;
	int m_nTA_field_2C;
	int m_nTA_field_30;
	bool m_fTA_field_34;
};