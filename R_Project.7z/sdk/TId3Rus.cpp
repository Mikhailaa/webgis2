#include "TId3Rus.h"

void TId3Rus::Init(void * pParam1, char * pParam2)
{
	m_bTSDKPC_IsInitial = moduleprocessgl::isCommandSupported(PGC_TId3Rus);	// 12700
};

bool TId3Rus::IsProcessingFinished(ProcessParamsHolder &)
{
	bool bRes;
	if (m_bTSDKPC_IsInitial)
		bRes = (m_bTSDKPC_IsFinished != 0);
	else
		bRes = 1;
	return bRes;
}

bool TId3Rus::NeedProcess(ProcessParamsHolder &, TResultContainerList &)
{
	return m_bTSDKPC_IsInitial;
}

int TId3Rus::Process(TResultContainerList *pTRCL_Param1, common::container::RclHolder & xRH_Param2, string & strParam3, bool bParam4)
{
	string strTemp("TId3Rus::Process()");
	// common::ScopeLogHelper::ScopeLogHelper
	char *str = "{\"processParam\":{\"singleImageProcess\":true}}";
	if (bParam4)
	{
		str = "{\"processParam\":{\"singleImageProcess\":false}}";
	}
	TResultContainerList *pTRCL = 0;
	char *s = 0;
	int res = moduleprocessgl::process(12700, pTRCL_Param1, str, (void **)&pTRCL, &s);
	if (!res)
	{
		strParam3 = s;
		if (pTRCL)
			xRH_Param2.addCopy(pTRCL);
	}
	return res;
}

