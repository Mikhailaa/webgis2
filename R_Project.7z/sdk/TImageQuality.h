#pragma once

#include "../moduleprocessgl.h"
#include "TSDKProcessingClass.h"
#include "../ProcessParamsHolder.h"
#include "../rclhelp.h"
#include "../common/container/json.h"

class TImageQuality : public TSDKProcessingClass
{
public:
	TImageQuality();
	~TImageQuality();
	processmanagerdefault::eModuleType type() { return processmanagerdefault::ModuleType_ImageQuality; };
	virtual void Init(void * pParam1, char * pParam2);
	virtual bool IsProcessingFinished(ProcessParamsHolder &);
	virtual bool NeedProcess(ProcessParamsHolder &, TResultContainerList &);
	TCheckResult DoQC(TResultContainerList *, common::container::RclHolder &, string &, eProcessGlCommands, eImageQualityCheckType);
	TCheckResult CheckFocus(TResultContainerList *, common::container::RclHolder &, string &);
	TCheckResult CheckGlares(TResultContainerList *, common::container::RclHolder &, string &);
	TCheckResult CheckFocusAndGlares(TResultContainerList *, common::container::RclHolder &, string &);
	TCheckResult UpdateGlaresCoordinates(TResultContainerList *, common::container::RclHolder &, string &);
	int LocateAndCheck(TResultContainerList *, common::container::RclHolder &, string &, bool);

	static bool IsEmpty(TResultContainer const &);
	static bool IsError(TResultContainer const &);
	static bool IsNotDone(TResultContainer const &);
	static bool IsNotEmpty(TResultContainer const &);
	static bool IsOk(TResultContainer const &);
	static int GetQualityCheckType(TResultContainer const &);
	static eCheckResult DetermineCommonCheckResult(TResultContainerList const &);
	static void FlattenQCResults(common::container::RclHolder const &, common::container::RclHolder &);
};