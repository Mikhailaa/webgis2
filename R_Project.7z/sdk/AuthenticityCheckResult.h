#pragma once
#include "SecurityFeatureCheck.h"

class AuthenticityCheckResult : public TAuthenticityCheckResult
{
public:
	AuthenticityCheckResult();
	~AuthenticityCheckResult();
	template <typename T>
	void add(T &a2)
	{
		if (!reserve(this->nACR_Count + 1))
		{
			this->ppACR_List[this->nACR_Count++] = &a2;
		}
	}
	void generateCommonResult();
	int reserve(int);
	int exchangePointers(int, int);
	void free();
};