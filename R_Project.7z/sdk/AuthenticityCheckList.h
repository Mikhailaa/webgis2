#pragma once

#include "../pch.h"

class AuthenticityCheckList : TAuthenticityCheckList
{
public:
	AuthenticityCheckList();
	~AuthenticityCheckList();
	int add(TAuthenticityCheckResult *);
	void free();
};