#include "TLex.h"

TLex::TLex()
{

}

TLex::~TLex()
{

}

void TLex::Init(void * pParam1, char * pParam2)
{
	m_bTSDKPC_IsInitial = moduleprocessgl::isCommandSupported(PGC_TLex);	// 650
}

bool TLex::IsProcessingFinished(ProcessParamsHolder & xPPH_Param1)
{
	bool bRes = true;
	if (m_bTSDKPC_IsInitial)
	{
		if ((xPPH_Param1.m_nPPH_processParam & 0x1C0) || xPPH_Param1.m_fPPH_doLex)
		{
			bRes = (m_bTSDKPC_IsFinished != 0);
		}
	}
	return bRes;
}

bool TLex::NeedProcess(ProcessParamsHolder & xPPH_Param1, TResultContainerList & xTRCL_Param2)
{
	bool bRes = false;
	if (m_bTSDKPC_IsInitial)
	{
		if ((xPPH_Param1.m_nPPH_processParam & 0x1C0) || xPPH_Param1.m_fPPH_doLex || 
			xPPH_Param1.getOption(processparams::PROCESSMODE_rfid))
		{
			bRes = (rclhelp::getContainerContent(&xTRCL_Param2, 15) == 0);
		}
	}
	return bRes;
}

int TLex::setParams(string & strParam)
{
	return moduleprocessgl::process(655, 0, strParam.data(), 0, 0);
}

int TLex::Process(TResultContainerList *pTRCL_Param1, common::container::RclHolder & xRH_Param2, string & strParam3)
{
	int res = 1;
	string strTemp("TLex::Process()");
	// common::ScopeLogHelper::ScopeLogHelper
	xRH_Param2.remove(22);
	xRH_Param2.remove(15);
	xRH_Param2.remove(36);
	xRH_Param2.remove(37);
	xRH_Param2.remove(28);
	strTemp = "Executing ePC_Lex_Process...";
	// common::ScopeLogHelper::AppendToLog<>
	TResultContainerList *pTRCL = 0;
	char *pC = 0;
	res = moduleprocessgl::process(651, pTRCL_Param1, strParam3.data(), (void **)&pTRCL, &pC);
	strTemp = "PC_Lex_Process: %s (%d)";
	string strRes("Ok");
	if (res)
		strRes = "Failed";
	// common::ScopeLogHelper::AppendToLog<char const*,int>
	if (!res)
	{
		if (rclhelp::getContainerContent(pTRCL, 15))
		{
			m_bTSDKPC_IsFinished = 1;
			if (pTRCL)
				xRH_Param2.addCopy(*pTRCL);
		}
	}
	return res;
}