#pragma once

#include "TSDKProcessingClass.h"
#include "../ProcessParamsHolder.h"

class TCanDetector : public TSDKProcessingClass
{
public:
	int m_nTCD_20;

	TCanDetector();
	~TCanDetector();
	processmanagerdefault::eModuleType type() { return processmanagerdefault::ModuleType_CanDetector; };
	bool isResultReady();
	void Init(void * pParam1, char * pParam2);
	void Free(bool);
	void StartNewFrame(void);
	bool IsProcessingFinished(ProcessParamsHolder &);
	bool NeedProcess(ProcessParamsHolder &, TResultContainerList &);

	string DetectorErrorToText(MRZDetectorErrorCode);
	int ReadCanWithDetector(TResultContainerList *, common::container::RclHolder &, string &);
};