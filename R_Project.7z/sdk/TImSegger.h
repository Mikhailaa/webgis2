#pragma once

#include "../moduleprocessgl.h"
#include "TSDKProcessingClass.h"
#include "../ProcessParamsHolder.h"
#include "../rclhelp.h"
#include "../common/container/json.h"

class TImSegger : public TSDKProcessingClass
{
public:
	TImSegger();
	~TImSegger();
	processmanagerdefault::eModuleType type() { return processmanagerdefault::ModuleType_ImSegger; };
	virtual void Init(void * pParam1, char * pParam2);
	virtual bool IsProcessingFinished(ProcessParamsHolder &);
	virtual bool NeedProcess(ProcessParamsHolder &, TResultContainerList &);
	bool isFinished();
	bool isResultReady();
	string GenerateJson(string &, TDwordArray *);
	int Process(int, TResultContainerList *, common::container::RclHolder &, string &);
};