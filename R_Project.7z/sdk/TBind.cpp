#include "TBind.h"
#include "../moduleprocessgl.h"
#include "../rclhelp.h"

TBind::TBind()
{
}

TBind::~TBind()
{
}

void TBind::Init(void *, char *)
{
	m_bTSDKPC_IsInitial = moduleprocessgl::isCommandSupported(PGC_TBind);
}

bool TBind::IsProcessingFinished(ProcessParamsHolder & a2)
{
	if (m_bTSDKPC_IsInitial && (a2.m_nPPH_processParam & 0x20))
		return m_bTSDKPC_IsFinished != 0;
	return true;
}

bool TBind::NeedProcess(ProcessParamsHolder &a2, TResultContainerList &a3)
{
	if (m_bTSDKPC_IsInitial && (a2.m_nPPH_processParam & 0x20))
		return rclhelp::getContainerContent(&a3, 70) == 0;
	return false;
}

int TBind::Process(TResultContainerList *a2, common::container::RclHolder &a3, string &a4)
{
	a3.remove(70);
	common::container::RclHolder v22;
	if (a2)
	{
		v22.addNoCopy(a2);
		vector<int> v21 = rclhelp::getPages(*a2);
		for (vector<int>::iterator i = v21.begin(); i != v21.end(); ++i)
		{
			common::container::RclHolder v20;
			v20.addNoCopy(v22.getRcListByPage(*i));
			if (v20.hasRc(1))
			{
				void* v19 = 0;
				int res = moduleprocessgl::process(1301, &v20, a4.data(), (void **)&v19, 0);
				if (!res)
				{
					common::container::RclHolder v18;
					if (v19)
						v18.addNoCopy(*(TResultContainerList*)v19);
					v18.setPageIndex(*i);
					a3.addCopy(v18.getRcList(70));
				}
			}
		}
	}
	return 0;
}
