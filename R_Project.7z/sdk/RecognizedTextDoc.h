#pragma once
#include "../pch.h"
#include "../commonStruct.h"

class CRecognizedTextFieldSDK : public TDocVisualExtendedField
{
public:
	CRecognizedTextFieldSDK();
	~CRecognizedTextFieldSDK();
	void addString(char *, int, int *);
	void addString(int);
	void free();
	int generateLineRect(int, int);
	wstring generateUnicodeTextFromSymbols();
	int getData_length();
	char *getData_pointer();
	int getLCID();
	int getMask_length();
	char *getMask_pointer();
	int getType();
	int getTypeFull();
	float middleProb();
	uint minProb();
	CRecognizedTextFieldSDK &operator=(CRecognizedTextFieldSDK&);
	void reset();
	void resize(int);
	void set(CRecognizedTextFieldSDK*);
	void set(char*, int, eVisualFieldType);
	void set(string const&, eVisualFieldType);
	void set(string const&, int, eVisualFieldType);
	void setComparison(int);
	void setFieldName(char*);
	void setMask(char const*);
	void setType(eVisualFieldType);
	void setValidity(int);
	int symbolCount();
	void updateString(char const*, int);
};

class CRecognizedTextDoc : public TDocVisualExtendedInfo
{
public:
	int nDVEI_Capacity;

	CRecognizedTextDoc();
	~CRecognizedTextDoc();
	CRecognizedTextFieldSDK *add();
	CRecognizedTextFieldSDK *at(int);
	int count();
	CRecognizedTextFieldSDK *field(int);
	CRecognizedTextFieldSDK *find(eVisualFieldType);
	CRecognizedTextFieldSDK *find(eVisualFieldType, eRPRM_Lights);
	CRecognizedTextFieldSDK *getPList();
	int getPos(eVisualFieldType);
	CRecognizedTextDoc &operator=(CRecognizedTextDoc&);
	CRecognizedTextFieldSDK *operator[](int);
	int remove(int);
	void reserve(int);
	void reset();
	void resize(int);
	void set(CRecognizedTextDoc*);
	void setPList(CRecognizedTextFieldSDK const*);
};