#pragma once

#include "../moduleprocessgl.h"
#include "TSDKProcessingClass.h"
#include "../ProcessParamsHolder.h"
#include "../rclhelp.h"

class TMrzDetector : public TSDKProcessingClass
{
public:
	TMrzDetector();
	~TMrzDetector();
	processmanagerdefault::eModuleType type() { return processmanagerdefault::ModuleType_MrzDetector; };
	virtual void Init(void * pParam1, char * pParam2);
	virtual bool IsProcessingFinished(ProcessParamsHolder &);
	virtual bool NeedProcess(ProcessParamsHolder &, TResultContainerList &);
	bool isFinished();
	bool isResultReady();
	void StartNewFrame();
	void StartNewPage();
	int ResolutionFromMrzWidth(CDocFormat, int);
	string DetectorErrorToText(MRZDetectorErrorCode);
	int ReadMrzWithDetector(int, TResultContainerList *, char *, common::container::RclHolder &, string &);

public:
	bool m_bTMD_IsResReady;
};