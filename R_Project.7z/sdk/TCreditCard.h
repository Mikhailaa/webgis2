#pragma once

#include "../moduleprocessgl.h"
#include "TSDKProcessingClass.h"
#include "../ProcessParamsHolder.h"

class TCreditCard : public TSDKProcessingClass
{
public:
	TCreditCard();
	~TCreditCard();
	processmanagerdefault::eModuleType type() { return processmanagerdefault::ModuleType_CreditCard; };
	virtual void Init(void * pParam1, char * pParam2);
	virtual bool IsProcessingFinished(ProcessParamsHolder &);
	virtual bool NeedProcess(ProcessParamsHolder &, TResultContainerList &);
	bool isFinished();
	bool isResultReady();
	int Process(TResultContainerList *, common::container::RclHolder &, string &);
};