#pragma once

#include "../moduleprocessgl.h"
#include "TSDKProcessingClass.h"
#include "../common/container/RclHolder.h"
#include "../common/container/json.h"
#include "../rclhelp.h"
#include "../ProcessParamsHolder.h"
#include "../json/Value.h"

class TRecPass : public TSDKProcessingClass
{
public:
	TRecPass();
	~TRecPass() {};
	processmanagerdefault::eModuleType type() { return processmanagerdefault::ModuleType_RecPass; };
	virtual void Init(void * pParam1, char * pParam2);
	virtual bool IsProcessingFinished(ProcessParamsHolder &);
	virtual bool NeedProcess(ProcessParamsHolder &, TResultContainerList &);
	bool isFinished();
	bool isResultReady();
	void StartNewFrame();
	void StartNewPage();
	void StartNewDocument();
	void setForceDocId(int);
	void setForceDocIds(common::container::RclHolder &);
	void resetForceDocIds();
	int Recognize(int, TResultContainerList *, string const &, common::container::RclHolder &, string &, int);

public:
	map<int, Json::Value> m_mTRP_field_20;
	int m_nTRP_field_2C;
	common::container::RclHolder m_xRH_field_30;
};