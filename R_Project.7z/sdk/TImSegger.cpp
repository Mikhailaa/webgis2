#include "TImSegger.h"

TImSegger::TImSegger()
{

}

TImSegger::~TImSegger()
{

}

void TImSegger::Init(void * pParam1, char * pParam2)
{
	m_bTSDKPC_IsInitial = moduleprocessgl::isCommandSupported(PGC_TImSegger);	// 302
}

bool TImSegger::IsProcessingFinished(ProcessParamsHolder & xPPH_Param1)
{
	bool bRes;
	if (m_bTSDKPC_IsInitial && (xPPH_Param1.m_nPPH_processParam & 0x80) && !m_bTSDKPC_IsFinished)
		bRes = (rclhelp::getContainerContent(&m_pTSDKPC_RH_field_1C->m_xTRCL, 9) == 0);
	else
		bRes = true;
	return bRes;
}

bool TImSegger::NeedProcess(ProcessParamsHolder & xPPH_Param1, TResultContainerList & xTRCL_Param2)
{
	bool bRes;
	if (m_bTSDKPC_IsInitial && (xPPH_Param1.m_nPPH_processParam & 0x80))
		bRes = (rclhelp::getContainerContent(&xTRCL_Param2, 17) == 0);
	else
		bRes = false;
	return bRes;
}

bool TImSegger::isFinished()
{
	return m_bTSDKPC_IsFinished;
}

bool TImSegger::isResultReady()
{
	return m_bTSDKPC_IsResReady;
}

string TImSegger::GenerateJson(string & strParam1, TDwordArray *pTDA_Param2)
{
	string res;
	if (strParam1.length())
	{
		GenericDocument<UTF8<char> > gd(kObjectType);
		int len = strParam1.length();
		GenericValue<UTF8<char> > gv(kArrayType);
		if (pTDA_Param2)
		{
			gv = common::container::json::ArrayToJson(pTDA_Param2->pnTDA_array, pTDA_Param2->nTDA_count, gd.GetAllocator());
		}
		gd.AddMember(StringRef(strParam1.data()),gv, gd.GetAllocator());
		GenericStringBuffer<UTF8<char> > sbuff;
		Writer<GenericStringBuffer<UTF8<char> > > wr(sbuff);
		gd.Accept(wr);
		res = sbuff.GetString();
	}
	return res;
}

int TImSegger::Process(int nParam1, TResultContainerList *pParam2, common::container::RclHolder & xRH_Param3, string & strParam4)
{
	int res = 54;
	string strTemp("TImSegger::Process()");
	// common::ScopeLogHelper::ScopeLogHelper
	xRH_Param3.remove(17);
	TDwordArray *pTDA = (TDwordArray *)rclhelp::getContainerContent(pParam2, 77);
	if (pTDA)
	{
		strTemp = "fieldTypesFilter";
		string strJson = GenerateJson(strTemp, pTDA);
		res = moduleprocessgl::process(309, 0, strJson.data(), 0, 0);
	}
	char *pC = 0;
	TResultContainerList *pTRCL = 0;
	if (nParam1 == 12204)
	{
		res = moduleprocessgl::process(302, pParam2, strParam4.data(), (void **)&pTRCL, &pC);
		if (!res)
			m_bTSDKPC_IsFinished = 1;
		else
			pTRCL = 0;
	}
	else
	{
		res = moduleprocessgl::process(306, pParam2, strParam4.data(), (void **)&pTRCL, &pC);
		if (!res)
		{
			m_bTSDKPC_IsFinished = m_bTSDKPC_IsResReady = true;
		}
	}
	if (pTRCL)
	{
		xRH_Param3.addCopy(*pTRCL);
	}
	if (pTDA)
	{
		strTemp = "fieldTypesFilter";
		string strJson = GenerateJson(strTemp, 0);
		moduleprocessgl::process(309, 0, strJson.data(), 0, 0);
	}
	return res;
}