#include "TCanDetector.h"
#include "../moduleprocessgl.h"

TCanDetector::TCanDetector()
{
	m_nTCD_20 = 0;
}

TCanDetector::~TCanDetector()
{

}

void TCanDetector::Init(void * pParam1, char * pParam2)
{
	m_bTSDKPC_IsInitial = true;
}

void TCanDetector::Free(bool a2)
{
	if (a2) m_nTCD_20 = 1;
	TSDKProcessingClass::Free(a2);
}

bool TCanDetector::IsProcessingFinished(ProcessParamsHolder & xPPH_Param1)
{
	if (m_bTSDKPC_IsInitial && xPPH_Param1.m_fPPH_doDetectCan)
		return m_bTSDKPC_IsFinished;
	return true;
}

bool TCanDetector::NeedProcess(ProcessParamsHolder & xPPH_Param1, TResultContainerList & xTRCL_Param2)
{
	if (m_bTSDKPC_IsInitial && xPPH_Param1.m_fPPH_doDetectCan)
		return !m_bTSDKPC_IsResReady;
	return false;
}

bool TCanDetector::isResultReady()
{
	return m_bTSDKPC_IsResReady;
}

void TCanDetector::StartNewFrame(void)
{
	bool flag = false;
	if (m_pTSDKPC_RH_field_1C)
		flag = m_pTSDKPC_RH_field_1C->hasRc(3);
	m_bTSDKPC_IsResReady = flag;
	m_bTSDKPC_IsFinished = flag;
}

string TCanDetector::DetectorErrorToText(MRZDetectorErrorCode a2)
{
	string str;
	switch (a2)
	{
	case MRZ_DETECTED:
		str = "MRZ_DETECTED";
		break;
	case ENABLE_ALLOCATE_MEMORY:
		str = "ENABLE_ALLOCATE_MEMORY";
		break;
	case INPUT_CONTAINER_NULL_POINTER:
		str = "INPUT_CONTAINER_NULL_POINTER";
		break;
	case OUTPUT_CONTAINER_NULL_POINTER:
		str = "OUTPUT_CONTAINER_NULL_POINTER";
		break;
	case NO_GOOD_INPUT_IMAGE_FOUND:
		str = "NO_GOOD_INPUT_IMAGE_FOUND";
		break;
	case NO_DETECTION:
		str = "NO_DETECTION";
		break;
	case NO_CLASSIFER_LOADED_RECOGN_IMPOSSIBLE:
		str = "NO_CLASSIFER_LOADED_RECOGN_IMPOSSIBLE";
		break;
	case BAD_MRZ_SEGMENTATION:
		str = "BAD_MRZ_SEGMENTATION";
		break;
	case MRZ_RECOGNIZED_CONFIDENTLY:
		str = "MRZ_RECOGNIZED_CONFIDENTLY";
		break;
	case MRZ_RECOGNIZED_UNCONFIDENTLY:
		str = "MRZ_RECOGNIZED_UNCONFIDENTLY";
		break;
	case BAD_COMMAND:
		str = "BAD_COMMAND";
		break;
	case NO_INPUT_DOCUMENT_BOUNDS_FOUND:
		str = "NO_INPUT_DOCUMENT_BOUNDS_FOUND";
		break;
	case CONSECUTIVE_RESULTS_ARE_NOT_EQUAL:
		str = "CONSECUTIVE_RESULTS_ARE_NOT_EQUAL";
		break;
	case NO_DETECTION_MRZ_VERY_SMALL:
		str = "NO_DETECTION_MRZ_VERY_SMALL";
		break;
	case NO_DETECTION_MRZ_IS_VERY_CLOSE_TO_LEFT:
		str = "NO_DETECTION_MRZ_IS_VERY_CLOSE_TO_LEFT";
		break;
	case NO_DETECTION_MRZ_IS_VERY_CLOSE_TO_RIGHT:
		str = "NO_DETECTION_MRZ_IS_VERY_CLOSE_TO_RIGHT";
		break;
	case NO_DETECTION_MRZ_IS_VERY_CLOSE_TO_TOP:
		str = "NO_DETECTION_MRZ_IS_VERY_CLOSE_TO_TOP";
		break;
	case NO_DETECTION_MRZ_IS_VERY_CLOSE_TO_BOTTOM:
		str = "NO_DETECTION_MRZ_IS_VERY_CLOSE_TO_BOTTOM";
		break;
	case NO_DETECTION_MRZ_IS_OUT_OF_FOCUS:
		str = "NO_DETECTION_MRZ_IS_OUT_OF_FOCUS";
		break;
	case NO_RECOGNITION_MRZ_IS_OUT_OF_FOCUS:
		str = "NO_RECOGNITION_MRZ_IS_OUT_OF_FOCUS";
		break;
	case NO_RECOGNITION_STRONG_PERSPECTIVE:
		str = "NO_RECOGNITION_STRONG_PERSPECTIVE";
		break;
	case NO_RECOGNITION_MRZ_IS_VERY_SMALL:
		str = "NO_RECOGNITION_MRZ_IS_VERY_SMALL";
		break;
	default:
		str = "unknown result";
		break;
	}
	return str;
}

int TCanDetector::ReadCanWithDetector(TResultContainerList *a2, common::container::RclHolder &a3, string &a4)
{
	int nRet = 2;
	if (a2 && a2->nTRCL_Count)
	{
		nRet = 0;
		TResultContainerList *pRCL = 0;
		int err = processgl(2404, a2, 0, (void **)&pRCL, 0);
		if (err == MRZ_RECOGNIZED_CONFIDENTLY || err == NO_DETECTION) m_bTSDKPC_IsFinished = true;
		else m_bTSDKPC_IsFinished = false;
		if (pRCL)
		{
			for (uint i = 0; i < pRCL->nTRCL_Count; i++)
			{
				if (pRCL->pTRCL_TRC[i].nTRC_result_type == 1)
				{
					TRawImageContainer* pRIC = pRCL->pTRCL_TRC[i].u.pTRC_RIC;
					uint v21 = (pRIC->pxRIC_bmi->bmiHeader.biBitCount * pRIC->pxRIC_bmi->bmiHeader.biWidth + 31) / 32
						* pRIC->pxRIC_bmi->bmiHeader.biHeight;
					if (pRIC->pxRIC_bmi->bmiHeader.biSizeImage != 4 * v21)
					{
						//Log("wrong result image size (alignment): should be %d, got %d");
						nRet = 2;
					}
				}
				else if (pRCL->pTRCL_TRC[i].nTRC_result_type == 3)
				{
					TDocVisualExtendedInfo* pDVEI = pRCL->pTRCL_TRC[i].u.pTRC_DVEI;
					if (pDVEI)
					{
						for (int j = 0; j < pDVEI->nDVEI_Fields; j ++)
						{
							ushort wFieldType = pDVEI->pDVEI_ArrayFields[j].u0.s0.wFieldType;
							if (wFieldType == 159)
							{
								//Log("ft_Card_Access_Number = %s\n", pDVEI->pDVEI_ArrayFields[j].pszDVEF_Buf_Text);
								m_bTSDKPC_IsResReady = true;
							}
							else if (wFieldType == 51)
							{
								//Log("ft_MRZ_Strings = %s\n", pDVEI->pDVEI_ArrayFields[j].pszDVEF_Buf_Text);
							}
						}
					}
					if (a2->nTRCL_Count)
						pRCL->pTRCL_TRC[i].nTRC_page_idx = a2->pTRCL_TRC->nTRC_page_idx;
					a3.addCopy(pRCL->pTRCL_TRC[i]);
				}
				else if (pRCL->pTRCL_TRC[i].nTRC_result_type == 87)
				{
					TResultMRZDetector *pRMD = pRCL->pTRCL_TRC[i].u.pTRC_RMD;
					if (pRMD)
					{
						m_bTSDKPC_IsFinished = (err == MRZ_RECOGNIZED_CONFIDENTLY);
						//Log("MRZ detection resut:");
						//Log("%000.000f:%000.000f\t\t\t%000.000f:%000.000f", pRMD->rnRMD_boundingQuadrangle[0], pRMD->rnRMD_boundingQuadrangle[1], pRMD->rnRMD_boundingQuadrangle[2], pRMD->rnRMD_boundingQuadrangle[3]);
						//Log("%000.000f:%000.000f\t\t\t%000.000f:%000.000f", pRMD->rnRMD_boundingQuadrangle[6], pRMD->rnRMD_boundingQuadrangle[7], pRMD->rnRMD_boundingQuadrangle[4], pRMD->rnRMD_boundingQuadrangle[5]);
					}
					if (a2->nTRCL_Count)
						pRCL->pTRCL_TRC[i].nTRC_page_idx = a2->pTRCL_TRC->nTRC_page_idx;
					a3.addCopy(pRCL->pTRCL_TRC[i]);
				}
				else
				{
					if (a2->nTRCL_Count)
						pRCL->pTRCL_TRC[i].nTRC_page_idx = a2->pTRCL_TRC->nTRC_page_idx;
					a3.addCopy(pRCL->pTRCL_TRC[i]);
				}
				nRet = 0;
			}
		}
	}

	return nRet;
}