#pragma once

#include "../moduleprocessgl.h"
#include "TSDKProcessingClass.h"
#include "../ProcessParamsHolder.h"
#include "../rclhelp.h"

class TLex : public TSDKProcessingClass
{
public:
	TLex();
	~TLex();
	virtual void Init(void * pParam1, char * pParam2);
	virtual bool IsProcessingFinished(ProcessParamsHolder &);
	virtual bool NeedProcess(ProcessParamsHolder &, TResultContainerList &);
	int setParams(string &);
	int Process(TResultContainerList *, common::container::RclHolder &, string &);
};