#include "TCreditCard.h"
#include "RecognizedTextDoc.h"

TCreditCard::TCreditCard()
{

}

TCreditCard::~TCreditCard()
{

}

void TCreditCard::Init(void * pParam1, char * pParam2)
{
	m_bTSDKPC_IsInitial = moduleprocessgl::isCommandSupported(PGC_TCreditCard);	// 313
}

bool TCreditCard::IsProcessingFinished(ProcessParamsHolder & xPPH_Param1)
{
	return m_bTSDKPC_IsFinished;
}

bool TCreditCard::NeedProcess(ProcessParamsHolder & xPPH_Param1, TResultContainerList & xTRCL_Param2)
{
	return !isFinished();
}

bool TCreditCard::isFinished()
{
	return m_bTSDKPC_IsFinished;
}

bool TCreditCard::isResultReady()
{
	return m_bTSDKPC_IsFinished;
}

int TCreditCard::Process(TResultContainerList *pTRCL_Param1, common::container::RclHolder & xRH_Param2, string & strParam3)
{
	string strTemp("TCreditCard::Process()");
	// common::ScopeLogHelper::ScopeLogHelper
	TResultContainerList *pTRCL = 0;
	int res = moduleprocessgl::process(313, pTRCL_Param1, strParam3.data(), (void **)&pTRCL, 0);
	if (!res)
	{
		common::container::RclHolder rh;
		rh.addCopy(*pTRCL);
		vector<TResultContainer *> vTRC = rh.getRcList(17);
		if (vTRC.size())
		{
			CRecognizedTextDoc *pCRTD = (CRecognizedTextDoc *)vTRC[0]->u.pTRC_CHAR;
			if (pCRTD && pCRTD->getPos(VisualFieldType_1ED) != -1)
			{
				for (uint i = 0; i < pTRCL->nTRCL_Count; i++)
				{
					xRH_Param2.addCopy(pTRCL->pTRCL_TRC[i]);
				}
				m_bTSDKPC_IsFinished = 1;
			}
		}
	}
	return res;
}