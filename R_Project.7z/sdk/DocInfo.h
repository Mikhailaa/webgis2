#pragma once
#include "../pch.h"
#include "../Field/VisualField.h"

class CDocInfo : public TDocInfo
{
public:
	CDocInfo();
	~CDocInfo();
	void reset();
	int count();
	int id();
	CVisualField *get(int);
	CVisualField *find(int);
	void resize(int);
	void reverseH(int);
	void updateDPI(int);
	int addShift(TBindingResultsList &);
};