#include "StringResultSDK.h"
#include "SymbolResult.h"

CStringResultSDK::CStringResultSDK()
{
	memclr(this, sizeof(CStringResultSDK));
}

CStringResultSDK::~CStringResultSDK()
{
}

CStringResultSDK & CStringResultSDK::operator=(CStringResultSDK &xCSRSDK)
{
	set(&xCSRSDK);
	return (*this);
}

void CStringResultSDK::resize(int nSize)
{
	if (pTSRS_StringResult) delete[] pTSRS_StringResult;
	nTSRS_SymbolsCount = 0;
	pTSRS_StringResult = 0;
	if (nSize)
	{
		CSymbolResult *pCSR = new CSymbolResult[nSize];
		nTSRS_SymbolsCount = nSize;
		pTSRS_StringResult = (TSymbolResult *)pCSR;
	}
}

void CStringResultSDK::set(CStringResultSDK *pCSRSDK)
{
	resize(pCSRSDK->nTSRS_SymbolsCount);
	if (pTSRS_StringResult)
	{
		for (uint i = 0; i < nTSRS_SymbolsCount; i++)
			memcpy(&pTSRS_StringResult[i], &pCSRSDK->pTSRS_StringResult[i], sizeof(TSymbolResult));
		nTSRS_Reserved = pCSRSDK->nTSRS_Reserved;
	}
}

void CStringResultSDK::set(char *pchar_a1, int n_a2, int *pn_a3)
{
	int nTmp;
	resize(n_a2);
	for (int i = 0; i < n_a2; i++)
	{
		if (pn_a3)
			nTmp = pn_a3[i];
		else
			nTmp = 100;
		((CSymbolResult *)pTSRS_StringResult)[i].addSymbolCandidate(pchar_a1[i], nTmp, 0, 0);
	}
}
