#include "TDocBoundLocator.h"
#include "../common/container/jsoncpp.h"

TDocBoundLocator::TDocBoundLocator()
{
	m_bTDBL_IsResReady = false;
}

TDocBoundLocator::~TDocBoundLocator()
{

}

void TDocBoundLocator::Init(void * pParam1, char * pParam2)
{
	m_bTSDKPC_IsInitial = moduleprocessgl::isCommandSupported(PGC_TDocBoundLocator);	// 514
}

bool TDocBoundLocator::IsProcessingFinished(ProcessParamsHolder & xPPH_Param1)
{
	bool bRes;
	bool b2, b3;
	if (xPPH_Param1.m_nPPH_processParam & 0x8000)
		b2 = m_bTSDKPC_IsFinished;
	else
		b2 = true;
	if (xPPH_Param1.m_nPPH_processParam & 0x10)
		b3 = m_bTDBL_IsResReady;
	else
		b3 = true;
	if (m_bTSDKPC_IsInitial)
		bRes = b2 && b3;
	else
		bRes = true;
	return bRes;
}

bool TDocBoundLocator::NeedProcess(ProcessParamsHolder & xPPH_Param1, TResultContainerList & xTRCL_Param2)
{
	if (!m_bTSDKPC_IsInitial)
		return false;
	bool bRes;
	if (xPPH_Param1.m_nPPH_processParam & 0x8000)
		bRes = true;
	else
		bRes = (xPPH_Param1.m_nPPH_processParam >> 4) & 1;
	return bRes;
}

bool TDocBoundLocator::isFinished()
{
	return m_bTSDKPC_IsFinished;
}

bool TDocBoundLocator::isResultReady()
{
	return m_bTDBL_IsResReady;
}

void TDocBoundLocator::StartNewFrame()
{
	TSDKProcessingClass::StartNewFrame();
	m_bTDBL_IsResReady = false;
}

bool TDocBoundLocator::NeedCrop(ProcessParamsHolder & xPPH_Param1, TResultContainerList & xTRCL_Param2)
{
	bool bRes;
	if (m_bTSDKPC_IsInitial && (xPPH_Param1.m_nPPH_processParam & 0x10) && rclhelp::getContainerContent(&xTRCL_Param2, 0x55))
		bRes = (m_nTSDKPC_result == 0);
	else
		bRes = false;
	return bRes;
}

int TDocBoundLocator::FindDocumentLocation(int nParam1, common::container::RclHolder & xRH_Param2, 
	common::container::RclHolder & xRH_Param3, string & strParam3)
{
	int res = 1;
	string strTemp("FindDocumentLocation");
	// common::ScopeLogHelper::ScopeLogHelper
	if (xRH_Param2.hasRc(0x57) && !xRH_Param3.hasRc(0x57))
	{
		Json::Value jv1(Json::json_type_null);
		common::container::jsoncpp::convert(strParam3, jv1);
		jv1["boundsParam"]["MrzFromOtherFrame"] = Json::Value(true);
		common::container::jsoncpp::convert(jv1, strParam3);
	}
	if (nParam1 == 0x2FAC)
	{
		strTemp = "Executing ePC_Bounds_DetectBounds...";
		// common::ScopeLogHelper::AppendToLog<>
		res = ProcessGeneric(PGC_TBounds_DetectBounds, &xRH_Param2.m_xTRCL, xRH_Param3, strParam3);	// 511
		strTemp = "ePC_Bounds_DetectBounds: %s (%d)";
		string strRes("Ok");
		if (res)
			strRes = "Failed";
		// common::ScopeLogHelper::AppendToLog<char const*,int>
	}
	else
	{
		strTemp = "Executing ePC_Bounds_ProcessSeries...";
		// common::ScopeLogHelper::AppendToLog<>
		res = ProcessGeneric(PGC_TBounds_ProcessSeries, &xRH_Param2.m_xTRCL, xRH_Param3, strParam3);	// 523
		strTemp = "ePC_Bounds_ProcessSeries: %s (%d)";
		string strRes("Ok");
		if (res)
			strRes = "Failed";
		// common::ScopeLogHelper::AppendToLog<char const*,int>
	}
	if (!res)
	{
		vector<TBoundsResult *> vv = rclhelp::bounds::getBoundsResult(xRH_Param3, BoundsResultStatus_0);	// 0
		for (uint i = 0; i < vv.size(); i++)
		{
			m_bTSDKPC_IsFinished = true;
			strTemp = "format = %d, W = %d, H = %d, LB = %d:%d, RB = %d:%d, RT = %d:%d, LT = %d:%d, angle = %f";
			// common::ScopeLogHelper::AppendToLog<int,int,int,int,int,int,int,int,int,int,int,float>
		}
	}
	return res;
}

int TDocBoundLocator::locate(common::container::RclHolder & xRH_Param1, common::container::RclHolder & xRH_Param2, float fParam3, Size & xParam4)
{
	int res = 2;
	updateFacePosition(xRH_Param1);
	updateMrzCoordinates(xRH_Param1);
	vector<TResultContainer *> vTRC = xRH_Param1.getRcList(1);
	if (vTRC.empty())
		return 2;
	vector<TResultContainer *> vTRC1 = xRH_Param1.getRcList(0x55);
	if (vTRC1.empty())
		return 2;
	common::container::RclHolder rh;
	rh.addNoCopy(vTRC);
	for (uint i = 0; i < vTRC1.size(); i++)
	{
		if (vTRC1[i]->u.pTRC_TBR)
		{
			TBoundsResult tbr;
			memcpy(&tbr, vTRC1[i]->u.pTRC_TBR, sizeof(TBoundsResult));
			if (fParam3 || (xParam4.width * xParam4.height))
			{
				if (xParam4.width * xParam4.height == 0)
				{
					xParam4.width = (int)((1.0 + fParam3) * tbr.nTBR_Width);
					xParam4.height = (int)((1.0 + fParam3) * tbr.nTBR_Height);
				}
				tbr.nTBR_Width = xParam4.width;
				tbr.nTBR_Height = xParam4.height;
				int wd = (int)((tbr.xTBR_RightTop.x - tbr.xTBR_LeftBottom.x) * fParam3);
				int hd = (int)((tbr.xTBR_RightTop.y - tbr.xTBR_LeftBottom.y) * fParam3);
				tagPOINT pLT, pLB, pRT, pRB;
				pLT.x = tbr.xTBR_LeftTop.x - (int)((tbr.xTBR_RightBottom.x - tbr.xTBR_LeftTop.x) * fParam3);
				pLT.y = tbr.xTBR_LeftTop.y - (int)((tbr.xTBR_RightBottom.y - tbr.xTBR_LeftTop.y) * fParam3);
				pLB.x = tbr.xTBR_LeftBottom.x - wd;
				pLB.y = tbr.xTBR_LeftBottom.y - hd;
				pRT.x = tbr.xTBR_RightTop.x + wd;
				pRT.y = tbr.xTBR_RightTop.y + hd;
				pRB.x = tbr.xTBR_RightBottom.x + (int)((tbr.xTBR_RightBottom.x - tbr.xTBR_LeftTop.x) * fParam3);
				pRB.y = tbr.xTBR_RightBottom.y + (int)((tbr.xTBR_RightBottom.y - tbr.xTBR_LeftTop.y) * fParam3);
				tbr.xTBR_LeftTop.x = pLT.x;
				tbr.xTBR_LeftTop.y = pLT.y;
				tbr.xTBR_LeftBottom.x = pLB.x;
				tbr.xTBR_LeftBottom.y = pLB.y;
				tbr.xTBR_RightTop.x = pRT.x;
				tbr.xTBR_RightTop.y = pRT.y;
				tbr.xTBR_RightBottom.x = pRB.x;
				tbr.xTBR_RightBottom.y = pRB.y;
			}
			rh.addNewCopy(85, &tbr, 0)->nTRC_page_idx = vTRC[i]->nTRC_page_idx;
		}
	}
	TResultContainerList *pTRCL = 0;
	m_nTSDKPC_result = moduleprocessgl::process(519, &rh, 0, (void **)&pTRCL, 0);
	if (m_nTSDKPC_result)
		return 2;
	if (pTRCL)
		xRH_Param2.addCopy(pTRCL);
	m_bTDBL_IsResReady = true;
	
	return 0;
}

int TDocBoundLocator::updateMrzCoordinates(common::container::RclHolder & xRH_Param)
{
	vector<shared_ptr<common::container::RclHolder> > vS = rclhelp::splitByPage(xRH_Param);
	for (uint i = 0; i < vS.size(); i++)
	{
		vector<TResultContainer *> vTRC = vS[i]->getRcList(3);
		vector<pair<tagRECT *, tagPOINT *> > vRP;
		if (vTRC.size())
		{
			for (uint j = 0; j < vTRC.size(); j++)
			{
				TDocVisualExtendedInfo *pTDVEI = vTRC[j]->u.pTRC_DVEI;
				if (pTDVEI)
				{
					for (int k = 0; k < pTDVEI->nDVEI_Fields; k++)
					{
						tagPOINT p;
						p.x = (pTDVEI->pDVEI_ArrayFields[k].u.xDVEF_FieldRect.left + pTDVEI->pDVEI_ArrayFields[k].u.xDVEF_FieldRect.right) / 2;
						p.x = (pTDVEI->pDVEI_ArrayFields[k].u.xDVEF_FieldRect.top + pTDVEI->pDVEI_ArrayFields[k].u.xDVEF_FieldRect.bottom) / 2;
						TResultContainer *pTRC = vS[i]->addNewCopy(60, &p, 0);
						vRP.push_back(pair<tagRECT *, tagPOINT *>(&pTDVEI->pDVEI_ArrayFields[k].u.xDVEF_FieldRect, pTRC->u.pTRC_POINT));
						for (int l = 0; l < pTDVEI->pDVEI_ArrayFields[k].nDVEF_StringsCount; l++)
						{
							for (uint m = 0; m < pTDVEI->pDVEI_ArrayFields[k].pDVEF_StringsResult[l].nTSRS_SymbolsCount; m++)
							{
								p.x = (pTDVEI->pDVEI_ArrayFields[k].pDVEF_StringsResult[l].pTSRS_StringResult[m].xTSR_SymbolRect.left +
									pTDVEI->pDVEI_ArrayFields[k].pDVEF_StringsResult[l].pTSRS_StringResult[m].xTSR_SymbolRect.right) / 2;
								p.y = (pTDVEI->pDVEI_ArrayFields[k].pDVEF_StringsResult[l].pTSRS_StringResult[m].xTSR_SymbolRect.top +
									pTDVEI->pDVEI_ArrayFields[k].pDVEF_StringsResult[l].pTSRS_StringResult[m].xTSR_SymbolRect.bottom) / 2;
								pTRC = vS[i]->addNewCopy(60, &p, 0);
								vRP.push_back(pair<tagRECT *, tagPOINT *>(&pTDVEI->pDVEI_ArrayFields[k].pDVEF_StringsResult[l].pTSRS_StringResult[m].xTSR_SymbolRect, pTRC->u.pTRC_POINT));
							}
						}
					}
				}
			}
			if (vTRC.size())
			{
				vector<TResultContainer *> vTRC1 = vS[i]->getRcList(61);
				for (uint j = 0; j < vTRC1.size(); j++)
				{
					TBoundsResult *pTBR = vTRC1[j]->u.pTRC_TBR;
					vS[i]->addNewCopy(60, &pTBR->xTBR_Center, 0);
					vS[i]->addNewCopy(60, &pTBR->xTBR_LeftTop, 0);
					vS[i]->addNewCopy(60, &pTBR->xTBR_RightTop, 0);
					vS[i]->addNewCopy(60, &pTBR->xTBR_RightBottom, 0);
					vS[i]->addNewCopy(60, &pTBR->xTBR_LeftBottom, 0);
				}
			}
			common::container::RclHolder rh;
			string strTemp;
			if (!ProcessGeneric(PGC_TBounds_ProcessSeries_524, &vS[i]->m_xTRCL, rh, strTemp))
			{
				for (uint j = 0; j < vRP.size(); j++)
				{
					if (vRP[j].first && vRP[j].second)
					{
						int n36 = (vRP[j].first->bottom - vRP[j].first->top) / 2;
						int n37 = (vRP[j].first->right - vRP[j].first->left) / 2;
						vRP[j].first->left = vRP[j].second->x - n37;
						vRP[j].first->right = vRP[j].second->x + n37;
						vRP[j].first->bottom = vRP[j].second->y - n36;
						vRP[j].first->top = vRP[j].second->y - n36;
					}
				}
			}
		}
	}
	return 0;
}

int TDocBoundLocator::updateFacePosition(common::container::RclHolder & xRH_Param)
{
	int res = 1;
	
	vector<TResultContainer *> vTRC = xRH_Param.getRcList(97);
	if (vTRC.empty())
		return 1;
	for (uint i = 0; i < vTRC.size(); i++)
	{
		CRectCandidats *pCRC = vTRC[i]->u.pTRC_CRC;
		for (int j = 0; j < pCRC->m_nRC_Count; j++)
		{
			tagPOINT p;
			p.x = pCRC->m_pRC_List[j].xRL_pRects.left + (pCRC->m_pRC_List[j].xRL_pRects.right - pCRC->m_pRC_List[j].xRL_pRects.left) / 2;
			p.y = pCRC->m_pRC_List[j].xRL_pRects.top + (pCRC->m_pRC_List[j].xRL_pRects.bottom - pCRC->m_pRC_List[j].xRL_pRects.top) / 2;
			xRH_Param.addNewCopy(60, &p, 0);
		}
	}
	common::container::RclHolder rh;
	string strTemp;
	if (ProcessGeneric(PGC_TBounds_ProcessSeries_524, &xRH_Param.m_xTRCL, rh, strTemp))
		return 1;
	vTRC = xRH_Param.getRcList(97);
	vector<TResultContainer *> vTRC1 = xRH_Param.getRcList(60);
	for (uint i = 0; i < vTRC.size(); i++)
	{
		CRectCandidats *pCRC = vTRC[i]->u.pTRC_CRC;
		if (pCRC)
		{
			uint k = 0;
			for (int j = 0; j < pCRC->m_nRC_Count; j++)
			{
				if (k < vTRC1.size())
				{
					tagPOINT *pPoint = vTRC1[k++]->u.pTRC_POINT;
					if (pPoint)
					{
						tagRECT r = pCRC->m_pRC_List[j].xRL_pRects;
						pCRC->m_pRC_List[j].xRL_pRects.left = pPoint->x - (r.right - r.left) / 2;
						pCRC->m_pRC_List[j].xRL_pRects.right = pPoint->x + (r.right - r.left) / 2;
						pCRC->m_pRC_List[j].xRL_pRects.top = pPoint->y - (r.bottom - r.top) / 2;
						pCRC->m_pRC_List[j].xRL_pRects.bottom = pPoint->y + (r.bottom - r.top) / 2;
					}
				}
			}
		}
	}
	
	return 0;
}