#include "ResultContainerList.h"

CResultContainer::CResultContainer()
{
	nTRC_result_type = 0;
	nTRC_light = RPRM_Lights_0;
	nTRC_buf_length = 0;
	u.pTRC_obj = 0;
	u1.nTRC_exposure = 0;
	pTRC_XML_buffer = NULL;
	nTRC_list_idx = 0;
	nTRC_page_idx = 0;
}

CResultContainer::~CResultContainer()
{
}

void * CResultContainer::internalPointer()
{
	return u.pTRC_obj;
}

void CResultContainer::dublicateByRefFrom(CResultContainer & a1)
{
	nTRC_result_type = a1.nTRC_result_type;
	nTRC_light = a1.nTRC_light;
	nTRC_buf_length = a1.nTRC_buf_length;
	u.pTRC_obj = a1.u.pTRC_obj;
	u1.nTRC_exposure = a1.u1.nTRC_exposure;
	pTRC_XML_buffer = a1.pTRC_XML_buffer;
	nTRC_list_idx = a1.nTRC_list_idx;
	nTRC_page_idx = a1.nTRC_page_idx;
}

void CResultContainer::moveFrom(CResultContainer & a1)
{
	nTRC_result_type = a1.nTRC_result_type;
	nTRC_light = a1.nTRC_light;
	nTRC_buf_length = a1.nTRC_buf_length;
	u.pTRC_obj = a1.u.pTRC_obj;
	u1.nTRC_exposure = a1.u1.nTRC_exposure;
	pTRC_XML_buffer = a1.pTRC_XML_buffer;
	nTRC_list_idx = a1.nTRC_list_idx;
	nTRC_page_idx = a1.nTRC_page_idx;

	a1.u.pTRC_obj = NULL;
	a1.nTRC_buf_length = 4;
	a1.nTRC_result_type = 100;
}

int CResultContainer::light()
{
	return nTRC_light & 0xFFFFFFF;
}

int CResultContainer::page()
{
	return nTRC_page_idx;
}

int CResultContainer::type()
{
	return nTRC_result_type;
}

CResultContainerList::CResultContainerList(void)
{
	m_nCRCL_8 = 0;
}

CResultContainerList::~CResultContainerList()
{
}

TResultContainer *CResultContainerList::addContainer(void)
{
	if (nTRCL_Count >= m_nCRCL_8)
	{
		if (m_nCRCL_8)
		{
			reserve(2 * m_nCRCL_8);
		}
		else
		{
			reserve(1);
		}
	}
	nTRCL_Count ++;
	if (nTRCL_Count == -1)
		return 0;
	
	return &pTRCL_TRC[nTRCL_Count - 1];
}

void CResultContainerList::reserve(int)
{

}


CResultContainerListR::CResultContainerListR()
{
	nTRCL_Count = 0;
	pTRCL_TRC = 0;
}

CResultContainerListR::~CResultContainerListR()
{
}

uint CResultContainerListR::count()
{
	return nTRCL_Count;
}

CResultContainer * CResultContainerListR::container(int a1)
{
	if (nTRCL_Count > (uint)a1)
		return (CResultContainer *)&pTRCL_TRC[a1];
	return 0;
}

CResultContainer * CResultContainerListR::find(eRPRM_ResultType a1, eRPRM_Lights a2, int a3, int * a4, int a5)
{
	if (nTRCL_Count <= (uint)a3)
		return 0;

	uint i;
	CResultContainer *pCRC;

	for (i = 0; i < nTRCL_Count; i++)
	{
		pCRC = (CResultContainer *)&pTRCL_TRC[i];
		if (pCRC->type() == a1 && (a2 == -1 || (pCRC->light() & 0xFFFFFFF) == a2))
		{
			if (a5 == -1)
				break;
			if (pCRC->page() == a5)
				break;
		}
	}

	if (i == nTRCL_Count)
	{
		if (a4)
			*a4 = -1;
		return 0;
	}

	if (a4)
		*a4 = i;
	return pCRC;
}

CResultContainer * CResultContainerListR::find(eRPRM_ResultType a1, eRPRM_Lights a2, int a3, int * a4)
{
	if (nTRCL_Count <= (uint)a3)
		return 0;

	for (uint i = 0; i < nTRCL_Count; i++)
	{
		CResultContainer *pCRC = (CResultContainer *)&pTRCL_TRC[i];
		if (pCRC->type() == a1 && (a2 == -1 || (pCRC->light() & 0xFFFFFFF) == a2))
		{
			if (a4)
				*a4 = i;
			return pCRC;
		}
	}

	if (a4)
		*a4 = -1;
	return 0;
}

CResultContainer * CResultContainerListR::operator[](int a1)
{
	if (nTRCL_Count > (uint)a1)
		return (CResultContainer *)&pTRCL_TRC[a1];
	else
		return 0;
}

namespace ResultContainerListNS {
	tagSIZE imageSize(CResultContainerListR & a1)
	{
		tagSIZE v1 = {0};
		CResultContainer * v2;
		TRawImageContainer * v3;

		for (uint i = 0; i < a1.count(); i++)
		{
			v2 = a1[i];
			if (v2 && v2->type() == 1)
			{
				v3 = (TRawImageContainer*)v2->internalPointer();
				if (v3 && v3->pxRIC_bmi)
				{
					v1.cx = v3->pxRIC_bmi->bmiHeader.biWidth;
					v1.cy = v3->pxRIC_bmi->bmiHeader.biHeight;
				}
				break;
			}
		}

		return v1;
	}

	int imageResolution(CResultContainerListR &a1)
	{
		for (uint i = 0; i < a1.count(); ++i)
		{
			CResultContainer *v3 = a1[i];
			if (v3->type() == 1 && v3->internalPointer())
			{
				TRawImageContainer* v4 = (TRawImageContainer *)v3->internalPointer();
				if (v4->pxRIC_bmi)
				{
					if(v4->pxRIC_bmi->bmiHeader.biXPelsPerMeter)
						return v4->pxRIC_bmi->bmiHeader.biXPelsPerMeter;
				}
			}
		}
		return 0;
	}
}