#include "TGraphicFieldCropper.h"

void TGraphicFieldCropper::Init(void * pParam1, char * pParam2)
{
	m_bTSDKPC_IsInitial = moduleprocessgl::isCommandSupported(PGC_TGraphicFieldCropper);	// 13401
}

bool TGraphicFieldCropper::IsProcessingFinished(ProcessParamsHolder &)
{
	return m_bTSDKPC_IsFinished;
}

bool TGraphicFieldCropper::NeedProcess(ProcessParamsHolder & xPPH_Param1, TResultContainerList & xTRCL_Param2)
{
	bool bRes;
	if (m_bTSDKPC_IsInitial && (xPPH_Param1.m_nPPH_processParam & 4))
		bRes = (0 == rclhelp::getContainerContent(&xTRCL_Param2, 6));
	else
		bRes = false;
	return bRes;
}

int TGraphicFieldCropper::Process(TResultContainerList *pTRCL_Param1, common::container::RclHolder & xRH_Param2, string & strParam3)
{
	string strTemp("TGraphicFieldCropper::Process()");
	//common::ScopeLogHelper::ScopeLogHelper
	TResultContainerList *pTRCL = 0;
	int res = moduleprocessgl::process(13401, pTRCL_Param1, strParam3.data(), (void **)&pTRCL, 0);
	if (!res)
	{
		m_bTSDKPC_IsFinished = 1;
		if (pTRCL)
		{
			xRH_Param2.addCopy(pTRCL);
		}
	}
	return res;
}
