#include "TMrzDetector.h"
#include "../Log.h"

TMrzDetector::TMrzDetector()
{
	m_bTMD_IsResReady = false;
}

TMrzDetector::~TMrzDetector()
{

}

void TMrzDetector::Init(void * pParam1, char * pParam2)
{
	m_bTSDKPC_IsInitial = moduleprocessgl::isCommandSupported(PGC_TMrzDetector);	// 2400
}

bool TMrzDetector::IsProcessingFinished(ProcessParamsHolder & xPPH_Param1)
{
	if (m_bTSDKPC_IsInitial && (xPPH_Param1.m_nPPH_processParam & 0x40))
		return m_bTSDKPC_IsFinished;
	return true;
}

bool TMrzDetector::NeedProcess(ProcessParamsHolder & xPPH_Param1, TResultContainerList & xTRCL_Param2)
{
	if (m_bTSDKPC_IsInitial && (xPPH_Param1.m_nPPH_processParam & 0x40))
		return !isFinished();
	return false;
}

bool TMrzDetector::isFinished()
{
	return m_bTSDKPC_IsFinished;
}

bool TMrzDetector::isResultReady()
{
	return m_bTSDKPC_IsResReady;
}

void TMrzDetector::StartNewFrame()
{
	bool flag = false;
	if (m_pTSDKPC_RH_field_1C)
		flag = m_pTSDKPC_RH_field_1C->hasRc(3);
	m_bTSDKPC_IsResReady = flag;
	m_bTSDKPC_IsFinished = flag;
}

void TMrzDetector::StartNewPage()
{
	m_bTMD_IsResReady = false;
}

int TMrzDetector::ResolutionFromMrzWidth(CDocFormat eDF_Param1, int nParam2)
{
	//Log("TMrzDetector::ResolutionFromMrzWidth()");
	int res = 0;
	double db[3] = { 77.6999969, 93.3000031, 114.0 };
	if (nParam2 && (eDF_Param1 < 3))
	{
		res = (int)(nParam2 / db[eDF_Param1] * 1000.0);
	}
	return res;
}

string TMrzDetector::DetectorErrorToText(MRZDetectorErrorCode nErrorCode)
{
	string strTemp = "TMrzDetector::DetectorErrorToText()";
	string res;
	// common::ScopeLogHelper::ScopeLogHelper
	switch (nErrorCode)
	{
	case MRZ_DETECTED:
		res = "MRZ_DETECTED";
		break;
	case ENABLE_ALLOCATE_MEMORY:
		res = "ENABLE_ALLOCATE_MEMORY";
		break;
	case INPUT_CONTAINER_NULL_POINTER:
		res = "INPUT_CONTAINER_NULL_POINTER";
		break;
	case OUTPUT_CONTAINER_NULL_POINTER:
		res = "OUTPUT_CONTAINER_NULL_POINTER";
		break;
	case NO_GOOD_INPUT_IMAGE_FOUND:
		res = "NO_GOOD_INPUT_IMAGE_FOUND";
		break;
	case NO_DETECTION:
		res = "NO_DETECTION";
		break;
	case NO_CLASSIFER_LOADED_RECOGN_IMPOSSIBLE:
		res = "NO_CLASSIFER_LOADED_RECOGN_IMPOSSIBLE";
		break;
	case BAD_MRZ_SEGMENTATION:
		res = "BAD_MRZ_SEGMENTATION";
		break;
	case MRZ_RECOGNIZED_CONFIDENTLY:
		res = "MRZ_RECOGNIZED_CONFIDENTLY";
		break;
	case MRZ_RECOGNIZED_UNCONFIDENTLY:
		res = "MRZ_RECOGNIZED_UNCONFIDENTLY";
		break;
	case BAD_COMMAND:
		res = "BAD_COMMAND";
		break;
	case NO_INPUT_DOCUMENT_BOUNDS_FOUND:
		res = "NO_INPUT_DOCUMENT_BOUNDS_FOUND";
		break;
	case CONSECUTIVE_RESULTS_ARE_NOT_EQUAL:
		res = "CONSECUTIVE_RESULTS_ARE_NOT_EQUAL";
		break;
	case NO_DETECTION_MRZ_VERY_SMALL:
		res = "NO_DETECTION_MRZ_VERY_SMALL";
		break;
	case NO_DETECTION_MRZ_IS_VERY_CLOSE_TO_LEFT:
		res = "NO_DETECTION_MRZ_IS_VERY_CLOSE_TO_LEFT";
		break;
	case NO_DETECTION_MRZ_IS_VERY_CLOSE_TO_RIGHT:
		res = "NO_DETECTION_MRZ_IS_VERY_CLOSE_TO_RIGHT";
		break;
	case NO_DETECTION_MRZ_IS_VERY_CLOSE_TO_TOP:
		res = "NO_DETECTION_MRZ_IS_VERY_CLOSE_TO_TOP";
		break;
	case NO_DETECTION_MRZ_IS_VERY_CLOSE_TO_BOTTOM:
		res = "NO_DETECTION_MRZ_IS_VERY_CLOSE_TO_BOTTOM";
		break;
	case NO_DETECTION_MRZ_IS_OUT_OF_FOCUS:
		res = "NO_DETECTION_MRZ_IS_OUT_OF_FOCUS";
		break;
	case NO_RECOGNITION_MRZ_IS_OUT_OF_FOCUS:
		res = "NO_RECOGNITION_MRZ_IS_OUT_OF_FOCUS";
		break;
	case NO_RECOGNITION_STRONG_PERSPECTIVE:
		res = "NO_RECOGNITION_STRONG_PERSPECTIVE";
		break;
	case NO_RECOGNITION_MRZ_IS_VERY_SMALL:
		res = "NO_RECOGNITION_MRZ_IS_VERY_SMALL";
		break;
	default:
		res = "unknown result";
		break;
	}
	return res;
}

int TMrzDetector::ReadMrzWithDetector(int nParam1, TResultContainerList * pTRCL_Param2, 
	char * pParam3, common::container::RclHolder & xRH_Param4, string & strParam5)
{
	int nRet = 2;
	//Log("TMrzDetector::ReadMrzWithDetector()");
	if (!pTRCL_Param2 || !pTRCL_Param2->nTRCL_Count)
		return nRet;
	common::container::RclHolder rh1(pTRCL_Param2, 1);
	vector<shared_ptr<common::container::RclHolder> > vv = rclhelp::splitByPage(rh1);
	int n48 = 2406;
	if (nParam1 == 12204)
		n48 = 2403;
	for (uint i = 0; i < vv.size(); i++)
	{
		common::container::RclHolder *pRH = vv[i].get();
		if (!pRH->empty())
		{
			nRet = 0;
			int nPage = rclhelp::getPage(pRH->m_xTRCL);
			//Log("detecting (mrzProcess(DETECT_AND_RECOGNIZE, ...))...");
			TResultContainerList *pTRCL = 0;
			int resTemp = processgl(n48, &pRH->m_xTRCL, pParam3, (void **)&pTRCL, 0);
			//Log("detecting (mrzProcess(DETECT_AND_RECOGNIZE, ...)) result %d: %s", resTemp, DetectorErrorToText((MRZDetectorErrorCode)resTemp));
			m_bTSDKPC_IsFinished = true;
			if (nParam1 != 12204)
			{
				m_bTSDKPC_IsFinished = (resTemp == NO_DETECTION || resTemp == MRZ_RECOGNIZED_CONFIDENTLY);
				m_bTMD_IsResReady = (m_bTMD_IsResReady || resTemp == MRZ_RECOGNIZED_UNCONFIDENTLY || resTemp == CONSECUTIVE_RESULTS_ARE_NOT_EQUAL);
				if (resTemp != MRZ_RECOGNIZED_CONFIDENTLY && m_bTMD_IsResReady)
				{
					m_bTSDKPC_IsFinished = false;
				}
			}
			if (pTRCL && pTRCL->nTRCL_Count)
			{
				common::container::RclHolder rh1(pTRCL, 1);
				pTRCL = 0;
				rh1.setPageIndex(nPage);
				vector<TResultContainer *> vTRC = rh1.getRcList(1);
				for (uint i = 0; i < vTRC.size(); i++)
				{
					vTRC[i]->nTRC_result_type = 66;
				}
				xRH_Param4.addCopy(rh1.m_xTRCL);
				vTRC = rh1.getRcList();
				for (uint i = 0; i < vTRC.size(); i++)
				{
					if (!vTRC[i]->u.pTRC_CHAR)
					{
						continue;
					}
					if (vTRC[i]->nTRC_result_type == 1)
					{
						uint n33 = ((vTRC[i]->u.pTRC_RIC->pxRIC_bmi->bmiHeader.biBitCount *
							vTRC[i]->u.pTRC_RIC->pxRIC_bmi->bmiHeader.biWidth + 31) / 32) * 4 *
							vTRC[i]->u.pTRC_RIC->pxRIC_bmi->bmiHeader.biHeight;
						if (vTRC[i]->u.pTRC_RIC->pxRIC_bmi->bmiHeader.biSizeImage != n33)
						{
							//Log("wrong result image size (alignment): should be %ld, got %d", n33, vTRC[i]->u.pTRC_RIC->pxRIC_bmi->bmiHeader.biSizeImage);
							nRet = 1;
						}
					}
					else if (vTRC[i]->nTRC_result_type == 3)
					{
						//Log("got %d fields", pTDVEI->nDVEI_Fields);
						TDocVisualExtendedInfo *pTDVEI = vTRC[i]->u.pTRC_DVEI;
						//Log("==================== MRZ Results ====================\n");
						fwprintf(g_log.m_fpLog, L"==================== MRZ Results ====================\r\n");
						for (int j = 0; j < pTDVEI->nDVEI_Fields; j++)
						{
							//Log("%s : %s\n", pTDVEI->pDVEI_ArrayFields[j].szDVEF_FieldName, pTDVEI->pDVEI_ArrayFields[j].pszDVEF_Buf_Text);
							fwprintf(g_log.m_fpLog, L"%S : %S\r\n", pTDVEI->pDVEI_ArrayFields[j].szDVEF_FieldName, pTDVEI->pDVEI_ArrayFields[j].pszDVEF_Buf_Text);
							memset(pTDVEI->pDVEI_ArrayFields[j].szDVEF_FieldName, 0, 256);
						}
						m_bTSDKPC_IsResReady = true;
					}
					else if (vTRC[i]->nTRC_result_type == 87)
					{
						TResultMRZDetector *pTRMRZD = vTRC[i]->u.pTRC_RMD;
						xRH_Param4.addNewCopy(95, (void *)pTRMRZD->nRMD_MRZFormat, 0)->nTRC_page_idx = nPage;
						//Log("MRZ detection resut: MRZ doc format %d", pTRMRZD->nRMD_MRZFormat);
						//Log("%000.000f:%000.000f\t\t\t%000.000f:%000.000f", pTRMRZD->rnRMD_boundingQuadrangle[0], pTRMRZD->rnRMD_boundingQuadrangle[1], pTRMRZD->rnRMD_boundingQuadrangle[2], pTRMRZD->rnRMD_boundingQuadrangle[3]);
						//Log("%000.000f:%000.000f\t\t\t%000.000f:%000.000f", pTRMRZD->rnRMD_boundingQuadrangle[6], pTRMRZD->rnRMD_boundingQuadrangle[7], pTRMRZD->rnRMD_boundingQuadrangle[4], pTRMRZD->rnRMD_boundingQuadrangle[5]);
					}
				}
				nRet = 0;
			}
		}
	}

	return nRet;
}