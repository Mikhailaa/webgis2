#include "AuthenticityCheckResult.h"

AuthenticityCheckResult::AuthenticityCheckResult()
{
	this->nACR_Type = 0;
	this->nACR_Result = 0;
	this->nACR_Count = 0;
	this->ppACR_List = 0;
}

AuthenticityCheckResult::~AuthenticityCheckResult()
{
	free();
}

void AuthenticityCheckResult::generateCommonResult()
{
	this->nACR_Result = -1;
	if (this->nACR_Type == 16)
	{
		for (int i = 0; i < this->nACR_Count; i++)
		{
			ushort* v14 = (ushort*)this->ppACR_List[i];
			if (*v14 == 0)
			{
				this->nACR_Result = 0;
			}
			else if (*v14 == 1)
			{
				if ((this->nACR_Result | 2) != 2)
					this->nACR_Result = 1;
			}
			else if (*v14 == 2)
			{
				if (this->nACR_Result)
				{
					this->nACR_Result = 2;
				}
				else
				{
					this->nACR_Result = 0;
				}
			}
		}
	}
	else if (this->nACR_Type == 4 || this->nACR_Type == 32)
	{
		for (int i = 0; i < this->nACR_Count; ++i)
		{
			ushort* v7 = (ushort*)this->ppACR_List[i];
			if (*v7 == 0)
			{
				this->nACR_Result = 0;
			}
			else if (*v7 == 2)
			{
				if (this->nACR_Result)
				{
					this->nACR_Result = 2;
				}
			}
			else if (*v7 == 1)
			{
				if ((this->nACR_Result | 2) != 2)
					this->nACR_Result = 1;
			}
			if (*v7 != 1)
			{
				for (int j = 0; j < i; ++j)
				{
					if (*(ushort *)this->ppACR_List[j] == 1)
					{
						exchangePointers(i, j);
						break;
					}
				}
			}
		}
	}
	else if (this->nACR_Type == 0x40)
	{
		for (int i = 0; i < this->nACR_Count; ++i)
		{
			ushort* v19 = (ushort*)this->ppACR_List[i];
			if (*v19 == 0)
			{
				this->nACR_Result = 0;
			}
			else if (*v19 == 1)
			{
				if ((this->nACR_Result | 2) != 2)
					this->nACR_Result = 1;
			}
			else if (*v19 == 2)
			{
				if (this->nACR_Result)
				{
					this->nACR_Result = 2;
				}
				else
				{
					this->nACR_Result = 0;
				}
			}
		}
	}
	else if (this->nACR_Type == 0x80)
	{
		for (int i = 0; i < this->nACR_Count; ++i)
		{
			ushort* v24 = (ushort*)this->ppACR_List[i];
			if (*v24 == 0)
			{
				this->nACR_Result = 0;
			}
			else if (*v24 == 1)
			{
				if ((this->nACR_Result | 2) != 2)
					this->nACR_Result = 1;
			}
			else if (*v24 == 2)
			{
				if (this->nACR_Result)
				{
					this->nACR_Result = 2;
				}
				else
				{
					this->nACR_Result = 0;
				}
			}
		}
	}
	else if (this->nACR_Type == 0x10000)
	{
		for (int i = 0; i < this->nACR_Count; ++i)
		{
			if (((SecurityFeatureCheck *)this->ppACR_List[i])->getElementResult() == CheckResult_0)
				this->nACR_Result = 0;
			if (((SecurityFeatureCheck *)this->ppACR_List[i])->getElementResult() == CheckResult_1 && 
				(this->nACR_Result | 2) != 2)
				this->nACR_Result = 1;
			if (((SecurityFeatureCheck *)this->ppACR_List[i])->getElementResult() == CheckResult_2 && 
				(this->nACR_Result >= 2 || this->nACR_Result < 2))
			{
				this->nACR_Result = 2;
			}
		}
	}
	else
	{
		for (int i = 0; i < this->nACR_Count; ++i)
		{
			if (((SecurityFeatureCheck *)this->ppACR_List[i])->getElementResult() == CheckResult_0)
				this->nACR_Result = 0;
			if (((SecurityFeatureCheck *)this->ppACR_List[i])->getElementResult() == CheckResult_1 && 
				(this->nACR_Result | 2) != 2)
				this->nACR_Result = 1;
			if (((SecurityFeatureCheck *)this->ppACR_List[i])->getElementResult() == CheckResult_2 && this->nACR_Result)
				this->nACR_Result = 2;
			if (((SecurityFeatureCheck *)this->ppACR_List[i])->getElementResult() != CheckResult_1)
			{
				for (int j = 0; j < i; ++j)
				{
					if (((SecurityFeatureCheck *)this->ppACR_List[i])->getElementResult() == CheckResult_1)
					{
						exchangePointers(i, j);
						break;
					}
				}
			}
		}
	}
}

int AuthenticityCheckResult::reserve(int a2)
{
	if (this->nACR_Count < a2)
	{
		void **v4 = new void *[a2];
		for (int i = 0; i < this->nACR_Count; ++i)
			v4[i] = this->ppACR_List[i];
		if (this->ppACR_List)
			delete[] this->ppACR_List;
		this->ppACR_List = v4;
	}
	return 0;
}

int AuthenticityCheckResult::exchangePointers(int a2, int a3)
{
	if (a2 >= 0)
	{
		if (this->nACR_Count > a3 && a3 >= 0 && this->nACR_Count > a2)
		{
			void* v5 = this->ppACR_List[a2];
			this->ppACR_List[a2] = this->ppACR_List[a3];
			this->ppACR_List[a3] = v5;
		}
	}
	return 0;
}

void AuthenticityCheckResult::free()
{
	if (this->ppACR_List)
		delete[] this->ppACR_List;
	this->nACR_Type = 0;
	this->nACR_Result = 2;
	this->nACR_Count = 0;
	this->ppACR_List = 0;
}