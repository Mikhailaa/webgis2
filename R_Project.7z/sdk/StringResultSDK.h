#pragma once
#include "../commonStruct.h"

class CStringResultSDK : public TStringResultSDK
{
public:
	CStringResultSDK();
	~CStringResultSDK();
	CStringResultSDK &operator=(CStringResultSDK&);
	void resize(int);
	void set(CStringResultSDK*);
	void set(char*, int, int*);
};
