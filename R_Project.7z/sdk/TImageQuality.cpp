#include "TImageQuality.h"
#include "../regula.h"
#include "../common/container/jsoncpp.h"

TImageQuality::TImageQuality()
{

}

TImageQuality::~TImageQuality()
{

}

void TImageQuality::Init(void * pParam1, char * pParam2)
{
	m_bTSDKPC_IsInitial = moduleprocessgl::isCommandSupported(PGC_TImageQuality);	// 107
}

bool TImageQuality::IsProcessingFinished(ProcessParamsHolder & xPPH_Param1)
{
	bool bRes;
	if (m_bTSDKPC_IsInitial && (xPPH_Param1.m_nPPH_processParam & 0x10000))
		bRes = (m_bTSDKPC_IsFinished != 0);
	else
		bRes = true;
	return bRes;
}

bool TImageQuality::NeedProcess(ProcessParamsHolder & xPPH_Param1, TResultContainerList & xTRCL_Param2)
{
	bool bRes;
	if (m_bTSDKPC_IsInitial && (xPPH_Param1.m_nPPH_processParam & 0x10000))
		bRes = (rclhelp::getContainerContent(&xTRCL_Param2, 30) == 0);
	else
		bRes = false;
	return bRes;
}

TCheckResult TImageQuality::DoQC(TResultContainerList *pTRCL_Param1, common::container::RclHolder & xRH_Param2, 
	string & strParam3, eProcessGlCommands eParam4, eImageQualityCheckType eParam5)
{
	TCheckResult tcr;
	int nRes = ProcessGeneric(eParam4, pTRCL_Param1, xRH_Param2, strParam3);
	tcr.nTCR_pcr = nRes;
	tcr.nTCR_cr = 2;
	if (!nRes)
	{
		TImageQualityCheckList *pTIQCL = (TImageQualityCheckList *)rclhelp::getContainerContent(&xRH_Param2.m_xTRCL, 30);
		if (pTIQCL && pTIQCL->ppxIQCL_List)
		{
			for (uint i = 0; i < pTIQCL->nIQCL_Count; i++)
			{
				if (pTIQCL->ppxIQCL_List[i]->nIQC_type == eParam5)
				{
					tcr.nTCR_cr = pTIQCL->ppxIQCL_List[i]->nIQC_result;
					break;
				}
			}
		}
	}
	return tcr;
}

TCheckResult TImageQuality::CheckFocus(TResultContainerList *pTRCL_Param1, common::container::RclHolder & xRH_Param2, string & strParam3)
{
	string strTemp("TImageQuality::CheckFocus() begin");
	// log
	TCheckResult tcr = DoQC(pTRCL_Param1, xRH_Param2, strParam3, PGC_TImageQuality, ImageQualityCheckType_1);
	strTemp = "TImageQuality::CheckFocus() cmdResult: %i, checkResult: %i";
	// log
	return tcr;
}

TCheckResult TImageQuality::CheckGlares(TResultContainerList *pTRCL_Param1, common::container::RclHolder & xRH_Param2, string & strParam3)
{
	string strTemp("TImageQuality::CheckGlares() begin");
	// log
	TCheckResult tcr = DoQC(pTRCL_Param1, xRH_Param2, strParam3, PGC_TImageQuality_CheckGlares, ImageQualityCheckType_0);	// 108
	strTemp = "TImageQuality::CheckGlares() cmdResult: %i, checkResult: %i";
	// log
	return tcr;
}

TCheckResult TImageQuality::CheckFocusAndGlares(TResultContainerList *pTRCL_Param1, common::container::RclHolder & xRH_Param2, string & strParam3)
{
	common::container::RclHolder rh;
	TCheckResult tcr = CheckFocus(pTRCL_Param1, rh, strParam3);
	if (tcr.nTCR_cr == 1)
	{
		tcr = CheckGlares(pTRCL_Param1, rh, strParam3);
		FlattenQCResults(rh, xRH_Param2);
	}
	else
	{
		xRH_Param2.addCopy(rh.m_xTRCL);
	}
	return tcr;
}

TCheckResult TImageQuality::UpdateGlaresCoordinates(TResultContainerList *pTRCL_Param1, common::container::RclHolder & xRH_Param2, string & strParam3)
{
	string strTemp("TImageQuality::UpdateGlaresCoordinates() begin");
	// log
	TCheckResult tcr = DoQC(pTRCL_Param1, xRH_Param2, strParam3, PGC_TImageQuality_UpdateGlaresCoordinates, ImageQualityCheckType_0);	// 111
	strTemp = "TImageQuality::UpdateGlaresCoordinates() end";
	// log
	return tcr;
}

int TImageQuality::LocateAndCheck(TResultContainerList *pTRCL_Param1, common::container::RclHolder & xRH_Param2, string & strParam3, bool bParam4)
{
	common::container::RclHolder rh1(pTRCL_Param1, 1);
	vector<shared_ptr<common::container::RclHolder> > vS = rclhelp::splitByPage(rh1);
	for (uint i = 0; i < vS.size(); i++)
	{
		vector<TResultContainer *> vTRC = vS[i]->getRcList(1);
		if (!vTRC.size())
			continue;
		common::container::RclHolder rh2;
		if (bParam4)
		{
			TResultContainer *pTRC = rclhelp::findFirstContainer(vS[i]->m_xTRCL, 85);
			if (!pTRC || !pTRC->u.pTRC_TBR)
			{
				continue;
			}
			vector<TResultContainer *> vTRC1 = vS[i]->getRcList(1, regula::light::whiteGroup());
			int res = 3;
			if (vTRC1.size())
			{
				TBoundsResult tbr;
				memcpy(&tbr, pTRC->u.pTRC_TBR, sizeof(TBoundsResult));
				common::container::RclHolder rh3;
				rh3.addNewNoCopy(85, &tbr);
				rh3.addCopy(*vTRC1[0]);
				TResultContainerList *pTRCL = 0;
				m_nTSDKPC_result = moduleprocessgl::process(519, &rh3, 0, (void **)&pTRCL, 0);
				if (!m_nTSDKPC_result && pTRCL)
				{
					rh2.addNoCopy(pTRCL);
					res = 0;
				}
			}
			if (res)
				continue;
		}
		else
		{
			rh2.addNoCopy(vS[i]->m_xTRCL);
		}
		common::container::RclHolder rh4;
		TCheckResult tcr = CheckFocusAndGlares(&rh2.m_xTRCL, rh4, strParam3);
		m_nTSDKPC_result = tcr.nTCR_pcr;
		if (bParam4)
		{
			Json::Value jv(Json::json_type_null);
			TResultContainer *pTRC = rclhelp::findFirstContainer(vS[i]->m_xTRCL, 85);
			if (pTRC && pTRC->u.pTRC_TBR)
			{
				Json::Value jv1(Json::json_type_null);
				Json::Value jv2(Json::json_type_null);
				jv1["originalImageWidth"] = Json::Value(pTRC->u.pTRC_TBR->nTBR_Width);
				jv2["originalImageHeight"] = Json::Value(pTRC->u.pTRC_TBR->nTBR_Height);
				jv["imageQuality"].append(jv1);
				jv["imageQuality"].append(jv2);
			}
			string strTemp;
			common::container::jsoncpp::convert(jv, strTemp);
			UpdateGlaresCoordinates(&rh4.m_xTRCL, rh4, strTemp);
		}
		rh4.setPageIndex(rclhelp::getPage(vS[i]->m_xTRCL));
		xRH_Param2.addCopy(rh4.m_xTRCL);
	}

	return 0;
}

bool TImageQuality::IsEmpty(TResultContainer const & xTRC_Param)
{
	bool bRes = true;
	if (xTRC_Param.nTRC_result_type == 30)
	{
		TImageQualityCheckList *pTIQCL = xTRC_Param.u.pTRC_IQCL;
		if (xTRC_Param.u.pTRC_IQCL)
			bRes = (xTRC_Param.u.pTRC_IQCL->nIQCL_Count == 0);
		else
			bRes = true;
	}
	return bRes;
}

bool TImageQuality::IsError(TResultContainer const & xTRC_Param)
{
	bool bRes;
	if (IsEmpty(xTRC_Param))
		bRes = true;
	else
		bRes = (xTRC_Param.u.pTRC_IQCL->nIQCL_result == 0);
	return bRes;
}

bool TImageQuality::IsNotDone(TResultContainer const & xTRC_Param)
{
	bool bRes;
	if (IsEmpty(xTRC_Param))
		bRes = true;
	else
		bRes = (xTRC_Param.u.pTRC_IQCL->nIQCL_result == 2);
	return bRes;
}

bool TImageQuality::IsNotEmpty(TResultContainer const & xTRC_Param)
{
	return !IsEmpty(xTRC_Param);
}

bool TImageQuality::IsOk(TResultContainer const & xTRC_Param)
{
	bool bRes;
	if (IsEmpty(xTRC_Param))
		bRes = false;
	else
		bRes = (xTRC_Param.u.pTRC_IQCL->nIQCL_result == 1);
	return bRes;
}

int TImageQuality::GetQualityCheckType(TResultContainer const & xTRC_Param)
{
	if (!IsEmpty(xTRC_Param))
	{
		return xTRC_Param.u.pTRC_IQCL->nIQCL_result;
	}
	return 0;
}

eCheckResult TImageQuality::DetermineCommonCheckResult(TResultContainerList const & xTRCL_Param)
{
	uint i;
	eCheckResult res = CheckResult_1;
	for (i = 0; i < xTRCL_Param.nTRCL_Count; i++)
	{
		if (IsError(xTRCL_Param.pTRCL_TRC[i]) && GetQualityCheckType(xTRCL_Param.pTRCL_TRC[i]))
			break;
	}
	if (i == xTRCL_Param.nTRCL_Count)
		res = CheckResult_0;
	for (i = 0; i < xTRCL_Param.nTRCL_Count; i++)
	{
		if (IsNotDone(xTRCL_Param.pTRCL_TRC[i]) && GetQualityCheckType(xTRCL_Param.pTRCL_TRC[i]))
			break;
	}
	if (i == xTRCL_Param.nTRCL_Count)
		return (res ? CheckResult_0 : CheckResult_1);
	res = (res ? CheckResult_0 : CheckResult_2);
	return res;
}

void TImageQuality::FlattenQCResults(common::container::RclHolder const & xRH_Param1, common::container::RclHolder & xRH_Param2)
{
	if (xRH_Param1.m_xTRCL.nTRCL_Count && xRH_Param1.m_xTRCL.pTRCL_TRC)
	{
		int n = 0;
		for (uint i = 0; i < xRH_Param1.m_xTRCL.nTRCL_Count; i++)
		{
			n += IsNotEmpty(xRH_Param1.m_xTRCL.pTRCL_TRC[i]);
		}
		TImageQualityCheckList *pTIQCL = new TImageQualityCheckList;
		pTIQCL->nIQCL_Count = n;
		pTIQCL->nIQCL_result = DetermineCommonCheckResult(xRH_Param1.m_xTRCL);
		pTIQCL->ppxIQCL_List = new TImageQualityCheck*[n];
		for (uint i = 0, j = 0; i < xRH_Param1.m_xTRCL.nTRCL_Count; i++)
		{
			if (!IsEmpty(xRH_Param1.m_xTRCL.pTRCL_TRC[i]))
			{
				pTIQCL->ppxIQCL_List[j++] = xRH_Param1.m_xTRCL.pTRCL_TRC[i].u.pTRC_IQCL->ppxIQCL_List[0];
			}
		}
		TResultContainer trc = { 0 };
		memcpy(&trc, &xRH_Param1.m_xTRCL.pTRCL_TRC[0], sizeof(TResultContainer));
		trc.nTRC_buf_length = sizeof(TImageQualityCheckList);
		trc.u.pTRC_IQCL = pTIQCL;
		xRH_Param2.addCopy(trc);
		if (pTIQCL->ppxIQCL_List)
			delete[] pTIQCL->ppxIQCL_List;
		delete pTIQCL;
	}
}