#pragma once

#include "../common/container/RclHolder.h"
#include "../processmanagerdefault.h"
#include "../json/Value.h"

class TSDKProcessingClass : public processmanagerdefault::IModuleStatus, public processmanagerdefault::IModuleRequirements
{
public:
	TSDKProcessingClass();
	virtual ~TSDKProcessingClass();
	virtual void Init(void *, char *) = 0;

	bool isInitialized() { return m_bTSDKPC_IsInitial; };
	bool isProcessed() { return m_bTSDKPC_IsFinished; };
	bool isFinished() { return m_bTSDKPC_IsFinished; };
	bool isResultReady() { return m_bTSDKPC_IsFinished; };
	void ForceReady(bool bParam) { m_bTSDKPC_IsFinished = bParam; };
	virtual void Reset();
	virtual void Free(bool);
	virtual void StartNewFrame();
	virtual void StartNewPage();
	virtual void StartNewDocument();
	virtual bool IsProcessingFinished(ProcessParamsHolder &) = 0;
	virtual bool NeedProcess(ProcessParamsHolder &, TResultContainerList &) = 0;

	int ProcessGeneric(eProcessGlCommands, TResultContainerList *, common::container::RclHolder &, string &);
	const Json::Value& GetDocumentDescriptionValue(TResultContainerList const &, string const &);
	// ...

	static void FlipPointY(tagPOINT &, tagSIZE &);
	static void FlipRectY(tagRECT &, tagSIZE &);

public:
	//int m_nTSDKPC_field_10; // processmanagerdefault::IModuleRequirements
	bool m_bTSDKPC_IsInitial;
	bool m_bTSDKPC_IsFinished;
	bool m_bTSDKPC_IsResReady;
	bool m_bTSDKPC_field_17;
	int m_nTSDKPC_result;
	common::container::RclHolder *m_pTSDKPC_RH_field_1C;
};