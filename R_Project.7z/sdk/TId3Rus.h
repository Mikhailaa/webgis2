#pragma once

#include "../moduleprocessgl.h"
#include "TSDKProcessingClass.h"
#include "../ProcessParamsHolder.h"

class TId3Rus : public TSDKProcessingClass
{
public:
	TId3Rus() {};
	~TId3Rus() {};
	processmanagerdefault::eModuleType type() { return processmanagerdefault::ModuleType_Id3Rus; };
	virtual void Init(void *, char *);
	virtual bool IsProcessingFinished(ProcessParamsHolder &);
	virtual bool NeedProcess(ProcessParamsHolder &, TResultContainerList &);
	int Process(TResultContainerList *, common::container::RclHolder &, string &, bool);
};