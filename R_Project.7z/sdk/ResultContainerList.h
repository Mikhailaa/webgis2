#pragma once
#include "../commonStruct.h"

class CResultContainer : public TResultContainer
{
public:
	CResultContainer();
	~CResultContainer();

	void * internalPointer();
	void dublicateByRefFrom(CResultContainer & a1);
	void moveFrom(CResultContainer & a1);
	int light();
	int page();
	int type();
};

class CResultContainerListR : public TResultContainerList
{
public:
	CResultContainerListR();
	~CResultContainerListR();
	uint count();
	CResultContainer * container(int a1);
	CResultContainer * find(eRPRM_ResultType a1, eRPRM_Lights a2, int a3, int * a4, int a5);
	CResultContainer * find(eRPRM_ResultType a1, eRPRM_Lights a2, int a3, int * a4);
	CResultContainer * operator[](int a1);
};

class CResultContainerList : public CResultContainerListR
{
public:
	CResultContainerList();
	~CResultContainerList();
	TResultContainer *addContainer(void);
	void reserve(int);
public:
	uint m_nCRCL_8;
};

namespace ResultContainerListNS {
	tagSIZE imageSize(CResultContainerListR & a1);
	int imageResolution(CResultContainerListR &);
}

