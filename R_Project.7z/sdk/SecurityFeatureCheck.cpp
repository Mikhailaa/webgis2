#include "SecurityFeatureCheck.h"

SecurityFeatureCheck::SecurityFeatureCheck()
{
	this->u.nSFC_Result = 0;
	this->nSFC_ElementType = 0;
	this->nSFC_Visibility = 0;
	this->nSFC_CriticalFlag = 0;
	this->pxSFC_AreaList = 0;
	this->xSFC_ElementRect = { 0 };
	this->nSFC_Reserved2 = 0;
}

SecurityFeatureCheck::~SecurityFeatureCheck()
{
	removeAllAreas();
}

void SecurityFeatureCheck::setElementDiagnose(eCheckDiagnose eParam)
{
	this->u.s.sSFC_ElementDiagnose = eParam;
}

void SecurityFeatureCheck::setElementResult(eCheckResult eParam)
{
	this->u.s.sSFC_ElementResult = eParam;
}

void SecurityFeatureCheck::setFeatureType(int nParam)
{
	this->nSFC_ElementType = nParam;
}

void SecurityFeatureCheck::setRect(tagRECT xParam)
{
	this->xSFC_ElementRect = xParam;
}

void SecurityFeatureCheck::removeAllAreas()
{
	if (this->pxSFC_AreaList)
	{
		if (this->pxSFC_AreaList->pxTAA_List)
			delete[] this->pxSFC_AreaList->pxTAA_List;
		delete this->pxSFC_AreaList;
		this->pxSFC_AreaList = 0;
	}
}

void SecurityFeatureCheck::reset()
{
	removeAllAreas();
	this->nSFC_Reserved2 = 0;
	this->u.nSFC_Result = 2;
	this->nSFC_ElementType = 0;
	this->xSFC_ElementRect = { 0 };
	this->nSFC_Visibility = 0;
	this->nSFC_CriticalFlag = 0;
}

int SecurityFeatureCheck::setResult(eCheckResult a2)
{
	if (a2 > CheckResult_2)
		return -1;
	this->u.nSFC_Result = a2;
	return 0;
}