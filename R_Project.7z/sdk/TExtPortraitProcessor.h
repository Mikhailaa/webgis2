#pragma once

#include "../moduleprocessgl.h"
#include "TSDKProcessingClass.h"
#include "../ProcessParamsHolder.h"
#include "../rclhelp.h"
#include "../ImageHelperLib.h"
#include "../common/container/json.h"
#include "../common/StringUtils.h"

class TExtPortraitProcessor : public TSDKProcessingClass
{
public:
	TExtPortraitProcessor();
	~TExtPortraitProcessor();
	processmanagerdefault::eModuleType type() { return processmanagerdefault::ModuleType_ExtPortraitProcessor; };
	virtual void Init(void * pParam1, char * pParam2);
	virtual bool IsProcessingFinished(ProcessParamsHolder &);
	virtual bool NeedProcess(ProcessParamsHolder &, TResultContainerList &);
	string GeneratePortraitComparisonRequest(TResultContainerList const &, vector<pair<eInputFaceType, TRawImageContainer *> > &);
	int ParsePortraitComparisonResponse(string &, vector<pair<eInputFaceType, TRawImageContainer *> > &, common::container::RclHolder &);
	int Process(TResultContainerList *, Json::Value &, common::container::RclHolder &, string &);

public:
	string m_strTEPP_field_20;
	string m_strTEPP_field_2C;
};