#include "SymbolCandidate.h"

CSymbolCandidate::CSymbolCandidate()
{
}

CSymbolCandidate::~CSymbolCandidate()
{
}

void CSymbolCandidate::set(int a1, int a2, int a3, int a4)
{
	nTSC_SymbolCode = a1;
	nTSC_SymbolProbability = a2;
	sTSC_SubClass = a3;
	sTSC_Class = a4;
}

void CSymbolCandidate::operator=(CSymbolCandidate a1)
{
	nTSC_SymbolCode = a1.nTSC_SymbolCode;
	nTSC_SymbolProbability = a1.nTSC_SymbolProbability;
	sTSC_Class = a1.sTSC_Class;
	sTSC_SubClass = a1.sTSC_SubClass;
}
