#include "TFaceDetector.h"
#include "../moduleprocessgl.h"

TFaceDetector::TFaceDetector()
{

}

TFaceDetector::~TFaceDetector()
{

}

void TFaceDetector::Init(void * pParam1, char * pParam2)
{
	m_bTSDKPC_IsInitial = moduleprocessgl::isCommandSupported(PGC_TFaceDetector);	// 400
}

bool TFaceDetector::IsProcessingFinished(ProcessParamsHolder &)
{
	return m_bTSDKPC_IsFinished;
}

bool TFaceDetector::NeedProcess(ProcessParamsHolder & xPPH_Param1, TResultContainerList & xTRCL_Param2)
{
	if (!m_bTSDKPC_IsInitial)
		return 0;
	vector<TResultContainer *> v = rclhelp::findContainer(xTRCL_Param2, 97);
	return (v.size() == 0);
}

void TFaceDetector::Cleanup(common::container::RclHolder & xRH_Param)
{
	if (m_bTSDKPC_IsInitial)
		xRH_Param.remove(97);
}

int TFaceDetector::DetectFaces(common::container::RclHolder & xRH_Param1, common::container::RclHolder & xRH_Param2)
{
	string str;
	int res = ProcessGeneric(PGC_TFaceDetector, &xRH_Param1.m_xTRCL, xRH_Param2, str);
	CheckIfProcessingFinished(xRH_Param2);
	return res;
}

void TFaceDetector::CheckIfProcessingFinished(common::container::RclHolder & xRH_Param)
{
	vector<TResultContainer *> v = rclhelp::findContainer(xRH_Param.m_xTRCL, 97);
	m_bTSDKPC_IsFinished = (v.size() == 0);
}

int TFaceDetector::DetectFacesAndReplace(common::container::RclHolder & xRH_Param1, 
	common::container::RclHolder & xRH_Param2, vector<common::container::RclHolder *> & vParam3)
{
	common::container::RclHolder rh;
	int res = DetectFaces(xRH_Param1, rh);
	if (res)
	{
		CheckIfProcessingFinished(xRH_Param2);
	}
	if (rclhelp::getContainerContent(&rh.m_xTRCL, 97))
	{
		for (uint i = 0; i < vParam3.size(); i++)
		{
			Cleanup(*vParam3[i]);
		}
		xRH_Param2.addCopy(rh.m_xTRCL);
	}
	return res;
}

void TFaceDetector::RemoveUnsafeContainer(common::container::RclHolder & xRH_Param)
{
	vector<int> v = rclhelp::getPages(xRH_Param.m_xTRCL);
	if (v.size() >= 2)
	{
		xRH_Param.remove(97);
	}
}

int TFaceDetector::AddFaceDetection(tagSIZE xParam1, Json::Value & xJV_Param2, common::container::RclHolder & xRH_Param3,
	common::container::RclHolder & xRH_Param4, int nParam5)
{
	if (!xJV_Param2.isNull())
	{
		vector<ResultList> vv;
		Json::Value jv1 = xJV_Param2["faceMetadata"];
		if (!jv1.isNull() && jv1.isArray())
		{
			for (Json::ValueIteratorBase iter = jv1.begin(); iter != jv1.end(); iter.increment())
			{
				Json::Value jv2 = iter.deref();
				if (!jv2.isNull() && jv2.isObject())
				{
					Json::Value jv3 = jv2["bounds"];
					if (!jv3.isNull() && jv3.isObject())
					{
						int x = jv3["x"].asInt();
						int y = jv3["y"].asInt();
						int width = jv3["width"].asInt();
						int height = jv3["height"].asInt();
						int rollAngle = jv3["rollAngle"].asInt();
						ResultList rl = { 0 };
						rl.nRL_LightType = 6;
						eRPRM_Orientation n25;
						if (rollAngle == 90)
						{
							n25 = RPRM_Orientation_8;
						}
						else if(rollAngle == 180)
						{
							n25 = RPRM_Orientation_2;
						}
						else if (rollAngle == 270)
						{
							n25 = RPRM_Orientation_4;
						}
						else
						{
							n25 = RPRM_Orientation_1;
						}
						rl.xRL_pRects.left = x;
						rl.xRL_pRects.top = xParam1.cy - (height + y);
						rl.xRL_pRects.right = width + x;
						rl.xRL_pRects.bottom = xParam1.cy - y;
						rl.nRL_Probability = 90;
						rl.nRL_Orientation = n25;
						if (((xParam1.cy - y) | y | x | (height + y) | rl.xRL_pRects.top) >= 0 && (width + x) <= xParam1.cx)
						{
							vv.push_back(rl);
						}
					}
				}
			}
		}
		if (vv.size())
		{
			CRectCandidats crc;
			crc.m_nRC_Reserved1 = 0;
			crc.m_nRC_Reserved2 = 0;
			crc.m_pRC_List = vv.data();
			crc.m_nRC_CountFalseDetection = 0;
			crc.m_nRC_Count = vv.size();
			xRH_Param4.addNewCopy(97, &crc, 0)->nTRC_page_idx = nParam5;
			crc.m_pRC_List = 0;
		}
	}
	int res = 0;
	vector<TResultContainer *> v = rclhelp::findContainer(xRH_Param4.m_xTRCL, 97);
	if (m_bTSDKPC_IsInitial && v.empty())
	{
		if (DetectFaces(xRH_Param3, xRH_Param4)) res = 1;
	}
	CheckIfProcessingFinished(xRH_Param4);
	return res;
}