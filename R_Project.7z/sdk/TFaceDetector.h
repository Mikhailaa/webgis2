#pragma once

#include "TSDKProcessingClass.h"
#include "../ProcessParamsHolder.h"
#include "../rclhelp.h"
#include "../common/container/RclHolder.h"

class TFaceDetector : public TSDKProcessingClass
{
public:
	TFaceDetector();
	~TFaceDetector();
	virtual void Init(void * pParam1, char * pParam2);
	virtual bool IsProcessingFinished(ProcessParamsHolder &);
	virtual bool NeedProcess(ProcessParamsHolder &, TResultContainerList &);
	void Cleanup(common::container::RclHolder &);
	int DetectFaces(common::container::RclHolder &, common::container::RclHolder &);
	void CheckIfProcessingFinished(common::container::RclHolder &);
	int DetectFacesAndReplace(common::container::RclHolder &, common::container::RclHolder &, vector<common::container::RclHolder *> &);
	void RemoveUnsafeContainer(common::container::RclHolder &);
	int AddFaceDetection(tagSIZE, Json::Value &, common::container::RclHolder &, common::container::RclHolder &, int);
};