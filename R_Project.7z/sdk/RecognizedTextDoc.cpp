#include "RecognizedTextDoc.h"
#include "../common/common.h"
#include "SymbolCandidate.h"
#include "SymbolResult.h"
#include "StringResultSDK.h"

//--------------------------------------------------
//CRecognizedTextFieldSDK
//--------------------------------------------------

CRecognizedTextFieldSDK::CRecognizedTextFieldSDK()
{
	memset(this, 0, sizeof(CRecognizedTextFieldSDK));
}

CRecognizedTextFieldSDK::~CRecognizedTextFieldSDK()
{
	free();
}

void CRecognizedTextFieldSDK::addString(int n_a1)
{
	resize(nDVEF_StringsCount + 1);
	((CStringResultSDK *)pDVEF_StringsResult)[nDVEF_StringsCount - 1].resize(n_a1);
}

void CRecognizedTextFieldSDK::addString(char *pchar_a1, int n_a2, int *pn_a3)
{
	string _s_10(pszDVEF_Buf_Text);
	_s_10 += pchar_a1;
	updateString(_s_10.data(), _s_10.size());
	resize(nDVEF_StringsCount + 1);
	((CStringResultSDK *)pDVEF_StringsResult)[nDVEF_StringsCount - 1].set(pchar_a1, n_a2, pn_a3);
}

void CRecognizedTextFieldSDK::free()
{
	delete[] pszDVEF_Buf_Text;
	pszDVEF_Buf_Text = 0;
	setMask(0);
	resize(0);
}

int CRecognizedTextFieldSDK::generateLineRect(int n_a1, int n_a2)
{
	if (!nDVEF_StringsCount)
		return 1;
	if (!pDVEF_StringsResult->nTSRS_SymbolsCount)
		return 1;
	
	int _left1, _top1, _right1, _bottom1;
	_left1 = pDVEF_StringsResult->pTSRS_StringResult->xTSR_SymbolRect.left;
	_top1 = pDVEF_StringsResult->pTSRS_StringResult->xTSR_SymbolRect.top;
	_right1 = pDVEF_StringsResult->pTSRS_StringResult->xTSR_SymbolRect.right;
	_bottom1 = pDVEF_StringsResult->pTSRS_StringResult->xTSR_SymbolRect.bottom;
	CSymbolResult *_pTSymbolResult;
	for (int j = 0; j < nDVEF_StringsCount; j++)
	{
		for (uint i = 0; i < pDVEF_StringsResult[j].nTSRS_SymbolsCount; i++)
		{
			_pTSymbolResult = (CSymbolResult *)&pDVEF_StringsResult[j].pTSRS_StringResult[i];
			if (_pTSymbolResult->get(0) != ' ' && _pTSymbolResult->get(0) != '^')
			{
				_left1 = min(_left1, _pTSymbolResult->xTSR_SymbolRect.left);
				_top1 = min(_top1, _pTSymbolResult->xTSR_SymbolRect.top);
				_right1 = min(_right1, _pTSymbolResult->xTSR_SymbolRect.right);
				_bottom1 = min(_bottom1, _pTSymbolResult->xTSR_SymbolRect.bottom);
			}
		}
	}
	u.xDVEF_FieldRect.left = _left1 + n_a1;
	u.xDVEF_FieldRect.top = _top1 + n_a2;
	u.xDVEF_FieldRect.right = _right1 + n_a1;
	u.xDVEF_FieldRect.bottom = _bottom1 + n_a2;
	return 0;
}

int CRecognizedTextFieldSDK::getData_length()
{
	return nDVEF_Buf_Length;
}

char * CRecognizedTextFieldSDK::getData_pointer()
{
	return pszDVEF_Buf_Text;
}

int CRecognizedTextFieldSDK::getLCID()
{
	return u0.s0.wLCID;
}

int CRecognizedTextFieldSDK::getMask_length()
{
	if (pszDVEF_FieldMask)
		return strlen(pszDVEF_FieldMask);
	else
		return 0;
}

char *CRecognizedTextFieldSDK::getMask_pointer()
{
	return pszDVEF_FieldMask;
}

wstring CRecognizedTextFieldSDK::generateUnicodeTextFromSymbols()
{
	wstring res;
	if (nDVEF_StringsCount)
	{
		int nTmp;
		for (int i = 0; i < nDVEF_StringsCount; i++)
		{
			if (i)
				res.push_back('^');
			for (uint j = 0; j < pDVEF_StringsResult[i].nTSRS_SymbolsCount; j++)
			{
				nTmp = ((CSymbolResult*)pDVEF_StringsResult[i].pTSRS_StringResult)[j].get(0);
				res.push_back(nTmp);
			}
		}
	}

	return res;
}

int CRecognizedTextFieldSDK::getType()
{
	return u0.s0.wFieldType;
}

int CRecognizedTextFieldSDK::getTypeFull()
{
	return u0.nDVEF_FieldType;
}

float CRecognizedTextFieldSDK::middleProb()
{
	float res = 0.0f;
	uint nSum = 0;
	for (int i = 0; i<nDVEF_StringsCount; i++)
	{
		for (uint j = 0; j < pDVEF_StringsResult[i].nTSRS_SymbolsCount; j++)
		{
			res += (float)pDVEF_StringsResult[i].pTSRS_StringResult[j].xnTSR_Candidates[0].nTSC_SymbolProbability;
		}
		nSum += pDVEF_StringsResult[i].nTSRS_SymbolsCount;
	}
	if (nSum)
		res /= nSum;
	return res;
}

uint CRecognizedTextFieldSDK::minProb()
{
	uint res = 100;

	for (int i = 0; i < nDVEF_StringsCount; i++)
	{
		for (uint j = 0; j < pDVEF_StringsResult[i].nTSRS_SymbolsCount; j++)
		{
			uint nProb = pDVEF_StringsResult[i].pTSRS_StringResult[j].xnTSR_Candidates[0].nTSC_SymbolProbability;
			if (nProb < res)
				res = nProb;
		}
	}
	return res;
}

CRecognizedTextFieldSDK & CRecognizedTextFieldSDK::operator=(CRecognizedTextFieldSDK &xCRTFSDK)
{
	set(&xCRTFSDK);
	return (*this);
}

void CRecognizedTextFieldSDK::reset()
{
	free();
	memset(this, 0, sizeof(CRecognizedTextFieldSDK));
}

void CRecognizedTextFieldSDK::resize(int nCount)
{
	CStringResultSDK *pCSRSDK = NULL;

	if (nCount)
	{
		CStringResultSDK* v6 = new CStringResultSDK[nCount];
		pCSRSDK = new CStringResultSDK[nCount];
		for (int i = 0; i < MIN(nDVEF_StringsCount, nCount); i++)
			pCSRSDK[i] = ((CStringResultSDK *)pDVEF_StringsResult)[i];
	}

	delete[] pDVEF_StringsResult;

	nDVEF_StringsCount = nCount;
	pDVEF_StringsResult = pCSRSDK;
}

void CRecognizedTextFieldSDK::set(CRecognizedTextFieldSDK *pCRTFSDK)
{
	reset();
	if (pCRTFSDK)
	{
		memcpy(this, pCRTFSDK, 0x138);
		pszDVEF_Buf_Text = 0;
		pszDVEF_FieldMask = 0;
		pDVEF_StringsResult = 0;
		updateString(pszDVEF_Buf_Text, nDVEF_Buf_Length);
		setMask(pCRTFSDK->pszDVEF_FieldMask);
		if (pCRTFSDK->nDVEF_StringsCount && pCRTFSDK->pDVEF_StringsResult)
		{
			resize(0);
			resize(pCRTFSDK->nDVEF_StringsCount);
			for (int i = 0; i < pCRTFSDK->nDVEF_StringsCount; i++)
				pDVEF_StringsResult[i] = pCRTFSDK->pDVEF_StringsResult[i];
		}
	}
}

void CRecognizedTextFieldSDK::set(string const &s_a1, eVisualFieldType VFType)
{
	set((char *)s_a1.data(), s_a1.size(), VFType);
}

void CRecognizedTextFieldSDK::set(char *pchar, int wLCID, eVisualFieldType VFType)
{
	reset();
	common::field::setFieldType(*this, VFType);
	addString(pchar, wLCID, 0);
}

void CRecognizedTextFieldSDK::set(string const &s_a1, int wLCID, eVisualFieldType VFType)
{
	reset();
	addString((char *)s_a1.data(), s_a1.size(), 0);
	common::field::setFieldType(*this, VFType);
	u0.s0.wLCID = wLCID;
}

void CRecognizedTextFieldSDK::setComparison(int nComparison)
{
	nDVEF_InComparison = nComparison;
}

void CRecognizedTextFieldSDK::setFieldName(char *pch)
{
	strcpy(szDVEF_FieldName, pch);
}

void CRecognizedTextFieldSDK::setMask(char const *a2)
{
	signed int v4; // r6
	unsigned int v5; // r0

	if (pszDVEF_FieldMask) delete[] pszDVEF_FieldMask;
	pszDVEF_FieldMask = 0;
	if (a2)
	{
		v4 = strlen(a2);
		v5 = v4 + 1;
		if (v4 < -1)
			v5 = -1;
		pszDVEF_FieldMask = (char *)new char[v5];
		memcpy(pszDVEF_FieldMask, a2, v4);
		pszDVEF_FieldMask[v4] = 0;
	}
}

void CRecognizedTextFieldSDK::setType(eVisualFieldType VFType)
{
	common::field::setFieldType(*this, VFType);
}

void CRecognizedTextFieldSDK::setValidity(int nValidity)
{
	nDVEF_Validity = nValidity;
}

int CRecognizedTextFieldSDK::symbolCount()
{
	int res;
	if (!nDVEF_StringsCount)
		return -1;
	res = nDVEF_StringsCount - 1;
	for (int i = 0; i < nDVEF_StringsCount; i++)
		res += pDVEF_StringsResult[i].nTSRS_SymbolsCount;
	return res;
}

void CRecognizedTextFieldSDK::updateString(char const *pchar, int nlen)
{
	delete[] pszDVEF_Buf_Text;
	if (pchar && nlen)
	{
		int nlenTmp = nlen;
		if (pchar[nlen - 1])
			nlenTmp = nlen + 1;
		char *pcharTmp = new char[MAX(nlenTmp, 0)];
		memset(pcharTmp, 0, MAX(nlenTmp, 0));
		memcpy(pcharTmp, pchar, nlen);
		pszDVEF_Buf_Text = pcharTmp;
		nDVEF_Buf_Length = nlenTmp;
	}
}


//--------------------------------------------------
//CRecognizedTextDoc
//--------------------------------------------------

CRecognizedTextDoc::CRecognizedTextDoc()
{
	nDVEI_Fields = 0;
	pDVEI_ArrayFields = 0;
	nDVEI_Capacity = 0;
}

CRecognizedTextDoc::~CRecognizedTextDoc()
{
	resize(0);
}

CRecognizedTextDoc & CRecognizedTextDoc::operator=(CRecognizedTextDoc &xCRTD)
{
	set(&xCRTD);
	return *this;
}

CRecognizedTextFieldSDK * CRecognizedTextDoc::operator[](int nPos)
{
	return at(nPos);
}

CRecognizedTextFieldSDK * CRecognizedTextDoc::add()
{
	if (nDVEI_Fields >= nDVEI_Capacity)
	{
		if (nDVEI_Fields)
			reserve(2 * nDVEI_Capacity);
		else
			reserve(1);
	}
	nDVEI_Fields++;
	return (CRecognizedTextFieldSDK *)&pDVEI_ArrayFields[nDVEI_Fields];
}

CRecognizedTextFieldSDK * CRecognizedTextDoc::at(int nPos)
{
	if (nPos < 0 || nDVEI_Fields <= nPos)
		return (CRecognizedTextFieldSDK *)pDVEI_ArrayFields;
	else
		return &((CRecognizedTextFieldSDK *)pDVEI_ArrayFields)[nPos];
}

int CRecognizedTextDoc::count()
{
	return nDVEI_Fields;
}

CRecognizedTextFieldSDK * CRecognizedTextDoc::field(int nPos)
{
	if (nDVEI_Fields)
		return &((CRecognizedTextFieldSDK *)pDVEI_ArrayFields)[nPos];
	return 0;
}

CRecognizedTextFieldSDK * CRecognizedTextDoc::find(eVisualFieldType VFType)
{
	for (int i = 0; i < nDVEI_Fields; i++)
	{
		if (((CRecognizedTextFieldSDK *)pDVEI_ArrayFields)[i].getTypeFull() == VFType)
			return (CRecognizedTextFieldSDK *)&pDVEI_ArrayFields[i];
	}
	return 0;
}

CRecognizedTextFieldSDK * CRecognizedTextDoc::find(eVisualFieldType VFType, eRPRM_Lights RPRM_Lights)
{
	for (int i = 0; i < nDVEI_Fields; i++)
	{
		if (((CRecognizedTextFieldSDK *)pDVEI_ArrayFields)[i].getTypeFull() == VFType)
		{
			if (pDVEI_ArrayFields[i].nDVEF_Reserved3 == RPRM_Lights)
				return (CRecognizedTextFieldSDK*)&pDVEI_ArrayFields[i];
		}
	}
	return 0;
}

CRecognizedTextFieldSDK * CRecognizedTextDoc::getPList()
{
	return (CRecognizedTextFieldSDK *)pDVEI_ArrayFields;
}

int CRecognizedTextDoc::getPos(eVisualFieldType VFType)
{
	for (int i = 0; i < nDVEI_Fields; i++)
	{
		if (((CRecognizedTextFieldSDK *)pDVEI_ArrayFields)[i].getTypeFull() == VFType)
			return i;
	}
	return -1;
}

int CRecognizedTextDoc::remove(int nRemovepos)
{
	if (nDVEI_Fields <= nRemovepos)
		return 1;
	for (int i = nRemovepos; i < nDVEI_Fields - 1; i++)
		pDVEI_ArrayFields[i] = pDVEI_ArrayFields[i + 1];
	if (nDVEI_Fields > 0)
	{
		((CRecognizedTextFieldSDK *)pDVEI_ArrayFields)[nDVEI_Fields - 1].reset();
		nDVEI_Fields--;
	}
	return 0;
}

void CRecognizedTextDoc::reserve(int nReserve)
{
	CRecognizedTextFieldSDK *pCRTFSDK = new CRecognizedTextFieldSDK[nReserve];
	int nFields = MIN(nDVEI_Fields, nReserve);
	for (int i = 0; i < nFields; i++)
		pCRTFSDK[i] = ((CRecognizedTextFieldSDK*)pDVEI_ArrayFields)[i];
	resize(0);
	nDVEI_Fields = nFields;
	pDVEI_ArrayFields = pCRTFSDK;
	nDVEI_Capacity = nReserve;
}

void CRecognizedTextDoc::reset()
{
	for (int i = 0; i < nDVEI_Fields; ++i)
		((CRecognizedTextFieldSDK*)pDVEI_ArrayFields)[i].reset();
	nDVEI_Fields = 0;
}

void CRecognizedTextDoc::resize(int nCount)
{
	if (nDVEI_Fields)
	{
		CRecognizedTextFieldSDK* p = (CRecognizedTextFieldSDK*)pDVEI_ArrayFields;
		delete[] p;
	}
	if (pDVEI_ArrayFields) delete[] pDVEI_ArrayFields;
	nDVEI_Fields = 0;
	pDVEI_ArrayFields = 0;
	nDVEI_Capacity = 0;

	if (nCount > 0)
	{
		CRecognizedTextFieldSDK* p = new CRecognizedTextFieldSDK[nCount];
		pDVEI_ArrayFields = p;
	}
	
	if (nCount <= nDVEI_Fields)
		nDVEI_Fields = nCount;
	nDVEI_Capacity = nCount;
}

void CRecognizedTextDoc::set(CRecognizedTextDoc *pCRTD)
{
	resize(pCRTD->nDVEI_Fields);
	for (int i = 0; i < pCRTD->nDVEI_Fields; i++)
		pDVEI_ArrayFields[i] = pCRTD->pDVEI_ArrayFields[i];
}

void CRecognizedTextDoc::setPList(CRecognizedTextFieldSDK const *pCRTFSDK)
{
	pDVEI_ArrayFields = (TDocVisualExtendedField *)pCRTFSDK;
}
