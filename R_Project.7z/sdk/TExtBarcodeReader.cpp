#include "TExtBarcodeReader.h"
#include "../common/container/container.h"

TExtBarcodeReader::TExtBarcodeReader()
{

}

TExtBarcodeReader::~TExtBarcodeReader()
{

}

void TExtBarcodeReader::Init(void * pParam1, char * pParam2)
{
	m_bTSDKPC_IsInitial = true;
}

bool TExtBarcodeReader::IsProcessingFinished(ProcessParamsHolder & xPPH_Param1)
{
	bool bRes;
	if (m_bTSDKPC_IsInitial && (xPPH_Param1.m_nPPH_processParam & 0x100))
		bRes = (m_bTSDKPC_IsFinished != 0);
	else
		bRes = true;
	return bRes;
}

bool TExtBarcodeReader::NeedProcess(ProcessParamsHolder & xPPH_Param1, TResultContainerList & xTRCL_Param2)
{
	bool bRes;
	if (m_bTSDKPC_IsInitial)
		bRes = ((xPPH_Param1.m_nPPH_processParam & 0x100) != 0);
	else
		bRes = false;
	return bRes;
}

int TExtBarcodeReader::Process(TResultContainerList * pTRCL_Param1, common::container::RclHolder & xRH_Param2, string & strParam3)
{
	if (!pTRCL_Param1)
		return 0;
	vector<TResultContainer *> v = rclhelp::findContainer(*pTRCL_Param1, 5);
	if (v.size())
	{
		if (v.size() == 1)
		{
			int *p6 = (int *)v[0]->u.pTRC_DBCI;
			if (v[0]->u.pTRC_DBCI && (!v[0]->u.pTRC_DBCI->nDBCI_nFields || !v[0]->u.pTRC_DBCI->pDBCI_pArrayFields))
				return 2;
		}
		TResultContainer *pTRC = rclhelp::findFirstContainer(xRH_Param2.m_xTRCL, 5);
		if (pTRC)
		{
			if (pTRC->u.pTRC_DBCI && pTRC->nTRC_buf_length)
			{
				vector<TDocBarCodeField> vv;
				TDocBarCodeInfo *pTDBCI = common::container::Duplicate(pTRC->u.pTRC_DBCI, 0);
				for (uint i = 0; i < pTDBCI->nDBCI_nFields; i++)
				{
					vv.push_back(pTDBCI->pDBCI_pArrayFields[i]);
				}
				for (uint i = 0; i < v.size(); i++)
				{
					TDocBarCodeInfo *p18 = v[i]->u.pTRC_DBCI;
					for (uint j = 0; j < p18->nDBCI_nFields; j++)
					{
						vv.push_back(p18->pDBCI_pArrayFields[j]);
					}
				}
				TDocBarCodeInfo tdbci;
				tdbci.nDBCI_nFields = vv.size();
				tdbci.pDBCI_pArrayFields = new TDocBarCodeField[tdbci.nDBCI_nFields];
				memcpy(tdbci.pDBCI_pArrayFields, vv.data(), vv.size() * sizeof(TDocBarCodeField));
				xRH_Param2.remove(*pTRC);
				xRH_Param2.addCopy(rclhelp::container(5, (uchar *)&tdbci, sizeof(TDocBarCodeInfo)));
				delete tdbci.pDBCI_pArrayFields;
				common::container::Delete(pTDBCI);
			}
		}
		else
		{
			for (uint i = 0; i < v.size(); i++)
			{
				xRH_Param2.addCopy(*v[i]);
			}
		}
		m_bTSDKPC_IsFinished = 1;
	}
	
	return 0;
}