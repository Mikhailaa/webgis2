#include "AuthenticityCheckList.h"

AuthenticityCheckList::AuthenticityCheckList()
{
	this->nACL_Count = 0;
	this->ppACL_List = 0;
}

AuthenticityCheckList::~AuthenticityCheckList()
{
	free();
}

int AuthenticityCheckList::add(TAuthenticityCheckResult *a2)
{
	if (!a2)
		return -1;
	TAuthenticityCheckResult** old = this->ppACL_List;
	if (this->ppACL_List && this->nACL_Count != 0)
	{
		TAuthenticityCheckResult **v8 = new TAuthenticityCheckResult *[this->nACL_Count + 1];
		memset(v8, 0, sizeof(pvoid) * (this->nACL_Count + 1));
		this->ppACL_List = v8;
		for (int i = 0; i < this->nACL_Count; i ++)
		{
			this->ppACL_List[i] = old[i];
		}
		delete old;
	}
	else
	{
		this->ppACL_List = new TAuthenticityCheckResult*[1];
		memset(this->ppACL_List, 0, sizeof(pvoid));
	}
	this->ppACL_List[this->nACL_Count++] = a2;
	return 0;
}

void AuthenticityCheckList::free()
{
	this->nACL_Count = 0;
	if (this->ppACL_List)
		delete this->ppACL_List;
	this->ppACL_List = 0;
}