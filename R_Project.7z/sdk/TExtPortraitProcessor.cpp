﻿#include "TExtPortraitProcessor.h"
#include <regex>
#include "../common/container/jsoncpp.h"
#include "../imaging.h"
#include "../common/common.h"

GenericValue<UTF8<char> > sub_4107F4(TDocGraphicsInfo * pTDGI_Param1, eInputFaceType nParam2, vector<pair<eInputFaceType, TRawImageContainer *> > & vParam3, MemoryPoolAllocator<CrtAllocator> & xMPA_Param4)
{
	string strTemp;
	if (pTDGI_Param1 && pTDGI_Param1->nDGI_nFields && pTDGI_Param1->pDGI_pArrayFields)
	{
		for (uint i = 0; i < pTDGI_Param1->nDGI_nFields; i++)
		{
			if (pTDGI_Param1->pDGI_pArrayFields[i].nDGF_FieldType == GFT_Portrait)
			{
				vParam3.push_back(pair<eInputFaceType, TRawImageContainer *>(nParam2, &pTDGI_Param1->pDGI_pArrayFields[i].xDGF_image));
				uchar *pC = 0;
				uint nLen = 0;
				CImageHelperLib iih;
				imaging::RI_SaveFileParameters risfp;
				TResultContainer v26;
				v26.nTRC_light = RPRM_Lights_0;
				v26.u1.nTRC_XML_length = 0;
				v26.pTRC_XML_buffer = 0;
				v26.nTRC_list_idx = 0;
				v26.nTRC_page_idx = 0;
				v26.nTRC_buf_length = sizeof(TRawImageContainer);
				v26.u.pTRC_RIC = &pTDGI_Param1->pDGI_pArrayFields[i].xDGF_image;
				v26.nTRC_result_type = 1;
				risfp.nSFP_0 = 1;
				risfp.nSFP_4 = 85;
				risfp.pxSFP_8 = &v26;
				risfp.ppSFP_10 = &pC;
				risfp.pnSFP_14 = &nLen;
				if (!iih.WriteToBuffer(&risfp))
				{
					strTemp = common::Base64::base64_encode(pC, nLen);
				}
				delete[] pC;
			}
		}
	}
	if (strTemp.length())
	{
		GenericValue<UTF8<char> > gv(kObjectType);
		common::container::json::AddStringMember(gv, ".JPG", GenericStringRef<char>("format"), false, xMPA_Param4);
		gv.AddMember(GenericStringRef<char>("type"), nParam2, xMPA_Param4);
		common::container::json::AddStringMember(gv, strTemp, GenericStringRef<char>("data"), false, xMPA_Param4);
		return gv;
	}
	return GenericValue<UTF8<char>>();
}

TRawImageContainer* sub_410C8A(TRawImageContainer* ret, eInputFaceType nParam1, vector<pair<eInputFaceType, TRawImageContainer *> > & vParam2)
{
	if (ret)
	{
		for (uint i = 0; i < vParam2.size(); i++)
		{
			if (vParam2[i].first == nParam1)
			{
				ret = vParam2[i].second;
				return ret;
			}
		}
	}
	return ret;
}

TExtPortraitProcessor::TExtPortraitProcessor()
{
	m_strTEPP_field_20 = "https://faceapi.regulaforensics.com";
	m_strTEPP_field_2C = "/api/faces";
}

TExtPortraitProcessor::~TExtPortraitProcessor()
{

}

void TExtPortraitProcessor::Init(void * pParam1, char * pParam2)
{
	m_bTSDKPC_IsInitial = moduleprocessgl::isCommandSupported(PGC_TExtPortraitProcessor);	// 650
}

bool TExtPortraitProcessor::IsProcessingFinished(ProcessParamsHolder & xPPH_Param1)
{
	bool bRes;
	if (m_bTSDKPC_IsInitial)
		bRes = (m_bTSDKPC_IsFinished != 0);
	else
		bRes = true;
	return bRes;
}

bool TExtPortraitProcessor::NeedProcess(ProcessParamsHolder & xPPH_Param1, TResultContainerList & xTRCL_Param2)
{
	return m_bTSDKPC_IsInitial;
}

string TExtPortraitProcessor::GeneratePortraitComparisonRequest(TResultContainerList const & xTRCL_Param1, vector<pair<eInputFaceType, TRawImageContainer *> > & vParam2)
{
	string strRes;
	GenericDocument<UTF8<char>> gd(kObjectType);
	GenericValue<UTF8<char>> gv(kArrayType);
	GenericValue<UTF8<char>> gvTemp;
	if (xTRCL_Param1.pTRCL_TRC)
	{
		for (uint i = 0; i < xTRCL_Param1.nTRCL_Count; i++)
		{
			TDocGraphicsInfo *pTDGI = xTRCL_Param1.pTRCL_TRC[i].u.pTRC_DGI;
			switch (xTRCL_Param1.pTRCL_TRC[i].nTRC_result_type)
			{
			case 6:
				gvTemp = sub_4107F4(pTDGI, InputFaceType_1, vParam2, gd.GetAllocator());
				if (gvTemp.IsObject())
					gv.PushBack(gvTemp, gd.GetAllocator());
				break;
			case 103:
				gvTemp = sub_4107F4(pTDGI, InputFaceType_2, vParam2, gd.GetAllocator());
				if (gvTemp.IsObject())
					gv.PushBack(gvTemp, gd.GetAllocator());
				break;
			case 32:
				gvTemp = sub_4107F4(pTDGI, InputFaceType_3, vParam2, gd.GetAllocator());
				if (gvTemp.IsObject())
					gv.PushBack(gvTemp, gd.GetAllocator());
				break;
			}
		}
	}
	gd.AddMember(GenericStringRef<char>("images"), gv, gd.GetAllocator());
	if (gd.MemberCount())
	{
		GenericStringBuffer<UTF8<char> > sbuff;
		Writer<GenericStringBuffer<UTF8<char> > > wr(sbuff);
		gd.Accept(wr);
		strRes = sbuff.GetString();
	}
	return strRes;
}

int TExtPortraitProcessor::ParsePortraitComparisonResponse(string & strParam1, vector<pair<eInputFaceType, TRawImageContainer *> > & vParam2, common::container::RclHolder & xRH_Param3)
{
	string strTemp("ParsePortraitComparisonResponse");
	// common::ScopeLogHelper::ScopeLogHelper
	if (strParam1.empty())
		return 0;
	GenericDocument<UTF8<char>> gd = common::container::json::ReadString(strParam1);
	if (!gd.IsObject())
		return 0;
	GenericValue<UTF8<char> > *gv = common::container::json::GetMember(gd, string("results"));
	vector<FaceComparisonResult> vv;
	vector<TIdentResult> vvv;
	if (gv->IsArray())
	{
		for (uint i = 0; i < gv->Size(); i++)
		{
			FaceComparisonResult fcr = { 0 };
			if (common::container::json::FromJson((*gv)[i], fcr))
			{
				vv.push_back(fcr);
			}
		}
	}
	int n13 = 2;
	for (uint i = 0; i < vv.size(); i++)
	{
		int n42 = 0;
		TIdentResult fcr = { 0 };
		switch (vv[i].nFCR_first)
		{
		case 1:
			if (vv[i].nFCR_second == InputFaceType_2)
			{
				fcr.nTIR_ElementType = 15;
				sub_410C8A(&fcr.xTIR_Image, InputFaceType_1, vParam2);
				sub_410C8A(&fcr.xTIR_EtalonImage, InputFaceType_2, vParam2);
			}
			if (vv[i].nFCR_second == InputFaceType_1)
			{
				fcr.nTIR_ElementType = 16;
				sub_410C8A(&fcr.xTIR_Image, InputFaceType_1, vParam2);
			}
			if (vv[i].nFCR_second == InputFaceType_3)
			{
				fcr.nTIR_ElementType = 19;
				sub_410C8A(&fcr.xTIR_Image, InputFaceType_3, vParam2);
				sub_410C8A(&fcr.xTIR_EtalonImage, InputFaceType_1, vParam2);
			}
			break;
		case 2:
			if (vv[i].nFCR_second == InputFaceType_3)
			{
				fcr.nTIR_ElementType = 20;
				sub_410C8A(&fcr.xTIR_Image, InputFaceType_3, vParam2);
				sub_410C8A(&fcr.xTIR_EtalonImage, InputFaceType_2, vParam2);
			}
			if (vv[i].nFCR_second == InputFaceType_2)
			{
				fcr.nTIR_ElementType = 15;
				sub_410C8A(&fcr.xTIR_Image, InputFaceType_1, vParam2);
				sub_410C8A(&fcr.xTIR_EtalonImage, InputFaceType_2, vParam2);
			}
			break;
		case 3:
			if (vv[i].nFCR_second == InputFaceType_2)
			{
				fcr.nTIR_ElementType = 20;
				sub_410C8A(&fcr.xTIR_Image, InputFaceType_3, vParam2);
				sub_410C8A(&fcr.xTIR_EtalonImage, InputFaceType_2, vParam2);
			}
			if (vv[i].nFCR_second == InputFaceType_1)
			{
				fcr.nTIR_ElementType = 19;
				sub_410C8A(&fcr.xTIR_Image, InputFaceType_3, vParam2);
				sub_410C8A(&fcr.xTIR_EtalonImage, InputFaceType_1, vParam2);
			}
			break;
		default:
			break;
		}
		if (vv[i].rFCR_similarity < 0.0)
			vv[i].rFCR_similarity = 0;
		int n22 = 0;
		if (vv[i].rFCR_similarity * 100.0 > 75)
			n22 = 1;
		fcr.u.nTIR_Result = n22;
		if (n13 > n22)
			n13 = n22;
		if (vv[i].nFCR_errorCode || vv[i].xFCR_errorMsg.length())
		{
			strTemp = "error %d: %s";
			// common::ScopeLogHelper::AppendToLog<int,char const*>
		}
		else
		{
			vvv.push_back(fcr);
		}
	}
	if (vvv.size())
	{
		TAuthenticityCheckResult tacr;
		tacr.nACR_Type = 0x8000;
		tacr.nACR_Result = 0;
		tacr.nACR_Count = vvv.size();
		tacr.ppACR_List = 0;
		vector<TIdentResult *> vP;
		for (uint i = 0; i < vvv.size(); i++)
		{
			vP.push_back(&vvv[i]);
		}
		tacr.nACR_Result = n13;
		tacr.ppACR_List = (void **)vP.data();
		TAuthenticityCheckResult *pTACR = &tacr;
		TAuthenticityCheckList tacl;
		tacl.nACL_Count = 1;
		tacl.ppACL_List = &pTACR;
		common::container::RclHolder rh;
		rh.addNewCopy(20, &tacl, 0);
		rclhelp::mergeResults(xRH_Param3, &rh.m_xTRCL);
	}
	return 0;
}

int TExtPortraitProcessor::Process(TResultContainerList *pTRCL_Param1, Json::Value & xJV_Param2, common::container::RclHolder & xRH_Param3, string & strParam4)
{
	string strTemp("TExtPortraitProcessor::Process()");
	// common::ScopeLogHelper::ScopeLogHelper
	if (!m_bTSDKPC_IsInitial)
		return 1;
	int res = 2;
	if (!pTRCL_Param1)
		return 2;
	vector<pair<eInputFaceType, TRawImageContainer *>> vv;
	string strR = GeneratePortraitComparisonRequest(*pTRCL_Param1, vv);
	if (vv.size() >= 2)
	{
		regex br("/+$");
		strTemp = xJV_Param2["processParam"]["serviceUrl"].asString();
		if (strTemp.length())
		{
			string str = strTemp;
			strTemp = regex_replace(str, br, "");
		}
		else
		{
			strTemp = m_strTEPP_field_20;
		}
		if (!common::StringUtils::contains(strTemp, m_strTEPP_field_2C))
		{
			strTemp.append(m_strTEPP_field_2C);
		}
		Json::Value jv(Json::json_type_null);
		jv["url"] = Json::Value(strTemp);
		jv["method"] = Json::Value("POST");
		jv["ssl_verifypeer"] = Json::Value(0);
		jv["http_headers"][0] = Json::Value("Content-Type: application/json");
		jv["http_headers"][1] = Json::Value("User-Agent: Regula DocReader");
		strTemp.clear();
		common::container::jsoncpp::convert(jv, strTemp);
		common::container::RclHolder rh;
		TResultContainer trc = { 0 };
		trc.nTRC_result_type = 64;
		trc.nTRC_buf_length = strR.length();
		trc.u.pTRC_CHAR = (char *)strR.data();
		rh.addCopy(trc);
		TResultContainerList *pTRCL = 0;
		char *pC = 0;
		res = moduleprocessgl::process(12900, &rh, strTemp.data(), (void **)&pTRCL, &pC);
		if (pTRCL && pTRCL->nTRCL_Count)
		{
			strTemp = string(pTRCL->pTRCL_TRC->u.pTRC_CHAR, pTRCL->pTRCL_TRC->nTRC_buf_length);
		}
		else
		{
			if (pC)
			{
				strTemp = pC;
			}
			else
			{
				string strLog("no string result");
				// common::ScopeLogHelper::AppendToLog<>
			}
		}
		if (!strTemp.length() || strTemp == "null" || strTemp == "null\n")
		{
			Log("Portrait = %s", strTemp.data());
		}
		else
		{
			ParsePortraitComparisonResponse(strTemp, vv, xRH_Param3);
		}
	}
	return res;
}