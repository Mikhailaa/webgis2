#include "MainDocument.h"

MainDocumentStorage::~MainDocumentStorage()
{
}

bool MainDocumentStorage::contains(int a2)
{
	for (size_t i = 0; i < m_vMDS_4.size(); i++)
	{
		if (m_vMDS_4[i] == a2)
		{
			return true;
		}
	}

	for (size_t i = 0; i < m_vMDS_10.size(); i++)
	{
		if (m_vMDS_10[i] == a2)
		{
			return true;
		}
	}

	return false;
}

void MainDocumentStorage::free()
{
	m_vMDS_4.clear();
	m_vMDS_10.clear();
}

void MainDocumentStorage::setValue(int a2, int a3)
{
	if (a3)
	{
		m_vMDS_10.push_back(a2);
		vector<int>::iterator iter = remove(m_vMDS_4.begin(), m_vMDS_4.end(), a2);
		m_vMDS_4.erase(iter, m_vMDS_4.end());
	}
	else
	{
		m_vMDS_4.push_back(a2);
		vector<int>::iterator iter = remove(m_vMDS_10.begin(), m_vMDS_10.end(), a2);
		m_vMDS_10.erase(iter, m_vMDS_10.end());
	}
}

MainDocumentFilter::~MainDocumentFilter()
{
}

int MainDocumentFilter::type()
{
	return 0;
}

void MainDocumentFilter::save(int, vector<uchar>&)
{
}

void MainDocumentFilter::load(int a2, vector<uchar>& a3)
{
	storage()->setValue(a2, *(int*)a3.data());
}

void MainDocumentFilter::clear(int a2)
{
	storage()->setValue(a2, 1);
}

MainDocumentStorage * MainDocumentFilter::storage()
{
	return &m_xMDF_4;
}
