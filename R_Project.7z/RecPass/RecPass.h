﻿#pragma once

#include "../pch.h"
#include "../common/container/RclHolder.h"
#include "interface.h"
#include "IdentifyRect.h"
#include "../rclhelp.h"
#include "../imaging.h"
#include "../common/StringUtils.h"
#include "../moduleprocessgl.h"
#include "MainDocument.h"
#include "TextClass.h"
#include "TextOneClass.h"
#include "Int2Class.h"
#include "IdentifyRect.h"
#include "DocTypeRecognizer.h"
#include "../common/common.h"
#include "../common/resources.h"
#include "../rcvmat.h"

struct CMC_DATA
{
	int nfield_0;
	int nfield_4;
	double dbfield_8;
	short wfield_10;
	short wfield_12;
	int nfield_14;
};

struct LoadInfoStat
{
	unordered_map<int, int> umLIS_field_0;
};

class TRecognParamsStd
{
public:

	TRecognParamsStd();
	~TRecognParamsStd();

public:

	vector<int> m_vTRPS_field_0;
	string m_strTRPS_field_C;
	string m_strTRPS_field_18;
	string m_strTRPS_field_24;
	string m_strTRPS_field_30;
	int m_nTRPS_field_3C;
	int m_nTRPS_field_40;
	bool m_bTRPS_field_44;
	bool m_bTRPS_field_45;
	bool m_bTRPS_field_46;
	bool m_bTRPS_field_47;
	string m_strTRPS_field_48;
	vector<int> m_vTRPS_field_54;
	bool m_bTRPS_field_60;
	bool m_bTRPS_field_61;
	char m_cTRPS_field_62;
	char m_cTRPS_field_63;
	vector<int> m_vTRPS_field_64;
	bool m_bTRPS_field_70;
	bool m_bTRPS_field_71;
	bool m_bTRPS_field_72;
	bool m_bTRPS_field_73;

};

class CMasCandidats
{
public:

	CMasCandidats(int);
	~CMasCandidats();

public:

	int		m_nCMC_field_0;
	int		m_nCMC_field_4;
	CMC_DATA *m_pCMC_field_8;		// 크기가 0x18인 구조체지시자이다.
	int		m_nCMC_field_C;

};

namespace recpass
{
	class GlobalParams
	{
	public:
		static int * obj();
	};

	namespace imageholder
	{
		class IImageHolder
		{
		public:
			virtual int getImage(eRPRM_Lights, cv::Rect &, cv::Size_<int> &, cv::Mat &) = 0;
			virtual bool isDpiTrue() = 0;
			virtual bool isLockProportion() = 0;
			virtual void imageInfo(int &, tagSIZE &) = 0;
		};

		class ImageHolder : public IImageHolder
		{
		public:
			ImageHolder();
			~ImageHolder();
			void init(common::container::RclHolder &, bool);
			int getImage(eRPRM_Lights, cv::Rect &, cv::Size_<int> &, cv::Mat &);
			bool isDpiTrue();
			bool isLockProportion();
			void imageInfo(int &, tagSIZE &);

		public:
			common::container::RclHolder m_xIH_RH_field_4;
			common::container::RclHolder m_xIH_RH_field_18;
			bool m_bIH_field_2C;
			bool m_bIH_field_2D;
			bool m_bIH_field_2E;
			bool m_bIH_field_2F;
		};
	}

	int getRecognParam(TResultContainerList *, Json::Value &, TRecognParamsStd &);
	int getROIByElementsAnalyze(IdentifyRectDocument &, DpiInfo &, tagRECT &);

	namespace IdentifyRectSearchM
	{
		int checkFilteredRects(IdentifyRectDocument *, CDocFormat, vector<int> &, imageholder::IImageHolder &, DpiInfo &, vector<IdentifyRectResult> &);
		int getSearchArrayForRect(IdentifyRectDocument &, CDocFormat, imageholder::IImageHolder &, int, DpiInfo &, cv::Mat &);
		int recognizeByRects(int, IdentifyRectDocument *, CDocFormat, imageholder::IImageHolder &, DpiInfo &, int, float, float &, set<int> &);
	}

	namespace rect
	{
		tagRECT convert(Rect const &, bool);
		Rect getRectInPixel(Rect2f const &, Size2f const &, tagSIZE const &);
		Rect getRectInPixel(Rect2f const &, int, tagSIZE const &);
		Size getSizeInPixel(Size const &, int, int);
		Size getSizeInPixel(Size const &, int, int, int);
	}

	namespace filters
	{
		void setFiltersDocumentsFast(vector<int> &);
	}
}

string filterName(eDocumentFilterClass);

class RecPass
{
public:
	RecPass();
	virtual ~RecPass();
	int loadDocument(int, vector<uchar> &, LoadInfoStat *);
	int saveDocument(int, vector<uchar> &);
	int init(void *);
	int recognizeOnePage(common::container::RclHolder &, Json::Value &, bool, common::container::RclHolder &);
	int recognize(int, common::container::RclHolder &, TRecognParamsStd &, CMasCandidats *);

public:
	vector<IDocumentFilter *>	m_vRP_field_0;
	MainDocumentFilter	m_xRP_MDF;
	TextClassFilter		m_xRP_TCF;
	TextStateCodeFilter m_xRP_TSCF;
	IdentifyRectFilter	m_xRP_IRF;
	DateOfExpFilter		m_xRP_DOEF;
	DocTypeRecognizer	m_xRP_DTR;
	TextCountryIDFilter	m_xRP_TCIDF;
	TextFilterMaskFilter m_xRP_TFMF;
	vector<int>			m_vRP_field_1EC;
	bool				m_bRP_field_1F8;
	bool				m_bRP_field_1F9;
	char				m_cRP_field_1FA;
	char				m_cRP_field_1FB;
	vector<int>			m_vRP_field_1FC;
	recpass::imageholder::ImageHolder m_xRP_IH;
	int					m_nRP_field_234;
	int					m_nRP_field_238;
	int					m_nRP_field_23C;
	int					m_nRP_field_240;
	int					m_nRP_field_244;
	int					m_nRP_field_248;
	bool				m_bRP_field_24C;
	bool				m_bRP_field_24D;
	bool				m_bRP_field_24E;
	bool				m_bRP_field_24F;
	Json::Value			m_xRP_JV;
	common::container::RclHolder m_xRP_RH;
	TOneCandidate       m_xRP_field_27C;
	TRecognParamsStd	m_xRP_TRPS;
	vector<string>		m_vRP_field_320;
};


/////////////////////////////////////////////////////
/////////////////////////////////////////////////////

class RecPassExternal : public moduleprocessgl::IProcessFunction, public RecPass
{
public:
	RecPassExternal();
	~RecPassExternal();
	vector<int> getCommands();
	int process(int, void *, const char *, void **, char **);
	int process_RecDoc(void *, char *, void **, bool);
	int exchange_SetData(int, CMemBufer *, LoadInfoStat *);
	int exchange_SetDataAllDocuments(CMemBufer *);
	int exchange_SetDataDNN(CMemBufer *);
};