#include "DocTypeRecognizer.h"
#include "opencv2/dnn/dnn_serialization.h"

void perImageStandardization(Mat const & xParam1, Size const & xParam2, Mat & xParam3)
{
	double v5, v7;
	Mat m;
	Scalar sclMean;
	Scalar sclStdDev;
	resize(xParam1, xParam3, xParam2, 0.0, 0.0, 1);
	if (!(xParam3.flags & 0xFF8))
	{
		cvtColor(xParam3, xParam3, COLOR_GRAY2BGR);
	}
	v5 = sqrt((double)(xParam3.total() * ((((unsigned int)xParam3.flags >> 3) & 0x1FF) + 1)));
	v7 = 1.0 / v5;
	m = xParam3.reshape(1, xParam3.rows);
	meanStdDev(m, sclMean, sclStdDev);
	xParam3.convertTo(xParam3, 5, 1.0, -sclMean[0]);
	double v15 = sclStdDev[0];
	if (v15 < v7)
		v15 = v7;
	xParam3.convertTo(xParam3, -1, 1.0 / v15, 0.0);
}

DocTypeRecognizer::DocTypeRecognizer()
{
	m_xDTR_field_14.width = 256;
	m_xDTR_field_14.height = 256;
}

DocTypeRecognizer::~DocTypeRecognizer()
{

}

bool DocTypeRecognizer::isLoaded()
{
	if (m_xDTR_dnn_Net_field_0.empty())
		return 0;
	return !m_vDTR_field_8.empty();
}

bool lessDocTypeCandidat(DocTypeCandidat & xDTC_Param1, DocTypeCandidat & xDTC_Param2)
{
	if (xDTC_Param1.fDTC_value_field_4 > xDTC_Param2.fDTC_value_field_4)
		return true;
	return false;
}

int DocTypeRecognizer::createOutputs(Mat const & xParam1, list<DocTypeCandidat> & lParam2)
{
	lParam2.clear();
	for (size_t i = 0; i < xParam1.total(); i++)
	{
		DocTypeCandidat dtc;
		float *fdata = (float *)xParam1.data;
		dtc.nDTC_type_field_0 = m_vDTR_field_8[i];
		dtc.fDTC_value_field_4 = fdata[i];
		lParam2.push_back(dtc);
	}
	lParam2.sort(lessDocTypeCandidat);
	return 0;
}

int DocTypeRecognizer::process(vector<Mat> const & vParam1, vector<list<DocTypeCandidat> > & vParam2)
{
	vector<Mat> vTemp(vParam1.size());
	for (uint i = 0; i < vParam1.size(); i++)
	{
		perImageStandardization(vParam1[i], m_xDTR_field_14, vTemp[i]);
	}
	Size sz(0, 0);
	Scalar sc;
	Mat m = dnn::blobFromImages(vTemp, 1.0, sz, sc, 1);
	m_xDTR_dnn_Net_field_0.setInput(m);
	Mat m1 = m_xDTR_dnn_Net_field_0.forward();
	vParam2.resize(m1.rows);
	for (int i = 0; i < m1.rows; i++)
	{
		createOutputs(m1.row(i), vParam2[i]);
	}
	return 0;
}

int DocTypeRecognizer::process(Mat const & xParam1, list<DocTypeCandidat> & lParam2)
{
	Mat m(xParam1);
	vector<Mat> vm;
	vector<list<DocTypeCandidat> > vl;
	vm.push_back(m);
	process(vm, vl);
	if (vl.size())
	{
		lParam2 = vl[0];
	}
	return 0;
}

vector<int> DocTypeRecognizer::getKnownIDs()
{
	return m_vDTR_field_8;
}

int DocTypeRecognizer::io_generic(cv::dnn::DnnReader & xDR_Param)
{
	cv::dnn::io_vec_int(xDR_Param, m_vDTR_field_8);
	m_xDTR_dnn_Net_field_0.io(xDR_Param);
	return 0;
}