#pragma
#include "../pch.h"
#include "../dnn/dnn_serialization.h"

class DocTypeRecognizer
{
public:
	DocTypeRecognizer();
	~DocTypeRecognizer();
	vector<int> getKnownIDs();
	bool isLoaded();
	int io_generic(cv::dnn::DnnReader &);
	int createOutputs(Mat const &, list<DocTypeCandidat> &);
	int process(vector<Mat> const &, vector<list<DocTypeCandidat> > &);
	int process(Mat const &, list<DocTypeCandidat> &);

public:
	dnn::Net	m_xDTR_dnn_Net_field_0;
	vector<int>	m_vDTR_field_8;
	Size		m_xDTR_field_14;
};