#include "interface.h"
#include "../common/common.h"

using namespace common;

IHashDocumentStorage::~IHashDocumentStorage()
{
	free();
}

void IHashDocumentStorage::free()
{
	unordered_map<int, _IDocument *>::iterator iter = m_umIHDS_8.begin();

	for (; iter != m_umIHDS_8.end(); iter++)
	{
		if (iter->first)
		{
			delete iter->second;
		}
	}

	m_umIHDS_8.clear();
}

void IHashDocumentStorage::docIDs(vector<int>& a2)
{
	a2 = mapKeys(m_umIHDS_8);
}

_IDocument * IHashDocumentStorage::getDocument(int a2)
{
	if (m_umIHDS_8.find(a2) == m_umIHDS_8.end() || m_umIHDS_8.at(a2) == 0)
	{
		_IDocument *pIDoc = create();

		if (pIDoc)
		{
			m_umIHDS_8.insert(pair<int, _IDocument *>(a2, pIDoc));
		}

		return pIDoc;
	}

	return m_umIHDS_8.at(a2);
}

_IDocument * IHashDocumentStorage::getExistDocument(int a2)
{
	if (m_umIHDS_8.find(a2) != m_umIHDS_8.end())
	{
		return m_umIHDS_8.at(a2);
	}
	return nullptr;
}

