#pragma once
#include "../pch.h"
#include "interface.h"

class Int2ClassStorage : public IDocumentStorage
{
public:
	unordered_multimap<int, pair<int, int>> m_ummI2CS_4;
public:
	~Int2ClassStorage();
	void clear(int);
	vector<int> filterByValue(vector<int> &, int);
	void free();
	void updateValue(int, int, int);
	void value(int, int &, int &);
};

class Int2ClassFilter : public IDocumentFilter
{
public:
	Int2ClassStorage m_xI2CF_4;
public:
	~Int2ClassFilter();
	
	int type();
	void save(int, vector<uchar> &);
	void load(int, vector<uchar> &);
	void clear(int);
	Int2ClassStorage* storage();
};

class DateOfExpFilter : public Int2ClassFilter
{
public:
	~DateOfExpFilter();

	int type();
};
