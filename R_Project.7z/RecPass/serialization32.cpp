#include "serialization32.h"

namespace serialization32
{
	void deserialize(uchar * a1, CImageRectFinal & a2, int * a3)
	{
		memcpy(&a2, a1, 40);
		a2.m_nCIRF_28 = 0;
		int n3 = *(int*)(a1 + 36);

		if (!n3)
		{
			*a3 = 40;
			return;
		}

		for (int i = 0; i < n3; i++)
		{
			char* p6 = (char*)&a2 + 40 + 8 * i;
			*(int*)(p6 + 4) = *(int*)(a1 + 40 + 8 * i);
			*(int*)(p6 + 8) = *(int*)(a1 + 40 + 8 * i + 4);
		}

		*a3 = 40 + 8 * n3;
	}
}


