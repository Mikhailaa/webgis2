#include "StdDataStreamDirect.h"

StdDataStreamDirectR::StdDataStreamDirectR(vector<uchar> const & vParam)
	: m_vSDSDR_0(vParam)
	, m_nSDSDR_C(0)
{

}

StdDataStreamDirectR::~StdDataStreamDirectR()
{

}

void StdDataStreamDirectR::readString(basic_string<char>& a2, int a3)
{
	if (m_nSDSDR_C + a3 <= (int)m_vSDSDR_0.size())
	{
		a2.insert(a2.end(), m_vSDSDR_0.begin() + m_nSDSDR_C, m_vSDSDR_0.begin() + m_nSDSDR_C + a3);
	}
	m_nSDSDR_C += a3;
}