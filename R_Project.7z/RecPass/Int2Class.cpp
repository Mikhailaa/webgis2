#include "Int2Class.h"
#include "StdDataStreamDirect.h"

Int2ClassStorage::~Int2ClassStorage()
{
}

void Int2ClassStorage::clear(int a2)
{
	if (m_ummI2CS_4.find(a2) != m_ummI2CS_4.end())
	{
		m_ummI2CS_4.erase(a2);
	}
}

vector<int> Int2ClassStorage::filterByValue(vector<int>& a3, int a4)
{
	if (a4)
	{
		vector<int> a1;

		for (size_t i = 0; i < a3.size(); i++)
		{
			int n13, n14;
			value(a3[i], n14, n13);

			if ((!n14 || n14 <= a4) && (!n13 || n13 >= a4))
			{
				a1.push_back(a3[i]);
			}
		}

		return a1;
	}
	return a3;
}

void Int2ClassStorage::free()
{
	m_ummI2CS_4.clear();
}

void Int2ClassStorage::updateValue(int a2, int a3, int a4)
{
	m_ummI2CS_4.emplace(a2, pair<int, int>(a3, a4));
}

void Int2ClassStorage::value(int a2, int & a3, int & a4)
{
	a3 = a4 = 0;
	unordered_multimap<int, pair<int, int>>::iterator iter = m_ummI2CS_4.find(a2);
	if (iter != m_ummI2CS_4.end())
	{
		a3 = iter->second.first;
		a4 = iter->second.second;
	}
}

Int2ClassFilter::~Int2ClassFilter()
{
}

int Int2ClassFilter::type()
{
	return 0;
}

void Int2ClassFilter::save(int, vector<uchar>&)
{
}

void Int2ClassFilter::load(int a2, vector<uchar>& a3)
{
	StdDataStreamDirectR xSDSDR(a3);

	int n6;

	if (xSDSDR.m_nSDSDR_C + 4 > (int)xSDSDR.m_vSDSDR_0.size())
	{
		n6 = 0;
	}
	else
	{
		n6 = *(int*)(xSDSDR.m_vSDSDR_0.data() + xSDSDR.m_nSDSDR_C);
	}

	xSDSDR.m_nSDSDR_C += 4;

	int n8;

	if (xSDSDR.m_nSDSDR_C + 4 > (int)xSDSDR.m_vSDSDR_0.size())
	{
		n8 = 0;
	}
	else
	{
		n8 = *(int*)(xSDSDR.m_vSDSDR_0.data() + xSDSDR.m_nSDSDR_C);
	}

	xSDSDR.m_nSDSDR_C += 4;

	storage()->updateValue(a2, n6, n8);
}

void Int2ClassFilter::clear(int a2)
{
	storage()->clear(a2);
}

Int2ClassStorage * Int2ClassFilter::storage()
{
	return &m_xI2CF_4;
}

DateOfExpFilter::~DateOfExpFilter()
{
}

int DateOfExpFilter::type()
{
	return 14;
}
