#pragma once
#include "../pch.h"

class StdDataStreamDirectW
{
public:
	vector<uchar> *m_pSDSDW_0;
public:
	template <class _T>
	StdDataStreamDirectW& operator<<(_T a)
	{
		m_pSDSDW_0->insert(m_pSDSDW_0->end(), (uchar*)(&a), (uchar*)(&a + 1));
		return *this;
	}
};

class StdDataStreamDirectR
{
public:
	StdDataStreamDirectR(vector<uchar> const &);
	~StdDataStreamDirectR();
	void readString(basic_string<char> &, int);

public:
	vector<uchar> m_vSDSDR_0;
	int m_nSDSDR_C;
};