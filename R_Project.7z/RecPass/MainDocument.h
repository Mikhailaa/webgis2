#pragma once
#include "../pch.h"
#include "interface.h"

class MainDocumentStorage : public IDocumentStorage
{
public:
	vector<int> m_vMDS_4;
	vector<int> m_vMDS_10;
public:
	~MainDocumentStorage();

	bool contains(int);
	void free();
	void setValue(int, int);
};

class MainDocumentFilter : public IDocumentFilter
{
public:
	MainDocumentStorage m_xMDF_4;
public:
	~MainDocumentFilter();
	int type();
	void save(int, vector<uchar> &);
	void load(int, vector<uchar> &);
	void clear(int);
	MainDocumentStorage* storage();
};