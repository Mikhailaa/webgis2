#include "TextOneClass.h"
#include "../common/common.h"
#include "StdDataStreamDirect.h"
#include "../common/StringUtils.h"

using namespace common;

TextOneClassStorage::~TextOneClassStorage()
{
}

void TextOneClassStorage::free()
{
	m_ummTOCS_4.clear();
	m_sTOCS_18.clear();
}

vector<int> TextOneClassStorage::filterByValue(vector<int> const & a3, string const & a4)
{
	vector<int> a1;
	set<int> s18(a3.begin(), a3.end());

	if (a4.length())
	{
		vector<int> vi1 = mapKeys(m_ummTOCS_4, a4);
		set<int> s15(vi1.begin(), vi1.end());
		a1.resize(s15.size() + s18.size());
		vector<int>::iterator iend = set_difference(s15.begin(), s15.end(), s18.begin(), s18.end(), a1.begin());
		a1.erase(iend, a1.end());
	}
	else
	{
		a1.resize(m_sTOCS_18.size() + s18.size());
		vector<int>::iterator iend = set_difference(s18.begin(), s18.end(), m_sTOCS_18.begin(), m_sTOCS_18.end(), a1.begin());
		a1.erase(iend, a1.end());
	}

	return a1;
}

void TextOneClassStorage::clear(int a2)
{
	if (m_ummTOCS_4.find(a2) != m_ummTOCS_4.end())
	{
		m_ummTOCS_4.erase(a2);
	}
}

void TextOneClassStorage::updateValue(int a2, string const & a3)
{
	if (a3.length())
	{
		m_ummTOCS_4.emplace(a2, a3);
	}
	else
	{
		m_sTOCS_18.insert(a2);
	}
}

vector<string> TextOneClassStorage::values(int a3)
{
	return mapValues(m_ummTOCS_4, a3);
}

TextOneClassFilter::~TextOneClassFilter()
{
}

int TextOneClassFilter::type()
{
	return 0;
}

void TextOneClassFilter::save(int, vector<uchar>&)
{
}

void TextOneClassFilter::load(int nParam1, vector<uchar>& vParam2)
{
	StdDataStreamDirectR xSDSDR(vParam2);

	int n5 = 0;


	if (xSDSDR.m_nSDSDR_C + 4 <= (int)xSDSDR.m_vSDSDR_0.size())
	{
		n5 = *(int*)(xSDSDR.m_vSDSDR_0.data() + xSDSDR.m_nSDSDR_C);
	}

	xSDSDR.m_nSDSDR_C += 4;

	for (int i = 0; i < n5; i++)
	{
		int n8 = 0;

		if (xSDSDR.m_nSDSDR_C + 4 <= (int)xSDSDR.m_vSDSDR_0.size())
		{
			n8 = *(int*)(xSDSDR.m_vSDSDR_0.data() + xSDSDR.m_nSDSDR_C);
		}

		xSDSDR.m_nSDSDR_C += 4;

		string str;

		xSDSDR.readString(str, n8);

		storage()->updateValue(nParam1, str);
	}
}

void TextOneClassFilter::clear(int a2)
{
	storage()->clear(a2);
}

TextOneClassStorage * TextOneClassFilter::storage()
{
	return &m_xTOCF_4;
}

TextStateCodeFilter::~TextStateCodeFilter()
{
}

int TextStateCodeFilter::type()
{
	return 9;
}

TextFilterMaskFilter::TextFilterMaskFilter()
{
}

TextFilterMaskFilter::~TextFilterMaskFilter()
{
}

int TextFilterMaskFilter::type()
{
	return 16;
}

MaskFilterStorage * TextFilterMaskFilter::storage()
{
	return &m_xTFMF_28;
}

MaskFilterStorage::~MaskFilterStorage()
{
}

vector<int> MaskFilterStorage::filterByValue(vector<int> const & vParam1, string const & strParam2)
{
	vector<int> vRes;

	for (size_t i = 0; i < vParam1.size(); i++)
	{
		unordered_multimap<int, string>::iterator iter = m_ummTOCS_4.find(vParam1[i]);

		if (iter != m_ummTOCS_4.end())
		{
			vector<string> v42 = common::StringUtils::Split(iter->second, ':');

			if (v42.size() >= 3 && v42[0] == "MRZ")
			{
				int n16 = common::StringUtils::toInt(v42[1]);
				vector<string> v0_0 = common::StringUtils::Split(v42[2], ',');

				for (size_t j = 0; j < v0_0.size(); j++)
				{
					if (v0_0[j].length() + n16 < strParam2.length())
					{
						string bs1a(strParam2, n16, v0_0[j].length());

						if (v0_0[j] == bs1a)
						{
							vRes.push_back(vParam1[i]);
						}
					}
				}
			}
		}
		else
		{
			vRes.emplace_back(vParam1[i]);
		}
	}
	return vRes;
}

TextCountryIDFilter::~TextCountryIDFilter()
{
}

void TextCountryIDFilter::save(int, vector<uchar>&)
{
}

void TextCountryIDFilter::load(int a2, vector<uchar>& a3)
{
	StdDataStreamDirectR xSDSDR(a3);

	int n5 = 0;

	if (xSDSDR.m_nSDSDR_C + 4 <= (int)xSDSDR.m_vSDSDR_0.size())
	{
		n5 = *(int*)(xSDSDR.m_vSDSDR_0.data() + xSDSDR.m_nSDSDR_C);
	}

	xSDSDR.m_nSDSDR_C += 4;

	for (int i = 0; i < n5; i++)
	{
		int n6 = 0;

		if (xSDSDR.m_nSDSDR_C + 4 <= (int)xSDSDR.m_vSDSDR_0.size())
		{
			n6 = *(int*)(xSDSDR.m_vSDSDR_0.data() + xSDSDR.m_nSDSDR_C);
		}

		xSDSDR.m_nSDSDR_C += 4;

		string a1;

		for (int j = 0; j < n6; j++)
		{
			a1.push_back(xSDSDR.m_vSDSDR_0[xSDSDR.m_nSDSDR_C] + j + 1);
			xSDSDR.m_nSDSDR_C++;
		}

		storage()->updateValue(a2, a1);
	}
}

int TextCountryIDFilter::type()
{
	return 15;
}
