#pragma once

#include "../pch.h"

struct CImageRectFinal
{
	int m_nCIRF_0;
	int m_nCIRF_4;
	int m_nCIRF_8;
	int m_nCIRF_C;
	int m_nCIRF_10;
	int m_nCIRF_14;
	int m_nCIRF_18;
	int m_nCIRF_1C;
	char m_fCIRF_20;
	char m_fCIRF_21;
	char m_fCIRF_22;
	char m_fCIRF_23;
	int m_nCIRF_24;
	int m_nCIRF_28;
	int m_nCIRF_2C;
	int m_nCIRF_30;
	int m_nCIRF_34;
	int m_nCIRF_38;
	int m_nCIRF_3C;
	int m_nCIRF_40;
	int m_nCIRF_44;
	int m_nCIRF_48;
	int m_nCIRF_4C;
	int m_nCIRF_50;
	int m_nCIRF_54;
	int m_nCIRF_58;
	int m_nCIRF_5C;
	int m_nCIRF_60;
	int m_nCIRF_64;
	int m_nCIRF_68;
	int m_nCIRF_6C;
	int m_nCIRF_70;
	int m_nCIRF_74;
	int m_nCIRF_78;
	int m_nCIRF_7C;
	int m_nCIRF_80;
	int m_nCIRF_84;
	int m_nCIRF_88;
	int m_nCIRF_8C;
	int m_nCIRF_90;
	int m_nCIRF_94;
	int m_nCIRF_98;
	int m_nCIRF_9C;
	int m_nCIRF_A0;
	int m_nCIRF_A4;
	int m_nCIRF_A8;
};

namespace serialization32
{
	void deserialize(uchar *, CImageRectFinal &, int *);
}
