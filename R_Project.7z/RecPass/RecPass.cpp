﻿#include "RecPass.h"
#include "../gdi/Point.h"
#include "../gdi/Rect.h"
#include "../regula.h"
#include "../docformatinfo.h"
#include "../imagemanipulation.h"
#include "StdDataStreamDirect.h"
#include "../common/container/jsoncpp.h"
#include "../common/ModuleOrchestrator.h"

using namespace cv;
using namespace regula::light;
using namespace docformatinfo;
using namespace imagemanipulation;

struct gRecPassExternal_global_registrator {
	shared_ptr<RecPassExternal> gRecPassExternal;
	gRecPassExternal_global_registrator() {
		gRecPassExternal = common::getModuleOrchestrator()->addModule<RecPassExternal>();
	}
} gRecPassExternal_global_registrator_;

TRecognParamsStd::TRecognParamsStd()
{
	m_nTRPS_field_3C = 0;
	m_nTRPS_field_40 = 0;
	m_bTRPS_field_44 = 0;
	m_bTRPS_field_45 = 0;
	m_bTRPS_field_46 = 0;
	m_bTRPS_field_47 = 0;
	m_bTRPS_field_60 = 0;
	m_bTRPS_field_61 = 0;
	m_cTRPS_field_62 = 0;
	m_cTRPS_field_63 = 0;
	m_bTRPS_field_70 = 0;
	m_bTRPS_field_71 = true;
	m_bTRPS_field_72 = 0;
	m_bTRPS_field_73 = 0;
}

TRecognParamsStd::~TRecognParamsStd()
{

}

CMasCandidats::CMasCandidats(int nParam)
{
	m_nCMC_field_0 = nParam;
	m_nCMC_field_4 = 0;
	m_pCMC_field_8 = 0;
	m_nCMC_field_C = 0;
	m_pCMC_field_8 = new CMC_DATA[nParam];
	if (nParam)
	{
		memset(m_pCMC_field_8, 0, sizeof(CMC_DATA) * nParam);
	}
}

CMasCandidats::~CMasCandidats()
{

}

namespace recpass
{
	int * GlobalParams::obj()
	{
		static int n112E488 = 0;
		return &n112E488;
	}

	namespace imageholder
	{
		ImageHolder::ImageHolder()
		{

		}

		ImageHolder::~ImageHolder()
		{

		}

		void ImageHolder::init(common::container::RclHolder & xPH_Param1, bool bParam2)
		{
			m_xIH_RH_field_4.clear();
			m_xIH_RH_field_4.addNoCopy(xPH_Param1.m_xTRCL);
			m_bIH_field_2C = bParam2;
			m_xIH_RH_field_18.clear();
			rclhelp::generateWhiteGray(m_xIH_RH_field_4);
			m_bIH_field_2D = 0;
		}

		int ImageHolder::getImage(eRPRM_Lights eParam1, cv::Rect & xParam2, cv::Size_<int> & xParam3, cv::Mat & xParam4)
		{
			TRawImageContainer *pTRIC;
			if (!m_bIH_field_2D)
			{
				pTRIC = regula::light::findImageUsingLightGroup(m_xIH_RH_field_4.m_xTRCL, eParam1, 1, 0, 0);
				if (!pTRIC)
				{
					return 29;
				}
			}
			else
			{
				pTRIC = regula::light::findImageUsingLightGroup(m_xIH_RH_field_18.m_xTRCL, eParam1, 0, 0, 0);
				if (!pTRIC)
				{
					vector<TResultContainer *> vTRC = m_xIH_RH_field_4.getRcList(1, regula::light::lightGroup(eParam1));
					if (!vTRC.size())
						return 29;
					m_xIH_RH_field_18.addCopy(*vTRC[0]);
					vTRC.clear();
					vTRC = m_xIH_RH_field_18.getRcList(1, regula::light::lightGroup(eParam1));
					if (!vTRC.size())
						return 29;
					common::images::RotateImage(*vTRC[0], imaging::RI_Rotations_2);
					pTRIC = regula::light::findImageUsingLightGroup(m_xIH_RH_field_18.m_xTRCL, eParam1, 0, 0, 0);
					if (!pTRIC)
						return 29;
				}
			}
			Mat mTemp = common::container::wrapByMat(*pTRIC);
			Rect r = xParam2 & Rect(0, 0, mTemp.cols, mTemp.rows);
			int res = 1;
			if (r.width * r.height)
			{
				Mat m1(mTemp, r);
				resize(m1, xParam4, xParam3);
				res = 0;
			}
			return res;
		}

		bool ImageHolder::isDpiTrue()
		{
			return m_bIH_field_2C;
		}

		bool ImageHolder::isLockProportion()
		{
			return m_bIH_field_2E;
		}

		void ImageHolder::imageInfo(int & nParam1, tagSIZE & xParam2)
		{
			rclhelp::imageParameters(m_xIH_RH_field_4.m_xTRCL, nParam1, xParam2);
		}
	}

	int getRecognParam(TResultContainerList *pTRCL_Param1, Json::Value & xJV_Param2, TRecognParamsStd & xTRPS_Param3)
	{
		string strTemp;
		common::container::RclHolder rh(pTRCL_Param1, 1);
		if (xJV_Param2.isMember("recpassParam"))
		{
			Json::Value jv(xJV_Param2["recpassParam"]);
			if (jv.isMember("docFormat"))
			{
				xTRPS_Param3.m_vTRPS_field_0.push_back(jv["docFormat"].asInt());
			}
			if (jv.isMember("codeCountry"))
			{
				xTRPS_Param3.m_strTRPS_field_18 = jv["codeCountry"].asString();
			}
			if (jv.isMember("codeDoc"))
			{
				xTRPS_Param3.m_strTRPS_field_C = jv["codeDoc"].asString();
			}
			if (jv.isMember("codeState"))
			{
				xTRPS_Param3.m_strTRPS_field_24 = jv["codeState"].asString();
			}
			if (jv.isMember("barcodeStatus"))
			{
				xTRPS_Param3.m_nTRPS_field_3C = jv["barcodeStatus"].asInt();
			}
			if (jv.isMember("dateOfExpCurr"))
			{
				xTRPS_Param3.m_nTRPS_field_40 = jv["dateOfExpCurr"].asInt();
			}
			if (jv.isMember("isDevice"))
			{
				xTRPS_Param3.m_bTRPS_field_45 = jv["isDevice"].asBool();
			}
			Json::Value jvTemp = (jv.get("countryFilter", Json::Value("")));
			xTRPS_Param3.m_strTRPS_field_48 = jvTemp.asString();
			jvTemp = (jv.get("cropByRectPosition", Json::Value(false)));
			xTRPS_Param3.m_bTRPS_field_60 = jvTemp.asBool();
			jvTemp = (jv.get("lockImageProportion", Json::Value(false)));
			xTRPS_Param3.m_bTRPS_field_61 = jvTemp.asBool();
			if (jv.isMember("addUnknownByDnn"))
			{
				xTRPS_Param3.m_bTRPS_field_70 = jv["addUnknownByDnn"].asBool();
			}
			if (jv.isMember("useDnn"))
			{
				xTRPS_Param3.m_bTRPS_field_71 = jv["useDnn"].asBool();
			}
			jvTemp = (jv.get("docIdListDnnTrue", Json::Value("")));
			strTemp = jvTemp.asString();
			if (strTemp.length())
			{
				vector<string> vstr = common::StringUtils::Split(strTemp, ',');
				for (uint i = 0; i < vstr.size(); i++)
				{
					xTRPS_Param3.m_vTRPS_field_64.push_back(common::StringUtils::toInt(vstr[i]));
				}
			}
			jvTemp = (jv.get("docIdFilter", Json::Value("")));
			strTemp = jvTemp.asString();
			if (strTemp.length())
			{
				vector<string> vstr = common::StringUtils::Split(strTemp, ',');
				for (uint i = 0; i < vstr.size(); i++)
				{
					xTRPS_Param3.m_vTRPS_field_54.push_back(common::StringUtils::toInt(vstr[i]));
				}
			}
		}
		if (!xTRPS_Param3.m_vTRPS_field_0.size())
		{
			int nDocFmt = rclhelp::documentFormat(rh.m_xTRCL);
			if (nDocFmt != -1)
			{
				xTRPS_Param3.m_vTRPS_field_0.push_back(nDocFmt);
			}
		}
		if (!xTRPS_Param3.m_strTRPS_field_18.length() || !xTRPS_Param3.m_strTRPS_field_C.length() || !xTRPS_Param3.m_nTRPS_field_40)
		{
			vector<TResultContainer *> vTRC = rh.getRcList(3);
			if (vTRC.size() && vTRC[0]->u.pTRC_DVEI)
			{
				TDocVisualExtendedInfo *pTDVEI = vTRC[0]->u.pTRC_DVEI;
				if (!xTRPS_Param3.m_strTRPS_field_18.length() || !xTRPS_Param3.m_strTRPS_field_C.length())
				{
					xTRPS_Param3.m_strTRPS_field_18 = common::textdoc::getValue(*pTDVEI, VisualFieldType_1);
					xTRPS_Param3.m_strTRPS_field_C = common::textdoc::getValue(*pTDVEI, VisualFieldType_0);
				}
				if (!xTRPS_Param3.m_strTRPS_field_30.length())
				{
					xTRPS_Param3.m_strTRPS_field_30 = common::textdoc::getValue(*pTDVEI, VisualFieldType_33);
				}
				if (!xTRPS_Param3.m_nTRPS_field_40)
				{
					strTemp = common::textdoc::getValue(*pTDVEI, VisualFieldType_3);
					string strMask = common::textdoc::getMask(*pTDVEI, VisualFieldType_3);
					if (strMask == "{YEAR_DD}{MONTH_DD}{DAY}")
					{
						xTRPS_Param3.m_nTRPS_field_40 = common::system::getDaysFrom30121899ForYYMMDD(strTemp);
					}
				}
				if (!xTRPS_Param3.m_vTRPS_field_0.size())
				{
					int nDocFmt = rclhelp::documentFormatFromMRZOld(rh.m_xTRCL);
					if (nDocFmt != -1)
					{
						xTRPS_Param3.m_vTRPS_field_0.push_back(nDocFmt);
						xTRPS_Param3.m_vTRPS_field_0.push_back(1000);
						xTRPS_Param3.m_vTRPS_field_0.push_back(1002);
					}
				}
			}
		}
		if (!xTRPS_Param3.m_strTRPS_field_24.length())
		{
			vector<TResultContainer *> vTRC = rh.getRcList(18);
			if (vTRC.size() && vTRC[0]->u.pTRC_DVEI)
			{
				TDocVisualExtendedInfo *pTDVEI = vTRC[0]->u.pTRC_DVEI;
				xTRPS_Param3.m_strTRPS_field_24 = common::textdoc::getValue(*pTDVEI, VisualFieldType_4E);
			}
		}
		if (rclhelp::deviceTypeReal(*pTRCL_Param1))
		{
			xTRPS_Param3.m_bTRPS_field_44 = 1;
		}
		return 0;
	}

	int getROIByElementsAnalyze(IdentifyRectDocument & xIRD_Param1, DpiInfo & xDI_Param2, tagRECT & xParam3)
	{
		xParam3.left = 0;
		xParam3.top = 0;
		xParam3.right = 0;
		xParam3.bottom = 0;
		uint v12 = 0;
		float v11 = xIRD_Param1.m_vIRD_44[0].m_rIRR_0;
		for (uint i = 0; i < xIRD_Param1.m_xIRD_4.m_vIRA_0.size(); i++)
		{
			if (xIRD_Param1.m_xIRD_4.m_vIRA_0[i].m_xCIRF2_0.struc_367_24 == 4 &&
				xIRD_Param1.m_vIRD_44[v12].m_rIRR_0 < v11)
			{
				v12 = i;
			}
		}
		float v16 = xIRD_Param1.m_xIRD_4.m_vIRA_0[v12].m_xCIRF2_0.struc_367_0.left * 1000.0f / xIRD_Param1.m_nIRD_20;
		float v17 = xIRD_Param1.m_xIRD_4.m_vIRA_0[v12].m_xCIRF2_0.struc_367_0.top * 1000.0f / xIRD_Param1.m_nIRD_20;
		int v19 = (int)xIRD_Param1.m_vIRD_44[v12].m_xIRR_4.x();
		int v20 = (int)(v16 * xDI_Param2.nDI_0 * 0.001f);
		int v21 = (int)xIRD_Param1.m_vIRD_44[v12].m_xIRR_4.y();
		xParam3.left = v19 - v20;
		xParam3.top = v21 - (int)(v17 * xDI_Param2.nDI_0 * 0.001f);
		xParam3.right = (int)(xIRD_Param1.m_xIRD_24.width * xDI_Param2.nDI_0 / 1000.0f);
		xParam3.bottom = (int)(xIRD_Param1.m_xIRD_24.width * xDI_Param2.nDI_0 / 1000.0f + xParam3.top);
		return 0;
	}

	namespace rect
	{
		tagRECT convert(Rect const & xParam1, bool bParam2)
		{
			tagRECT res;
			res.left = xParam1.x;
			res.top = xParam1.y;
			res.right = xParam1.x + xParam1.width;
			res.bottom = xParam1.y + xParam1.height;
			if (bParam2)
			{
				res.top ^= res.bottom ^= res.top ^= res.bottom;
			}
			return res;
		}

		Rect getRectInPixel(Rect2f const & xParam1, Size2f const & xParam2, tagSIZE const & xParam3)
		{
			Rect r11, r12;
			r11.width = xParam3.cx;
			r11.height = xParam3.cy;
			r12.x = (int)(xParam1.x * xParam3.cx / xParam2.width);
			r12.y = (int)(xParam1.y * xParam3.cy / xParam2.height);
			r12.width = (int)(xParam1.width * xParam3.cx / xParam2.width);
			r12.height = (int)(xParam1.height * xParam3.cy / xParam2.height);
			return (r11 & r12);
		}

		Rect getRectInPixel(Rect2f const & xParam1, int nParam2, tagSIZE const & xParam3)
		{
			Rect r9, r12;
			r9.width = xParam3.cx;
			r9.height = xParam3.cy;
			r12.x = (int)(xParam1.x * nParam2 * 0.001f);
			r12.y = (int)(xParam1.y * nParam2 * 0.001f);
			r12.width = (int)(xParam1.width * nParam2 * 0.001f);
			r12.height = (int)(xParam1.height * nParam2 * 0.001f);
			return (r9 & r12);
		}

		Size getSizeInPixel(Size const & xParam1, int nParam2, int nParam3)
		{
			return Size(xParam1.width * nParam3 / nParam2, xParam1.height * nParam3 / nParam2);
		}

		Size getSizeInPixel(Size const & xParam1, int nParam2, int nParam3, int nParam4)
		{
			return Size(xParam1.width * nParam4 / nParam2, xParam1.height * nParam4 / nParam3);
		}
	}

	namespace filters
	{
		void setFiltersDocumentsFast(vector<int> & vParam)
		{
			vParam.clear();
			vParam.push_back(0);
			vParam.push_back(1);
			vParam.push_back(14);
			vParam.push_back(2);
			vParam.push_back(3);
			vParam.push_back(16);
			vParam.push_back(13);
			vParam.push_back(6);
		}
	}

	namespace IdentifyRectSearchM
	{
		int checkFilteredRects(IdentifyRectDocument * a1, CDocFormat a2, vector<int>& a3, imageholder::IImageHolder & a4, DpiInfo & a5, vector<IdentifyRectResult>& a6)
		{
			int n14;

			vector<cv::Mat> vm55(a3.size());

			size_t i;

			for (i = 0; i < a3.size(); i++)
			{
				n14 = getSearchArrayForRect(*a1, a2, a4, a3[i], a5, vm55[i]);
				if (n14)
				{
					return n14;
				}
			}

			int *p15 = GlobalParams::obj();
			*p15 = max(*p15, 3);

			if (*p15)
			{
				for (size_t j = 0; j < vm55.size(); j++)
				{
					cv::Mat m56;
					vm55[j].copyTo(m56);
					cv::blur(m56, vm55[j], cv::Size(*p15, *p15));
				}
			}

			vector<IdentifyKit> v3a;
			a1->filterRects(a3, v3a);

			for (size_t j = 0; j < v3a.size(); j++)
			{
				v3a[j].m_pIK_4 = &vm55[j];
			}

			n14 = IdentifyRectSearch::findMask(v3a, a6);

			if (!n14)
			{
				vector<int> v1a;
				a1->getResolution(a3, v1a);
				int n48 = 0;
				tagSIZE x47;
				x47.cx = x47.cy = 0;
				a4.imageInfo(n48, x47);

				if (!n48)
				{
					n48 = a5.nDI_4;
				}

				for (size_t j = 0; j < v3a.size(); j++)
				{
					Info *p29 = &IdentifyRectDocument::searchInfo()->pSI_4[a3[j]];
					p29->nInfo_0 = (int)(v3a[j].m_pIK_8->m_rIRR_0 * 100.0f);
					float r28 = (float)n48 / v1a[j];

					CPoint xp46(v3a[j].m_pIK_8->m_xIRR_4 * r28);
					CPoint xp45(p29->xInfo_2C.left, p29->xInfo_2C.top);
					xp45.rx() += xp46.x();
					xp45.ry() += xp46.y();
					CRect x54(p29->xInfo_C);
					CRect x56(xp45, x54.m_size);
					p29->xInfo_1C = x56.regRect();
					a6[j].m_xIRR_4 = x56.center();
					v3a[j].m_pIK_8->m_xIRR_4 = CPointF(x56.left(), x56.top());

					int n39 = p29->xInfo_1C.top;
					p29->xInfo_1C.top = p29->xInfo_1C.bottom;
					p29->xInfo_1C.bottom = n39;
				}

				n14 = 0;
			}

			return n14;
		}

		int getSearchArrayForRect(IdentifyRectDocument & a1, CDocFormat a2, imageholder::IImageHolder & a3, int a4, DpiInfo & a5, cv::Mat & a6)
		{
			eRPRM_Lights e8 = a1.m_xIRD_4.m_vIRA_0[a4].m_xCIRF2_0.struc_367_14;
			if (contains(whiteGroup(), a1.m_xIRD_4.m_vIRA_0[a4].m_xCIRF2_0.struc_367_14) && a1.m_xIRD_4.m_vIRA_0[a4].m_xCIRF2_0.struc_367_1F == 1)
			{
				e8 = RPRM_Lights_2000000;
			}

			float r13 = (float)a1.m_nIRD_20;

			CRect x62(a1.m_xIRD_4.m_vIRA_0[a4].m_xCIRF2_0.struc_367_0);
			float r15 = 1000.0;
			cv::Rect2f x61(x62.left() / r13 * 1000.0f, x62.bottom() / r13 * 1000.0f, x62.m_size.width() / r13 * 1000.0f, x62.m_size.height() / r13 * 1000.0f);

			CPoint x60 = CPoint(a1.m_nIRD_10, -a1.m_nIRD_14) * r13 * 0.0001f;
			CSize x57 = CSize(a1.m_nIRD_18, a1.m_nIRD_1C) * r13 * 0.0008f;
			x62.setCenter(x62.center().added(x60));
			x62.increaseForCenter(x57);

			cv::Rect2f x54;
			x54.x = x62.left() / r13 * 1000.0f;
			x54.y = x62.bottom() / r13 * 1000.0f;
			x54.width = x62.m_size.width() / r13 * 1000.0f;
			x54.height = x62.m_size.height() / r13 * 1000.0f;

			float r23 = a1.m_xIRD_24.width;
			float r24 = a1.m_xIRD_24.height;

			cv::Size2f x3a;
			x3a.width = r23;
			x3a.height = r24;

			if (r23 == 0.0)
			{
				x3a = docSizeMM(a2);
			}
			else if (getDocFormatByMM(r23, r24, 0.07f, DOCFORMAT_3E8) != a2)
			{
				cv::Size2f x1a = docSizeMM(a2);

				if (x1a.width > 0.0)
				{
					x3a = x1a;
				}
			}

			float r25 = x3a.width;
			int n26 = 1;
			if (r25 == 0.0)
			{
				return n26;
			}

			r15 = x3a.height;

			int n52 = 0;
			tagSIZE x4a;
			x4a.cx = x4a.cy = 0;
			a3.imageInfo(n52, x4a);

			cv::Rect x49, x50;
			cv::Size x48;

			if (a3.isDpiTrue() && n52)
			{
				x50 = rect::getRectInPixel(x54, n52, x4a);
				x49 = rect::getRectInPixel(x61, n52, x4a);
				x48 = rect::getSizeInPixel(x50.size(), n52, a1.m_vIRD_2C[a4].second);
			}
			else
			{
				x50 = rect::getRectInPixel(x54, x3a, x4a);
				x49 = rect::getRectInPixel(x61, x3a, x4a);

				int n32 = (int)(1000 * x4a.cx / r25);
				int n33 = (int)min(1000 * x4a.cx / r25, 1000 * x4a.cy / r15);

				if (a3.isLockProportion())
				{
					n32 = n33;
				}
				else
				{
					n33 = (int)(1000 * x4a.cy / r15);
				}

				x48 = rect::getSizeInPixel(x50.size(), n32, n33, a1.m_vIRD_2C[a4].second);
				
				if (!n52)
				{
					a5.nDI_4 = (n32 + n33) / 2;
					n52 = a5.nDI_4;
				}
			}

			n26 = 1;

			if (x50.area() && x48.area() && n52)
			{
				cv::Mat x1a;
				if (a3.getImage(e8, x50, x48, x1a))
				{
					n26 = 29;
				}
				else
				{
					int n34 = a1.m_xIRD_4.m_vIRA_0[a4].m_xCIRF2_0.struc_367_1F;

					if (n34 <= 1)
					{
						n34 = 1;
					}

					convertImage24to8ByFieldDesc(x1a, a6, n34);
					SearchInfo *p36 = IdentifyRectDocument::searchInfo();
					p36->pSI_4[a4].xInfo_2C = rect::convert(x50, false);
					p36->pSI_4[a4].xInfo_C = rect::convert(x49, false);
					n26 = 0;
					p36->pSI_4[a4].nInfo_4 = a1.m_xIRD_4.m_vIRA_0[a4].m_xCIRF2_0.struc_367_14;
				}
			}

			return n26;
		}

		int recognizeByRects(int a1, IdentifyRectDocument * a2, CDocFormat a3, imageholder::IImageHolder & a4, DpiInfo & a5, int a6, float a7, float & a8, set<int>& a9)
		{
			int n20;
			memset(IdentifyRectDocument::searchInfo(), 0, 964);
			a8 = 0.0;
			vector<int> v1a;
			vector<vector<int>> vv103;
			a2->m_xIRD_4.filterByConflictID(a6, v1a);
			a2->m_xIRD_4.filterByLayer(v1a, vv103);

			bool fbrk = 0;

			if (!vv103[1].empty())
			{
				vector<IdentifyRectResult> v106;
				int n102;

				n102 = checkFilteredRects(a2, a3, vv103[1], a4, a5, v106);

				if (n102)
				{
					a9.insert(n102);
				}

				for (size_t i = 0; i < v106.size(); i++)
				{
					if (v106[i].m_rIRR_0 < a2->m_xIRD_4.m_vIRA_0[vv103[1][i]].m_xCIRF2_0.struc_367_22 / 100.0f)
					{
						a8 = v106[i].m_rIRR_0;
						return 1;
					}
				}
			}

			vector<int> v101;
			vector<int> v102;
			a2->m_xIRD_4.filterByRequred(vv103[0], v101, v102);
			vector<int> v3a(1);

			n20 = 1;

			for (size_t i = 0; i < v102.size(); i++)
			{
				v3a[0] = v102[i];
				vector<IdentifyRectResult> v106;
				int n99 = checkFilteredRects(a2, a3, v3a, a4, a5, v106);
				if (n99)
				{
					a9.insert(n99);
				}
				else
				{
					if (v106[0].m_rIRR_0 >= a2->m_xIRD_4.m_vIRA_0[v3a[0]].m_xCIRF2_0.struc_367_22 / 100.0f)
					{
						if (a8 > v106[0].m_rIRR_0 || a8 == 0.0)
						{
							a8 = v106[0].m_rIRR_0;
						}
					}
					else
					{
						n20 = 1;
						a8 = 0.0;
						return n20;
					}
				}
			}

			if (!v101.empty())
			{
				vector<IdentifyRectResult> v106;
				int n99 = checkFilteredRects(a2, a3, v101, a4, a5, v106);
				if (n99)
				{
					a9.insert(n99);
				}

				float r24 = -1.0f;

				for (size_t i = 0; i < v106.size(); i++)
				{
					r24 = max(v106[i].m_rIRR_0, r24);
				}

				if (r24 >= 0.7)
				{
					if (a8 > r24 || a8 == 0.0)
					{
						a8 = r24;
					}
				}
				else
				{
					return 1;
				}
			}

			if (vv103[2].empty())
			{
				return 0;
			}

			vector<IdentifyRectResult> v99;

			int n98 = checkFilteredRects(a2, a3, vv103[2], a4, a5, v99);

			if (n98)
			{
				a9.insert(n98);
			}

			float r30 = 1.0f, r31 = -1.0f, r33 = 100.0;

			for (size_t i = 0; i < v99.size(); i++)
			{
				char ch36 = a2->m_xIRD_4.m_vIRA_0[vv103[2][i]].m_xCIRF2_0.struc_367_1C;
				char ch37 = a2->m_xIRD_4.m_vIRA_0[vv103[2][i]].m_xCIRF2_0.struc_367_22;
				r33 = min(r33, (float)ch37);

				if (ch36)
				{
					if (v99[i].m_rIRR_0 < ch37 / 100.0f)
					{
						return 1;
					}

					r30 = min(r30, v99[i].m_rIRR_0);
				}
				else if (v99[i].m_rIRR_0 > r31)
				{
					r31 = v99[i].m_rIRR_0;
				}
			}

			if (r31 == -1.0)
			{
				r31 = r30;
			}

			a8 = min(r30, r31);

			if (r31 < r33 / 100.0f)
			{
				a8 = 0.0;
				return 1;
			}

			int n40 = 0;
			tagSIZE x95;
			x95.cx = x95.cy = 0;
			a4.imageInfo(n40, x95);

			int n45 = n40 ? n40 : a5.nDI_4;

			float r54 = (float)n45 / a2->m_nIRD_20;

			int n88 = 0;
			float r46 = -1.0, r48 = -1.0;

			bool f2a = 1;

			for (size_t i = 0; i < v99.size(); i++)
			{
				f2a &= (a2->m_xIRD_4.m_vIRA_0[vv103[2][i]].m_xCIRF2_0.struc_367_18 != 4);

				if (v99[i].m_rIRR_0 * 100.0f >= a2->m_xIRD_4.m_vIRA_0[vv103[2][i]].m_xCIRF2_0.struc_367_22)
				{
					for (size_t j = i + 1; j < v99.size(); j++)
					{
						if (v99[j].m_rIRR_0 * 100.0f >= a2->m_xIRD_4.m_vIRA_0[vv103[2][j]].m_xCIRF2_0.struc_367_22)
						{
							CPoint x93 = CRect(a2->m_xIRD_4.m_vIRA_0[vv103[2][i]].m_xCIRF2_0.struc_367_0).center();
							CPoint x92 = CRect(a2->m_xIRD_4.m_vIRA_0[vv103[2][j]].m_xCIRF2_0.struc_367_0).center();
							CPoint x94 = x93.subtract(x92);
							x94 = x94 * r54;
							CPoint x106 = v99[i].m_xIRR_4.subtract(v99[j].m_xIRR_4);

							float r69 = sqrtf((float)x94.x() * x94.x() + (float)x94.y() * x94.y());
							float r73 = sqrtf((float)x106.x() * x106.x() + (float)x106.y() * x106.y());

							int n76 = (int)fabsf((float)x94.x() - x106.x());
							int n78 = (int)fabsf((float)x94.y() - x106.y());

							float r80 = sqrtf((float)n76 * n76 + (float)n78 * n78);
							float r81 = 0.0;
							float r82 = 100.0f;

							if (r69 != 0.0)
							{
								r81 = r80 / r69;
								r82 = r80 / r69 * 100.0f;

								if (r73 < r69)
								{
									r81 = -r81;
								}
							}

							if (!(a2->m_xIRD_4.m_vIRA_0[vv103[2][i]].m_xCIRF2_0.struc_367_18 != 4 && a2->m_xIRD_4.m_vIRA_0[vv103[2][j]].m_xCIRF2_0.struc_367_18 != 4))
							{
								n88 = (int)((r81 + 1.0f) * n45);
							}

							f2a &= (a2->m_xIRD_4.m_vIRA_0[vv103[2][j]].m_xCIRF2_0.struc_367_18 != 4);

							if (a2->m_xIRD_4.m_vIRA_0[vv103[2][i]].m_xCIRF2_0.struc_367_1C && a2->m_xIRD_4.m_vIRA_0[vv103[2][j]].m_xCIRF2_0.struc_367_1C)
							{
								if (r46 < r82 || r46 == -1.0)
								{
									r46 = r82;
								}
							}
							else
							{
								if (r48 > r82 || r48 == -1.0)
								{
									r48 = r82;
								}
							}
						}
					}
				}
			}

			if (r48 < r46)
			{
				r48 = r46;
			}

			if (f2a && (r48 > a7 || r48 == 1.0))
			{
				a8 = 0.0;
				n20 = 1;
			}
			else
			{
				n20 = 0;
				a5.nDI_0 = n88;
			}

			return n20;
		}
	}
}

string filterName(eDocumentFilterClass eParam)
{
	string strFilter;
	switch (eParam)
	{
	case DocumentFilterClass_0:
		strFilter = "MainChildrenFilter";
		break;
	case DocumentFilterClass_1:
		strFilter = "DocIDType";
		break;
	case DocumentFilterClass_2:
		strFilter = "CountryCode";
		break;
	case DocumentFilterClass_3:
		strFilter = "DocumentCode";
		break;
	case DocumentFilterClass_4:
		strFilter = "Face";
		break;
	case DocumentFilterClass_5:
		strFilter = "Color";
		break;
	case DocumentFilterClass_6:
		strFilter = "Rects";
		break;
	case DocumentFilterClass_8:
		strFilter = "AddRelatedByRects";
		break;
	case DocumentFilterClass_9:
		strFilter = "StateCode";
		break;
	case DocumentFilterClass_12:
		strFilter = "Barcode";
		break;
	case DocumentFilterClass_13:
		strFilter = "Dnn";
		break;
	case DocumentFilterClass_14:
		strFilter = "DateOfExp";
		break;
	case DocumentFilterClass_16:
		strFilter = "FilterMask";
		break;
	default:
		strFilter = "Unknown";
		break;
	}
	return strFilter;
}

RecPass::RecPass()
	: m_xRP_JV(0)
{
	m_nRP_field_238 = m_nRP_field_23C = m_nRP_field_240 = m_nRP_field_244 = m_nRP_field_248 = 0;
	m_bRP_field_24C = 0;
	m_xRP_field_27C.pszTOC_DocumentName = 0;
	m_xRP_field_27C.nTOC_ID = 0;
	m_xRP_field_27C.dTOC_P = 0.0;
	m_xRP_field_27C.nTOC_NecessaryLights = 0;
	m_xRP_field_27C.pxTOC_preview = 0;
	m_xRP_field_27C.nTOC_RFID_Presence = 0;
	m_xRP_field_27C.sTOC_Rotated180 = m_xRP_field_27C.sTOC_RotationAngle = 0;
	m_xRP_field_27C.nTOC_CheckAuthenticity = 0;
	m_xRP_field_27C.sTOC_UVExp = 0;
	m_xRP_field_27C.sTOC_OVIExp = 0;
	m_xRP_field_27C.nTOC_AuthenticityNecessaryLights = 0;
	m_xRP_field_27C.pxTOC_FDSIDList = 0;
	m_bRP_field_1F8 = 0;
	m_bRP_field_1F9 = 1;
	m_vRP_field_0.push_back(&m_xRP_TCIDF);
	m_vRP_field_0.push_back(&m_xRP_MDF);
	m_vRP_field_0.push_back(&m_xRP_TCF);
	m_vRP_field_0.push_back(&m_xRP_IRF);
	m_vRP_field_0.push_back(&m_xRP_TSCF);
	m_vRP_field_0.push_back(&m_xRP_DOEF);
	m_vRP_field_0.push_back(&m_xRP_TFMF);
}

RecPass::~RecPass()
{

}

int RecPass::loadDocument(int nParam1, vector<uchar> & vParam2, LoadInfoStat *pLIS_Param3)
{
	StdDataStreamDirectR sdsdr(vParam2);
	if (m_vRP_field_320.size())
	{
		int v7 = 0, v8 = sdsdr.m_vSDSDR_0.size(), v9 = sdsdr.m_nSDSDR_C + 4, v10 = sdsdr.m_nSDSDR_C + 8, v11 = 0;
		if (v9 <= v8)
		{
			v11 = *(int *)&sdsdr.m_vSDSDR_0[sdsdr.m_nSDSDR_C];
		}
		sdsdr.m_nSDSDR_C += 4;
		if (v10 <= v8)
		{
			v7 = *(int *)&sdsdr.m_vSDSDR_0[v9];
		}
		sdsdr.m_nSDSDR_C = v10;
		int i, v15;
		for (i = 0; i < v7; i++)
		{
			int v13 = v10 + 4, v14 = 0;
			if (v13 <= v8)
			{
				v14 = *(int *)&sdsdr.m_vSDSDR_0[v10];
			}
			v15 = v10 + 8;
			sdsdr.m_nSDSDR_C = v13;
			if (v15 < v8)
			{
				v11 = *(int *)&sdsdr.m_vSDSDR_0[v13];
			}
			sdsdr.m_nSDSDR_C = v15;
			if (v14 == 15)
			{
				break;
			}
			v10 = v15 + v11;
			sdsdr.m_nSDSDR_C = v10;
		}
		if (i == v7)
		{
			return 0;
		}
		vector<uchar> vv(&vParam2[v15], &vParam2[v15 + v11]);
		if (!vv.size())
		{
			return 0;
		}
		TextCountryIDFilter tcidf;
		tcidf.load(nParam1, vv);
		tcidf.m_xTOCF_4.values(nParam1);
		vector<string> vstr;
		common::intersect(vstr, m_vRP_field_320);
		if (!vstr.size())
		{
			return 0;
		}

	}
	int i;
	StdDataStreamDirectR sdsdr1(vParam2);
	int v18 = sdsdr1.m_nSDSDR_C + 4, v19 = 0;
	if (v18 <= (int)sdsdr1.m_vSDSDR_0.size())
	{
		v19 = *(int *)&sdsdr1.m_vSDSDR_0[sdsdr1.m_nSDSDR_C];
	}
	int v20 = sdsdr1.m_nSDSDR_C + 8, v21 = 0;
	sdsdr1.m_nSDSDR_C += 4;
	if (v20 <= (int)sdsdr1.m_vSDSDR_0.size())
	{
		v21 = *(int *)&sdsdr1.m_vSDSDR_0[v18];
	}
	sdsdr1.m_nSDSDR_C = v20;
	for (i = 0; i < v21; i++)
	{
		int v24 = 0;
		if (sdsdr1.m_nSDSDR_C + 4 <= (int)sdsdr1.m_vSDSDR_0.size())
		{
			v24 = *(int *)&sdsdr1.m_vSDSDR_0[sdsdr1.m_nSDSDR_C];
		}
		sdsdr1.m_nSDSDR_C += 4;
		uint j;
		for (j = 0; j < m_vRP_field_0.size(); j++)
		{
			if (m_vRP_field_0[j]->type() == v24)
			{
				break;
			}
		}
		if (j == m_vRP_field_0.size())
		{
			j = -1;
		}
		int v26 = sdsdr1.m_nSDSDR_C + 4;
		if (v26 <= (int)sdsdr1.m_vSDSDR_0.size())
		{
			v19 = *(int *)&sdsdr1.m_vSDSDR_0[sdsdr1.m_nSDSDR_C];
		}
		sdsdr1.m_nSDSDR_C += 4;
		vector<uchar> vvv(vParam2.begin() + v26, vParam2.begin() + v26 + v19);
		sdsdr1.m_nSDSDR_C += v19;
		if (pLIS_Param3)
		{
			pLIS_Param3->umLIS_field_0[v24] += vvv.size();
		}
		if (j != -1)
		{
			m_vRP_field_0[j]->load(nParam1, vvv);
		}
	}

	return 0;
}

int RecPass::saveDocument(int nParam1, vector<uchar> & vParam2)
{
	vParam2.clear();
	StdDataStreamDirectW sdsd;
	sdsd.m_pSDSDW_0 = &vParam2;
	sdsd << 0;
	vector<uchar> vTemp;
	sdsd << m_vRP_field_0.size();
	for (uint i = 0; i < m_vRP_field_0.size(); i++)
	{
		sdsd << m_vRP_field_0[i]->type();
		m_vRP_field_0[i]->save(nParam1, vTemp);
		sdsd << vTemp.size();
		vParam2.insert(vParam2.end(), vTemp.begin(), vTemp.end());
	}
	string strLog1("");
	string strLog2("RecPass.dll");
	// common::log::Log<char const*>(&v11, 0, 3, &v10, "RecPass::saveDocument stop");
	return 0;
}

int RecPass::init(void * pParam1)
{
	string str1("RecPass.ini");
	string str2;
	char *pch = 0;
	int n = 0;
	
	common::resources::getFile((TResultContainerList *)pParam1, str1, (uchar**)&pch, n, str2);
		
	int res = 2;
	if (pch && n)
	{
		str1 = string(pch, n);
		if (!common::container::jsoncpp::convert(str1, m_xRP_JV))
		{
			Json::Value jv(m_xRP_JV["Main"]);
			m_xRP_IRF.m_nIRF_4 = (jv.get("identifyRectThreshold", Json::Value(70))).asInt();
			m_xRP_IRF.m_nIRF_8 = (jv.get("conflictRectThreshold", Json::Value(70))).asInt();
			m_xRP_IRF.m_nIRF_C = (jv.get("relatedRectThreshold", Json::Value(7))).asInt();
			m_nRP_field_248 = (jv.get("minSizeSide", Json::Value(30))).asInt();
			m_nRP_field_238 = (jv.get("probCheckRotateMainDoc", Json::Value(80))).asInt();
			m_nRP_field_23C = (jv.get("probCheckRotateChildDoc", Json::Value(90))).asInt();
			m_nRP_field_240 = (jv.get("probRecognClassUnknown", Json::Value(70))).asInt();
			m_nRP_field_244 = (jv.get("probthresholdLayer1", Json::Value(50))).asInt();
			int *nobj = recpass::GlobalParams::obj();
			*nobj = (jv.get("blurImageTest", Json::Value(0))).asInt();
			Json::Value jv1(m_xRP_JV["MainTeachMode"]);
			m_xRP_IRF.m_nIRF_10 = (jv1.get("isEnableST", Json::Value(0))).asInt();
			m_xRP_IRF.m_nIRF_14 = (jv1.get("stX", Json::Value(15))).asInt();
			m_xRP_IRF.m_nIRF_18 = (jv1.get("stY", Json::Value(10))).asInt();
			Json::Value jv2(m_xRP_JV["RectDebug"]);
			res = 0;
		}
	}
	return res;
}

int RecPass::recognizeOnePage(common::container::RclHolder & xRH_Param1, Json::Value & xJV_Param2, bool bParam3, common::container::RclHolder & xRH_Param4)
{
	TRecognParamsStd trps;
	recpass::getRecognParam(&xRH_Param1.m_xTRCL, xJV_Param2, trps);
	if (xRH_Param1.hasRc(98) || trps.m_strTRPS_field_18 != m_xRP_TRPS.m_strTRPS_field_18
		|| trps.m_strTRPS_field_C != m_xRP_TRPS.m_strTRPS_field_C)
	{
		m_xRP_field_27C.nTOC_CheckAuthenticity = 0;
		m_xRP_field_27C.sTOC_UVExp = 0;
		m_xRP_field_27C.sTOC_OVIExp = 0;
		m_xRP_field_27C.nTOC_AuthenticityNecessaryLights = 0;
		m_xRP_field_27C.pxTOC_FDSIDList = 0;
		m_xRP_field_27C.sTOC_Rotated180 = 0;
		m_xRP_field_27C.sTOC_RotationAngle = 0;
		m_xRP_field_27C.nTOC_NecessaryLights = 0;
		m_xRP_field_27C.pxTOC_preview = 0;
		m_xRP_field_27C.nTOC_RFID_Presence = 0;
		m_xRP_field_27C.pszTOC_DocumentName = 0;
		m_xRP_field_27C.nTOC_ID = 0;
		m_xRP_field_27C.dTOC_P = 0;
		TRecognParamsStd tmp;
		m_xRP_TRPS = tmp;
	}
	int v27 = 0;
	if (xJV_Param2.isMember("recpassParam"))
	{
		Json::Value jv = xJV_Param2["recpassParam"];
		if (jv.isMember("docID"))
		{
			v27 = jv["docID"].asInt();
		}
	}
	CMasCandidats cmc(5);
	int v28 = recognize(v27, xRH_Param1, trps, &cmc);
	if (v28 == 15 && bParam3 == false && m_xRP_field_27C.nTOC_ID)
	{
		m_xRP_field_27C.nTOC_CheckAuthenticity = 0;
		m_xRP_field_27C.sTOC_UVExp = 0;
		m_xRP_field_27C.sTOC_OVIExp = 0;
		m_xRP_field_27C.nTOC_AuthenticityNecessaryLights = 0;
		m_xRP_field_27C.pxTOC_FDSIDList = 0;
		m_xRP_field_27C.sTOC_Rotated180 = 0;
		m_xRP_field_27C.sTOC_RotationAngle = 0;
		m_xRP_field_27C.nTOC_NecessaryLights = 0;
		m_xRP_field_27C.pxTOC_preview = 0;
		m_xRP_field_27C.nTOC_RFID_Presence = 0;
		m_xRP_field_27C.pszTOC_DocumentName = 0;
		m_xRP_field_27C.nTOC_ID = 0;
		m_xRP_field_27C.dTOC_P = 0;
		v28 = recognize(v27, xRH_Param1, trps, &cmc);
	}
	if (v28 == 15)
	{
		return v28;
	}
	if (cmc.m_nCMC_field_4)
	{
		m_xRP_TRPS = trps;
		m_xRP_field_27C.nTOC_CheckAuthenticity = 0;
		m_xRP_field_27C.sTOC_UVExp = 0;
		m_xRP_field_27C.sTOC_OVIExp = 0;
		m_xRP_field_27C.nTOC_AuthenticityNecessaryLights = 0;
		m_xRP_field_27C.pxTOC_FDSIDList = 0;
		m_xRP_field_27C.sTOC_Rotated180 = 0;
		m_xRP_field_27C.sTOC_RotationAngle = 0;
		m_xRP_field_27C.nTOC_NecessaryLights = 0;
		m_xRP_field_27C.pxTOC_preview = 0;
		m_xRP_field_27C.nTOC_RFID_Presence = 0;
		m_xRP_field_27C.pszTOC_DocumentName = 0;
		m_xRP_field_27C.nTOC_ID = cmc.m_pCMC_field_8->nfield_0;
		m_xRP_field_27C.dTOC_P = cmc.m_pCMC_field_8->dbfield_8;
		m_xRP_field_27C.sTOC_Rotated180 = cmc.m_pCMC_field_8->wfield_10;
		TResultContainer v50;
		v50.nTRC_light = RPRM_Lights_0;
		v50.u1.nTRC_exposure = 0;
		v50.nTRC_list_idx = 0;
		v50.nTRC_result_type = 9;
		v50.pTRC_XML_buffer = 0;
		v50.u.pTRC_obj = &m_xRP_field_27C.pszTOC_DocumentName;
		v50.nTRC_buf_length = 4;
		v50.nTRC_page_idx = 0;
		xRH_Param4.addCopy(v50);
		int v36 = m_xRP_TCF.m_xTCF_4.getDocumentFormat(cmc.m_pCMC_field_8->nfield_0);
		if (v36 != -1)
		{
			rclhelp::documentFormatUpdate(xRH_Param4, (CDocFormat)v36);
		}
		int i;
		vector<TOneCandidate> v;
		for (i = 0; i < cmc.m_nCMC_field_4; i++)
		{
			TOneCandidate toc;
			memset(&toc, 0, sizeof(TOneCandidate));
			toc.nTOC_ID = cmc.m_pCMC_field_8[i].nfield_0;
			toc.dTOC_P = cmc.m_pCMC_field_8[i].dbfield_8;
			toc.sTOC_Rotated180 = cmc.m_pCMC_field_8[i].wfield_10;
			toc.sTOC_RotationAngle = cmc.m_pCMC_field_8[i].wfield_12;
			v.push_back(toc);
		}
		TCandidatesListContainer tclc;
		tclc.nCLC_RecResult = v28;
		tclc.nCLC_Count = v.size();
		tclc.pxCLC_Candidates = v.data();
		memset(&v50, 0, sizeof(TResultContainer));
		v50.nTRC_result_type = 8;
		v50.u.pTRC_CLC = &tclc;
		v50.nTRC_buf_length = sizeof(int);
		xRH_Param4.addCopy(v50);
	}

	return v28;
}

int RecPass::recognize(int nParam1, common::container::RclHolder & xRH_Param2, TRecognParamsStd & xTRPS_Param3, CMasCandidats * pCMC_Param4)
{
	string strFilter;
	string strLog("RecPass::recognize");
	//common::ScopeLogHelper::ScopeLogHelper()
	vector<TResultContainer *> vTRC = xRH_Param2.getRcList(71);
	if (vTRC.size())
	{
		xTRPS_Param3.m_bTRPS_field_70 = 1;
	}
	tagSIZE sz = rclhelp::imageSize(xRH_Param2.m_xTRCL);
	if (!sz.cx)
	{
		return 1;
	}
	int v10 = rclhelp::deviceTypeReal(xRH_Param2.m_xTRCL);
	int v11 = xTRPS_Param3.m_bTRPS_field_45;
	vector<int> vvv;
	if (!xTRPS_Param3.m_vTRPS_field_0.size())
	{
		if (v10)
			v11 = v10;
		if (v11)
		{
			int v245;
			vvv = rclhelp::documentFormatsFromCLMix(xRH_Param2.m_xTRCL, &v245);
			vvv.push_back(1002);
		}
	}
	else
	{
		vvv = xTRPS_Param3.m_vTRPS_field_0;
	}
	if (xTRPS_Param3.m_bTRPS_field_61)
	{
		vvv.clear();
	}
	int v240 = 0;
	sz.cx = 0;
	sz.cy = 0;
	rclhelp::imageParameters(xRH_Param2.m_xTRCL, v240, sz);
	m_xRP_IH.init(xRH_Param2, xTRPS_Param3.m_bTRPS_field_44);
	m_xRP_IH.m_bIH_field_2E = xTRPS_Param3.m_bTRPS_field_61;
	pCMC_Param4->m_nCMC_field_C = 0;
	strLog = string("RECOGNIZE");
	// common::ScopeLogHelper::AppendToLog<>()
	vector<int> vFilter;
	recpass::filters::setFiltersDocumentsFast(vFilter);
	vector<unordered_map<int, float> > vmap(2);
	int v234 = 0;
	m_xRP_IRF.m_nIRF_44 = 0;
	vTRC.clear();
	vTRC = xRH_Param2.getRcList(98);
	vector<int> v231, v236(2);
	v231.push_back(0);
	v231.push_back(1);
	if (m_xRP_field_27C.sTOC_Rotated180)
	{
		// assign 함수대신 리용한 코드임. 기능은 같다.
		v231.clear();
		v231.push_back(1);
		v231.push_back(0);
	}
	if (!vTRC.size() && (xTRPS_Param3.m_strTRPS_field_18.length() || !m_bRP_field_1F9))
	{
		v231.clear();
		v231.push_back(0);
	}
	m_xRP_IRF.m_umIRF_54.clear();
	int v209 = 0;
	uint i, j;
	for (i = 0; i < v231.size(); i++)
	{
		strLog = string("Rotate mode = %d");
		// common::ScopeLogHelper::AppendToLog<int> v231[i]
		m_xRP_IH.m_bIH_field_2D = (v231[i] ? 1 : 0);
		list<DocTypeCandidat> l;
		vector<vector<int> > vv(17); // size = 17
		int v26 = vFilter[0];
		for (j = 0; j < vFilter.size(); j++)
		{
			MainDocumentStorage *pMDS = 0;
			vector<int> vTemp;
			vector<pair<int, int> > vPair;
			string strTemp;
			unordered_map<int, float> umf;
			unordered_map<int, int> umi;
			switch (vFilter[j])
			{
			case 0:
				if (!m_xRP_field_27C.nTOC_ID)
					vTemp = rclhelp::docinfo::getUnrecognizedDocId(xRH_Param2);
				else
					vTemp.push_back(m_xRP_field_27C.nTOC_ID);
				if (!vTemp.size())
				{
					vTemp = xTRPS_Param3.m_vTRPS_field_54;
				}
				if (!vTemp.size())
				{
					pMDS = m_xRP_MDF.storage();
					vv[0] = pMDS->m_vMDS_4;
					if (xTRPS_Param3.m_strTRPS_field_48.length())
					{
						vv[0].insert(vv[0].end(), pMDS->m_vMDS_10.begin(), pMDS->m_vMDS_10.end());
					}
					v209 = 0;
				}
				else
				{
					for (uint k = 0; k < vTemp.size(); k++)
					{
						pMDS = m_xRP_MDF.storage();
						if (pMDS->contains(vTemp[k]))
						{
							vv[0].push_back(vTemp[k]);
						}
					}
					v209 = 1;
				}
				if (vv[0].size() == 1)
				{
					strLog = string("Only one candidate for recogmize = %d");
					// common::ScopeLogHelper::AppendToLog<int>
				}
				break;

			case 1:
				if (vvv.size())
				{
					vv[1] = m_xRP_TCF.m_xTCF_4.filterDocumentFormat(vv[v26], vvv);
				}
				else
				{
					vv[1] = vv[v26];
				}
				break;

			case 2:
				strTemp = xTRPS_Param3.m_strTRPS_field_18;
				if (xTRPS_Param3.m_strTRPS_field_48.length())
				{
					strTemp = xTRPS_Param3.m_strTRPS_field_48;
				}
				if (!strTemp.length())
				{
					strTemp = "!!!";
					if (xTRPS_Param3.m_strTRPS_field_C.length())
					{
						strTemp = "===";
					}
				}
				vv[2] = m_xRP_TCF.m_xTCF_4.filterByCountryCode(vv[v26], strTemp, (xTRPS_Param3.m_strTRPS_field_48.length() == 0));
				break;

			case 3:
				if (xTRPS_Param3.m_strTRPS_field_C.length())
				{
					strTemp = xTRPS_Param3.m_strTRPS_field_C;
					vv[3] = m_xRP_TCF.m_xTCF_4.filterByDocumentClass(vv[v26], strTemp);
				}
				else
				{
					vv[3] = vv[v26];
				}
				break;

			case 6:
				if (!m_xRP_field_27C.nTOC_ID)
				{
					for (uint k = 0; k < vv[v26].size(); k++)
					{
						IdentifyRectDoc ird = m_xRP_IRF.m_umIRF_1C[vv[v26][k]];
						for (set<int>::iterator iter = ird.m_sIRD_0.begin(); iter != ird.m_sIRD_0.end(); iter++)
						{
							if (m_xRP_IRF.m_xIRF_68.getExistDocument(*iter))
							{
								if (l.size())
								{
									int c = 0;
									list<DocTypeCandidat>::iterator liter;
									for (liter = l.begin(); liter != l.end(); liter++)
									{
										if ((*liter).nDTC_type_field_0 == *iter)
											break;
										c++;
									}
									if (c == l.size())
										continue;
									if (c <= 99 && (*liter).fDTC_value_field_4 > 0.0001)
									{
										if (!common::contains(vPair, pair<int, int>(vv[v26][k], *iter)))
										{
											vPair.push_back(pair<int, int>(vv[v26][k], *iter));
										}
									}
								}
								else
								{
									uint c;
									for (c = 0; c < vv[3].size(); c++)
									{
										if (vv[3][c] == *iter)
											break;
									}
									if (c != vv[3].size())
									{
										if (!common::contains(vPair, pair<int, int>(vv[v26][k], *iter)))
										{
											vPair.push_back(pair<int, int>(vv[v26][k], *iter));
										}
									}
								}
							}
						}
					}
					if (vPair.size())
					{
						strLog = string("add related by conflicts rects = %d");
						// common::ScopeLogHelper::AppendToLog<unsigned int> vPair.size()
					}
				}
				strLog = string("docIds request = %d");
				// common::ScopeLogHelper::AppendToLog<unsigned int> vv[v26].size()
				vTemp = vv[v26];
				for (uint k = 0; k < vPair.size(); k++)
				{
					vTemp.push_back(vPair[k].second);
				}
				umi = m_xRP_TCF.m_xTCF_4.getDocumentFormat(vTemp);
				vTemp.clear();
				m_xRP_IRF.filter(vv[v26], vPair, m_xRP_IH, umf, vTemp, umi, nParam1);
				vv[6] = common::mapKeys(umf);
				common::unit(vv[7], vTemp);
				for (unordered_map<int, float>::iterator umiter = umf.begin(); umiter != umf.end(); umiter++)
				{
					vmap[v231[i]][(*umiter).first] = (*umiter).second;
				}
				strLog = "finish check rects";
				// common::ScopeLogHelper::AppendToLog<> strLog
				break;

			case 9:
				if (xTRPS_Param3.m_strTRPS_field_24.length())
				{
					vv[9] = m_xRP_TSCF.m_xTOCF_4.filterByValue(vv[v26], xTRPS_Param3.m_strTRPS_field_24);
				}
				else
				{
					vv[9] = vv[v26];
				}
				break;

			case 13:
				if (m_bRP_field_24C && !v209 && xTRPS_Param3.m_bTRPS_field_71 &&
					!xTRPS_Param3.m_strTRPS_field_18.length() && !xTRPS_Param3.m_strTRPS_field_C.length() &&
					vv[v26].size() >= 20 && !xTRPS_Param3.m_strTRPS_field_48.length())
				{
					strLog = "DNN variant";
					// common::ScopeLogHelper::AppendToLog<>
					Mat m = common::container::wrapByMat(xRH_Param2, regula::light::whiteAndIrGroup());
					if (!m.empty())
					{
						Mat mTemp;
						flip(m, mTemp, v231[i]);
						m_xRP_DTR.process(mTemp, l);
					}
					if (xTRPS_Param3.m_bTRPS_field_70)
					{
						static set<int> s631D70A8;
						if (!s631D70A8.size())
						{
							vector<int> knownIDs = m_xRP_DTR.getKnownIDs();
							for (uint k = 0; k < knownIDs.size(); k++)
							{
								s631D70A8.insert(s631D70A8.begin(), knownIDs[k]);
							}
						}
						set<int> sTemp;
						for (uint k = 0; k < vv[v26].size(); k++)
						{
							sTemp.insert(sTemp.begin(), vv[13][k]);
						}
						vector<int> diff(sTemp.size() + s631D70A8.size());
						vector<int>::iterator iend = set_difference(sTemp.begin(), sTemp.end(), s631D70A8.begin(), s631D70A8.end(), diff.begin());
						diff.erase(iend, diff.end());
						if (diff.size())
						{
							strLog = "DNN unknown doc number = %d";
							// common::ScopeLogHelper::AppendToLog<unsigned int> diff.size()
						}
					}
					int n53 = l.size();
					if (n53 >= 10)
					{
						n53 = 10;
					}
					if (nParam1)
					{
						list<DocTypeCandidat>::iterator liter;
						for (liter = l.begin(); liter != l.end(); liter++)
						{
							if ((*liter).nDTC_type_field_0 == nParam1)
								break;
						}
						if (liter != l.end())
						{
							strLog = "DNN filter info : currPos = %d, currProb = %f, maxIdx = %d, minProb = %f";
							// common::ScopeLogHelper::AppendToLog<int,float,unsigned int,float> (*liter).fDTC_value_field_4 n53
						}
					}
					list<DocTypeCandidat>::iterator liter = l.begin();
					for (int k = 0; k < n53; k++, liter++)
					{
						if ((*liter).fDTC_value_field_4 < 0.0001)
							break;
						if (common::contains(vv[v26], (*liter).nDTC_type_field_0))
						{
							vTemp.push_back((*liter).nDTC_type_field_0);
						}
					}
					for (uint k = 0; k < xTRPS_Param3.m_vTRPS_field_64.size(); k++)
					{
						uint t;
						for (t = 0; t < vTemp.size(); t++)
						{
							if (vTemp[t] == xTRPS_Param3.m_vTRPS_field_64[k])
								break;
						}
						if (t == vTemp.size())
						{
							for (t = 0; t < vv[v26].size(); t++)
							{
								if (vv[v26][t] == xTRPS_Param3.m_vTRPS_field_64[k])
									break;
							}
							if (t != vv[13].size())
							{
								vTemp.push_back(xTRPS_Param3.m_vTRPS_field_64[k]);
							}
						}
					}
					vv[13] = vTemp;
				}
				else
				{
					vv[13] = vv[v26];
				}
				break;

			case 14:
				vv[14] = m_xRP_DOEF.m_xI2CF_4.filterByValue(vv[v26], xTRPS_Param3.m_nTRPS_field_40);
				break;

			case 16:
				if (xTRPS_Param3.m_strTRPS_field_30.length())
				{
					vv[16] = m_xRP_TFMF.m_xTFMF_28.filterByValue(vv[v26], xTRPS_Param3.m_strTRPS_field_30);
				}
				else
				{
					vv[16] = vv[v26];
				}
				break;

			default:
				vv[vFilter[j]] = vv[v26];
				break;
			}
			uint k;
			for (k = 0; k < vv[vFilter[j]].size(); k++)
			{
				if (vv[vFilter[j]][k] == nParam1)
				{
					pCMC_Param4->m_nCMC_field_C = 0;
					break;
				}
			}
			if (k == vv[vFilter[j]].size() && !pCMC_Param4->m_nCMC_field_C)
				pCMC_Param4->m_nCMC_field_C = vFilter[j];
			strLog = "%d - %d = %d - Document Filter \"%s\"";
			strFilter = filterName(eDocumentFilterClass(vFilter[j]));
			// common::ScopeLogHelper::AppendToLog<unsigned int, unsigned int, unsigned int, char const*> strFilter
			if (nParam1)
			{
				strLog = "currPos = %d";
				// common::ScopeLogHelper::AppendToLog<int>
			}
			v26 = vFilter[j];
			if (m_xRP_IRF.m_nIRF_44)
				v234 = m_xRP_IRF.m_nIRF_44;
			if (!vv[vFilter[j]].size())
			{
				break;
			}
		}
		if (vmap[v231[i]].size())
		{
			vector<float> vm = common::mapValues(vmap[v231[i]]);
			sort(vm.begin(), vm.end(), greater<float>());
			v236[v231[i]] = (int)(vm[0] * 100);
		}
		strLog = "Prob for this rotate mode = %d";
		// common::ScopeLogHelper::AppendToLog<int> v236[v231[i]]
		int v143 = m_nRP_field_238;
		if (v209)
			v143 = m_nRP_field_23C;
		if (m_xRP_field_27C.nTOC_ID)
		{
			if (v143 > (int)(m_xRP_field_27C.dTOC_P * 0.980000019 * 100.0))
				v143 = (int)(m_xRP_field_27C.dTOC_P * 0.980000019 * 100.0);
		}
		if (v236[v231[i]] > v143)
			break;
	}
	int v146 = 0;
	if (v236[0] <= v236[1])
		v146 = 1;
	unordered_map<int, float> umTemp(vmap[v146]);
	if (nParam1)
	{
		IdentifyRectDoc ird = m_xRP_IRF.m_umIRF_30[nParam1];
		vector<int> vTemp(ird.m_sIRD_0.begin(), ird.m_sIRD_0.end());
		for (i = 0; i < vTemp.size(); i++)
		{
			if (umTemp.find(vTemp[i]) == umTemp.end())
			{
				umTemp[vTemp[i]] = 0.0;
			}
		}
		if (v234)
		{
			umTemp[v234] = 0.01f;
		}
	}
	vector<int> vTemp = common::mapKeys(umTemp);
	vector<pair<float, int> > vpTemp;
	for (i = 0; i < vTemp.size(); i++)
	{
		vpTemp.push_back(pair<float, int>(umTemp[vTemp[i]], vTemp[i]));
	}
	sort(vpTemp.begin(), vpTemp.end(), greater<pair<float, int> >());
	if (!xTRPS_Param3.m_bTRPS_field_71)
	{
		for (i = 0; i < vpTemp.size(); i++)
		{
			if (vpTemp[i].first < 0.69)
				break;
			string strTemp("test with dnn Off: docId = %d, prob = %f");
			// common::ScopeLogHelper::AppendToLog<int,float> vpTemp[i].second, vpTemp[i].first
		}
	}
	for (i = 0; i < vpTemp.size(); i++)
	{
		if (i >= (uint)pCMC_Param4->m_nCMC_field_0)
			break;
		if (!nParam1 && vpTemp[i].first < 0.6)
			break;
		pCMC_Param4->m_pCMC_field_8[i].dbfield_8 = vpTemp[i].first;
		pCMC_Param4->m_pCMC_field_8[i].nfield_0 = vpTemp[i].second;
		pCMC_Param4->m_pCMC_field_8[i].wfield_10 = v146;
		pCMC_Param4->m_nCMC_field_4 = (i + 1);
	}
	int res = 15;
	if (pCMC_Param4->m_nCMC_field_4)
	{
		if (pCMC_Param4->m_pCMC_field_8[0].dbfield_8 * 100.0 >= m_nRP_field_240)
		{
			if (m_xRP_IRF.m_sIRF_48.find(29) != m_xRP_IRF.m_sIRF_48.end())
				res = 29;
			else
				res = 0;
			if (!xTRPS_Param3.m_bTRPS_field_44 && pCMC_Param4->m_nCMC_field_4)
			{
				int nDocFmt = m_xRP_TCF.m_xTCF_4.getDocumentFormat(pCMC_Param4->m_pCMC_field_8[0].nfield_0);
				IdentifyRectDocument *pIRD = dynamic_cast<IdentifyRectDocument *>(m_xRP_IRF.m_xIRF_68.getExistDocument(pCMC_Param4->m_pCMC_field_8[0].nfield_0));
				if (xTRPS_Param3.m_bTRPS_field_60)
				{
					tagRECT r = { 0 };
					DpiInfo di = m_xRP_IRF.info(pCMC_Param4->m_pCMC_field_8[0].nfield_0);
					recpass::getROIByElementsAnalyze(*pIRD, di, r);
					Rect cvr = rcvmat::RCVRect::fromDib(r);
					int v176 = cvr.x + cvr.width, v177 = (cvr.x < 0) ? 0 : cvr.x, v178 = cvr.y + cvr.height, v5 = (cvr.y < 0) ? 0 : cvr.y;
					if (v178 > sz.cy)
						v178 = sz.cy;
					int v179 = v178 - v5;
					int v180 = 0;
					if (v179 < 1)
						v180 = 1;
					if (sz.cx < v176)
						v176 = sz.cx;
					int v181 = v176 - v177;
					int v182 = 0;
					if (v181 < 1)
						v182 = 1;
					int v183 = v180 | v182;
					if (v183)
					{
						v177 = 0;
						v5 = 0;
						v181 = 0;
						v179 = 0;
					}
					Rect cvr1;
					cvr1.x = v177;
					cvr1.y = v5;
					cvr1.width = v181;
					cvr1.height = v179;
					if (cvr.width == v181 && cvr.height == v179)
					{
						tagRECT rr = rcvmat::RCVRect::regRect(cvr1);
						common::images::CropImage(xRH_Param2.m_xTRCL, rr);
					}
					else
					{
						res = 15;
						pCMC_Param4->m_nCMC_field_4 = 0;
					}
				}
				if (pCMC_Param4->m_nCMC_field_4)
				{
					Size2f cvsz;
					if ((nDocFmt | 2) == 1002 && pIRD)
						cvsz = pIRD->m_xIRD_24;
					rclhelp::updateCLByDocumentFormat(xRH_Param2, (CDocFormat)nDocFmt, cvsz);
					if (pIRD)
					{
						DpiInfo di = m_xRP_IRF.info(pCMC_Param4->m_pCMC_field_8[0].nfield_0);
						if (di.nDI_0)
						{
							rclhelp::setResolution(xRH_Param2.m_xTRCL, di.nDI_0);
							string strTemp("Update PPI by RECTS = %d");
							// common::ScopeLogHelper::AppendToLog<int> di.nDI_0
						}
						else if (di.nDI_4)
						{
							rclhelp::setResolution(xRH_Param2.m_xTRCL, di.nDI_4);
							string strTemp("Update PPI by docSize = %d");
							// common::ScopeLogHelper::AppendToLog<int> di.nDI_4
						}
					}
				}
			}
		}
	}
	if (!rclhelp::imageResolution(xRH_Param2.m_xTRCL))
		rclhelp::setResolution(xRH_Param2.m_xTRCL, 0);
	if (pCMC_Param4->m_nCMC_field_4)
	{
		string strTemp("Recognize status = %d, Doc type = %d  prob = %f output image res = %d");
		// common::ScopeLogHelper::AppendToLog<int,int,double,int>
	}
	else
	{
		string strTemp("Recognize status = %d");
		// common::ScopeLogHelper::AppendToLog<int>
	}
	return res;
}

RecPassExternal::RecPassExternal()
{

}

RecPassExternal::~RecPassExternal()
{

}

vector<int> RecPassExternal::getCommands()
{
	static vector<int> v = { 0xCD, 0xCE, 0x9C5, 0x9CD, 0x9C6, 0x9C7, 0x9CA, 0x9C8, 0x9C9, 0x9CB, 0x9CC, 0x9CE, 0x2FAD, 0x2FB1, 0x2FB2 };
	
	return v;
}

int RecPassExternal::process(int nParam1, void * pParam2, const char * pParam3, void ** pParam4, char ** pParam5)
{
	TResultContainerList *pTRCL = (TResultContainerList *)pParam2;
	common::container::RclHolder rh1(pTRCL, 1);
	vector<TResultContainer *> vv;
	Json::Value jv(Json::json_type_null);
	int res = 1;
	string strTemp, strTemp1;
	MainDocumentStorage *pMDS = 0;

	switch (nParam1)
	{
	case 0xCD:
	case 0x9C5:
		res = init(pParam2);
		if (!res)
		{
			pMDS = m_xRP_MDF.storage();
			if (!pMDS->m_vMDS_4.size() && !pMDS->m_vMDS_10.size())
			{
				string strTemp;
				uchar *pC = 0;
				int n = 0;

				common::resources::getFile(pTRCL, string("RecPass.dat"), &pC, n, strTemp);
				if (pC && n)
				{
					CMemBufer cmb;
					cmb.nCMB_field_0 = n;
					cmb.nCMB_field_4 = n;
					cmb.nCMB_field_8 = 0;
					cmb.pCMB_data_field_C = pC;
					exchange_SetDataAllDocuments(&cmb);
				}
			}
			if (!m_xRP_DTR.isLoaded())
			{
				string strTemp;
				uchar *pC = 0;
				int n = 0;

				common::resources::getFile(pTRCL, string("RecPass.dnn"), &pC, n, strTemp);
				if (pC && n)
				{
					CMemBufer cmb;
					cmb.nCMB_field_0 = n;
					cmb.nCMB_field_4 = n;
					cmb.nCMB_field_8 = 0;
					cmb.pCMB_data_field_C = pC;
					exchange_SetDataDNN(&cmb);
				}
			}
		}
		break;
	case 0x9C6:
		vv = rh1.getRcList(64);
		if (!vv.size() || !vv[0]->u.pTRC_obj || !vv[0]->nTRC_buf_length)
		{
			res = 2;
		}
		else
		{
			CMemBufer cmb;
			cmb.nCMB_field_0 = vv[0]->nTRC_buf_length;
			cmb.nCMB_field_4 = vv[0]->nTRC_buf_length;
			cmb.nCMB_field_8 = 0;
			cmb.pCMB_data_field_C = vv[0]->u.pTRC_UCHAR;
			exchange_SetDataAllDocuments(&cmb);
			res = 0;
		}
		break;

	case 0x9C7:
		break;

	case 0x9C8:
		m_xRP_field_27C.pszTOC_DocumentName = 0;
		m_xRP_field_27C.nTOC_ID = 0;
		m_xRP_field_27C.dTOC_P = 0.0;
		m_xRP_field_27C.sTOC_Rotated180 = 0;
		m_xRP_field_27C.sTOC_RotationAngle = 0;
		m_xRP_field_27C.nTOC_NecessaryLights = 0;
		m_xRP_field_27C.pxTOC_preview = 0;
		m_xRP_field_27C.nTOC_RFID_Presence = 0;
		m_xRP_field_27C.nTOC_CheckAuthenticity = 0;
		m_xRP_field_27C.sTOC_UVExp = 0;
		m_xRP_field_27C.sTOC_OVIExp = 0;
		m_xRP_field_27C.nTOC_AuthenticityNecessaryLights = 0;

		m_xRP_field_27C.pxTOC_FDSIDList = 0;
		res = process_RecDoc(pParam2, (char*)pParam3, pParam4, 0);
		break;

	case 0x9C9:
		res = process_RecDoc(pParam2, (char*)pParam3, pParam4, 1);
		break;

	case 0x9CA:
		vv = rh1.getRcList(64);
		if (!vv.size() || !vv[0]->u.pTRC_obj || !vv[0]->nTRC_buf_length)
		{
			res = 2;
		}
		else
		{
			CMemBufer cmb;
			cmb.nCMB_field_0 = vv[0]->nTRC_buf_length;
			cmb.nCMB_field_4 = vv[0]->nTRC_buf_length;
			cmb.nCMB_field_8 = 0;
			cmb.pCMB_data_field_C = vv[0]->u.pTRC_UCHAR;
			exchange_SetDataDNN(&cmb);
			res = 0;
		}
		break;

	case 0x9CB:
		if (!pParam3 || common::container::jsoncpp::convert(string(pParam3), jv))
		{
			res = 2;
		}
		else
		{
			m_vRP_field_320 = common::StringUtils::Split(jv["recpass"]["countryFilter"].asString(), ',');
			res = 0;
		}
		break;

	case 0x9CC:
		res = 0;
		if (!pParam3)
		{
			break;
		}
		common::container::jsoncpp::convert(string(pParam3), jv);
		if (jv.isMember("rotate180"))
		{
			m_bRP_field_1F9 = jv["rotate180"].asBool();
		}
		if (!jv.isMember("docId") || !jv.isMember("filterMask"))
		{
			break;
		}
		strTemp = jv.get("filterMask", Json::Value("")).asString();
		if (strTemp.length())
		{
			m_xRP_TFMF.m_xTFMF_28.updateValue(jv["docId"].asInt(), strTemp);
		}
		break;

	case 0xCE:
	case 0x9CD:
		for (uint i = 0; i < m_vRP_field_0.size(); i++)
		{
			m_vRP_field_0[i]->clearAll();
		}
		res = 0;
		break;

	case 0x9CE:
		pMDS = m_xRP_MDF.storage();
		vv = rh1.getRcList(3);
		if (vv.size() && vv[0]->u.pTRC_DVEI)
		{
			strTemp = common::textdoc::getValue(*vv[0]->u.pTRC_DVEI, VisualFieldType_1);
			strTemp1 = common::textdoc::getValue(*vv[0]->u.pTRC_DVEI, VisualFieldType_0);
		}
		if (!strTemp.length())
		{
			if (strTemp1.length())
				strTemp = "===";
			else
				strTemp = "!!!";
		}
		if (m_xRP_TCF.m_xTCF_4.filterByDocumentClass(m_xRP_TCF.m_xTCF_4.filterByCountryCode(pMDS->m_vMDS_4, strTemp, 1), strTemp1).size())
			res = 0;
		else
			res = 2;
		break;

	case 0x2FAD:
	case 0x2FB1:
		m_xRP_field_27C.pszTOC_DocumentName = 0;
		m_xRP_field_27C.nTOC_ID = 0;
		m_xRP_field_27C.dTOC_P = 0.0;
		m_xRP_field_27C.sTOC_Rotated180 = 0;
		m_xRP_field_27C.sTOC_RotationAngle = 0;
		m_xRP_field_27C.nTOC_NecessaryLights = 0;
		m_xRP_field_27C.pxTOC_preview = 0;
		m_xRP_field_27C.nTOC_RFID_Presence = 0;
		m_xRP_field_27C.nTOC_CheckAuthenticity = 0;
		m_xRP_field_27C.sTOC_UVExp = 0;
		m_xRP_field_27C.sTOC_OVIExp = 0;
		m_xRP_field_27C.nTOC_AuthenticityNecessaryLights = 0;
		m_xRP_field_27C.pxTOC_FDSIDList = 0;
		res = 0;
		break;
	default:
		break;
	}

	return res;
}

int RecPassExternal::process_RecDoc(void * pParam1, char * pParam2, void ** pParam3, bool bParam4)
{
	m_xRP_RH.clear();
	if (pParam3)
		*((TResultContainerList **)pParam3) = &m_xRP_RH.m_xTRCL;
	TResultContainerList *pTRCL = (TResultContainerList *)pParam1;
	common::container::RclHolder rh(pTRCL, 1);
	Json::Value jv = rclhelp::getProcessParams(rh, (char const *)pParam2);
	vector<int> vTemp;
	vTemp.push_back(98);
	vector<shared_ptr<common::container::RclHolder> > vsTemp = rclhelp::splitByContainerType(rh, vTemp);  //vTemp에 의한 려과
	vector<shared_ptr<common::container::RclHolder> > vs = rclhelp::splitByPage(*vsTemp[1]); //
	vector<shared_ptr<common::container::RclHolder> > vss;
	for (uint i = 0; i < vs.size(); i++)
	{
		vector<TResultContainer *> vTRC = vs[i]->getRcList(1);
		if (vTRC.size())
		{
			vss.push_back(vs[i]);
		}
	}
	if (vss.size() > 1)
	{
		TResultContainer *pTRC = rclhelp::findFirstContainer(&rh.m_xTRCL, 3);
		if (pTRC && pTRC->nTRC_page_idx)
		{
			for (uint i = 0; i < vss.size() - 1; i++)
			{
				if (rclhelp::getPage(vss[i]->m_xTRCL) == pTRC->nTRC_page_idx)
				{
					shared_ptr<common::container::RclHolder> s = vss[0];
					vss[0] = vss[i + 1];
					vss[i + 1] = s;
					break;
				}
			}
		}
	}
	vector<bool> vbool(vss.size(), 0);
	common::container::RclHolder rh1;
	int n30;
	int n39 = 0, n41 = 0;
	int res = 0;
	for (uint i = 0; i < vss.size(); i++)
	{
		if (vbool[i])
		{
			n30 = i;
			continue;
		}
		int n32 = rclhelp::getPage(vss[i].get()->m_xTRCL);
		if (rh1.empty())
		{
			vector<TResultContainer *> vTRC = vss[i]->getRcList(98);
			if (!vTRC.size())
			{
				if (!vsTemp[0].get()->empty())
				{
					vss[i].get()->addNoCopy(*(vsTemp[0].get()));
				}
			}
		}
		else
		{
			vss[i].get()->remove(98);
			vss[i].get()->addNoCopy(rh1);
		}
		common::container::RclHolder rh2;
		res = recognizeOnePage(*vss[i].get(), jv, bParam4, rh2);
		vector<int> vDocIds = rclhelp::getDocIds(rh2);
		if (vDocIds.size())
		{
			rh2.setPageIndex(n32);
			m_xRP_RH.addCopy(rh2.m_xTRCL);
			if (vss.size() >= 2)
			{
				if (n39)
				{
					rclhelp::docinfo::updateMainDocumentInfo(rh1, m_xRP_RH);
				}
				else
				{
					if (i)
						n41 = 1;
					n39 = vDocIds[0];
					vector<int> vcdoc;
					rclhelp::docdesc::getChildDocList(vDocIds[0], vcdoc);
					rclhelp::docinfo::addMainDocumentInfo(rh1, m_xRP_RH, vcdoc);
				}
			}
			if (n39)
				vbool[i] = 1;
			else
				n39 = 0;
			int n31 = i;
			if (n41 & 1)
				n31 = -1;
			int n37 = i - (vss.size() - 1);
			if (n37)
			{
				n31 = i;
				n37 = 1;
			}
			n41 &= n37;
			i = n31;
		}
	}
	return res;
}

int RecPassExternal::exchange_SetData(int nParam1, CMemBufer *pCMB_Param2, LoadInfoStat *pLIS_Param3)
{
	bool bRes;
	int n = *(int *)pCMB_Param2->pCMB_data_field_C;
	if (pCMB_Param2->nCMB_field_4 < 4 || n != 706)
	{
		bRes = 1;
	}
	else
	{
		vector<uchar> v;
		v.insert(v.begin(), pCMB_Param2->pCMB_data_field_C + 4, pCMB_Param2->pCMB_data_field_C + pCMB_Param2->nCMB_field_4);
		if (!v.size())
		{
			bRes = 1;
		}
		else
		{
			loadDocument(nParam1, v, pLIS_Param3);
			bRes = 0;
		}
	}
	return bRes;
}

int RecPassExternal::exchange_SetDataAllDocuments(CMemBufer *pCMB_Param)
{
	LoadInfoStat lis;
	int index = 0;
	while (index < pCMB_Param->nCMB_field_4 - 4)
	{
		int n = *(int *)&pCMB_Param->pCMB_data_field_C[index];
		int m = *(int *)&pCMB_Param->pCMB_data_field_C[index + 4];
		CMemBufer cmb = { 0 };
		cmb.nCMB_field_4 = m;
		cmb.pCMB_data_field_C = &pCMB_Param->pCMB_data_field_C[index + 8];
		exchange_SetData(n, &cmb, &lis);
		index += (m + 8);
	}
	m_xRP_IRF.updateConflictRelation();
	return 0;
}

int RecPassExternal::exchange_SetDataDNN(CMemBufer *pCMB_Param)
{
	// 다시 고려할것.
	string data((char *)pCMB_Param->pCMB_data_field_C, pCMB_Param->nCMB_field_4);
	istringstream biss(data, ios_base::binary);
	cv::dnn::DnnReader dr;
	dr.m_pDR_istream = &biss;
	m_xRP_DTR.io_generic(dr);
	m_bRP_field_24C = 1;
	return 0;
}