#include "IdentifyRect.h"
#include "../RCv.h"
#include "RecPass.h"
#include "StdDataStreamDirect.h"
#include "serialization32.h"
#include "../common/common.h"

using namespace recpass::IdentifyRectSearchM;

IdentifyRectDocumentStorage::IdentifyRectDocumentStorage()
{
}

IdentifyRectDocumentStorage::~IdentifyRectDocumentStorage()
{
}

IdentifyRectDocument * IdentifyRectDocumentStorage::create()
{
	IdentifyRectDocument * pIRD = new IdentifyRectDocument;
	return pIRD;
}

void IdentifyRectDocumentStorage::remove(_IDocument * a2)
{
	if (a2)
	{
		delete a2;
	}
}

IdentifyRectDocument::~IdentifyRectDocument()
{
}

void IdentifyRectDocument::clear()
{
	m_xIRD_4.m_vIRA_0.clear();
	m_vIRD_2C.clear();
}

void IdentifyRectDocument::filterRects(vector<int>& a2, vector<IdentifyKit>& a3)
{
	if (!m_vIRD_2C.empty() && !m_vIRD_2C[0].first.size.p[1])
	{
		for (size_t i = 0; i < m_vIRD_38.size(); i++)
		{
			cv::imdecode(m_vIRD_38[i], 0x80, &m_vIRD_2C[i].first);
		}
		m_vIRD_38.clear();
	}

	a3.resize(a2.size());

	for (size_t i = 0; i < a2.size(); i++)
	{
		a3[i].m_pIK_0 = &m_vIRD_2C[a2[i]].first;
		a3[i].m_pIK_4 = 0;
		a3[i].m_pIK_8 = &m_vIRD_44[a2[i]];
	}
}

void IdentifyRectDocument::getResolution(vector<int>& a2, vector<int>& a3)
{
	a3.resize(a2.size());

	for (size_t i = 0; i < a2.size(); i++)
	{
		a3[i] = m_vIRD_2C[a2[i]].second;
	}
}

SearchInfo * IdentifyRectDocument::searchInfo(void)
{
	static SearchInfo searchInfo;
	return &searchInfo;
}

void IdentifyRectDocument::setRectNumber(int a2)
{
	m_vIRD_2C.clear();
	m_vIRD_2C.resize(a2);
	m_vIRD_44.resize(a2);
}

void IdentifyRectDocument::getConflictDocIds(vector<int>& a2)
{
	a2.clear();

	for (size_t i = 0; i < m_xIRD_4.m_vIRA_0.size(); i++)
	{
		for (int j = 0; j < m_xIRD_4.m_vIRA_0[i].m_xCIRF2_0.struc_367_24; j++)
		{
			if (!common::contains(a2, m_xIRD_4.m_vIRA_0[i].m_pCIRF2_2C[j].struc_368_0))
			{
				a2.push_back(m_xIRD_4.m_vIRA_0[i].m_pCIRF2_2C[j].struc_368_0);
			}
		}
	}
}

IdentifyRectResult::IdentifyRectResult()
	: m_rIRR_0(0.0f)
{
}

IdentifyRectResult::IdentifyRectResult(IdentifyRectResult const & a2)
{
	m_rIRR_0 = a2.m_rIRR_0;
	m_xIRR_4 = a2.m_xIRR_4;
}

CImageRectFinal2::CImageRectFinal2()
{
	memset(this, 0, sizeof(CImageRectFinal2));
}

IdentifyRectDoc::IdentifyRectDoc()
{

}

IdentifyRectDoc::IdentifyRectDoc(IdentifyRectDoc const & a2)
	: m_sIRD_0(a2.m_sIRD_0)
{
}

IdentifyRectFilter::IdentifyRectFilter()
	: m_nIRF_4(70), m_nIRF_8(70), m_nIRF_10(0),
	m_nIRF_14(0), m_nIRF_18(0), m_nIRF_44(0)
{
}

IdentifyRectFilter::~IdentifyRectFilter()
{
}

int IdentifyRectFilter::type()
{
	return 6;
}

void IdentifyRectFilter::save(int a2, vector<uchar>& a3)
{

}

void IdentifyRectFilter::load(int a2, vector<uchar>& a3)
{
	if (!a3.empty())
	{
		IdentifyRectDocument * p7 = dynamic_cast<IdentifyRectDocument *>(storage()->getDocument(a2));

		if (p7)
		{
			StdDataStreamDirectR xSDSDR(a3);

			if (xSDSDR.m_nSDSDR_C + 4 <= (int)xSDSDR.m_vSDSDR_0.size())
			{
				p7->m_nIRD_10 = *(int*)(xSDSDR.m_vSDSDR_0.data() + xSDSDR.m_nSDSDR_C);
			}
			xSDSDR.m_nSDSDR_C += 4;

			if (xSDSDR.m_nSDSDR_C + 4 <= (int)xSDSDR.m_vSDSDR_0.size())
			{
				p7->m_nIRD_14 = *(int*)(xSDSDR.m_vSDSDR_0.data() + xSDSDR.m_nSDSDR_C);
			}
			xSDSDR.m_nSDSDR_C += 4;

			if (xSDSDR.m_nSDSDR_C + 4 <= (int)xSDSDR.m_vSDSDR_0.size())
			{
				p7->m_nIRD_18 = *(int*)(xSDSDR.m_vSDSDR_0.data() + xSDSDR.m_nSDSDR_C);
			}
			xSDSDR.m_nSDSDR_C += 4;

			if (xSDSDR.m_nSDSDR_C + 4 <= (int)xSDSDR.m_vSDSDR_0.size())
			{
				p7->m_nIRD_1C = *(int*)(xSDSDR.m_vSDSDR_0.data() + xSDSDR.m_nSDSDR_C);
			}
			xSDSDR.m_nSDSDR_C += 4;

			if (m_nIRF_10)
			{
				p7->m_nIRD_18 = m_nIRF_14;
				p7->m_nIRD_1C = m_nIRF_18;
			}

			if (xSDSDR.m_nSDSDR_C + 4 <= (int)xSDSDR.m_vSDSDR_0.size())
			{
				p7->m_nIRD_20 = *(int*)(xSDSDR.m_vSDSDR_0.data() + xSDSDR.m_nSDSDR_C);
			}
			xSDSDR.m_nSDSDR_C += 4;

			int n16;

			if (xSDSDR.m_nSDSDR_C + 4 >(int)xSDSDR.m_vSDSDR_0.size())
			{
				n16 = 0;
			}
			else
			{
				n16 = *(int*)(xSDSDR.m_vSDSDR_0.data() + xSDSDR.m_nSDSDR_C);
			}
			xSDSDR.m_nSDSDR_C += 4;

			p7->setRectNumber(n16);

			p7->m_xIRD_4.m_vIRA_0.resize(n16);

			int i = 0;

			for (i = 0; i < n16; i++)
			{
				int n38 = 0;
				CImageRectFinal xCIRF;
				memset(&xCIRF, 0, sizeof(CImageRectFinal));
				serialization32::deserialize(a3.data() + xSDSDR.m_nSDSDR_C, xCIRF, &n38);
				memcpy(&p7->m_xIRD_4.m_vIRA_0[i], &xCIRF, sizeof(CImageRectFinal));
				xSDSDR.m_nSDSDR_C += n38;
			}

			p7->m_vIRD_2C.resize(n16);
			p7->m_vIRD_38.resize(n16);

			for (i = 0; i < n16; i++)
			{
				if (xSDSDR.m_nSDSDR_C + 4 <= (int)xSDSDR.m_vSDSDR_0.size())
				{
					p7->m_vIRD_2C[i].second = *(int*)(xSDSDR.m_vSDSDR_0.data() + xSDSDR.m_nSDSDR_C);
				}
				xSDSDR.m_nSDSDR_C += 12;

				int n27;

				if (xSDSDR.m_nSDSDR_C + 4 >(int)xSDSDR.m_vSDSDR_0.size())
				{
					n27 = 0;
				}
				else
				{
					n27 = *(int*)(xSDSDR.m_vSDSDR_0.data() + xSDSDR.m_nSDSDR_C);
				}

				xSDSDR.m_nSDSDR_C += 4;

				p7->m_vIRD_38[i] = vector<uchar>(a3.begin() + xSDSDR.m_nSDSDR_C, a3.begin() + xSDSDR.m_nSDSDR_C + n27);

				xSDSDR.m_nSDSDR_C += n27;
			}

			p7->m_xIRD_24.width = 0.0;
			p7->m_xIRD_24.height = 0.0;

			int n33 = 0;

			if (xSDSDR.m_nSDSDR_C + 4 <= (int)xSDSDR.m_vSDSDR_0.size())
			{
				n33 = *(int*)(xSDSDR.m_vSDSDR_0.data() + xSDSDR.m_nSDSDR_C);
				if (n33)
					p7->m_xIRD_24.width = n33 / 1000.0f;
			}
			xSDSDR.m_nSDSDR_C += 4;

			if (xSDSDR.m_nSDSDR_C + 4 <= (int)xSDSDR.m_vSDSDR_0.size())
			{
				n33 = *(int*)(xSDSDR.m_vSDSDR_0.data() + xSDSDR.m_nSDSDR_C);
			}

			xSDSDR.m_nSDSDR_C += 4;

			if (n33)
			{
				p7->m_xIRD_24.height = n33 / 1000.0f;
			}
		}
	}
}

void IdentifyRectFilter::clear(int a2)
{
	IdentifyRectDocument *pIRD = dynamic_cast<IdentifyRectDocument *>(storage()->getDocument(a2));

	if (pIRD)
	{
		pIRD->clear();
	}
}

void IdentifyRectFilter::clearAll()
{
	m_umIRF_30.clear();
	m_umIRF_1C.clear();
	m_sIRF_48.clear();
	m_umIRF_54.clear();
	IDocumentFilter::clearAll();
}

IdentifyRectDocumentStorage * IdentifyRectFilter::storage()
{
	return &m_xIRF_68;
}

void IdentifyRectFilter::filter(vector<int>& a2, vector<pair<int, int>>& a3, recpass::imageholder::IImageHolder & a4, unordered_map<int, float>& a5, vector<int>& a6, unordered_map<int, int>& a7, int a8)
{
	m_sIRF_48.clear();
	a6.clear();
	a5.clear();
	m_nIRF_44 = 0;
	vector<pair<float, int>> vp81(a2.size());
	list<int> l80(a2.begin(), a2.end());

	int n11 = 0;

	for (list<int>::iterator iter = l80.begin(); iter != l80.end(); iter++)
	{
		int n16 = a7[*iter];
		IdentifyRectDocument *p17 = dynamic_cast<IdentifyRectDocument *>(storage()->getExistDocument(*iter));

		float r77 = 0.0f;
		float r20;

		if (p17)
		{
			DpiInfo x19 = m_umIRF_54[*iter];
			if (recognizeByRects(*iter, p17, (CDocFormat)n16, a4, x19, 0, (float)m_nIRF_C, r77, m_sIRF_48))
			{
				r20 = 0.0f;
			}
			else
			{
				r20 = r77;
			}
		}
		else
		{
			r20 = 1.0f;
		}

		vp81[n11].first = r20;
		vp81[n11].second = *iter;
		n11++;
	}

	for (size_t k = 0; k < vp81.size(); k++)
	{
		if (vp81[k].first == 0.0f)
		{
			a6.push_back(vp81[k].second);
		}
	}

	int n = vp81.size();

	for (size_t k = 0; k < vp81.size(); k++)
	{
		if (vp81[k].first == 0.0f)
		{
			for (size_t l = k; l < vp81.size() - 1; l++)
			{
				if (vp81[l + 1].first != 0.0)
				{
					vp81[k] = vp81[l + 1];
					k++;
					n = k;
				}
			}
			break;
		}
	}

	vp81.erase(vp81.begin() + n, vp81.end());

	unordered_map<int, float> um2a;

	for (size_t i = 0; i < vp81.size(); i++)
	{
		um2a[vp81[i].second] = vp81[i].first;
	}

	vector<pair<float, int>> v78(vp81);

	for (size_t i = 0; i < v78.size(); i++)
	{
		if (um2a.find(v78[i].second) != um2a.end())
		{
			IdentifyRectDocument *p48 = dynamic_cast<IdentifyRectDocument *>(storage()->getDocument(v78[i].second));

			if (p48)
			{
				bool f49 = 0;

				int n64 = a7[v78[i].second];

				for (size_t j = 0; j < p48->m_xIRD_4.m_vIRA_0.size(); j++)
				{
					int n52 = p48->m_xIRD_4.m_vIRA_0[j].m_xCIRF2_0.struc_367_24;
					if (n52 && !f49)
					{
						vector<int> v1;

						for (int k = 0; k < n52; k++)
						{
							if (um2a.find(p48->m_xIRD_4.m_vIRA_0[j].m_pCIRF2_2C[k].struc_368_0) != um2a.end())
							{
								v1.push_back(p48->m_xIRD_4.m_vIRA_0[j].m_pCIRF2_2C[k].struc_368_0);
							}
						}

						if (!v1.empty())
						{
							float r75;
							int n59 = recognizeByRects(v78[i].second, p48, (CDocFormat)n64, a4, m_umIRF_54[v78[i].second], v1[0], (float)m_nIRF_C, r75, m_sIRF_48);

							f49 = 0;

							if (n59)
							{								
								if (n59 != 29)
								{
									if (um2a.find(v78[i].second) != um2a.end())
									{
										um2a.erase(v78[i].second);
									}

									if (v78[i].second == a8 && !m_nIRF_44)
									{
										m_nIRF_44 = a8;
									}
					
								}
							}
							else
							{
								for (size_t k = 0; k < v1.size(); k++)
								{
									if (um2a.find(v1[k]) != um2a.end())
									{
										um2a.erase(v1[k]);
									}
								}

								for (size_t k = 0; k < v1.size(); k++)
								{
									if (v1[k] == a8)
									{
										if (!m_nIRF_44)
										{
											m_nIRF_44 = v78[i].second;
										}
									}
								}								
							}
						}
					}
				}
			}
		}
	}

	a5 = um2a;
}

DpiInfo IdentifyRectFilter::info(int a2)
{
	return m_umIRF_54[a2];
}

void IdentifyRectFilter::updateConflictRelation(void)
{
	m_umIRF_1C.clear();
	m_umIRF_30.clear();
	vector<int> v2;
	storage()->docIDs(v2);
	sort(v2.begin(), v2.end());

	for (size_t i = 0; i < v2.size(); i++)
	{
		IdentifyRectDocument * p7 = dynamic_cast<IdentifyRectDocument *>(storage()->getDocument(v2[i]));

		if (p7)
		{
			vector<int> v1;
			p7->getConflictDocIds(v1);

			for (size_t j = 0; j < v1.size(); j++)
			{
				size_t k;
				for (k = 0; k < v2.size(); k++)
				{
					if (v2[k] == v1[j])
					{
						break;
					}
				}

				if (k == v2.size())
				{

				}
				else if (v2[i] != v1[j])
				{
					m_umIRF_30[v2[i]].m_sIRD_0.insert(v1[j]);
					m_umIRF_30[v1[j]].m_sIRD_0.insert(v2[i]);
				}
			}
		}
	}

	vector<int> v1 = common::mapKeys(m_umIRF_30);

	for (size_t i = 0; i < v1.size(); i++)
	{
		if (m_umIRF_30[v1[i]].m_sIRD_0.size())
		{
			common::unit(m_umIRF_1C[v1[i]].m_sIRD_0, m_umIRF_30[v1[i]].m_sIRD_0);

			for (set<int>::iterator iter = m_umIRF_30[v1[i]].m_sIRD_0.begin(); iter != m_umIRF_30[v1[i]].m_sIRD_0.end(); iter++)
			{
				common::unit(m_umIRF_1C[v1[i]].m_sIRD_0, m_umIRF_30[*iter].m_sIRD_0);
			}

			m_umIRF_1C[v1[i]].m_sIRD_0.erase(v1[i]);
		}
	}
}

void IdentifyRectArray::filterByConflictID(int a2, vector<int>& a3)
{
	a3.clear();
	a3.reserve(m_vIRA_0.size());
	for (size_t i = 0; i < m_vIRA_0.size(); i++)
	{
		if (a2)
		{
			for (int j = 0; j < m_vIRA_0[i].m_xCIRF2_0.struc_367_24; j++)
			{
				if (m_vIRA_0[i].m_pCIRF2_2C[j].struc_368_0 == a2)
				{
					a3.push_back(i);
				}
			}
		}
		else if (!m_vIRA_0[i].m_xCIRF2_0.struc_367_24)
		{
			a3.push_back(i);
		}
	}
}

void IdentifyRectArray::filterByRequred(vector<int>& a2, vector<int>& a3, vector<int>& a4)
{
	a3.clear();
	a4.clear();

	for (size_t i = 0; i < a2.size(); i++)
	{
		if (m_vIRA_0[a2[i]].m_xCIRF2_0.struc_367_1C)
		{
			a4.push_back(a2[i]);
		}
		else
		{
			a3.push_back(a2[i]);
		}
	}
}

void IdentifyRectArray::filterByLayer(vector<int>& a2, vector<vector<int>>& a3)
{
	a3.clear();
	a3.resize(5);
	for (size_t i = 0; i < a2.size(); i++)
	{
		if (m_vIRA_0[a2[i]].m_xCIRF2_0.struc_367_18 != -1 && m_vIRA_0[a2[i]].m_xCIRF2_0.struc_367_18)
		{
			int n10 = m_vIRA_0[a2[i]].m_xCIRF2_0.struc_367_18;
			if (n10 == 4)
			{
				n10 = 2;
			}

			a3[n10].push_back(a2[i]);
		}
		else
		{
			a3[0].push_back(a2[i]);
		}
	}
}

namespace IdentifyRectSearch
{
	int findMask(vector<IdentifyKit>& a1, vector<IdentifyRectResult>& a2)
	{
		IdentifyRectResult x19;

		a2.resize(a1.size(), x19);

		for (size_t i = 0; i < a1.size(); i++)
		{
			int nRes = RCv::find(*a1[i].m_pIK_4, *a1[i].m_pIK_0, a1[i].m_pIK_8->m_xIRR_4.rx(), a1[i].m_pIK_8->m_xIRR_4.ry(), a1[i].m_pIK_8->m_rIRR_0, CV_TYPESEARCHIGIMAGE_1, 5);

			if (nRes)
			{
				return nRes;
			}

			a2[i].m_rIRR_0 = a1[i].m_pIK_8->m_rIRR_0;
			a2[i].m_xIRR_4.fx = a1[i].m_pIK_8->m_xIRR_4.fx;
			a2[i].m_xIRR_4.fy = a1[i].m_pIK_8->m_xIRR_4.fy;
		}

		return 0;
	}
}
