#include "TextClass.h"
#include "../common/common.h"
#include "StdDataStreamDirect.h"

using namespace common;

TextClassStorage::TextClassStorage()
{
}

TextClassStorage::~TextClassStorage()
{
}

void TextClassStorage::free()
{
	m_ummTCS_4.clear();
	m_sTCS_18.clear();
	m_sTCS_24.clear();
	m_sTCS_30.clear();
	m_ummTCS_3C.clear();
	m_umTCS_50.clear();
}

void TextClassStorage::clear(int a2)
{
	clearCountryCode(a2);
	clearDocumentClass(a2);
	clearDocumentFormat(a2);
}

void TextClassStorage::clearCountryCode(int a2)
{
	if (m_ummTCS_4.find(a2) != m_ummTCS_4.end())
	{
		m_ummTCS_4.erase(a2);
	}

	if (m_sTCS_30.find(a2) != m_sTCS_30.end())
	{
		m_sTCS_30.erase(a2);
	}

	if (m_sTCS_24.find(a2) != m_sTCS_24.end())
	{
		m_sTCS_24.erase(a2);
	}

	if (m_sTCS_18.find(a2) != m_sTCS_18.end())
	{
		m_sTCS_18.erase(a2);
	}
}

void TextClassStorage::clearDocumentClass(int a2)
{
	if (m_ummTCS_3C.find(a2) != m_ummTCS_3C.end())
	{
		m_ummTCS_3C.erase(a2);
	}
}

void TextClassStorage::clearDocumentFormat(int a2)
{
	if (m_umTCS_50.find(a2) != m_umTCS_50.end())
	{
		m_umTCS_50.erase(a2);
	}
}

vector<basic_string<char>> TextClassStorage::countryCode(int a2)
{
	vector<basic_string<char>> a1;
	a1 = mapValues(m_ummTCS_4, a2);

	if (m_sTCS_30.find(a2) != m_sTCS_30.end())
	{
		a1.emplace_back("!!!");
	}

	if (m_sTCS_24.find(a2) != m_sTCS_24.end())
	{
		a1.emplace_back("???");
	}

	if (m_sTCS_18.find(a2) != m_sTCS_18.end())
	{
		a1.emplace_back("===");
	}

	return a1;
}

vector<basic_string<char>> TextClassStorage::documentClass(int a2)
{
	return mapValues(m_ummTCS_3C, a2);
}

vector<int> TextClassStorage::filterByCountryCode(vector<int>& a3, basic_string<char> a4, bool a5)
{
	vector<int> a1;

	if(a4 == "!!!")
	{
		return intersect(m_sTCS_30, a3);
	}

	if (a4 == "===")
	{
		return intersect(m_sTCS_18, a3);
	}

	if (a4.length())
	{
		vector<int> v1a = mapKeys(m_ummTCS_4, a4);
		set<int> s25;

		s25.insert(v1a.begin(), v1a.end());
			
		if (a5)
		{
			vector<int> v24(m_sTCS_24.size() + s25.size());
			vector<int>::iterator iter = set_union(m_sTCS_24.begin(), m_sTCS_24.end(), s25.begin(), s25.end(), v24.begin());
			v24.erase(iter, v24.end());
			a1 = intersect(v24, a3);
		}
		else
		{
			a1 = intersect(s25, a3);
		}
	}

	return a1;
}

vector<int> TextClassStorage::filterByDocumentClass(vector<int>& a3, basic_string<char> a4)
{
	if (a4.length())
	{
		return intersect(mapKeys(m_ummTCS_3C, a4), a3);
	}

	return a3;
}

vector<int> TextClassStorage::filterDocumentFormat(vector<int>& a3, vector<int>& a4)
{
	return intersect(mapKeys(m_umTCS_50, a4), a3);
}

int TextClassStorage::getDocumentFormat(int a2)
{
	unordered_map<int, int>::iterator iter = m_umTCS_50.find(a2);
	if (iter != m_umTCS_50.end())
	{
		return iter->second;
	}
	return -1;
}

unordered_map<int, int> TextClassStorage::getDocumentFormat(vector<int> const & a3)
{
	unordered_map<int, int> a1;
	a1.reserve(a3.size());
	for (size_t i = 0; i < a3.size(); i++)
	{
		a1[a3[i]] = getDocumentFormat(a3[i]);
	}
	return a1;
}

void TextClassStorage::updateCountryCode(int a2, basic_string<char> a3)
{
	if (a3 == "???")
	{
		m_sTCS_24.insert(a2);
		return;
	}

	if (a3 == "!!!")
	{
		m_sTCS_30.insert(a2);
		return;
	}

	if (a3 == "===")
	{
		m_sTCS_18.insert(a2);
		return;
	}

	m_ummTCS_4.insert(pair<int, basic_string<char>>(a2, a3));
}

void TextClassStorage::updateDocumentClass(int a2, basic_string<char> a3)
{
	if (!contains(mapValues(m_ummTCS_3C, a2), a3))
	{
		m_ummTCS_3C.emplace(a2, a3);
	}
}

void TextClassStorage::updateDocumentFormat(int a2, int a3)
{
	m_umTCS_50[a2] = a3;
}

TextClassFilter::TextClassFilter()
{
}

TextClassFilter::~TextClassFilter()
{
}

int TextClassFilter::type()
{
	return 2;
}

void TextClassFilter::save(int, vector<uchar>&)
{
}

void TextClassFilter::load(int a2, vector<uchar>& a3)
{
	StdDataStreamDirectR xSDSDR(a3);

	int n5 = 0;

	if (xSDSDR.m_nSDSDR_C + 4 <= (int)xSDSDR.m_vSDSDR_0.size())
	{
		n5 = *(int*)(xSDSDR.m_vSDSDR_0.data() + xSDSDR.m_nSDSDR_C);
	}

	xSDSDR.m_nSDSDR_C += 4;

	for (int i = 0; i < n5; i++)
	{
		int n10 = 0;

		if (xSDSDR.m_nSDSDR_C + 4 <= (int)xSDSDR.m_vSDSDR_0.size())
		{
			n10 = *(int*)(xSDSDR.m_vSDSDR_0.data() + xSDSDR.m_nSDSDR_C);
		}

		xSDSDR.m_nSDSDR_C += 4;

		basic_string<char> str;

		xSDSDR.readString(str, n10);

		storage()->updateCountryCode(a2, str);
	}


	if (xSDSDR.m_nSDSDR_C + 4 <= (int)xSDSDR.m_vSDSDR_0.size())
	{
		n5 = *(int*)(xSDSDR.m_vSDSDR_0.data() + xSDSDR.m_nSDSDR_C);
	}

	xSDSDR.m_nSDSDR_C += 4;

	for (int i = 0; i < n5; i++)
	{
		int n16 = 0;

		if (xSDSDR.m_nSDSDR_C + 4 <= (int)xSDSDR.m_vSDSDR_0.size())
		{
			n16 = *(int*)(xSDSDR.m_vSDSDR_0.data() + xSDSDR.m_nSDSDR_C);
		}

		xSDSDR.m_nSDSDR_C += 4;

		basic_string<char> str;

		xSDSDR.readString(str, n16);

		storage()->updateDocumentClass(a2, str);
	}

	int n21;

	if (xSDSDR.m_nSDSDR_C + 4 > (int)xSDSDR.m_vSDSDR_0.size())
	{
		n21 = 0;
	}
	else
	{
		n21 = *(int*)(xSDSDR.m_vSDSDR_0.data() + xSDSDR.m_nSDSDR_C);
	}

	xSDSDR.m_nSDSDR_C += 4;

	storage()->updateDocumentFormat(a2, n21);
}

void TextClassFilter::clear(int a2)
{
	storage()->clear(a2);
}

TextClassStorage * TextClassFilter::storage()
{
	return &m_xTCF_4;
}
