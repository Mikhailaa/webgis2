#pragma once
#include "interface.h"
#include "../gdi/Point.h"

namespace recpass
{
	namespace imageholder
	{
		class IImageHolder;
	}
}


class IdentifyRectResult
{
public:
	float   m_rIRR_0;
	CPointF m_xIRR_4;
public:
	IdentifyRectResult();
	IdentifyRectResult(IdentifyRectResult const&);
};

class IdentifyKit
{
public:
	cv::Mat*             m_pIK_0;
	cv::Mat*             m_pIK_4;
	IdentifyRectResult * m_pIK_8;
};

struct struc_368
{
	int struc_368_0;
	int struc_368_4;
};

struct struc_367
{
	tagRECT				struc_367_0;
	int                 struc_367_10;
	eRPRM_Lights        struc_367_14;
	int                 struc_367_18;
	char                struc_367_1C;
	char                struc_367_1D;
	char                struc_367_1E;
	char                struc_367_1F;
	char                struc_367_20;
	char                struc_367_21;
	char                struc_367_22;
	char                struc_367_23;
	int                 struc_367_24;
	struc_368 *         struc_367_28;
};


class CImageRectFinal2
{
public:
	struc_367   m_xCIRF2_0;
	struc_368   m_pCIRF2_2C[15];
	int			m_pCIRF2_A4[54];
public:
	CImageRectFinal2();
};

struct Info
{
	int              nInfo_0;
	eRPRM_Lights     nInfo_4;
	int              nInfo_8;
	tagRECT        xInfo_C;
	tagRECT        xInfo_1C;
	tagRECT        xInfo_2C;
};


struct SearchInfo
{
	int  nSI_0;
	Info pSI_4[16];
};

class IdentifyRectArray
{
public:
	vector<CImageRectFinal2> m_vIRA_0;
public:
	void filterByConflictID(int, vector<int> &);
	void filterByRequred(vector<int> &, vector<int> &, vector<int> &);
	void filterByLayer(vector<int> &, vector<vector<int>> &);
};

class IdentifyRectDocument : public _IDocument
{
public:
	~IdentifyRectDocument();
	void clear();
	void filterRects(vector<int> &, vector<IdentifyKit> &);
	void getResolution(vector<int> &, vector<int> &);
	static SearchInfo* searchInfo(void);
	void setRectNumber(int);
	void getConflictDocIds(vector<int> &);
public:
	IdentifyRectArray           m_xIRD_4;
	int                         m_nIRD_10;
	int                         m_nIRD_14;
	int                         m_nIRD_18;
	int                         m_nIRD_1C;
	int                         m_nIRD_20;
	Size2f                      m_xIRD_24;
	vector<pair<cv::Mat, int>>  m_vIRD_2C;
	vector<vector<uchar>>       m_vIRD_38;
	vector<IdentifyRectResult>  m_vIRD_44;
};

class IdentifyRectDocumentStorage : public IHashDocumentStorage
{
public:
	IdentifyRectDocumentStorage();
	~IdentifyRectDocumentStorage();
	IdentifyRectDocument* create();
	void remove(_IDocument *);
};

class IdentifyRectDoc
{
public:
	IdentifyRectDoc();
	IdentifyRectDoc(IdentifyRectDoc const&);
public:
	set<int> m_sIRD_0;
};

class IdentifyRectFilter : public IDocumentFilter
{
public:
	IdentifyRectFilter();
	~IdentifyRectFilter();

	int type();
	void save(int, vector<uchar> &);
	void load(int, vector<uchar> &);
	void clear(int);
	void clearAll();
	IdentifyRectDocumentStorage* storage();

	void filter(vector<int> &, vector<pair<int, int>> &, recpass::imageholder::IImageHolder &, unordered_map<int, float> &, vector<int> &, unordered_map<int, int> &, int);
	DpiInfo info(int);
	void updateConflictRelation(void);
public:
	int                                 m_nIRF_4;
	int                                 m_nIRF_8;
	int                                 m_nIRF_C;
	int                                 m_nIRF_10;
	int                                 m_nIRF_14;
	int                                 m_nIRF_18;
	unordered_map<int, IdentifyRectDoc> m_umIRF_1C;
	unordered_map<int, IdentifyRectDoc> m_umIRF_30;
	int                                 m_nIRF_44;
	set<int>                            m_sIRF_48;
	unordered_map<int, DpiInfo>         m_umIRF_54;
	IdentifyRectDocumentStorage         m_xIRF_68;
};

namespace IdentifyRectSearch
{
	int findMask(vector<IdentifyKit> &, vector<IdentifyRectResult> &);
}