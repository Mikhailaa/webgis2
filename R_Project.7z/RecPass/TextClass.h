#pragma once
#include "../pch.h"
#include "interface.h"

class TextClassStorage : public IDocumentStorage
{
public:
	unordered_multimap<int, basic_string<char>> m_ummTCS_4;
	set<int>                                    m_sTCS_18;
	set<int>                                    m_sTCS_24;
	set<int>                                    m_sTCS_30;
	unordered_multimap<int, basic_string<char>> m_ummTCS_3C;
	unordered_map<int, int>                     m_umTCS_50;
public:
	TextClassStorage();
	~TextClassStorage();
	void free();
	void clear(int);
	void clearCountryCode(int);
	void clearDocumentClass(int);
	void clearDocumentFormat(int);
	vector<basic_string<char>> countryCode(int);
	vector<basic_string<char>> documentClass(int);
	vector<int> filterByCountryCode(vector<int> &, basic_string<char>, bool);
	vector<int> filterByDocumentClass(vector<int> &, basic_string<char>);
	vector<int> filterDocumentFormat(vector<int> &, vector<int> &);
	int getDocumentFormat(int);
	unordered_map<int, int> getDocumentFormat(vector<int> const&);
	void updateCountryCode(int, basic_string<char>);
	void updateDocumentClass(int, basic_string<char>);
	void updateDocumentFormat(int, int);
};

class TextClassFilter : public IDocumentFilter
{
public:
	TextClassStorage m_xTCF_4;
public:
	TextClassFilter();
	~TextClassFilter();

	int type();
	void save(int, vector<uchar> &);
	void load(int, vector<uchar> &);
	void clear(int);
	TextClassStorage* storage();
};
