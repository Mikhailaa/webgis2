#pragma once
#include "../pch.h"
#include "interface.h"

class TextOneClassStorage : public IDocumentStorage
{
public:
	unordered_multimap<int, basic_string<char>>  m_ummTOCS_4;
	set<int>                                     m_sTOCS_18;
public:
	~TextOneClassStorage();
	void free();
	virtual vector<int> filterByValue(vector<int> const&, string const&);

	void clear(int);
	void updateValue(int, string const&);
	vector<string> values(int);
};

class TextOneClassFilter : public IDocumentFilter
{
public:
	TextOneClassStorage m_xTOCF_4;
public:
	~TextOneClassFilter();

	int type();
	void save(int, vector<uchar> &);
	void load(int, vector<uchar> &);
	void clear(int);
	TextOneClassStorage* storage();
};

class TextStateCodeFilter : public TextOneClassFilter
{
public:
	~TextStateCodeFilter();

	int type();
};

class MaskFilterStorage : public TextOneClassStorage
{
public:
	~MaskFilterStorage();

	vector<int> filterByValue(vector<int> const&, basic_string<char> const&);
};

class TextFilterMaskFilter : public TextOneClassFilter
{
public:
	MaskFilterStorage m_xTFMF_28;
public:
	TextFilterMaskFilter();
	~TextFilterMaskFilter();

	int type();
	MaskFilterStorage* storage();
};

class TextCountryIDFilter : public TextOneClassFilter
{
public:
	~TextCountryIDFilter();

	void save(int, vector<uchar> &);
	void load(int, vector<uchar> &);
	int type();
};