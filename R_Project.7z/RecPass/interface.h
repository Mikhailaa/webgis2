#pragma once
#include "../pch.h"
#include "../gdi/Point.h"

struct DpiInfo
{
	int nDI_0;
	int nDI_4;
};

class _IDocument
{
public:
	virtual ~_IDocument() {};
};

class IDocumentStorage
{
public:
	virtual ~IDocumentStorage() {};
	virtual void free() = 0;
};

class IDocumentFactory
{
public:
	virtual _IDocument* create() = 0;
	virtual void remove(_IDocument *) = 0;
};

class IHashDocumentStorage : public IDocumentStorage, public IDocumentFactory
{
public:
	~IHashDocumentStorage();
	void free();

	void docIDs(vector<int> &);
	_IDocument* getDocument(int);
	_IDocument* getExistDocument(int);
public:
	unordered_map<int, _IDocument *> m_umIHDS_8;
};

class IDocumentFilter
{
public:
	virtual ~IDocumentFilter() {};
	virtual int type() = 0;
	virtual void save(int, vector<uchar> &) = 0;
	virtual void load(int, vector<uchar> &) = 0;
	virtual void clear(int) = 0;
	virtual void clearAll()
	{
		storage()->free();
	}
	virtual IDocumentStorage* storage() = 0;
};
