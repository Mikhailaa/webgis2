#pragma once
#include "common/container/RclHolder.h"
#include "ProcessParamsHolder.h"
#include <functional>
#include "commonStruct.h"

using namespace std;

namespace status
{
	class StatusGenerator
	{
	public:
		StatusGenerator();
		void generateStatus(common::container::RclHolder const&, ProcessParamsHolder const&, common::container::RclHolder&);
		void obtainStatusComplete(void);		
	};

	class OpticalStatusGenerator
	{
	public:
		OpticalStatusGenerator();
		void generateStatus(common::container::RclHolder const&, ProcessParamsHolder const&);
		void obtainStatusOverall(void);
	};

	class RfidStatusGenerator
	{
	public:
		RfidStatusGenerator();
		void generateStatus(common::container::RclHolder const&);
	};

	/*checkAuthenticityContainers(common::container::RclHolder const&, eRPRM_ResultType);
	checkComparisonElements(TVerifiedFieldMap const&);
	checkContainers(common::container::RclHolder const&, eRPRM_ResultType, function<eCheckResult()(TResultContainer const&)>);
	checkLexExpiryField(TListVerifiedFields const&);
	checkMatrix(TVerifiedFieldMap const&);
	checkMrzQualFields(TDocMRZTestQuality const&);
	checkMrzQualityForPage(common::container::RclHolder const&, int);
	checkVerificationElements(TVerifiedFieldMap const&);
	createStatusesVector(TAuthenticityCheckList const&);
	createStatusesVector(TListVerifiedFields const&);
	findSessionRFID(TDocBinaryInfo const&);
	hasMrzStrings(TDocVisualExtendedInfo const&);
	obtainPagesCount(common::container::RclHolder const&);
	obtainResultingStatus(std::__ndk1::vector<eCheckResult, std::__ndk1::allocator<eCheckResult>> const&);
	obtainSessionRFID(common::container::RclHolder const&);
	obtainStatusDocType(common::container::RclHolder const&, ProcessParamsHolder const&);
	obtainStatusExpiry(common::container::RclHolder const&);
	obtainStatusImageQA(common::container::RclHolder const&);
	obtainStatusMRZ(common::container::RclHolder const&);
	obtainStatusStopList(common::container::RclHolder const&);
	obtainStatusText(common::container::RclHolder const&);*/
};

