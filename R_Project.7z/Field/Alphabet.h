#pragma once
#include "../pch.h"

class CAlphabet
{
public:
	CAlphabet();
	void init(string &);
	void reset();

	int m_bCA_HasData_0;
	char m_szCA_Alphabet[256];
};