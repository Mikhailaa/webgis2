#pragma once 
#include "../Field/Alphabet.h"

class TVisualSubField
{
public:
	TVisualSubField();
public:
	short m_sTVSF_fieldType;
	short m_sTVSF_lcid;
	char m_szTVSF_4[256];
	int m_nTVSF_104;
	int m_nTVSF_MinMaxLen_108;
	int m_nTVSF_10C;
	char m_szTVSF_110[256];
	int m_nTVSF_Count_210;
	char *m_lpTVSF_Buffer_214;
	CAlphabet m_aTVSF_Alphabet_218[4];
};

class CVisualSubField : public TVisualSubField
{
public:
	~CVisualSubField();
	CVisualSubField();
	void free();
	int maxLen();
	int minLen();
	CVisualSubField& operator=(CVisualSubField&);
	void reset();
	void set(CVisualSubField&);
	int variantPos(char *);
	void zeroize();
public:
 	TVocList m_xCVSF_VL;
};