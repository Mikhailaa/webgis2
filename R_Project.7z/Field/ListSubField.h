#pragma once
#include "VisualSubField.h"

class ListSubField
{
public:
	ListSubField();
	~ListSubField();
	void reset();
	int count();
	int indexOf(const char *);
	void reserve(int);
	void resize(int);
	void set(ListSubField &);
	void free();
	ListSubField & operator=(ListSubField &);
	CVisualSubField & operator[](int);

public:
	int m_nLSF_count_0;
	CVisualSubField *m_pLSF_CVSF_4;
	int m_nLFS_size_8;
};