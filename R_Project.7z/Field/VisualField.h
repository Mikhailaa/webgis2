#pragma once
#include "../pch.h"

class CVisualField : public TVisualField
{
public:
	CVisualField();
	//~CVisualField(){};

	int bindLayer();
	uint getLightType();
	TPhotoParams * getPhotoParams();
	TProcParams& getProcParams();
	tagRECT getRegion();
	eVisualFieldType getType();
	uint getVocCount();
	uint getVocID(int);
	TVocList &getVocList();
	bool isPerforation();
	bool operator==(CVisualField&);
	void setLightType(int);
	void setName(char *, int);
	void setRegion(tagRECT &);
	void setRelRegion(tagRECTF &);
	void setType(int);
};