#pragma once
#include "pch.h"
#include "common/container/RclHolder.h"

int processgl(int a1, TResultContainerList *a2, const char *a3, void **a4, char **a5);

namespace mobileadapter
{
	int process(int, void *, char const*, void **, char **);
};

