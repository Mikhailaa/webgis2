#pragma once
#include "commonStruct.h"

class CDocBarCodeField : public TDocBarCodeField
{
public:
	CDocBarCodeField(CDocBarCodeField const&);
	CDocBarCodeField();
	~CDocBarCodeField();
	void free(void);
	void getData(vector<uchar> &);
	int getType(void);
	void load(CDocBarCodeField const&);
	void load(string &);
	int loadDecodeResult(TDocBarCodeField *);
	int setRect(tagRECT a2);
};

class CDocBarCodeInfo : public TDocBarCodeInfo
{
public:
	uint m_nCDBCIR_field_8;

	CDocBarCodeInfo();
	~CDocBarCodeInfo();
	CDocBarCodeField *add(void);
	void free(void);
	void reserve(int);
};

