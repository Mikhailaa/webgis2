#include "NotifyFunction.h"

namespace NotifyFunction
{
	void(*g_pLogFunc)(int, int);
	void(*g_pNotifyFunc)(int, int);

	void setLog(void(*a1)(int, int))
	{
		g_pLogFunc = a1;
	}

	void setNotify(void(*a1)(int, int))
	{
		g_pNotifyFunc = a1;
	}
}
