#include "procmgr.h"
#include "procmgrdefault.h"
#include "processmanagerdefault.h"
#include "common/container/json.h"
#include "common/container/jsoncpp.h"
#include "common/FilesystemUtils.h"
#include "common/fs.h"
#include "imaging.h"
#include "ImageHelperLib.h"
#include "common/common.h"
#include "common/RegulaConfig.h"
#include "ProcessParamsHolder.h"
#include "ImageHelperLib.h"
#include "Guid.h"
#include "common/resources.h"
#include "DocBarCodeInfo.h"

namespace procmgr
{
	struct gProcMgr_global_registrator {
		shared_ptr<ProcMgr> gProcMgr;
		gProcMgr_global_registrator() {
			gProcMgr = common::getModuleOrchestrator()->addModule<ProcMgr>();
		}
	} gProcMgr_global_registrator_;

	void initScenario(eProcessCommands eParam1, common::container::RclHolder & xRH_Param2, Json::Value & xJV_Param3)
	{
		if (eParam1 != ProcessCommands_2F45 && eParam1 != ProcessCommands_2F48)
			return;
		
		if (xJV_Param3["processParam"].get("doublePageSpread", Json::Value(false)).asBool())
		{
			if (xJV_Param3["processParam"].get("integralImage", Json::Value(false)).asBool())
			{
				xJV_Param3["processParam"]["integralImage"] = Json::Value(false);
			}
		}
		procmgr::timeout::configureTimeOut(xJV_Param3);
		if (eParam1 == ProcessCommands_2F45)
		{
			xJV_Param3["processParam"]["isSeries"] = Json::Value(true);
		}
		string str1("basicOneBig,id3x2Series,id3x2One,id3x2Split2Series,basic");
		string str2("basicOneBig,fullSplit2,id3x2,id3x2One,id3x2Split2,id1x2,basic,full,mrz");
		string str3("basicOneBig,basic,full,mrz");
		if (!xJV_Param3["processParam"].isMember("imageDpiOutMax"))
		{
			xJV_Param3["processParam"]["imageDpiOutMax"] = Json::Value(300);
		}
		int ir = rclhelp::imageResolution(xRH_Param2.m_xTRCL);
		if (ir <= 7400)
			rclhelp::setResolution(xRH_Param2.m_xTRCL, 0);
		using namespace processmanagerdefault::scenario;
		eProcessScenario st = procmgrdefault::jsonRequest::getScenarioType(xJV_Param3);
		if (eParam1 == ProcessCommands_2F48)
		{
			xJV_Param3["processParam"]["disableFocusingCheck"] = Json::Value(true);
		}
		if (st == ProcessScenario_Ocr || st == ProcessScenario_DocType || st == ProcessScenario_MrzOrOcr || st == ProcessScenario_MrzOrBarcodeOrOcr ||
			st == ProcessScenario_LocateVisual_And_MrzOrOcr || st == ProcessScenario_FullProcess || (st == ProcessScenario_Id3Rus && eParam1 == ProcessCommands_2F48))
		{
			if (st == ProcessScenario_Id3Rus)
			{
				xJV_Param3["processParam"]["scenario"] = Json::Value(convert(ProcessScenario_Ocr));
			}
			if (!xJV_Param3["processParam"].get("manualCrop", Json::Value(false)).asBool())
			{
				if (xJV_Param3["processParam"].get("doublePageSpread", Json::Value(false)).asBool())
				{
					if (eParam1 == ProcessCommands_2F45)
					{
						xJV_Param3["boundsParam"]["checkVariants"] = Json::Value(str1);
					}
					if (eParam1 == ProcessCommands_2F48)
					{
						xJV_Param3["boundsParam"]["checkVariants"] = Json::Value(str2);
						xJV_Param3["boundsParam"]["processMode"] = Json::Value("BoundsMode_NoDPI_PerspectiveSlowServer");
					}
				}
				else if (eParam1 == ProcessCommands_2F48)
				{
					xJV_Param3["boundsParam"]["checkVariants"] = Json::Value(str3);
					xJV_Param3["boundsParam"]["processMode"] = Json::Value("BoundsMode_NoDPI_PerspectiveSlowServer");
				}
			}
		}
		else if (st == ProcessScenario_CreditCard)
		{
			procmgr::json::updateCreditCardScenario(xJV_Param3);
		}
		else if (st == ProcessScenario_RusStamp)
		{
			xJV_Param3["boundsParam"]["processMode"] = Json::Value("BoundsMode_NoDPI_PerspectiveSlow");
			xJV_Param3["boundsParam"]["activeDocFormatGroups"] = Json::Value("RusStamp");
			xJV_Param3["processParam"]["forceDocID"] = Json::Value(353160962);
			xJV_Param3["processParam"]["mrzDetect"] = Json::Value(false);
		}
		else if (st == ProcessScenario_OcrFree)
		{
			xJV_Param3["boundsParam"]["processMode"] = Json::Value("FullImage");
			xJV_Param3["processParam"]["forceDocID"] = Json::Value(1);
			xJV_Param3["processParam"]["mrzDetect"] = Json::Value(false);
			xJV_Param3["processParam"]["disableFocusingCheck"] = Json::Value(true);
			xJV_Param3["imSegParam"]["seriesProcess"]["minTextLenForResult"] = Json::Value(5);
			Json::Value jvTemp(Json::json_type_array);
			jvTemp.append(Json::Value(50));
			xJV_Param3["imSegParam"]["seriesProcess"]["necessaryFieldType"] = Json::Value(jvTemp);
			xJV_Param3["imSegParam"]["seriesProcess"]["confirmResultCount"] = Json::Value(4);
			xJV_Param3["imSegParam"]["seriesProcess"]["minProbThresholdDnn"] = Json::Value(101);
		}
		if (ir >= 7401)
		{
			xJV_Param3["boundsParam"]["processMode"] = Json::Value("BoundsMode_NoDPI_PerspectiveSlow");
			xJV_Param3["processParam"]["deviceId"] = Json::Value(0x10000004u);
		}
		if (xJV_Param3["processParam"].get("manualCrop", Json::Value(false)).asBool())
		{
			xJV_Param3["boundsParam"]["multipageProcessing"] = Json::Value(false);
		}
	}

	void FilterResultsByType(common::container::RclHolder & xRH_Param1, vector<uint> const& vParam2)
	{
		if (vParam2.size())
		{
			vector<TResultContainer> vTRC =	xRH_Param1.getContainers();
			uint i, j;
			for (i = 0; i < vTRC.size(); i++)
			{
				for (j = 0; j < vParam2.size(); j++)
				{
					if (vParam2[j] == vTRC[i].nTRC_result_type)
					{
						break;
					}
				}
				if (j == vParam2.size())
					xRH_Param1.remove(vTRC[i].nTRC_result_type);
			}
		}
	}

	void filterRclForSerialization(common::container::RclHolder & xRH_Param1, vector<uint> const& vParam2)
	{
		if (!vParam2.size())
		{
			xRH_Param1.remove(1);
			xRH_Param1.remove(16);
			xRH_Param1.remove(66);
		}
		else
		{
			FilterResultsByType(xRH_Param1, vParam2);
		}
	}

	string serializeRclToJson(common::container::RclHolder & xRH_Param1, string const& strParam2)
	{
		Json::Value jv1(Json::json_type_null);
		string strRet;

		jv1[strParam2] = common::container::jsoncpp::convert(xRH_Param1.toJson());
		common::container::jsoncpp::convert(jv1, strRet);
		return strRet;
	}

	ProcMgr::ProcMgr(void)
		:m_bPM_field_4(0), m_nPM_field_48(0), m_nPM_field_4C(0), m_nPM_field_5C(0), m_xPM_Params(Json::json_type_null)
	{
		GuidGenerator gen(0);
		m_xPM_Guid2 = gen.newGuid();
		m_xPM_ImgSize.cx = 0;
		m_xPM_ImgSize.cy = 0;
	}

	ProcMgr::~ProcMgr()
	{
		if (m_spPM_HeartbeatHelper.get())
		{
			m_spPM_HeartbeatHelper.get()->Close();
		}
	}

	int ProcMgr::Initialize(void * a2, char * a3, string & a4)
	{

		int v10;
		TResultContainerList *v6 = (TResultContainerList *)a2;

		if (m_bPM_field_4)
		{
			if (!m_xPM_String3.empty())
			{
				a4 = m_xPM_String3;
			}
			v10 = 0;
		}
		else
		{
			m_xPM_String3.clear();
			string v30;
			RclHolder rclHolder;
			if (!rclhelp::findFirstContainer(*v6, 0x40))
			{
				string strPathOfResource = common::RegulaConfig::GetFilePath("resource.dat");
				common::filesystemutils::readFile(strPathOfResource, v30);
				if (v30.length())
				{
					TResultContainer Rc = rclhelp::container(0x40, (uchar *)v30.data(), v30.length());
					rclHolder.addNoCopy(Rc);
					v6 = &rclHolder.m_xTRCL;
				}
			}

			moduleprocessgl::process(0xA8D, v6, a3, 0, 0);
			moduleprocessgl::process(0xCD, v6, a3, 0, 0);
			char * s = 0;
			v10 = moduleprocessgl::process(0x2FAB, v6, a3, 0, &s);
			if (s)
			{
				m_xPM_String3 = s;
				a4 = m_xPM_String3;
			}
			if (!v10)
				m_bPM_field_4 = true;
			string v31;
			string str = "db.json";
			common::resources::getFile(v6, str, v31);
			m_xPM_Params = Json::Value(common::container::jsoncpp::convert(v31)["config"]);
			m_tsPM_RclHolder.cleanup();
		}
		moduleprocessgl::process(0x2F49, 0, 0, 0, 0);

		return v10;
	}

	int ProcMgr::cmdProcessImage(RclHolder & a2, string const & a3, processmanagerdefault::scenario::eProcessScenario const & a4, void ** a5, char ** a6)
	{
		moduleprocessgl::process(0x2FAD, 0, 0, 0, 0);
		vector<shared_ptr<RclHolder>> v22 = rclhelp::splitByPage(a2);
		int v10 = v22.size();
		using namespace processmanagerdefault::scenario;
		if (v10 >= 2)
		{
			vector<eProcessScenario> v21 = getScenarioWithDocTypeRequired();
			vector<eProcessScenario>::const_iterator i;
			for (i = v21.begin(); i != v21.end(); i++)
			{
				if (*i == a4) break;
			}
			if (i != v21.end())
			{
				for (uint j = 0; j < v22.size(); ++j)
				{
					moduleprocessgl::process(0x2FAC, v22[j].get(), a3.data(), a5, a6);
					if (v10 == v22.size())
					{
						RclHolder v22((TResultContainerList *)*a5, true);
						vector<int> v20 = rclhelp::getDocIds(v22);
						if (v20.empty())
						{
							moduleprocessgl::process(0x2FAD, 0, 0, 0, 0);
						}
						else
						{
							v10 = j;
						}
					}
					moduleprocessgl::process(0x2FB1, 0, 0, 0, 0);
				}
			}
		}

		for (int k = 0; k < v10; ++k)
		{
			moduleprocessgl::process(0x2FAC, v22[k].get(), a3.data(), a5, a6);
			if (v10 - 1 != k)
				moduleprocessgl::process(0x2FB1, 0, 0, 0, 0);
		}

		return 0;
	}

	vector<int> ProcMgr::getCommands(void)
	{
		static vector<int> g_vnPM_1140F90 = { 0x2F47, 0x2F44, 0x2F49, 0x2F4A, 0x2F4E, 0x2F45, 0x2F46, 0x2F48,
			0x2F4C, 0x2F4B, 0x2F4D, 0x2F4F, 0x2F50, 0xCD, 0xCE };

		return g_vnPM_1140F90;
	}

	int ProcMgr::process(int a2, void * a3, const char * a4, void ** a5, char ** a6)
	{
		void * v194 = 0;
		void ** v8 = &v194;
		if (a5)
			v8 = a5;

		if (a2 == ProcessCommands_2F45 || a2 == ProcessCommands_2F46 || a2 == ProcessCommands_2F48)
			++m_nPM_field_48;

		if (a2 == ProcessCommands_2F48 || a2 == ProcessCommands_2F49)
		{
			GuidGenerator v1(0);
			m_xPM_Guid2 = v1.newGuid();
		}

		m_xPM_String1.clear();
		string v192 = procmgrdefault::jsonResponse::def::notReady();

		Json::Value v190(Json::json_type_null);
		string v189;

		if (a4)
		{
			v189 = string(a4);
		}

		common::container::jsoncpp::convert(v189, v190);
		Json::Value v16 = v190["processParam"]["customParams"];
		if (!v16.isNull() && v16.isObject())
		{
			vector<string> v2 = v16.getMemberNames();
			for (vector<string>::iterator i = v2.begin(); i != v2.end(); ++i)
			{
				v190["processParam"][*i] = Json::Value(v16[*i]);
			}
		}
		v190["trans_id"] = Json::Value(m_xPM_Guid2.ToString());
		string v186 = procmgrdefault::jsonRequest::getScenario(v190);
		processmanagerdefault::scenario::eProcessScenario v185 = processmanagerdefault::scenario::convert(v186);
		if (a2 == ProcessCommands_2F45 && !processmanagerdefault::scenario::isSupportSeriesProcessMode(v185))
		{
			m_xPM_String1 = procmgrdefault::jsonResponse::def::notReady();
			if (a6)
			{
				*a6 = (char *)m_xPM_String1.data();
			}
			return 0;
		}

		common::container::RclHolder rclHolder;
		barcode::addExternalBarcode(v190, rclHolder);

		if (a3)
			rclHolder.addNoCopy(*(TResultContainerList *)a3);
		if (!rclHolder.hasRc(1))
		{
			if (!v189.empty())
			{
				procmgr::imageconvert::getImageFromJson((eProcessCommands)a2, v190, rclHolder);
				common::container::json::FromJson(v189, rclHolder);
			}
		}
		if (a2 == ProcessCommands_2F48 && rclHolder.empty())
		{
			return 2;
		}

		procmgr::bounds::addBoundsResult(v190, rclHolder);
		ProcessParamsHolder pph(v189);
		if (!v189.empty())
		{
			moduleprocessgl::process(pph.m_fPPH_log ? ProcessCommands_CB : ProcessCommands_CC, 0, 0, 0, 0);
		}

		if (pph.getOption(processparams::PROCESSMODE_debugSaveLogs))
		{
			moduleprocessgl::process(ProcessCommands_CB, 0, 0, 0, 0);
			moduleprocessgl::process(ProcessCommands_CF, 0, 0, 0, 0);
		}

		if (m_xPM_String2.empty())
		{
			if (pph.getOption(processparams::PROCESSMODE_debugSaveLogs)
				|| pph.getOption(processparams::PROCESSMODE_debugSaveImages)
				|| pph.getOption(processparams::PROCESSMODE_debugSaveCroppedImages)
				|| pph.m_fPPH_debugSaveRFIDSession)
			{
				common::fs::Path v195;
				if (v190.isMember("processParam") && v190["processParam"].isMember("sessionLogFolder"))
				{
					v195.add(common::fs::Path(v190["processParam"]["sessionLogFolder"].asString()));
				}
				else
				{
					v195.add(common::fs::Path(common::RegulaConfig::GetTmpPath()));
					v195.add(common::fs::Path(common::system::getCurrentDate()));
				}
				m_xPM_String2 = v195.toString();
			}
		}
		v190["sessionLogFolder"] = Json::Value(m_xPM_String2);
		if (pph.getOption(processparams::PROCESSMODE_debugSaveImages))
			procmgr::develop::saveImage(rclHolder, processparams::PROCESSMODE_debugSaveImages, m_xPM_String2, m_nPM_field_4C, m_nPM_field_48, 20);
		if (pph.getOption(processparams::PROCESSMODE_returnUncroppedImage) && a3 != 0)
		{
			common::container::RclHolder v195(rclHolder.getRcList(1), true);
			vector<TResultContainer *> v174 = v195.getRcList();
			for (uint i = 0; i < v174.size(); i++)
			{
				v174[i]->nTRC_result_type = 16;
			}
			rclHolder.addCopy(v195.getRcList());
		}
		string v191 = v190["initParam"].get("applicationPath", Json::Value("")).asString();
		if (v191.empty())
		{
			v191 = common::ModuleUtils::GetModulePath();
		}
		if (!v191.empty())
		{
			common::RegulaConfig::SetRootPath(v191);
			common::RegulaConfig::SetTmpPath(common::fs::Path(v191).add(common::fs::Path("tmp")));
		}
		int v193 = procmgr::license::checkLicense(a2, v190, v192);
		if (v193)
		{
			m_xPM_String1 = v192;
			if (a6)
			{
				*a6 = (char*)m_xPM_String1.data();
			}
			return v193;
		}
		if (a2 == ProcessCommands_2F48)
		{
			v190["processParam"]["singleImageProcess"] = Json::Value(true);
		}
		updateAppConfigParams(v190);
		updateScenarioParams(v186, v190);
		
		const char *v72 = a4;
		if ((v190.isMember("imageInputParam") || v190.isMember("processParam")) 
			&& (a2 == ProcessCommands_2F45 || a2 == ProcessCommands_2F46 || a2 == ProcessCommands_2F48 || a2 == ProcessCommands_2F4F))
		{
			int v58 = v190["imageInputParam"].get("resolutionType", 0).asInt();
			if (v58 == 1)
			{
				rclhelp::updateContainerType(rclHolder, RT_TRawImageContainer_1, RT_TRawImageContainer_17);
				rclhelp::generateImageFromHiResolutionImage(m_xPM_ImgSize, RPRM_Lights_6, rclHolder);
			}
			if (pph.m_sPPH_scenario != "Capture")
			{
				tagPOINT v195 = { 0 };
				imageconvert::cropImage(v190["imageInputParam"], rclHolder, 0.07f, v195);
				json::updateFacePos(v190, v195);
				face::printFacePosition(v190["faceMetadata"]);
				json::updateBarcodePos(v190, v195);
			}
			if (v190["processParam"]["doFlipYAxis"].asBool())
				common::images::FlipImage(rclHolder.m_xTRCL, imaging::RI_FLIPMODES_1);
			tagSIZE imgSize = rclhelp::imageSize(rclHolder.m_xTRCL);
			if (v190["imageInputParam"].isMember("rotation"))
			{
				int v67 = v190["imageInputParam"]["rotation"].asInt();
				if(v67 < 0) v67 = -v67;
				imaging::eRI_Rotations v68 = imaging::angle::convert(v67);
				if (v68)
				{
					face::rotateFaceMetadata(v190["faceMetadata"], imaging::angle::convert(v68), rclhelp::imageSize(rclHolder.m_xTRCL));
					face::printFacePosition(v190["faceMetadata"]);
					common::container::jsoncpp::convert(v190, v189);
					v72 = 0;
					if (a4)
					{
						v72 = v189.data();
						common::filesystemutils::writeFile("jsonStringIn.json", v189.data(), v189.length());
					}
					common::images::RotateImage(rclHolder.m_xTRCL, v68);
				}
			}

			if (pph.getOption(processparams::PROCESSMODE_debugSaveCroppedImages))
				procmgr::develop::saveImage(rclHolder, processparams::PROCESSMODE_debugSaveImagesCroppedByFrame, m_xPM_String2,
					m_nPM_field_4C, m_nPM_field_48, 20);

			tagSIZE v187 = rclhelp::imageSize(rclHolder.m_xTRCL);
			if (m_xPM_ImgSize.cx != v187.cx || m_xPM_ImgSize.cy != v187.cy)
			{
				if (m_xPM_ImgSize.cx && m_xPM_ImgSize.cy)
				{
					moduleprocessgl::process(0x2F4E, 0, 0, 0, 0);
				}
				m_xPM_ImgSize = v187;
			}
		}
		if (v190.get("cameraType", Json::Value("back")).asString() == "front")
		{
			common::images::FlipImage(rclHolder.m_xTRCL, imaging::RI_FLIPMODES_1);
		}
		initScenario((eProcessCommands)a2, rclHolder, v190);
		rclHolder.addNewNoCopy<void>(0x33, &v190);
		common::container::jsoncpp::convert(v190, v189);
		char * v182 = 0;
		string v187;
		switch (a2)
		{
		case ProcessCommands_2F44:
			// "ePC_ProcMgr_SetLicense"
			/*if (m_spPM_HeartbeatHelper.get())
			{
				v193 = 6;
				break;
			}
			v193 = license::initLicense(v190, v192);
			if (v193)
				break;*/
			common::resources::setRclResources(&rclHolder.m_xTRCL);
			
			common::dbupdate::updateDB();
			if (!moduleprocessgl::process(0x9CC, 0, 0, 0, 0))
			{
				if (common::resources::getDBVersion().empty() || !common::resources::getDBUnpackStatus().empty())
				{
					Json::Value v174(Json::json_type_null);
					common::container::jsoncpp::convert(v192, v174);
					v174["license"]["status"] = Json::Value(false);
					string v188 = common::resources::getDBUnpackStatus();
					if (v188.empty())
					{
						v188.assign("db.dat is absent");
					}
					v174["license"]["message"] = Json::Value(v188);
					common::container::jsoncpp::convert(v174, v192);
					common::resources::setRclResources(0);
					break;
				}
			}
			v193 = Initialize(&rclHolder, (char*)v72, v187);
			common::container::jsoncpp::merge(v192, v187, v192);
			common::resources::setRclResources(0);
			break;
		case ProcessCommands_2F45:
			// "ePC_ProcMgr_Process"
			v193 = moduleprocessgl::process(0x2FA9, &rclHolder, v189.data(), v8, &v182);
			break;
		case ProcessCommands_2F46:
			// "ePC_ProcMgr_ProcessAsync"
			v193 = moduleprocessgl::process(0x2FAA, &rclHolder, v189.data(), v8, &v182);
			break;
		case ProcessCommands_2F47:
			v193 = Initialize(&rclHolder, (char*)v72, v187);
			if (v187.length())
			{
				v192 = v187;
			}
			break;
		case ProcessCommands_2F48:
			if (pph.m_sPPH_scenario != "Capture")
			{
				cmdProcessImage(rclHolder, v189, v185, v8, &v182);
			}
			else
			{
				m_tsPM_RclHolder.get()->clear();
				m_tsPM_RclHolder.get()->addCopy(rclHolder.getRcList(1));
				*v8 = m_tsPM_RclHolder.get();
				v192 = "{\"ProcessingFinished\":1}";
			}
			break;
		case ProcessCommands_2F49:
			/*
			Json::Value v174(0);
			v174["sessionLogFolder"] = Json::Value("");
			m_xPM_String2.clear();
			if (pph.getOption(processparams::PROCESSMODE_debugSaveLogs)
			|| pph.getOption(processparams::PROCESSMODE_debugSaveImages)
			|| pph.getOption(processparams::PROCESSMODE_debugSaveCroppedImages)
			|| pph.m_fPPH_debugSaveRFIDSession)
			{
			log::getBufferLog()->resetLog();
			m_xPM_String2 = fs::Path(RegulaConfig::GetTmpPath()).add(system::getCurrentDate()).toString();
			v174["sessionLogFolder"] = Json::Value(m_xPM_String2);
			}
			string v188;
			common::container::jsoncpp::convert(v174, v188);
			v192 = container::json::MergeJson(v192, v188);*/
			
			m_nPM_field_48 = 0;
			m_nPM_field_4C = 0;
			m_xPM_ImgSize.cx = 0;
			m_xPM_ImgSize.cy = 0;

			// "ePC_ProcMgr_StartNewDocument"
			v193 = moduleprocessgl::process(0x2FAD, 0, v72, 0, 0);
			break;
		case ProcessCommands_2F4A:
			// "ePC_ProcMgr_StartNewPage"
			m_nPM_field_48 = 0;
			m_nPM_field_4C ++;
			v193 = moduleprocessgl::process(0x2FB1, &rclHolder, v72, v8, a6);
			break;
		case ProcessCommands_2F4B:
			v193 = moduleprocessgl::process(0xCE, &rclHolder, v72, v8, a6);
			break;
		case ProcessCommands_2F4C:
			// "ePC_ProcMgr_ReadRfid"
			v193 = moduleprocessgl::process(0x30D4, &rclHolder, v189.data(), v8, &v182);
			break;
		case ProcessCommands_2F4D:
			common::dbupdate::checkDB(v72 != 0 ? string(v72) : string(""), v192);
			break;
		case ProcessCommands_2F4E:
			// "ePC_ProcMgr_RestartPage"
			v193 = moduleprocessgl::process(0x2FB4, &rclHolder, v72, v8, a6);
			break;
		case ProcessCommands_2F4F:
			// "ePC_ProcMgr_ComparePortraits"
			v193 = moduleprocessgl::process(0x2FB5, &rclHolder, v72, v8, &v182);
			break;
		case ProcessCommands_2F50:
			if (m_tsPM_RclHolder.get())
			{
				RclHolder * v83 = m_tsPM_RclHolder.get();
				v83->remove(0x1F);
				//if (licensing::getLicense())
				//{
				//	TResultContainer v174;
				//	v174.nTRC_result_type = 0x1F;
				//	if (!v190["processParam"]["xmlResults"].isBool() || v190["processParam"]["xmlResults"].asBool())
				//	{
				//		XmlSerializerInternal v195;
				//		v195.bXSI_field_7C = 1;
				//		v195.wsXSI_field_70 = UnicodeUtils::UncheckedUtf8ToWStr(packageversion::getCoreVersion());
				//		v195.wsXSI_field_40 = UnicodeUtils::UncheckedUtf8ToWStr(packageversion::getCoreVersion());
				//		v195.wsXSI_field_4C = L"V";
				//		v195.sXSI_field_64 = ""; // TRegulaDeviceProperties.LabelSerialNumberStr
				//		v195.makeXML(v174);
				//	}
				//	*v8 = v83;
				//	v83->addWithOwnership(v174);
				//	break;
				//}
				//v193 = 5;
				break;
			}
			v193 = 4;
			break;
		default:
			// license
			if (a2 != 0xCD)
			{
				if (a2 == 0xCE)
				{
					m_bPM_field_4 = false;
					m_spPM_HeartbeatHelper = 0;
				}
				else
				{
					v193 = 1;
				}
			}
			break;
		}

		if (1)
		{
			if (v182)
			{
				string v195(v182);
				if (!v195.empty())
				{
					v192 = common::container::json::MergeJson(v192, v195);
				}
			}
			TResultContainerList * v134 = (TResultContainerList *)*v8;
			if (v134)
			{
				RclHolder v195(*v134, true);
				if (pph.getOption(processparams::PROCESSMODE_debugSaveCroppedImages))
				{
					if (!rclhelp::bounds::getBoundsResult(v195, BoundsResultStatus_1).empty())
					{
						procmgr::develop::saveImage(v195, processparams::PROCESSMODE_debugSaveCroppedImages, m_xPM_String2,
							m_nPM_field_4C, m_nPM_field_48, 20);
					}
				}

				string v188 = common::container::json::getTransactionInfoJson(m_xPM_Guid2);
				v192 = common::container::json::MergeJson(v192, v188);
				RclHolder v174;
				v174.addNoCopy(*v134);
				filterRclForSerialization(v174, pph.m_vPPH_resultTypeOutput);
				string v181 = serializeRclToJson(v174, "ContainerList");
				v192 = common::container::json::MergeJson(v192, v181);
			}
		}
		else
		{
			*v8 = 0;
			v193 = 5;
			v182 = 0;
		}
		m_xPM_String1 = v192;
		if (a6)
		{
			*a6 = (char *)m_xPM_String1.data();
		}
		if (pph.getOption(processparams::PROCESSMODE_debugSaveLogs))
		{
			/*
			fs::mkDir(m_xPM_String2);
			string v188 = log::getBufferLog()->getLog();
			filesystemutils::appendFile(string(fs::Path(m_xPM_String2).add(fs::Path("log.txt"))), v188.data(), v188.length());
			filesystemutils::writeFile(fs::Path(m_xPM_String2).add(fs::Path("results.json")).toString(), m_xPM_String1.data(), m_xPM_String1.length());
			log::getBufferLog()->resetLog();
			*/
		}

		return v193;
	}

	void ProcMgr::updateAppConfigParams(Json::Value &a2)
	{
		if (!m_xPM_Params.empty())
		{
			if (!a2["processParam"].isMember("documentIdList") || a2["processParam"]["documentIdList"].empty())
			{
				if (m_xPM_Params.isMember("documentIdList"))
				{
					a2["processParam"]["documentIdList"] = Json::Value(m_xPM_Params["docIdProcessFilter"]);
				}
			}
		}
	}

	void ProcMgr::updateScenarioParams(string & a2, Json::Value & a3)
	{
		if (!a2.empty())
		{
			if (!m_xPM_Params.empty())
			{
				if (!a3["processParam"].isMember("customParams"))
				{
					if (m_xPM_Params.isMember("scenario"))
					{
						Json::Value v36(Json::json_type_null);
						for (Json::ValueIteratorBase iter = m_xPM_Params["scenario"].begin(); iter != m_xPM_Params["scenario"].end(); iter.increment())
						{
							Json::Value v12 = iter.deref();
							if (v12.get("name", Json::Value("")).asString() == a2)
							{
								v36 = Json::Value(v12);
								break;
							}
							if (v12.get("name", Json::Value("")).asString() == "all")
							{
								v36 = Json::Value(v12);
							}
							iter.increment();
						}
						if (!v36.empty())
						{
							a3["processParam"]["customParams"] = Json::Value(v36["customParams"]);
						}
					}
				}
			}
		}
	}

	namespace bounds
	{
		void addBoundsResult(Json::Value const&xJV_Param1, common::container::RclHolder &xRH_Param2)
		{
			if (xJV_Param1["processParam"].isMember("docPosition"))
			{
				tagSIZE s = rclhelp::imageSize(xRH_Param2.m_xTRCL);
				if (s.cy)
				{
					TBoundsResult tbr = { 0 };
					tbr.cTBR_PerspectiveTr = 1;
					Json::Value jv1 = xJV_Param1["processParam"]["docPosition"];
					tbr.xTBR_LeftBottom.x = jv1["LeftBottom"].get("x", Json::Value(-1)).asInt();
					tbr.xTBR_LeftBottom.y = jv1["LeftBottom"].get("y", Json::Value(-1)).asInt();
					tbr.xTBR_RightBottom.x = jv1["RightBottom"].get("x", Json::Value(-1)).asInt();
					tbr.xTBR_RightBottom.y = jv1["RightBottom"].get("y", Json::Value(-1)).asInt();
					tbr.xTBR_RightTop.x = jv1["RightTop"].get("x", Json::Value(-1)).asInt();
					tbr.xTBR_RightTop.y = jv1["RightTop"].get("y", Json::Value(-1)).asInt();
					tbr.xTBR_LeftTop.x = jv1["LeftTop"].get("x", Json::Value(-1)).asInt();
					tbr.xTBR_LeftTop.y = jv1["LeftTop"].get("y", Json::Value(-1)).asInt();
					if (xJV_Param1["processParam"].get("doFlipYAxis", Json::Value(false)).asBool())
						common::bounds::invertByH(tbr, s.cy);
					common::bounds::updateDocumentSizeByCoordinates(tbr);
					xRH_Param2.addNewCopy(85, &tbr, sizeof(TBoundsResult));
				}
			}
		}
	}

	namespace barcode {

		int addExternalBarcode(Json::Value &a1, common::container::RclHolder &a2)
		{
			if (rclhelp::findFirstContainer(&a2.m_xTRCL, 5))
				return 0;
			CDocBarCodeInfo v39;
			map<string, eBarCodeType> v38 = {
				map<string, eBarCodeType>::value_type("bct_QRCODE", BarCodeType_E),
				map<string, eBarCodeType>::value_type("bct_AZTEC", BarCodeType_F),
				map<string, eBarCodeType>::value_type("bct_DATAMATRIX", BarCodeType_10),
				map<string, eBarCodeType>::value_type("bct_PDF417", BarCodeType_5)
			};
			map<string, eBarCodeType> v37 = {
				map<string, eBarCodeType>::value_type("Code128", BarCodeType_1),
				map<string, eBarCodeType>::value_type("Code39", BarCodeType_2),
				map<string, eBarCodeType>::value_type("Code39Mod43", BarCodeType_2),
				map<string, eBarCodeType>::value_type("Code93", BarCodeType_B),
				map<string, eBarCodeType>::value_type("ean13", BarCodeType_D),
				map<string, eBarCodeType>::value_type("ean8", BarCodeType_3),
				map<string, eBarCodeType>::value_type("interleaved2of5", BarCodeType_4),
				map<string, eBarCodeType>::value_type("itf14", BarCodeType_4),
				map<string, eBarCodeType>::value_type("upce", BarCodeType_C)
			};
			Json::Value v35 = a1["barcodeData"];
			if (v35.isNull() || !v35.isArray())
				return 0;
			for (Json::ValueIteratorBase v41 = v35.begin(); v41 != v35.end(); v41.increment())
			{
				Json::Value v11 = v41.deref();
				string v42 = v11["type"].asString();
				if (v42 == "bct_QRCODE" || v42 == "bct_AZTEC")
				{
					string v36 = v11["data"].asString();
					if (v36.size())
					{
						CDocBarCodeField* v21 = v39.add();
						if (v21)
						{
							v21->load(v36);
							v21->nDBCF_bcTextFieldType = 50;
							if (v38.find(v42) != v38.end())
							{
								v21->nDBCF_bcType_DETECT = 2;
								v21->nDBCF_bcType_DECODE = v38[v42];
							}
							if (v37.find(v42) != v37.end())
							{
								v21->nDBCF_bcType_DETECT = 1;
								v21->nDBCF_bcType_DECODE = v37[v42];
							}
							v21->xDBCF_bcROI_DETECT.left = v11["bounds"]["x"].asInt();
							v21->xDBCF_bcROI_DETECT.top = v11["bounds"]["y"].asInt();
							v21->xDBCF_bcROI_DETECT.right = v11["bounds"]["width"].asInt() + v21->xDBCF_bcROI_DETECT.left;
							v21->xDBCF_bcROI_DETECT.bottom = v11["bounds"]["height"].asInt() + v21->xDBCF_bcROI_DETECT.top;
						}
					}
				}
			}

			if (v39.nDBCI_nFields && v39.pDBCI_pArrayFields)
			{
				a2.addCopy(rclhelp::container(5, (uchar*)&v39, 8u));
			}

			return 0;
		}
	}

	namespace develop {

		void saveImage(TResultContainer *pTRC_Param1, processparams::eProcessMode eParam2, string const& strParam3,
			int nParam4, int nParam5, int nParam6, int nParam7, int nParam8)
		{
			if (!pTRC_Param1 || !pTRC_Param1->u.pTRC_CHAR || !strParam3.length())
				return;
			common::fs::mkDir(common::fs::Path(strParam3));
			string strTemp = processparams::ProcessModeConvertor::convert(eParam2);
			strTemp = "";
			if (eParam2 == processparams::PROCESSMODE_debugSaveCroppedImages)
			{
				strTemp = "_out";
			}
			else if (eParam2 == processparams::PROCESSMODE_debugSaveImagesCroppedByFrame)
			{
				strTemp = "_croppedByFrame";
			}
			if (nParam5 >= nParam8)
			{
				stringstream ss;
				ss << "image_" << nParam4 << "_" << (nParam5 - nParam8) << "_" << nParam6 << "_" << nParam7 << strTemp << ".bmp";
				common::fs::Path path(strParam3);
				path.add(common::fs::Path(ss.str()));
				common::fs::rmFile(common::fs::Path(path.toString()));
			}
			stringstream ss;
			ss << "image_" << nParam4 << "_" << nParam5 << "_" << nParam6 << "_" << nParam7 << strTemp << ".bmp";
			common::fs::Path path(strParam3);
			path.add(common::fs::Path(ss.str()));
			wstring wsPath = path.toWString();
			common::container::RclHolder rh;
			rh.addCopy(*pTRC_Param1);
			if (eParam2 == processparams::PROCESSMODE_debugSaveImages)
			{
				common::images::FlipImage(rh.m_xTRCL, imaging::RI_FLIPMODES_1);
			}
			vector<TResultContainer *> vTRC = rh.getRcList();
			CImageHelper ihl;
			ihl.init(vTRC[0]);
			ihl.WriteToFile(wsPath.data(), imaging::RI_ImageFormats_0);
		}

		void saveImage(common::container::RclHolder & xRH_Param1, processparams::eProcessMode eParam2,
			string const& strParam3, int nParam4, int nParam5, int nParam6)
		{
			vector<TResultContainer *> vTRC = xRH_Param1.getRcList(1);
			for (uint i = 0; i < vTRC.size(); i++)
			{
				saveImage(vTRC[i], eParam2, strParam3, nParam4, nParam5, i, vTRC[i]->nTRC_light, 100);
			}
		}
	}

	namespace face
	{
		void printFacePosition(Json::Value & xJV_Param)
		{
			if (!xJV_Param.isNull() && !xJV_Param.empty() && xJV_Param.isArray())
			{
				for (size_t i = 0; i < xJV_Param.size(); i++)
				{
					Json::Value jv = xJV_Param[i];
					if (!jv.isNull() && jv.isObject())
					{
						Json::Value jv1 = jv["bounds"];
						if (!jv1.isNull() && jv1.isObject())
						{
							string strTemp("face position: x=%d, y=%d, w=%d, h=%d, angle=%d");
							int x = jv1["x"].asInt();
							int y = jv1["y"].asInt();
							int width = jv1["width"].asInt();
							int height = jv1["height"].asInt();
							int rollAngle = jv1["rollAngle"].asInt();
						}
					}
				}
			}
		}

		void rotateFaceMetadata(Json::Value & xJV_Param1, eRPRM_Orientation eParam2, tagSIZE const& xParam3)
		{
			if (!xJV_Param1.isNull() && xJV_Param1.isArray())
			{
				for (uint i = 0; i < xJV_Param1.size(); i++)
				{
					Json::Value jv = xJV_Param1[i];
					if (!jv.isNull() && jv.isObject())
					{
						Json::Value jv1 = jv["bounds"];
						if (!jv1.isNull() && jv1.isObject())
						{
							tagPOINT p;
							tagSIZE s;
							p.x = jv1["x"].asInt();
							p.y = jv1["y"].asInt();
							s.cx = jv1["width"].asInt();
							s.cy = jv1["height"].asInt();
							int rollAngle = jv1["rollAngle"].asInt();
							common::rotate::rotatePoint(p, eParam2, xParam3, s);
							common::rotate::rotateSize(s, eParam2);
							common::rotate::rotateAngle(rollAngle, eParam2);
							jv1["x"] = Json::Value(p.x);
							jv1["y"] = Json::Value(p.y);
							jv1["width"] = Json::Value(s.cx);
							jv1["height"] = Json::Value(s.cy);
							jv1["rollAngle"] = Json::Value(rollAngle);
						}
					}
				}
			}
		}
	}

	namespace imageconvert
	{
		int getImageFromJson(eProcessCommands eParam1, Json::Value & xJV_Param2, common::container::RclHolder & xRH_Param3)
		{
			if (eParam1 != ProcessCommands_2F45 && eParam1 != ProcessCommands_2F46 && eParam1 != ProcessCommands_2F48 && eParam1 != ProcessCommands_2F4F)
				return 1;
			Json::Value jv = xJV_Param2["imagesList"];
			if (!jv.isArray())
				return 1;
			CImageHelperLib ihl;
			for (Json::ValueIteratorBase iter = jv.begin(); iter != jv.end(); iter.increment())
			{
				Json::Value xJV = iter.deref();
				uchar *p11 = (uchar *)xJV["ptr"].asLargestUInt();
				uint64 n15 = xJV["size"].asUInt64();
				string strData = xJV["data"].asString();
				string strTemp;
				if (!p11 && !n15)
				{
					if (!strData.length())
						continue;
					strTemp = common::Base64::base64_decode(strData);
					n15 = strTemp.length();
					if (!n15)
						continue;
					p11 = (uchar *)strTemp.data();
				}
				if (!p11 || !n15)
					continue;
				uint light = xJV["light"].asUInt();
				uint pageIdx = xJV["pageIdx"].asUInt();
				if (!ihl.InitFromBuffer(p11, (uint)n15))
				{
					if (ihl.m_pxIHL_4)
					{
						ihl.m_pxIHL_4->nTRC_page_idx = pageIdx;
						ihl.m_pxIHL_4->nTRC_light = (eRPRM_Lights)light;
						xRH_Param3.addCopy(*ihl.m_pxIHL_4);
					}
				}
			}
			return 0;
		}

		bool cropImage(Json::Value & xJV_Param1, common::container::RclHolder & xRH_Param2, float fParam3, tagPOINT & xParam4)
		{
			tagSIZE s = rclhelp::imageSize(xRH_Param2.m_xTRCL);
			if (!xJV_Param1.isMember("frameLeft") || !xJV_Param1.isMember("frameRight") ||
				!xJV_Param1.isMember("frameBottom") || !xJV_Param1.isMember("frameTop"))
				return false;
			int fL = xJV_Param1["frameLeft"].asInt();
			int fR = xJV_Param1["frameRight"].asInt();
			int fB = xJV_Param1["frameBottom"].asInt();
			int fT = xJV_Param1["frameTop"].asInt();
			int w = fR - fL, h = fB - fT;
			if (w < 1 || h < 1)
				return false;
			int n24, n25, n56, fRa;
			if (fParam3 <= 0.0)
			{
				n24 = n25 = n56 = fRa = 0;
			}
			else
			{
				int n23 = (int)(fParam3 * min(h , w));
				n24 = fB + n23;
				n25 = fR + n23;
				n56 = fT - n23;
				fRa = (((fL - n23) < 0) ? 0 : (fL - n23));
			}
			if (n24 > s.cy)
				n24 = s.cy;
			if (n25 > s.cx)
				n25 = s.cx;
			if (n56 < 0)
				n56 = 0;
			int n29 = fT - n56;
			int n28 = xJV_Param1.get("rotation", Json::Value(0)).asInt();
			switch (n28)
			{
			case -90:
				xJV_Param1["frame"]["frameLeft"] = Json::Value(n29);
				xJV_Param1["frame"]["frameTop"] = Json::Value(n25 - (fL + w));
				xJV_Param1["frame"]["frameRight"] = Json::Value(n29 + h);
				xJV_Param1["frame"]["frameBottom"] = Json::Value(n25 - fL);
				break;
			case 90:
				xJV_Param1["frame"]["frameLeft"] = Json::Value(n56 - fT);
				xJV_Param1["frame"]["frameTop"] = Json::Value(fL - fRa);
				xJV_Param1["frame"]["frameRight"] = Json::Value(h - n29);
				xJV_Param1["frame"]["frameBottom"] = Json::Value(fL - fRa + w);
				break;
			case 0:
				xJV_Param1["frame"]["frameLeft"] = Json::Value(fL - fRa);
				xJV_Param1["frame"]["frameTop"] = Json::Value(n29);
				xJV_Param1["frame"]["frameRight"] = Json::Value(fL - fRa + w);
				xJV_Param1["frame"]["frameBottom"] = Json::Value(n29 + h);
				break;
			}
			tagRECT r;
			r.left = fRa;
			r.bottom = n24;
			r.top = n25;
			r.right = n56;
			bool fRet = common::images::CropImage(xRH_Param2.m_xTRCL, r);
			xParam4.x = fRa;
			xParam4.y = n56;
			return fRet;
		}
	}

	namespace json
	{
		void updateFacePos(Json::Value & xJV_Param1, tagPOINT & xParam2)
		{
			if (xJV_Param1.isMember("faceMetadata"))
			{
				Json::Value jv = xJV_Param1["faceMetadata"];
				for (Json::ValueIteratorBase iter = jv.begin(); iter != jv.end(); iter.increment())
				{
					Json::Value pJV = iter.deref();
					pJV["bounds"]["x"] = Json::Value(pJV["bounds"]["x"].asInt() - xParam2.x);
					pJV["bounds"]["y"] = Json::Value(pJV["bounds"]["y"].asInt() - xParam2.y);
				}
			}
		}

		void updateBarcodePos(Json::Value & xJV_Param1, tagPOINT & xParam2)
		{
			if (xJV_Param1.isMember("barcodeData"))
			{
				Json::Value jv = xJV_Param1["barcodeData"];
				for (Json::ValueIteratorBase iter = jv.begin(); iter != jv.end(); iter.increment())
				{
					Json::Value pJV = iter.deref();
					pJV["bounds"]["x"] = Json::Value(pJV["bounds"]["x"].asInt() - xParam2.x);
					pJV["bounds"]["y"] = Json::Value(pJV["bounds"]["y"].asInt() - xParam2.y);
					Json::Value jv1 = pJV["corners"];
					for (Json::ValueIteratorBase iter1 = jv1.begin(); iter1 != jv1.end(); iter1.increment())
					{
						Json::Value pJV1 = iter1.deref();
						pJV1["x"] = Json::Value(pJV1["x"].asInt() - xParam2.x);
						pJV1["y"] = Json::Value(pJV1["y"].asInt() - xParam2.y);
					}
				}
			}
		}

		void updateCreditCardScenario(Json::Value & xJV_Param)
		{
			if (xJV_Param.isMember("processParam"))
			{
				if (xJV_Param["processParam"].isMember("scenario"))
				{
					if (xJV_Param["processParam"]["scenario"] == "CreditCard")
					{
						xJV_Param["processParam"]["scenario"] = Json::Value("Ocr");
						xJV_Param["processParam"]["mrzDetect"] = Json::Value(false);
						xJV_Param["recpassParam"]["countryFilter"] = Json::Value("!BC");
						Json::Value jvTemp(Json::json_type_array);
						jvTemp.append(Json::Value(493));
						xJV_Param["imSegParam"]["seriesProcess"]["necessaryFieldType"] = Json::Value(jvTemp);
						xJV_Param["imSegParam"]["seriesProcess"]["minProbThresholdDnn"] = Json::Value(101);
						xJV_Param["processParam"]["timeoutFromFirstDetect"] = Json::Value(0);
						xJV_Param["processParam"]["timeoutFromFirstDocType"] = Json::Value(0);
					}
				}
			}
		}
	}

	namespace license
	{
		int checkLicense(int, Json::Value &, string &)
		{
			return 0;
		}

		int initLicense(Json::Value &, string &)
		{
			return 0;
		}
	}

	namespace timeout
	{
		void configureTimeOut(Json::Value& xJV_Param)
		{
			int to = xJV_Param["processParam"].get("timeout", Json::Value(-1)).asInt();
			int toffd = xJV_Param["processParam"].get("timeoutFromFirstDetect", Json::Value(-1)).asInt();
			int toffdt = xJV_Param["processParam"].get("timeoutFromFirstDocType", Json::Value(-1)).asInt();
			if (to == -1)
			{
				to = toffd;
				if (toffd < toffdt)
					to = toffdt;
				if (to <= 20000)
					to = 20000;
			}
			if (toffd == -1)
			{
				toffd = to;
				if (to >= 5000 || to < 1)
					toffd = 5000;
				if (toffdt == -1)
				{
					toffdt = 3000;
				}
				else if (toffd < toffdt)
				{
					toffd = toffdt;
				}
			}
			else if (toffdt == -1)
			{
				toffdt = 3000;
			}
			if (toffd < toffdt)
				toffdt = toffd;
			setTimeOut(xJV_Param, to, toffd, toffdt);
		}

		void setTimeOut(Json::Value& xJV_Param1, int nParam2, int nParam3, int nParam4)
		{
			xJV_Param1["processParam"]["timeout"] = Json::Value(nParam2);
			xJV_Param1["processParam"]["timeoutFromFirstDetect"] = Json::Value(nParam3);
			xJV_Param1["processParam"]["timeoutFromFirstDocType"] = Json::Value(nParam4);
		}
	}
}