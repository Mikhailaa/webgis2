#pragma once

#include "pch.h"

#include "ImageControl.h"
//#include "imgStructs.h"

namespace rcvmat {
	enum typePosition
	{

	};

	enum cvTypeSearchigImage
	{

	};

	namespace RCVRect {
		Rect crossing(Rect a1, Size a2);
		Rect fromDib(tagRECT a1);
		Rect increaseForCenter(Rect & a1, Size a2);
		tagRECT regRect(Rect & a1);
		Rect reverseHeight(Rect a1, int a2);
		Rect reverseHeight(tagRECT const & a1, int a2);
	};

	namespace RCVMat {
		void and__(Mat & a1, Mat & a2);
		void load(Mat const & a1, Mat & a2);
		void load(Mat const & a1, Mat & a2, Rect a3);
		void load(Mat const& a1, Mat & a2, tFullColors_cv a3);
		void numberPointInRange(vector<int> & a1, int a2, int a3, int & a4);
		void rotate(Mat & a1, Mat & a2, int a3);
		void threshold(Mat & a1, double a3, double a4, int a5);
		int calcHist(Mat const & a1, vector<int> & a2, int a3, int a4, int a5);
		int countNonZero(Mat & a1);
		int dilate(Mat & a1, Mat & a2, Size a3);
		int dynamicRange(vector<int> & a1, int a2, int a3, int & a4, int & a5, int & a6);
		int flip(Mat & a1);
		int find(Mat const & a1, Mat const & a2, float & a3, float & a4, float & a5, cvTypeSearchigImage a6, int a7);
		int histCenter(vector<int> & a1, float & a2, int a3, int a4);
		int load(RawImageContainerR * a1, Mat & a2);
		int open(Mat & a1, Mat & a2, Size a3);
		int projection(Mat & a1, Mat & a2, int a3);
		int resize(Mat const & a1, Mat & a2, Size a3);
		int rotate(Mat const & a1, Mat & a2, double a3, double a4, double a5, Scalar & a6);
		int rotateCenter(Mat const & a1, Mat & a2, double a3, int a4, Scalar a5);
		int sobel(Mat const & a1, Mat & a2, rcvmat::typePosition a3);
	};
};