#pragma once
#include <string>
#include <map>
#include "UnicodeUtils.h"
#include <regex>
#include <sstream>
#include "../commonStruct.h"

using namespace std;

namespace common
{
	string toBase64(TRawImageContainer const&);

	namespace StringUtils
	{
		template<typename T>
		basic_string<T> Replace(basic_string<T> &a2, basic_string<T> const&a3, basic_string<T> const&a4)
		{
			basic_string<T> a1;
			if (a3.empty() || a3 == a4)
			{
				return move(a2);
			}
			uint v18 = 0;
			while (v18 < a2.size())
			{
				v18 = a2.find(a3, v18);
				if (v18 == basic_string<T>::npos) break;
				a2.replace(v18, a3.size(), a4.data(), a4.size());
				if (a4.size() > a3.size())
					v18 += a4.size();
			}
			return move(a2);
		}

		template<typename T>
		basic_string<T> Replace(basic_string<T> const& a2, const T& a3, const T& a4)
		{
			return Replace(a2, basic_string<T>(1, a3), basic_string<T>(1, a4));
		}

		string ToBase64(string const& a2);
		string FromBase64(string const& a2);
		string Encode(string const& a2);
		string Decode(string const& a2);
		string FromHexStr(string const& a2);
		string FromZip(string const& a2);
		string FromZip(uchar const*, uint);

		template<typename T>
		T LeftTrim(T const& a2)
		{
			uint i, v6 = a2.size();
			const T::value_type* v5 = a2.data();
			for (i = 0; i < v6; i ++)
			{
				if (LeftTrim_Lambda(v5[i]))
					break;
			}
			return T(&v5[i], &v5[v6]);
		}

		template<typename T>
		bool LeftTrim_Lambda(const T a2)
		{
			locale loc;
			return !isspace<T>(a2, loc);
		}

		template<typename T>
		int LenCommonSubStr(T const& a1, T const& a2)
		{
			uint v4 = a2.size();
			uint v6 = a1.size();
			vector<vector<int>> v22(v6 + 1);
			vector<vector<int>>::iterator i;
			for (i = v22.begin(); i != v22.end(); i++)
				i->resize(v4 + 1);
			int v11 = 0;
			for (uint j = 0; j <= v6; j ++)
			{
				for (uint k = 0; k <= v4; k ++)
				{
					if (j && k)
					{
						if (a1[j - 1] == a2[k - 1])
						{
							int v17 = v22[j - 1][k - 1];
							v22[j][k] = v17 + 1;
							if (v11 <= v17) v11 = v17 + 1;
						}
						else 
							v22[j][k] = 0;
					}
					else 
						v22[j][k] = 0;
				}
			}
			return v11;
		}

		string RemoveExtraSymbols(string const& a2);
		wstring RemoveExtraSymbols(wstring const& a2);
		string ReplaceSymbols(string const& a2, string const& a3, string const& a4, bool a5);

		template<typename T>
		bool RightTrim_Lambda(const T a2)
		{
			return LeftTrim_Lambda(a2);
		}

		template<typename T>
		T RightTrim(T const& a2)
		{
			const T::value_type* v4 = a2.data();
			uint i, v3 = a2.size();
			for (i = 0; i < v3; i ++)
			{
				if (RightTrim_Lambda(v4[v3 - i - 1]))
					break;
			}
			return T(v4, &v4[v3 - i]);
		}

		template<typename T>
		vector<T> Split(T const& a2, T const& a3)
		{
			vector<T> a1;
			uint i = 0;
			while (i < a2.size())
			{
				uint v8 = a2.find(a3, i);
				if (v8 == T::npos)
					break;
				a1.push_back(T(a2, i, v8 - i));
				i = v8 + a3.size();
			}
			if(i < a2.size())
				a1.push_back(T(a2, i));
			return a1;
		}

		template<typename T>
		vector<T> Split(T const& a2, typename T::value_type a3)
		{
			T str(1, a3);
			return Split(a2, str);
		}

		template<typename T>
		T Trim(T const& a2)
		{
			return LeftTrim(RightTrim(a2));
		}

		template<typename T>
		bool contains(T const& a2, T const& a3)
		{
			if (!a2.size() || !a3.size()) return false;
			uint v11 = a2.find(a3);
			return v11 != T::npos;
		}

		char* duplicateNullTerminatedString(char const* a2);
		string getCurrentTimeString();
		float toFloat(string const& a2);

		template<typename T>
		int toInt(basic_string<T> const& a2)
		{
			basic_istringstream<T> str(a2);
			int rlt = 0;
			str >> rlt;
			return rlt;
		}

		template<typename T>
		int toInt(T a2)
		{
			basic_stringstream<T> str;
			str << a2;
			int rlt = 0;
			str >> rlt;
			return rlt;
		}

		template<typename T>
		__int64 toInt64(basic_string<T> const& a2)
		{
			basic_istringstream<T> str(a2);
			__int64 rlt = 0;
			str >> rlt;
			return rlt;
		}

		template<typename T>
		basic_string<T> toLower(basic_string<T> const& a2)
		{
			basic_string<T> a1;
			locale loc;
			for (uint i = 0; i < a2.size(); i++)
				a1 += tolower(a2[i], loc);

			return a1;
		}

		template<typename T>
		T toLower(T a2)
		{
			locale loc;
			return tolower(a2, loc);
		}

		uint toSize(string const& a2);

		template<typename T>
		string toString(T a2)
		{
			stringstream str;
			str << a2;
			return str.str();
		}

		template<typename T>
		basic_string<T> toUpper(basic_string<T> const& a2)
		{
			basic_string<T> a1;
			locale loc;
			for (uint i = 0; i < a2.size(); i++)
				a1 += toupper(a2[i], loc);
			return a1;
		}

		template<typename T>
		T toUpper(T a2)
		{
			locale loc;
			return toupper(a2, loc);
		}

		template<typename T>
		wstring toWString(T a2)
		{
			wstringstream str;
			str << a2;
			return str.str();
		}
	}
}


