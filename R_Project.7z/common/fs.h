#pragma once
#include <string>
#include <vector>

#ifdef ANDROID_NDK
#define SLASH "/"
#define CSLASH '/'
#define DSLASH "//"
#define RSLASH "\\"
#else
#define SLASH "\\"
#define CSLASH '\\'
#define DSLASH "\\\\"
#define RSLASH "/"
#endif

using namespace std;

namespace common
{
	namespace fs
	{
		class Path
		{
		public:
			string m_str1, m_str2;

			Path(void);
			~Path(void);
			Path(const char* a2);
			Path(const string& a2);
			Path(const Path& a2);
			Path(const wstring& a2);
			Path(const wchar_t* a2);

			operator string();
			operator wstring();
			string toString(void) const;
			wstring toWString(void);
			Path& operator=(const Path& a2);
			bool isSame(const Path& a2);
			bool operator!=(const Path& a2);
			Path& add(const Path& a2);
			Path& operator+=(const Path& a2);
			bool operator<(const Path& a2);
			bool operator==(const Path& a2);
			string toOriginString(void);
			wstring toOriginWString(void);
			Path getPathBase(void) const;
			string getFileName(void) const;
			wstring getWFileExt(void);
			wstring getWFileName(void);
			wstring getWFileNameBase(void);
			string getFileExt(void);
			string getFileNameBase(void);
			void setFileExt(const string& a2);
			string& setDelim(const string& a2);
			bool isEmpty(void) const;
			bool isAbsolute(void);
			Path& Path::clear(void);
		};

		Path generateTimeFolderName(const Path& a2);
		Path generateUUIDFolderName(const Path& a2);
		bool isExist(const Path& a2);
		vector<string> convert(const vector<Path>& a2);
		vector<Path> getAllFolders(const Path& a2);
		void cpDir(const Path& a1, const Path& a2);
		vector<Path> getFolderFileList(const Path& a2);
		vector<Path> getFolderList(const Path& a2);
		vector<Path> getFileList(const Path& a2);
		void cpFile(const Path& a1, const Path& a2);
		__time64_t getFileAccessTime(const Path& a2);
		__time64_t getFileWriteTime(const Path& a2);
		unsigned long long getFileSize(const Path& a2);
		bool isDir(const Path& a1);
		bool mkDir(const Path& a1);
		bool mvFile(const Path& a1,const Path& a2);
		bool rmFile(const Path& a1);
		Path operator+(const Path& a1,const Path&a2);
		Path operator/(const Path& a1,const Path&a2);
		bool rmDir(const Path& a1);
	};
}



