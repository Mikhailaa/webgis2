#include "ModuleOrchestrator.h"

namespace common
{
	ModuleOrchestrator::ModuleOrchestrator()
	{
	}

	ModuleOrchestrator::~ModuleOrchestrator()
	{
	}

	ModuleOrchestrator *getModuleOrchestrator()
	{
		static ModuleOrchestrator g_MO_11410D4;
		return &g_MO_11410D4;
	}
}
