#pragma once
#include <xstring>
#include <istream>
#include <map>

using namespace std;

typedef unsigned long long ulonglong;

namespace common
{
	class FileHeader
	{
	public:
		FileHeader();
		FileHeader(common::FileHeader const&);
		~FileHeader() {};
		ulonglong Deserialize(char const*, ulonglong);
		FileHeader& operator=(common::FileHeader const&);
		
	public:
		string m_strFH_name;
		ulonglong m_ulFH_off;
		ulonglong m_ulFH_size;
	};

	class FileFsReader
	{
	public:
		FileFsReader(istream &);
		~FileFsReader();
		string DecodeData(string);
		string GetFileData(string const&);
		bool Load(void);

	public:
		istream* m_pisFR_stream;
		ulonglong m_ulFR_dataoff;
		map<string, FileHeader> m_mapFR_FileHeader;
	};
};

