#pragma once
#include "../pch.h"
#include "StringUtils.h"

namespace common
{
	namespace FilesystemUtils
	{
		uchar* GetMemoryMappedFile(wstring const& a2, ulonglong& a3);
		uchar* GetMemoryMappedFile(string const& a2, ulonglong& a3);
		bool IsDirectoryExists(const string& a2);
		bool IsDirectoryExists(wstring const&);
		bool IsFileExists(const string& a2);
		bool FileExists(const string& a2);
		bool FileExists(const wstring& a2);
		bool MkDir(string const&);
		bool MkDir(wstring const&);
		bool Delete(const string& a1);
		string GetCurrentDir();
		wstring GetCurrentDirW();
		__time64_t GetFileLastWriteTime(const string& a1);
		__time64_t GetFileLastWriteTime(const wstring& a1);
		string GetTmpDir();
		wstring GetTmpDirW();
		void ReleaseMemoryMappedFile(uchar *&);
		
		template <typename T> T GetPathBase(const T& a2)
		{
			T v10 = GetPathFilename(a2);
			T v9(a2);
			v9.erase(a2.size() - v10.size(), (uint)(-1));
			return NormalizePath(v9);
		};
		
		template <typename T> T GetPathFilename(const T& a2)
		{
			T v12 = PathTraits<T>::getForwardSlash();
			T v11 = NormalizePath(a2);
			if (!v11.size() || v11[v11.size() - 1] == v12[0])
				return T();
			return SplitPath(a2).back();
		};

		template <class _Tx, class _Ty> _Tx JoinPath(_Tx const&a2, _Ty a3)
		{
			basic_stringstream<typename _Tx::value_type> ss;
			JoinPathDetail(ss, a2, a3);
			return NormalizePath(ss.str());
		};

		template <class _Tx, class _Ty> void JoinPathDetail(basic_stringstream<_Tx> &a1, basic_string<_Tx> const&a2, _Ty const&a3)
		{
			if (a2.size())
			{
				basic_string<_Tx> v17 = NormalizePath(a2);
				a1 << v17;
				basic_string<_Tx> v14 = PathTraits<basic_string<_Tx>>::getForwardSlash();
				if (v17[v17.size() - 1] != v14[0])
				{
					a1 << v14;
				}
				a1 << a3;
			}
			else
			{
				a1 << a3;
			}
		};

		template <typename T> void JoinPathDetail(basic_stringstream<T> &a1, T const*a2)
		{
			a1 << basic_string<T>(a2);
		};

		template <typename T> T NormalizePath(T const&a2)
		{
			T a1(a2), v72(a2);
			T v73 = PathTraits<T>::getBackSlash();
			T v74 = PathTraits<T>::getForwardSlash();
			a1 = common::StringUtils::Replace(a1, v73 + v74, v74);
			while (a1 != v72)
			{
				a1 = v72;
				v72 = common::StringUtils::Replace(a1, v73 + v74, v74);
			}
			a1 = common::StringUtils::Replace(a1, v74 + v73, v74);
			while (a1 != v72)
			{
				a1 = v72;
				v72 = common::StringUtils::Replace(a1, v74 + v73, v74);
			}
			a1 = common::StringUtils::Replace(a1, v73 + v73, v73);
			while (a1 != v72)
			{
				a1 = v72;
				v72 = common::StringUtils::Replace(a1, v73 + v73, v73);
			}
			a1 = common::StringUtils::Replace(a1, v74 + v74, v74);
			while (a1 != v72)
			{
				a1 = v72;
				v72 = common::StringUtils::Replace(a1, v74 + v74, v74);
			}
			a1 = common::StringUtils::Replace(a1, v73, v74);
			a1 = common::StringUtils::Trim(a1);
			if (a2.size() >= 3 && a1.size())
			{
				if (a2[0] == a2[1] && (v74[0] == a2[0] || v73[0] == a2[0]))
				{
					a1 = a1[0] + a1;
				}
			}
			return a1;
		};

		template <typename T> vector<T> SplitPath(T const&a2)
		{
			vector<T> a1;
			T v14 = NormalizePath(a2);
			T v12 = PathTraits<T>::getForwardSlash();
			vector<T> v13 = common::StringUtils::Split(v14, v12[0]);
			for (vector<T>::iterator iter = v13.begin(); iter != v13.end(); iter++)
			{
				if (!(*iter).empty())
				{
					a1.push_back(*iter);
				}
			}
			return a1;
		};
		
		template <typename T> class PathTraits
		{
		public:
			static T getBackSlash(void)
			{
#ifdef ANDROID_NDK
				return T("\\");
#else
				return T("/");
#endif
			};
			static T getForwardSlash(void)
			{
#ifdef ANDROID_NDK
				return T("/");
#else
				return T("\\");
#endif
			};
		};
	};

	namespace filesystemutils
	{
		bool appendFile(string const&, char const*, uint);
		int readFile(string const&, string&);
		bool writeFile(string const&, char const*, uint);
		bool writeFile(wstring const&, char const*, uint);
	};
}

