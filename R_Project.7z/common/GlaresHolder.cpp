#include "GlaresHolder.h"
#include "container/RclHolder.h"

namespace common
{
	GlaresHolder::GlaresHolder()
	{
	}
	
	GlaresHolder::GlaresHolder(common::container::RclHolder &)
	{

	}

	GlaresHolder::~GlaresHolder()
	{
	}

	void GlaresHolder::init(TResultContainerList *)
	{

	}

	void GlaresHolder::init(common::container::RclHolder &)
	{

	}

	bool GlaresHolder::isAreaContainsGlares(cv::Rect const&, double)
	{
		return false;
	}

	bool GlaresHolder::isAreaContainsGlares(tagRECT const&, double)
	{
		return false;
	}
}
