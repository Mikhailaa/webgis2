#include "RegulaConfig.h"
#include "common.h"
#include "FilesystemUtils.h"
#include "fs.h"
#include <time.h>

namespace common 
{
	string _tmpPath;

	namespace RegulaConfig
	{
		string getSystemTimeW3C(void)
		{
			char s[100];
			time_t t;
			time(&t);
			tm* gt = gmtime(&t);
			strftime(s, 0x64, "%Y-%m-%dT%H:%M:%S", gt);
			return string(s);
		}

		string GetCompName()
		{
#ifdef ANDROID_NDK
			struct utsname name;
			uname(&name);
			return string(name.machine);
#else
			return string("");
#endif
		}

		string GetCurrentUserName()
		{
#ifdef ANDROID_NDK
			return string(getlogin());
#else
			return string("");
#endif
		}

		string SetRootPath(string const&a2)
		{
			if (common::fs::isDir(common::fs::Path(a2)))
			{
				if (common::FilesystemUtils::IsDirectoryExists(a2))
				{
					RootAppDataPath() = a2;
				}
				else
				{
					common::FilesystemUtils::MkDir(a2);
					RootAppDataPath() = a2;
				}
			}
			
			return RootAppDataPath();
		}

		void SetTmpPath(string const&a1)
		{
			if (a1 != _tmpPath)
			{
				if (common::FilesystemUtils::IsDirectoryExists(a1) ||
					common::FilesystemUtils::MkDir(a1))
					_tmpPath = a1;
			}
		}

		string GetAppDataPath()
		{
			return common::RootAppDataPath();
		}

		string GetDataPath()
		{
			return GetAppDataPath();
		}

		string GetDllPath(string const&a2)
		{
			return RootAppDataPath() + SLASH + a2;
		}

		string GetFilePath(string const&a2)
		{
			return GetDllPath(a2);
		}

		string GetInstallationPath()
		{
			return string("/usr/local/lib/regula/sdk");
		}

		string GetPath(string const&a2)
		{
			return GetDllPath(a2);
		}

		string GetTmpPath()
		{
			static string str_11412C4 = "Regula";
			if (_tmpPath.empty())
				SetTmpPath(common::FilesystemUtils::JoinPath(common::FilesystemUtils::GetTmpDir(), str_11412C4));
			return _tmpPath;
		}

		string GetUpdatesPath()
		{
#ifdef ANDROID_NDK
			return common::FilesystemUtils::JoinPath(GetAppDataPath(), "updates/bin");
#else
			return common::FilesystemUtils::JoinPath(GetAppDataPath(), "updates\\bin");
#endif
		}

		bool IsRegulaLoggingEnabled()
		{
			return false;
		}

		void UpdateLogStatus()
		{
		}
	};
}