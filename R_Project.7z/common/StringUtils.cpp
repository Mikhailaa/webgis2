#include "StringUtils.h"
#include "../imaging.h"
#include "container/container.h"

unsigned char byte_108544C[8] = { 0xED, 0x43, 0x96, 0xCF, 0xAF, 0xD4, 0x2A, 0x93 };
string g_str_1141100("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/");
string g_str_114110C("0123456789ABCDEF");

namespace common
{
	string toBase64(TRawImageContainer const&a2)
	{
		TResultContainer v16;
		imaging::RI_SaveFileParameters v15;
		uchar* v12 = 0;
		uint v11 = 0;

		memset(&v16, 0, sizeof(TResultContainer));
		v16.nTRC_result_type = 1;
		v16.u.pTRC_RIC = (TRawImageContainer*)&a2;
		v16.nTRC_buf_length = 8;
		v15.pxSFP_8 = 0;
		v15.ppSFP_10 = &v12;
		v15.pnSFP_14 = &v11;
		v15.nSFP_C = 0;
		v15.nSFP_0 = 1;
		v15.nSFP_4 = 0x55;
		imaging::WriteToBuffer(&v15, v16);
		if (v12)
		{
			string v9(v12, v12 + v11);
			return StringUtils::ToBase64(v9);
		}
		return string();
	}

	namespace StringUtils
	{
		string ToBase64(string const& a2)
		{
			string a1;

			const char* v3 = a2.data();
			uint v4 = a2.size();
			char v18[4] = { 0 };
			uchar v22[3] = { 0 };
			int j = 0;
			for (uint i = 0; i < a2.size(); i++)
			{
				v22[j++] = v3[i];
				if (j == 3)
				{
					int v11 = 0;
					v18[0] = v22[0] >> 2;
					v18[1] = (v22[1] >> 4) | ((v22[0] & 0x3) << 4);
					v18[2] = (v22[2] >> 6) | ((v22[1] & 0xf) << 2);
					v18[3] = v22[2] & 0x3f;
					for (int k = 0; k <= 3; k++)
					{
						a1 += g_str_1141100[v18[k]];
					}
					j = 0;
				}
			}
			if (j)
			{
				for (int k = j; k <= 2; k++) v22[k] = 0;
				v18[0] = v22[0] >> 2;
				v18[1] = (v22[1] >> 4) | ((v22[0] & 0x3) << 4);
				v18[2] = (v22[2] >> 6) | ((v22[1] & 0xf) << 2);
				v18[3] = v22[3] & 0x3f;
				for (int k = 0; k <= j; k++)
				{
					a1 += g_str_1141100[v18[k]];
				}
				for (int k = j; k <= 2; k++)
					a1 += '=';
			}
			return a1;
		}

		string FromBase64(string const& a2)
		{
			string a1;
			const char* v9 = a2.data();
			char v23[3] = { 0 };
			char v24[4] = { 0 };

			uint v8 = 0;
			for (uint i = 0; i < a2.size(); i++)
			{
				if (v9[i] == '=') break;
				if (v9[i] != '/' && v9[i] != '+' && !isalnum(v9[i]))
					return a1;
				v24[v8++] = v9[i];
				if (v8 == 4)
				{
					for (uint j = 0; j < 4; j++)
						v24[j] = (char)g_str_1141100.find(v24[j]);
					v23[0] = ((v24[1] >> 4) & 0x3) | (v24[0] << 2);
					v23[1] = ((v24[2] >> 2) & 0xf) | (v24[1] << 4);
					v23[2] = v24[3] | (v24[2] << 6);
					for (uint j = 0; j < 3; j++)
						a1 += v23[j];
					v8 = 0;
				}
			}
			if (v8)
			{
				for (uint j = v8; j < 4; j++)
					v24[j] = 0;
				for (uint j = 0; j < 4; j++)
					v24[j] = (char)g_str_1141100.find(v24[j]);
				v23[0] = ((v24[1] >> 4) & 0x3) | (v24[0] << 2);
				v23[1] = ((v24[2] >> 2) & 0xf) | (v24[1] << 4);
				v23[2] = v24[3] + (v24[2] << 6);
				for (uint j = 0; j < v8 - 1; j++)
					a1 += v23[j];
			}
			return a1;
		}

		string Encode(string const& a2)
		{
			string a1;
			uint len = a2.size();
			a1.reserve(len);
			for (uint i = 0; i < len; i++)
			{
				a1 += (a2[i] ^ byte_108544C[i & 7]);
			}
			return a1;
		}

		string Decode(string const& a2)
		{
			return Encode(a2);
		}

		string FromHexStr(string const& a2)
		{
			uint v4 = a2.size();
			if (v4 & 1)
				return string("");
			string result;
			result.reserve(v4 / 2);
			for (uint v6 = 0; v6 < v4 - 1; v6 += 2)
			{
				uint v11 = g_str_114110C.find(toupper(a2[v6]));
				uint v12 = g_str_114110C.find(toupper(a2[v6 + 1]));
				if (v11 == -1 || v12 == -1)
				{
					return string("");
				}
				result += (char)((v11 << 4) | (v12));
			}
			return result;
		}

		string FromZip(string const& a2)
		{
			return string("");
		}

		string FromZip(uchar const*, uint)
		{
			return string("");
		}

		string RemoveExtraSymbols(string const& a2)
		{
			regex v24("[+*\\()<>/#,{}.:;$'=]");
			regex v20("[\\\\]");
			string s = regex_replace(a2, v24, string(""), regex_constants::match_default);
			s = regex_replace(s, v20, string(""), regex_constants::match_default);
			return s;
		}

		wstring RemoveExtraSymbols(wstring const& a2)
		{
			wregex v24(L"[+*\\()<>/#,{}.:;$'=]");
			wregex v20(L"[\\\\]");
			wstring s = regex_replace(a2, v24, wstring(L""), regex_constants::match_default);
			s = regex_replace(s, v20, wstring(L""), regex_constants::match_default);
			return s;
		}

		string ReplaceSymbols(string const& a2, string const& a3, string const& a4, bool a5)
		{
			string a1(a2);

			do
			{
				uint v18 = a1.size();
				for (uint v10 = 0; v10 < a3.size(); v10++)
				{
					a1 = Replace(a1, string(1, a3[v10]), a4);
				}
				if (v18 == a1.size()) break;
			} while (!a5);

			return a1;
		}

		char* duplicateNullTerminatedString(char const* a2)
		{
			if (!a2) return 0;
			size_t v2 = strlen(a2) + 1;
			char* v4 = new char[v2];
			memset(v4, 0, v2);
			strcpy_s(v4, v2, a2);
			return v4;
		}

		string getCurrentTimeString()
		{
			char buf[0x100] = "";
			time_t t = time(0);
			tm* v2 = localtime(&t);
			strftime(buf, 0x100, "%Y.%m.%d-%H.%M.%S", v2);
			return string(buf);
		}

		float toFloat(string const& a2)
		{
			istringstream str(a2);
			float rlt = 0.0f;
			str >> rlt;
			return rlt;
		}

		uint toSize(string const& a2)
		{
			istringstream str(a2);
			locale loc = str.getloc();
			ios_base::iostate st = 0;
			uint nVal = 0;
			use_facet<num_get<char>>(loc).get(basic_istream<char>::_Iter(str.rdbuf()),
				basic_istream<char>::_Iter(0), str, st, nVal);
			return nVal;
		}
	}
}