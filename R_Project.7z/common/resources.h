#include "../pch.h"
#include "container/RclHolder.h"

namespace common {
	namespace resources {
		void getFile(string const&strFileName, string& strOut);
		void getFile(TResultContainerList *pRcl, string const&strFileName, string& strOut);
		void getFile(TResultContainerList *pRcl, string const&strFileName, uchar** ppszOut, int& nOutLen, string& strOut);
		int getFile(void *a1, char *lpszKeyword, void **a4, char **a5, common::container::RclHolder &RclHolder);
		void checkDataBase();
		int getDocDesc(int, string &);
		void setRclResources(TResultContainerList *);
		string getDBVersion(void);
		string getDBUnpackStatus(void);
	}
}
