#include "Timer.h"

namespace common
{
	Timer::Timer(string const& a2)
		: m_bsTimer_0(a2)
	{
		m_fTimer_C = false;
		reset();
	}

	Timer::~Timer()
	{
	}

	void Timer::clear(void)
	{
		m_fTimer_C = false;
		m_ulTimer_18 = 0;
	}

	unsigned long long Timer::getTimeDeltaMs(void)
	{
		if (m_fTimer_C)
		{
			chrono::steady_clock::time_point tp = chrono::steady_clock::now();
			m_ulTimer_18 += (unsigned long long)((tp - m_xTimer_10).count() / 1000000000.0 * 1000.0);
		}
		return m_ulTimer_18;
	}

	void Timer::reset(void)
	{
		m_fTimer_C = false;
		m_ulTimer_18 = 0;
		start();
	}

	void Timer::start(void)
	{
		m_fTimer_C = true;
		m_xTimer_10 = chrono::steady_clock::now();
	}

	void Timer::stop(void)
	{
		m_ulTimer_18 = getTimeDeltaMs();
		m_fTimer_C = false;
	}
}