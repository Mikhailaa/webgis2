#pragma once

#include <string>
#include <map>
#include <vector>
using namespace std;

namespace common
{
	void InternalUncheckedWStrToUtf8(wstring const&a1, string &a2);
	void InternalWStrToUtf8(wstring const&a1, string &a2);
	
	namespace UnicodeUtils
	{
		string KOI8RToUtf8(string const&a2);
		wstring UncheckedUtf8ToWStr(string const& a2);
		string UncheckedWStrToUtf8(wstring const&a2);
		wstring Utf8ToWStr(string const&a2);
		string WStrToUtf8(wstring const&a2);
		string Win1251ToUtf8(string const&a2);
		wstring ansiKOI8RToWstr(string const&a2);
		string encodeStrByTable(string const&a2, map<unsigned char, wchar_t> const&a3);
		map<unsigned char,wchar_t>& koi8rTable();
		map<unsigned char,wchar_t>& win1251Table();
	};

	namespace unicodeconvert
	{
		wstring ansiToUnicode(string const& a1,int a2);
		int getCodePageByUnicode(wchar_t);
	};

	namespace unicode_convert
	{
		wstring ansiToWStr(string const&, int);
		int codePage(int);
		string icao(int, string const&);
		string icao(int, wstring const&);
		wstring toCyrillic(wstring);
		wchar_t toLower(wchar_t);
		wstring toUpper(wstring);
		wchar_t toUpper(wchar_t);
	};
}

