﻿#include "resources.h"
#include "../rclhelp.h"
#include "FilesystemUtils.h"
#include "container/json.h"
#include "container/jsoncpp.h"
#include "../moduleprocessgl.h"
#include "RegulaConfig.h"
#include "fs.h"

//TResultContainerList g_1141B10;
using namespace common::container;
bool g_fCheckDataBase_1141B10;
string g_strDbStatus_1141B14;
RclHolder g_rh_1141B20;

namespace common {
	namespace resources {
		void getFile(string const&strFileName, string& strOut)
		{
			getFile(0, strFileName, strOut);
		}

		void getFile(TResultContainerList *pRcl, string const&strFileName, string &strOut)
		{
			char *lpszOut = 0;
			int nOutLen = 0;
			string strTmp;

			getFile(pRcl, strFileName, (uchar**)&lpszOut, nOutLen, strTmp);
			if (nOutLen)
				strOut = string(lpszOut, lpszOut + nOutLen);
		}

		void getFile(TResultContainerList *pRcl, string const&strFileName, uchar** ppszOut, int &OutLen, string &strOut)
		{
			RclHolder rclHolder;
			TResultContainerList* pOutRcl = 0;
			char* p_v28 = 0;

			*ppszOut = 0;
			OutLen = 0;
			string strKeyword("{\"fileName\":\"");
			strKeyword.append(strFileName.data(), strFileName.size());
			strKeyword.append("\"}");
			if (!getFile(pRcl, (char*)strKeyword.data(), (void**)&pOutRcl, &p_v28, rclHolder) && pOutRcl)
			{
				TResultContainer* pRc = rclhelp::findFirstContainer(*pOutRcl, 64);
				if (pRc && pRc->u.pTRC_CHAR)
				{
					strOut = string(pRc->u.pTRC_CHAR, pRc->u.pTRC_CHAR + pRc->nTRC_buf_length);
					OutLen = strOut.size();
					*ppszOut = (uchar*)strOut.data();
				}
			}

			rclHolder.clear();
			if (!OutLen)
			{
				string strFilePath = RegulaConfig::GetFilePath(strFileName);
				if (!common::filesystemutils::readFile(strFilePath, strOut))
				{
					OutLen = strOut.size();
					*ppszOut = (uchar*)strOut.data();
				}
			}
		}

		int getFile(void *a1, char *lpszKeyword, void **a4, char **a5, RclHolder &rclHolder)
		{
			rclHolder.clear();
			if (!lpszKeyword)
			{
				//Log("Error: file name not defined!");
				return 2;
			}

			if (a4) *a4 = &rclHolder;
			string strName(lpszKeyword, strlen(lpszKeyword));
			GenericDocument<UTF8<char>> gd = json::ReadString(strName);
			string strFileName;
			if (!gd.IsNull())
				json::stringFromJson(gd, strFileName, string("fileName"));
			else strFileName = strName;

			if (!strFileName.size())
			{
				//Log("Error: file name is empty!");
				return 2;
			}

			//Log("Try load: %s",strFileName.data());

			RclHolder rh;
			bool fCheckDB = g_fCheckDataBase_1141B10;
			rh.addNoCopy(g_rh_1141B20.m_xTRCL);
			if (a1) rh.addNoCopy(*(TResultContainer*)a1);
			vector<TResultContainer*> vContainer = rclhelp::findContainer(rh.m_xTRCL, 64);
			bool fExist = false;
			for (uint i = 0; i < vContainer.size(); i++)
			{
				if (!vContainer[i] || !vContainer[i]->u.pTRC_UCHAR || !vContainer[i]->nTRC_buf_length) 
					continue;
				
				/*string strResult = zip::FromZip(vContainer[i]->u.pTRC_UCHAR, vContainer[i]->nTRC_buf_length, strFileName);
				if (strResult.size())
				{
					rclHolder.addCopy(rclhelp::container(64, (uchar*)strResult.data(), strResult.size()));
					fExist = true;
					break;
				}*/
			}

			//Log("Resource '%s' is %s", strFileName.data());
			if (fExist)
			{
				//Log("File %s found in Rcl", strFileName.data());
				return 0;
			}
			
			common::fs::Path UpdatePath(RegulaConfig::GetUpdatesPath());
			common::fs::Path DataPath(RegulaConfig::GetDataPath());

			if (!FilesystemUtils::IsDirectoryExists(DataPath.toString()))
				FilesystemUtils::MkDir(DataPath.toString());

			//Log("::getFileFromResource()");
			//Log("Try load resource '%s' from resources", strFileName.data());
			//Log("SDK update path: '%s'", UpdatePath.toString().data());
			//Log("SDK data path: '%s'", DataPath.toString().data());

			if (!fCheckDB)
			{
				checkDataBase();
				rclHolder.clear();
			}

			string strFileList[2] = { "resource.dat", "db.dat" };
			string strPath;
			ulonglong nBufferLen;
			fExist = false;
			for (int i = 0; i < 2; i ++)
			{
				common::fs::Path file;
				if (common::FilesystemUtils::IsDirectoryExists(UpdatePath.toString()))
					file = UpdatePath + common::fs::Path(strFileList[i]);

				if (!common::FilesystemUtils::FileExists(file.toString()))
					file = DataPath + common::fs::Path(strFileList[i]);

				if (!common::FilesystemUtils::FileExists(file.toString()))
					file = common::fs::Path(common::RegulaConfig::GetPath(strFileList[i]));

				strPath = file.toString();
				if (!common::FilesystemUtils::FileExists(strPath))
					strPath = strFileList[i];
				if (!common::FilesystemUtils::FileExists(strPath)) continue;
				
				nBufferLen = 0;
				uchar* pMemBuffer = common::FilesystemUtils::GetMemoryMappedFile(strPath, nBufferLen);
				if (!pMemBuffer)
				{
					common::FilesystemUtils::ReleaseMemoryMappedFile(pMemBuffer);
					continue;
				}

				/*vector<string> vtZipFiles = common::zip::GetZipFiles(pMemBuffer, nBufferLen);
				for (uint z_i = 0; z_i < vtZipFiles.size(); z_i++)
				{
					if (vtZipFiles[z_i] == strFileName)
					{
						string strResult = common::zip::FromZip(pMemBuffer, nBufferLen, vtZipFiles[z_i]);
						if (strResult.size())
						{
							rclHolder.addCopy(rclhelp::container(64, (uchar*)strResult.data(), strResult.size()));
							fExist = true;
							break;
						}
					}
				}*/
				if (fExist) break;
				common::FilesystemUtils::ReleaseMemoryMappedFile(pMemBuffer);
			}

			if (fExist)
				return 0;

			strPath = common::fs::Path(common::RegulaConfig::GetPath(strFileName)).toString();
			if (common::FilesystemUtils::FileExists(strPath))
			{
				nBufferLen = 0;
				uchar* pMemBuffer = common::FilesystemUtils::GetMemoryMappedFile(strPath, nBufferLen);
				if (pMemBuffer && nBufferLen)
				{
					rclHolder.addCopy(rclhelp::container(64, pMemBuffer, (uint)nBufferLen));
					//Log("Resource '%s' found",strFileName.data());
					//Log("File %s found on disk",strFileName.data());
					common::FilesystemUtils::ReleaseMemoryMappedFile(pMemBuffer);
					return 0;
				}
				common::FilesystemUtils::ReleaseMemoryMappedFile(pMemBuffer);
			}

			//Log("Resource '%s' is not found",strFileName.data());
			//Log("File '%s' not found",strFileName.data());
			return 2;
		}

		void checkDataBase()
		{
			g_fCheckDataBase_1141B10 = true;
			g_strDbStatus_1141B14.clear();
		}

		int getDocDesc(int a1, string &a2)
		{
			Json::Value v20(Json::json_type_null);
			v20["id"] = Json::Value(a1);
			string v18;
			jsoncpp::convert(v20, v18);
			TResultContainerList* v17 = 0;
			int v8 = moduleprocessgl::process(2700, 0, v18.data(), (void**)&v17, 0);
			if (v17)
			{
				RclHolder v16;
				v16.addNoCopy(v17);
				vector<TResultContainer*> v15 = v16.getRcList(64);
				if (v15.empty())
				{
					v8 = 1;
				}
				else
				{
					a2 = string(v15[0]->u.pTRC_CHAR, v15[0]->nTRC_buf_length);
					v8 = 0;
				}
			}

			return v8;
		}

		void setRclResources(TResultContainerList *a1)
		{
			g_rh_1141B20.clear();
			if (a1)
				g_rh_1141B20.addNoCopy(*a1);
		}

		string getDBVersion(void)
		{
			string v7;
			getFile(0, "db.json", v7);
			Json::Value v6(Json::json_type_null);
			jsoncpp::convert(v7, v6);
			Json::Value v4("");
			return v6.get("version", v4).asString();
		}

		string getDBUnpackStatus(void)
		{
			return g_strDbStatus_1141B14;
		}
	}
}

