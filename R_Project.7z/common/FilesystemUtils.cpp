#include "FilesystemUtils.h"
#include "UnicodeUtils.h"
#include <fstream>
#include <direct.h>
#include "fs.h"

namespace common
{
	namespace FilesystemUtils
	{
		uchar* GetMemoryMappedFile(wstring const& a2, ulonglong& a3)
		{
			return GetMemoryMappedFile(common::UnicodeUtils::UncheckedWStrToUtf8(a2), a3);
		}

		uchar* GetMemoryMappedFile(string const& a2, ulonglong& a3)
		{
			ifstream ifs(a2, ios_base::in | ios_base::binary | ios_base::ate);
			if (!ifs.is_open()) return 0;
			ifs.seekg(0, ios_base::end);
			uint len = (uint)ifs.tellg();
			ifs.seekg(0, ios_base::beg);
			uchar* result = new uchar[len + 1];
			memset(result, 0, len + 1);
			ifs.read((char*)result, len);
			a3 = len;
			return result;
		}

		bool IsDirectoryExists(const string& a2)
		{
			if (common::fs::isExist(a2) && common::fs::isDir(a2)) return true;
			return false;
		}

		bool IsDirectoryExists(const wstring& a2)
		{
			if (common::fs::isExist(a2) && common::fs::isDir(a2)) return true;
			return false;
		}

		bool IsFileExists(const string& a2)
		{
			if (common::fs::isExist(a2) && common::fs::isDir(a2)) return true;
			return false;
		}

		bool FilesystemUtils::Delete(const string& a1)
		{
			if (IsDirectoryExists(a1))
			{
				common::fs::Path v9(a1);
				return common::fs::rmDir(v9);
			}
			if (IsFileExists(a1))
			{
				common::fs::Path v9(a1);
				return common::fs::rmFile(v9);
			}
			return false;
		}

		bool FilesystemUtils::FileExists(const string& a2)
		{
			common::fs::Path v6(a2);
			if (common::fs::isExist(v6)) return common::fs::isDir(v6) ^ 1;
			return false;
		}

		bool FilesystemUtils::FileExists(const wstring& a2)
		{
			common::fs::Path v6(a2);
			if (common::fs::isExist(v6)) return common::fs::isDir(v6) ^ 1;
			return false;
		}

		string FilesystemUtils::GetCurrentDir()
		{
			char cwd[_MAX_PATH];
#ifdef ANDROID_NDK
			getcwd(cwd, _MAX_PATH);
#else
			_getcwd(cwd, _MAX_PATH);
#endif
			return cwd;
		}

		wstring FilesystemUtils::GetCurrentDirW()
		{
			string cwd = GetCurrentDir();
			return common::UnicodeUtils::Utf8ToWStr(cwd);
		}

		__time64_t FilesystemUtils::GetFileLastWriteTime(const string& a1)
		{
			return fs::getFileWriteTime(a1);
		}

		__time64_t FilesystemUtils::GetFileLastWriteTime(const wstring& a1)
		{
			string path = common::UnicodeUtils::WStrToUtf8(a1);
			return GetFileLastWriteTime(path);
		}

		string FilesystemUtils::GetTmpDir()
		{
			return "/data/local/tmp";
		}

		wstring FilesystemUtils::GetTmpDirW()
		{
			return L"/data/local/tmp";
		}

		bool FilesystemUtils::MkDir(const string& a2)
		{
			return common::fs::mkDir(a2);
		}

		bool FilesystemUtils::MkDir(const wstring& a2)
		{
			return common::fs::mkDir(a2);
		}

		void ReleaseMemoryMappedFile(uchar *&a1)
		{
			if (a1)
			{
				delete[] a1;
				a1 = 0;
			}
		}
	}

	namespace filesystemutils
	{
		bool appendFile(string const&a1, char const*a2, uint a3)
		{
			ofstream ofs(a1, ios_base::out | ios_base::binary | ios_base::app);
			ofs.write(a2, a3);
			ios_base::iostate st = ofs.rdstate();
			return st == ios_base::goodbit;
		}

		int readFile(string const&a1, string& a2)
		{
			a2.clear();
			ifstream ifs(a1, ios_base::in | ios_base::binary);
			if (ifs.is_open())
			{
				ifs.seekg(0, ios_base::end);
				uint i = (uint)ifs.tellg();
				a2.resize(i, 0);
				ifs.seekg(0, ios_base::beg);
				ifs.read((char*)a2.data(), i);
				ifs.close();
				return 0;
			}
			return -1;
		}

		bool writeFile(string const&a1, char const*a2, uint a3)
		{
			string v9 = FilesystemUtils::GetPathBase(a1);
			if (!FilesystemUtils::IsDirectoryExists(v9))
				FilesystemUtils::MkDir(v9);
			ofstream ofs(a1, ios_base::out | ios_base::binary | ios_base::trunc);
			ofs.write(a2, a3);
			ios_base::iostate st = ofs.rdstate();
			return st == ios_base::goodbit;
		}

		bool writeFile(wstring const&a1, char const*a2, uint a3)
		{
			return writeFile(UnicodeUtils::WStrToUtf8(a1), a2, a3);
		}
	}
}