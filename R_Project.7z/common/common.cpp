#include "common.h"
#include "../moduleprocessgl.h"
#include "container/jsoncpp.h"
#include "resources.h"
#include "StringUtils.h"

string g_str_1141060 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

namespace common
{
	namespace ModuleUtils
	{
		string GetModulePath(void)
		{
			return string("");
		}
	}

	namespace Base64
	{
		string base64_encode(uchar const*a2, uint a3)
		{
			string ret;
			uint i, j, k;
			uchar v17[3];
			char v16[4];

			for (i = 0, j = 0; i < a3; i++)
			{
				v17[j++] = a2[i];
				if (j == 3)
				{
					v16[0] = v17[0] >> 2;
					v16[1] = (v17[1] >> 4) | 16 * (v17[0] & 3);
					v16[2] = (v17[2] >> 6) | 4 * (v17[1] & 0xF);
					v16[3] = v17[2] & 0x3F;
					for (k = 0; k < 4; k ++)
					{
						ret += g_str_1141060[v16[k]];
					}
					j = 0;
				}
			}
			if (j)
			{
				for (i = j; i <= 2; i++)
					v17[i] = 0;
				v16[0] = v17[0] >> 2;
				v16[1] = (v17[1] >> 4) | 16 * (v17[0] & 3);
				v16[2] = (v17[2] >> 6) | 4 * (v17[1] & 0xF);
				v16[3] = v17[2] & 0x3F;
				for (k = 0; k <= j; k++)
				{
					ret += g_str_1141060[v16[k]];
				}
				for (k = j; k <= 2; k++)
					ret += '=';
			}
			return ret;
		}

		string base64_decode(string const&a2)
		{
			string ret;
			uint i, j, k;
			uchar v18[3];
			uchar v19[4];

			for (i = 0, j = 0; i < a2.size(); i++)
			{
				char v10 = a2[i];
				if (v10 == '=')
					break;
				if (v10 != '/' && v10 != '+' && !isalnum(v10))
					break;
				v19[j++] = v10;
				if (j == 4)
				{
					for (k = 0; k < 4; k++)
						v19[k] = (uchar)g_str_1141060.find(v19[k], 0);
					v18[0] = ((v19[1] >> 4) & 3) | (v19[0] << 2);
					v18[1] = ((v19[2] >> 2) & 0xF) | (v19[1] << 4);
					v18[2] = v19[3] + (v19[2] << 6);
					for (k = 0; k < 3; k++)
						ret += v18[k];
					j = 0;
				}
			}
			if (j)
			{
				for (i = j; i < 4; i++)
					v19[i] = 0;
				for (k = 0; k < 4; k++)
					v19[k] = (uchar)g_str_1141060.find(v19[k], 0);
				v18[0] = ((v19[1] >> 4) & 3) | (v19[0] << 2);
				v18[1] = ((v19[2] >> 2) & 0xF) | (v19[1] << 4);
				v18[2] = v19[3] + (v19[2] << 6);
				for (k = 0; k < j - 1; k ++)
					ret += v18[k];
			}

			return ret;
		}
	}

	namespace bounds
	{
		void invertByH(TBoundsResult &a1, int a2)
		{
			a1.xTBR_LeftBottom.y = a2 - a1.xTBR_LeftBottom.y;
			a1.xTBR_RightBottom.y = a2 - a1.xTBR_RightBottom.y;
			a1.xTBR_RightTop.y = a2 - a1.xTBR_RightTop.y;
			a1.xTBR_LeftTop.y = a2 - a1.xTBR_LeftTop.y;
			a1.xTBR_Center.y = a2 - a1.xTBR_Center.y;
		}

		void updateDocumentSizeByCoordinates(TBoundsResult &a1)
		{
			double v2 = (a1.xTBR_LeftBottom.y - a1.xTBR_RightBottom.y)	* (a1.xTBR_LeftBottom.y - a1.xTBR_RightBottom.y)
				+ (a1.xTBR_LeftBottom.x - a1.xTBR_RightBottom.x) * (a1.xTBR_LeftBottom.x - a1.xTBR_RightBottom.x);
			double v3 = sqrt(v2);
			double v6 = (a1.xTBR_RightBottom.y - a1.xTBR_RightTop.y) * (a1.xTBR_RightBottom.y - a1.xTBR_RightTop.y)
				+ (a1.xTBR_RightBottom.x - a1.xTBR_RightTop.x) * (a1.xTBR_RightBottom.x - a1.xTBR_RightTop.x);
			double v7 = sqrt(v6);
			double v9 = (a1.xTBR_RightTop.y - a1.xTBR_LeftTop.y) * (a1.xTBR_RightTop.y - a1.xTBR_LeftTop.y)
				+ (a1.xTBR_RightTop.x - a1.xTBR_LeftTop.x) * (a1.xTBR_RightTop.x - a1.xTBR_LeftTop.x);
			double v10 = sqrt(v9);
			double v13 = (a1.xTBR_LeftTop.y - a1.xTBR_LeftBottom.y) * (a1.xTBR_LeftTop.y - a1.xTBR_LeftBottom.y)
				+ (a1.xTBR_LeftTop.x - a1.xTBR_LeftBottom.x) * (a1.xTBR_LeftTop.x - a1.xTBR_LeftBottom.x);
			double v14 = sqrt(v13);
			a1.nTBR_Width = (int)(v3 + v10) / 2;
			a1.nTBR_Height = (int)(v7 + v14) / 2;;
		}
	}

	namespace system
	{
		string getCurrentDate(void)
		{
			char s[0x100];
			stringstream ss;
			time_t timer = time(0);
			if (strftime(s, 0x100, "%Y_%m_%d %H_%M_%S", localtime(&timer)))
				 ss << s;
			return ss.str();
		}

		int getDaysFrom30121899ForYYMMDD(string const&a1)
		{
			int nRet = 0;
			struct tm tp;

			if (a1.size() == 6)
			{
				memset(&tp, 0, sizeof(tm));
				tp.tm_mday = 1;
				tp.tm_year = 70;
				time_t t = mktime(&tp);
				memset(&tp, 0, sizeof(tm));
				if ((t + 86399) < 172799)
					nRet = 25570;
				tp.tm_year = common::StringUtils::toInt(string(a1, 0, 2)) + 100;
				tp.tm_mon = common::StringUtils::toInt(string(a1, 2, 2)) - 1;
				tp.tm_mday = common::StringUtils::toInt(string(a1, 4, 2));
				t = mktime(&tp);
				nRet += (int)(t / 86400);
			}
			return nRet;
		}

		string time_in_HH_MM_SS_MMM(void)
		{
			chrono::system_clock::time_point tp = chrono::system_clock::now();
			time_t timer = time(0);
			struct tm t;
			char s[0x100];
			ostringstream oss;

			memcpy(&t, localtime(&timer), sizeof(tm));
			long long v7 = tp.time_since_epoch().count() / 1000 - (tp.time_since_epoch().count() / 1000000) * 1000;

			if (strftime(s, 0x100, "%H:%M:%S:", &t))
				oss << s;
			oss << v7;
			return oss.str();
		}
	}

	namespace process
	{
		bool isProcessingTimeExceeded()
		{
			if (moduleprocessgl::isCommandSupported(PGC_TimeCheck))
				return moduleprocessgl::process(PGC_TimeCheck, 0, 0, 0, 0) != 0;
			return false;
		}
	}

	namespace dbupdate
	{
		void checkDB(string &a1, string &a2)
		{
			updateDB();
			Json::Value v45(Json::json_type_null);
			v45["downloadDbJson"] = Json::Value(false);
			if (moduleprocessgl::process(0x9CB, 0, 0, 0, 0) != 1)
			{
				Json::Value v42(Json::json_type_null);
				common::container::jsoncpp::convert(a1, v42);
				string v41 = common::resources::getDBVersion();
				string v40 = common::StringUtils::toString(99136);
				if (!v42.isMember("versions"))
				{
					if (!v41.size() || common::StringUtils::toInt(v41) < common::StringUtils::toInt(v40))
						v45["downloadDbJson"] = Json::Value(true);
					return;
				}
				if (!v41.size()) v41 = "0";
				//////////////////////////////////////////////////////////////////////////
			}
		}

		void updateDB(void)
		{

		}
	}

	namespace docsize
	{
		float widthMM(CDocFormat a1)
		{
			float v1 = 0.0;
			switch (a1)
			{
			case DOCFORMAT_0:
			case DOCFORMAT_B:
				v1 = 85.6f;
				break;
			case DOCFORMAT_1:
			case DOCFORMAT_D:
				v1 = 105.0f;
				break;
			case DOCFORMAT_2:
			case DOCFORMAT_5:
			case DOCFORMAT_E:
				v1 = 125.0f;
				break;
			case DOCFORMAT_3:
			case DOCFORMAT_7:
			case DOCFORMAT_8:
			case DOCFORMAT_9:
				break;
			case DOCFORMAT_4:
				v1 = 297.0f;
				break;
			case DOCFORMAT_6:
				v1 = 92.5f;
				break;
			case DOCFORMAT_A:
			case DOCFORMAT_C:
				v1 = 54.0f;
				break;
			case DOCFORMAT_3E8:
				v1 = 85.6f;
				break;
			case DOCFORMAT_3E9:
				v1 = 35.0f;
				break;
			default:
				break;
			}
			return v1;
		}

		float heightMM(CDocFormat a1)
		{
			float v1 = 0.0;
			switch (a1)
			{
			case DOCFORMAT_0:
			case DOCFORMAT_B:
				v1 = 54.0f;
				break;
			case DOCFORMAT_1:
			case DOCFORMAT_D:
				v1 = 74.0f;
				break;
			case DOCFORMAT_2:
			case DOCFORMAT_E:
				v1 = 88.0f;
				break;
			case DOCFORMAT_3:
			case DOCFORMAT_7:
			case DOCFORMAT_8:
			case DOCFORMAT_9:
				break;
			case DOCFORMAT_4:
				v1 = 210.0f;
				break;
			case DOCFORMAT_5:
				v1 = 176.0f;
				break; 
			case DOCFORMAT_6:
				v1 = 65.5f;
				break;
			case DOCFORMAT_A:
			case DOCFORMAT_C:
				v1 = 85.6f;
				break;
			case DOCFORMAT_3E8:
				v1 = 54.0f;
				break;
			case DOCFORMAT_3E9:
				v1 = 45.0f;
				break;
			default:
				break;
			}
			return v1;
		}

		float kWH(CDocFormat a1)
		{
			float v2 = heightMM(a1);
			if (v2 != 0.0f)
				v2 = widthMM(a1) / v2;
			return v2;
		}
	}

	namespace images
	{
		int FlipImage(uchar *a1, int a2, int a3, int a4, imaging::eRI_FlipModes a5)
		{
			int nRet = 2;
			if (a5 && a2 >= 8 && a1 && a3 >= 1 && a4 >= 1)
			{
				if (a2 == 8 || a2 == 24 || a2 == 32)
				{
					Mat v9(a4, a3, (a2 & 0xF8) - 8, a1, ((a3 * a2 + 31) / 32) * 4);
					switch (a5)
					{
					case imaging::RI_FLIPMODES_1:
						flip(v9, v9, 0);
						break;
					case imaging::RI_FLIPMODES_3:
						flip(v9, v9, -1);
						break;
					case imaging::RI_FLIPMODES_2:
						flip(v9, v9, 1);
						break;
					}
					nRet = 0;
				}
			}
			return nRet;
		}

		bool FlipImage(TRawImageContainer &a1, imaging::eRI_FlipModes a2)
		{
			if (a1.pxRIC_bmi)
				return FlipImage(a1.pRIC_data, a1.pxRIC_bmi->bmiHeader.biBitCount, a1.pxRIC_bmi->bmiHeader.biWidth, a1.pxRIC_bmi->bmiHeader.biHeight, a2) == 0;
			return false;
		}

		bool FlipImage(TResultContainerList &a1, imaging::eRI_FlipModes a2)
		{
			bool v4 = true;
			for (uint i = 0; i < a1.nTRCL_Count; ++i)
			{
				if (a1.pTRCL_TRC[i].nTRC_result_type == 16 || a1.pTRCL_TRC[i].nTRC_result_type == 1)
					v4 &= FlipImage(a1.pTRCL_TRC[i], a2);
			}
			return v4;
		}

		bool FlipImage(TResultContainer &a1, imaging::eRI_FlipModes a2)
		{
			if ((a1.nTRC_result_type == 16 || a1.nTRC_result_type == 1) && a1.nTRC_buf_length && a1.u.pTRC_RIC)
				return FlipImage(*a1.u.pTRC_RIC, a2);
			return false;
		}

		bool RotateImage(TResultContainerList &a1, imaging::eRI_Rotations a2)
		{
			bool v6 = true;
			for (uint i = 0; i < a1.nTRCL_Count; ++i)
			{
				if (a1.pTRCL_TRC[i].nTRC_result_type == 1)
					v6 &= RotateImage(a1.pTRCL_TRC[i], a2);
			}
			return v6;
		}

		bool RotateImage(TResultContainer &a1, imaging::eRI_Rotations a2)
		{
			if (a1.nTRC_result_type == 1 && a1.nTRC_buf_length && a1.u.pTRC_RIC)
				return RotateImage(*a1.u.pTRC_RIC, a2);
			return false;
		}

		bool RotateImage(TRawImageContainer &a1, imaging::eRI_Rotations a2)
		{
			if (!a1.pxRIC_bmi)
				return false;
			int w = a1.pxRIC_bmi->bmiHeader.biWidth;
			int h = a1.pxRIC_bmi->bmiHeader.biHeight;
			int nRet = RotateImage(a1.pRIC_data, a1.pxRIC_bmi->bmiHeader.biBitCount, w, h, a2);
			a1.pxRIC_bmi->bmiHeader.biWidth = w;
			a1.pxRIC_bmi->bmiHeader.biHeight = h;
			a1.pxRIC_bmi->bmiHeader.biSizeImage = (((a1.pxRIC_bmi->bmiHeader.biBitCount * w + 31) / 32) * 4) * h;
			return (nRet == 0);
		}

		int RotateImage(uchar *a1, int a2, int &a3, int &a4, imaging::eRI_Rotations a5)
		{
			int nRet = 2;
			if (!a1 || a3 < 1 || !a5 || a2 < 8 || a4 < 1)
				return nRet;
			if (a2 != 8 && a2 != 24 && a2 != 32)
				return nRet;
			int v22 = ((a3 * a2 + 31) / 32) * 4;
			int v14 = (a2 & 0xF8) - 8;
			Mat v26(a4, a3, v14, a1, v22);
			if (a5 == imaging::RI_Rotations_3 || a5 == imaging::RI_Rotations_1)
			{
				int v16 = ((v26.rows * a2 + 31) / 32) * 4;
				uchar* v20 = new uchar[v16 * v26.cols];
				Mat v25(v26.cols, v26.rows, v14, v20, v16);
				transpose(v26, v25);
				flip(v25, v25, (a5 == 1) ? 0 : 1);
				memcpy(a1, v20, min(a4 * v22, v16 * v26.cols));
				a3 = a4;
				a4 = a4 * v22 / v16;
				delete[] v20;
			}
			else if(a5 == imaging::RI_Rotations_2)
				flip(v26, v26, -1);
			return 0;
		}

		bool CropImage(TResultContainerList &a1, tagRECT a2)
		{
			bool v6 = true;
			for (uint i = 0; i < a1.nTRCL_Count; ++i)
			{
				if (a1.pTRCL_TRC[i].nTRC_result_type == 1)
				{
					v6 &= CropImage(a1.pTRCL_TRC[i], a2);
				}
			}
			return v6;
		}

		bool CropImage(TResultContainer &a1, tagRECT a2)
		{
			if (a1.nTRC_result_type != 1)
				return false;
			if (a1.nTRC_buf_length == 0 || a1.u.pTRC_RIC == 0)
				return false;
			return CropImage(*a1.u.pTRC_RIC, a2);
		}

		bool CropImage(TRawImageContainer &a1, tagRECT a2)
		{
			if (!a1.pxRIC_bmi)
				return false;
			int w = a1.pxRIC_bmi->bmiHeader.biWidth;
			int h = a1.pxRIC_bmi->bmiHeader.biHeight;
			int ret = CropImage(a1.pRIC_data, a1.pxRIC_bmi->bmiHeader.biBitCount, w, h, a2);
			a1.pxRIC_bmi->bmiHeader.biWidth = w;
			a1.pxRIC_bmi->bmiHeader.biHeight = h;
			a1.pxRIC_bmi->bmiHeader.biSizeImage = (((a1.pxRIC_bmi->bmiHeader.biBitCount * w + 31) / 32) * 4) * h;
			return (ret == 0);
		}

		int CropImage(uchar *a1, int a2, int &a3, int &a4, tagRECT a5)
		{
			int v6 = max(a5.top, 1);
			int v7 = max(a5.left, 1);
			int v9 = min(a5.bottom, a4 - 2);
			int v8 = min(a5.right, a3 - 2);
			int ret = 2;
			if (!a1 || a3 < 1 || a2 < 8 || a4 < 1)
				return ret;
			if (a2 != 8 && a2 != 24 && a2 != 32)
				return ret;
			int v18 = a2 / 8;
			Mat v33(a4, a3, 8 * v18 - 8, a1, ((a3 * a2 + 31) / 32) * 4);
			v8 -= v7;
			v9 -= v6;
			if (v8 < 1 || v9 < 1 || (v8 >= a3 && v9 >= a4))
				return ret;
			Rect v27;
			v27.x = v7;
			v27.y = v6;
			v27.width = v8;
			v27.height = v9;
			Mat v32(v9, v8, 8 * v18 - 8, a1, ((v8 * a2 + 31) / 32) * 4);
			Mat v31(v33.clone(), v27);
			for (int i = 0; i < v9; ++i)
			{
				memcpy(v32.row(i).data, v31.row(i).data, v8 * v18);
			}
			a3 = v8;
			a4 = v9;
			return 0;
		}

		bool ResizeImage(TResultContainerList &a1, int a2, int a3)
		{
			bool v6 = true;
			for (uint i = 0; i < a1.nTRCL_Count; ++i)
			{
				if (a1.pTRCL_TRC[i].nTRC_result_type == 1)
					v6 &= ResizeImage(a1.pTRCL_TRC[i], a2, a3);
			}
			return v6;
		}

		bool ResizeImage(TRawImageContainer &a1, int a2, int a3)
		{
			if (!a1.pxRIC_bmi)
				return false;
			int w = a1.pxRIC_bmi->bmiHeader.biWidth;
			int h = a1.pxRIC_bmi->bmiHeader.biHeight;
			int v6 = ResizeImage(a1.pRIC_data, a1.pxRIC_bmi->bmiHeader.biBitCount, w, h, a2, a3, true);
			a1.pxRIC_bmi->bmiHeader.biWidth = w;
			a1.pxRIC_bmi->bmiHeader.biHeight = h;
			a1.pxRIC_bmi->bmiHeader.biSizeImage = CalculateBitmapSize(a1.pxRIC_bmi, 0x20);
			return v6 == 0;
		}

		bool ResizeImage(TResultContainer &a1, int a2, int a3)
		{
			if (a1.nTRC_result_type == 1 && a1.nTRC_buf_length && a1.u.pTRC_RIC != 0)
				return ResizeImage(*a1.u.pTRC_RIC, a2, a3);
			return false;
		}

		int ResizeImage(uchar *a1, int a2, int &a3, int &a4, int a5, int a6, bool a7)
		{
			if (!a1 || a3 < 1 || a6 < 1 || a5 < 1 || a4 < 1 || (a2 != 8 && a2 != 24 && a2 != 32))
				return 2;
			int v22 = (a2 & 0xF8) - 8;
			Mat v37(a4, a3, v22, a1, ((uint)(a3 * a2 + 31) / 32) * 4);
			uint v23 = ((uint)(a5 * a2 + 31) / 32) * 4;
			uchar* v7 = new uchar[v23 * a6];
			Mat v36(Size(a5, a6), v22, v7, v23);
			if (a7)
			{
				resize(v37, v36, Size(a5, a6));
			}
			else
			{
				resize(v37, v36, Size(a5, a6), 0.0, 0.0, 2);
			}
			memcpy(a1, v7, v23 * a6);
			a3 = a5;
			a4 = a6;
			delete[] v7;
			return 0;
		}

		int ResizeImage(uchar const*a1, int a2, int a3, int a4, uchar const*a5, int a6, int a7, bool a8)
		{
			if (!a5 || !a1 || a3 < 1 || a4 < 1 || a6 < 1 || a7 < 1 || (a2 != 8 && a2 != 24 && a2 != 32))
				return 2;
			Mat v24(a4, a3, (a2 & 0xF8) - 8, (void*)a1, ((uint)(a3 * a2 + 31) / 32) * 4);
			Mat v23(Size(a6, a7), (a2 & 0xF8) - 8, (void*)a5, ((uint)(a6 * a2 + 31) / 32) * 4);
			if (a8)
			{
				resize(v24, v23, Size(a6, a7));
			}
			else
			{
				resize(v24, v23, Size(a6, a7), 0.0, 0.0, 2);
			}
			return 0;
		}

		uint CalculateBitmapSize(tagBITMAPINFO *a1, uint a2)
		{
			uint result;
			if (a1)
				result = (((a2 + a1->bmiHeader.biWidth * a1->bmiHeader.biBitCount - 1) & ((~a2) + 1)) >> 3)
				* a1->bmiHeader.biHeight;
			else
				result = 0;
			return result;
		}

		uint CalculateBitmapSize(uint a1, uint a2, uint a3, uint a4)
		{
			return (((a4 + a3 * a1 - 1) & ((~a4) + 1)) >> 3) * a2;
		}

		uint CalculateRowStride(uint a1, uint a2, uint a3)
		{
			return ((a3 + a2 * a1 - 1) & ((~a3) + 1)) >> 3;
		}
	}

	namespace rotate
	{
		void rotatePoint(tagPOINT &a1, eRPRM_Orientation a2, tagSIZE const &a3, tagSIZE const &a4)
		{
			if (a2 == RPRM_Orientation_1 || a3.cx < 1 || a3.cy < 1)
				return;
			if (a2 == RPRM_Orientation_2)
			{
				a1.y = a3.cy - a1.y - a4.cy;
				a1.x = a3.cx - a1.x - a4.cx;
			}
			else if (a2 == RPRM_Orientation_4)
			{
				int x = a1.x;
				a1.x = a1.y;
				a1.y = a3.cx - x - a4.cx;
			}
			else if (a2 == RPRM_Orientation_8)
			{
				int x = a1.x;
				a1.x = a3.cy - a1.y - a4.cy;
				a1.y = x;
			}
		}
		void rotateSize(tagSIZE &a1, eRPRM_Orientation a2)
		{
			if (a2 == RPRM_Orientation_8 || a2 == RPRM_Orientation_4)
			{
				int cx = a1.cx;
				a1.cx = a1.cy;
				a1.cy = cx;
			}
		}
		void rotateAngle(int &a1, eRPRM_Orientation a2)
		{
			int v3;
			switch (a2)
			{
			case RPRM_Orientation_8:
				v3 = 90;
				break;
			case RPRM_Orientation_4:
				v3 = 270;
				break;
			case RPRM_Orientation_2:
				v3 = 180;
				break;
			default:
				return;
			}
			a1 = (a1 + v3) % 360;
		}
	}

	namespace field
	{
		string graphicFieldName(eGraphicFieldType eGFT)
		{
			string ret;
			switch (eGFT)
			{
			case GFT_Portrait: //0xC9
				ret = "Portrait";
				break;
			case GFT_Fingerprint: // 0xCA
				ret = "Fingerprint";
				break;
			case GFT_Iris: // 0xCB
				ret = "Iris";
				break;
			case GFT_Signature: // 0xCC
				ret = "Signature";
				break;
			case GFT_Barcode: // 0xCD
				ret = "Barcode";
				break;
			case GFT_ProofOfCitizenship: // 0xCE
				ret = "Proof of citizenship";
				break;
			case GFT_DocumentFrontSide: // 0xCF
				ret = "Document front side";
				break;
			case GFT_DocumentReverseSide: // 0xD0
				ret = "Document reverse side";
				break;
			case GFT_ColorDynamic: // 0xD1
				ret = "Color dynamic";
				break;
			case GFT_GhostPortrait: // 0xD2
				ret = "Ghost portrait";
				break;
			case GFT_Stamp: // 0xD3
				ret = "Stamp";
				break;
			case GFT_PortraitOfChild: // 0xD4
				ret = "Portrait of child";
				break;
			case GFT_Other: // 0xFA
				ret = "Other";
				break;
			case GFT_LeftThumb: // 0x12C
				ret = "Left thumb";
				break;
			case GFT_LeftIndexFinger: // 0x12D
				ret = "Left index finger";
				break;
			case GFT_LeftMiddleFinger: // 0x12E
				ret = "Left middle finger";
				break;
			case GFT_LeftRingFinger: // 0x12F
				ret = "Left ring finger";
				break;
			case GFT_LeftLittleFinger: // 0x130
				ret = "Left little finger";
				break;
			case GFT_RightThumb: // 0x131
				ret = "Right thumb";
				break;
			case GFT_RightIndexFinger: // 0x132
				ret = "Right index finger";
				break;
			case GFT_RightMiddleFinger: // 0x133
				ret = "Right middle finger";
				break;
			case GFT_RightRingFinger: // 0x134
				ret = "Right ring finger";
				break;
			case GFT_RightLittleFinger: // 0x135
				ret = "Right little finger";
				break;
			default:
				ret = "Unknown";
				break;
			}
			return ret;
		}

		string lcidName(int a2)
		{
			string ret;
			switch (a2)
			{
			case 1025:
				ret = "Arabic (Saudi Arabia)";
				break;
			case 1026:
				ret = "Bulgarian";
				break;
			case 1027:
				ret = "Catalan";
				break;
			case 1028:
			case 1041:
			case 1054:
			case 1067:
			case 1070:
			case 1072:
			case 1073:
			case 1074:
			case 1075:
			case 1076:
			case 1077:
			case 1081:
			case 1082:
			case 1083:
			case 1084:
			case 1085:
			case 1090:
			case 1093:
			case 1094:
			case 1095:
			case 1096:
			case 1097:
			case 1098:
			case 1099:
			case 1100:
			case 1101:
			case 1102:
			case 1103:
			case 1105:
			case 1106:
			case 1107:
			case 1108:
			case 1109:
				ret = "<unknown>";
				break;
			case 1029:
				ret = "Czech";
				break;
			case 1030:
				ret = "Danish";
				break;
			case 1031:
				ret = "German (Germany)";
				break;
			case 1032:
				ret = "Greek";
				break;
			case 1033:
				ret = "English (United States)";
				break;
			case 1034:
				ret = "Spanish (Traditional Sort)";
				break;
			case 1035:
				ret = "Finnish";
				break;
			case 1036:
				ret = "French (France)";
				break;
			case 1037:
				ret = "Hebrew";
				break;
			case 1038:
				ret = "Hungarian";
				break;
			case 1039:
				ret = "Icelandic";
				break;
			case 1040:
				ret = "Italian (Italy)";
				break;
			case 1042:
				ret = "Korean";
				break;
			case 1043:
				ret = "Dutch (Netherlands)";
				break;
			case 1044:
				ret = "Norwegian (Bokmal)";
				break;
			case 1045:
				ret = "Polish";
				break;
			case 1046:
				ret = "Portuguese (Brazil)";
				break;
			case 1047:
				ret = "Rhaeto-Romanic";
				break;
			case 1048:
				ret = "Romanian";
				break;
			case 1049:
				ret = "Russian";
				break;
			case 1050:
				ret = "Croatian";
				break;
			case 1051:
				ret = "Slovak";
				break;
			case 1052:
				ret = "Albanian";
				break;
			case 1053:
				ret = "Swedish";
				break;
			case 1055:
				ret = "Turkish";
				break;
			case 1056:
				ret = "Urdu";
				break;
			case 1057:
				ret = "Indonesian";
				break;
			case 1058:
				ret = "Ukrainian";
				break;
			case 1059:
				ret = "Belarusian";
				break;
			case 1060:
				ret = "Slovenian";
				break;
			case 1061:
				ret = "Estonian";
				break;
			case 1062:
				ret = "Latvian";
				break;
			case 1063:
				ret = "Lithuanian";
				break;
			case 1064:
				ret = "Tajik (Cyrillic)";
				break;
			case 1065:
				ret = "Farsi";
				break;
			case 1066:
				ret = "Vietnamese";
				break;
			case 1068:
				ret = "Azeri (Latin)";
				break;
			case 1069:
				ret = "Basque";
				break;
			case 1071:
				ret = "FYRO Macedonian";
				break;
			case 1078:
				ret = "Afrikaans";
				break;
			case 1079:
				ret = "Georgian";
				break;
			case 1080:
				ret = "Faroese";
				break;
			case 1086:
				ret = "Malay (Malaysia)";
				break;
			case 1087:
				ret = "Kazakh";
				break;
			case 1088:
				ret = "Kyrgyz (Cyrillic)";
				break;
			case 1089:
				ret = "Swahili";
				break;
			case 1091:
				ret = "Uzbek (Latin)";
				break;
			case 1092:
				ret = "Tatar";
				break;
			case 1104:
				ret = "Mongolian (Cyrillic)";
				break;
			case 1110:
				ret = "Galician";
				break;
			case 2055:
				ret = "German (Switzerland)";
				break;
			case 2056:
			case 2059:
			case 2061:
			case 2062:
			case 2063:
			case 2065:
			case 2066:
			case 2069:
			case 2071:
			case 2072:
			case 2073:
			case 2075:
			case 2076:
				ret = "<unknown>";
				break;
			case 2057:
				ret = "English (United Kingdom)";
				break;
			case 2058:
				ret = "Spanish (Mexico)";
				break;
			case 2060:
				ret = "French (Belgium)";
				break;
			case 2064:
				ret = "Italian (Switzerland)";
				break;
			case 2067:
				ret = "Dutch (Belgium)";
				break;
			case 2068:
				ret = "Norwegian (Nynorsk)";
				break;
			case 2070:
				ret = "Portuguese (Portugal)";
				break;
			case 2074:
				ret = "Serbian (Latin)";
				break;
			case 2077:
				ret = "Swedish (Finland)";
				break;
			case 3073:
				ret = "Arabic (Egypt)";
				break;
			case 3074:
			case 3075:
			case 3076:
			case 3077:
			case 3078:
			case 3080:
			case 3083:
				ret = "<unknown>";
				break;
			case 3079:
				ret = "German (Austria)";
				break;
			case 3081:
				ret = "English (Australia)";
				break;
			case 3082:
				ret = "Spanish (International Sort)";
				break;
			case 3084:
				ret = "French (Canada)";
				break;
			case 4097:
				ret = "Arabic (Libya)";
				break;
			case 4098:
			case 4099:
			case 4100:
			case 4101:
			case 4102:
			case 4104:
			case 4107:
				ret = "<unknown>";
				break;
			case 4103:
				ret = "German (Luxembourg)";
				break;
			case 4105:
				ret = "English (Canada)";
				break;
			case 4106:
				ret = "Spanish (Guatemala)";
				break;
			case 4108:
				ret = "French (Switzerland)";
				break;
			case 5121:
				ret = "Arabic (Algeria)";
				break;
			case 5122:
			case 5123:
			case 5124:
			case 5125:
			case 5126:
			case 5128:
			case 5131:
				ret = "<unknown>";
				break;
			case 5127:
				ret = "German (Liechtenstein)";
				break;
			case 5129:
				ret = "English (New Zealand)";
				break;
			case 5130:
				ret = "Spanish (Costa Rica)";
				break;
			case 5132:
				ret = "French (Luxembourg)";
				break;
			case 20490:
				ret = "Spanish (Puerto Rico)";
				break;
			case 2049:
				ret = "Arabic (Iraq)";
				break;
			case 2092:
				ret = "Azeri (Cyrillic)";
				break;
			case 2110:
				ret = "Malay (Brunei Darussalam)";
				break;
			case 2115:
				ret = "Uzbek (Cyrillic)";
				break;
			case 3098:
				ret = "Serbian (Cyrillic)";
				break;
			case 6145:
				ret = "Arabic (Morocco)";
				break;
			case 6153:
				ret = "English (Ireland)";
				break;
			case 6154:
				ret = "Spanish (Panama)";
				break;
			case 6156:
				ret = "French (Monaco)";
				break;
			case 7169:
				ret = "Arabic (Tunisia)";
				break;
			case 7177:
				ret = "English (South Africa)";
				break;
			case 7178:
				ret = "Spanish (Dominican Republic)";
				break;
			case 8193:
				ret = "Arabic (Oman)";
				break;
			case 8201:
				ret = "English (Jamaica)";
				break;
			case 8202:
				ret = "Spanish (Venezuela)";
				break;
			case 9217:
				ret = "Arabic (Yemen)";
				break;
			case 9225:
				ret = "English (Caribbean)";
				break;
			case 9226:
				ret = "Spanish (Colombia)";
				break;
			case 10241:
				ret = "Arabic (Syria)";
				break;
			case 10249:
				ret = "English (Belize)";
				break;
			case 10250:
				ret = "Spanish (Peru)";
				break;
			case 11265:
				ret = "Arabic (Jordan)";
				break;
			case 11273:
				ret = "English (Trinidad)";
				break;
			case 11274:
				ret = "Spanish (Argentina)";
				break;
			case 12289:
				ret = "Arabic (Lebanon)";
				break;
			case 12297:
				ret = "English (Zimbabwe)";
				break;
			case 12298:
				ret = "Spanish (Ecuador)";
				break;
			case 13313:
				ret = "Arabic (Kuwait)";
				break;
			case 13321:
				ret = "English (Philippines)";
				break;
			case 13322:
				ret = "Spanish (Chile)";
				break;
			case 14337:
				ret = "Arabic (U.A.E.)";
				break;
			case 14346:
				ret = "Spanish (Uruguay)";
				break;
			case 15361:
				ret = "Arabic (Bahrain)";
				break;
			case 15370:
				ret = "Spanish (Paraguay)";
				break;
			case 16385:
				ret = "Arabic (Qatar)";
				break;
			case 16394:
				ret = "Spanish (Bolivia)";
				break;
			case 17418:
				ret = "Spanish (El Salvador)";
				break;
			case 18442:
				ret = "Spanish (Honduras)";
				break;
			case 19466:
				ret = "Spanish (Nicaragua)";
				break;
			default:
				if (a2) ret = "<unknown>";
				else ret = "";
				break;
			}
			return ret;
		}

		void setFieldType(TDocGraphicField &a1, eGraphicFieldType a2)
		{
			a1.nDGF_FieldType = a2;
			strcpy_s(a1.szDGF_FieldName, graphicFieldName(a2).data());
		}

		void setFieldType(TDocVisualExtendedField &a1, eVisualFieldType a2)
		{
			a1.u0.nDVEF_FieldType = a2;
			strcpy_s(a1.szDVEF_FieldName, textFieldName(a2).data());
		}

		string textFieldName(eVisualFieldType a2)
		{
			string ret;
			switch (a2)
			{
			case 0u:
				ret = "Document Class Code";
				break;
			case 1u:
				ret = "Issuing State Code";
				break;
			case 2u:
				ret = "Document Number";
				break;
			case 3u:
				ret = "Date of Expiry";
				break;
			case 4u:
				ret = "Date of Issue";
				break;
			case 5u:
				ret = "Date of Birth";
				break;
			case 6u:
				ret = "Place of Birth";
				break;
			case 7u:
				ret = "Personal Number";
				break;
			case 8u:
				ret = "Surname";
				break;
			case 9u:
				ret = "Given Names";
				break;
			case 0xAu:
				ret = "Mothers Name";
				break;
			case 0xBu:
				ret = "Nationality";
				break;
			case 0xCu:
				ret = "Sex";
				break;
			case 0xDu:
				ret = "Height";
				break;
			case 0xEu:
				ret = "Weight";
				break;
			case 0xFu:
				ret = "Eyes Color";
				break;
			case 0x10u:
				ret = "Hair Color";
				break;
			case 0x11u:
				ret = "Address";
				break;
			case 0x12u:
				ret = "Donor";
				break;
			case 0x13u:
				ret = "Social Security Number";
				break;
			case 0x14u:
				ret = "DL Class";
				break;
			case 0x15u:
				ret = "DL Endorsed";
				break;
			case 0x16u:
				ret = "DL Restriction Code";
				break;
			case 0x17u:
				ret = "DL Under 21 Date";
				break;
			case 0x18u:
				ret = "Authority";
				break;
			case 0x19u:
				ret = "Surname And Given Names";
				break;
			case 0x1Au:
				ret = "Nationality Code";
				break;
			case 0x1Bu:
				ret = "Passport Number";
				break;
			case 0x1Cu:
				ret = "Invitation Number";
				break;
			case 0x1Du:
				ret = "Visa ID";
				break;
			case 0x1Eu:
				ret = "Visa Class";
				break;
			case 0x1Fu:
				ret = "Visa SubClass";
				break;
			case 0x20u:
				ret = "MRZ String1";
				break;
			case 0x21u:
				ret = "MRZ String2";
				break;
			case 0x22u:
				ret = "MRZ String3";
				break;
			case 0x23u:
				ret = "MRZ Type";
				break;
			case 0x24u:
				ret = "Optional Data";
				break;
			case 0x25u:
				ret = "Document Class Name";
				break;
			case 0x26u:
				ret = "Issuing State Name";
				break;
			case 0x27u:
				ret = "Place of Issue";
				break;
			case 0x28u:
				ret = "Document Number Checksum";
				break;
			case 0x29u:
				ret = "Date of Birth Checksum";
				break;
			case 0x2Au:
				ret = "Date of Expiry Checksum";
				break;
			case 0x2Bu:
				ret = "Personal Number Checksum";
				break;
			case 0x2Cu:
				ret = "Final Checksum";
				break;
			case 0x2Du:
				ret = "Passport Number Checksum";
				break;
			case 0x2Eu:
				ret = "Invitation Number Checksum";
				break;
			case 0x2Fu:
				ret = "Visa ID Checksum";
				break;
			case 0x30u:
				ret = "Surname And Given Names Checksum";
				break;
			case 0x31u:
				ret = "Visa Valid Until Checksum";
				break;
			case 0x32u:
				ret = "Other";
				break;
			case 0x33u:
				ret = "MRZ Strings";
				break;
			case 0x34u:
				ret = "Name Suffix";
				break;
			case 0x35u:
				ret = "Name Prefix";
				break;
			case 0x36u:
				ret = "Date of Issue Checksum";
				break;
			case 0x37u:
				ret = "Date of Issue Checkdigit";
				break;
			case 0x38u:
				ret = "Document Series";
				break;
			case 0x39u:
				ret = "RegCert RegNumber";
				break;
			case 0x3Au:
				ret = "RegCert CarModel";
				break;
			case 0x3Bu:
				ret = "RegCert CarColor";
				break;
			case 0x3Cu:
				ret = "RegCert BodyNumber";
				break;
			case 0x3Du:
				ret = "RegCert CarType";
				break;
			case 0x3Eu:
				ret = "RegCert MaxWeight";
				break;
			case 0x3Fu:
				ret = "Reg Cert Weight";
				break;
			case 0x40u:
				ret = "Address Area";
				break;
			case 0x41u:
				ret = "Address State";
				break;
			case 0x42u:
				ret = "Address Building";
				break;
			case 0x43u:
				ret = "Address House";
				break;
			case 0x44u:
				ret = "Address Flat";
				break;
			case 0x45u:
				ret = "Place of Registration";
				break;
			case 0x46u:
				ret = "Date of Registration";
				break;
			case 0x47u:
				ret = "Resident From";
				break;
			case 0x48u:
				ret = "Resident Until";
				break;
			case 0x49u:
				ret = "Authority Code";
				break;
			case 0x4Au:
				ret = "Place of Birth Area";
				break;
			case 0x4Bu:
				ret = "Place of Birth StateCode";
				break;
			case 0x4Cu:
				ret = "Address Street";
				break;
			case 0x4Du:
				ret = "Address City";
				break;
			case 0x4Eu:
				ret = "Address Jurisdiction Code";
				break;
			case 0x4Fu:
				ret = "Address Postal Code";
				break;
			case 0x50u:
				ret = "Document Number Checkdigit";
				break;
			case 0x51u:
				ret = "Date of Birth Checkdigit";
				break;
			case 0x52u:
				ret = "Date of Expiry Checkdigit";
				break;
			case 0x53u:
				ret = "Personal Number Checkdigit";
				break;
			case 0x54u:
				ret = "Final Checkdigit";
				break;
			case 0x55u:
				ret = "Passport Number Checkdigit";
				break;
			case 0x56u:
				ret = "Invitation Number Checkdigit";
				break;
			case 0x57u:
				ret = "Visa ID Checkdigit";
				break;
			case 0x58u:
				ret = "Surname And Given Names Checkdigit";
				break;
			case 0x59u:
				ret = "Visa Valid Until Checkdigit";
				break;
			case 0x5Au:
				ret = "Permit DL Class";
				break;
			case 0x5Bu:
				ret = "Permit Date of Expiry";
				break;
			case 0x5Cu:
				ret = "Permit Identifier";
				break;
			case 0x5Du:
				ret = "Permit Date of Issue";
				break;
			case 0x5Eu:
				ret = "Permit Restriction Code";
				break;
			case 0x5Fu:
				ret = "Permit Endorsed";
				break;
			case 0x60u:
				ret = "Issue Timestamp";
				break;
			case 0x61u:
				ret = "Number of Duplicates";
				break;
			case 0x62u:
				ret = "Medical Indicator Codes";
				break;
			case 0x63u:
				ret = "Non Resident Indicator";
				break;
			case 0x64u:
				ret = "Visa Type";
				break;
			case 0x65u:
				ret = "Visa Valid From";
				break;
			case 0x66u:
				ret = "Visa Valid Until";
				break;
			case 0x67u:
				ret = "Duration of Stay";
				break;
			case 0x68u:
				ret = "Number of Entries";
				break;
			case 0x69u:
				ret = "Day";
				break;
			case 0x6Au:
				ret = "Month";
				break;
			case 0x6Bu:
				ret = "Year";
				break;
			case 0x6Cu:
				ret = "Unique Customer Identifier";
				break;
			case 0x6Du:
				ret = "Commercial Vehicle Codes";
				break;
			case 0x6Eu:
				ret = "AKA Date of Birth";
				break;
			case 0x6Fu:
				ret = "AKA Social Security Number";
				break;
			case 0x70u:
				ret = "AKA Surname";
				break;
			case 0x71u:
				ret = "AKA Given Names";
				break;
			case 0x72u:
				ret = "AKA Name Suffix";
				break;
			case 0x73u:
				ret = "AKA Name Prefix";
				break;
			case 0x74u:
				ret = "Mailing Address Street";
				break;
			case 0x75u:
				ret = "Mailing Address City";
				break;
			case 0x76u:
				ret = "Mailing Address Jurisdiction Code";
				break;
			case 0x77u:
				ret = "Mailing Address Postal Code";
				break;
			case 0x78u:
				ret = "Audit Information";
				break;
			case 0x79u:
				ret = "Inventory Number";
				break;
			case 0x7Au:
				ret = "Race Ethnicity";
				break;
			case 0x7Bu:
				ret = "Jurisdiction Vehicle Class";
				break;
			case 0x7Cu:
				ret = "Jurisdiction Endorsement Code";
				break;
			case 0x7Du:
				ret = "Jurisdiction Restriction Code";
				break;
			case 0x7Eu:
				ret = "Family Name";
				break;
			case 0x7Fu:
				ret = "Given Names RUS";
				break;
			case 0x80u:
				ret = "Visa ID RUS";
				break;
			case 0x81u:
				ret = "Fathers Name";
				break;
			case 0x82u:
				ret = "Fathers Name RUS";
				break;
			case 0x83u:
				ret = "Surname And Given Names RUS";
				break;
			case 0x84u:
				ret = "Place Of Birth RUS";
				break;
			case 0x85u:
				ret = "Authority RUS";
				break;
			case 0x86u:
				ret = "Issuing State Code Numeric";
				break;
			case 0x87u:
				ret = "Nationality Code Numeric";
				break;
			case 0x88u:
				ret = "Engine Power";
				break;
			case 0x89u:
				ret = "Engine Volume";
				break;
			case 0x8Au:
				ret = "Chassis Number";
				break;
			case 0x8Bu:
				ret = "Engine Number";
				break;
			case 0x8Cu:
				ret = "Engine Model";
				break;
			case 0x8Du:
				ret = "Vehicle Category";
				break;
			case 0x8Eu:
				ret = "Identity Card Number";
				break;
			case 0x8Fu:
				ret = "Control No";
				break;
			case 0x90u:
				ret = "Parent's Given Names";
				break;
			case 0x91u:
				ret = "Second Surname";
				break;
			case 0x92u:
				ret = "Middle Name";
				break;
			case 0x93u:
				ret = "RegCert VIN";
				break;
			case 0x94u:
				ret = "RegCert VIN CheckDigit";
				break;
			case 0x95u:
				ret = "RegCert VIN Checksum";
				break;
			case 0x96u:
				ret = "Line1 CheckDigit";
				break;
			case 0x97u:
				ret = "Line2 CheckDigit";
				break;
			case 0x98u:
				ret = "Line3 CheckDigit";
				break;
			case 0x99u:
				ret = "Line1 Checksum";
				break;
			case 0x9Au:
				ret = "Line2 Checksum";
				break;
			case 0x9Bu:
				ret = "Line3 Checksum";
				break;
			case 0x9Cu:
				ret = "RegCert RegNumber CheckDigit";
				break;
			case 0x9Du:
				ret = "RegCert RegNumber Checksum";
				break;
			case 0x9Eu:
				ret = "RegCert Vehicle ITS Code";
				break;
			case 0x9Fu:
				ret = "Card Access Number";
				break;
			case 0xA0u:
				ret = "Marital Status";
				break;
			case 0xA1u:
				ret = "Company Name";
				break;
			case 0xA2u:
				ret = "Special Notes";
				break;
			case 0xA3u:
				ret = "Surname of Spouse";
				break;
			case 0xA4u:
				ret = "Tracking Number";
				break;
			case 0xA5u:
				ret = "Booklet Number";
				break;
			case 0xA6u:
				ret = "Children";
				break;
			case 0xA7u:
				ret = "Copy";
				break;
			case 0xA8u:
				ret = "Serial Number";
				break;
			case 0xA9u:
				ret = "Dossier Number";
				break;
			case 0xAAu:
				ret = "AKA Surname And Given Names";
				break;
			case 0xABu:
				ret = "Territorial Validity";
				break;
			case 0xACu:
				ret = "MRZ Strings With Correct CheckSums";
				break;
			case 0xADu:
				ret = "DL CDL Restriction Code";
				break;
			case 0xAEu:
				ret = "DL Under 18 Date";
				break;
			case 0xAFu:
				ret = "DL Record Created";
				break;
			case 0xB0u:
				ret = "DL Duplicate Date";
				break;
			case 0xB1u:
				ret = "DL Iss Type";
				break;
			case 0xB2u:
				ret = "Military Book Number";
				break;
			case 0xB3u:
				ret = "Destination";
				break;
			case 0xB4u:
				ret = "Blood Group";
				break;
			case 0xB5u:
				ret = "Sequence Number";
				break;
			case 0xB6u:
				ret = "RegCert BodyType";
				break;
			case 0xB7u:
				ret = "RegCert CarMark";
				break;
			case 0xB8u:
				ret = "Transaction Number";
				break;
			case 0xB9u:
				ret = "Age";
				break;
			case 0xBAu:
				ret = "Folio Number";
				break;
			case 0xBBu:
				ret = "Voter Key";
				break;
			case 0xBCu:
				ret = "Address Municipality";
				break;
			case 0xBDu:
				ret = "Address Location";
				break;
			case 0xBEu:
				ret = "Section";
				break;
			case 0xBFu:
				ret = "OCR Number";
				break;
			case 0xC0u:
				ret = "Federal Elections";
				break;
			case 0xC1u:
				ret = "Reference Number";
				break;
			case 0xC2u:
				ret = "Optional Data Checksum";
				break;
			case 0xC3u:
				ret = "Optional Data CheckDigit";
				break;
			case 0xC4u:
				ret = "Visa Number";
				break;
			case 0xC5u:
				ret = "Visa Number Checksum";
				break;
			case 0xC6u:
				ret = "Visa Number CheckDigit";
				break;
			case 0xC7u:
				ret = "Voter";
				break;
			case 0xC8u:
				ret = "Previous Type";
				break;
			case 0xDCu:
				ret = "FieldFromMRZ";
				break;
			case 0xDDu:
				ret = "CurrentDate";
				break;
			case 0xFBu:
				ret = "Status Date of Expiry";
				break;
			case 0xFCu:
				ret = "Banknote Number";
				break;
			case 0xFDu:
				ret = "CSC Code";
				break;
			case 0xFEu:
				ret = "Artistic Name";
				break;
			case 0xFFu:
				ret = "Academic Title";
				break;
			case 0x100u:
				ret = "Address Country";
				break;
			case 0x101u:
				ret = "Address Zip code";
				break;
			case 0x102u:
				ret = "eID Residence Permit1";
				break;
			case 0x103u:
				ret = "eID Residence Permit2";
				break;
			case 0x104u:
				ret = "eID PlaceOfBirth Street";
				break;
			case 0x105u:
				ret = "eID PlaceOfBirth City";
				break;
			case 0x106u:
				ret = "eID PlaceOfBirth State";
				break;
			case 0x107u:
				ret = "eID PlaceOfBirth Country";
				break;
			case 0x108u:
				ret = "eID PlaceOfBirth Zip code";
				break;
			case 0x109u:
				ret = "CDL Class";
				break;
			case 0x10Au:
				ret = "DL Under 19 Date";
				break;
			case 0x10Bu:
				ret = "Weight pounds";
				break;
			case 0x10Cu:
				ret = "Limited Duration Document Indicator";
				break;
			case 0x10Du:
				ret = "Endorsement Expiration Date";
				break;
			case 0x10Eu:
				ret = "Revision Date";
				break;
			case 0x10Fu:
				ret = "Compliance Type";
				break;
			case 0x110u:
				ret = "Family name truncation";
				break;
			case 0x111u:
				ret = "First name truncation";
				break;
			case 0x112u:
				ret = "Middle name truncation";
				break;
			case 0x113u:
				ret = "Exam Date";
				break;
			case 0x114u:
				ret = "Organization";
				break;
			case 0x115u:
				ret = "Department";
				break;
			case 0x116u:
				ret = "Pay Grade";
				break;
			case 0x117u:
				ret = "Rank";
				break;
			case 0x118u:
				ret = "Benefits Number";
				break;
			case 0x119u:
				ret = "Sponsor Service";
				break;
			case 0x11Au:
				ret = "Sponsor Status";
				break;
			case 0x11Bu:
				ret = "Sponsor";
				break;
			case 0x11Cu:
				ret = "Relationship";
				break;
			case 0x11Du:
				ret = "USCIS";
				break;
			case 0x11Eu:
				ret = "Category";
				break;
			case 0x11Fu:
				ret = "Conditions";
				break;
			case 0x120u:
				ret = "Identifier";
				break;
			case 0x121u:
				ret = "Configuration";
				break;
			case 0x122u:
				ret = "Discretionary data";
				break;
			case 0x123u:
				ret = "Line1 Optional Data";
				break;
			case 0x124u:
				ret = "Line2 Optional Data";
				break;
			case 0x125u:
				ret = "Line3 Optional Data";
				break;
			case 0x126u:
				ret = "EQV Code";
				break;
			case 0x127u:
				ret = "ALT Code";
				break;
			case 0x128u:
				ret = "Binary Code";
				break;
			case 0x129u:
				ret = "Pseudo Code";
				break;
			case 0x12Au:
				ret = "Fee";
				break;
			case 0x12Bu:
				ret = "Stamp Number";
				break;
			case 0x12Cu:
				ret = "SBH Security Options";
				break;
			case 0x12Du:
				ret = "SBH Integrity Options";
				break;
			case 0x12Eu:
				ret = "Date of Creation";
				break;
			case 0x12Fu:
				ret = "Validity Period";
				break;
			case 0x130u:
				ret = "Patron Header Version";
				break;
			case 0x131u:
				ret = "BDB Type";
				break;
			case 0x132u:
				ret = "Biometric Type";
				break;
			case 0x133u:
				ret = "Biometric Subtype";
				break;
			case 0x134u:
				ret = "Biometric Product ID";
				break;
			case 0x135u:
				ret = "Biometric Format Owner";
				break;
			case 0x136u:
				ret = "Biometric Format Type";
				break;
			case 0x137u:
				ret = "Phone";
				break;
			case 0x138u:
				ret = "Profession";
				break;
			case 0x139u:
				ret = "Title";
				break;
			case 0x13Au:
				ret = "Personal Summary";
				break;
			case 0x13Bu:
				ret = "Other Valid ID";
				break;
			case 0x13Cu:
				ret = "Custody Info";
				break;
			case 0x13Du:
				ret = "Other Name";
				break;
			case 0x13Eu:
				ret = "Observations";
				break;
			case 0x13Fu:
				ret = "Tax";
				break;
			case 0x140u:
				ret = "Date of Personalization";
				break;
			case 0x141u:
				ret = "Personalization SN";
				break;
			case 0x142u:
				ret = "Other Person Name";
				break;
			case 0x143u:
				ret = "Person To Notify Date of Record";
				break;
			case 0x144u:
				ret = "Person To Notify Name";
				break;
			case 0x145u:
				ret = "Person To Notify Phone";
				break;
			case 0x146u:
				ret = "Person To Notify Address";
				break;
			case 0x147u:
				ret = "DS Certificate Issuer";
				break;
			case 0x148u:
				ret = "DS Certificate Subject";
				break;
			case 0x149u:
				ret = "DS Certificate Valid From";
				break;
			case 0x14Au:
				ret = "DS Certificate Valid To";
				break;
			case 0x14Bu:
				ret = "VRC Data Object Entry";
				break;
			case 0x14Cu:
				ret = "Type Approval Number";
				break;
			case 0x14Du:
				ret = "Administrative Number";
				break;
			case 0x14Eu:
				ret = "Document Discriminator";
				break;
			case 0x14Fu:
				ret = "Data Discriminator";
				break;
			case 0x150u:
				ret = "ISO Issuer ID Number";
				break;
			case 0x154u:
				ret = "GNIB Number";
				break;
			case 0x155u:
				ret = "Dept Number";
				break;
			case 0x156u:
				ret = "Telex Code";
				break;
			case 0x157u:
				ret = "Allergies";
				break;
			case 0x158u:
				ret = "Sp Code";
				break;
			case 0x159u:
				ret = "Court Code";
				break;
			case 0x15Au:
				ret = "Cty";
				break;
			case 0x15Bu:
				ret = "Sponsor SSN";
				break;
			case 0x15Cu:
				ret = "DoD Number";
				break;
			case 0x15Du:
				ret = "MC Novice Date";
				break;
			case 0x15Eu:
				ret = "DUF Number";
				break;
			case 0x15Fu:
				ret = "AGY";
				break;
			case 0x160u:
				ret = "PNR Code";
				break;
			case 0x161u:
				ret = "From Airport Code";
				break;
			case 0x162u:
				ret = "To Airport Code";
				break;
			case 0x163u:
				ret = "Flight Number";
				break;
			case 0x164u:
				ret = "Date of Flight";
				break;
			case 0x165u:
				ret = "Seat Number";
				break;
			case 0x166u:
				ret = "Date of Issue Boarding Pass";
				break;
			case 0x167u:
				ret = "CCW Until";
				break;
			case 0x168u:
				ret = "Reference Number Checksum";
				break;
			case 0x169u:
				ret = "Reference Number CheckDigit";
				break;
			case 0x16Au:
				ret = "Room Number";
				break;
			case 0x16Bu:
				ret = "Religion";
				break;
			case 0x16Cu:
				ret = "RemainderTerm";
				break;
			case 0x16Du:
				ret = "Electronic Ticket Indicator";
				break;
			case 0x16Eu:
				ret = "Compartment Code";
				break;
			case 0x16Fu:
				ret = "CheckIn Sequence Number";
				break;
			case 0x170u:
				ret = "Airline Designator of boarding pass issuer";
				break;
			case 0x171u:
				ret = "Airline Numeric Code";
				break;
			case 0x172u:
				ret = "Ticket Number";
				break;
			case 0x173u:
				ret = "Frequent Flyer Airline Designator";
				break;
			case 0x174u:
				ret = "Frequent Flyer Number";
				break;
			case 0x175u:
				ret = "Free Baggage Allowance";
				break;
			case 0x176u:
				ret = "PDF417Codec";
				break;
			case 0x177u:
				ret = "Identity Card Number Checksum";
				break;
			case 0x178u:
				ret = "Identity Card Number CheckDigit";
				break;
			case 0x179u:
				ret = "Veteran";
				break;
			case 0x17Au:
				ret = "DLClassCode A1 From";
				break;
			case 0x17Bu:
				ret = "DLClassCode A1 To";
				break;
			case 0x17Cu:
				ret = "DLClassCode A1 Notes";
				break;
			case 0x17Du:
				ret = "DLClassCode A From";
				break;
			case 0x17Eu:
				ret = "DLClassCode A To";
				break;
			case 0x17Fu:
				ret = "DLClassCode A Notes";
				break;
			case 0x180u:
				ret = "DLClassCode B From";
				break;
			case 0x181u:
				ret = "DLClassCode B To";
				break;
			case 0x182u:
				ret = "DLClassCode B Notes";
				break;
			case 0x183u:
				ret = "DLClassCode C1 From";
				break;
			case 0x184u:
				ret = "DLClassCode C1 To";
				break;
			case 0x185u:
				ret = "DLClassCode C1 Notes";
				break;
			case 0x186u:
				ret = "DLClassCode C From";
				break;
			case 0x187u:
				ret = "DLClassCode C To";
				break;
			case 0x188u:
				ret = "DLClassCode C Notes";
				break;
			case 0x189u:
				ret = "DLClassCode D1 From";
				break;
			case 0x18Au:
				ret = "DLClassCode D1 To";
				break;
			case 0x18Bu:
				ret = "DLClassCode D1 Notes";
				break;
			case 0x18Cu:
				ret = "DLClassCode D From";
				break;
			case 0x18Du:
				ret = "DLClassCode D To";
				break;
			case 0x18Eu:
				ret = "DLClassCode D Notes";
				break;
			case 0x18Fu:
				ret = "DLClassCode BE From";
				break;
			case 0x190u:
				ret = "DLClassCode BE To";
				break;
			case 0x191u:
				ret = "DLClassCode BE Notes";
				break;
			case 0x192u:
				ret = "DLClassCode C1E From";
				break;
			case 0x193u:
				ret = "DLClassCode C1E To";
				break;
			case 0x194u:
				ret = "DLClassCode C1E Notes";
				break;
			case 0x195u:
				ret = "DLClassCode CE From";
				break;
			case 0x196u:
				ret = "DLClassCode CE To";
				break;
			case 0x197u:
				ret = "DLClassCode CE Notes";
				break;
			case 0x198u:
				ret = "DLClassCode D1E From";
				break;
			case 0x199u:
				ret = "DLClassCode D1E To";
				break;
			case 0x19Au:
				ret = "DLClassCode D1E Notes";
				break;
			case 0x19Bu:
				ret = "DLClassCode DE From";
				break;
			case 0x19Cu:
				ret = "DLClassCode DE To";
				break;
			case 0x19Du:
				ret = "DLClassCode DE Notes";
				break;
			case 0x19Eu:
				ret = "DLClassCode M From";
				break;
			case 0x19Fu:
				ret = "DLClassCode M To";
				break;
			case 0x1A0u:
				ret = "DLClassCode M Notes";
				break;
			case 0x1A1u:
				ret = "DLClassCode L From";
				break;
			case 0x1A2u:
				ret = "DLClassCode L To";
				break;
			case 0x1A3u:
				ret = "DLClassCode L Notes";
				break;
			case 0x1A4u:
				ret = "DLClassCode T From";
				break;
			case 0x1A5u:
				ret = "DLClassCode T To";
				break;
			case 0x1A6u:
				ret = "DLClassCode T Notes";
				break;
			case 0x1A7u:
				ret = "DLClassCode AM From";
				break;
			case 0x1A8u:
				ret = "DLClassCode AM To";
				break;
			case 0x1A9u:
				ret = "DLClassCode AM Notes";
				break;
			case 0x1AAu:
				ret = "DLClassCode A2 From";
				break;
			case 0x1ABu:
				ret = "DLClassCode A2 To";
				break;
			case 0x1ACu:
				ret = "DLClassCode A2 Notes";
				break;
			case 0x1ADu:
				ret = "DLClassCode B1 From";
				break;
			case 0x1AEu:
				ret = "DLClassCode B1 To";
				break;
			case 0x1AFu:
				ret = "DLClassCode B1 Notes";
				break;
			case 0x1B0u:
				ret = "Surname at Birth";
				break;
			case 0x1B1u:
				ret = "Civil Status";
				break;
			case 0x1B2u:
				ret = "Number of Seats";
				break;
			case 0x1B3u:
				ret = "Number of Standing Places";
				break;
			case 0x1B4u:
				ret = "Max Speed";
				break;
			case 0x1B5u:
				ret = "Fuel Type";
				break;
			case 0x1B6u:
				ret = "EC Environmental Type";
				break;
			case 0x1B7u:
				ret = "Power Weight Ratio";
				break;
			case 0x1B8u:
				ret = "Max Mass of Trailer Braked";
				break;
			case 0x1B9u:
				ret = "Max Mass of Trailer Unbraked";
				break;
			case 0x1BAu:
				ret = "Transmission Type";
				break;
			case 0x1BBu:
				ret = "Trailer Hitch";
				break;
			case 0x1BCu:
				ret = "Accompanied by";
				break;
			case 0x1BDu:
				ret = "Police District";
				break;
			case 0x1BEu:
				ret = "First Issue Date";
				break;
			case 0x1BFu:
				ret = "Payload Capacity";
				break;
			case 0x1C0u:
				ret = "Number of Axis";
				break;
			case 0x1C1u:
				ret = "Permissible Axle Load";
				break;
			case 0x1C2u:
				ret = "Precinct";
				break;
			case 0x1C3u:
				ret = "Invited by";
				break;
			case 0x1C4u:
				ret = "Purpose of Entry";
				break;
			case 0x1C5u:
				ret = "Skin Color";
				break;
			case 0x1C6u:
				ret = "Complexion";
				break;
			case 0x1C7u:
				ret = "Airport From";
				break;
			case 0x1C8u:
				ret = "Airport To";
				break;
			case 0x1C9u:
				ret = "Airline Name";
				break;
			case 0x1CAu:
				ret = "Airline Name Frequent Flyer";
				break;
			case 0x1CBu:
				ret = "License number";
				break;
			case 0x1CCu:
				ret = "In Tanks";
				break;
			case 0x1CDu:
				ret = "Exept In Tanks";
				break;
			case 0x1CEu:
				ret = "Fast track";
				break;
			case 0x1CFu:
				ret = "Owner";
				break;
			case 0x1D0u:
				ret = "MRZ Strings ICAO for RFID";
				break;
			case 0x1D1u:
				ret = "Card issuance number";
				break;
			case 0x1D2u:
				ret = "Card issuance number checksum";
				break;
			case 0x1D3u:
				ret = "Card issuance number checkdigit";
				break;
			case 0x1D4u:
				ret = "Date of birth (century)";
				break;
			case 0x1D5u:
				ret = "DLClassCode A3 From";
				break;
			case 0x1D6u:
				ret = "DLClassCode A3 To";
				break;
			case 0x1D7u:
				ret = "DLClassCode A3 Notes";
				break;
			case 0x1D8u:
				ret = "DLClassCode C2 From";
				break;
			case 0x1D9u:
				ret = "DLClassCode C2 To";
				break;
			case 0x1DAu:
				ret = "DLClassCode C2 Notes";
				break;
			case 0x1DBu:
				ret = "DLClassCode B2 From";
				break;
			case 0x1DCu:
				ret = "DLClassCode B2 To";
				break;
			case 0x1DDu:
				ret = "DLClassCode B2 Notes";
				break;
			case 0x1DEu:
				ret = "DLClassCode D2 From";
				break;
			case 0x1DFu:
				ret = "DLClassCode D2 To";
				break;
			case 0x1E0u:
				ret = "DLClassCode D2 Notes";
				break;
			case 0x1E1u:
				ret = "DLClassCode B2E From";
				break;
			case 0x1E2u:
				ret = "DLClassCode B2E To";
				break;
			case 0x1E3u:
				ret = "DLClassCode B2E Notes";
				break;
			case 0x1E4u:
				ret = "DLClassCode G From";
				break;
			case 0x1E5u:
				ret = "DLClassCode G To";
				break;
			case 0x1E6u:
				ret = "DLClassCode G Notes";
				break;
			case 0x1E7u:
				ret = "DLClassCode J From";
				break;
			case 0x1E8u:
				ret = "DLClassCode J To";
				break;
			case 0x1E9u:
				ret = "DLClassCode J Notes";
				break;
			case 0x1EAu:
				ret = "DLClassCode LC From";
				break;
			case 0x1EBu:
				ret = "DLClassCode LC To";
				break;
			case 0x1ECu:
				ret = "DLClassCode LC Notes";
				break;
			case 0x1EDu:
				ret = "Bank Card Number";
				break;
			case 0x1EEu:
				ret = "Bank Card Valid Thru";
				break;
			case 0x1EFu:
				ret = "Tax Number";
				break;
			case 0x1F0u:
				ret = "Health Number";
				break;
			case 0x1F1u:
				ret = "Grandfather Name";
				break;
			case 0x1F2u:
				ret = "Selectee Indicator";
				break;
			case 0x1F3u:
				ret = "Mother Surname";
				break;
			case 0x1F4u:
				ret = "Mother Given Name";
				break;
			case 0x1F5u:
				ret = "Father Surname";
				break;
			case 0x1F6u:
				ret = "Father Given Name";
				break;
			case 0x1F7u:
				ret = "Mother Date Of Birth";
				break;
			case 0x1F8u:
				ret = "Father Date Of Birth";
				break;
			case 0x1F9u:
				ret = "Mother Personal Number";
				break;
			case 0x1FAu:
				ret = "Father Personal Number";
				break;
			case 0x1FBu:
				ret = "Mother Place Of Birth";
				break;
			case 0x1FCu:
				ret = "Father Place Of Birth";
				break;
			case 0x1FDu:
				ret = "Mother Country Of Birth";
				break;
			case 0x1FEu:
				ret = "Father Country Of Birth";
				break;
			case 0x1FFu:
				ret = "Date Of First Renewal";
				break;
			case 0x200u:
				ret = "Date Of Second Renewal";
				break;
			case 0x201u:
				ret = "Place Of Examination";
				break;
			case 0x202u:
				ret = "Application Number";
				break;
			case 0x203u:
				ret = "Voucher Number";
				break;
			case 0x204u:
				ret = "Authorization Number";
				break;
			case 0x205u:
				ret = "Faculty";
				break;
			case 0x206u:
				ret = "Form Of Education";
				break;
			case 0x207u:
				ret = "DNI Number";
				break;
			case 0x208u:
				ret = "Retirement Number";
				break;
			case 0x209u:
				ret = "Professional ID Number";
				break;
			case 0x20Au:
				ret = "Age at Issue";
				break;
			case 0x20Bu:
				ret = "Years Since Issue";
				break;
			case 0x20Cu:
				ret = "DLClassCode BTP From";
				break;
			case 0x20Du:
				ret = "DLClassCode BTP Notes";
				break;
			case 0x20Eu:
				ret = "DLClassCode BTP To";
				break;
			case 0x20Fu:
				ret = "DLClassCode C3 From";
				break;
			case 0x210u:
				ret = "DLClassCode C3 Notes";
				break;
			case 0x211u:
				ret = "DLClassCode C3 To";
				break;
			case 0x212u:
				ret = "DLClassCode E From";
				break;
			case 0x213u:
				ret = "DLClassCode E Notes";
				break;
			case 0x214u:
				ret = "DLClassCode E To";
				break;
			case 0x215u:
				ret = "DLClassCode F From";
				break;
			case 0x216u:
				ret = "DLClassCode F Notes";
				break;
			case 0x217u:
				ret = "DLClassCode F To";
				break;
			case 0x218u:
				ret = "DLClassCode FA From";
				break;
			case 0x219u:
				ret = "DLClassCode FA Notes";
				break;
			case 0x21Au:
				ret = "DLClassCode FA To";
				break;
			case 0x21Bu:
				ret = "DLClassCode FA1 From";
				break;
			case 0x21Cu:
				ret = "DLClassCode FA1 Notes";
				break;
			case 0x21Du:
				ret = "DLClassCode FA1 To";
				break;
			case 0x21Eu:
				ret = "DLClassCode FB From";
				break;
			case 0x21Fu:
				ret = "DLClassCode FB Notes";
				break;
			case 0x220u:
				ret = "DLClassCode FB To";
				break;
			case 0x221u:
				ret = "DLClassCode G1 From";
				break;
			case 0x222u:
				ret = "DLClassCode G1 Notes";
				break;
			case 0x223u:
				ret = "DLClassCode G1 To";
				break;
			case 0x224u:
				ret = "DLClassCode H From";
				break;
			case 0x225u:
				ret = "DLClassCode H Notes";
				break;
			case 0x226u:
				ret = "DLClassCode H To";
				break;
			case 0x227u:
				ret = "DLClassCode I From";
				break;
			case 0x228u:
				ret = "DLClassCode I Notes";
				break;
			case 0x229u:
				ret = "DLClassCode I To";
				break;
			case 0x22Au:
				ret = "DLClassCode K From";
				break;
			case 0x22Bu:
				ret = "DLClassCode K Notes";
				break;
			case 0x22Cu:
				ret = "DLClassCode K To";
				break;
			case 0x22Du:
				ret = "DLClassCode LK From";
				break;
			case 0x22Eu:
				ret = "DLClassCode LK Notes";
				break;
			case 0x22Fu:
				ret = "DLClassCode LK To";
				break;
			case 0x230u:
				ret = "DLClassCode N From";
				break;
			case 0x231u:
				ret = "DLClassCode N Notes";
				break;
			case 0x232u:
				ret = "DLClassCode N To";
				break;
			case 0x233u:
				ret = "DLClassCode S From";
				break;
			case 0x234u:
				ret = "DLClassCode S Notes";
				break;
			case 0x235u:
				ret = "DLClassCode S To";
				break;
			case 0x236u:
				ret = "DLClassCode TB From";
				break;
			case 0x237u:
				ret = "DLClassCode TB Notes";
				break;
			case 0x238u:
				ret = "DLClassCode TB To";
				break;
			case 0x239u:
				ret = "DLClassCode TM From";
				break;
			case 0x23Au:
				ret = "DLClassCode TM Notes";
				break;
			case 0x23Bu:
				ret = "DLClassCode TM To";
				break;
			case 0x23Cu:
				ret = "DLClassCode TR From";
				break;
			case 0x23Du:
				ret = "DLClassCode TR Notes";
				break;
			case 0x23Eu:
				ret = "DLClassCode TR To";
				break;
			case 0x23Fu:
				ret = "DLClassCode TV From";
				break;
			case 0x240u:
				ret = "DLClassCode TV Notes";
				break;
			case 0x241u:
				ret = "DLClassCode TV To";
				break;
			case 0x242u:
				ret = "DLClassCode V From";
				break;
			case 0x243u:
				ret = "DLClassCode V Notes";
				break;
			case 0x244u:
				ret = "DLClassCode V To";
				break;
			case 0x245u:
				ret = "DLClassCode W From";
				break;
			case 0x246u:
				ret = "DLClassCode W Notes";
				break;
			case 0x247u:
				ret = "DLClassCode W To";
				break;
			case 0x248u:
				ret = "URL";
				break;
			case 0x249u:
				ret = "Caliber";
				break;
			case 0x24Au:
				ret = "Model";
				break;
			case 0x24Bu:
				ret = "Make";
				break;
			case 0x24Cu:
				ret = "Number of cylinders";
				break;
			case 0x24Du:
				ret = "Husband surname after registration";
				break;
			case 0x24Eu:
				ret = "Wife surname after registration";
				break;
			case 0x24Fu:
				ret = "Wife date of birth";
				break;
			case 0x250u:
				ret = "Husband date of birth";
				break;
			case 0x251u:
				ret = "First person citizenship";
				break;
			case 0x252u:
				ret = "Second person citizenship";
				break;
			case 0x253u:
				ret = "CVV/CVC";
				break;
			default:
				ret = "<unknown>";
				break;
			}
			return ret;
		}
	}

	namespace StringTransform
	{
		tagRECT toRECT(basic_string<char> str)
		{
			tagRECT rc;
			istringstream ss(str);
			vector<int> v11;
			int v12;
			while (1)
			{
				ss >> v12;
				if (ss.fail()) break;
				v11.push_back(v12);
				if (ss.peek() == ',')
					ss.ignore();
			}
			if (v11.size() == 4)
			{
				rc.left = v11[0];
				rc.top = v11[1];
				rc.right = v11[2];
				rc.bottom = v11[3];
			}
			return rc;
		}
	}

	namespace jsoncpp
	{
		namespace imageparam
		{
			tagRECT getFrameRect(Json::Value &a2)
			{
				tagRECT ret = { 0 };
				ret.left = a2["frameLeft"].asInt();
				ret.top = a2["frameTop"].asInt();
				ret.right = a2["frameRight"].asInt();
				ret.bottom = a2["frameBottom"].asInt();
				return ret;
			}
		}
	}

	namespace kwtpn
	{
		int getChecksum(string const&a1)
		{
			vector<int> v14 = { 2, 1, 6, 3, 7, 9, 0xA, 5, 8, 4, 2 };
			int v8 = 0;
			if (a1.size() < 11)
				return 10;
			for (int i = 0; i < 11; i++)
			{
				int v9 = a1[i] - '0';
				if (v9 >= 10)
					return 10;
				v8 += v14[i] * v9;
			}
			return 11 - (v8 % 11);
		}
	}

	namespace romcnp
	{
		int getChecksum(string const&a1)
		{
			vector<int> v14 = { 2, 7, 9, 1, 4, 6, 3, 5, 8, 2, 7, 9 };
			int v8 = 0;
			if (a1.size() < 12)
				return 10;
			for (int i = 0; i < 12; i++)
			{
				int v9 = a1[i] - '0';
				if (v9 >= 10)
					return 10;
				v8 += v14[i] * v9;
			}
			if ((v8 % 11) == 10)
				return 1;
			return (v8 % 11);
		}
	}

	namespace textdoc
	{
		string getMask(TDocVisualExtendedInfo &a2, eVisualFieldType a3)
		{
			for (int i = 0; i < a2.nDVEI_Fields; i++)
			{
				if (a2.pDVEI_ArrayFields[i].u0.nDVEF_FieldType == a3)
				{
					return string(a2.pDVEI_ArrayFields[i].pszDVEF_FieldMask);
				}
			}
			return string();
		}

		string getValue(TDocVisualExtendedInfo &a2, eVisualFieldType a3)
		{
			for (int i = 0; i < a2.nDVEI_Fields; i++)
			{
				if (a2.pDVEI_ArrayFields[i].u0.nDVEF_FieldType == a3)
				{
					return string(a2.pDVEI_ArrayFields[i].pszDVEF_Buf_Text);
				}
			}
			return string();
		}
	}

	string& RootAppDataPath()
	{
		static string str_11412B8;
		return str_11412B8;
	}

	string getLanguageName(int) 
	{ 
		return string(""); 
	}

	void unit(vector<int> &a1, vector<int> const&a2)
	{
		set<int> v15, v12;
		vector<int> v9(a1.size() + a2.size());
		for (uint i = 0; i < a1.size(); i++)
		{
			v15.insert(a1[i]);
		}
		for (uint i = 0; i < a2.size(); i++)
		{
			v12.insert(a2[i]);
		}
		vector<int>::iterator iend = set_union(v15.begin(), v15.end(), v12.begin(), v12.end(), v9.begin());
		v9.erase(iend, v9.end());
		a1 = v9;
	}

	void unit(set<int> &a1, set<int> const&a2)
	{
		a1.insert(a2.begin(), a2.end());
	}

	map<int, int> getCodePages()
	{
		map<int, int> ret;
		ret[1048] = 1250;
		ret[1060] = 1250;
		ret[1038] = 1250;
		ret[1051] = 1250;
		ret[1045] = 1250;
		ret[1052] = 1250;
		ret[2074] = 1250;
		ret[1050] = 1250;
		ret[1029] = 1250;
		ret[1104] = 1251;
		ret[1071] = 1251;
		ret[2115] = 1251;
		ret[1058] = 1251;
		ret[2092] = 1251;
		ret[1092] = 1251;
		ret[1087] = 1251;
		ret[1059] = 1251;
		ret[1088] = 1251;
		ret[1026] = 1251;
		ret[3098] = 1251;
		ret[1049] = 1251;
		ret[1064] = 1251;
		ret[8201] = 1252;
		ret[3084] = 1252;
		ret[1036] = 1252;
		ret[5132] = 1252;
		ret[5129] = 1252;
		ret[6153] = 1252;
		ret[1043] = 1252;
		ret[9225] = 1252;
		ret[4108] = 1252;
		ret[4105] = 1252;
		ret[1110] = 1252;
		ret[10249] = 1252;
		ret[3079] = 1252;
		ret[6156] = 1252;
		ret[12297] = 1252;
		ret[1069] = 1252;
		ret[2067] = 1252;
		ret[2060] = 1252;
		ret[1035] = 1252;
		ret[1080] = 1252;
		ret[1031] = 1252;
		ret[3081] = 1252;
		ret[1033] = 1252;
		ret[2057] = 1252;
		ret[1027] = 1252;
		ret[11273] = 1252;
		ret[7177] = 1252;
		ret[1030] = 1252;
		ret[13321] = 1252;
		ret[15370] = 1252;
		ret[9226] = 1252;
		ret[5130] = 1252;
		ret[7178] = 1252;
		ret[12298] = 1252;
		ret[17418] = 1252;
		ret[4106] = 1252;
		ret[18442] = 1252;
		ret[3082] = 1252;
		ret[13322] = 1252;
		ret[19466] = 1252;
		ret[2058] = 1252;
		ret[10250] = 1252;
		ret[20490] = 1252;
		ret[1034] = 1252;
		ret[14346] = 1252;
		ret[8202] = 1252;
		ret[1089] = 1252;
		ret[1053] = 1252;
		ret[2077] = 1252;
		ret[5127] = 1252;
		ret[1078] = 1252;
		ret[6154] = 1252;
		ret[4103] = 1252;
		ret[16394] = 1252;
		ret[2055] = 1252;
		ret[1039] = 1252;
		ret[1057] = 1252;
		ret[1040] = 1252;
		ret[2064] = 1252;
		ret[2068] = 1252;
		ret[11274] = 1252;
		ret[1046] = 1252;
		ret[1044] = 1252;
		ret[1086] = 1252;
		ret[2110] = 1252;
		ret[2070] = 1252;
		ret[1032] = 1253;
		ret[1091] = 1254;
		ret[1068] = 1254;
		ret[1055] = 1254;
		ret[1037] = 1255;
		ret[5121] = 1256;
		ret[15361] = 1256;
		ret[9217] = 1256;
		ret[3073] = 1256;
		ret[2049] = 1256;
		ret[11265] = 1256;
		ret[13313] = 1256;
		ret[12289] = 1256;
		ret[4097] = 1256;
		ret[6145] = 1256;
		ret[8193] = 1256;
		ret[16385] = 1256;
		ret[1025] = 1256;
		ret[10241] = 1256;
		ret[14337] = 1256;
		ret[1065] = 1256;
		ret[1056] = 1256;
		ret[7169] = 1256;
		ret[1061] = 1257;
		ret[1062] = 1257;
		ret[1063] = 1257;
		ret[1066] = 1258;
		ret[1079] = 1259;
		ret[0] = 1252;

		return ret;
	}

	map<wstring, wchar_t> getCyrillivConvertTable()
	{
		map<wstring, wchar_t> ret;
		ret[L"A"] = 1040;
		ret[L"AH"] = 1040;
		ret[L"B"] = 1041;
		ret[L"V"] = 1042;
		ret[L"W"] = 1042;
		ret[L"G"] = 1043;
		ret[L"D"] = 1044;
		ret[L"E"] = 1045;
		ret[L"ZH"] = 1046;
		ret[L"J"] = 1046;
		ret[L"Z"] = 1047;
		ret[L"I"] = 1048;
		ret[L"K"] = 1050;
		ret[L"Q"] = 1050;
		ret[L"CC"] = 1050;
		ret[L"L"] = 1051;
		ret[L"M"] = 1052;
		ret[L"N"] = 1053;
		ret[L"HN"] = 1053;
		ret[L"O"] = 1054;
		ret[L"P"] = 1055;
		ret[L"R"] = 1056;
		ret[L"S"] = 1057;
		ret[L"C"] = 1057;
		ret[L"T"] = 1058;
		ret[L"TH"] = 1058;
		ret[L"U"] = 1059;
		ret[L"F"] = 1060;
		ret[L"PH"] = 1060;
		ret[L"KH"] = 1061;
		ret[L"H"] = 1061;
		ret[L"X"] = 1061;
		ret[L"TS"] = 1062;
		ret[L"TZ"] = 1062;
		ret[L"ZZ"] = 1062;
		ret[L"CH"] = 1063;
		ret[L"SH"] = 1064;
		ret[L"SCH"] = 1064;
		ret[L"SHCH"] = 1065;
		ret[L"Y"] = 1048;
		ret[L"IU"] = 1070;
		ret[L"UE"] = 1070;
		ret[L"EW"] = 1070;
		ret[L"YA"] = 1071;

		return ret;
	}

	map<int, map<int, string>> getIcaoConvertTable()
	{
		map<int, map<int, string>> ret;
		map<int, string> v82;
		
		v82[0] = "A";
		ret[193] = v82;
		ret[225] = v82;
		ret[192] = v82;
		ret[224] = v82;
		ret[195] = v82;
		ret[227] = v82;
		ret[258] = v82;
		ret[259] = v82;
		ret[256] = v82;
		ret[257] = v82;
		ret[260] = v82;
		ret[261] = v82;
		ret[263] = v82;
		ret[265] = v82;
		ret[913] = v82;
		ret[945] = v82;
		v82[1051] = "C";
		v82[1060] = "C";
		ret[269] = v82;
		v82.erase(1051);
		v82.erase(1060);
		v82[1052] = "C";
		ret[231] = v82;
		v82.erase(1052);
		ret[267] = v82;
		ret[231] = v82;
		ret[1040] = v82;
		ret[1072] = v82;
		ret[194] = v82;
		ret[226] = v82;
		v82[0] = "AA";
		ret[197] = v82;
		ret[229] = v82;
		v82[0] = "AE";
		ret[196] = v82;
		ret[228] = v82;
		ret[198] = v82;
		ret[230] = v82;
		v82[0] = "B";
		ret[1041] = v82;
		ret[1073] = v82;
		v82[0] = "C";
		ret[262] = v82;
		ret[264] = v82;
		ret[268] = v82;
		ret[266] = v82;
		ret[199] = v82;
		ret[1115] = v82;
		v82[0] = "D";
		ret[272] = v82;
		ret[208] = v82;
		ret[273] = v82;
		ret[270] = v82;
		ret[271] = v82;
		ret[1044] = v82;
		ret[1076] = v82;
		ret[1026] = v82;
		ret[916] = v82;
		ret[948] = v82;
		v82[0] = "DZ";
		ret[1029] = v82;
		ret[1039] = v82;
		v82[0] = "E";
		ret[201] = v82;
		ret[233] = v82;
		ret[200] = v82;
		ret[232] = v82;
		ret[202] = v82;
		ret[234] = v82;
		ret[203] = v82;
		ret[235] = v82;
		ret[276] = v82;
		ret[277] = v82;
		ret[278] = v82;
		ret[279] = v82;
		ret[274] = v82;
		ret[275] = v82;
		ret[280] = v82;
		ret[281] = v82;
		ret[282] = v82;
		ret[283] = v82;
		ret[1045] = v82;
		ret[1077] = v82;
		ret[1069] = v82;
		ret[1101] = v82;
		ret[917] = v82;
		ret[949] = v82;
		v82[0] = "F";
		ret[1060] = v82;
		ret[1092] = v82;
		ret[934] = v82;
		ret[966] = v82;
		v82[0] = "G";
		ret[284] = v82;
		ret[285] = v82;
		ret[286] = v82;
		ret[287] = v82;
		ret[288] = v82;
		ret[289] = v82;
		ret[290] = v82;
		ret[291] = v82;
		ret[1168] = v82;
		ret[1169] = v82;
		ret[915] = v82;
		ret[947] = v82;
		v82[0] = "H";
		ret[294] = v82;
		ret[295] = v82;
		ret[292] = v82;
		ret[293] = v82;
		v82[0] = "I";
		v82[1026] = "Y";
		ret[304] = v82;
		ret[305] = v82;
		ret[205] = v82;
		ret[237] = v82;
		ret[204] = v82;
		ret[236] = v82;
		ret[206] = v82;
		ret[238] = v82;
		ret[207] = v82;
		ret[239] = v82;
		ret[296] = v82;
		ret[297] = v82;
		ret[298] = v82;
		ret[299] = v82;
		ret[302] = v82;
		ret[303] = v82;
		ret[300] = v82;
		ret[301] = v82;
		ret[1049] = v82;
		ret[1081] = v82;
		ret[1030] = v82;
		ret[1110] = v82;
		ret[1031] = v82;
		ret[1111] = v82;
		ret[919] = v82;
		ret[951] = v82;
		ret[921] = v82;
		ret[953] = v82;
		v82.erase(1026);
		v82[0] = "IE";
		ret[1026] = v82;
		ret[1028] = v82;
		v82[0] = "IJ";
		ret[306] = v82;
		ret[307] = v82;
		v82[0] = "IU";
		v82[1026] = "YU";
		ret[1070] = v82;
		ret[1102] = v82;
		v82[0] = "IA";
		v82[1026] = "YA";
		ret[1071] = v82;
		ret[1103] = v82;
		v82.erase(1026);
		v82[0] = "J";
		ret[308] = v82;
		ret[309] = v82;
		ret[1032] = v82;
		v82[0] = "K";
		ret[310] = v82;
		ret[311] = v82;
		ret[1050] = v82;
		ret[1082] = v82;
		ret[1036] = v82;
		ret[922] = v82;
		ret[954] = v82;
		v82[0] = "L";
		ret[321] = v82;
		ret[322] = v82;
		ret[313] = v82;
		ret[314] = v82;
		ret[317] = v82;
		ret[318] = v82;
		ret[315] = v82;
		ret[316] = v82;
		ret[319] = v82;
		ret[320] = v82;
		ret[1051] = v82;
		ret[1083] = v82;
		ret[923] = v82;
		ret[955] = v82;
		v82[0] = "LJ";
		ret[1033] = v82;
		v82[0] = "M";
		ret[1052] = v82;
		ret[1084] = v82;
		ret[924] = v82;
		ret[956] = v82;
		v82[0] = "N";
		ret[323] = v82;
		ret[324] = v82;
		ret[209] = v82;
		ret[241] = v82;
		ret[327] = v82;
		ret[328] = v82;
		ret[325] = v82;
		ret[326] = v82;
		ret[330] = v82;
		ret[331] = v82;
		ret[1053] = v82;
		ret[1085] = v82;
		ret[925] = v82;
		ret[957] = v82;
		v82[0] = "NJ";
		ret[1034] = v82;
		v82[0] = "OE";
		ret[216] = v82;
		ret[248] = v82;
		ret[214] = v82;
		ret[246] = v82;
		ret[338] = v82;
		ret[339] = v82;
		v82[0] = "O";
		ret[211] = v82;
		ret[243] = v82;
		ret[210] = v82;
		ret[242] = v82;
		ret[212] = v82;
		ret[244] = v82;
		ret[213] = v82;
		ret[245] = v82;
		ret[336] = v82;
		ret[337] = v82;
		ret[332] = v82;
		ret[333] = v82;
		ret[334] = v82;
		ret[335] = v82;
		ret[1054] = v82;
		ret[1086] = v82;
		ret[927] = v82;
		ret[959] = v82;
		ret[937] = v82;
		ret[969] = v82;
		v82[0] = "P";
		ret[1055] = v82;
		ret[1087] = v82;
		ret[928] = v82;
		ret[960] = v82;
		v82[0] = "PS";
		ret[936] = v82;
		ret[968] = v82;
		v82[0] = "R";
		ret[340] = v82;
		ret[341] = v82;
		ret[344] = v82;
		ret[345] = v82;
		ret[342] = v82;
		ret[343] = v82;
		ret[1056] = v82;
		ret[1088] = v82;
		ret[929] = v82;
		ret[961] = v82;
		v82[0] = "S";
		ret[346] = v82;
		ret[347] = v82;
		ret[348] = v82;
		ret[349] = v82;
		ret[352] = v82;
		ret[353] = v82;
		ret[350] = v82;
		ret[351] = v82;
		ret[1057] = v82;
		ret[1089] = v82;
		ret[931] = v82;
		ret[963] = v82;
		v82[0] = "T";
		ret[358] = v82;
		ret[359] = v82;
		ret[356] = v82;
		ret[357] = v82;
		ret[354] = v82;
		ret[355] = v82;
		ret[1058] = v82;
		ret[1090] = v82;
		ret[932] = v82;
		ret[964] = v82;
		v82[0] = "TH";
		ret[222] = v82;
		ret[920] = v82;
		ret[952] = v82;
		v82[0] = "U";
		ret[218] = v82;
		ret[250] = v82;
		ret[217] = v82;
		ret[249] = v82;
		ret[219] = v82;
		ret[251] = v82;
		ret[360] = v82;
		ret[361] = v82;
		ret[364] = v82;
		ret[365] = v82;
		ret[368] = v82;
		ret[369] = v82;
		ret[366] = v82;
		ret[367] = v82;
		ret[362] = v82;
		ret[363] = v82;
		ret[370] = v82;
		ret[371] = v82;
		ret[1059] = v82;
		ret[1091] = v82;
		ret[1038] = v82;
		ret[1118] = v82;
		ret[933] = v82;
		ret[965] = v82;
		v82[0] = "UE";
		ret[220] = v82;
		ret[252] = v82;
		v82[0] = "V";
		ret[1042] = v82;
		ret[1074] = v82;
		ret[914] = v82;
		ret[946] = v82;
		v82[0] = "W";
		ret[372] = v82;
		ret[373] = v82;
		v82[0] = "X";
		ret[926] = v82;
		ret[958] = v82;
		v82[0] = "Y";
		ret[221] = v82;
		ret[253] = v82;
		ret[374] = v82;
		ret[375] = v82;
		ret[376] = v82;
		ret[1067] = v82;
		ret[1099] = v82;
		v82[0] = "Z";
		ret[377] = v82;
		ret[381] = v82;
		ret[382] = v82;
		ret[379] = v82;
		ret[380] = v82;
		ret[1047] = v82;
		ret[1079] = v82;
		ret[918] = v82;
		ret[950] = v82;
		v82[0] = "SS";
		ret[223] = v82;
		v82[0] = "";
		v82[1026] = "A";
		ret[1066] = v82;
		ret[1098] = v82;
		v82[1026] = "Y";
		ret[1068] = v82;
		ret[1100] = v82;
		v82.erase(1026);
		v82[0] = "I";
		v82[1058] = "Y";
		ret[1048] = v82;
		ret[1080] = v82;
		v82.erase(1058);
		v82[0] = "E";
		v82[1059] = "IO";
		ret[1025] = v82;
		ret[1105] = v82;
		v82.erase(1059);
		v82[0] = "G";
		v82[1059] = "H";
		v82[1071] = "H";
		v82[3098] = "H";
		ret[1043] = v82;
		ret[1075] = v82;
		v82.erase(1059);
		v82[0] = "ZH";
		v82[1071] = "Z";
		v82[3098] = "Z";
		ret[1046] = v82;
		ret[1078] = v82;
		v82[0] = "KH";
		v82[1071] = "H";
		v82[3098] = "H";
		v82[1026] = "H";
		ret[1061] = v82;
		ret[1093] = v82;
		v82.erase(1026);
		v82[0] = "TS";
		v82[1071] = "C";
		v82[3098] = "C";
		ret[1062] = v82;
		ret[1094] = v82;
		v82[0] = "CH";
		v82[1071] = "C";
		v82[3098] = "C";
		ret[1063] = v82;
		ret[1095] = v82;
		ret[935] = v82;
		ret[967] = v82;
		v82[0] = "SH";
		v82[1071] = "S";
		v82[3098] = "S";
		ret[1064] = v82;
		ret[1096] = v82;
		v82.erase(1071);
		v82.erase(3098);
		v82[0] = "SHCH";
		v82[1026] = "SHT";
		ret[1065] = v82;
		ret[1097] = v82;
		v82.erase(1026);
		v82[0] = "A";
		ret[913] = v82;
		ret[945] = v82;
		v82[0] = "A";
		ret[913] = v82;
		ret[945] = v82;
		v82[0] = "#";
		ret[8470] = v82;
		
		return ret;
	}
}

