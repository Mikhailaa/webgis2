#include "FileFsReader.h"
#include "../zlib/zlib.h"

namespace common
{
	FileHeader::FileHeader()
	{
		m_ulFH_off = 0;
		m_ulFH_size = 0;
	}

	FileHeader::FileHeader(common::FileHeader const&a2)
	{
		m_strFH_name = a2.m_strFH_name;
		m_ulFH_off = a2.m_ulFH_off;
		m_ulFH_size = a2.m_ulFH_size;
	}
	
	ulonglong FileHeader::Deserialize(char const*a2, ulonglong a3)
	{
		if (a3 >= 8)
		{
			ulonglong namelen = *(ulonglong*)a2;
			if (a3 >= namelen + sizeof(ulonglong))
			{
				ulonglong size = sizeof(ulonglong);
				m_strFH_name = string(a2 + size, (unsigned int)namelen);
				if (a3 >= namelen + sizeof(ulonglong) + sizeof(ulonglong) + sizeof(ulonglong))
				{
					size += namelen;
					m_ulFH_off = *(ulonglong*)(a2 + size);
					size += sizeof(ulonglong);
					m_ulFH_size = *(ulonglong*)(a2 + size);
					size += sizeof(ulonglong);
					return size;
				}
			}
		}
		return (ulonglong)-1LL;
	}

	FileHeader& FileHeader::operator = (common::FileHeader const& a2)
	{
		m_strFH_name = a2.m_strFH_name;
		m_ulFH_off = a2.m_ulFH_off;
		m_ulFH_size = a2.m_ulFH_size;
		return *this;
	}


	FileFsReader::FileFsReader(istream & a2)
	{
		m_pisFR_stream = &a2;
		m_ulFR_dataoff = 0;
	}


	FileFsReader::~FileFsReader()
	{
	}

	string FileFsReader::DecodeData(string a2)
	{
		string strRet;
		unsigned long datalen = a2.size() * 20;
		unsigned char* data = new unsigned char[datalen];
		if (!uncompress(data, &datalen, (unsigned char*)a2.data(), a2.size()))
		{
			strRet = string((char*)data, datalen);
			delete[] data;
			return strRet;
		}

		delete[] data;
		return strRet;
	}

	string FileFsReader::GetFileData(string const&a2)
	{
		if (m_mapFR_FileHeader.find(a2) != m_mapFR_FileHeader.end())
		{
			FileHeader fhdr = m_mapFR_FileHeader.at(a2);
			string data((unsigned int)fhdr.m_ulFH_size, 0);
			m_pisFR_stream->seekg(m_ulFR_dataoff + fhdr.m_ulFH_off);
			if (!m_pisFR_stream->fail())
			{
				m_pisFR_stream->read((char*)data.data(), data.size());
				if (!m_pisFR_stream->fail())
				{
					return DecodeData(data);
				}
			}
		}

		return string("");
	}

	bool FileFsReader::Load(void)
	{
		ulonglong hdrlen;
		m_pisFR_stream->seekg(0, ios_base::beg);
		m_pisFR_stream->read((char*)&hdrlen, sizeof(ulonglong));
		if (m_pisFR_stream->fail())
			return false;
		m_ulFR_dataoff = hdrlen + 8;
		string hdr((unsigned int)hdrlen, 0);
		m_pisFR_stream->read((char*)hdr.data(), hdr.size());
		if (m_pisFR_stream->fail())
			return false;
		hdr = DecodeData(hdr);
		ulonglong off = 0;
		while (off < hdr.size())
		{
			FileHeader fhdr;
			off += fhdr.Deserialize(hdr.data() + off, hdr.size() - off);
			m_mapFR_FileHeader[fhdr.m_strFH_name] = fhdr;
		}
		return true;
	}
}