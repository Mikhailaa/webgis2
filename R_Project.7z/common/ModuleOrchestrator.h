#pragma once
#include "../pch.h"
#include "../moduleprocessgl.h"

namespace common
{
	class ModuleOrchestrator
	{
	public:
		vector<shared_ptr<moduleprocessgl::IProcessFunction>> m_vMO_8;
		map<uint, shared_ptr<moduleprocessgl::IProcessFunction>> m_vMO_14;

		ModuleOrchestrator();
		~ModuleOrchestrator();
		vector<shared_ptr<moduleprocessgl::IProcessFunction>>& getModules() { return m_vMO_8; };
		template<class T> shared_ptr<T> addModule()
		{
			return addModule(make_shared<T>());
		}
		template<class T> shared_ptr<T> addModule(shared_ptr<T>& a2)
		{
			shared_ptr<T> ret;
			uint val = typeid(T).hash_code();
			if (m_vMO_14.find(val) == m_vMO_14.end())
			{
				m_vMO_14[val] = a2;
				m_vMO_8.push_back(a2);
				ret = a2;
			}
			return ret;
		}
	};

	ModuleOrchestrator *getModuleOrchestrator();
}