#pragma once
#include "../pch.h"
#include "../imaging.h"

namespace common
{
	template <class T> class UniqueObjectByIndex
	{
	public:
		UniqueObjectByIndex() {};
		~UniqueObjectByIndex() {};
		vector<ulonglong> getIds()
		{
			vector<ulonglong> a1;
			for (unordered_map<ulonglong, unique_ptr<T>>::iterator iter = m_xUOBI_map.begin(); iter != m_xUOBI_map.end(); iter++)
			{
				a1.push_back(iter->first);
			}
			return a1;
		};

		T* getObject(ulonglong a2)
		{
			if (m_xUOBI_map.find(a2) == m_xUOBI_map.end())
			{
				m_xUOBI_mtx.lock();
				T* v7 = new T();
				m_xUOBI_map[a2] = unique_ptr<T>(v7);
				m_xUOBI_mtx.unlock();
			}
			return m_xUOBI_map.at(a2).get();
		};
	public:
		mutex m_xUOBI_mtx;
		unordered_map<ulonglong, unique_ptr<T>> m_xUOBI_map;
	};

	namespace ModuleUtils
	{
		string GetModulePath(void);
	};

	namespace Base64
	{
		string base64_encode(uchar const*, uint);
		string base64_decode(string const&);
	};

	namespace bounds
	{
		void invertByH(TBoundsResult &, int);
		void updateDocumentSizeByCoordinates(TBoundsResult &);
	};

	namespace dbupdate 
	{
		void checkDB(string &, string &);
		void updateDB(void);
	};

	namespace system 
	{
		string getCurrentDate(void);
		int getDaysFrom30121899ForYYMMDD(string const&);
		string time_in_HH_MM_SS_MMM(void);
	};

	namespace process
	{
		bool isProcessingTimeExceeded();
	};

	namespace docsize
	{
		float widthMM(CDocFormat);
		float heightMM(CDocFormat);
		float kWH(CDocFormat);
	};

	namespace images
	{
		bool FlipImage(TRawImageContainer &, imaging::eRI_FlipModes);
		bool FlipImage(TResultContainerList &, imaging::eRI_FlipModes);
		bool FlipImage(TResultContainer &, imaging::eRI_FlipModes);
		int FlipImage(uchar *, int, int, int, imaging::eRI_FlipModes);
		bool CropImage(TResultContainerList &, tagRECT);
		bool CropImage(TResultContainer &, tagRECT);
		bool CropImage(TRawImageContainer &, tagRECT);
		int CropImage(uchar *, int, int &, int &, tagRECT);
		bool RotateImage(TResultContainerList &, imaging::eRI_Rotations);
		bool RotateImage(TResultContainer &, imaging::eRI_Rotations);
		bool RotateImage(TRawImageContainer &, imaging::eRI_Rotations);
		int RotateImage(uchar *, int, int &, int &, imaging::eRI_Rotations);
		bool ResizeImage(TResultContainerList &, int, int);
		uint CalculateBitmapSize(tagBITMAPINFO *, uint);
		uint CalculateBitmapSize(uint, uint, uint, uint);
		uint CalculateRowStride(uint, uint, uint);
		bool ResizeImage(TRawImageContainer &, int, int);
		bool ResizeImage(TResultContainer &, int, int);
		int ResizeImage(uchar *, int, int &, int &, int, int, bool);
		int ResizeImage(uchar const*, int, int, int, uchar const*, int, int, bool);
	};

	namespace rotate
	{
		void rotatePoint(tagPOINT &, eRPRM_Orientation, tagSIZE const &, tagSIZE const &);
		void rotateSize(tagSIZE &, eRPRM_Orientation);
		void rotateAngle(int &, eRPRM_Orientation);
	};

	namespace field
	{
		string graphicFieldName(eGraphicFieldType);
		string lcidName(int);
		void setFieldType(TDocGraphicField &, eGraphicFieldType);
		void setFieldType(TDocVisualExtendedField &, eVisualFieldType);
		string textFieldName(eVisualFieldType);
	};

	namespace StringTransform
	{
		tagRECT toRECT(basic_string<char>);
	};

	namespace jsoncpp
	{
		namespace imageparam
		{
			tagRECT getFrameRect(Json::Value &);
		};
	};

	namespace kwtpn
	{
		int getChecksum(string const&);
	};

	namespace romcnp
	{
		int getChecksum(string const&);
	}

	namespace textdoc
	{
		string getMask(TDocVisualExtendedInfo &, eVisualFieldType);
		string getValue(TDocVisualExtendedInfo &, eVisualFieldType);
	}
	
	template <class _Tx, class _Ty>
	vector<_Ty> mapValues(unordered_map<_Tx, _Ty> const&a2)
	{
		vector<_Ty> vRet;

		if (a2.size())
		{
			for (unordered_map<_Tx, _Ty>::const_iterator iter = a2.begin(); iter != a2.end(); iter++)
			{
				vRet.push_back(iter->second);
			}
		}

		return vRet;
	};

	template <class _Tx, class _Ty>
	vector<_Ty> mapValues(multimap<_Tx, _Ty> const&a2, _Tx a3)
	{
		vector<_Ty> vRet;

		if (a2.size())
		{
			pair<multimap<_Tx, _Ty>::const_iterator, multimap<_Tx, _Ty>::const_iterator> v14 = a2.equal_range(a3);
			for (; v14.first != v14.second; ++v14.first)
			{
				vRet.push_back(v14.first->second);
			}
		}

		return vRet;
	};

	template <class _Tx, class _Ty>
	vector<_Ty> mapValues(unordered_multimap<_Tx, _Ty> const&a2, _Tx a3)
	{
		vector<_Ty> vRet;
		if (a2.size())
		{
			pair<unordered_multimap<_Tx, _Ty>::const_iterator, unordered_multimap<_Tx, _Ty>::const_iterator> v17 = a2.equal_range(a3);
			for (; v17.first != v17.second; ++v17.first)
			{
				vRet.push_back(v17.first->second);
			}
		}

		return vRet;
	};

	template <class _Tx, class _Ty>
	_Ty mapValues(unordered_map<_Tx, _Ty> const&a1, _Tx a2, _Ty a3)
	{
		if (a1.size() && a1.find(a2) != a1.end())
			return a1.at(a2);
		return a3;
	};

	template <class _Tx, class _Ty>
	vector<_Tx> mapKeys(unordered_map<_Tx, _Ty> const&a2)
	{
		vector<_Tx> vRet;
		if (a2.size())
		{
			for (unordered_map<_Tx, _Ty>::const_iterator iter = a2.begin(); iter != a2.end(); iter++)
			{
				vRet.push_back(iter->first);
			}
		}
		return vRet;
	};

	template <class _Tx, class _Ty>
	vector<_Tx> mapKeys(multimap<_Tx, _Ty> const& a2)
	{
		vector<_Tx> vRet;
		if (a2.size())
		{
			set<_Tx> a;
			for (multimap<_Tx, _Ty>::const_iterator iter = a2.begin(); iter != a2.end(); iter++)
			{
				a.insert(iter->first);
			}
			return vector<_Tx>(a.begin(), a.end());
		}
		return vRet;
	};

	template <class _Tx, class _Ty>
	vector<_Tx> mapKeys(unordered_map<_Tx, _Ty> const&a2, _Ty a3)
	{
		vector<_Tx> vRet;
		if (a2.size())
		{
			set<_Tx> a;
			for (unordered_map<_Tx, _Ty>::const_iterator iter = a2.begin(); iter != a2.end(); iter++)
			{
				if (iter->second == a3)
					a.insert(iter->first);
			}
			return vector<_Tx>(a.begin(), a.end());
		}
		return vRet;
	};

	template <class _Tx, class _Ty>
	vector<_Tx> mapKeys(unordered_map<_Tx, _Ty> const&a2, vector<_Ty> const&a3)
	{
		vector<_Tx> vRet;
		if (a2.size())
		{
			set<_Tx> a;
			for (unordered_map<_Tx, _Ty>::const_iterator iter = a2.begin(); iter != a2.end(); iter++)
			{
				for (vector<_Ty>::const_iterator iter1 = a3.begin(); iter1 != a3.end(); iter1 ++)
				{
					if (iter->second == *iter1)
					{
						a.insert(iter->first);
						break;
					}
				}
			}
			return vector<_Tx>(a.begin(), a.end());
		}
		return vRet;
	};

	template <class _Tx, class _Ty>
	vector<_Tx> mapKeys(unordered_multimap<_Tx, _Ty> const&a2, _Ty a3)
	{
		vector<_Tx> vRet;
		if (a2.size())
		{
			set<_Tx> a;
			for (typename unordered_multimap<_Tx, _Ty>::const_iterator iter = a2.begin(); iter != a2.end(); iter++)
			{
				if (iter->second == a3)
					a.insert(iter->first);
			}
			return vector<_Tx>(a.begin(), a.end());
		}
		return vRet;
	};

	void unit(vector<int> &, vector<int> const&);
	void unit(set<int> &, set<int> const&);

	template<typename T>
	vector<T> substract(vector<T> const&a2, vector<T> const&a3)
	{
		set<T> v15, v12;
		vector<T> a1;
		for (uint i = 0; i < a2.size(); i++)
		{
			v15.insert(a2[i]);
		}
		for (uint i = 0; i < a3.size(); i++)
		{
			v12.insert(a3[i]);
		}
		set_difference(v15.begin(), v15.end(), v12.begin(), v12.end(), a1.begin());
		return a1;
	}
	template<class _Tx, class _Ty>
	bool contains(_Tx const&a1, _Ty &a2)
	{
		typename _Tx::const_iterator iter;
		for (iter = a1.begin(); iter != a1.end(); iter++)
		{
			if (*iter == (_Ty)a2)
				break;
		}
		return (iter != a1.end());
	};

	string& RootAppDataPath();
	map<int, int> getCodePages();
	map<wstring, wchar_t> getCyrillivConvertTable();
	map<int, map<int, string>> getIcaoConvertTable();
	string getLanguageName(int);
	
	template <class _Tx, class _Ty>
	int indexOf(_Tx const&a1, _Ty const&a2)
	{
		int nRet = 0;
		typename _Tx::const_iterator iter;
		for (iter = a1.begin(); iter != a1.end(); iter++)
		{
			if (*iter == a2)
				return nRet;
			nRet++;
		}
		return -1;
	};

	template <typename T>
	vector<T> intersect(set<T> const&a2, vector<T> const&a3)
	{
		vector<T> vRes(a3.size());
		vector<T> vTemp(a3);
		sort(vTemp.begin(), vTemp.end());
		vector<T> vTemp1(a2.begin(), a2.end());
		sort(vTemp1.begin(), vTemp1.end());
		typename vector<T>::iterator iend = set_intersection(vTemp1.begin(), vTemp1.end(), vTemp.begin(), vTemp.end(), vRes.begin());
		vRes.erase(iend, vRes.end());
		return vRes;
	}

	template <typename T>
	vector<T> intersect(vector<T> const&a2, vector<T> const&a3)
	{
		vector<T> vRes(a3.size());
		vector<T> vTemp(a3);
		sort(vTemp.begin(), vTemp.end());
		vector<T> vTemp1(a2);
		sort(vTemp1.begin(), vTemp1.end());
		typename vector<T>::iterator iend = set_intersection(vTemp1.begin(), vTemp1.end(), vTemp.begin(), vTemp.end(), vRes.begin());
		vRes.erase(iend, vRes.end());
		return vRes;
	}
}