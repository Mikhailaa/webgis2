#include "ImageControl.h"

int calcWidthStep(int width, int depth, int channels, int a4)
{
	int v4 = width * depth * channels / 8 + a4 - 1;
	return v4 - (v4 % a4);
}