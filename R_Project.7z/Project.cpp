// Project.cpp : Defines the entry point for the console application.
//

#include <stdio.h>
#include <io.h>
#include <algorithm>
#include "Project.h"
#include "common/container/container.h"
#include "common/container/jsoncpp.h"
#include "Json/CharReaderBuilder.h"
#include "common/common.h"
#include "mobileadapter.h"
#include "moduleprocessgl.h"
#include "imageConvertor.h"
#include "androidgl.h"
#include "Log.h"

int g_nFromTo_10076F8[6] = { 0, 2, 1, 1, 2, 0 };
int g_nFromTo_10076E0[6] = { 0, 0, 0, 1, 0, 2 };

#ifdef ANDROID_NDK
void getImages(JNIEnv *a1, jobjectArray a2, imageConvertor::ImageParams &a3, androidgl::Data *a4)
#else
void getImages(vector<MyImageData*> const *a2, imageConvertor::ImageParams &a3, androidgl::Data *a4)
#endif
{
	imageConvertor::ImageParams v29;

	memcpy(&v29, &a3, sizeof(imageConvertor::ImageParams));
	if (a2)
	{
#ifdef ANDROID_NDK
		jclass v7 = a1->FindClass("com/regula/core/ImageResult");
		jfieldID v23 = a1->GetFieldID(v7, "pageIndex", "I");
		jfieldID v22 = a1->GetFieldID(v7, "light", "I");
		jfieldID v21 = a1->GetFieldID(v7, "width", "I");
		jfieldID v20 = a1->GetFieldID(v7, "height", "I");
		jfieldID v19 = a1->GetFieldID(v7, "imgBytes", "[B");
		jfieldID v18 = a1->GetFieldID(v7, "type", "I");
		jfieldID v17 = a1->GetFieldID(v7, "exposure", "I");
		int i, v8 = (int)a1->GetArrayLength(a2);
#else
		int i, v8 = a2->size();
#endif
		for (i = 0; i < v8; i++)
		{
#ifdef ANDROID_NDK
			jobject v10 = a1->GetObjectArrayElement(a2, i);
			v29.nIP_height = a1->GetIntField(v10, v21);
			v29.nIP_width = a1->GetIntField(v10, v20);
			v29.nIP_light = a1->GetIntField(v10, v22);
#else
			v29.nIP_height = (*a2)[i]->nID_height;
			v29.nIP_width = (*a2)[i]->nID_width;
			v29.nIP_light = (*a2)[i]->nID_light;
#endif
			if (v29.nIP_light == 0)
				v29.nIP_light = 6;
#ifndef ANDROID_NDK
			v29.nIP_pageIndex = (*a2)[i]->nID_pageIndex;
			v29.nIP_exposure = (*a2)[i]->nID_exposure;
			v29.nIP_type = (*a2)[i]->nID_type;
			imageConvertor::fromBytesToContainer(v29, (*a2)[i]->bID_data, a4->m_xData_rclHolder);
#else
			v29.nIP_pageIndex = a1->GetIntField(v10, v23);
			v29.nIP_exposure = a1->GetIntField(v10, v17);
			v29.nIP_type = a1->GetIntField(v10, v18);
			jobject v15 = a1->GetObjectField(v10, v19);
			uchar* v16;
			if (a1->GetArrayLength(v15))
				v16 = a1->GetByteArrayElements(v15, 0);
			else
				v16 = 0;
			imageConvertor::fromBytesToContainer(v29, v16, a4->m_xData_rclHolder);
			a1->ReleaseByteArrayElements(v15, v16, 2);
			a1->DeleteLocalRef(v15);
#endif
		}
	}
}

#ifdef ANDROID_NDK
jobjectarray getDocumentImages(JNIEnv *a1)
#else
vector<MyImageData*> getDocumentImages()
#endif
{
#ifdef ANDROID_NDK
	jbytearray result;
#else
	vector<MyImageData*> result;
#endif
	bool fSuccess = true;

	androidgl::getObj()->m_xData_mutex1C.lock();
	TResultContainerList* pTRCL = androidgl::getObj()->m_pData_TRCL;
	if (!pTRCL)
	{
		androidgl::getObj()->m_xData_mutex1C.unlock();
#ifdef ANDROID_NDK
		return 0;
#else
		return result;
#endif
	}
	common::container::RclHolder v32;
	v32.addNoCopy(*pTRCL);
	vector<TResultContainer*> v28 = v32.getRcList(1);
	if (v28.empty())
	{
		androidgl::getObj()->m_xData_mutex1C.unlock();
#ifndef ANDROID_NDK
		return result;
	}
#else
		return 0;
	}
	result = a1->NewObjectArray(v28.size(), a1->FindClass("android/graphics/Bitmap"), 0);
#endif
	for (size_t i = 0; i < v28.size(); i ++)
	{
		TRawImageContainer *v7 = v28[i]->u.pTRC_RIC;
		if (!v7)
		{
			fSuccess = false;
			break;
		}
		Mat var58 = common::container::wrapByMat(*v7);
		Mat v31(cv::Size(var58.size.p[1], var58.size.p[0]), 24, Scalar(255.0, 255.0, 255.0, 255.0));
		if (var58.type())
		{
			if (var58.type() == 16)
			{
				cv::mixChannels(&var58, 1, &v31, 1, g_nFromTo_10076F8, 3);
			}
			else
			{
				var58.copyTo(v31);
			}
		}
		else
		{
			cv::mixChannels(&var58, 1, &v31, 1, g_nFromTo_10076E0, 3);
		}
		cv::flip(v31, v31, 0);
#ifdef ANDROID_NDK
		jclass v11 = a1->FindClass("android/graphics/Bitmap");
		jmethodid v12 = a1->GetStaticMethodID(v11, "createBitmap", "(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;");
		jclass v15 = a1->FindClass("android/graphics/Bitmap$Config");
		jmethodid v17 = a1->GetStaticMethodID(v15, "valueOf", "(Ljava/lang/String;)Landroid/graphics/Bitmap$Config;");
		jobject v18 = a1->CallStaticObjectMethod(v15, v17, a1->NewStringUTF("ARGB_8888"));
		jobject v19 = a1->CallStaticObjectMethod(v11, v12, v31.cols, v31.rows, v18);
		uchar* v30;
		if (AndroidBitmap_lockPixels(a1, v19, &v30) < 0)
		{
			fSuccess = false;
			break;
		}
		memcpy(v30, v31.data, 4 * v31.cols * v31.rows);
		AndroidBitmap_unlockPixels(a1, v19);
		a1->SetObjectArrayElement(result, i, v19);
#else
		MyImageData* pImgData = new MyImageData;
		memclr(pImgData, sizeof(MyImageData));
		pImgData->nID_width = v31.cols;
		pImgData->nID_height = v31.rows;
		pImgData->bID_data = new uchar[4 * v31.cols * v31.rows];
		memcpy(pImgData->bID_data, v31.data, 4 * v31.cols * v31.rows);
		result.push_back(pImgData);
#endif
	}
	androidgl::getObj()->m_xData_mutex1C.unlock();
#ifdef ANDROID_NDK
	if (!fSuccess)
		return 0;
#endif
	
	return result;
}

	
#ifdef ANDROID_NDK
jbytearray getImageResults(JNIEnv *a1)
#else
MyImageData* getImageResults()
#endif
{
#ifdef ANDROID_NDK
	jbytearray result;
#else
	MyImageData* result = 0;
#endif
	bool fSuccess = true;

	androidgl::getObj()->m_xData_mutex1C.lock();
	TResultContainerList* pTRCL = androidgl::getObj()->m_pData_TRCL;
	if (!pTRCL)
	{
		androidgl::getObj()->m_xData_mutex1C.unlock();
		return 0;
	}
	common::container::RclHolder v32;
	v32.addNoCopy(*pTRCL);
	vector<TResultContainer*> v28 = v32.getRcList(1);
	if (v28.empty())
	{
		androidgl::getObj()->m_xData_mutex1C.unlock();
		return 0;
	}
	TRawImageContainer *v7 = 0;
	for (size_t i = 0; i < v28.size(); i++)
	{
		v7 = v28[i]->u.pTRC_RIC;
		if (common::container::wrapByMat(*v7).type() == 16)
			break;
	}
	if (v7)
	{
		Mat var58 = common::container::wrapByMat(*v7);
		Mat v31(cv::Size(var58.size.p[1], var58.size.p[0]), 24, Scalar(255.0, 255.0, 255.0, 255.0));
		if (var58.type())
		{
			if (var58.type() == 16)
			{
				cv::mixChannels(&var58, 1, &v31, 1, g_nFromTo_10076F8, 3);
			}
			else
			{
				var58.copyTo(v31);
			}
		}
		else
		{
			cv::mixChannels(&var58, 1, &v31, 1, g_nFromTo_10076E0, 3);
		}
		cv::flip(v31, v31, 0);
#ifdef ANDROID_NDK
		jclass v11 = a1->FindClass("android/graphics/Bitmap");
		jmethodid v12 = a1->GetStaticMethodID(v11, "createBitmap", "(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;");
		jclass v15 = a1->FindClass("android/graphics/Bitmap$Config");
		jmethodid v17 = a1->GetStaticMethodID(v15, "valueOf", "(Ljava/lang/String;)Landroid/graphics/Bitmap$Config;");
		jobject v18 = a1->CallStaticObjectMethod(v15, v17, a1->NewStringUTF("ARGB_8888"));
		jobject result = a1->CallStaticObjectMethod(v11, v12, v31.cols, v31.rows, v18);
		uchar* v30;
		if (AndroidBitmap_lockPixels(a1, result, &v30) < 0)
		{
			fSuccess = false;
		}
		else
		{
			memcpy(v30, v31.data, 4 * v31.cols * v31.rows);
			AndroidBitmap_unlockPixels(a1, result);
		}
#else
		result = new MyImageData;
		memclr(result, sizeof(MyImageData));
		result->nID_width = v31.cols;
		result->nID_height = v31.rows;
		result->bID_data = new uchar[4 * v31.cols * v31.rows];
		memcpy(result->bID_data, v31.data, 4 * v31.cols * v31.rows);
#endif
	}
	else
	{
		fSuccess = false;
		result = 0;
	}
	androidgl::getObj()->m_xData_mutex1C.unlock();
	if (!fSuccess)
		return 0;

	return result;
}

#ifdef ANDROID_NDK
jobjectarray getRichDocumentImages(JNIEnv *a1)
#else
vector<MyImageData*> getRichDocumentImages()
#endif
{
#ifdef ANDROID_NDK
	jobjectarray result;
#else
	vector<MyImageData*> result;
#endif
	bool fSuccess = true;

	androidgl::getObj()->m_xData_mutex1C.lock();
	TResultContainerList* pTRCL = androidgl::getObj()->m_pData_TRCL;
	if (!pTRCL)
	{
		androidgl::getObj()->m_xData_mutex1C.unlock();
		return result;
	}
	common::container::RclHolder v37;
	v37.addNoCopy(*pTRCL);
	vector<TResultContainer*> v36 = v37.getRcList(1);
	vector<TResultContainer*> v35 = v37.getRcList(16);
	v36.insert(v36.begin(), v35.begin(), v35.end());
	if (v36.empty())
	{
		androidgl::getObj()->m_xData_mutex1C.unlock();
#ifdef ANDROID_NDK
		return 0;
	}
	result = a1->NewObjectArray(v36.size(), a1->FindClass("com/regula/core/ImageResult"), 0);
#else
		return result;
	}
	result.resize(v36.size());
#endif
	for (size_t i = 0; i < v36.size(); i++)
	{
		TRawImageContainer *v8 = v36[i]->u.pTRC_RIC;
		if (!v8)
		{
			fSuccess = false;
			break;
		}
		Mat v40 = common::container::wrapByMat(*v8);
		if (v40.total())
		{
			Mat v39(cv::Size(v40.size.p[1], v40.size.p[0]), 24, Scalar(255.0, 255.0, 255.0, 255.0));
			if (v40.type())
			{
				if (v40.type() == 16)
				{
					cv::mixChannels(&v40, 1, &v39, 1, g_nFromTo_10076F8, 3);
				}
				else
				{
					v40.copyTo(v39);
				}
			}
			else
			{
				cv::mixChannels(&v40, 1, &v39, 1, g_nFromTo_10076E0, 3);
			}
			cv::flip(v39, v39, 0);
#ifdef ANDROID_NDK
			jclass v12 = a1->FindClass("com/regula/core/ImageResult");
			jobject v15 = a1->NewObject(v12, a1->GetMethodID(v12, "<init>", "()V"));
			jfieldID v16 = a1->GetFieldID(v12, "pageIndex", "I");
			if (v16) a1->SetIntField(v15, v16, v36[i]->nTRC_page_idx);
			v16 = a1->GetFieldID(v12, "light", "I");
			if (v16) a1->SetIntField(v15, v16, v36[i]->nTRC_light);
			v16 = a1->GetFieldID(v12, "type", "I");
			if (v16) a1->SetIntField(v15, v16, v36[i]->nTRC_result_type);
			v16 = a1->GetFieldID(v12, "width", "I");
			if (v16) a1->SetIntField(v15, v16, v39.cols);
			v16 = a1->GetFieldID(v12, "height", "I");
			if (v16) a1->SetIntField(v15, v16, v39.rows);
#else
			MyImageData* pImgData = new MyImageData;
			pImgData->nID_pageIndex = v36[i]->nTRC_page_idx;
			pImgData->nID_height = v36[i]->nTRC_light;
			pImgData->nID_type = v36[i]->nTRC_result_type;
			pImgData->nID_width = v39.cols;
			pImgData->nID_height = v39.rows;
			pImgData->nID_light = 0;
			pImgData->nID_exposure = 0;
#endif
			size_t v22, v21 = v39.total();
			if (v39.dims < 1)
				v22 = 0;
			else
				v22 = v39.step.p[v39.dims - 1];
			size_t v24 = v22 * v21;
#ifdef ANDROID_NDK
			v16 = a1->GetFieldID(v12, "imgBytes", "[B");
			if (v16)
			{
				size_t v24 = v22 * v21;
				jbyteArray v25 = a1->NewByteArray(v24);
				if (v25)
				{
					if (a1->GetArrayLength(v25) == v24)
					{
						a1->SetByteArrayRegion(v25, 0, v24, v39.data);
						a1->SetObjectField(v15, v16, v25);
					}
					a1->DeleteLocalRef(v25);
				}
			}
			a1->SetObjectArrayElement(result, i, v15);
#else
			pImgData->bID_data = new uchar[v24];
			if (pImgData->bID_data)
			{
				memcpy(pImgData->bID_data, v39.data, v24);
			}
			result[i] = pImgData;
#endif
		}
	}
	androidgl::getObj()->m_xData_mutex1C.unlock();
#ifdef ANDROID_NDK
	if (!fSuccess)
		return result;
#endif
		
	return result;
}

#ifdef ANDROID_NDK
jstring processImg(JNIEnv *a1, jobject a2, jobject a3, int a4, jbyteArray a5, jstring a6)
#else
char* processImg(int a4, uchar* a5, uint a51, const char* a6)
#endif
{
	androidgl::getObj()->m_xData_mutex1C.lock();
	androidgl::getObj()->m_pData_TRCL = 0;
	androidgl::getObj()->m_xData_mutex1C.unlock();
#ifdef ANDROID_NDK
	uint v9;
	uchar* v10;
	if (a5 && (v9 = a1->GetArrayLength(a5)) != 0)
	{
		v10 = a1->GetByteArrayElements(a5, 0);
	}
	else
	{
		v9 = 0;
		v10 = 0;
	}
#endif
	string v44;
	if (a6)
	{
#ifdef ANDROID_NDK
		char* v13 = a1->GetStringUTFChars(a6, 0);
		if (v13)
		{
			v44 = string(v13, strlen(v13));
		}
#else
		v44 = string(a6, strlen(a6));
#endif
	}
	if (a4 == 0x2F44)
	{
		Json::Value val(Json::json_type_null);
		if (v44.size())
		{
			Json::CharReaderBuilder v42;
			Json::OurCharReader* v19 = v42.newCharReader();
			v19->parse(v44.data(), v44.data() + v44.size(), &val, 0);
		}
#ifdef ANDROID_NDK
		val["systemInfo"]["license"] = Json::Value(common::Base64::base64_encode(v10, v9));
		val["systemInfo"]["packName"] = Json::Value(android_helper::getPackName(a1, a3));
		val["systemInfo"]["deviceID"] = Json::Value(android_helper::getDeviceId(a1, a3));
		v10 = 0;
#else
		val["systemInfo"]["license"] = Json::Value(common::Base64::base64_encode(a5, a51));
		val["systemInfo"]["packName"] = Json::Value("com.regula.documentreader");
		val["systemInfo"]["deviceID"] = Json::Value("0123456789");
		a5 = 0;
#endif
		val["systemInfo"]["system"] = Json::Value(1);
		common::container::jsoncpp::convert(val, v44);
	}
	char* szRes = 0;
	void* pvRes = 0;
#ifdef ANDROID_NDK
	mobileadapter::process(a4, v10, v44.data(), &pvRes, &szRes);
	if (a5 && v10)
	{
		a1->ReleaseByteArrayElements(a5, (jbyte *)v10, 2);
		a1->DeleteLocalRef(a5);
	}
#else
	mobileadapter::process(a4, a5, v44.data(), &pvRes, &szRes);
#endif
	androidgl::getObj()->m_xData_mutex1C.lock();
	androidgl::getObj()->m_pData_TRCL = (TResultContainerList*)pvRes;
	androidgl::getObj()->m_xData_mutex1C.unlock();
#ifdef ANDROID_NDK
	return a1->NewStringUTF(szRes);
#else
	return szRes;
#endif
}

#ifdef ANDROID_NDK
jstring processImgContainer(JNIEnv *a1, jobject a2, jobject a3, int a4, jbyteArray a5, jstring a6, jbyteArray a7)
#else
char* processImgContainer(int a4, vector<MyImageData*> const*a5, const char* a6, uchar* a7, uint a8)
#endif
{
	androidgl::getObj()->m_xData_mutex1C.lock();
	androidgl::getObj()->m_pData_TRCL = 0;
	androidgl::getObj()->m_xData_mutex1C.unlock();
	
#ifdef ANDROID_NDK
	uint v17;
	uchar* v18;
#endif
	string v44;
	if (a6)
	{
#ifdef ANDROID_NDK
		char* v13 = a1->GetStringUTFChars(a6, 0);
		if (v13)
		{
			v44 = string(v13, strlen(v13));
		}
#else
		v44 = string(a6, strlen(a6));
#endif
	}
	Json::Value val(Json::json_type_null);
	if (v44.size())
	{
		common::container::jsoncpp::convert(v44, val);
	}
	if (a4 == 0x2F44)
	{
#ifdef ANDROID_NDK
		if (a7 && (v17 = a1->GetArrayLength(a7)) != 0)
		{
			v18 = a1->GetByteArrayElements(a7, 0);
		}
		else
		{
			v17 = 0;
			v18 = 0;
		}
		val["systemInfo"]["license"] = Json::Value(common::Base64::base64_encode(v18, v17));
		val["systemInfo"]["packName"] = Json::Value(android_helper::getPackName(a1, a3));
		val["systemInfo"]["system"] = Json::Value(1);
		val["systemInfo"]["deviceID"] = Json::Value(android_helper::getDeviceId(a1, a3));
		if (a7 && v18)
		{
			a1->ReleaseByteArrayElements(a7, (jbyte *)v18, 2);
			a1->DeleteLocalRef(a7);
		}
#else
		val["systemInfo"]["license"] = Json::Value(common::Base64::base64_encode(a7, a8));
		val["systemInfo"]["packName"] = Json::Value("com.regula.documentreader");
		val["systemInfo"]["system"] = Json::Value(1);
		val["systemInfo"]["deviceID"] = Json::Value("0123456789");
#endif
		common::container::jsoncpp::convert(val, v44);
	}
	androidgl::getObj()->m_xData_mutex14.lock();
	androidgl::getObj()->m_xData_rclHolder.clear();
	val["processParam"]["doFlipYAxis"] = Json::Value(true);
	imageConvertor::ImageParams params;
	imageConvertor::convert(val, params);
	getImages(a5, params, androidgl::getObj());
	common::container::jsoncpp::convert(val, v44);
	char* szRes = 0;
	processgl(a4, &androidgl::getObj()->m_xData_rclHolder.m_xTRCL, v44.data(), (void**)&androidgl::getObj()->m_pData_TRCL, &szRes);
	androidgl::getObj()->m_xData_mutex14.unlock();
#ifdef ANDROID_NDK
	return a1->NewStringUTF(szRes);
#else
	return szRes;
#endif
}

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#include "stb_image_write.h"
#include <ReadBarcode.h>
#include <ResultMetadata.h>

using namespace ZXing;

int ReadBarcode(string filePath)
{
	DecodeHints hints;
	hints.setTryHarder(true);
	hints.setTryRotate(true);
	int width, height, channels;
	std::unique_ptr<stbi_uc, void(*)(void*)> buffer(stbi_load(filePath.c_str(), &width, &height, &channels, 4), stbi_image_free);
	if (buffer == nullptr) {
		//std::cerr << "Failed to read image: " << filePath << "\n";
		return -1;
	}

	auto result = ReadBarcode({ buffer.get(), width, height, ImageFormat::RGBX });
	if (result.status() != DecodeStatus::NotFound)
	{
		fwprintf(g_log.m_fpLog, L"==================== Barcode Data ====================\r\n");
		fwprintf(g_log.m_fpLog, L"Text:     %s\r\n", result.text().data());
		fwprintf(g_log.m_fpLog, L"Format:   %S\r\n", ToString(result.format()));
		fwprintf(g_log.m_fpLog, L"Position: (%d, %d), (%d, %d), (%d, %d), (%d, %d)\r\n", 
			result.position().topLeft().x, result.position().topLeft().y,
			result.position().topRight().x, result.position().topRight().y,
			result.position().bottomRight().x, result.position().bottomRight().y,
			result.position().bottomLeft().x, result.position().bottomLeft().y);
		fwprintf(g_log.m_fpLog, L"Rotation: %d\r\n", result.orientation());
		fwprintf(g_log.m_fpLog, L"EC Level: %s\r\n", result.metadata().getString(ResultMetadata::ERROR_CORRECTION_LEVEL).data());
		fwprintf(g_log.m_fpLog, L"Price:    %s\r\n", result.metadata().getString(ResultMetadata::SUGGESTED_PRICE).data());
		fwprintf(g_log.m_fpLog, L"Issue #:  %s\r\n", result.metadata().getString(ResultMetadata::ISSUE_NUMBER).data());
		fwprintf(g_log.m_fpLog, L"Country:  %s\r\n", result.metadata().getString(ResultMetadata::POSSIBLE_COUNTRY).data());
		fwprintf(g_log.m_fpLog, L"Extension:%s\r\n", result.metadata().getString(ResultMetadata::UPC_EAN_EXTENSION).data());
	}	

	return 0;
}

#ifdef _CONSOLE
int _tmain(int argc, _TCHAR* argv[])
{
	printf("Initializing...");
#ifdef ANDROID_NDK
	processImg(0x2f44, 0, 0, "{\"processParam\":{\"measureSystem\":0,\"dateFormat\":\"YY.M.D.\",\"scenario\":\"\"},\"initParam\":{\"applicationPath\":\"\\/storage\\/sdcard0\\/Android\\/data\\/com.regula.documentreader\\/files\\/Regula\"}}");
#else
	processImg(0x2f44, 0, 0, "{\"processParam\":{\"measureSystem\":0,\"dateFormat\":\"YY.M.D.\",\"scenario\":\"\"},\"initParam\":{\"applicationPath\":\"db\"}}");
#endif

	//////////////////////////////////////////////////////////////////////////
	//while (1)
	{
		printf("\n>>Please input image path : ");
		char szPath[_MAX_PATH] = "";
	
		gets_s(szPath);
		char *lpszPath = szPath;
		if (szPath[0] == '\"')
		{
			*(lpszPath + strlen(lpszPath) - 1) = 0;
			lpszPath++;
			
		}
		
		Mat src = imread(lpszPath);
		if (!src.empty())
		{
			g_log.setpath(lpszPath);
			processImg(0x2f49, 0, 0, "{\"processParam\":{\"measureSystem\":0,\"dateFormat\":\"YY.M.D.\",\"sessionLogFolder\":\"\",\"scenario\":\"FullProcess\"}}");
			MyImageData ImgData;
			ImgData.nID_height = src.rows;
			ImgData.nID_width = src.cols;
			ImgData.nID_type = 0xFD;
			ImgData.nID_light = 6;
			ImgData.nID_pageIndex = 0;
			ImgData.nID_exposure = 0;
			ImgData.bID_data = src.data;
			char* szRes = processImgContainer(0x2f48, &vector<MyImageData*>(1, &ImgData), "{\"processParam\":{\"dateFormat\":\"YY.M.D.\",\"sessionLogFolder\":\"\",\"scenario\":\"FullProcess\",\"measureSystem\":0,\"timeout\":2147483647}}", 0, 0);
			getRichDocumentImages();

			ReadBarcode(string(lpszPath));
			g_log.setpath(0);
		}
	}
	return 0;
}
#endif