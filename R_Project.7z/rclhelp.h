#pragma once
#include "pch.h"
#include "common/container/container.h"
//#include "json/Json.h"
//#include "imageproc/RawImageContainer.h"
//#include "docformatinfo.h"
//#include "regula.h"
//#include "common/images.h"
//#include "mrz/MRZAnalyze.h"
#include "sdk/DocInfo.h"

using namespace common::container;

namespace rclhelp {
	
	void GetRclForPage(TResultContainerList *, int, RclHolder &);

	bool checkImagesSize(TResultContainerList &);

	bool checkImagesSize(RclHolder &);

	TResultContainer container(int, uchar *, uint);

	TResultContainer container(int, uchar *, uint, uint);

	TRawImageContainer * convertPointerToRawImage(TResultContainer *);

	vector<TResultContainer> convertToContainers(vector<TResultContainer *> const&);

	int deviceType(TResultContainerList &);

	int deviceTypeReal(TResultContainerList &);

	CDocFormat docFormatFromDocumentPosition(RclHolder &);

	CDocFormat docFormatFromRecognizeResult(TResultContainerList const&);

	CDocFormat documentFormat(TResultContainerList const&);

	CDocFormat documentFormatByImages(TResultContainerList &, float, int *);

	CDocFormat documentFormatFromCLMix(TResultContainerList &, int *);

	CDocFormat documentFormatFromContainers(RclHolder const&, vector<int> &);

	CDocFormat documentFormatFromMRZOld(TResultContainerList const&);

	void documentFormatUpdate(RclHolder &, CDocFormat);

	vector<int>  documentFormatsFromCLMix(TResultContainerList &, int *);

	int documentIDRecogn(TResultContainerList &);

	vector<TResultContainer *> filter(vector<TResultContainer *> const&, eRPRM_Lights);

	vector<TResultContainer *> filter(vector<TResultContainer *> const&, vector<int> const&);

	vector<TResultContainer> filter(vector<TResultContainer> const&, eRPRM_Lights);

	vector<TResultContainer> filter(vector<TResultContainer> const&, eRPRM_ResultType);
	
	vector<TResultContainer> filter(vector<TResultContainer> const&, vector<int> const&);

	vector<TResultContainer> filterByExposure(vector<TResultContainer> const&, int);

	vector<TResultContainer> filterByPage(vector<TResultContainer> const&, int);

	vector<TResultContainer *> findContainer(TResultContainerList const&, int);

	vector<TResultContainer *> findContainer(TResultContainerList const&, int, int);

	//vector<TResultContainer *> findContainer(TResultContainerPointersList const&, int);

	TResultContainer * findFirstContainer(TResultContainerList const&, int);

	TResultContainer * findFirstContainer(TResultContainerList const*, int);

	int generateImageFromHiResolutionImage(tagSIZE &, eRPRM_Lights, RclHolder &);

	int generateWhiteGray(RclHolder &);

	TAuthenticityCheckResult * getAuthenticityContent(TResultContainerList *, eRPRM_Authenticity);

	void * getContainerContent(TResultContainerList const*, int);

	vector<TResultContainer *> getContainers(TResultContainerList const&);

	CDocFormat getDocFormat(TResultContainer const*);

	CDocFormat getDocFormat(TResultContainerList const*);

	int getDocId(RclHolder &);

	vector<int> getDocIds(RclHolder &);

	TOneCandidate * getDocInfoRecogn(TResultContainerList &);

	int getExposure(TResultContainer const&);

	int getPage(TResultContainerList const&);

	//int getPageIndxMax(TResultContainerList const&);

	vector<int> getPages(TResultContainerList const&);

	Json::Value getProcessParams(RclHolder &, char const*);

	Json::Value getProcessParams(RclHolder &, string const&);

	//string getSamplePath(TResultContainerList &);

	int imageParameters(TResultContainerList const&, int &, tagSIZE &);

	int imageResolution(TResultContainerList const&);

	tagSIZE imageSize(TResultContainerList &);

	/*bool imageSizeMM(TResultContainerList &, float &, float &);

	int indexOf(TResultContainerList const&, TResultContainer const&);*/

	void mergeResults(RclHolder &, TResultContainerList *);

	void setExposure(TResultContainer &, int);

	int setResolution(TResultContainerList &, int);

	vector<shared_ptr<RclHolder>> splitByContainerType(RclHolder &, vector<int> const&);

	vector<shared_ptr<RclHolder>> splitByPage(RclHolder &);

	int updateCLByDocumentFormat(RclHolder &, CDocFormat, cv::Size_<float> &);

	int updateContainerType(RclHolder &, eRPRM_ResultType, eRPRM_ResultType);

	int updateDocumentPosition(RclHolder &, CDocFormat, float, float);

	int updateImagesByDocumentFormat(RclHolder &, CDocFormat, float &, float &, cv::Size_<float> &);


	//namespace authenticity {

	//	int getPatternsDescription(RclHolder &, string &, string &, ScopeLogHelper &); //No xrefs

	//	TAuthenticityCheckResult * GetFirstResult(TResultContainerList *); //No xrefs


	//}
	//
	//namespace debug {

	//	void printAllContainersType(ScopeLogHelper &, RclHolder &);

	//	void printAllContainersType(RclHolder &); //No xrefs

	//}
	//
	namespace docdesc {

		int convertDocDesc(RclHolder &, char const*, Json::Value &);

		int docID(CDocInfo &, Json::Value &);

		int docID(Json::Value &);

		int getChildDocList(Json::Value &, vector<int> &);

		int getChildDocList(int, vector<int> &);

		int getChildDocList(string &, vector<int> &);

		CDocInfo * getDocDescFromContainer(RclHolder &);

		Size2f getDocSizeMM(Json::Value const&);

		Size2f getDocSizeMM(int);

		int getPairPageDocList(Json::Value &, vector<int> &);

		int getPairPageDocList(int, vector<int> &);

		int getPairPageDocList(string &, vector<int> &);

		bool isDocsHasMrz(vector<int> const&, bool);

	}
	
	namespace docinfo {

		void addMainDocumentInfo(RclHolder &, RclHolder &, vector<int> const&);

		void addMainDocumentInfo(vector<int> const&, RclHolder &);

		int documentWasProcessed(RclHolder &, int);

		vector<int> getUnrecognizedDocId(RclHolder &);

		void updateMainDocumentInfo(RclHolder &, RclHolder &);

	}
	
	//namespace image {

	//	int maxResolutionInImages(RclHolder const&); //No xrefs

	//}
	//
	////namespace info {

	////	void checkImagesInDebugMode(TResultContainerList *) {};

	////}
	
	namespace mrz {

		tagPOINT getMrzCenter(RclHolder const&);
	}
	
	namespace page {

		void setPageIndex(vector<TResultContainer *> const&, int);

		void sortByFaceMrz(RclHolder &);

		void swapPageIndex(TResultContainer &, int, int);

		void swapPageIndex(vector<TResultContainer *> const&, int, int);

		void updateMrzContainerPageByBoundsResult(RclHolder &);

		void updatePageIndex(vector<TResultContainer *> const&, int, int);

		void updatePageIndexByDocId(RclHolder &);

		void updatePageIndexFrom0Step1(RclHolder &);

	}
	//
	namespace qa {

	//	int getQACheck(TImageQualityCheckList *);

	//	int getQACheck(TImageQualityCheckList *, eImageQualityCheckType);

	//	int getQACheck(RclHolder &); //No xrefs

	//	int getQACheck(RclHolder &, eImageQualityCheckType); //No xrefs

		bool hasNoGlares(RclHolder &, bool);

		bool isInFocus(RclHolder &, bool);

	}

	namespace bounds {
		vector<TBoundsResult*> getBoundsResult(RclHolder const& rclHolder, eBoundsResultStatus status);
		Rect getBoundsResultForPage(RclHolder const& rclHolder, int page_idx);
		bool updateBoundsResultByDpi(RclHolder &, int, int, float, int);
		void removeBoundsResultWithoutMrz(RclHolder &);
	}
}

