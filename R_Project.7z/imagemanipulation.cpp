#include "imagemanipulation.h"
#include "rcvmat.h"
//#include "imageproc/imgStructs.h"
#include "common/container/container.h"
#include "rclhelp.h"
#include "common/common.h"

namespace imagemanipulation
{
	integralImageData::integralImageData()
		: m_niI_A8(0)
	{
	}
	integralImageData::~integralImageData()
	{
	}
	void integralImageData::clear(void)
	{
		m_xiI_0.release();
		m_xiI_38.release();
		m_xiI_70.release();
		m_niI_A8 = 0;
	}
	void addImageToResultRcl(cv::Mat & a1, eRPRM_Lights a2, RclHolder & a3)
	{
		unique_ptr<TRawImageContainer, TRawImageContainer*(*)(TRawImageContainer*)> up3a = common::container::copyMatToRic(a1);
		TResultContainer* pTRC6 = a3.addNewWithOwnership(1, up3a.release(), RPRM_Lights_0);
		pTRC6->nTRC_light = a2;
		pTRC6->nTRC_page_idx = 0;
	}
	bool checkBackgroundLight(RclHolder & a1)
	{
		vector<TResultContainer> vrc38 = rclhelp::filter(a1.getContainers(), RT_TRawImageContainer_1);
		if (vrc38.empty())
		{
			return false;
		}
		Rect rc37 = rclhelp::bounds::getBoundsResultForPage(a1, 0);

		uint n25 = 0;

		for (size_t i = 0; i < vrc38.size(); i++)
		{
			Mat m1a = common::container::wrapByMat(vrc38[i]);
			Size sz;

			sz.width = m1a.cols;
			sz.height = m1a.rows;

			Rect rc3 = rcvmat::RCVRect::crossing(rc37, sz);

			if (rc3.width > 0 && rc3.height > 0)
			{
				cv::Mat m40;
				rcvmat::RCVMat::load(m1a, m40, FullColors_cv_4);
				cv::Mat m39(m40, rc3);
				vector<int> vi33;
				rcvmat::RCVMat::calcHist(m39, vi33, 256, 0, 256);
				int n30, n31, n32;
				n30 = n31 = n32 = 0;
				float r29 = 0.0;
				rcvmat::RCVMat::dynamicRange(vi33, m39.total() / 2, 0, n32, n31, n30);
				rcvmat::RCVMat::histCenter(vi33, r29, n32, 256);
				double d26 = 0.0;
				m39.setTo(d26);
				rcvmat::RCVMat::calcHist(m40, vi33, 256, 0, 256);
				rcvmat::RCVMat::dynamicRange(vi33, m39.total() + (m40.total() - m39.total()) / 2, 0, n32, n31, n30);
				float r28;
				rcvmat::RCVMat::histCenter(vi33, r28, n32, 256);

				if (r29 * 0.1 < r28 - r29)
				{
					n25++;
				}
			}
		}

		if (n25 > vrc38.size() / 2)
			return true;
		
		return false;
	}
	int checkObjectColor(cv::Mat const & a1, tFullColors_cv a2, eCheckDiagnose & a3, tFullColors_cv & a4, bool a5)
	{
		if (a1.empty() || a1.channels() != 3)
		{
			return -1;
		}

		vector<cv::Mat> vm67;
		cv::split(a1, vm67);

		cv::Mat m2a;

		switch (a2)
		{
		case FullColors_cv_2:
			if (a5)
			{
				vm67[2].copyTo(m2a);
			}
			else
			{
				vm67[1].copyTo(m2a);
			}
			break;
		case FullColors_cv_3:
			if (a5)
			{
				vm67[1].copyTo(m2a);
			}
			else
			{
				vm67[2].copyTo(m2a);
			}
			break;
		case FullColors_cv_4:
			if (a5)
			{
				vm67[0].copyTo(m2a);
			}
			else
			{
				vm67[2].copyTo(m2a);
			}
			break;
		default:
			vm67[1].copyTo(m2a);
			break;
		}

		cv::Mat m6;
		cv::threshold(m2a, m6, 0.0, 255.0, 8);

		cv::Mat m74, m73;

		if (a5)
		{
			rcvmat::RCVMat::open(m74, m2a, cv::Size(3, 3));
		}
		else
		{
			cv::bitwise_not(m74, m73);
			rcvmat::RCVMat::open(m73, m2a, cv::Size(3, 3));
		}

		int n18 = countNonZero(m2a);

		if (m2a.rows * m2a.cols * 0.8 < n18)
		{
			a3 = CheckDiagnose_0;
			return 0;
		}

		float r70[5] = { 0.0 }; //??? 3?

		for (size_t i = 0; i < vm67.size(); i++)
		{
			rcvmat::RCVMat::and__(m2a, vm67[i]);
			vector<int> vi69;
			rcvmat::RCVMat::calcHist(vm67[i], vi69, 256, 0, 256);
			vi69[0] = 0;
			rcvmat::RCVMat::histCenter(vi69, r70[i], 0, 256);
		}

		cv::Mat m29(1, 1, 16, cv::Scalar(r70[0], r70[1], r70[2], 0.0));
		cv::Mat m1a;
		cv::cvtColor(m29, m1a, COLOR_BGR5552BGRA);

		int n30, n31, n32, n33;
		n30 = m1a.at<uchar>(0, 2);
		n31 = m1a.at<uchar>(0, 1);
		n32 = m1a.at<uchar>(0, 0) * 2;
		n33 = n30 + n31;

		bool f40 = 0, f36 = 0;

		if (n30 >= 0x64)
		{
			if (n31 > 0x6D)
			{
				f36 = 1; // goto 51;
			}
			else 
			{
				if (n30 > 0x72)
				{
					if (n31 > 0x59)
					{
						f36 = 1; // goto 51;
					}
					else if (n30 > 0x86)
					{
						if (n33 > 0xFA || n31 >= 0x41)
						{
							f36 = 1; // goto 51;
						}
						else
						{
							f36 = 0; // goto 51;
						}
					}
					else
					{
						if (n33 > 0xFA)
						{
							f36 = 1; // goto 51;
						}
						else
						{
							f36 = 0; // goto 51;
						}
					}
				}
				else
				{
					if (n33 > 0xFA)
					{
						f36 = 1; // goto 51;
					}
					else
					{
						f36 = 0; // goto 51;
					}
				}
			}
		}
		else
		{
			if (n30 >= 0x5A && n31 > 0x95)
			{
				f36 = 1;// goto 51;
			}
			else
			{
				if (n33 > 0xFA)
				{
					f36 = 1;// goto 51;
				}
				else
				{
					f36 = 0;// goto 51;
				}
			}
		}

		if (n30 < 0x46)
		{
			f40 = 1; // goto 62;
		}
		else
		{
			if (n31 < 0x28)
			{
				f40 = 1; // goto 62;
			}
			else
			{
				if (n31 < 0x50 && n30 < 0x64)
				{
					f40 = 1;// goto 62;
				}
				else
				{
					f40 = 0;// goto 62;
				}
			}
		}

		bool f8 = n33 > 0x81;
		bool f42 = n32 - 0x3C < 0x65;
		bool f47 = n33 > 0x95 && n32 - 0x28 < 0x1F;
		bool f48;
		int n6 = n32 - 0xBE;
		int n41 = n32 - 0x3C;
		int n43 = n32 - 0x28;

		if (!f40)
		{
			if (n33 > 0xB3 && n6 < 0x65)
			{
				f36 = 1;
			}
			f48 = 1;
		}
		else
		{
			f48 = f36;
		}

		if (!f47)
		{
			f48 = f36;
		}

		bool f54 = f48 | f36;

		a3 = CheckDiagnose_0;

		switch (a2)
		{
		case FullColors_cv_1:
			if (f40)
			{
				a3 = CheckDiagnose_1;
				a4 = a2;
			}
			else if (f54)
			{
				a3 = CheckDiagnose_85;

				if (n6 < 0x65 || n43 > 0x104)
				{
					a4 = n43 > 0x104 ? FullColors_cv_2 : FullColors_cv_4;
				}

				if (f42 & f8 | f47)
				{
					a4 = FullColors_cv_3;
				}
			}
			else
			{
				a3 = CheckDiagnose_0;
				a4 = FullColors_cv_0;
			}
			break;
		case FullColors_cv_2:
			if (n43 <= 0x104 || f40)
			{
				a3 = CheckDiagnose_84;
				if (!f54 | f40)
				{
					a4 = FullColors_cv_1;
				}
				else
				{
					if (n6 < 0x65 || n43 > 0x104)
					{
						a4 = n43 > 0x104 ? FullColors_cv_2 : FullColors_cv_4;
					}

					if (f42 & f8 | f47)
					{
						a4 = FullColors_cv_3;
					}
				}
			}
			else
			{
				a3 = CheckDiagnose_1;
				a4 = a2;
			}
			break;
		case FullColors_cv_3:
			if (n33 >= 0x82 && n41 <= 0x64 && !f40)
			{
				a3 = CheckDiagnose_1;
				a4 = a2;
			}
			else
			{
				a3 = CheckDiagnose_83;

				if (!f54 | f40)
				{
					a4 = FullColors_cv_1;
				}
				else
				{
					if (n6 < 0x65 || n43 > 0x104)
					{
						a4 = n43 > 0x104 ? FullColors_cv_2 : FullColors_cv_4;
					}

					if (f42 & f8 | f47)
					{
						a4 = FullColors_cv_3;
					}
				}
			}
			break;
		case FullColors_cv_4:
			if (n6 <= 0x64 && !f40)
			{
				a3 = CheckDiagnose_1;
				a4 = a2;
			}
			else
			{
				a3 = CheckDiagnose_82;

				if (!f54 | f40)
				{
					a4 = FullColors_cv_1;
				}
				else
				{
					if (n6 < 0x65 || n43 > 0x104)
					{
						a4 = n43 > 0x104 ? FullColors_cv_2 : FullColors_cv_4;
					}

					if (f42 & f8 | f47)
					{
						a4 = FullColors_cv_3;
					}
				}
			}
			break;
		default:
			if (!f54 | f40)
			{
				a4 = FullColors_cv_1;
			}
			else
			{
				if (n6 < 0x65 || n43 > 0x104)
				{
					a4 = n43 > 0x104 ? FullColors_cv_2 : FullColors_cv_4;
				}

				if (f42 & f8 | f47)
				{
					a4 = FullColors_cv_3;
				}
			}
			break;
		}

		return 0;
	}

	void convertImage24to8ByFieldDesc(cv::Mat & a1, cv::Mat & a2, int a3)
	{
		int n5 = a1.channels() - 1;  //(a1.flags >> 3) & 0x1FF;

		if (n5)
		{
			if (a3 >= 2 && a3 <= 7)
			{
				vector<cv::Mat> vm7(3);
				cv::split(a1, vm7);

				switch (a3 - 2)
				{
				case 0:
					vm7[2].copyTo(a2);
					break;
				case 1:
					vm7[1].copyTo(a2);
					break;
				case 2:
					vm7[0].copyTo(a2);
					break;
				case 3:
					cv::addWeighted(vm7[1], 0.663, vm7[2], 0.337, 0.0, a2);
					break;
				case 4:
					cv::addWeighted(vm7[0], 0.276, vm7[2], 0.724, 0.0, a2);
					break;
				case 5:
					cv::addWeighted(vm7[0], 0.163, vm7[1], 0.837, 0.0, a2);
					break;
				default:
					cv::cvtColor(vm7[1], a2, COLOR_BGR2GRAY);
					break;
				}
			}
			else
			{
				if (n5 == 2)
				{
					cv::cvtColor(a1, a2, COLOR_BGR2GRAY);
				}
			}
		}
		else
		{
			a1.copyTo(a2);
		}
	}

	int enhancementContrastUV(cv::Mat & a1)
	{
		if (a1.empty())
		{
			return -1;
		}

		cv::Mat m14(1, 256, 0);
		float r4 = 0.0;

		for (size_t i = 0; i < 256; i++)
		{
			double d6 = pow(i / 255.0, 0.600000024);
			int n8 = (int)(d6 * 255);

			if (n8 > 0)
			{
				m14.ptr(0)[i] = -1;
			}

			if (n8 < 0x100)
			{
				m14.ptr(0)[i] = n8;
			}
		}

		cv::Mat m1 = a1.clone();
		cv::LUT(a1, m14, m1);
		cv::GaussianBlur(m1, a1, cv::Size(9, 9), 0.0);
		return 0;
	}

	int generateIntegralImage(common::container::RclHolder & a1, integralImageData & a2)
	{
		vector<TResultContainer> vtrc22 = rclhelp::filter(a1.getContainers(), RT_TRawImageContainer_1);
		
		if (vtrc22.empty())
		{
			return -1;
		}

		vector<TResultContainer> vtrc21 = rclhelp::filter(vtrc22, RPRM_Lights_18);

		if (!vtrc21.empty())
		{
			cv::Mat m1a = wrapByMat(vtrc21[0]);

			if (m1a.empty())
			{
				return -1;
			}

			vector<cv::Rect> vrc20;
			cv::Rect rc4;
			cv::Mat mnu;
			getTextRects(a1, mnu/*no use*/, vrc20, rc4);
			cv::Mat m27;

			if (a2.m_xiI_0.empty())
			{
				m1a.copyTo(a2.m_xiI_0);
				getMaskForImage(m1a, a2.m_xiI_38);
				a2.m_xiI_38.copyTo(a2.m_xiI_70);
				a2.m_niI_A8 = cv::countNonZero(a2.m_xiI_38);
			}
			else
			{
				if (a2.m_niI_A8 > 99)
				{
					if (!vrc20.empty())
					{
						filterMaskByOCRFileds(vrc20, a2.m_xiI_38);
					}

					a2.m_niI_A8 = cv::countNonZero(a2.m_xiI_38);
					cv::Mat m26;
					getMaskForImage(m1a, m26);
					cv::resize(m26, m27, a2.m_xiI_38.size());
					rcvmat::RCVMat::and__(a2.m_xiI_38, m27);

					if (a2.m_niI_A8 * 0.8 >= cv::countNonZero(m27))
					{
						cv::Mat m25;
						//???? sub_404B10(m1a, a2.m_xiI_0)
						if (m25.empty())
						{
							cv::resize(m1a, m1a, cv::Size(), a2.m_xiI_0.cols / m1a.cols, a2.m_xiI_0.rows / m1a.rows);
						}
						else
						{
							cv::warpPerspective(m1a, m1a, m25, a2.m_xiI_0.size());
						}

						getMaskForImage(m1a, m27);

						int n10 = cv::countNonZero(m27);

						if (n10 > 99)
						{
							if (n10 <= a2.m_niI_A8)
							{
								a2.m_niI_A8 = n10;
								m27.copyTo(a2.m_xiI_70);
								uniteImages(a2.m_xiI_0, a2.m_xiI_38, m1a, m27, m27);
								m1a.copyTo(a2.m_xiI_0);
								m27.copyTo(a2.m_xiI_38);
							}
							else
							{
								uniteImages(m1a, m27, a2.m_xiI_0, a2.m_xiI_38, a2.m_xiI_70);
							}

							a2.m_niI_A8 = cv::countNonZero(a2.m_xiI_38);
						}
						else
						{
							m1a.copyTo(a2.m_xiI_0);
							m27.copyTo(a2.m_xiI_38);
						}
					}
					else
					{

					}
					return 0;
				}
			}
			return 0;
		}

		return -1;
	}

	void getMaskForImage(cv::Mat & a1, cv::Mat & a2)
	{
		rcvmat::RCVMat::load(a1, a2, FullColors_cv_1);
		cv::Scalar sca17, sca18;
		cv::meanStdDev(a1, sca18, sca17);
		double d10 = min(sca18[0] + sca17[0] * 3.0, 235.0);
		rcvmat::RCVMat::threshold(a2, d10, 255.0, 0);
		rcvmat::RCVMat::dilate(a2, a2, cv::Size(7, 7));
	}
	
	int getTextRects(common::container::RclHolder & a1, cv::Mat & a2, vector<cv::Rect>& a3, cv::Rect& a4)
	{
		Json::Value xJV1a(0);

		rclhelp::docdesc::convertDocDesc(a1, 0, xJV1a);

		if (xJV1a.isMember("document"))
		{
			if (xJV1a["document"].isMember("textRects"))
			{
				Json::Value xJV46(xJV1a["document"]["textRects"]);

				if (!xJV46.empty())
				{
					int n44;
					tagSIZE tsz45;
					tsz45.cx = tsz45.cy = 0;
					rclhelp::imageParameters(a1.m_xTRCL, n44, tsz45);
					cv::Mat m48;
					m48.setTo(0.0);
					a3.resize(xJV46.size());

					for (size_t i = 0; i < xJV46.size(); i++)
					{
						tagRECT rc43 = common::StringTransform::toRECT(xJV46[i]["relRect"].asString());
						a3[i].x = (int)(rc43.left / 1000000000.0 * n44);
						a3[i].y = (int)(min(rc43.bottom, rc43.top) / 1000000000.0 * n44);
						a3[i].width = (int)fabs(rc43.right / 1000000000.0 * n44 - a3[i].x);
						a3[i].height = (int)fabs(max(rc43.bottom, rc43.top) / 1000000000.0 * n44 - a3[i].y);
					}
				}

				if (!a3.empty() || !xJV46.empty())
				{
					for (size_t i = 0; i < a3.size(); i++)
					{
						if (a4.x || a4.width)
						{
							a4.x = min(a4.x, a3[i].x);
							a4.y = max(a4.y, a3[i].y);
							a4.width = max(a3[i].br().x, a4.br().x) - a4.x;
							a4.height = max(a3[i].br().y, a4.br().y) - a4.y;
						}
						else
						{
							a4 = a3[i];
						}
					}
					return 0;
				}
			}
		}
		return -1;
	}

	void filterMaskByOCRFileds(vector<cv::Rect> const & a1, cv::Mat & a2)
	{
		if (!a1.empty())
		{
			cv::Mat m1a(a2.size(), a2.type()); //a2->flags & 0xFFF
			m1a.setTo(0.0);

			for (size_t i = 0; i < a1.size(); i++)
			{
				cv::Size sz;
				sz.width = m1a.cols;
				sz.height = m1a.rows;
				cv::Mat m18(m1a, rcvmat::RCVRect::crossing(a1[i], sz));
				m18.setTo(255.0);
			}
			rcvmat::RCVMat::and__(m1a, a2);
		}
	}
	
	bool isDullPaper(cv::Mat & a1, int a2)
	{
		double d3;
		
		if (a2)
		{
			d3 = a2 / 8000.0;
		}
		else
		{
			d3 = a1.cols / 125.0 * 0.125;
		}

		if (a1.empty())
		{
			return false;
		}
		else
		{
			if (a1.channels() == 3)
			{
				cv::Mat m2a;
				rcvmat::RCVMat::load(a1, m2a, FullColors_cv_3);
				vector<int> vi1a;
				rcvmat::RCVMat::calcHist(m2a, vi1a, 256, 0, 256);
				int n30, n31, n32;
				n30 = n31 = n32 = 0;
				rcvmat::RCVMat::dynamicRange(vi1a, (int)(m2a.total() * 0.005), (int)(m2a.total() * 0.001), n32, n31, n30);

				if (n32 <= 243)
				{
					int n8, n12;
					n12 = n8 = 0;

					for (size_t i = 243; i < vi1a.size(); i++)
					{
						n8 += vi1a[i];
					}

					for (int i = 0; i < n32 + 12; i++)
					{
						n12 += vi1a[i];
					}

					int n15 = 100 * n8 / (m2a.total() - n12);

					rcvmat::RCVMat::load(a1, m2a, FullColors_cv_4);

					vi1a.assign(0, 0);

					rcvmat::RCVMat::calcHist(m2a, vi1a, 256, 0, 256);

					int n16, n20;
					n16 = n20 = 0;

					for (size_t i = 243; i < vi1a.size(); i++)
					{
						n16 += vi1a[i];
					}

					for (size_t i = 0; i < 12; i++)
					{
						n20 += vi1a[i];
					}

					int n23 = 100 * n16 / (m2a.total() - n12);

					double d25 = min(d3 * 70.0, 88.0);
					double d26 = max(d3 * 5.0, 1.0);

					if (d25 < n23 && d26 < n15)
					{
						return true;
					}
				}
				else
				{
					return true;
				}
			}
		}

		return false;
	}
	int replaceUVByDiff(RclHolder & a1, RclHolder & a2, float a3, string const & a4)
	{
		a2.clear();
		return 0;
	}
	void uniteImages(cv::Mat const & a1, cv::Mat const & a2, cv::Mat & a3, cv::Mat & a4, cv::Mat & a5)
	{
		for (int i = 0; i < a3.rows; i++)
		{
			for (int j = 0; j < a3.cols; j++)
			{
				if (a5.at<uchar>(i, j) && !a2.at<uchar>(i, j))
				{
					for (size_t k = 0; k < 3; k++)
					{
						if (a1.ptr(i)[3 * j + k])
						{
							a3.ptr(i)[3 * j] = a1.ptr(i)[3 * j];
							a3.ptr(i)[3 * j + 1] = a1.ptr(i)[3 * j + 1];
							a3.ptr(i)[3 * j + 2] = a1.ptr(i)[3 * j + 2];
							a4.ptr(i)[j] = 0;
							break;
						}
					}
				}
			}
		}
	}
}