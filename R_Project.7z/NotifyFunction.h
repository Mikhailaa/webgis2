#pragma once

namespace NotifyFunction
{
	void setLog(void(*)(int, int));
	void setNotify(void(*)(int, int));
};

