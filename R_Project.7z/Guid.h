#pragma once
#include "pch.h"

class Guid
{
public:
	vector<unsigned char> m_vGuid_val;
	
	Guid();
	~Guid();
	Guid(string const&);
	Guid(uchar const*);
	GUID toNative();
	string ToString(void) const;
	Guid(Guid const&);
	Guid& operator=(Guid const&a2);
	Guid& operator=(GUID const&);
	Guid& operator=(Guid&& a2);
	bool operator==(Guid const&a2);
};

class GuidGenerator
{
public:
	GuidGenerator(/*JNIEnv**/void*) {};
	Guid newGuid(void) 
	{ 
		uchar val[16];
		srand((uint)time(0));
		for (int i = 0; i < 16; i++)
			val[i] = (uchar)rand();
		return Guid(val);
	};
};