#include "imaging.h"
#include "common/FilesystemUtils.h"
#include "common/fs.h"
#include "common/common.h"

void sub_6B01E4(TResultContainer *a1, uint a2, BITMAPINFO *a3, bool a4)
{
	if (a1 && a1->nTRC_result_type == 1 && a1->u.pTRC_RIC)
	{
		TRawImageContainer *v5 = a1->u.pTRC_RIC;
		if (v5->pxRIC_bmi && v5->pRIC_data)
		{
			BITMAPINFO *v6 = v5->pxRIC_bmi;
			if (v6->bmiHeader.biBitCount != 24)
			{
				int v7 = imaging::CImageCodec::CalculateRowStride(v6->bmiHeader.biWidth, 24, 32);
				TRawImageContainer *v8 = imaging::CImageCodec::AllocateRawImageContainer(
					3u,
					8u,
					v5->pxRIC_bmi->bmiHeader.biWidth,
					v5->pxRIC_bmi->bmiHeader.biHeight,
					v7 * v5->pxRIC_bmi->bmiHeader.biHeight,
					v5->pxRIC_bmi->bmiHeader.biXPelsPerMeter,
					v5->pxRIC_bmi->bmiHeader.biYPelsPerMeter);
				if (v8)
				{
					if (imaging::CImageCodec::Make24bits(v5->pxRIC_bmi, v5->pRIC_data, v8->pxRIC_bmi, v8->pRIC_data))
					{
						imaging::FreeMemory((uchar *)v5->pxRIC_bmi);
						imaging::FreeMemory(v5->pRIC_data);
						imaging::FreeMemory((uchar *)a1->u.pTRC_RIC);
						a1->u.pTRC_RIC = v8;
					}
				}
			}
		}
	}
}

void sub_6B0164(TResultContainer *a1, uint a2, BITMAPINFO *a3, bool a4)
{
	if (a1 && a1->nTRC_result_type == 1 && a1->u.pTRC_RIC)
	{
		TRawImageContainer *v5 = a1->u.pTRC_RIC;
		if (v5->pxRIC_bmi && v5->pRIC_data)
		{
			BITMAPINFO *v6 = v5->pxRIC_bmi;
			if (v6->bmiHeader.biBitCount != 8)
			{
				int v7 = imaging::CImageCodec::CalculateRowStride(v6->bmiHeader.biWidth, 8, 32);
				TRawImageContainer *v8 = imaging::CImageCodec::AllocateRawImageContainer(
					1u,
					8u,
					v5->pxRIC_bmi->bmiHeader.biWidth,
					v5->pxRIC_bmi->bmiHeader.biHeight,
					v7 * v5->pxRIC_bmi->bmiHeader.biHeight,
					v5->pxRIC_bmi->bmiHeader.biXPelsPerMeter,
					v5->pxRIC_bmi->bmiHeader.biYPelsPerMeter);
				if (v8)
				{
					if (imaging::CImageCodec::MakeGrayscale(v5->pxRIC_bmi, v5->pRIC_data, v8->pxRIC_bmi, v8->pRIC_data))
					{
						imaging::FreeMemory((uchar *)v5->pxRIC_bmi);
						imaging::FreeMemory(v5->pRIC_data);
						imaging::FreeMemory((uchar *)a1->u.pTRC_RIC);
						a1->u.pTRC_RIC = v8;
					}
				}
			}
		}
	}
}

void sub_6B0698(TResultContainer *a1)
{
	if (a1 && a1->nTRC_result_type == 1)
	{
		TRawImageContainer *v1 = a1->u.pTRC_RIC;
		if (v1 && v1->pxRIC_bmi && v1->pRIC_data)
		{
			BITMAPINFO *v2 = v1->pxRIC_bmi;
			ushort v3 = v2->bmiHeader.biBitCount;
			bool v4 = true;
			if (v3 <= 8)
			{
				v4 = false;
				for (int v6 = 0; v6 < (1 << v3); v6 ++)
				{
					if (v2->bmiColors[v6].rgbBlue != v2->bmiColors[v6].rgbGreen || v2->bmiColors[v6].rgbBlue != v2->bmiColors[v6].rgbRed)
					{
						v4 = true;
						break;
					}
				}
			}
			if ((v3 != 8 && v3 != 0x18) || (v3 <= 8 && v4 == true))
			{
				ushort v11 = 8;
				if (v4)
					v11 = 24;
				if (v11 != v3)
				{
					if (v4)
						sub_6B01E4(a1, v11, v2, v4);
					else
						sub_6B0164(a1, v11, v2, false);
				}
			}
		}
	}
}

namespace imaging
{
	ThreadResourcesHolder g_xTRH_1140F50;
	CJpegImageCodec g_cJpegImageCodec_1140F40;
	CBmpImageCodec g_cBmpImageCodec_1140F44;
	CJpg2KImageCodec g_cBmpImageCodec_1140F48;

	int ExecuteCommand(eRI_Commands a1, RI_Parameters *a2)
	{
		int ret = 2;
		CleanupCurrentThreadResources();
		switch (a1)
		{
		case RI_Commands_0:
			if (a2 && a2->pRIP_0)
				FreeMemory((uchar*)a2->pRIP_0);
			break;
		case RI_Commands_1:
			if (a2)
			{
				//ret = sub_6AF130(a2->pRIP_0, a2->pRIP_4, 1);
			}
			break;
		case RI_Commands_3:
			if (a2 && a2->pRIP_0)
			{
				//
			}
			break;
		case RI_Commands_5:
			if (a2)
			{
				//ret = sub_6AF178(a2->pRIP_0, a2->pRIP_4, 0, 1);
			}
			break;
		case RI_Commands_7:
			if (a2)
			{
				//
			}
			break;
		case RI_Commands_8:
			if (a2)
			{
				//ret = imaging::GetFileImageInfo(a2->pRIP_0, a2->pRIP_4);
			}
			break;
		case RI_Commands_9:
			if (a2 && a2->pRIP_0)
			{
				RI_SaveFileParameters *v24 = (RI_SaveFileParameters*)a2->pRIP_0;
				if (v24->ppSFP_10 && v24->pnSFP_14 && v24->pxSFP_8)
				{
					if (v24->pxSFP_8->nTRC_result_type == 1 && v24->pxSFP_8->u.pTRC_RIC)
					{
						TRawImageContainer* v26 = v24->pxSFP_8->u.pTRC_RIC;
						if (v26->pxRIC_bmi && v26->pRIC_data && v26->pxRIC_bmi->bmiHeader.biWidth && v26->pxRIC_bmi->bmiHeader.biHeight)
						{
							sub_6B0698(v24->pxSFP_8);
							if (v24->nSFP_0)
							{
								if (v24->nSFP_0 == 8)
								{
									ret = g_cBmpImageCodec_1140F48.WriteBuffer(v24->ppSFP_10, v24->pnSFP_14, v24->nSFP_4, v24->pxSFP_8->u.pTRC_RIC);
								}
								else if (v24->nSFP_0 == 1)
								{
									ret = g_cJpegImageCodec_1140F40.WriteBuffer(v24->ppSFP_10, v24->pnSFP_14, v24->nSFP_4, v24->pxSFP_8->u.pTRC_RIC);
								}
							}
							else
							{
								ret = g_cBmpImageCodec_1140F44.WriteBuffer(v24->ppSFP_10, v24->pnSFP_14, v24->nSFP_4, v24->pxSFP_8->u.pTRC_RIC);
							}
						}
					}
				}
			}
			break;
		case RI_Commands_A:
			if (a2)
			{
				//ret = sub_6AF52C(a2->pRIP_0, a2->pRIP_4, 1);
			}
			break;
		case RI_Commands_B:
			if (a2)
			{
				//ret = imaging::GetFileBufferImageInfo(a2->pRIP_0, a2->pRIP_4);
			}
			break;
		case RI_Commands_C:
			if (a2)
			{
				//ret = sub_6AF178(a2->pRIP_0, a2->pRIP_4, 1, 1);
			}
			break;
		case RI_Commands_D:
			if (a2 && a2->pRIP_0)
			{
				//int* v11 = (int*)a2->pRIP_0;
				//ret = common::images::ResizeImage((const uchar *)*v11, v11[1], v11[2], v11[3], (const uchar *)v11[4], v11[5], v11[6], (bool)v11[7]);
			}
			break;
		case RI_Commands_E:
			if (a2 && a2->pRIP_0)
			{
				/*int* v6 = (int*)a2->pRIP_0;
				int a = v6[2], b = v6[3];
				ret = common::images::CropImage(v6[0], v6[1], &a, &b, v6[4]);
				v6[2] = a;
				v6[3] = b;*/
			}
			break;
		case RI_Commands_F:
			if (a2 && a2->pRIP_0)
			{
				//int* v6 = (int*)a2->pRIP_0;
				//ret = common::images::FlipImage(v6[0], v6[1], v6[2], v6[3], v6[4]);
			}
			break;
		case RI_Commands_10:
			if (a2 && a2->pRIP_0)
			{
				/*int* v6 = (int*)a2->pRIP_0;
				int a = v6[2], b = v6[3];
				ret = common::images::RotateImage(v6[0], v6[1], &a, &b, v6[4]);
				v6[2] = a;
				v6[3] = b;*/
			}
			break;
		case RI_Commands_11:
			if (a2)
			{
				//ret = sub_6AF130(a2->pRIP_0, a2->pRIP_4, 0);
			}
			break;
		case RI_Commands_12:
			if (a2)
			{
				//ret = sub_6AF52C(a2->pRIP_0, a2->pRIP_4, 0);
			}
			break;
		case RI_Commands_13:
			if (a2)
			{
				//ret = sub_6AF178(a2->pRIP_0, a2->pRIP_4, 0, 0);
			}
			break;
		default:
			break;
		}
		return 0;
	}

	int WriteToBuffer(RI_SaveFileParameters *a2, TResultContainer const&a3)
	{
		if (!a2)
			return 2;
		a2->pxSFP_8 = (TResultContainer*)&a3;
		RI_Parameters rip;
		rip.pRIP_0 = a2;
		rip.pRIP_4 = 0;
		return ExecuteCommand(RI_Commands_9, &rip);
	}

	bool CleanupCurrentThreadResources()
	{
		return g_xTRH_1140F50.CleanupCurrentThreadResources();
	}

	void FreeMemory(uchar *a1)
	{
		g_xTRH_1140F50.FreeMemory(a1);
	}

	uchar* AllocateMemory(ulong a1)
	{
		return g_xTRH_1140F50.AllocateMemory(a1);
	}


	int CImageCodec::ReadFile(wchar_t const*a2, TResultContainer *a3)
	{
		uchar* v10;
		uint v9;
		int nRet = MapFile(a2, &v10, &v9);
		if (nRet)
			nRet = 3;
		else
			nRet = ReadBuffer(v10, v9, a3);
		return nRet;
	}

	int CImageCodec::WriteFile(wchar_t const*a2, int a3, TRawImageContainer *a4)
	{
		int nRet = 2;
		if (a2 && a4 && a4->pxRIC_bmi)
		{
			common::fs::Path v16(a2);
			common::fs::Path v15 = v16.getPathBase();
			if (!common::FilesystemUtils::IsDirectoryExists(v15.toWString()))
			{
				common::FilesystemUtils::MkDir(v15.toWString());
			}
			uchar *v14 = 0;
			uint v13 = 0;
			nRet = WriteBuffer(&v14, &v13, a3, a4);
			if (!nRet && v14 && v13)
			{
				FILE* fp;
				if (_wfopen_s(&fp, a2, L"wb"))
				{
					nRet = 3;
				}
				else
				{
					fwrite(v14, 1, v13, fp);
					fclose(fp);
					nRet = 0;
				}
			}
			imaging::FreeMemory(v14);
		}
		return nRet;
	}

	int CImageCodec::WriteFile(char const*a2, int a3, TRawImageContainer *a4)
	{
		int nRet = 2;
		if (a2 && a4 && a4->pxRIC_bmi)
		{
			common::fs::Path v16(a2);
			common::fs::Path v15 = v16.getPathBase();
			if (!common::FilesystemUtils::IsDirectoryExists(v15.toString()))
			{
				common::FilesystemUtils::MkDir(v15.toString());
			}
			uchar *v14 = 0;
			uint v13 = 0;
			nRet = WriteBuffer(&v14, &v13, a3, a4);
			if (!nRet && v14 && v13)
			{
				FILE* fp;
				if (fopen_s(&fp, a2, "wb"))
				{
					nRet = 3;
				}
				else
				{
					fwrite(v14, 1, v13, fp);
					fclose(fp);
					nRet = 0;
				}
			}
			imaging::FreeMemory(v14);
		}
		return nRet;
	}

	int CImageCodec::GetFileImageInfo(wchar_t const*a2, imaging::RI_ImageInfo *a3)
	{
		int nRet = 2;
		if (a2 && a3)
		{
			uchar* v10;
			uint v9;
			nRet = MapFile(a2, &v10, &v9);
			if (nRet)
			{
				nRet = 3;
			}
			else
			{
				nRet = GetBufferImageInfo(v10, v9, a3);
			}
			UnmapFile(&v10, &v9);
		}
		return nRet;
	}

	int CImageCodec::QuickDetectFormat(uchar *, uint)
	{
		return 255;
	}

	int CImageCodec::MapFile(wchar_t const*a2, uchar **a3, uint *a4)
	{
		int nRet = 2;
		if (a2 && a3 && a4)
		{
			ulonglong v14 = 0;
			*a3 = common::FilesystemUtils::GetMemoryMappedFile(wstring(a2), v14);
			nRet = 3;
			if (*a3 && v14)
			{
				*a4 = (uint)v14;
				nRet = 0;
			}
		}
		return nRet;
	}

	int CImageCodec::UnmapFile(uchar **a2, uint *a3)
	{
		int nRet;
		if (*a2)
		{
			common::FilesystemUtils::ReleaseMemoryMappedFile(*a2);
			nRet = 0;
			*a2 = 0;
		}
		else
		{
			nRet = 2;
		}
		if (a3)
			*a3 = 0;
		return nRet;
	}

	uint CImageCodec::CalculateRowStride(uint a1, uint a2, uint a3)
	{
		return ((a3 + a2 * a1 - 1) & ~(a3 - 1)) >> 3;
	}

	TRawImageContainer* CImageCodec::AllocateRawImageContainer(uint a1, int a2, int a3, int a4, int a5, int a6)
	{
		TRawImageContainer *v10 = (TRawImageContainer *)imaging::AllocateMemory(sizeof(TRawImageContainer));
		if (v10)
		{
			tagBITMAPINFO *v11 = (tagBITMAPINFO *)imaging::AllocateMemory(sizeof(tagBITMAPINFO));
			v10->pxRIC_bmi = v11;
			v11->bmiHeader.biBitCount = a1;
			v11->bmiHeader.biXPelsPerMeter = a5;
			v11->bmiHeader.biYPelsPerMeter = a6;
			v11->bmiHeader.biWidth = a2;
			v11->bmiHeader.biSizeImage = a4;
			v11->bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
			v11->bmiHeader.biPlanes = 1;
			v11->bmiHeader.biHeight = a3;
			v11->bmiHeader.biCompression = 0;
			v11->bmiHeader.biClrUsed = 0;
			v11->bmiHeader.biClrImportant = 0;
			for (uint i = 0; i < 256; i++)
			{
				v11->bmiColors[i].rgbBlue = i;
				v11->bmiColors[i].rgbGreen = i;
				v11->bmiColors[i].rgbRed = i;
			}
			v10->pRIC_data = (uchar *)imaging::AllocateMemory(a4);
		}
		return v10;
	}

	TRawImageContainer* CImageCodec::AllocateRawImageContainer(uint a1, uint a2, int a3, int a4, int a5, int a6, int a7)
	{
		TRawImageContainer *result;

		if (a2 == 8 && (a1 == 1 || a1 == 3 || a1 == 4))
			result = AllocateRawImageContainer(8 * a1, a3, a4, a5, a6, a7);
		else
			result = 0;
		return result;
	}

	bool CImageCodec::Make24bits(tagBITMAPINFO *a1, uchar *a2, tagBITMAPINFO *a3, uchar *a4)
	{
		if (!a1 || !a2 || !a3 || !a4)
			return false;
		uint v37 = *((uint*)&a1->bmiColors[0]);
		if ((v37 & 0xFFFF) != 0x7C00 && (v37 & 0xFFFF) != 0xF800)
			v37 = 0x7C00;
		uint v38 = *((uint*)&a1->bmiColors[1]);
		if (((v38 & 0xFFFF) | 0x400) != 0x7E0)
			v38 = 0x3E0;
		int v8 = a1->bmiHeader.biWidth;
		int v12 = 4 * ((a1->bmiHeader.biBitCount * v8 + 31) / 32);
		int v36 = 8;
		if ((v37 & 0xFFFF) == 0x7C00)
			v36 = 7;
		int v35 = 3;
		if ((v38 & 0xFFFF) == 0x3E0)
			v35 = 2;
		tagRGBQUAD* v19;
		uchar v20, v21, v22, v25;
		uint v27;
		for (int y = 0; y < a1->bmiHeader.biHeight; y++)
		{
			uchar* v15 = &a2[v12 * y];
			for (int x = 0; x < a1->bmiHeader.biWidth; x++)
			{
				switch (a1->bmiHeader.biBitCount)
				{
				case 32:
					v20 = v15[4 * x];
					v21 = v15[4 * x + 1];
					v22 = v15[4 * x + 2];
					break;
				case 4:
					v25 = v15[x >> 1] & 0xF;
					if (!(x & 1))
						v25 = v15[x >> 1] >> 4;
					v20 = a1->bmiColors[v25].rgbBlue;
					v21 = a1->bmiColors[v25].rgbGreen;
					v22 = a1->bmiColors[v25].rgbRed;
					break;
				case 8:
					v20 = a1->bmiColors[v15[x]].rgbBlue;
					v21 = a1->bmiColors[v15[x]].rgbGreen;
					v22 = a1->bmiColors[v15[x]].rgbRed;
					break;
				case 16:
					v27 = *((ushort *)&v15[2 * x]);
					v20 = 8 * v27;
					v21 = (v38 & v27) >> v35;
					v22 = (v37 & v27) >> v36;
					break;
				case 24:
					v20 = v15[3 * x];
					v21 = v15[3 * x + 1];
					v22 = v15[3 * x + 2];
					break;
				case 1:
					v19 = &a1->bmiColors[1];
					if (!(v15[x >> 3] & (0x80u >> (x & 7))))
						v19 = &a1->bmiColors[0];
					v20 = v19->rgbBlue;
					v21 = v19->rgbGreen;
					v22 = v19->rgbRed;
					break;
				default:
					v20 = 0;
					v21 = 0;
					v22 = 0;
					break;
				}
				a4[3 * x] = v20;
				a4[3 * x + 1] = v21;
				a4[3 * x + 2] = v22;
			}
			a4 += 4 * ((24 * v8 + 31) / 32);
		}
		return true;
	}

	bool CImageCodec::MakeGrayscale(tagBITMAPINFO *a1, uchar *a2, tagBITMAPINFO *a3, uchar *a4)
	{
		if (!a1 || !a2 || !a3 || !a4)
			return false;
		uint v44 = *((uint*)&a1->bmiColors[0]);
		if ((v44 & 0xFFFF) != 0x7C00 && (v44 & 0xFFFF) != 0xF800)
			v44 = 0x7C00;
		uint v45 = *((uint*)&a1->bmiColors[1]);
		if (((v45 & 0xFFFF) | 0x400) != 0x7E0)
			v45 = 0x3E0;
		int v9 = a1->bmiHeader.biWidth;
		int v41 = 4 * ((a1->bmiHeader.biBitCount * a1->bmiHeader.biWidth + 31) / 32);
		int v36 = 4 * ((8 * a1->bmiHeader.biWidth + 31) / 32);
		int v43 = 8;
		if ((v44 & 0xFFFF) == 0x7C00)
			v43 = 7;
		int v42 = 3;
		if ((v45 & 0xFFFF) == 0x3E0)
			v42 = 2;
		for (int i = 0; i < 256; i++)
		{
			a3->bmiColors[i].rgbBlue = i;
			a3->bmiColors[i].rgbGreen = i;
			a3->bmiColors[i].rgbRed = i;
			a3->bmiColors[i].rgbReserved = 0;
		}
		uint v46 = a1->bmiHeader.biBitCount;
		if (v46 < 8)
		{
			uint v19 = (1 << v46) - 1;
			for (int i = 0; i < (1 << v46); i++)
			{
				a3->bmiColors[i].rgbBlue = i * 255 / v19;
				a3->bmiColors[i].rgbGreen = i * 255 / v19;
				a3->bmiColors[i].rgbRed = i * 255 / v19;
				a3->bmiColors[i].rgbReserved = 0;
			}
		}
		Mat v51(a1->bmiHeader.biHeight, a1->bmiHeader.biWidth, (v46 & 0xFFFFFFF8) - 8, a2, v41);
		Mat v50(a3->bmiHeader.biHeight, a3->bmiHeader.biWidth, (a3->bmiHeader.biBitCount & 0xFFF8) - 8, a4, v36);
		switch (a1->bmiHeader.biBitCount)
		{
		case 8:
			break;
		case 24:
			cvtColor(v51, v50, COLOR_BGR2GRAY);
			break;
		case 32:
			cvtColor(v51, v50, COLOR_BGRA2GRAY);
			break;
		default:
			for (int y = 0; y < a1->bmiHeader.biHeight; y++)
			{
				uchar* v27 = &a2[y * v41];
				uchar v29, v30, v31;
				for (int x = 0; x < a1->bmiHeader.biWidth; x++)
				{
					if (a1->bmiHeader.biBitCount == 16)
					{
						uint v34 = *(ushort *)(&v27[2 * x]);
						v30 = 8 * v34;
						v31 = (v45 & v34) >> v42;
						v29 = (v44 & v34) >> v43;
					}
					else if (a1->bmiHeader.biBitCount == 4)
					{
						uchar v33 = v27[x >> 1] & 0xF;
						if (!(x & 1))
							v33 = v27[x >> 1] >> 4;
						v30 = a1->bmiColors[v33].rgbBlue;
						v31 = a1->bmiColors[v33].rgbGreen;
						v29 = a1->bmiColors[v33].rgbRed;
					}
					else if (a1->bmiHeader.biBitCount == 8)
					{
						v30 = a1->bmiColors[v27[x]].rgbBlue;
						v31 = a1->bmiColors[v27[x]].rgbGreen;
						v29 = a1->bmiColors[v27[x]].rgbRed;
					}
					else if (a1->bmiHeader.biBitCount == 1)
					{
						tagRGBQUAD* v28 = &a1->bmiColors[1];
						if (!(v27[x >> 3] & (0x80u >> (x & 7))))
							v28 = &a1->bmiColors[0];
						v30 = v28->rgbBlue;
						v31 = v28->rgbGreen;
						v29 = v28->rgbRed;
					}
					else
					{
						v30 = 0;
						v31 = 0;
						v29 = 0;
					}
					a4[x] = (299 * v29 + 587 * v31 + 114 * v30 + 500) / 1000;
				}
				a4 += v36;
			}
			break;
		}
		return true;
	}

	ushort CImageCodec::GetDensity(int a1, eRI_Density_Units a2)
	{
		ushort v2;

		if (a2 == RI_Density_Units_2)
		{
			v2 = (ushort)(a1 / 100.0);
		}
		else if (a2 == RI_Density_Units_1)
		{
			v2 = (ushort)((a1 / 100.0) * 2.54);
		}
		else
			v2 = 0;
		
		return v2;
	}

	void CImageCodec::SwapRedBlue(uchar *a2, uint a3, uint a4, uint a5)
	{
		if (a2 && a3 && a4)
		{
			if (a5 == 32 || a5 == 24)
			{
				uint v9 = common::images::CalculateRowStride(a3, a5, 0x20u);
				Mat mat(a4, a3, (a5 - 8) & 0xFFFFFFF8, a2, v9);
				if (a5 == 32)
				{
					cv::cvtColor(mat, mat, 5, 0);
				}
				else if (a5 == 24)
				{
					cv::cvtColor(mat, mat, 4, 0);
				}
			}
		}
	}

	int CJpg2KImageCodec::ReadFile(wchar_t const*, TResultContainer *)
	{
		return 0;
	}
	int CJpg2KImageCodec::ReadBuffer(uchar *, uint, TResultContainer *)
	{
		return 0;
	}
	int CJpg2KImageCodec::WriteFile(wchar_t const*, int, TRawImageContainer *)
	{
		return 0;
	}
	int CJpg2KImageCodec::WriteBuffer(uchar **, uint *, int, TRawImageContainer *)
	{
		return 0;
	}
	int CJpg2KImageCodec::GetFileImageInfo(wchar_t const*, imaging::RI_ImageInfo *)
	{
		return 0;
	}
	int CJpg2KImageCodec::GetBufferImageInfo(uchar *, uint, imaging::RI_ImageInfo *)
	{
		return 0;
	}
	int CJpg2KImageCodec::QuickDetectFormat(uchar *, uint)
	{
		return 0;
	}
	
	int CJpegImageCodec::ReadFile(wchar_t const*, TResultContainer *)
	{
		return 0;
	}
	int CJpegImageCodec::ReadBuffer(uchar *, uint, TResultContainer *)
	{
		return 0;
	}
	/*int CJpegImageCodec::WriteFile(wchar_t const*, int, TRawImageContainer *)
	{
		return 0;
	}*/
	int CJpegImageCodec::WriteBuffer(uchar **a2, uint *a3, int a4, TRawImageContainer *a5)
	{
		int v8 = 2;
		if (a2 && a3 && a5)
		{
			jpeg_compress_struct cinfo;
			jpeg_error_mgr err;
			v8 = 0;

			cinfo.err = jpeg_std_error(&err);
			jpeg_create_compress(&cinfo);
			uchar* ptr = 0;
			ulong v14 = 0;
			jpeg_mem_dest(&cinfo, &ptr, &v14);
			*a3 = v14;
			WriteJpegHelper(&cinfo, a4, a5);
			jpeg_destroy_compress(&cinfo);
			*a3 = v14;
			if (v14 && ptr)
			{
				uchar *v12 = imaging::AllocateMemory(v14);
				*a2 = v12;
				if (v12)
				{
					memcpy_s(v12, v14, ptr, v14);
					v8 = 0;
				}
				else
				{
					v8 = 7;
					*a3 = 0;
				}
			}
			if (ptr)
			{
				free(ptr);
				ptr = 0;
			}
		}
		return v8;
	}
	int CJpegImageCodec::GetFileImageInfo(wchar_t const*, imaging::RI_ImageInfo *)
	{
		return 0;
	}
	int CJpegImageCodec::GetBufferImageInfo(uchar *, uint, imaging::RI_ImageInfo *)
	{
		return 0;
	}
	int CJpegImageCodec::QuickDetectFormat(uchar *, uint)
	{
		return 0;
	}

	int CJpegImageCodec::WriteJpegHelper(jpeg_compress_struct *a2, int a3, TRawImageContainer *a4)
	{
		int result = 1;
		if (a2 && a4)
		{
			a2->image_width = a4->pxRIC_bmi->bmiHeader.biWidth;
			a2->image_height = a4->pxRIC_bmi->bmiHeader.biHeight;
			int v12 = (int)(a4->pxRIC_bmi->bmiHeader.biBitCount >> 3);
			a2->input_components = a2->num_components = v12;
			a2->in_color_space = a2->jpeg_color_space = (v12 == 1) ? JCS_GRAYSCALE : JCS_RGB;
			jpeg_set_defaults(a2);
			a2->density_unit = 1;
			a2->X_density = CImageCodec::GetDensity(a4->pxRIC_bmi->bmiHeader.biXPelsPerMeter, RI_Density_Units_1);
			a2->Y_density = CImageCodec::GetDensity(a4->pxRIC_bmi->bmiHeader.biYPelsPerMeter, RI_Density_Units_1);
			jpeg_set_quality(a2, a3, true);
			jpeg_start_compress(a2, true);
			uint v15 = CImageCodec::CalculateRowStride(a4->pxRIC_bmi->bmiHeader.biWidth, a4->pxRIC_bmi->bmiHeader.biBitCount, 0x20);
			uchar* v16 = new uchar[v15];
			a2->next_scanline = 0;
			JSAMPROW row_pointer[1];
			while (a2->next_scanline < a2->image_height)
			{
				memcpy_s(v16, v15, &a4->pRIC_data[(a2->image_height - a2->next_scanline - 1) * v15], v15);
				SwapRedBlue(v16, a2->image_width, 1, 8 * a2->input_components);
				row_pointer[0] = v16;
				jpeg_write_scanlines(a2, row_pointer, 1);
			}
			delete[] v16;
			jpeg_finish_compress(a2);
			result = 0;
		}
		return result;
	}
	
	int CBmpImageCodec::ReadFile(wchar_t const*, TResultContainer *)
	{
		return 0;
	}
	int CBmpImageCodec::ReadBuffer(uchar *, uint, TResultContainer *)
	{
		return 0;
	}
	int CBmpImageCodec::WriteFile(wchar_t const*, int, TRawImageContainer *)
	{
		return 0;
	}
	int CBmpImageCodec::WriteBuffer(uchar **, uint *, int, TRawImageContainer *)
	{
		return 0;
	}
	int CBmpImageCodec::GetFileImageInfo(wchar_t const*, imaging::RI_ImageInfo *)
	{
		return 0;
	}
	int CBmpImageCodec::GetBufferImageInfo(uchar *, uint, imaging::RI_ImageInfo *)
	{
		return 0;
	}
	int CBmpImageCodec::QuickDetectFormat(uchar *, uint)
	{
		return 0;
	}
	

	namespace angle 
	{
		eRI_Rotations convert(eRPRM_Orientation a1)
		{
			if (a1 == RPRM_Orientation_2)
				return RI_Rotations_2;
			if (a1 == RPRM_Orientation_4)
				return RI_Rotations_3;
			if (a1 == RPRM_Orientation_8)
				return RI_Rotations_1;
			return RI_Rotations_0;
		}

		eRI_Rotations convert(int a2)
		{
			if (a2 == 270)
				return RI_Rotations_3;
			if (a2 == 180)
				return RI_Rotations_2;
			if (a2 == 90)
				return RI_Rotations_1;
			return RI_Rotations_0;
		}

		eRPRM_Orientation convert(eRI_Rotations a1)
		{
			eRPRM_Orientation ret;
			if (a1 == RI_Rotations_1) ret = RPRM_Orientation_8;
			else if (a1 == RI_Rotations_2) ret = RPRM_Orientation_2;
			else if (a1 == RI_Rotations_3) ret = RPRM_Orientation_4;
			else ret = RPRM_Orientation_1;
			return ret;
		}
	}
}
