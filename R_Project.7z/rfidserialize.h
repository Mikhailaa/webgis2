#pragma once
#include "pch.h"
#include <document.h>

class IRFIDJson
{
public:
	virtual GenericValue<UTF8<char>> ToJson(TResultContainer const&a2, MemoryPoolAllocator<CrtAllocator> &a3)
	{
		GenericValue<UTF8<char>> ret;
		return ret;
	}
};

class CRFIDJson : IRFIDJson
{

};

shared_ptr<CRFIDJson> m_prfidJson;
IRFIDJson *g_pIRJ_11411D4;

namespace rfidserialize
{
	IRFIDJson *getSerializer() { return g_pIRJ_11411D4; };
	void setSerialzer(IRFIDJson *a1) { g_pIRJ_11411D4 = a1; };
};

