#pragma once
#include "commonStruct.h"

class CRectCandidats
{
public:
	int m_nRC_Count;
	ResultList *m_pRC_List;
	int m_nRC_CountFalseDetection;
	int m_nRC_Reserved1;
	int m_nRC_Reserved2;

	CRectCandidats();
	~CRectCandidats();
	void clear();
	void resize(uint a2);
};

