#pragma once
#include "../commonStruct.h"

class CPointF;

class CPoint
{
public:
	int nx;
	int ny;
public:
	CPoint();
	CPoint(CPoint const&);
	CPoint(CPointF const&);
	CPoint(float, float);
	CPoint(int, int);
	CPoint(tagPOINT const&);
	CPoint added(CPoint const&);

	operator tagPOINT(void);
	CPoint operator*(float);
	bool operator==(CPoint&);

	CPoint & point(void);
	int & rx(void);
	int & ry(void);
	void set(CPoint const&);
	void set(int, int);
	CPoint subtract(CPoint const&) const;
	int x();
	int y();
};

class CPointF
{
public:
	float fx;
	float fy;
public:
	CPointF();
	CPointF(CPoint const&);
	CPointF(CPointF const&);
	CPointF(float, float);
	CPointF(int, int);
	CPointF added(CPointF const&);
	static float getAngle(CPointF const&, CPointF const&);
	CPointF operator*(float);
	bool operator==(CPointF&);
	CPointF & point();
	float & rx();
	float & ry();
	void set(CPointF const&);
	void set(float, float);
	CPointF subtract(CPointF const&);
	float x();
	float y();
};
