#pragma once
#include "../commonStruct.h"
#include "Point.h"
#include "Size.h"

class CRect
{
public:
	int bottom();
	CPoint center();
	CRect(CPoint &);
	CRect(CPoint &, CSize &);
	CRect(CRect &);
	CRect(CSize &);
	CRect(tagPOINT &, tagSIZE &);
	CRect(tagRECT const&);
	CRect(tagSIZE &);
	CRect();
	CRect crossing(CRect &);
	CRect cut(CSize &);
	bool entering(CPoint &);
	void flatten(CSize &);
	void fromDib(tagRECT &);
	void increaseForCenter(CSize &);
	int left();
	CRect operator*(float);
	bool operator==(CRect&);
	CRect rect();
	tagRECT regRect();
	void reverseH(int);
	void reverseHeight(int);
	void reverseV(int);
	void reverseWidth(int);
	int right();
	void set(CPoint &);
	void set(CRect &);
	void set(CSize &);
	void set(tagRECT &);
	void setCenter(CPoint const&);
	CRect subtractForCenter(CSize &);
	tagRECT toDib();
	int top();

public:
	CPoint m_point;
	CSize m_size;
};