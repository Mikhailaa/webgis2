#pragma once
#include "../commonStruct.h"
#include "Point.h"

class CSize
{
public:
	CSize added(CSize const&);
	//addedAdmitRotate(float);
	//area();
	//CSize(CSize const&);
	//CSize(CSizeF const&);
	CSize(float, float);
	CSize(int, int);
	CSize(tagSIZE const&);
	CSize();
	CSize half();
	int height();
	//kWH();
	//maxWH();
	//minWH();
	//operator tagSIZE();
	//operator!=(CSize const&);
	CSize operator*(float);
	//operator/(float);
	//operator<(CSize const&);
	bool operator==(CSize const&);
	//operator>(CSize const&);
	//rheight();
	//rwidth();
	void set(CSize const&);
	void set(int, int);
	//sizeConst();
	CSize subtract(CSize const&);
	CPoint toPoint();
	int width();
private:
	int m_width;
	int m_height;
};