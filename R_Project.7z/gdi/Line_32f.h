#pragma once
#include "../commonStruct.h"
#include "Point.h"

class CLine_32f
{
public:
	CPointF m_ptStart;
	CPointF m_ptEnd;
	CLine_32f::CLine_32f(tagPOINT &, tagPOINT &);
	static float CLine_32f::getAngle(CLine_32f, CLine_32f);
};

