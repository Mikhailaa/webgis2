#pragma once
#include "pch.h"
#include "ImageControl.h"

enum cv_typeSearchigImage
{
	CV_TYPESEARCHIGIMAGE_1 = 1,
};

namespace RCv
{
	int Check(Mat &);
	void MinMaxLoc(cv::Mat &, double *, double *, cv::Point_<int> *, cv::Point_<int> *);
	int Resize(Mat &, Mat &, int);
	void SobelFull(Mat &, Mat &);
	int WhiteTopHat(cv::Mat const&, cv::Mat&, cv::Size_<int>);
	int find(Mat &, Mat &, float &, float &, float &, cv_typeSearchigImage, int);
	bool match(cv::Mat &, cv::Mat &, cv::Mat &, int);
	void ref(cv::Mat &, IImageControlRef &);
}

namespace RCvMat
{
	void calcHistFastForSmallImg(cv::Mat &, int *&);
	void histogramRange(IImageControlRef &, int, int *);
	bool normalize(IImageControlRef &, IImageControl &, float, float, int);
	Mat ref(IImageControlRef &);
	Mat ref(IImageControlRef &, int);
	Mat ref(RawImageContainerR &);
	int ref(cv::Mat &, IImageControlRef &);
	void rotate_90n(cv::Mat &, cv::Mat &, int);	
}