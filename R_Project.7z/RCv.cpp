#include "RCv.h"
#include "bounds/Analyse.h"

namespace RCv
{
	int Check(Mat &a2)
	{
		if (a2.empty())
			return 2;
		if (a2.data == 0)
			return 2;
		return 0;
	}

	void SobelFull(cv::Mat &xMat_a2, cv::Mat &xMat_a3)
	{
		cv::Mat xSobelMat[2];
		cv::Mat xScaleAbsMat[2];

		cv::Sobel(xMat_a2, xSobelMat[0], 3, 1, 0);
		cv::convertScaleAbs(xSobelMat[0], xScaleAbsMat[0]);
		cv::Sobel(xMat_a2, xSobelMat[1], 3, 0, 1);
		cv::convertScaleAbs(xSobelMat[1], xScaleAbsMat[1]);
		cv::addWeighted(xScaleAbsMat[0], 0.5, xScaleAbsMat[1], 0.5, 0.0, xMat_a3);
	}
	
	int Resize(Mat &a2, Mat &a3, int a4)
	{
		if (Check(a2))
			return 1;

		cv::resize(a2, a3, Size(a3.size.p[1], a3.size.p[0]), 0.0, 0.0, a4);
		return 0;
	}

	int find(Mat & a1, Mat & a2, float & a3, float & a4, float & a5, cv_typeSearchigImage a6, int a7)
	{
		cv::Mat m1a;
		int n7;

		if (!a1.empty() && !a2.empty())
		{
			if (a1.cols >= a2.cols && a1.rows >= a2.rows)
			{
				int n12 = RCv::match(a1, a2, m1a, a7);

				if (n12)
				{
					n7 = 11;
				}
				else
				{
					double d19, d20;
					cv::Point xp21, xp22;
					if (a6 == 2)
					{
						MinMaxLoc(m1a, &d20, 0, &xp22, 0);
					}
					else
					{
						if (a6 == 1)
						{
							MinMaxLoc(m1a, 0, &d19, 0, &xp21);
							a3 = (float)xp21.x;
							a4 = (float)xp21.y;
							a5 = fabsf((float)d19);
							return 0;
						}

						if (a6)
						{
							a3 = a4 = 0.0f;
							return 0;
						}

						MinMaxLoc(m1a, &d20, &d19, &xp22, &xp21);

						if (fabsf((float)d20) <= (float)d19)
						{
							a5 = (float)fabs(d19);
							a3 = (float)xp21.x;
							a4 = (float)xp21.y;
							return 0;
						}
					}

					a5 = fabsf((float)d20);
					a3 = (float)xp22.x;
					a4 = (float)xp22.y;
					return 0;
				}
			}
			else
			{
				return -1;
			}
		}
		return -2;
	}

	bool match(cv::Mat & a1, cv::Mat & a2, cv::Mat & a3, int a4)
	{
		if (!a1.empty() && !a2.empty() && a1.cols >= a2.cols && a1.rows >= a2.rows)
		{
			cv::matchTemplate(a1, a2, a3, a4);
			return false;
		}
		return true;
	}

	void MinMaxLoc(cv::Mat & a1, double * a2, double * a3, cv::Point_<int>* a4, cv::Point_<int>* a5)
	{
		cv::minMaxLoc(a1, a2, a3, a4, a5);
	}

	int WhiteTopHat(cv::Mat const & a1, cv::Mat & a2, cv::Size_<int> a3)
	{
		int n7;
		if (a1.cols && a1.rows)
		{
			a2.release();
			a2.create(a1.size(), a1.flags & 0xFFF);
			cv::Mat m1 = cv::getStructuringElement(2, a3, a3 / 2);

			if (a1.empty())
			{
				n7 = -2;
			}
			else
			{
				cv::morphologyEx(a1, a2, 5, m1);
				n7 = 0;
			}
		}
		else
		{
			n7 = -1;
		}
		return n7;
	}

	void ref(cv::Mat &a2, IImageControlRef &a3)
	{
		a3.ref(a2.cols, a2.rows, a2.data, (int)a2.step.buf[0], 8, ((a2.flags >> 3) & 0x1FF) + 1);
	}
}

namespace RCvMat
{
	void calcHistFastForSmallImg(cv::Mat &a1, int *&a2)
	{
		memclr(a2, 0x400);
		for (int i = 0; i < a1.rows; i++)
		{
			unsigned char *p = (unsigned char *)(a1.data + *a1.step.p * i);
			int j = 0;
			if (a1.cols >= 9)
			{
				for (j = 0; j < a1.cols - 8; j += 8)
				{
					a2[p[j + 0]] ++;
					a2[p[j + 1]] ++;
					a2[p[j + 2]] ++;
					a2[p[j + 3]] ++;
					a2[p[j + 4]] ++;
					a2[p[j + 5]] ++;
					a2[p[j + 6]] ++;
					a2[p[j + 7]] ++;
				}
			}

			for (; j < a1.cols; j++)
			{
				a2[p[j]] ++;
			}
		}
	}

	void histogramRange(IImageControlRef &a1, int a2, int *a3)
	{
		cv::Mat mat_4C = ref(a1);
		cv::Mat mat_8C;
		int v6 = a2;
		float v5[2] = { 0.0f, (float)a2 };
		const float* v7 = v5;
		if (mat_4C.total() > 0x9c3 || mat_4C.empty())
		{
			int v15 = 0;
			cv::calcHist(&mat_4C, 1, &v15, cv::Mat(), mat_8C, 1, &v6, &v7);
			for (int i = 0; i < mat_8C.rows; i++)
			{
				a3[i] = (int)mat_8C.at<float>(i);
			}
		}
		else
		{
			calcHistFastForSmallImg(mat_4C, a3);
		}
	}

	bool normalize(IImageControlRef &a1, IImageControl &a2, float a3, float a4, int a5)
	{
		int v29[256];
		
		histogramRange(a1, 256, v29);
		int w = a1.width();
		int h = a1.height();

		int a6, a7, a8;
		RAnalyse::dynamicRange(v29, 256, (int)((h * w) * a3), (int)((h * w) * a4), a6, a7, a8);
		if (a8 <= a5)
			return true;

		cv::Mat v28 = RCvMat::ref(a1);
		cv::Mat v27(1, 256, 0);

		for (int i = 0; i < a6; i++)
		{
			v27.data[i] = 0;
		}

		for (int i = a7; i < 256; i++)
		{
			v27.data[i] = -1;
		}

		double v17 = 256.0 / (a7 - a6);
		for (int i = a6; i < a7; i++)
		{
			v27.data[i] = (uchar)(v17 * (i - a6) + 0.5);
		}

		MatImage mImg;
		cv::LUT(v28, v27, mImg.m_vMI_4);
		a2.load(mImg);

		return false;
	}

	Mat ref(IImageControlRef &a2)
	{
		int type = 16 * (a2.nChannels() == 3);
		if (a2.nChannels() == 4)
			type = 24;
		return Mat(a2.height(), a2.width(), type, a2.pdata(), a2.widthStep());
	}

	Mat ref(IImageControlRef &a2, int a3)
	{
		Mat a1;
		cv::flip(ref(a2), a1, a3);

		return a1;
	}

	Mat ref(RawImageContainerR &a1)
	{
		int w = -8, h = 0, c = 0;
		if (a1.pxRIC_bmi)
		{
			w = a1.pxRIC_bmi->bmiHeader.biWidth;
			h = a1.pxRIC_bmi->bmiHeader.biHeight;
			c = a1.pxRIC_bmi->bmiHeader.biBitCount & 0xFFF8 - 8;
		}
		return Mat(h, w, c, a1.pRIC_data, a1.widthStep());
	}

	int ref(cv::Mat &a1, IImageControlRef &a2)
	{
		return a2.ref(a1.cols, a1.rows, a1.data, a1.step.buf[0], 8, ((a1.flags >> 3) & 0x1FF) + 1);
	}

	void rotate_90n(Mat & a1, Mat & a2, int a3)
	{
		a2.create(a1.size().height, a1.size().width, a1.flags & 0xFFF);
		switch (a3)
		{
		case -270:
		case 90:
			transpose(a1, a2);
			flip(a2, a2, 1);
			break;
		case 180:
		case -180:
			flip(a1, a2, -1);
			break;
		case 0:
		case 360:
			a2 = a1;
			break;
		case 270:
		case -90:
			transpose(a1, a2);
			flip(a2, a2, 0);
			break;
		default:
			break;
		}
	}
}