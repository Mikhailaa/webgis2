#pragma once
#include "pch.h"
#include "common/container/RclHolder.h"

namespace imageConvertor
{
	struct ImageParams
	{
		int nIP_height;
		int nIP_width;
		int nIP_type;
		int nIP_light;
		uint nIP_pageIndex;
		int nIP_exposure;
	};

	void convert(Json::Value const&, ImageParams &);
	void fromBytesToContainer(ImageParams const&, void *, common::container::RclHolder &);
	void fromBytesToContainer(Json::Value const&, void *, common::container::RclHolder &);
};

