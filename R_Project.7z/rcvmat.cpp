﻿#include "rcvmat.h"

namespace rcvmat {

	namespace RCVRect {
		//화상크기와 령역을 지정하면 해당한 령역을 돌려준다.
		Rect crossing(Rect a1, Size a2)
		{
			int v1, v2, v3, v4;
			Rect v5;

			v1 = (a1.x < 0) ? 0 : a1.x;
			v2 = (a1.y < 0) ? 0 : a1.y;

			if (a2.width >= v1 && a2.height >= v2)
			{
				v3 = a1.width;
				if (v3 < 0 || a1.width > a2.width)
					v3 = a2.width - 1;

				v4 = a1.height;
				if (v4 < 0 || a1.height > a2.height)
					v4 = a2.height - 1;

				if (v1 + v3 > a2.width)
				{
					v3 = a2.width - v1;
					if (a2.width - v1 <= 1)
						v3 = 1;
				}
				if (v2 + v4 > a2.height)
				{
					v4 = a2.height - v2;
					if (a2.height - v2 <= 1)
						v4 = 1;
				}

				v5.x = v1;
				v5.y = v2;
				v5.width = v3;
				v5.height = v4;
			}
			else
				v5 = Rect(0, 0, 0, 0);

			return v5;
		}

		tagRECT regRect(Rect & a1)
		{
			tagRECT v1;
			v1.left = a1.x;
			v1.top = a1.y;
			v1.right = (a1.width + a1.x);
			v1.bottom = (a1.height + a1.y);
			return v1;
		}

		Rect fromDib(tagRECT a1)
		{
			Rect v1;
			v1.x = a1.left;
			v1.y = a1.top;
			v1.width = a1.right - a1.left;
			v1.height = a1.bottom - a1.top;
			return v1;
		}

		Rect increaseForCenter(Rect & a1, Size a2)
		{
			Rect v1;
			v1.x = a1.x - a2.width / 2;
			v1.y = a1.y - a2.height / 2;
			v1.width = a1.width + a2.width;
			v1.height = a1.height + a2.height;
			return v1;
		}

		Rect reverseHeight(Rect a1, int a2)
		{
			int v1;
			Rect v2;

			v1 = a1.y + a1.height;
			if (v1 > a2)
				a2 = v1;

			v2.x = a1.x;
			v2.y = a2 - v1;
			v2.width = a1.width;
			v2.height = a1.height;
			return v2;
		}

		Rect reverseHeight(tagRECT const & a1, int a2)
		{
			Rect v1;
			v1.x = a1.left;
			v1.y = a2 - a1.bottom;
			v1.width = a1.right;
			v1.height = a2 - a1.top;
			return v1;
		}
	}
	
	namespace RCVMat {
		//같은 크기의 두개 화상의 and를 a2에 돌려준다.
		void and__(Mat & a1, Mat & a2)
		{
			Mat v1;
			if (!a1.empty() && !a2.empty())
			{
				bitwise_and(a1, a2, v1);
				v1.copyTo(a2);
			}
		}

		//원천화상a1을 a2에 복사한다.
		void load(Mat const & a1, Mat & a2)
		{
			if (!a1.empty())
				a1.copyTo(a2);
		}
		
		//원천화상을 a3령역으로 잘라내여 a2에 복사한다.(령역지정을 바로하지 않으면 오유발생)		
		void load(Mat const & a1, Mat & a2, Rect a3)
		{
			Rect v1;
			Mat v2;

			if (!a1.empty())
			{
				v1 = rcvmat::RCVRect::crossing(a3, a1.size());
				load(a1, v2);
				Mat v3(v2, v1);
				load(v3, a2);
			}
		}

		//색갈화상에 대하여 여러가지 색변화를 진행하여 a2에 보관한다.(색갈화상이 아니면 그대로 출력)
		void load(Mat const& a1, Mat & a2, tFullColors_cv a3)
		{
			vector<Mat> v1;
			Mat v2;
			Scalar v3;

			if (a1.empty() || a1.flags & CV_MAT_CN_MASK)
			{
				if (!a1.empty() && (a1.flags & CV_MAT_CN_MASK) == 16)
				{
					v1.resize(3);
					switch (a3)
					{
					case 1:
						cvtColor(a1, a2, COLOR_BGR2GRAY);
						break;
					case 2:
						split(a1, v1);
						v1[2].copyTo(a2);
						break;
					case 3:
						split(a1, v1);
						v1[1].copyTo(a2);
						break;
					case 4:
						split(a1, v1);
						v1[0].copyTo(a2);
						break;
					case 5:
						a1.copyTo(v2);
						v3 = Scalar(255.0, 0.0, 0.0, 0.0);
						subtract(v2, v3, v2);
						cvtColor(v2, a2, COLOR_BGR2GRAY);
						break;

					case 6:
						a1.copyTo(v2);
						v3 = Scalar(0.0, 255.0, 0.0, 0.0);
						subtract(v2, v3, v2);
						cvtColor(v2, a2, COLOR_BGR2GRAY);
						break;

					case 7:
						a1.copyTo(v2);
						v3 = Scalar(0.0, 0.0, 255.0, 0.0);
						subtract(v2, v3, v2);
						cvtColor(v2, a2, COLOR_BGR2GRAY);
						break;
					}
				}
			}
			else
				a1.copyTo(a2);
		}

		//첨수가 a2, a3범위에 있는 벡토르성분들의 합을 a4에 돌려준다.
		void numberPointInRange(vector<int> & a1, int a2, int a3, int & a4)
		{
			int v1 = 0;
			a4 = 0;
			for (int i = a2; i <= a3; i++)
				a4 += a1[i];
		}

		//화상에 대한 회전을 진행한다. 출력 = a2, 회전각 = a3
		void rotate(Mat & a1, Mat & a2, int a3)
		{
			if (!a1.empty())
			{
				if (a3)
				{
					switch (a3)
					{
					case 270:
						transpose(a1, a2);
						flip(a2, a2, 1);
						break;
					case 180:
						flip(a1, a2, -1);
						break;
					case 90:
						transpose(a1, a2);
						flip(a2, a2, 0);
						break;
					}
				}
				else
					a1.copyTo(a2);
			}
		}

		//화상에 대하여 경계를 검출한다. 출력 = a2, 형태 = a5
		void threshold(Mat & a1, double a3, double a4, int a5)
		{
			int v1;
			if (!a1.empty() && !(a1.flags & CV_MAT_CN_MASK))
			{
				v1 = a5;
				if(a3 == 0.0 && a5 == 0)
					v1 = 8;
				Mat a2;
				threshold(a1, a2, a3, a4, v1);
				a2.copyTo(a1);
			}
		}

		//히스토그람을 계산하여 a2에 돌려준다.
		int calcHist(Mat const & a1, vector<int>& a2, int a3, int a4, int a5)
		{
			int v1, v2;
			Mat v3, v4;
			const float v5[] = { (float)a4, (float)a5 };
			const float* v7[] = { v5 };
			int v6[] = { a3 };

			if (a1.empty())
				v1 = 0;
			else
			{
				v1 = 0;
				if (!(a1.flags & CV_MAT_CN_MASK))
				{
					v2 = 0;
					a2.clear();
					calcHist(&a1, 1, &v2, Mat(), v3, 1, v6, v7);
					if (v3.empty())
						v1 = -1;
					else
					{
						v3.convertTo(v4, 4);
						if (v4.data)
						{
							a2.resize(a3);
							memmove(a2.data(), v4.data, 4 * v4.rows);
						}
						else
							v1 = -1;
					}
				}
			}

			return v1;
		}

		//화상에서 령아닌 성분개수(GrayScale화상에 대하여서만 적용가능하다.)
		int countNonZero(Mat & a1)
		{
			int v1 = 0;

			if (a1.empty())
				return 0;

			if (!(a1.flags & CV_MAT_CN_MASK))
				v1 = countNonZero(a1);

			return v1;
		}

		//화상경계를 팽창시킨다. 결과 = a2
		int dilate(Mat & a1, Mat & a2, Size a3)
		{
			int v1 = 0;
			Mat v2;
			Size v3;

			if (!a1.empty() && !(a1.flags << 20))
			{
				if (a3.width == 3 && a3.height == 3)
					dilate(a1, a2, Mat());
				else
				{
					v3.width = 2 * a3.width + 1;
					v3.height = 2 * a3.height + 1;
					v2 = getStructuringElement(1, v3, a3);
					dilate(a1, a2, v2);
				}
			}
			else
				v1 = -1;

			return v1;
		}

		int dynamicRange(vector<int> & a1, int a2, int a3, int & a4, int & a5, int & a6)
		{
			int v1 = 0, v2 = 0, v3;

			if (a1.empty())
				return -1;

			int i;
			int sum = 0;
			for (i = 0; i < (int)(a1.size() - 1); i++)
			{
				sum += a1[i];
				if (sum > a2) 
					break;
			}
			a4 = i;

			sum = 0;
			for (i = (int)a1.size() - 1; i >= 0; i--)
			{
				sum += a1[i];
				if (sum > a3)
					break;
			}
			a5 = i;
			a6 = a5 - a4;

			v3 = a6;
			if (a4 == a5)
				v3 = 1;
			if (!a4)
				v3 = a6;
			a6 = v3;

			if (v3 <= 0)
			{
				a4 = 0;
				a5 = 0;
				a6 = 0;
			}

			return v1;
		}

		//화상을 180도 돌린다.
		int flip(Mat & a1)
		{
			Mat v1;
			if (a1.empty())
				return -1;

			flip(a1, v1, 0);
			load(v1, a1);

			return 0;
		}

		int find(Mat const & a1, Mat const & a2, float & a3, float & a4, float & a5, cvTypeSearchigImage a6, int a7)
		{
			int v1 = 0;
			Mat v2;
			double v3, v6;
			Point v4, v5;

			if (!a1.empty() && !a2.empty())
			{
				a5 = 0;
				if (a1.cols >= a2.cols && a1.rows >= a2.rows)
				{
					matchTemplate(a1, a2, v2, a7);
					if (v2.empty())
						return 0;

					if (a6 == 2)
					{
						minMaxLoc(v2, &v3, 0, &v4, 0, 0);
						a5 = fabsf((float)v3);
						a3 = (float)v4.x;
						a4 = (float)v4.y;
					}
					else if (a6 == 1)
					{
						minMaxLoc(v2, 0, &v3, 0, &v5, 0);
						a5 = fabsf((float)v3);
						a3 = (float)v5.x;
						a4 = (float)v5.y;
					}
					else if (a6 == 0)
					{
						minMaxLoc(v2, &v3, &v6, &v4, &v5, 0);
						if (fabs(v3) > v6)
						{
							a5 = (float)fabs(v3);
							a3 = (float)v4.x;
							a4 = (float)v4.y;
						}
						else
						{
							a5 = (float)fabs(v6);
							a3 = (float)v5.x;
							a4 = (float)v5.y;
						}
					}
				}
				else
					v1 = -1;
			}
			else
				v1 = -1;

			return v1;
		}

		int histCenter(vector<int> & a1, float & a2, int a3, int a4)
		{
			int v1 = 0, v2 = 0;

			if (a4 > (int)a1.size())
				return 1;

			a2 = -1.0;
			for (int i = a3; i < a4; i++)
			{
				v1 += a1[i];
				v2 += a1[i] * i;
			}

			if (!v1)
				return 1;

			a2 = (float)v2 / v1;
			return 0;
		}

		//TRawImageContainer로부터 화상을 불러들인다.
		int load(RawImageContainerR * a1, Mat & a2)
		{
			int cols, rows, v3, step, v6 = 0;

			if (a1 && a1->pxRIC_bmi && a1->pRIC_data)
			{
				cols = a1->pxRIC_bmi->bmiHeader.biWidth;
				rows = a1->pxRIC_bmi->bmiHeader.biHeight;
				v3 = a1->pxRIC_bmi->bmiHeader.biBitCount;
				step = a1->widthStep();

				Mat v5(rows, cols, (v3 & 0xfffffff8) - 8, a1->pRIC_data, step);
				if (v5.empty())
					v6 = -1;
				else
					v5.copyTo(a2);
			}
			else
				v6 = -1;

			return v6;
		}

		int open(Mat & a1, Mat & a2, Size a3)
		{
			int v1 = 0;
			Mat v2;
			Size v3;

			if (!a1.empty() && !(a1.flags << 20))
			{
				if (a3.width == 3 && a3.height == 3)
					morphologyEx(a1, a2, 2, Mat());
				else
				{
					v3.width = 2 * a3.width + 1;
					v3.height = 2 * a3.height + 1;
					v2 = getStructuringElement(1, v3, a3);
					morphologyEx(a1, a2, 2, v2);
				}
			}
			else
				v1 = -1;

			return v1;
		}

		int projection(Mat & a1, Mat & a2, int a3)
		{
			int v1 = -1;
			if (!a1.empty())
			{
				reduce(a1, a2, a3, 1);
				v1 = a2.empty() ? -1 : 0;
			}

			return v1;
		}

		//화상의 크기를 변화시킨다.
		int resize(Mat const & a1, Mat & a2, Size a3)
		{
			if (a1.empty()|| !a3.height || !a3.width)
				return -1;
			
			cv::resize(a1, a2, a3);
			return a2.empty() ? -1 : 0;
		}

		int rotate(Mat const & a1, Mat & a2, double a3, double a4, double a5, Scalar & a6)
		{
			Mat v1;
			if (a1.empty())
				return -1;

			v1 = getRotationMatrix2D(Point2f((float)a4, (float)a5), a3, 1.0);
			warpAffine(a1, a2, v1, a1.size(), 1, 0, a6);
			return 0;
		}

		int rotateCenter(Mat const & a1, Mat & a2, double a3, int a4, Scalar a5)
		{
			Scalar v1;
			for (int i = 0; i < 4; i++)
				v1.val[i] = a5.val[i];
			return rotate(a1, a2, a3, a1.cols * 0.5, a1.rows * 0.5, v1);
		}

		int sobel(Mat const & a1, Mat & a2, rcvmat::typePosition a3)
		{
			Mat v1, v2;
			MatExpr v3;

			if (a1.empty())
				return -1;
			switch (a3)
			{
			case 2:
				Sobel(a1, v1, -1, 1, 0);
				Sobel(a1, v2, -1, 0, 1);
				v3 = v1 + v2;
				v3.op->assign(v3, a2);
				break;
			case 1:
				Sobel(a1, a2, -1, 1, 0);
				break;
			case 0:
				Sobel(a1, a2, -1, 0, 1);
				break;
			}

			return (a2.empty() ? -1 : 0);
		}
	}
}