#pragma once

#include "commonStruct.h"
#include "common/container/ThreadStorage.h"
#include "Json/Value.h"
#include "rclhelp.h"
#include "processparams.h"
#include "processmanagerdefault.h"
#include "moduleprocessgl.h"
#include "common/ModuleOrchestrator.h"

namespace procmgr
{

	void initScenario(eProcessCommands, common::container::RclHolder &, Json::Value &);
	void FilterResultsByType(common::container::RclHolder &, vector<uint> const&);
	void filterRclForSerialization(common::container::RclHolder &, vector<uint> const&);
	string serializeRclToJson(common::container::RclHolder &, string const&);

	namespace bounds
	{
		void addBoundsResult(Json::Value const&, common::container::RclHolder &);
	}

	namespace barcode 
	{
		int addExternalBarcode(Json::Value &, common::container::RclHolder &);
	}

	namespace develop
	{
		void saveImage(TResultContainer *, processparams::eProcessMode, string const&, int, int, int, int, int);

		void saveImage(common::container::RclHolder &, processparams::eProcessMode, string const&, int, int, int);
	}

	namespace face
	{
		void printFacePosition(Json::Value &);
		void rotateFaceMetadata(Json::Value &, eRPRM_Orientation, tagSIZE const&);
	}

	namespace imageconvert
	{
		int getImageFromJson(eProcessCommands, Json::Value &, common::container::RclHolder &);
		bool cropImage(Json::Value &, common::container::RclHolder &, float, tagPOINT &);
	}

	namespace json
	{
		void updateFacePos(Json::Value &, tagPOINT &);
		void updateBarcodePos(Json::Value &, tagPOINT &);
		void updateCreditCardScenario(Json::Value &);
	}

	namespace license
	{
		int checkLicense(int, Json::Value &, string &);
		int initLicense(Json::Value &, string &);

		class HeartbeatHelper
		{
		public:
			HeartbeatHelper() {};
			~HeartbeatHelper() {};
			void Close() {};
			void HeartBeat(void) {};
			void Register(Json::Value &, Guid const&) {};
			void allowTransaction(void) {};
		};
	}

	namespace timeout
	{
		void configureTimeOut(Json::Value &);
		void setTimeOut(Json::Value &, int, int, int);
	}

	class ProcMgr : public moduleprocessgl::IProcessFunction
	{
	public:
		ProcMgr(void);
		virtual ~ProcMgr();

		int Initialize(void *, char *, string &);
		int cmdProcessImage(common::container::RclHolder &, string const&, processmanagerdefault::scenario::eProcessScenario const&, void **, char **);
		vector<int> getCommands(void);
		int process(int, void *, const char *, void **, char **);
		void updateAppConfigParams(Json::Value &);
		void updateScenarioParams(string &, Json::Value &);

		bool	m_bPM_field_4;
		common::container::ThreadStorage<common::container::RclHolder> m_tsPM_RclHolder;
		string	m_xPM_String1;
		Guid	m_xPM_Guid1;
		Guid	m_xPM_Guid2;
		shared_ptr<license::HeartbeatHelper> m_spPM_HeartbeatHelper;
		string	m_xPM_String2;
		int		m_nPM_field_48;
		int		m_nPM_field_4C;
		string	m_xPM_String3;
		int		m_nPM_field_5C;
		Json::Value m_xPM_Params;
		tagSIZE	m_xPM_ImgSize;
	};
}