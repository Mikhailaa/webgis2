#include "legacycommonlib.h"
#include "common/StringUtils.h"
#include "rclhelp.h"
#include "common/container/jsoncpp.h"
#include "Json/CharReaderBuilder.h"

namespace legacycommonlib
{
	FieldsLoadFilter & FieldsLoadFilter::operator=(FieldsLoadFilter &arg1)
	{
		m_vn_0 = arg1.m_vn_0;
		m_vn_C = arg1.m_vn_C;
		field_18 = arg1.field_18;
		field_1C = arg1.field_1C;
		return *this;
	}
	FieldsLoadFilter& FieldsLoadFilter::operator=(FieldsLoadFilter &&arg1)
	{
		m_vn_0 = move(arg1.m_vn_0);
		m_vn_C = move(arg1.m_vn_C);
		field_18 = move(arg1.field_18);
		field_1C = move(arg1.field_1C);
		return *this;
	}

	FieldsLoadFilter::FieldsLoadFilter()
		: m_vn_0()
		, m_vn_C()
	{
		field_18 = -1;
		field_1C = 0xFFFF;
	}

	FieldsLoadFilter::~FieldsLoadFilter()
	{

	}

	//////////////////////////////////////////////////

	namespace jsoncpp
	{
		namespace realrect
		{
			void convert(Json::Value const &xJV_Param1, tagRECTF &xParam2)
			{
				Json::Value xJV_Param(xJV_Param1);
				if (xJV_Param.isObject())
				{
					xParam2.left = xJV_Param["left"].asFloat();
					xParam2.top = xJV_Param["top"].asFloat();
					xParam2.right = xJV_Param["right"].asFloat();
					xParam2.bottom = xJV_Param["bottom"].asFloat();
				}
				else
				{
					string sTemp = xJV_Param.asString();
					vector<string> vstr = common::StringUtils::Split(sTemp, ',');
					if (vstr.size() == 4)
					{
						xParam2.left = atoi(vstr[0].data()) / 1000000000.0f;
						xParam2.top = atoi(vstr[1].data()) / 1000000000.0f;
						xParam2.right = atoi(vstr[2].data()) / 1000000000.0f;
						xParam2.bottom = atoi(vstr[3].data()) / 1000000000.0f;
					}
				}
			}
		}

		bool tryToGetDocInfo(common::container::RclHolder &xRH_Param1, const char *pcParam2, Json::Value &xJV_Param3, CDocInfo **ppCDI_Param4)
		{
			CDocInfo *v8 = rclhelp::docdesc::getDocDescFromContainer(xRH_Param1);
			ppCDI_Param4 = &v8;
			return (!v8  && rclhelp::docdesc::convertDocDesc(xRH_Param1, pcParam2, xJV_Param3));
		}

		int convert(string const &strParam1, CDocInfo &xCDI_Param2, FieldsLoadFilter *pFLF_Param3)
		{
			Json::Value jvTemp(0);
			int v6 = common::container::jsoncpp::convert(strParam1, jvTemp);
			if (!v6)
			{
				jsoncpp::convert(jvTemp["document"], xCDI_Param2, pFLF_Param3);
			}
			return v6;
		}

		int convert(string &strParam1, ListSubField &xLSF_Param2)
		{
			Json::CharReaderBuilder crb;
			Json::OurCharReader ocr = *crb.newCharReader();
			Json::Value jv(0);
			int res;
			if (ocr.parse(strParam1.data(), strParam1.data() + strParam1.length(), &jv, 0))
			{
				convert(Json::Value(jv["subfields"]), xLSF_Param2);
				res = 0;
			}
			else
			{
				res = 1;
			}
			return res;
		}

		void convert(Json::Value const &xJV_Param1, TVocList &xTVL_Param2)
		{
			vector<string> vstr = xJV_Param1.getMemberNames();
			xTVL_Param2.nTVL_VocCount = vstr.size();
			for (uint i = 0; i < vstr.size(); i++)
			{
				xTVL_Param2.nnTVL_VocIDList[i] = atoi(vstr[i].data());
			}
		}

		void convert(Json::Value const &xJV_Param1, TProcParams &xTPP_Param2)
		{
			xTPP_Param2.rTPP_Orientation = (float)xJV_Param1["orientation"].asInt();
			xTPP_Param2.nTPP_Mirror_flip = xJV_Param1["mirror"].asInt();
			xTPP_Param2.nTPP_TypeResultColor = xJV_Param1["colorType"].asInt();
			xTPP_Param2.nTPP_Median_Execute = xJV_Param1["medianFilter"].asBool();
			xTPP_Param2.nTPP_Blur_Level = xJV_Param1["blur"].asInt();
			xTPP_Param2.nTPP_Sharpness_Level = xJV_Param1["sharpness"].asInt();
			xTPP_Param2.nTPP_brightness = xJV_Param1["brightness"].asInt();
			xTPP_Param2.nTPP_contrast = xJV_Param1["contrast"].asInt();
			xTPP_Param2.sTPP_RemoveLines = xJV_Param1["linesFilter"].asInt();
			xTPP_Param2.sTPP_AutoSwitchIRtoWHITE = xJV_Param1["autoSwitchIrToWhite"].asInt();
			xTPP_Param2.sTPP_IRtoWHITEThreshold = xJV_Param1["irToWhiteThreshold"].asInt();
			xTPP_Param2.nTPP_Layer = xJV_Param1["layer"].asInt();
			xTPP_Param2.nTPP_Positive = xJV_Param1["negative"].asBool() ^ 1;
		}

		void convert(Json::Value const&xJV_Param1, CAlphabet *pCA_Param2)
		{
			Json::Value xJV_Param(xJV_Param1);
			if (xJV_Param.isArray())
			{
				for (uint i = 0; i < xJV_Param.size(); i++)
				{
					Json::Value jvTemp = xJV_Param[i];
					if (jvTemp["isActive"].asBool())
					{
						int t = jvTemp["type"].asInt();
						string s = jvTemp["values"].asString();
						wstring ws = common::UnicodeUtils::Utf8ToWStr(s);
						int v13;
						if (t == 'D')
						{
							v13 = 2;
						}
						else if (t == 'S')
						{
							v13 = 3;
						}
						else if (t == 'c')
						{
							v13 = 1;
						}
						else
						{
							v13 = 0;
						}
						pCA_Param2[v13].m_bCA_HasData_0 = t;
						strcpy(pCA_Param2[v13].m_szCA_Alphabet, s.data());
					}
				}
			}
			else
			{
				string s = xJV_Param1.get("67", "").asString();
				if (s.length())
				{
					pCA_Param2[0].m_bCA_HasData_0 = 67;
					strcpy(pCA_Param2[0].m_szCA_Alphabet, "ABCDEFGHIJKLMNOPQRSTUVWXYZ");
				}
				s = xJV_Param1.get("99", "").asString();
				if (s.length())
				{
					pCA_Param2[1].m_bCA_HasData_0 = 99;
					strcpy(pCA_Param2[1].m_szCA_Alphabet, "abcdefghijklmnopqrstuvwxyz");
				}
				s = xJV_Param1.get("68", "").asString();
				if (s.length())
				{
					pCA_Param2[2].m_bCA_HasData_0 = 68;
					strcpy(pCA_Param2[2].m_szCA_Alphabet, "0123456789");
				}
				s = xJV_Param1.get("83", "").asString();
				if (s.length())
				{
					pCA_Param2[3].m_bCA_HasData_0 = 83;
					strcpy(pCA_Param2[3].m_szCA_Alphabet, s.data());
				}
			}
		}

		void convert(Json::Value const &xJV_Param1, ListSubField &xLSF_Param2)
		{
			xLSF_Param2.resize(xJV_Param1.size());
			for (uint i = 0; i < xJV_Param1.size(); i++)
			{
				Json::Value jvTemp = xJV_Param1[i];
				convert(jvTemp["vocabularies"], xLSF_Param2[i].m_xCVSF_VL);
				convert(jvTemp["alphabet"], xLSF_Param2[i].m_aTVSF_Alphabet_218);
				xLSF_Param2[i].m_sTVSF_fieldType = jvTemp["fieldType"].asInt();
				xLSF_Param2[i].m_sTVSF_lcid = jvTemp["lcid"].asInt();
				string sCap = jvTemp["caption"].asString();
				strcpy(xLSF_Param2[i].m_szTVSF_4, sCap.data());
				string sTemp = jvTemp["mask"].asString();
				strcpy(xLSF_Param2[i].m_szTVSF_110, sTemp.data());
				sTemp = jvTemp["enum"].asString();
				if (sCap == "SPACE")
				{
					sTemp = " ";
				}
				if (sTemp.length())
				{
					wstring wsTemp = common::UnicodeUtils::Utf8ToWStr(sTemp);
					vector<wstring> vwstr = common::StringUtils::Split(wsTemp, '|');
					xLSF_Param2[i].m_nTVSF_Count_210 = vwstr.size();
					if (vwstr.size())
					{
						xLSF_Param2[i].m_lpTVSF_Buffer_214 = new char[256 * vwstr.size()];
						for (uint j = 0; j < vwstr.size(); j++)
						{
							string s = common::UnicodeUtils::WStrToUtf8(vwstr[j]);
							strcpy(&xLSF_Param2[i].m_lpTVSF_Buffer_214[256 * j], s.data());
						}
					}
				}
			}
		}

		void convert(Json::Value const &xJV_Param1, CFieldFont &xCFF_Param2)
		{
			xCFF_Param2.m_nFF_layer = xJV_Param1["fontLayer"].asInt();
			xCFF_Param2.m_sFF_LCID = xJV_Param1["lcid"].asInt();
			xCFF_Param2.m_nFF_Incline = xJV_Param1["inclined"].asInt();
			xCFF_Param2.m_sFF_LongSpace = xJV_Param1["longSpaces"].asInt();
			xCFF_Param2.m_nFF_Type = xJV_Param1["fontType"].asInt();
			xCFF_Param2.m_cFF_VarHeight = xJV_Param1["varHeight"].asInt();
			xCFF_Param2.m_cFF_emptyFieldToResult = xJV_Param1["emptyResultOutput"].asBool();
			if (xJV_Param1.isMember("h"))
			{
				xCFF_Param2.m_rFF_HeightRel = xJV_Param1["h"].asFloat() / 1000000000.0f;
			}
			else
			{
				tagRECTF r;
				realrect::convert(Json::Value(xJV_Param1["heightRect"]), r);
				xCFF_Param2.m_rFF_HeightRel = fabsf(r.top - r.bottom);
			}
		}

		int convert(Json::Value const &xJV_Param1, CVisualField &xCVF_Param2, FieldsLoadFilter *pFLF_Param3)
		{
			xCVF_Param2.sTVF_status = xJV_Param1.isMember("status") ? xJV_Param1["status"].asInt() : 1;
			xCVF_Param2.nTVF_docID = xJV_Param1["number"].asInt();
			xCVF_Param2.nTVF_lightType = xJV_Param1["lightType"].asInt();
			realrect::convert(Json::Value(xJV_Param1["relRect"]), xCVF_Param2.xTVF_RelRegion);
			xCVF_Param2.u.s.sTVF_wFieldType = xJV_Param1["fieldType"].asInt();
			xCVF_Param2.u.s.sTVF_wLCID = xJV_Param1["lcid"].asInt();
			string strTemp = xJV_Param1["mask"].asString();
			
			tuple<string, string, bool> tp[4] = {
				tuple<string, string, bool>("removeBackground", "CBR", false),
				tuple<string, string, bool>("useDNN", "DNN", true),
				tuple<string, string, bool>("removeValue", "FRV", false),
				tuple<string, string, bool>("lowContrastText", "LCT", false),
			};
			for (int i = 0; i < 4; i++)
			{
				Json::Value jvTemp = xJV_Param1.get(get<0>(tp[i]), Json::Value(get<2>(tp[i])));
				if (!jvTemp.asBool())
					continue;
				int pos = strTemp.find("{_@");
				if (pos == -1)
				{
					string s("{_@");
					s.append(get<1>(tp[i]));
					s.append("@}");
					s.append(strTemp);
					strTemp = s;
				}
				else
				{
					string s(get<1>(tp[i]));
					s.append(",");
					strTemp.insert(pos + 3, s);
				}
			}
			strcpy(xCVF_Param2.szTVF_Mask, strTemp.data());
			xCVF_Param2.nTVF_InComparison = xJV_Param1["inComparison"].asInt();
			if (xJV_Param1.isMember("outputCase"))
			{
				xCVF_Param2.sTVF_postProcessing = xJV_Param1["outputCase"].asInt();
			}
			convert(Json::Value(xJV_Param1["alphabet"]), (CAlphabet *)xCVF_Param2.xTVF_Alphabet);
			convert(Json::Value(xJV_Param1["vocabularies"]), xCVF_Param2.getVocList());
			convert(xJV_Param1, xCVF_Param2.xTVF_Font);
			convert(xJV_Param1, xCVF_Param2.xTVF_ProcParams);
			xCVF_Param2.xTVF_Font.m_cFF_emptyFieldToResult = xJV_Param1.isMember("emptyResultOutput") ? xJV_Param1["emptyResultOutput"].asBool() : 0;
			if (pFLF_Param3)
			{
				uint i;
				for (i = 0; i < pFLF_Param3->m_vn_0.size(); i++)
				{
					if (pFLF_Param3->m_vn_0[i] == xCVF_Param2.u.s.sTVF_wFieldType)
						break;
				}
				if (!pFLF_Param3->m_vn_0.empty() && i == pFLF_Param3->m_vn_0.size())
					return 1;
				for (i = 0; i < pFLF_Param3->m_vn_C.size(); i++)
				{
					if (pFLF_Param3->m_vn_C[i] == xCVF_Param2.u.s.sTVF_wLCID)
						break;
				}
				if (!pFLF_Param3->m_vn_C.empty() && i == pFLF_Param3->m_vn_C.size())
					return 1;
				if (pFLF_Param3->field_1C != -1 && !(pFLF_Param3->field_1C & xCVF_Param2.sTVF_status))
					return 1;
				if (pFLF_Param3->field_18 != -1 && xJV_Param1["number"].asInt() != pFLF_Param3->field_18)
					return 1;
			}
			return 0;
		}

		void convert(Json::Value const &xJV_Param1, CDocInfo &xCDI_Param2, FieldsLoadFilter *pFLF_Param3)
		{
			xCDI_Param2.nTDI_DocID = xJV_Param1["number"].asInt();
			Json::Value jvTemp(xJV_Param1["textRects"]);
			xCDI_Param2.resize(jvTemp.size());
			int i = 0;
			for (Json::ValueIteratorBase iter = jvTemp.begin(); iter != jvTemp.end(); iter.increment())
			{
				Json::Value jv = iter.deref();
				memset(&xCDI_Param2.pxTDI_Fields[i], 0, sizeof(CVisualField));
				if (!convert(jv, *(CVisualField *)&xCDI_Param2.pxTDI_Fields[i], pFLF_Param3))
					i++;
			}
			xCDI_Param2.nTDI_nFields = i;
		}

		void convert(CRecognizedTextDoc &xCRTD_Param1, Json::Value &xJV_Param2, int nParam3)
		{
			xJV_Param2.clear();
			if (nParam3 == 1)
			{
				for (int i = 0; i < xCRTD_Param1.count(); i++)
				{
					string strTemp = common::StringUtils::toString(xCRTD_Param1.field(i)->u0.s0.wFieldType);
					strTemp.append("-");
					strTemp.append(common::StringUtils::toString(xCRTD_Param1.field(i)->u0.s0.wLCID));
					string s21;
					if (xCRTD_Param1.field(i)->pszDVEF_Buf_Text)
					{
						s21 = (char *)xCRTD_Param1.field(i)->pszDVEF_Buf_Text;
					}
					xJV_Param2[strTemp] = Json::Value(s21);
				}
			}
		}
	}
};
