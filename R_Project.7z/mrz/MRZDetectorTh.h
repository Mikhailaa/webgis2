#pragma once
#include "../pch.h"
#include "mrz_detector/MRZDetectorResults.h"
#include "mrz_detector/SingletonRegime.h"
#include "../moduleprocessgl.h"
#include "../common/container/ThreadStorage.h"

class MRZDetectorExt
{
public:
	mrz_detector::MRZDetectorResults          m_xMRZDE_0;
	shared_ptr<mrz_detector::SingletonRegime> m_spMRZDE_18;
public:
	MRZDetectorExt();
	~MRZDetectorExt();

	int initMRZDetector(int);
	int process(int, void *, const char *, void **, char **);
};

class MRZDetectorTh : public moduleprocessgl::IProcessFunction
{
public:
	common::container::ThreadStorage<MRZDetectorExt> m_xMRZDT_4;
public:
	MRZDetectorTh();
	~MRZDetectorTh();

	vector<int> getCommands();
	int process(int, void *, const char *, void **, char **);
};
