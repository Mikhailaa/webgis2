#include "MRZDetectorTh.h"
#include "mrz_detector/MRZDetectorProcessSingleton.h"
#include "mrz_detector/MRZDetectorProcess.h"
#include "../common/resources.h"
#include "mrz_error_corrector/MrzCorrectorInfo.h"
#include "../common/ModuleOrchestrator.h"

using namespace mrz_detector;

MRZDetectorExt::MRZDetectorExt()
{
}

MRZDetectorExt::~MRZDetectorExt()
{
}

int MRZDetectorExt::initMRZDetector(int a2)
{
	m_spMRZDE_18 = make_shared<SingletonRegime>(a2);
	return MRZDetectorProcessSingleton::obj()->init();
}

int MRZDetectorExt::process(int a2, void * a3, const char * a4, void ** a5, char ** a6)
{
	TResultContainerList * p11 = m_xMRZDE_0.getPointer(pthread_self());

	basic_string<char> bs36(!a4 ? "" : a4);
	int n14;

	switch (a2)
	{
	case 2401:
	case 2403:
		n14 = initMRZDetector(6);
		if (n14)
		{
			return n14;
		}
		else
		{
			*a5 = p11;
			return Process(1, m_spMRZDE_18, (TResultContainerList *)a3, bs36, p11);
		}
		break;
	case 2402:
		n14 = initMRZDetector(12);
		if (n14)
		{
			return n14;
		}
		else
		{
			*a5 = p11;
			return Process(1, m_spMRZDE_18, (TResultContainerList *)a3, bs36, p11);
		}
		break;
	case 2404:
		n14 = initMRZDetector(6);
		if (n14)
		{
			return n14;
		}
		else
		{
			*a5 = p11;
			return Process(2, m_spMRZDE_18, (TResultContainerList *)a3, bs36, p11);
		}
		break;
	case 2405:
		n14 = initMRZDetector(6);
		if (n14)
		{
			return n14;
		}
		else
		{
			*a5 = p11;
			return Process(3, m_spMRZDE_18, (TResultContainerList *)a3, bs36, p11);
		}
		break;
	case 2406:
		n14 = initMRZDetector(36);
		if (n14)
		{
			return n14;
		}
		else
		{
			*a5 = p11;
			return Process(1, m_spMRZDE_18, (TResultContainerList *)a3, bs36, p11);
		}
		break;
	case 2407:
		if (!a3 && !bs36.length())
		{
			return 2;
		}
		n14 = initMRZDetector(2);
		if (n14)
		{
			return n14;
		}
		else
		{
			*a5 = p11;
			int n24 = Process(5, m_spMRZDE_18, (TResultContainerList *)a3, bs36, p11);
			if (n24 != 8)
			{
				return 2;
			}

			return 0;
		}
		break;
	case 2408:
		if (a3)
		{
			n14 = initMRZDetector(2);

			if (!n14)
			{
				*a5 = p11;
				int n27 = Process(5, m_spMRZDE_18, (TResultContainerList *)a3, bs36, p11);
				
				if (n27 != 2)
				{
					return 2;
				}

				return 0;
			}

			return n14;
		}
		else
		{
			return 2;
		}
		break;
	case 2400:
	case 205:
	{
		uchar *ch3a = 0;
		int n4a;
		basic_string<char> bs33;
		common::resources::getFile((TResultContainerList *)a3, "MRZDetector.dat", &ch3a, n4a, bs33);
		MRZDetectorProcessSingleton::obj()->setMrzDetectorDat((char*)ch3a, n4a);
		n14 = initMRZDetector((int)a5);
		return n14;
		break;
	}
	case 206:
		MRZDetectorProcessSingleton::free();
		mrz_error_corrector::MrzCorrectorInfoSingleton::free();
		return 0;
	default:
		if (a2 == 12209 || a2 == 12205)
		{
			MRZDetectorProcessSingleton::obj()->clearSeriesData();
			return 0;
		}
		return 1;
		break;
	}

	return 0;
}


struct gMRZDetectorExt_global_registrator {
	shared_ptr<MRZDetectorTh> gMRZDetectorExt;
	gMRZDetectorExt_global_registrator() {
		gMRZDetectorExt = common::getModuleOrchestrator()->addModule<MRZDetectorTh>();
	}
} gMRZDetectorExt_global_registrator_;


MRZDetectorTh::MRZDetectorTh()
{
}

MRZDetectorTh::~MRZDetectorTh()
{
}

vector<int> MRZDetectorTh::getCommands()
{
	static vector<int> v_1129AE8 = { 0xCD, 0xCE, 0x2FAD, 0x2FB1, 0x960, 0x961, 0x962, 0x963 ,0x964, 0x965, 0x966, 0x967, 0x968 };
	return v_1129AE8;
}

int MRZDetectorTh::process(int a2, void * a3, const char * a4, void ** a5, char ** a6)
{
	m_xMRZDT_4.get()->process(a2, a3, a4, a5, a6);
	return 0;
}
