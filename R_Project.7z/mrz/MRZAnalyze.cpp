#include "MRZAnalyze.h"
#include "../rclhelp.h"
#include "opencv2/imgproc.hpp"
#include "../common/container/RclHolder.h"

namespace MRZAnalyze {
	string sub_6280744C(TDocVisualExtendedInfo *a2)
	{
		string a1;
		
		if (a2)
		{
			for (int i = 0; i < a2->nDVEI_Fields; i ++)
			{
				if (a2->pDVEI_ArrayFields[i].u0.s0.wFieldType == 51)
				{
					int v7 = min(a2->pDVEI_ArrayFields[i].nDVEF_Buf_Length, 5);
					a1 = string(a2->pDVEI_ArrayFields[i].pszDVEF_Buf_Text, v7);
					break;
				}
			}
		}
		return a1;
	}

	void correctSymbolRect(tagRECT & a1)
	{
		int h = abs(a1.top - a1.bottom);
		int w = abs(a1.left - a1.right);

		if (w && h && (float)w / h < 0.7f)
		{
			float r1 = floorf((float)h * 0.7f - w);

			if (r1 >= 2.0f)
			{
				r1 = floorf(r1 * 0.5f);
				a1.left = (int)(a1.left - r1);
			}
			a1.right = (int)(a1.right + r1);
		}
	}

	void getKHLetterDigit(TDocVisualExtendedField & a1, float & a2, float a3)
	{
		a2 = a3;
		float r6 = 0.0f;
		int n4 = 0;

		for (int i = 0; i < a1.nDVEF_StringsCount; i++)
		{
			for (size_t j = 0; j + 1 < a1.pDVEF_StringsResult[i].nTSRS_SymbolsCount; j ++)
			{
				if (a1.pDVEF_StringsResult[i].pTSRS_StringResult[j].xnTSR_Candidates[0].nTSC_SymbolCode >= '0' &&
					a1.pDVEF_StringsResult[i].pTSRS_StringResult[j].xnTSR_Candidates[0].nTSC_SymbolCode <= '9' &&
					(a1.pDVEF_StringsResult[i].pTSRS_StringResult[j + 1].xnTSR_Candidates[0].nTSC_SymbolCode > '9' ||
					a1.pDVEF_StringsResult[i].pTSRS_StringResult[j + 1].xnTSR_Candidates[0].nTSC_SymbolCode < '0'))
				{
					n4++;
					r6 += (float)(a1.pDVEF_StringsResult[i].pTSRS_StringResult[j + 1].xTSR_SymbolRect.bottom - a1.pDVEF_StringsResult[i].pTSRS_StringResult[j + 1].xTSR_SymbolRect.top)
						/ (a1.pDVEF_StringsResult[i].pTSRS_StringResult[j].xTSR_SymbolRect.bottom - a1.pDVEF_StringsResult[i].pTSRS_StringResult[j].xTSR_SymbolRect.top);
				}

				if (a1.pDVEF_StringsResult[i].pTSRS_StringResult[j + 1].xnTSR_Candidates[0].nTSC_SymbolCode >= '0' &&
					a1.pDVEF_StringsResult[i].pTSRS_StringResult[j + 1].xnTSR_Candidates[0].nTSC_SymbolCode <= '9' &&
					(a1.pDVEF_StringsResult[i].pTSRS_StringResult[j].xnTSR_Candidates[0].nTSC_SymbolCode > '9' ||
					a1.pDVEF_StringsResult[i].pTSRS_StringResult[j].xnTSR_Candidates[0].nTSC_SymbolCode < '0'))
				{
					n4++;
					r6 += (float)(a1.pDVEF_StringsResult[i].pTSRS_StringResult[j].xTSR_SymbolRect.bottom - a1.pDVEF_StringsResult[i].pTSRS_StringResult[j].xTSR_SymbolRect.top)
						/ (a1.pDVEF_StringsResult[i].pTSRS_StringResult[j + 1].xTSR_SymbolRect.bottom - a1.pDVEF_StringsResult[i].pTSRS_StringResult[j + 1].xTSR_SymbolRect.top);
				}
			}
		}
		if (r6 > 2.0)
		{
			a2 = r6 / n4;
		}
	}

	void getMRZPos(TResultMRZDetector & a1, vector<cv::Point_<float>>& a2)
	{
		a2.resize(4);

		for (size_t i = 0; i < 4; i++)
		{
			a2[i].x = a1.rnRMD_boundingQuadrangle[2 * i];
			a2[i].y = a1.rnRMD_boundingQuadrangle[2 * i + 1];
		}
	}

	void getMRZPosHorBase(TDocVisualExtendedInfo & a1, vector<cv::Point_<float>>& a2)
	{
		for (int i = 0; i < a1.nDVEI_Fields; i++)
		{
			if (a1.pDVEI_ArrayFields[i].u0.s0.wFieldType == 51)
			{
				a2.resize(4);
				if (a1.pDVEI_ArrayFields[i].nDVEF_StringsCount == 1)
				{
					int n11 = a1.pDVEI_ArrayFields[i].pDVEF_StringsResult[0].nTSRS_SymbolsCount;
					TSymbolResult *p12 = a1.pDVEI_ArrayFields[i].pDVEF_StringsResult[0].pTSRS_StringResult;
					a2[0].x = (float)p12[0].xTSR_SymbolRect.left;
					a2[0].y = (float)p12[0].xTSR_SymbolRect.top;
					a2[1].x = (float)p12[n11 - 1].xTSR_SymbolRect.right;
					a2[1].y = (float)p12[n11 - 1].xTSR_SymbolRect.top;
					a2[2].x = (float)p12[n11 - 1].xTSR_SymbolRect.right;
					a2[2].y = (float)p12[n11 - 1].xTSR_SymbolRect.bottom;
					a2[3].x = (float)p12[0].xTSR_SymbolRect.left;
					a2[3].y = (float)p12[0].xTSR_SymbolRect.bottom;
				}
				else
				{
					int nfirst = a1.pDVEI_ArrayFields[i].pDVEF_StringsResult[0].nTSRS_SymbolsCount;
					TSymbolResult *pfirst = a1.pDVEI_ArrayFields[i].pDVEF_StringsResult[0].pTSRS_StringResult;
					int nlast = a1.pDVEI_ArrayFields[i].pDVEF_StringsResult[a1.pDVEI_ArrayFields[i].nDVEF_StringsCount - 1].nTSRS_SymbolsCount;
					TSymbolResult *plast = a1.pDVEI_ArrayFields[i].pDVEF_StringsResult[a1.pDVEI_ArrayFields[i].nDVEF_StringsCount - 1].pTSRS_StringResult;
					a2[0].x = (float)pfirst[0].xTSR_SymbolRect.left;
					a2[0].y = (float)pfirst[0].xTSR_SymbolRect.top;
					a2[1].x = (float)pfirst[nfirst - 1].xTSR_SymbolRect.right;
					a2[1].y = (float)pfirst[nfirst - 1].xTSR_SymbolRect.top;
					a2[2].x = (float)plast[nlast - 1].xTSR_SymbolRect.right;
					a2[2].y = (float)plast[nlast - 1].xTSR_SymbolRect.bottom;
					a2[3].x = (float)plast[0].xTSR_SymbolRect.left;
					a2[3].y = (float)plast[0].xTSR_SymbolRect.bottom;
				}
				break;
			}
		}
	}

	void getRealMRZPosHor(TDocVisualExtendedInfo & a1, vector<cv::Point_<float>>& a2)
	{
		for (int i = 0; i < a1.nDVEI_Fields; i++)
		{
			if (a1.pDVEI_ArrayFields[i].u0.s0.wFieldType == 51)
			{
				float r2a, r30, r29, r28, r27;
				getKHLetterDigit(a1.pDVEI_ArrayFields[i], r2a, 0.95f);
				getWHParamLeft(a1.pDVEI_ArrayFields[i], r30, r29, r2a, 4);
				getWHParamRight(a1.pDVEI_ArrayFields[i], r28, r27, r2a, 4);

				a2.resize(4);

				if (a1.pDVEI_ArrayFields[i].nDVEF_StringsCount == 1)
				{
					int n8 = a1.pDVEI_ArrayFields[i].pDVEF_StringsResult[0].nTSRS_SymbolsCount;
					TSymbolResult *p9 = a1.pDVEI_ArrayFields[i].pDVEF_StringsResult[0].pTSRS_StringResult;
					a2[0].x = (p9[0].xTSR_SymbolRect.left + p9[0].xTSR_SymbolRect.right) * 0.5f - r30 * 0.5f;
					a2[0].y = p9[0].xTSR_SymbolRect.bottom - r29;
					a2[1].x = (p9[n8 - 1].xTSR_SymbolRect.left + p9[n8 - 1].xTSR_SymbolRect.right) * 0.5f + r28 * 0.5f;
					a2[1].y = p9[n8 - 1].xTSR_SymbolRect.bottom - r27;
					a2[2].x = a2[1].x;
					a2[2].y = (float)p9[n8 - 1].xTSR_SymbolRect.bottom;
					a2[3].x = a2[0].x;
					a2[3].y = (float)p9[0].xTSR_SymbolRect.bottom;
				}
				else
				{
					int nfirst = a1.pDVEI_ArrayFields[i].pDVEF_StringsResult[0].nTSRS_SymbolsCount;
					TSymbolResult *pfirst = a1.pDVEI_ArrayFields[i].pDVEF_StringsResult[0].pTSRS_StringResult;
					int nlast = a1.pDVEI_ArrayFields[i].pDVEF_StringsResult[a1.pDVEI_ArrayFields[i].nDVEF_StringsCount - 1].nTSRS_SymbolsCount;
					TSymbolResult *plast = a1.pDVEI_ArrayFields[i].pDVEF_StringsResult[a1.pDVEI_ArrayFields[i].nDVEF_StringsCount - 1].pTSRS_StringResult;
					a2[0].x = (pfirst[0].xTSR_SymbolRect.left + pfirst[0].xTSR_SymbolRect.right) * 0.5f - r30 * 0.5f;
					a2[0].y = pfirst[0].xTSR_SymbolRect.bottom - r29;
					a2[1].x = (pfirst[nfirst - 1].xTSR_SymbolRect.left + pfirst[nfirst - 1].xTSR_SymbolRect.right) * 0.5f + r28 * 0.5f;
					a2[1].y = pfirst[nfirst - 1].xTSR_SymbolRect.bottom - r27;
					a2[2].x = (plast[nlast - 1].xTSR_SymbolRect.left + plast[nlast - 1].xTSR_SymbolRect.right) * 0.5f + r28 * 0.5f;
					a2[2].y = (float)plast[nlast - 1].xTSR_SymbolRect.bottom;
					a2[3].x = (plast[0].xTSR_SymbolRect.left + plast[0].xTSR_SymbolRect.right) * 0.5f - r30 * 0.5f;
					a2[3].y = (float)plast[0].xTSR_SymbolRect.bottom;
				}
				break;
			}
		}
	}

	void getWHParamLeft(TDocVisualExtendedField & a1, float & a2, float & a3, float & a4, int a5)
	{
		a2 = a3 = 0.0f;

		if (a1.nDVEF_StringsCount)
		{
			float r8 = 0.0f;
			int n9 = 0;
			float r12 = 0.0f;
			int n15 = 0;

			for (uint i = 0; i < a1.pDVEF_StringsResult[0].nTSRS_SymbolsCount && n9 < a5; i++)
			{
				int j;
				for (j = 0; j < a1.nDVEF_StringsCount && n9 < a5; j++)
				{
					uint n19 = a1.pDVEF_StringsResult[j].pTSRS_StringResult[i].xnTSR_Candidates[0].nTSC_SymbolCode;
					float r21 = (float)(a1.pDVEF_StringsResult[j].pTSRS_StringResult[i].xTSR_SymbolRect.bottom - a1.pDVEF_StringsResult[j].pTSRS_StringResult[i].xTSR_SymbolRect.top);
					if (n19 >= '0' && n19 <= '9')
					{
						r21 *= a4;
					}
					if (n19 != '1' && n19 != 'F' && n19 != 'I')
					{
						n9++;
						r8 += (a1.pDVEF_StringsResult[j].pTSRS_StringResult[i].xTSR_SymbolRect.right - a1.pDVEF_StringsResult[j].pTSRS_StringResult[i].xTSR_SymbolRect.left);
					}
					r12 += r21;
				}
				n15 += j;
			}

			if (n15)
			{
				a3 = r12 / n15;
			}
			if (n9)
			{
				a2 = r8 / n9;
			}
		}
	}

	void getWHParamRight(TDocVisualExtendedField & a1, float & a2, float & a3, float & a4, int a5)
	{
		a2 = a3 = 0.0f;

		if (a1.nDVEF_StringsCount)
		{
			float r8 = 0.0f;
			int n9 = 0;
			float r10 = 0.0f;
			int n13 = 0;

			for (int i = (int)a1.pDVEF_StringsResult[0].nTSRS_SymbolsCount - 1; i > 0 ; i--)
			{
				int j;
				for (j = 0; j < a1.nDVEF_StringsCount; j++)
				{
					int n17 = a1.pDVEF_StringsResult[j].pTSRS_StringResult[i].xnTSR_Candidates[0].nTSC_SymbolCode;
					float r19 = (float)(a1.pDVEF_StringsResult[j].pTSRS_StringResult[i].xTSR_SymbolRect.bottom - a1.pDVEF_StringsResult[j].pTSRS_StringResult[i].xTSR_SymbolRect.top);
					if (n17 >= '0' && n17 <= '9')
					{
						r19 *= a4;
					}
					if (n17 != '1' && n17 != 'F' && n17 == 'I')
					{
						n9++;
						r8 += (a1.pDVEF_StringsResult[j].pTSRS_StringResult[i].xTSR_SymbolRect.right - a1.pDVEF_StringsResult[j].pTSRS_StringResult[i].xTSR_SymbolRect.left);
					}
					r10 += r19;
					if (n9 >= a5) break;
				}
				n13 += j;
				if (n9 >= a5) break;
			}

			if (n13)
			{
				a3 = r10 / n13;
			}
			if (n9)
			{
				a2 = r8 / n9;
			}
		}
	}

	void getRealPos(vector<cv::Point2f> &a1, vector<cv::Point2f> &a2, vector<cv::Point2f> &a3, vector<cv::Point2f> &a4)
	{
		cv::Mat v11 = cv::getPerspectiveTransform(a1, a2);
		a4.resize(4);
		cv::perspectiveTransform(a3, a4, v11);
	}

	vector<cv::Point2f> getRealMRZPos(TResultMRZDetector *a1, TDocVisualExtendedInfo *a2)
	{
		vector<cv::Point2f> vRet;

		vector<cv::Point2f> v6;
		vector<cv::Point2f> a1a;
		vector<cv::Point2f> a2a;

		getMRZPos(*a1, a2a);
		getMRZPosHorBase(*a2, a1a);
		getRealMRZPosHor(*a2, v6);
		getRealPos(a1a, a2a, v6, vRet);

		return vRet;
	}

	bool isVisaID2(TResultContainerList &a1)
	{
		TResultContainer *v2;
		TResultContainer *v3;
		bool result;
		TDocVisualExtendedInfo *v5;
		int v6;
		TDocVisualExtendedField *v8;

		v2 = rclhelp::findFirstContainer(a1, 87);
		v3 = rclhelp::findFirstContainer(a1, 3);
		result = 0;
		if (v2 && v3)
		{
			if (v2->u.pTRC_DVEI)
			{
				v5 = v3->u.pTRC_DVEI;
				if (v5)
				{
					v6 = 0;
					while (v6 < v5->nDVEI_Fields)
					{
						v8 = v5->pDVEI_ArrayFields;

						if (v5->pDVEI_ArrayFields[v6].u0.nDVEF_FieldType == 51)
						{
							if (v5->pDVEI_ArrayFields[v6].nDVEF_Reserved2 == 29)
								result = 1;
							else
								result = (v5->pDVEI_ArrayFields[v6].pszDVEF_Buf_Text[0] == 'V');
							break;
						}
						v6++;
					}
				}
			}
		}
		return result;
	}

	bool isBGRVisa(TResultContainerList &a1)
	{
		TResultContainer *v1 = rclhelp::findFirstContainer(a1, 3);
		if (!v1 || !v1->u.pTRC_DVEI)
			return false;
		
		string v10 = sub_6280744C(v1->u.pTRC_DVEI);

		if (v10 == "VRGBR" || v10 == "VDGBR")
			return 1;
		
		return 0;
	}

	bool isArgId(TResultContainerList &a1)
	{
		TResultContainer *v1 = rclhelp::findFirstContainer(a1, 3);
		if (!v1 || !v1->u.pTRC_DVEI)
			return false;
		
		string v6 = sub_6280744C(v1->u.pTRC_DVEI);
		if (v6 == "IDARG")
			return true;
				
		return false;
	}

	bool isEcuId(TResultContainerList &a1)
	{
		TResultContainer *v1 = rclhelp::findFirstContainer(a1, 3);
		if (!v1 || !v1->u.pTRC_DVEI)
			return false;
		
		string v6 = sub_6280744C(v1->u.pTRC_DVEI);
		if (v6 == "IDECU")
			return true;
	
		return false;
	}

	int MRZAnalyze::getRealMRZLineH(TDocVisualExtendedInfo &a1, float &a2, float &a3)
	{
		a2 = 0.0f;
		a3 = 0.0f;
		for (int i = 0; i < a1.nDVEI_Fields; i ++)
		{
			if (a1.pDVEI_ArrayFields[i].u0.s0.wFieldType == 51)
			{
				int v8 = 0;
				float v7 = 0.0f;
				for (int j = 0; j < a1.pDVEI_ArrayFields[i].nDVEF_StringsCount; j ++)
				{
					TStringResultSDK *v10 = &a1.pDVEI_ArrayFields[i].pDVEF_StringsResult[j];
					for (uint k = 0; k < v10->nTSRS_SymbolsCount; k++)
					{
						v7 += (v10->pTSRS_StringResult[k].xTSR_SymbolRect.bottom - v10->pTSRS_StringResult[k].xTSR_SymbolRect.top);
					}
					v8 += v10->nTSRS_SymbolsCount;
				}
				if (v8)
					a2 = v7 / v8;
				v7 = 0.0;
				v8 = 0;
				for (int j = 0; j < a1.pDVEI_ArrayFields[i].nDVEF_StringsCount - 1; j ++)
				{
					TStringResultSDK *v22 = &a1.pDVEI_ArrayFields[i].pDVEF_StringsResult[j];
					uint k;
					for (k = 0; k < v22->nTSRS_SymbolsCount && k < v22[1].nTSRS_SymbolsCount; k ++)
					{
						v7 += (float)(v22[1].pTSRS_StringResult[k].xTSR_SymbolRect.top - v22->pTSRS_StringResult[k].xTSR_SymbolRect.bottom);
					}
					v8 += k;
				}
				if (v8)
					a3 = v7 / v8;
				break;
			}
		}
		return 0;
	}

	int MRZAnalyze::getIDParam(int a1, float a2, vector<cv::Point2f> &a3)
	{
		float v6, v7, v8;
		a3.resize(4);
		if (a1 == 0 || a1 == 1 || a1 == 2 || a1 == 1000)
		{
			if (a1 == 0 || a1 == 1000)
			{
				v6 = 54.0f;
				v7 = 54.0f - (a2 * 54.0f) * 0.5f;
				v8 = 85.6f;
			}
			else if(a1 == 1)
			{
				v6 = 74.0f;
				v7 = 74.0f - (a2 * 74.0f) * 0.5f;
				v8 = 105.0f;
			}
			else if (a1 == 2)
			{
				v6 = 88.0f;
				v7 = 88.0f - (a2 * 88.0f) * 0.5f;
				v8 = 125.0f;
			}
			a3[0] = Point2f(v7, v6 - v7);
			a3[1] = Point2f(v7, v7);
			a3[2] = Point2f(v8 - v7, v7);
			a3[3] = Point2f(v8 - v7, v6 - v7);
		}
		return 0;
	}

	int MRZAnalyze::getIDParam(int a1, float a2, float a3, vector<cv::Point2f> &a4, vector<cv::Point2f> &a5)
	{
		a4.resize(4);
		a5.resize(4);
		float v10, v11, v13, v14, v18;
		if (a1 == 0)
		{
			a5[0] = Point2f(0.0f, 54.0f);
			a5[1] = Point2f(85.6f, 54.0f);
			a5[2] = Point2f(85.6f, 0.0f);
			a5[3] = Point2f(0.0f, 0.0f);
			v10 = 81.65f;
			v11 = 5.08f / (a2 / a3) + 7.62f;
			v13 = 3.95f;
			v14 = 11.5f - (v11 * 0.5f);
			v18 = v11 + v14;
			a4[0] = Point2f(v13, v18);
			a4[1] = Point2f(v10, v18);
			a4[2] = Point2f(v10, v14);
			a4[3] = Point2f(v13, v14);
		}
		else if (a1 == 1)
		{
			a5[0] = Point2f(0.0f, 74.0f);
			a5[1] = Point2f(105.0f, 74.0f);
			a5[2] = Point2f(105.0f, 0.0f);
			a5[3] = Point2f(0.0f, 0.0f);
			v10 = 99.15f;
			v11 = 2.54f / (a2 / a3) + 5.08f;
			v14 = 12.575f - (v11 * 0.5f);
			v13 = 5.85f;
			v18 = v11 + v14;
			a4[0] = Point2f(v13, v18);
			a4[1] = Point2f(v10, v18);
			a4[2] = Point2f(v10, v14);
			a4[3] = Point2f(v13, v14);
		}
		else if (a1 == 2)
		{
			a5[0] = Point2f(0.0f, 88.0f);
			a5[1] = Point2f(125.0f, 88.0f);
			a5[2] = Point2f(125.0f, 0.0f);
			a5[3] = Point2f(0.0f, 0.0f);
			v11 = 2.54f / (a2 / a3) + 5.08f;
			v14 = 12.575f - (v11 * 0.5f);
			v18 = v11 + v14;
			v13 = 5.5f;
			v10 = 119.5f;
			a4[0] = Point2f(v13, v18);
			a4[1] = Point2f(v10, v18);
			a4[2] = Point2f(v10, v14);
			a4[3] = Point2f(v13, v14);
		}
		else if (a1 == 5)
		{
			a5[0] = Point2f(0.0f, 176.0f);
			a5[1] = Point2f(125.0f, 176.0f);
			a5[2] = Point2f(125.0f, 0.0f);
			a5[3] = Point2f(0.0f, 0.0f);
			v11 = 2.54f / (a2 / a3) + 5.08f;
			v14 = 12.575f - (v11 * 0.5f);
			v18 = v11 + v14;
			v13 = 5.5f;
			v10 = 119.5f;
			a4[0] = Point2f(v13, v18);
			a4[1] = Point2f(v10, v18);
			a4[2] = Point2f(v10, v14);
			a4[3] = Point2f(v13, v14);
		}
		else if (a1 == 1000)
		{
			a5[0] = Point2f(0.0f, 54.0f);
			a5[1] = Point2f(85.6f, 54.0f);
			a5[2] = Point2f(85.6f, 0.0f);
			a5[3] = Point2f(0.0f, 0.0f);
			a4[0] = Point2f(3.95f, 8.745f);
			a4[1] = Point2f(81.65f, 8.745f);
			a4[2] = Point2f(81.65f, 5.795f);
			a4[3] = Point2f(3.95f, 5.795f);
		}

		return 0;
	}

	int getRealDocPos(TResultContainerList &a1, vector<MrzCornerResult>& a2, int &a3)
	{
		vector<cv::Point_<float>> vPr_18, vPr_24;
		return getRealDocPos(a1, vPr_18, vPr_24, a2, a3);
	}

	int getRealDocPos(TResultContainerList &a1, vector<cv::Point2f> &a2, vector<cv::Point2f> &a3, vector<MrzCornerResult> &a4)
	{
		int a5 = 0;
		return getRealDocPos(a1, a2, a3, a4, a5);
	}

	int getRealDocPos(TResultContainerList &a1, vector<cv::Point2f> &a2, vector<cv::Point2f> &a3, vector<MrzCornerResult> &a4, int &a5)
	{
		common::container::RclHolder rcl_34;
		rcl_34.addNoCopy(a1);
		TResultContainer * trc1 = rclhelp::findFirstContainer(a1, 87);
		TResultContainer * trc2 = rclhelp::findFirstContainer(a1, 3);
		int nRet = 2;

		if (trc1 && trc2)
		{
			nRet = 3;
			TResultMRZDetector * trmd = trc1->u.pTRC_RMD;
			TDocVisualExtendedInfo * tdvei = trc2->u.pTRC_DVEI;
			if (trmd && tdvei)
			{
				vector<cv::Point_<int>> vPInt_40;
				vector<cv::Point_<float>> vPInt_4C;
				vPInt_40.resize(4, cv::Point_<int>(0, 0));
				vPInt_4C = getRealMRZPos(trmd, tdvei);
				a3 = vPInt_4C;

				float r_50, r_54;
				getRealMRZLineH(*tdvei, r_50, r_54);

				int r0 = 0;
				if (trmd->nRMD_MRZFormat)
					r0 = trmd->nRMD_MRZFormat;
				else if (trmd->nRMD_MRZRowsNum == 1)
					r0 = 1000;

				vector<cv::Point_<float>> vPR_60;
				getIDParam(r0, r_50, r_54, a2, vPR_60);

				a4.resize(1);
				a4[0].m_nMCR_DocForamt = (CDocFormat)trmd->nRMD_MRZFormat;
				getRealPos(a2, vPInt_4C, vPR_60, a4[0].m_vMrzCorner_field_0);

				float r_s2 = sqrt((vPInt_4C[1].y - vPInt_4C[0].y) * (vPInt_4C[1].y - vPInt_4C[0].y) + (vPInt_4C[1].x - vPInt_4C[0].x) * (vPInt_4C[1].x - vPInt_4C[0].x));
				a5 = (int)(r_s2 * 1000.0f / (a2[1].x - a2[0].x));

				if (trmd->nRMD_MRZFormat == 2)
				{
					a4.resize(2);
					vector<cv::Point_<float>> vPR_6C, vPR_78;
					getIDParam(5, r_50, r_54, vPR_6C, vPR_78);
					a4[1].m_nMCR_DocForamt = DOCFORMAT_5;
					getRealPos(vPR_6C, vPInt_4C, vPR_78, a4[1].m_vMrzCorner_field_0);
				}
				nRet = 0;
			}
		}

		return nRet;
	}

	int getBoundaryArea(vector<cv::Point2f> &a1, vector<cv::Point2f> &a2, int a3, float a4, float a5, vector<cv::Point2f> &a6)
	{
		vector<cv::Point2f> v16, v15, v14;
		getIDParam(a3, a4, v16);
		getIDParam(a3, a5, v15);
		v14.resize(4);
		v14[0] = v15[0];
		v14[1] = v16[1];
		v14[2] = v16[2];
		v14[3] = v15[3];
		getRealPos(a1, a2, v14, a6);
		return 0;
	}

	int getMrzInfo(TResultContainerList &a1, int &a2, int &a3, int &a4)
	{
		TResultContainer *v7 = rclhelp::findFirstContainer(a1, 0x57);
		if (!v7)
			return 0;
		TResultMRZDetector *v8 = v7->u.pTRC_RMD;
		if (!v8)
			return 0;
		a2 = v8->nRMD_MRZFormat;
		a3 = v8->nRMD_MRZRowsNum;
		if (v8->nRMD_MRZRowsNum >= 1)
			a4 = v8->xnRMD_MRZRows[0].nSR_length;
		return 1;
	}

	int resolutionFromMrzWidth(CDocFormat a1, int a2)
	{
		int result = 0;
		double dbl_63372880[3] = { 77.6999969, 93.3000031, 114.0 };

		if (a2 >= 1 && a1 <= 2)
			result = (int)(a2 / dbl_63372880[a1] * 1000.0);
		return result;
	}

	bool pageIndexUsual(TResultMRZDetector *a1, bool &a2)
	{
		bool ret = false;
		if (a1)
		{
			if (a1->nRMD_MRZFormat == 2)
				a2 = true;
			else if (a1->nRMD_MRZFormat == 0 && a1->nRMD_MRZRowsNum != 1)
				ret = true;
		}
		return ret;
	}

	MrzCornerResult::MrzCornerResult(MrzCornerResult const&a1)
	{
		m_vMrzCorner_field_0 = a1.m_vMrzCorner_field_0;
		m_nMCR_DocForamt = a1.m_nMCR_DocForamt;
	}

	MrzCornerResult::MrzCornerResult(MrzCornerResult &&a1)
	{
		m_vMrzCorner_field_0 = move(a1.m_vMrzCorner_field_0);
		m_nMCR_DocForamt = a1.m_nMCR_DocForamt;
	}
}

