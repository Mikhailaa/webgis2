#pragma once
#include "../commonStruct.h"

namespace MRZAnalyze
{
	class MrzCornerResult
	{
	public:
		MrzCornerResult() { m_nMCR_DocForamt = DOCFORMAT_0; };
		~MrzCornerResult() {};
		MrzCornerResult(MrzCornerResult const&);
		MrzCornerResult(MrzCornerResult &&);
		vector<Point2f> m_vMrzCorner_field_0;
		CDocFormat m_nMCR_DocForamt;
	};

	void correctSymbolRect(tagRECT &);
	void getKHLetterDigit(TDocVisualExtendedField &, float &, float);
	
	void getMRZPos(TResultMRZDetector &, vector<cv::Point_<float>> &);
	void getMRZPosHorBase(TDocVisualExtendedInfo &, vector<cv::Point_<float>> &);
	void getRealMRZPosHor(TDocVisualExtendedInfo &, vector<cv::Point_<float>> &);
	void getWHParamLeft(TDocVisualExtendedField &, float &, float &, float &, int);
	void getWHParamRight(TDocVisualExtendedField &, float &, float &, float &, int);

	int getIDParam(int, float, vector<cv::Point2f> &);
	int getIDParam(int a1, float a2, float a3, vector<cv::Point2f> &a4, vector<cv::Point2f> &a5);
	int getRealMRZLineH(TDocVisualExtendedInfo &a1, float &a2, float &a3);
	void getRealPos(vector<cv::Point2f> &a1, vector<cv::Point2f> &a2, vector<cv::Point2f> &a3, vector<cv::Point2f> &a4);
	vector<cv::Point2f> getRealMRZPos(TResultMRZDetector *, TDocVisualExtendedInfo *);

	bool isVisaID2(TResultContainerList &a1);
	bool isBGRVisa(TResultContainerList &a1);
	bool isArgId(TResultContainerList &a1);
	bool isEcuId(TResultContainerList &a1);

	int getRealDocPos(TResultContainerList &, vector<MrzCornerResult>&, int &);
	int getRealDocPos(TResultContainerList &a1, vector<cv::Point2f> &a2, vector<cv::Point2f> &a3, vector<MrzCornerResult> &a4);
	int getRealDocPos(TResultContainerList &a1, vector<cv::Point2f> &a2, vector<cv::Point2f> &a3, vector<MrzCornerResult> &a4, int &a5);

	int getBoundaryArea(vector<cv::Point2f> &a1, vector<cv::Point2f> &a2, int a3, float r3_0, float a5, vector<cv::Point2f> &a4);
	int getMrzInfo(TResultContainerList &a1, int &a2, int &a3, int &a4);

	int resolutionFromMrzWidth(CDocFormat a1, signed int a2);
	bool pageIndexUsual(TResultMRZDetector *, bool &);

}