#pragma once
#include "mrz_error_corrector.h"

namespace mrz_error_corrector
{
	class CHypothesesLine;

	class CMaskCorrector : public AbstractFieldCorrector
	{
	public:
		basic_string<char>                  m_bsCMC_4;
		vector<shared_ptr<IFieldCorrector const>> m_vCMC_10;
	public:
		CMaskCorrector(basic_string<char> const&, vector<shared_ptr<IFieldCorrector const>> const&);
		~CMaskCorrector();

		basic_string<char> correct(CHypothesesLine const&) const;
		basic_string<char> getMask(void) const;
		bool isValid(basic_string<char> const&) const;


		class FieldPart
		{
		public:
			shared_ptr<IFieldCorrector const> m_spFP_0;
			CHypothesesLine                   m_xFP_8;
			basic_string<char>                m_bsFP_14;
		public:
			FieldPart();
			FieldPart(FieldPart const&);
			FieldPart(FieldPart&&);
			~FieldPart();

			FieldPart & operator=(FieldPart&&);
		};

		vector<FieldPart> getFieldParts(CHypothesesLine const&, basic_string<char> const&) const;

	};
}