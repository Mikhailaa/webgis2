#pragma once
#include "mrz_error_corrector.h"

namespace mrz_error_corrector
{
	class CDigitCorrector : public AbstractFieldCorrector
	{
	public:
		uint m_nCDC_4;
	public:
		CDigitCorrector(uint);
		~CDigitCorrector();

		basic_string<char> correct(CHypothesesLine const&) const;
		basic_string<char> getMask(void) const;
		bool isValid(basic_string<char> const&) const;
	};

	class CDigitOrFillerCorrector : public AbstractFieldCorrector
	{
	public:
		uint m_nCDOFC_4;
	public:
		CDigitOrFillerCorrector(uint);
		~CDigitOrFillerCorrector();

		basic_string<char> correct(CHypothesesLine const&) const;
		basic_string<char> getMask(void) const;
		bool isValid(basic_string<char> const&) const;
	};
}
