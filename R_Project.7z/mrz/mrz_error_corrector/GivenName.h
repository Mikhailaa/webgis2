#pragma once
#include "../../pch.h"

class SurnameGivenName
{
public:
	SurnameGivenName(SurnameGivenName && a1);
	SurnameGivenName();
	~SurnameGivenName();

public:
	string m_strSG_0;
	string m_strSG_C;
};

class GivenNameFathersName
{
public:
	GivenNameFathersName(GivenNameFathersName && a1);
	GivenNameFathersName();
	~GivenNameFathersName();

public:
	string m_strGNFN_0;
	string m_strGNFN_C;
};