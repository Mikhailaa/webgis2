#pragma once
#include "../../pch.h"
#include "CParsedMrz.h"
#include "../../commonStruct.h"

using namespace mrz_error_corrector;

namespace mrz_error_corrector
{
	class CDocVisualExtendedFieldsGenerator
	{
	public:
		CDocVisualExtendedFieldsGenerator();
		CDocVisualExtendedFieldsGenerator(CParsedMrz const&);
		void addParsedFields(TDocVisualExtendedInfo &);
		int calcValidityForFtMrzStrings(TDocVisualExtendedInfo &, int &);
		void correctftMrzStrings(TDocVisualExtendedInfo &, string);
		static TDocVisualExtendedField* expandContainer(TDocVisualExtendedInfo &, uint);
		string fieldTypeToString(sFieldType);
		void fillDocVisualExtendedField(sParsedMrzField, TDocVisualExtendedField &, bool);
		void fillSymbolsRecognitionResult(sParsedMrzField, TDocVisualExtendedField &, TDocVisualExtendedInfo &, int);
		void fixMaskAndTextLength(TDocVisualExtendedInfo &);
		void generateDefaultMasks(TDocVisualExtendedInfo &);
		uint getStringsCount(string const&);
		string removeFillers(string, sFieldType);
		void rewriteCandidates(TDocVisualExtendedInfo &);
		static void setStringResult(string const&, int, TStringResultSDK *);
		void setValidity(sParsedMrzField, TDocVisualExtendedField &);

		CParsedMrz *m_pParseMrz_0;
	};
}