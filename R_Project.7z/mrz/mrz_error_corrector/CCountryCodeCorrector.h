#pragma once
#include "mrz_error_corrector.h"

namespace mrz_error_corrector
{
	class CountryCodeHelper;

	class CCountryCodeCorrector : public AbstractFieldCorrector
	{
	public:
		CountryCodeHelper const * m_pCCCC_4;
	public:
		CCountryCodeCorrector(CountryCodeHelper const&);
		~CCountryCodeCorrector();

		basic_string<char> correct(CHypothesesLine const&) const;
		basic_string<char> getMask(void) const;
		bool isValid(basic_string<char> const&) const;
	};
}