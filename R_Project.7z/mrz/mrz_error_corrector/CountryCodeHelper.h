#pragma once

#include "../../pch.h"
#include <array>

namespace mrz_error_corrector
{
	class CountryCodeHelper
	{
	public:
		bool IsCountryCodeExist(array<char, 4u> const&) const;
		bool IsCountryCodeExist(basic_string<char> const&) const;
		basic_string<char> getCountryName(array<char, 4u> const&);
	};
}