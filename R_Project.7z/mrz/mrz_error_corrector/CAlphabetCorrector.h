#pragma once
#include "mrz_error_corrector.h"

namespace mrz_error_corrector
{
	class CAlphabetCorrector : public AbstractFieldCorrector
	{
	public:
		uint               m_nCAC_4;
		basic_string<char> m_bsCAC_8;
	public:
		CAlphabetCorrector(uint, basic_string<char> const&);
		~CAlphabetCorrector();

		basic_string<char> correct(CHypothesesLine const&) const;
		basic_string<char> getMask(void) const;
		bool isValid(basic_string<char> const&) const;
	};
}
