#pragma once
#include "mrz_error_corrector.h"

namespace mrz_error_corrector
{
	class COneOfListCorrector : public AbstractFieldCorrector
	{
	public:
		set<basic_string<char>> m_sCOOLC_4;
	public:
		COneOfListCorrector(set<basic_string<char>> const&);
		~COneOfListCorrector();

		basic_string<char> correct(CHypothesesLine const&) const;
		basic_string<char> getMask(void) const;
		bool isValid(basic_string<char> const&) const;
	};
}
