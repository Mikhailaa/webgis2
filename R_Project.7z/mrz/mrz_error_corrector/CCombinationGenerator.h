#pragma once
#include "../../pch.h"
#include "CHypotheses.h"

using namespace mrz_error_corrector;

namespace mrz_error_corrector
{
	class CCombinationGenerator 
	{
	public:
		CCombinationGenerator();
		~CCombinationGenerator();
		CCombinationGenerator(CHypothesesLine const&);
		void changeState();
		string generateCurrentCombination(double &);
		string generateFirst(double &);
		string generateNext(double &);
		uint getCombinationsCount();
		bool isFinished();
		void resetState();


		vector<CHypotheses> m_vCHypoth_0;
		vector<uint> m_vuint_C;
	};
}
