#pragma once
#include "../../pch.h"
#include "../../commonStruct.h"
//#include "imseg/RecognizedTextDoc.h"
#include "CHypotheses.h"
#include "GivenName.h"
#include "CRecognizedMrz.h"
#include "document.h"
#include "CountryCodeHelper.h"

using namespace rapidjson;

namespace mrz_error_corrector
{
	enum eMrzFormatSizeExt
	{
		eMrzFormatSizeExt_0,
		eMrzFormatSizeExt_1,
		eMrzFormatSizeExt_2,
		eMrzFormatSizeExt_3,
		eMrzFormatSizeExt_4,
		eMrzFormatSizeExt_5,
		eMrzFormatSizeExt_6,
		eMrzFormatSizeExt_7,
		eMrzFormatSizeExt_8,
	};

	enum eMrzFormatSize
	{
		eMrzFormatSize_Unknown = -1,
		eMrzFormatSize_0 = 0,
		eMrzFormatSize_1 = 1,
		eMrzFormatSize_2 = 2,
		eMrzFormatSize_3 = 3,
	};

	enum sFieldType
	{
		sFieldType_0 = 0,
		sFieldType_1 = 1,
		sFieldType_2 = 2,
		sFieldType_3 = 3,
		sFieldType_4 = 4,
		sFieldType_5 = 5,
		sFieldType_7 = 7,
		sFieldType_8 = 8,
		sFieldType_9 = 9,
		sFieldType_12 = 12,
		sFieldType_25 = 25,
		sFieldType_26 = 26,
		sFieldType_35 = 35,
		sFieldType_36 = 36,
		sFieldType_51 = 51,
		sFieldType_80 = 80,
		sFieldType_81 = 81,
		sFieldType_82 = 82,
		sFieldType_84 = 84,
		sFieldType_100 = 100,
		sFieldType_129 = 129,
		sFieldType_142 = 142,
		sFieldType_172 = 172,
		sFieldType_193 = 193,
		sFieldType_288 = 288,
		sFieldType_289 = 289,
		sFieldType_292 = 292,
		sFieldType_464 = 464,
		sFieldType_68747272 = 0x4190008,
		sFieldType_68747273 = 0x4190009,
		sFieldType_68747289 = 0x4190019,
		sFieldType_68747393 = 0x4190081,
	};

	class sParsedMrzField;
	class CParsedMrz;
	class sMrzFormatDescription;

	class IChecksumCorrector
	{
	public:
		virtual ~IChecksumCorrector() {};

		virtual map<sFieldType, sParsedMrzField> correct(CParsedMrz const&) = 0;
		virtual bool isValid(CParsedMrz const&) = 0;
		virtual unsigned int getChecksum(CParsedMrz const&) = 0;
		virtual unsigned int getChecksum(basic_string<char> const&) = 0;
		virtual sFieldType getChecksumFieldType(void) = 0;
		virtual vector<sFieldType> & getFieldTypes(void) = 0;
		virtual shared_ptr<IChecksumCorrector> clone(sFieldType, vector<sFieldType> const&) = 0;
	};

	class IFieldCorrector
	{
	public:
		virtual ~IFieldCorrector() {};
		virtual basic_string<char> correct(CHypothesesLine const&) const = 0;
		virtual bool isValid(basic_string<char> const&) const = 0;
		virtual basic_string<char> getMask(void) const = 0;
	};

	class AbstractChecksumCorrector : public IChecksumCorrector
	{
	public:
		sFieldType         m_eACC_4;
		vector<sFieldType> m_vACC_8;

		AbstractChecksumCorrector(sFieldType, vector<sFieldType> const&);
		~AbstractChecksumCorrector();
		sFieldType getChecksumFieldType(void);
		vector<sFieldType> & getFieldTypes(void);
	};

	class AbstractFieldCorrector : public IFieldCorrector
	{
	public:
		basic_string<char> getResult(basic_string<char> const&, CHypothesesLine const&) const;
	};

	class IssuingStateCodeDescr
	{
	public:
		map<string, vector<sMrzFormatDescription *>> m_mapISCD_0;
	};

	string getParsedMrzJson(TDocVisualExtendedInfo *);
	string getParsedMrzXml(TDocVisualExtendedInfo *);

	eMrzFormatSize stringToMrzFormatSize(string const & a1);
	GivenNameFathersName splitGivenNameFathersName(string a1);
	SurnameGivenName splitSurnameGivenName(string a1);
	vector<string> split(string const & a1, char a2);
	sFieldType stringToFieldType(string const & a1);

	string addLineDelims(string const & a1);
	string ANY_COUNTRY();
	string DIGITS();
	string fieldTypeToString(sFieldType);
	string LETTERS();
	string mrzFormatSizeToString(eMrzFormatSize a1);
	string NO_COUNTRY();
	string normolizeSpaces(string const & a1);
	string numberToString(int a1);
	string removeLineDelims(string const & a1);
	string removeFillers(string const & a1);
	string replace(string a1, string const & a2, string const& a3);
	string replaceAll(string const & a1, string const & a2, string const& a3);
	void TDocVisualExtendedInfoDeleter(TDocVisualExtendedInfo *);
	string translateCodesRusVisaIdToRus(string a1);
	string translateToChina(string const & a1);
	string translateToRus(string const & a1);
	string trim(string const & a1);
	string SEX_VALUES();
	string UNSUPPORTED_FORMAT();
	
	bool check_Conformity_Checksum(string a1, int a2, int a3);
	int check_Conformity_Date(string a1);
	bool CorrectAndParseMrz(CRecognizedMrz const&, TDocVisualExtendedInfo *, string &, string const&);
	unique_ptr<TDocVisualExtendedInfo, void(*)(TDocVisualExtendedInfo*)> CorrectAndParseMrz(string const&);
	bool CorrectAndParseMrz(TDocVisualExtendedInfo *);
	shared_ptr<IFieldCorrector const> createFieldCorrector(string &, unsigned int);
	shared_ptr<IFieldCorrector const> createFieldCorrector(GenericValue<UTF8<char>> const &, unsigned int);
	shared_ptr<IChecksumCorrector> createChecksumCorrector(GenericValue<UTF8<char>> const &, sFieldType);
	unique_ptr<TDocVisualExtendedInfo, void(*)(TDocVisualExtendedInfo*)> CorrectAndParseMrz(string const&, string, string const&);
	eMrzFormatSizeExt determineMrzFormatSizeExt(unsigned int, unsigned int);

	vector<sMrzFormatDescription> getMrzDescriptions(string const &);

	bool isDigit(char a1);
	bool isDigit(string const & a1);
	bool isFiller(string const & a1);
	bool isLetter(char a1);
	bool isLetter(string const & a1);
	bool isLetterOrFiller(string const & a1);
	bool hasCodesRusVisaId(string const&);
	/*bool operator<(sFieldType const & a1, sFieldType const & a2);*/
	
	string replace(string a1, string const & a2, string const & a3);
	string replaceAll(string const & a1, string const & a2, string const & a3);

	CParsedMrz* parse(CRecognizedMrz const&, vector<sMrzFormatDescription> const&, map<eMrzFormatSizeExt, vector<sMrzFormatDescription*>> const&, map<eMrzFormatSizeExt, IssuingStateCodeDescr> const&, CountryCodeHelper const&, bool &);

	class sMrzFieldDescription
	{
	public:
		typedef struct _sLocation
		{
			int nsLoc_0;
			int nField_4;
			int nField_8;
		} sLocation;

	public:
		sMrzFieldDescription();
		sMrzFieldDescription(sMrzFieldDescription const &);
		sMrzFieldDescription(sMrzFieldDescription &&);
		sMrzFieldDescription & operator=(sMrzFieldDescription const &);
		sMrzFieldDescription & operator=(sMrzFieldDescription &&);
		~sMrzFieldDescription() {};

	public:
		sFieldType m_eMFLD_type_0;
		string m_strMFLD_4;
		short m_sMFLD_10;
		bool m_bMFLD_12;
		bool m_bMFLD_13;
		string m_strMFLD_14;
		bool m_bMFLD_20;
		int m_nMFLD_24;
		vector<sMrzFieldDescription::sLocation> m_vMFLD_28;
		shared_ptr<IFieldCorrector const> m_spMFLD_34;
		shared_ptr<IChecksumCorrector> m_spMFLD_3C;
	};

	class sMrzFormatDescription
	{
	public:
		sMrzFormatDescription();
		sMrzFormatDescription(sMrzFormatDescription const &);
		sMrzFormatDescription(sMrzFormatDescription &&);
		~sMrzFormatDescription();
		sMrzFormatDescription &operator=(sMrzFormatDescription const &);
		vector<sMrzFieldDescription> getFields(sFieldType) const;
		int fieldsCount(sFieldType);
		void eraseFields(sFieldType);

	public:
		string m_strMFMD_0;
		eMrzFormatSize m_eMFMD_C;
		bool m_bMFMD_10;
		bool m_bMFMD_11;
		bool m_bMFMD_12;
		bool m_bMFMD_13;
		int m_nMFMD_14;
		int m_nMFMD_18;
		map<string, set<string>> m_mMFMD_1C;
		vector<sMrzFieldDescription> m_vMFMD_MFLD_28;
	};

	class sParsedMrzField
	{
	public:
		sParsedMrzField();
		sParsedMrzField(sParsedMrzField const &);
		sParsedMrzField(sParsedMrzField &&);
		~sParsedMrzField();
		sParsedMrzField & operator=(sParsedMrzField const &);
		void correct();
		bool isChecksum();
		bool isFormatValid();

	public:
		string m_strPMF_0;
		CHypothesesLine m_xPMF_CH_C;
		sMrzFieldDescription m_xPMF_MFD_18;
		bool m_bPMF_5C;
	};
};

map<mrz_error_corrector::eMrzFormatSizeExt, vector<mrz_error_corrector::sMrzFormatDescription *>> sortMrzDescriptionsByFormatSize(vector<mrz_error_corrector::sMrzFormatDescription> &);
map<basic_string<char>, vector<mrz_error_corrector::sMrzFormatDescription *>> sortMrzDescriptionsByIssuingStateCode(vector<mrz_error_corrector::sMrzFormatDescription *> &);
map<mrz_error_corrector::eMrzFormatSizeExt, mrz_error_corrector::IssuingStateCodeDescr> sortMrzDescriptionsByFormatSizeAndIssuingStateCode(vector<mrz_error_corrector::sMrzFormatDescription> &);