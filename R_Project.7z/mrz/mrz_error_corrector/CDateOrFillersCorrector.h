#pragma once
#include "mrz_error_corrector.h"
#include "CAbstractDateCorrector.h"

namespace mrz_error_corrector
{
	class CDateOrFillersCorrector : public CAbstractDateCorrector
	{
	public:
		~CDateOrFillersCorrector();

		basic_string<char> correct(CHypothesesLine const&) const;
		basic_string<char> getMask(void) const;
		bool isValid(basic_string<char> const&) const;
	};

	class CDateOrFillersCorrector_DDMMYY : public CAbstractDateCorrector
	{
	public:
		~CDateOrFillersCorrector_DDMMYY();

		basic_string<char> correct(CHypothesesLine const&) const;
		basic_string<char> getMask(void) const;
		bool isValid(basic_string<char> const&) const;
	};

	class CDateOrFillersCorrector_YYMMDD : public CAbstractDateCorrector
	{
	public:
		~CDateOrFillersCorrector_YYMMDD();

		basic_string<char> correct(CHypothesesLine const&) const;
		basic_string<char> getMask(void) const;
		bool isValid(basic_string<char> const&) const;
	};

	class CDateOrFillersCorrector_YYYYMMDD : public CAbstractDateCorrector
	{
	public:
		~CDateOrFillersCorrector_YYYYMMDD();

		basic_string<char> correct(CHypothesesLine const&) const;
		basic_string<char> getMask(void) const;
		bool isValid(basic_string<char> const&) const;
	};
}

