#pragma once
#include "../../pch.h"
#include "../../commonStruct.h"
#include "mrz_error_corrector.h"
#include "document.h"

using namespace rapidjson;

namespace mrz_error_corrector
{
	class CJsonMrzFormatDescriptionParser
	{
	public:
		vector<sMrzFormatDescription> m_vCJMFDP_0;
	public:
		void createCountryDocumentCodeMap(GenericValue<UTF8<char> > const&, mrz_error_corrector::sMrzFormatDescription &);
		void createFields(GenericValue<UTF8<char> > const&, mrz_error_corrector::sMrzFormatDescription &);
		void eraseRewritedFields(GenericValue<UTF8<char> > const&, mrz_error_corrector::sMrzFormatDescription &);
		sMrzFormatDescription getFormatDescrByName(string const&);
		sMrzFormatDescription getMrzFormatDescription(GenericValue<UTF8<char> > const&);
		void Parse(string);
		void rewriteByBaseFormat(GenericValue<UTF8<char> > const&, sMrzFormatDescription &);
	};
}