#pragma once
#include "mrz_error_corrector.h"

namespace mrz_error_corrector
{
	class CHypothesesLine;

	class CAbstractDateCorrector : public AbstractFieldCorrector
	{
	public:
		basic_string<char> correctDD(CHypothesesLine const&, uint, uint, bool) const;
		bool isDateValid(basic_string<char> const&, bool, bool, bool) const;
		static bool isLeapYear(int);
	};
}




