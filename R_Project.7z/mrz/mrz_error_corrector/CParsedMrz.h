#pragma once
#include "../../pch.h"
#include "../../commonStruct.h"
#include "CRecognizedMrz.h"
#include "mrz_error_corrector.h"

namespace mrz_error_corrector
{
	class CParsedMrz
	{
	public:
		~CParsedMrz();
		sParsedMrzField *begin(void);
		void correctChecksumsForced(void);
		void correctFields(void);
		void correctKnownFields(void);
		CParsedMrz(CParsedMrz const&);
		CParsedMrz(CParsedMrz&&);
		CParsedMrz(CRecognizedMrz const&, sMrzFormatDescription const&);
		CParsedMrz(void);
		sParsedMrzField *end(void);
		bool fieldHasChecksum(sFieldType);
		void generateFields(void);
		set<string> getAllDocumentCodes(void);
		sParsedMrzField getChecksumField(sFieldType);
		sParsedMrzField getField(sFieldType) const;
		vector<sParsedMrzField> getFields(void);
		int getMaxRank(void);
		int getRank(void);
		CRecognizedMrz &getRecognizedMrz();
		bool hasField(sFieldType);
		bool isDistinguished(bool);
		bool isRusNat(void);
		bool isValid(void);
		CParsedMrz &operator=(CParsedMrz const&);
		CParsedMrz &operator=(CParsedMrz&&);
		void parseMrz(CRecognizedMrz const&, sMrzFormatDescription const&);
		void parseMrz(CRecognizedMrz const&, vector<sMrzFormatDescription *> const&);
		void reparseFields(vector<string> const&);
		void restoreFieldsConsistency(void);
		string toString(void);

	public:
		CRecognizedMrz m_xCPM_CRM_0;
		string m_strCPM_C;
		eMrzFormatSize m_eCPM_size_18;
		bool m_bCPM_1C;
		bool m_bCPM_1D;
		bool m_bCPM_1E;
		bool m_bCPM_1F;
		int m_nCPM_20;
		int m_nCPM_24;
		map<string, set<string>> m_mCPM_28;
		vector<sParsedMrzField> m_vCPM_34;
		vector<sFieldType> m_vCPM_type_40;
	};
}