#pragma once
#include "../../pch.h"

namespace mrz_error_corrector {
	class CHypotheses
	{
	public:
		typedef struct __sHypothesis_ {
			char chHyThes_0;
			int nHyThesProb_4;
		}sHypothesis;

	public:
		CHypotheses(CHypotheses const &);
		CHypotheses(CHypotheses&& a1);
		CHypotheses();

		char getMostProbableDigit() const;
		char getMostProbableDigitOrFiller() const;
		char getMostProbableFiller() const;
		char getMostProbableLetter() const;
		char getMostProbableLetterOrFiller() const;
		char getMostProbableOneOf(string const & a1) const;
		char getMostProbableSymbol() const;
		int getProbability(char a1) const;
		void supplementWithSimilar();
		void push_back(CHypotheses::sHypothesis const & a1);

		CHypotheses & operator=(CHypotheses const& a1);

		static multimap<char, char> getSimilarityMap();

	public:
		vector<sHypothesis> m_vsHypoThesis_0;
	};

	class CHypothesesLine
	{
	public:
		CHypothesesLine(CHypothesesLine const & a1);
		CHypothesesLine(CHypothesesLine&& a1);
		CHypothesesLine();

		void append(CHypothesesLine const& a1);
		void clear();
		CHypothesesLine getInterval(unsigned int a2, unsigned int a3) const;
		void push_back(CHypotheses const& a1);
		void removeFarHypotheses(unsigned int a1);
		int getStringProbSum(string const &a1) const;
		string getMostProbableString() const;

		CHypothesesLine & operator=(CHypothesesLine const & a1);

	public:
		vector<CHypotheses> m_vCHypoTheses_0;
	};
}
