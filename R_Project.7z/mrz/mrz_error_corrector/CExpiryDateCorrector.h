#pragma once
#include "CAbstractDateCorrector.h"

namespace mrz_error_corrector
{
	class CExpiryDateCorrector_DDMMYY : public CAbstractDateCorrector
	{
	public:
		~CExpiryDateCorrector_DDMMYY();

		basic_string<char> correct(CHypothesesLine const&) const;
		basic_string<char> getMask(void) const;
		bool isValid(basic_string<char> const&) const;
	};

	class CExpiryDateCorrector_YYMMDD : public CAbstractDateCorrector
	{
	public:
		~CExpiryDateCorrector_YYMMDD();

		basic_string<char> correct(CHypothesesLine const&) const;
		basic_string<char> getMask(void) const;
		bool isValid(basic_string<char> const&) const;
	};

	class CExpiryDateCorrector_YYYYMMDD : public CAbstractDateCorrector
	{
	public:
		~CExpiryDateCorrector_YYYYMMDD();

		basic_string<char> correct(CHypothesesLine const&) const;
		basic_string<char> getMask(void) const;
		bool isValid(basic_string<char> const&) const;
	};
}
