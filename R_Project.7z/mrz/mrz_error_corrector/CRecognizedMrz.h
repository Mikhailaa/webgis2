#pragma once
#include "../../pch.h"
#include "CHypotheses.h"
#include "../../commonStruct.h"
//#include "common/ResultContainerList.h"
//#include "imseg/RecognizedTextDoc.h"

using namespace mrz_error_corrector;

namespace mrz_error_corrector
{
	class CRecognizedMrz
	{
	public:
		CRecognizedMrz() {};
		~CRecognizedMrz() {};
		CRecognizedMrz(CRecognizedMrz&&);
		CRecognizedMrz(string const&);
		CRecognizedMrz(TDocVisualExtendedInfo &);
		//CRecognizedMrz(TResultContainerList &); no xref
		void fix_0_O_heuristics(TDocVisualExtendedInfo &);
		//fix_0_O_heuristics(TResultContainerList &); no xref
		int getFormatSize() const;
		//getMostProbableMrzString(); no xref
		static TDocVisualExtendedField& getMrzVisualExtendedField(TDocVisualExtendedInfo &);
		//TDocVisualExtendedField& getMrzVisualExtendedField(TDocVisualExtendedInfo const&); no xref
		static TDocVisualExtendedInfo& getMrzVisualExtendedInfo(TResultContainerList &);
		//getMrzVisualExtendedInfo(TResultContainerList const&); no xref
		void init(string const&);
		void init(TDocVisualExtendedInfo &);
		CRecognizedMrz& operator=(CRecognizedMrz const&);

		vector<CHypothesesLine> m_vCHypthesesLine_0;
	};
}
