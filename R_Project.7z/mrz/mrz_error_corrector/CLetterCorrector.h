#pragma once
#include "mrz_error_corrector.h"

namespace mrz_error_corrector
{
	class CLetterCorrector : public AbstractFieldCorrector
	{
	public:
		uint m_nCLC_4;
	public:
		CLetterCorrector(uint);
		~CLetterCorrector();

		basic_string<char> correct(CHypothesesLine const&) const;
		basic_string<char> getMask(void) const;
		bool isValid(basic_string<char> const&) const;
	};

	class CLetterOrFillerCorrector : public AbstractFieldCorrector
	{
	public:
		uint m_nCLOFC_4;
	public:
		CLetterOrFillerCorrector(uint);
		~CLetterOrFillerCorrector();

		basic_string<char> correct(CHypothesesLine const&) const;
		basic_string<char> getMask(void) const;
		bool isValid(basic_string<char> const&) const;
	};
}
