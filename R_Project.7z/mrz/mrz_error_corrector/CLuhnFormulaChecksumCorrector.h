#pragma once
#include "mrz_error_corrector.h"

namespace mrz_error_corrector
{
	class sParsedMrzField;
	class CParsedMrz;

	class CLuhnFormulaChecksumCorrector : public AbstractChecksumCorrector
	{
	public:
		CLuhnFormulaChecksumCorrector(sFieldType const&, vector<sFieldType> const&);
		~CLuhnFormulaChecksumCorrector();

		map<sFieldType, sParsedMrzField> correct(CParsedMrz const&);
		bool isValid(CParsedMrz const&);
		uint getChecksum(CParsedMrz const&);
		uint getChecksum(basic_string<char> const&);

		shared_ptr<IChecksumCorrector> clone(sFieldType, vector<sFieldType> const&);

		CHypothesesLine composeHypothesesLine(CParsedMrz const&);
		basic_string<char> composeValueLine(CParsedMrz const&);

		basic_string<char> getChecksumAsString(CParsedMrz const&);
		basic_string<char> getChecksumAsString(basic_string<char> const&);
		static uint getChecksumForString(basic_string<char> const&);
		map<sFieldType, sParsedMrzField> getFieldsIfCorrect(basic_string<char>, CParsedMrz const&);
	};
}
