#pragma once
#include "mrz_error_corrector.h"

namespace mrz_error_corrector
{
	class MrzCorrectorInfo
	{
	public:
		vector<sMrzFormatDescription>                           m_vMCI_0;
		map<eMrzFormatSizeExt, vector<sMrzFormatDescription *>> m_mMCI_C;
		map<eMrzFormatSizeExt, IssuingStateCodeDescr>           m_mMCI_18;
	public:
		MrzCorrectorInfo();
		~MrzCorrectorInfo();
		void init(basic_string<char> const&);
	};

	class MrzCorrectorInfoSingleton
	{
	public:
		static MrzCorrectorInfo * free(void);
		static MrzCorrectorInfo * obj(void);
		static MrzCorrectorInfo * pObj(bool);
	};
}