#pragma once
#include "COneOfListCorrector.h"

namespace mrz_error_corrector
{
	class CDocumentCodeCorrector : public COneOfListCorrector
	{
	public:
		set<basic_string<char> > m_sCDCC_10;
		uint                     m_nCDCC_1C;
	public:
		CDocumentCodeCorrector(set<basic_string<char> > const&);
		~CDocumentCodeCorrector();

		basic_string<char> correct(CHypothesesLine const&) const;
		basic_string<char> getMask(void) const;
	};
}
