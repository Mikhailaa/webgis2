#pragma once
#include "mrz_error_corrector.h"

namespace mrz_error_corrector
{
	class CNameCorrector : public AbstractFieldCorrector
	{
	public:
		uint m_nCNC_4;
	public:
		CNameCorrector(uint);
		~CNameCorrector();

		basic_string<char> correct(CHypothesesLine const&) const;
		bool isValid(basic_string<char> const&) const;
		basic_string<char> getMask(void) const;
	};

	class CNameWithDigitsCorrector : public AbstractFieldCorrector
	{
	public:
		uint m_nCNWDC_4;
	public:
		CNameWithDigitsCorrector(uint);
		~CNameWithDigitsCorrector();

		basic_string<char> correct(CHypothesesLine const&) const;
		bool isValid(basic_string<char> const&) const;
		basic_string<char> getMask(void) const;
	};
}
