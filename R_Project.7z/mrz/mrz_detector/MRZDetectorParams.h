#pragma once
#include "../../pch.h"
#include "mrz_detector.h"

namespace mrz_detector
{
	class MRZDetectorParams
	{
	public:
		double              m_dMRZP_field_0;
		double              m_dMRZP_field_8;
		double              m_dMRZP_field_10; //###
		int                 m_nMRZP_field_18; //###
		bool                m_fMRZP_field_1C; //###
		int 				m_nMRZP_field_20; //int ? float
		int 				m_nMRZP_field_24;
		float               m_rMRZP_field_28;
		int 				m_nMRZP_field_2C;
		int 				m_nMRZP_field_30;
		float 				m_rMRZP_field_34;
		float               m_rMRZP_field_38;
		int					m_nMRZP_field_3C;
		int					m_nMRZP_field_40;
		bool                m_fMRZP_field_44;
		bool                m_fMRZP_field_45;
		int                 m_nMRZP_field_48;
		float               m_rMRZP_field_4C;
		bool                m_fMRZP_field_50;
		vector<FlipingType> m_vMRZP_field_54;
		float				m_rMRZP_field_60;
		int                 m_nMRZP_field_64;
		int                 m_nMRZP_field_68;
	public:
		MRZDetectorParams(int);
		void initDefaults();
		void updateDPIDepParams(float, cv::Size_<int>);
		void initPossibleFlipping();
	};
}
