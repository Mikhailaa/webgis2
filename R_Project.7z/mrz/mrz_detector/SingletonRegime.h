#pragma once
#include "../../pch.h"
#include "MRZDetectorParams.h"
#include "../../commonStruct.h"
#include "MRZFormat.h"

namespace mrz_detector
{
	class SingletonRegime
	{
	public:
		function<basic_string<char>(TDocVisualExtendedInfo *)>  m_funcSR_field_0;
		vector<MRZFormat>                                       m_vSR_field_18;
		bool                                                    m_fSR_field_24;
		basic_string<char>                                      m_bsSR_field_28;
		bool                                                    m_fSR_field_34;
		bool													m_fSR_field_38;
		shared_ptr<MRZDetectorParams>                           m_spSR_field_3C;
		int                                                     m_nSR_field_44;
	public:
		SingletonRegime(int);
		~SingletonRegime();
		void init(int);
	};
}
