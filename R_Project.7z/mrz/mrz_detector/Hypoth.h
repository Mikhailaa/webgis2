#pragma once
#include "../../pch.h"
#include "mrz_detector.h"

namespace mrz_detector
{
	class Hypoth
	{
	public:
		Hypoth();
		Hypoth(vector<candidat> &, cv::Rect_<int>);
		Hypoth(Hypoth const&);
		Hypoth(Hypoth&&);
		~Hypoth();

		Hypoth& operator=(Hypoth const &);
		Hypoth& operator=(Hypoth&&);

		float prob();
		char symbol(void) const;
	public:
		vector<candidat>   m_vHyp_field_0;
		vector<float>	   m_vHyp_field_C;
		cv::Rect           m_xHyp_field_18;
	};
}