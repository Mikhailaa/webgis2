#pragma once
#include "../../pch.h"
#include "mrz_detector.h"
#include "MRZDetectorParams.h"
#include "MRZLines.h"
#include "Blob.h"

namespace mrz_detector
{
	class MRZGeom
	{
	public:
		int         m_nMRZG_field_0;
		float       m_rMRZG_field_4;
		float       m_rMRZG_field_8;
		cv::Mat     m_xMRZG_field_C;
		cv::Mat     m_xMRZG_field_44;
		cv::Size    m_xMRZG_field_7C;
		float       m_rMRZG_field_84;
		float       m_rMRZG_field_88;
		cv::Point2f m_xMRZG_field_8C;
		float       m_rMRZG_field_94;
		float       m_rMRZG_field_98;
	public:
		MRZGeom(void);
		MRZGeom(MRZGeom const&);
		~MRZGeom();
		MRZGeom& operator=(MRZGeom const&);

		void addRotation180(cv::Size_<int>);
		void calc_rot_mat(cv::Size_<int>, float);
		void dst2src(vector<cv::Point2f> const&, vector<cv::Point2f>&);
		float getAngle(void);
		float getScale(void);
		void imgRot2srcSmall(cv::Rect const&, vector<cv::Point2f> &);
		void imgRot2srcSmall(vector<cv::Point2f> const&, vector<cv::Point2f>&);
		void resizeImg(shared_ptr<MRZDetectorParams> &, cv::Mat const&, cv::Mat&);  //###
		void setTranslationVector(cv::Point2f const&);
		void shiftTranslationVector(float, float);
		void src2srcSmall(vector<Blob> &);
		void srcSmall2imgRot(cv::Mat const&, cv::Mat&) const;
		void srcSmall2imgRot(MRZLines &) const;
		void srcSmall2src(vector<Blob> &) const;
		bool wasResized(void);
	};
}