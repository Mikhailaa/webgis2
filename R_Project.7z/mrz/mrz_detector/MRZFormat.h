#pragma once
#include "../../pch.h"
#include "mrz_detector.h"

namespace mrz_detector
{
	typedef int stdMRZFormats;

	class MRZFormat
	{
		public:
			MRZFormat();
			MRZFormat(stdMRZFormats);
			~MRZFormat();

			void initDefault(void);

			bool operator==(MRZFormat const&) const;
		public:
			int m_nMRZF_field_0;
			int m_nMRZF_field_4;
			int m_nMRZF_field_8;
			int m_nMRZF_field_C;
			int m_nMRZF_field_10;
			int m_nMRZF_field_14;
			float m_rMRZF_field_18;
			float m_rMRZF_field_1C;
			float m_rMRZF_field_20;
			float m_rMRZF_field_24;
			int m_nMRZF_field_28;
			float m_rMRZF_field_2C;
			CANParams m_xMRZF_field_30;
	};
}