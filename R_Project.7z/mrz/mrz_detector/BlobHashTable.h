#pragma once
#include "../../pch.h"

namespace mrz_detector
{
	class BlobHashTable
	{
	public:
		//BlobHashTable() {};
		BlobHashTable(cv::Size const&);
		~BlobHashTable();

		int calcHash(cv::Rect const&);
		bool insertIfNotFound(cv::Rect_<int> const&);
	public:
		cv::Size        m_xBHT_field_0;
		set<int>        m_sBHT_field_8;
	};
}

