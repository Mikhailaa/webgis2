#pragma once
#include "../../pch.h"
#include "mrz_detector.h"

namespace mrz_detector
{
	class NodeOpt
	{
	public:
		NodeOpt* pNO_field_0;
		NodeOpt* pNO_field_4;
		short wNO_field_8;
		char chNO_field_A;
		//char chNO_field_B;
	public:
		~NodeOpt();
		void read(basic_istream<char> &);
		void read(basic_istream<char> &, int);
	};

	class TreeOpt
	{
	public:
		NodeOpt* pTO_field_0;
	public:
		TreeOpt(basic_istream<char> &);
		~TreeOpt();

		int predict(cv::Mat &);
	};

	class ERTreesOpt
	{
	public:
		vector<TreeOpt*> m_vERTO_field_0;

		~ERTreesOpt();
		void clear();
		void predict(cv::Mat &, vector<candidat> &);
		int read(basic_istream<char> &);
	};

	inline
		bool compCandi(candidat & a1, candidat & a2)
	{
		return a1.second > a2.second;
	}
}
