#pragma once
#include "../../pch.h"
#include "Hypoth.h"
#include "MRZ.h"

namespace mrz_detector
{
	class RecognitionResult
	{
		public:
			RecognitionResult();
			RecognitionResult(RecognitionResult const &);
			~RecognitionResult();

			RecognitionResult& operator=(RecognitionResult const&);
			int operator==(RecognitionResult const&);

			float   avgProb();
			double calcArbitraryTextLikelihood(void);
			void clear(void);
			uint cols(uint);
			uint cols(void);
			bool empty(void);
			void fillByMessage(basic_string<char> &);
			Hypoth& getHypoth(uint, uint);
			char getLabel(uint const&, uint const&);
			void getRecognizedArray(vector<vector<char>> &);
			basic_string<char> getRecognizedString(void) const;
			cv::Rect getRect(uint, uint);
			void init(MRZ &);
			bool isCorrect(uint, uint, char, MRZ *);
			float minProb(void);
			//void setGroundTruth(basic_string<char>); //???
			void setResult(vector<vector<Hypoth>> &);
			void setSymbolHeights(uint, uint, vector<float> &);
		public:
			vector<vector<Hypoth>> m_vRR_field_0;
			vector<vector<char>>   m_vRR_field_C;
			float                  m_rRR_field_18;
	};
}