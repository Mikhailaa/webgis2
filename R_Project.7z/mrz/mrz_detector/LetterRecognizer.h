#pragma once
#include "../../pch.h"
#include "MRZ.h"
#include "Hypoth.h"
#include "NormalDistribution.h"
#include "BlobHashTable.h"
#include "ERTreesOpt.h"
#include "Segmenter.h"
#include "RecognitionResult.h"

namespace mrz_detector
{
	class LetterRecognizer
	{
	public:
		LetterRecognizer(MRZDetectionMode);
		void     askClassifier(FlipingType &, cv::Mat &, vector<FlipingType> const&, vector<candidat> &);
		void     askClassifierOnSegmentedImage(cv::Mat &, vector<candidat> &);
		double   calcArbitraryTextLikelihood(void);
		void     calcSymbolHeights(MRZ &);
		void     copyResultTo(RecognitionResult &);
		void     correctLetterVsDigitConflict(Hypoth &, float &, float &, int);
		void     correctPersepctiveDistortion(MRZ&);
		void     correctPersepctiveDistortionInIDL(MRZ&);
		void     deleteExtraSymbols(MRZ &, vector<vector<Hypoth>> &);
		int      determineFlipping(MRZ &, vector<FlipingType> &);
		void     distinguishOvsZero(MRZ &);
		void     estimatePartsOfSplittedSymbol(MRZ &, cv::Ptr<Blob> &, cv::Ptr<Blob> &, float &, float &, float &);
		void     findMissedSymbolsHorizontaly(MRZ &, int, vector<vector<Hypoth>> &, cv::Mat &/*, cv::Mat &*/);
		cv::Rect findApriorSymbolROI(vector<vector<Hypoth>> &, uint, uint, int, int, int);
		void     findMissedSymbols(MRZ &, FlipingType, vector<vector<Hypoth>> &, cv::Mat &/*, cv::Mat &*/);
		void     flip(cv::Mat &, FlipingType);
		Hypoth   getHypoth(uint, uint);
		basic_string<char> getRecognizedString(void);
		void     improveHypoth(cv::Rect_<int> &, MRZ &, FlipingType, Hypoth &);
		void     improveLowProbableAndOutlierRecognition(MRZ &, FlipingType, vector<vector<Hypoth>> &/*, cv::Mat &, cv::Mat &*/);
		void     improveMRZquadriangleTightSrcRef(MRZ &);
		void     initDefaultParams(void);
		void     initGoodSymbols(void);
		bool     isBadLetterOrDigit(int);
		bool     isGoodDigit(int);
		bool     isGoodLetter(int);
		bool     isGoodSegmentation(MRZFormat &, vector<vector<Hypoth>> &);
		bool     isThereSymbolOnMask(cv::Mat const&);
		void     letterOrDigitDecideByHeight(Hypoth &, vector<NormalDistribution> &, vector<NormalDistribution> &, float &, float &);
		void     load(ERTreesOpt *);
		float    minProb(void);
		int      strings(void);
		int      symbolsInString(uint);
		int      tryRecognizeConfidently(MRZ&, bool);
		Hypoth   tryToFindSymbolWithHighPrior(cv::Rect_<int>&, MRZ &, int, cv::Mat &);
		bool     tryToFindSymbolAroundPoint(BlobHashTable &, cv::Point_<int>, vector<float> &, float, cv::Mat &, MRZ &, int, cv::Mat &, Hypoth &);
		void     recognizeRotatedSymbol(cv::Mat const&, vector<cv::Point2f> const&, float, std::vector<int> const&, int&, vector<candidat> &);
		int      recognizeSymbol(MRZ &, uint, uint, int, vector<int> &, cv::Mat &, cv::Rect_<int> &, Hypoth &);
		
	public:
		ERTreesOpt        *m_pLR_field_0;
		RecognitionResult  m_xLR_field_4;
		Segmenter          m_xLR_field_20;
		float              m_rLR_field_30;
		float              m_rLR_field_34;
		int                m_nLR_field_38;
		int                m_nLR_field_3C;
		bool               m_fLR_field_40;
		float              m_rLR_field_44;
		float              m_rLR_field_48;
		float              m_rLR_field_4C;
		float              m_rLR_field_50;
		float              m_rLR_field_54;
		float              m_rLR_field_58;
		float              m_rLR_field_5C;
		float              m_rLR_field_60;
		unordered_set<int> m_usLR_field_64;
		unordered_set<int> m_usLR_field_78;
		float              m_rLR_field_8C;
		float              m_rLR_field_90;
	};

	inline
		bool compHypoth(Hypoth & a1, Hypoth & a2)
		{
			return a1.m_xHyp_field_18.x + a1.m_xHyp_field_18.width < a2.m_xHyp_field_18.x + a2.m_xHyp_field_18.width;
		}
}
