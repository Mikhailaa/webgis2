#pragma once
#include "../../pch.h"
#include "mrz_detector.h"
#include "MRZFormat.h"
#include "MRZGeom.h"

namespace mrz_detector
{
	class RecognitionResult;

	class MRZ
	{
	public:
		vector<cv::Vec<float, 2>>				m_vMRZ_field_0;
		int										m_nMRZ_field_C;
		float									m_rMRZ_field_10;
		float									m_rMRZ_field_14;
		cv::Size2f								m_xMRZ_field_18;
		MRZGeom									m_xMRZ_field_20;
		cv::Mat									m_xMRZ_field_BC;
		MRZFormat								m_xMRZ_field_F4;
		vector<cv::Point2f>						m_vMRZ_field_14C;
		vector<cv::Point2f>						m_vMRZ_field_158;
		vector<vector<cv::Ptr<Blob>>>			m_vMRZ_field_164;
		vector<vector<vector<cv::Point2f>>>     m_vMRZ_field_170;

		MRZ();
		MRZ(MRZ const&);
		MRZ& operator=(MRZ const&);
		MRZ& operator=(MRZ&&);
		~MRZ();

		void calcBlobsQuadsSrcRef(void);
		void calcErrorPerLine(void);
		void calcQuadrTightSrcRef(void);
		void clear(void);
		bool empty(void);
		bool isGoodSize(int);
		void recutMRZImage(RecognitionResult &);
		void rotate180(void);
		void scale(float);
		void updateBlobs(RecognitionResult &);
	};

	inline
		bool compPtrBlob0x(cv::Ptr<Blob> & a1, cv::Ptr<Blob> & a2)
	{
		return a1->m_xBlob_field_0.x < a2->m_xBlob_field_0.x;
	}
}
