#pragma once
#include "../../pch.h"
#include "ERTreesOpt.h"
#include "RecognitionAggregator.h"
#include "RecognitionResult.h"
#include "MRZ.h"
#include "LetterRecognizer.h"
#include "SingletonRegime.h"
#include "../../common/container/RclHolder.h"
#include "../../common/container/ThreadStorage.h"

using namespace common::container;

namespace mrz_detector
{
	class MRZDetectorProcess
	{
	public:
		MRZDetectorProcess();
		~MRZDetectorProcess();
		void clearSeriesData(void);
		void correctErrorsAndGenResults(shared_ptr<SingletonRegime> &, cv::Mat &, MRZ &, RecognitionResult &, basic_string<char> &, TResultContainerList *&); //
		void correctSymbols(RecognitionResult &);
		TDocMRZTestQuality * generateTestQuality(TDocVisualExtendedInfo &);
		ERTreesOpt * getClassifierPtr(void);
		void getRGBAMrzImg(MRZ &, cv::Mat &);
		int init(void);
		void initImpl(void);
		bool isBad(void);
		int process(bool, cv::Mat &, RclHolder &);
		int process(shared_ptr<SingletonRegime> &, cv::Mat &, float, cv::Mat &, vector<cv::Point_<float>> &, vector<vector<char>> &, basic_string<char> &, TResultContainerList *&);
		int processReadyMRZ(TResultContainerList *, basic_string<char> const&, bool, TResultContainerList *&);
		void putColorSecurityMessage(basic_string<char> &, cv::Mat &);
		void putText(cv::Mat &, basic_string<char> const&, cv::Rect_<int> const&, cv::Scalar_<double> const&, int, double, int/*, int*/);
		int recognizeAndChooseBestMRZ(shared_ptr<SingletonRegime> &, vector<MRZ> &, MRZ&, LetterRecognizer &, cv::Mat);
		void retainOneBestMRZOnTheBaseOfDetectorOnly(vector<MRZ> &, MRZ&);
		void setMrzDetectorDat(char *, uint);
	public:
		vector<char>          m_vMRZDP_field_0;
		ERTreesOpt            m_xMRZDP_field_C;
		int                   m_nMRZDP_field_18;
		RecognitionAggregator m_xMRZDP_field_1C;
		RecognitionResult     m_xMRZDP_field_30;
		MRZ                   m_xMRZDP_field_4C;
	    common::container::ThreadStorage<RclHolder>  m_xMRZDP_field_1C8;
	};

}
