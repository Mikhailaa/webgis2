#pragma once
#include "../../pch.h"
#include "MRZ.h"
#include "Blob.h"

namespace mrz_detector
{
	class PerspectiveDistortionCorrector
	{
	public:
		PerspectiveDistortionCorrector();
		~PerspectiveDistortionCorrector();
		
		int calcWidestLineIdx(MRZ const&);
		void calcXs(int const&, vector<cv::Ptr<Blob>> const&, vector<float> &);
		bool correct(MRZ &);
	};

	inline
		float sub_47BE18(vector<cv::Ptr<Blob>> const&);
}