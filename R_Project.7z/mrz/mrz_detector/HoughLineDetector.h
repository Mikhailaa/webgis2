#pragma once
#include "../../pch.h"
#include "Blob.h"
#include "Line.h"

namespace mrz_detector
{
	class HoughLineDetector
	{
	public:
		HoughLineDetector(float);
		~HoughLineDetector();

		void detectLines(vector<Blob> &, cv::Size_<int>, float, int, int, vector<Line> &);
		void detectLinesBtwAngles(vector<Blob> const&, cv::Size_<int>, float, int, int, float, float, vector<Line> &);
	public:
		float	      m_rHLD_field_0;
		vector<float> m_vHLD_field_4;
		vector<float> m_vHLD_field_10;
		vector<float> m_vHLD_field_1C;
	};

	inline
		bool compLine(Line & a1, Line & a2)
	{
		float r39, r40;
		r39 = a2.m_rLine_field_18;
		r40 = a1.m_rLine_field_18;

		if (r40 == r39)
		{
			r39 = a2.m_rLine_field_1C;
			r40 = a1.m_rLine_field_1C;
		}

		if (r40 < r39)
		{
			return true;
		}

		return false;
	}

	inline
		bool compPairVf(pair<cv::Vec<float, 2>, float> & a1, pair<cv::Vec<float, 2>, float> & a2)
	{
		return a1.second > a2.second;
	}
}