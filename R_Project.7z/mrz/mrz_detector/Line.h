#pragma once
#include "../../pch.h"
#include "Blob.h"

namespace mrz_detector
{
	class Line
	{
	public:
		cv::Vec<float, 2 >       m_xLine_field_0;
		vector<cv::Ptr<Blob>>    m_vLine_field_8;
		float                    m_rLine_field_14;
		float                    m_rLine_field_18;
		float                    m_rLine_field_1C;
		float                    m_rLine_field_20;
		int                      m_nLine_field_24;
		int                      m_nLine_field_28;  //??? bool?

		Line();
		Line(Line const&);
		~Line();

		Line& operator=(Line const&);

		void calcBlobDistVariability(void);
		cv::Point calcIntersectionPointwith(Line&);
		void copyRhoThetaFromCv(cv::Vec<float, 2> &);
		bool hasSameBlobsAs(Line&);
		bool isBlobOnLine(Blob &);
		void linearRegression(vector<float> &, vector<float> &, cv::Vec<float, 2> &);
		void regressLineThroughBlobs(void);
		void searchAdditionalBlobs(vector<Blob> &);
		void sortBlobsAlongLine(void);
	};

	//inline
	//	bool compBlob18(cv::Ptr<Blob> & a1, cv::Ptr<Blob> & a2)
	//{
	//	return a1->m_nBlob_field_18 < a2->m_nBlob_field_18;
	//}
}
