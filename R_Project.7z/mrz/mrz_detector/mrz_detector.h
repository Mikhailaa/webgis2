#pragma once

#include "../../pch.h"
#include "../../commonStruct.h"
//#include "common/ResultContainerList.h"
//#include "imseg/RecognizedTextDoc.h"


namespace mrz_detector
{
	typedef int MRZDetectionMode;
	typedef int FlipingType;

	class Blob;
	class MRZ;
	class RecognitionResult;
	class SingletonRegime;

	struct DataForBlobSaving
	{
		cv::Mat               xDFBS_field_0;
		vector<Blob>         *pDFBS_field_38;
	};

	typedef pair<char, float> candidat;


	class CANParams
	{
	public:
		float rCANP_field_0;
		float rCANP_field_4;
		int   nCANP_field_8;
		float rCANP_field_C;
		float rCANP_field_10;
		float rCANP_field_14;
		int   nCANP_field_18;
		float rCANP_field_1C;
		int   nCANP_field_20;
		float rCANP_field_24;
	public:
		CANParams()
		{
			rCANP_field_0 = 3.0;
			rCANP_field_4 = 10.0;
			nCANP_field_8 = 4;
			rCANP_field_C = 5.0;
			rCANP_field_10 = 4.0;
			rCANP_field_14 = 2.0;
			nCANP_field_18 = 0x32;
			rCANP_field_1C = 0.05f;
			nCANP_field_20 = 0x64;
			rCANP_field_24 = 40.0;
		};
	};

	class membuf : public basic_streambuf<char>
	{
	public:
		membuf(char *, char *);
		~membuf();
	};


	void anyColorToGray(cv::Mat &, cv::Mat &);
	cv::Rect_<int> & align4(cv::Rect_<int> &, cv::Size_<int> const&);
	cv::Matx<float, 2, 1> calcLongestSideDirection(cv::RotatedRect const&);
	void chooseImgs(TResultContainerList const*, TRawImageContainer *&, eRPRM_Lights &, TRawImageContainer *&, eRPRM_Lights &);
	void cutBlobImg(Blob *, cv::Mat &, cv::Mat &);

	void deleteTBoundsResult(TBoundsResult **);
	void deleteTestQualityResult(TDocMRZTestQuality **);
	void deleteTDocVisualExtendedInfo(TDocVisualExtendedInfo **);
	void deleteTRawImageContainer(TRawImageContainer **);
	void deleteTResultContainerList(TResultContainerList **);
	void deleteTResultMRZDetector(TResultMRZDetector **);
	int detectAndRecognizeCANByBounds(shared_ptr<SingletonRegime> &, TRawImageContainer const*, cv::RotatedRect &, vector<char> &);
	
	int expandROI(int, cv::Rect_<int> &);
	void fastFlip(cv::Mat const&, cv::Mat&);

	int fillCANRecognitionOutput(vector<char> const&, TResultContainerList *&);
	void fillMrzRecognitionRects(TResultContainerList *, cv::Mat &);
	int fillSymbolCoordinates(TDocVisualExtendedField &, tagRECT &);
	TDocVisualExtendedInfo * fillSymbolsAndCandidats(RecognitionResult &);
	TDocVisualExtendedInfo * fillSymbolsAndCandidats(vector<char> const&);
	TDocMRZTestQuality * fillTestQuality(TDocVisualExtendedInfo *, MRZ const&);
	TRawImageContainer * fillTRawImageContainer(MRZ &, SingletonRegime &);
	TResultMRZDetector * fillTResultMRZDetector(MRZ &, cv::Mat &, SingletonRegime &);
	tagPOINT * fillTResultMRZPosition(MRZ &, cv::Mat &, SingletonRegime &);
	void fillTResultMRZPositionExtracted(MRZ &, int, int, int, tagPOINT &, int);

	int getMrzFormat(MRZ const&);

	bool isEmpty(tagRECT &);

	cv::Rect_<int> & noAccessViolation(cv::Rect_<int> &, cv::Size_<int> const&);
	int Process(int, std::shared_ptr<SingletonRegime> &, TResultContainerList const*, basic_string<char> const&, TResultContainerList*);

	void readCorrectedSymbolsFrom(TDocVisualExtendedInfo const*, RecognitionResult &);

	void ROI2Vector(cv::Rect_<int> const&, vector<cv::Point2f> &);
	void rotateQuadr180(vector<cv::Point2f> &);
	void rotateQuadr180(cv::Size const&, vector<cv::Point2f> &);

	int stringToMrzFormatSize(basic_string<char> const&);
	tagRECT & toAbsoluteCoords(tagRECT &, tagRECT);
	bool TRawImage2Mat(TRawImageContainer const*, cv::Mat &, tFullColors_cv);

	namespace RecognFeatures
	{
		void calcFeatures(cv::Mat &, cv::Mat &);
	}
}