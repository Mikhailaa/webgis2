#pragma once
#include "../../pch.h"
#include "../../commonStruct.h"
//#include "common/ResultContainerList.h"

namespace mrz_detector
{
	class MRZDetectorResults
	{
	public:
		mutex                                              m_xMRZDR_0;
		unordered_map<__thread_id, TResultContainerList *> m_umMRZDR_4;
	public:
		MRZDetectorResults();
		~MRZDetectorResults();

		TResultContainerList * allocateThreadMemory(void);
		void freeAll(void);
		TResultContainerList * getPointer(__thread_id);
	};
}