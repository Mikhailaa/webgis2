#pragma once
#include "../../pch.h"
#include "MRZ.h"
#include "mrz_detector.h"

namespace mrz_detector
{
	class FailDiagnoser
	{
	public:
		float m_rFD_field_0;
		float m_rFD_field_4;
		float m_rFD_field_8;
		float m_rFD_field_C;
		float m_rFD_field_10;
		float m_rFD_field_14;
	public:
		FailDiagnoser();
		~FailDiagnoser();
		//int calcHorPerspective(mrz_detector::MRZ const&);
		float calcVertPerspectiveOnRecognizedMRZ(MRZ const&);
		//bool  isMRZAreaToSmall(cv::Rect_<int> &, cv::Size_<int> const&);
		bool isMRZOutOfFocuse(cv::Mat const&);
		bool isMRZOutOfFocuse(cv::Mat const&, vector<Blob> &);
		bool isStrongPerspective(MRZ const&);
		bool isThisSimilarToMRZ(float);
	};
}
