#pragma once
#include "../../pch.h"
#include "Line.h"

namespace mrz_detector
{

	class MRZLines
	{
	public:
		vector<Line> m_vMRZL_field_0;

		MRZLines();
		MRZLines(vector<Line> &);
		~MRZLines();

		float calcErrorPerLine(int);
		float calcHalfMedianDistBtwBlobs(void);
		float calcRotationAngle(void);
		void copyToCv(vector<cv::Vec<float, 2>> &);
		void debugShowBlobs(cv::Mat &, basic_string<char>) {};
		bool isAtLeastOneLineEmpty(void);
		void minMax(float &, float &, float &, float &);
		void rotate(cv::Mat const&, cv::Size const&, double, int);
	};
}