#pragma once
#include "../../pch.h"

namespace mrz_detector
{
	class FilterByProbability
	{
	public:
		double m_dFBP_field_0;
	public:
		FilterByProbability();
		~FilterByProbability();

		bool filter(vector<vector<double>> &, bool, vector<vector<bool>> &);
		bool filter(vector<double> &, bool, vector<bool> &);
	};
}