#pragma once
#include "../../pch.h"
#include "FastBlobDetector.h"
#include "MRZDetectorParams.h"
#include "ERTreesOpt.h"
#include "MRZ.h"
#include "LetterRecognizer.h"
#include "Line.h"
#include "FilterByProbability.h"
#include "FailDiagnoser.h"
#include "HoughLineDetector.h"

namespace mrz_detector
{
	class MRZDetector
	{
		struct CompVLine
		{
			vector<Line> vl;
			int			  n;

			CompVLine(vector<Line> const & a2)
				: vl(a2)
			{
			}

			bool operator()(Line & a2, Line & a3)
			{
				float r5 = fabsf(a3.m_rLine_field_14);
				float r6 = fabsf(a2.m_rLine_field_14);
				float r7, r8;

				bool f10;

				if (r6 == r5)
				{
					r7 = fabsf(sinf(a2.m_xLine_field_0.val[1] - vl[n].m_xLine_field_0.val[1]));
					r8 = fabsf(sinf(a3.m_xLine_field_0.val[1] - vl[n].m_xLine_field_0.val[1]));
					f10 = (r7 < r8);
				}
				else
				{
					f10 = (r6 < r5);
				}
				if (f10)
					return true;
				return false;
			}
		};

		typedef Line CANCandidate;
		//struct CANCandidate
		//{
		//	Line m_xCANC_field_0;
		//};
	public:
		class MRZLinesIdx
		{
		public:
			MRZLinesIdx() {};
			MRZLinesIdx(MRZLinesIdx const&);
			MRZLinesIdx(MRZLinesIdx&&);
			MRZLinesIdx& operator=(MRZLinesIdx&&);
		public:
			int         m_nMRZLI_field_0;
			vector<int> m_vMRZLI_field_4;
			float         m_rMRZLI_field_10;
			int         m_nMRZLI_field_14;
		};

	public:
		MRZDetector();
		MRZDetector(shared_ptr<MRZDetectorParams> &, ERTreesOpt *);
		~MRZDetector();
		void addNewBlobs(vector<Blob> &, vector<Blob> &);
		void analyseSplittedSymbol(MRZ &, cv::Ptr<Blob> &, cv::Ptr<Blob> &, bool &, bool &, bool &);
		void calcCandidatesCAN(cv::Mat &, vector<Blob> &, vector<Line> &, MRZFormat &, vector<CANCandidate> &);
		void calcPossibleCANRegions(cv::RotatedRect const&, cv::Mat const&, vector<cv::RotatedRect> &);
		bool CANCandidateToHiResMRZ(MRZFormat const&, MRZDetector::CANCandidate &, cv::Mat &, cv::Mat const&, MRZ &);
		bool checkMRZ(cv::Mat const&, cv::Mat const&, MRZFormat, float, MRZLines &, float);
		bool checkMRZSize(vector<MRZ> &, MRZDetectorErrorCode &);
		void chooseMRZLines(cv::Mat const&, cv::Mat const&, MRZGeom const&, vector<vector<Line>> &, MRZFormat, vector<MRZLinesIdx> &); //
		void clarifyBlobs(cv::Mat &, float, vector<Blob> &);
		bool clarifyBlobsBtwSegments(cv::Mat &, float, float, vector<vector<cv::Ptr<Blob>>> &);
		bool detectBlobs(vector<MRZFormat> &, cv::Mat &, cv::Mat &, float, float, bool, float, bool, vector<Blob> &, bool, DataForBlobSaving *);
		void deleteDuplicateBlobs(MRZ &);
		int detect(cv::Mat &, float, vector<MRZFormat> &, vector<MRZ> &);
		void detectCAN(cv::Mat const&, float, cv::RotatedRect const&, vector<char> &);
		void detectCAN_docPart(cv::Mat const&, float, cv::RotatedRect const&, vector<char> &);
		void detectCAN_docPartOnBlobs(vector<Blob> &, MRZFormat &, cv::Mat, cv::RotatedRect &, MRZGeom const&, cv::Mat, vector<char> &);
		int detectFormat(cv::Mat const&, cv::Mat&, MRZGeom const&, vector<Line> &, vector<Blob> &, MRZFormat, MRZ &, DataForBlobSaving &);
		int detectFormatOnMRZLines(vector<vector<Line>> &, MRZLinesIdx &, cv::Mat &, MRZFormat &, MRZ &, DataForBlobSaving &);
		void detectLines(cv::Mat, vector<Blob> &, vector<MRZFormat> &, vector<Line> &);
		void detectLinesCAN(cv::Mat, vector<Blob> &, float, MRZFormat &, vector<Line> &);
		void detectParallelLines(cv::Mat &, vector<Line> &, vector<Blob> &, MRZFormat &, vector<vector<Line>> &);
		int detectWithSpecifiedRegime(cv::Mat &, cv::Mat &, vector<MRZFormat> &, vector<Blob> &, vector<MRZ> &);
		FlipingType determineFlipping(Line &, LetterRecognizer &, cv::Mat const&, float);
		bool enoughBlobs(vector<Blob> &, vector<MRZFormat> &);
		void extractParallelLinesGroups(cv::Mat &, vector<Line>, MRZFormat &, vector<vector<Line>> &);
		void filterBlobsByProbability(vector<Blob> &);
		void filterMRZBlobsByColor(MRZLines &, cv::Mat &/*, int*/);
		void filterMRZBlobsByDistance(MRZLines &, int, float, float, cv::Mat &, bool);
		void filterMRZBlobsByDistance(vector<vector<cv::Ptr<Blob>>> &, int, float, float, cv::Mat &, bool);
		void filterMRZBlobsByProbability(MRZLines &, cv::Mat, bool, bool, bool);
		void filterMRZBlobsBySize(MRZLines &, cv::Mat);
		void filterMRZBlobsByY(MRZLines &);
		void filterMRZBlobsOnBoundary(MRZLines &, cv::Size_<int>, float);
		void filterOutArbitraryTextBlobs(Line &, MRZFormat &, cv::Mat &, Line &, Line &);
		bool findMissingMRZBlobs(MRZ &);
		static void getHiResMRZImg(cv::Mat const&, MRZ &);
		void improveSegmentation(MRZ &);
		int isCloseToBoundary(MRZ &, MRZLines &, cv::Mat &);
		bool isGoodIDLLine(cv::Mat const&, cv::Mat const&, MRZGeom const&, Line &);
		bool isIncluded(cv::KeyPoint &, cv::KeyPoint &);
		bool isParallel(Line &, Line &, cv::Size_<int>);
		bool isParallel(vector<Line> &, Line&, cv::Size_<int>);
		cv::Size_<float> makeAllBlobsEqual(vector<vector<cv::Ptr<Blob>>> &);
		void rotateImageBlobsLines(cv::Mat const&, MRZGeom const&, cv::Mat&, MRZLines &);
		void sortBlobsOfMRZ(vector<vector<cv::Ptr<Blob>>> &);
		void trySplitLongBlobLine(vector<vector<cv::Ptr<Blob>>> &, Line &, MRZFormat &, cv::Mat &, Line &, Line &);
		bool tryToFindBlobsOnLineEnds(cv::Mat &, MRZFormat &, float, bool, MRZLines &);
		bool tryToFindBlobsOnLineEnds(cv::Mat &, MRZFormat &, float, bool, vector<vector<cv::Ptr<Blob>>> &);
		void tryToSplitLargeBlob(MRZ &);
		void uniteCrossingBlobs(MRZ &);
		void updateMRZByPossibleFlipping(MRZ &);
	public:
		float						  m_rMRZD_field_0;
		float						  m_rMRZD_field_4;
		shared_ptr<MRZDetectorParams> m_spMRZD_field_8;
		FastBlobDetector              m_xMRZD_field_10;
		ERTreesOpt *                  m_pMRZD_field_3C;
	};

	inline
		bool compPtrBlob240x(cv::Ptr<Blob> & a1, cv::Ptr<Blob> & a2)
	{
		return a1->m_vBlob_field_24[0].x < a2->m_vBlob_field_24[0].x;
	}

	inline
		bool compPtrBlob1C(cv::Ptr<Blob> & a1, cv::Ptr<Blob> & a2)
	{
		return a1->m_rBlob_field_1C < a2->m_rBlob_field_1C;
	}

	inline
		bool compBlob0x(Blob & a1, Blob & a2)
	{
		return a1.m_xBlob_field_0.x < a2.m_xBlob_field_0.x;
	}

	inline
		bool compBlob1C(Blob & a1, Blob & a2)
	{
		return a1.m_rBlob_field_1C < a2.m_rBlob_field_1C;
	}


	inline
		bool compLine14(Line & a1, Line & a2)
	{
		return fabsf(a1.m_rLine_field_14) < fabsf(a2.m_rLine_field_14);
	}

	inline
		bool compLine1C(Line & a1, Line & a2)
	{
		return a1.m_rLine_field_1C < a2.m_rLine_field_1C;
	}


	inline
		bool compLine00(Line & a1, Line & a2)
	{
		return a1.m_xLine_field_0.val[0] < a2.m_xLine_field_0.val[0];
	}
	
	inline
		bool compMLIdx10(MRZDetector::MRZLinesIdx & a1, MRZDetector::MRZLinesIdx & a2)
	{
		return a1.m_rMRZLI_field_10  < a2.m_rMRZLI_field_10;
	}
}