#pragma once

namespace mrz_detector
{
	class MRZDetectorProcess;
	class MRZDetectorProcessSingleton
	{
	public:
		static MRZDetectorProcess * free(void);
		static MRZDetectorProcess * obj(void);
		static MRZDetectorProcess * pObj(bool);
	};
}
