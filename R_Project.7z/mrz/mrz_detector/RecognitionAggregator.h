#pragma once
#include "../../pch.h"
#include "RecognitionResult.h"

namespace mrz_detector
{
	class IRecognitionAggregator
	{
	public:
		list<RecognitionResult>  m_lIRA_field_4;

	public:
		virtual ~IRecognitionAggregator();
		virtual void getIfReady(RecognitionResult &) = 0;
		virtual void clear(void);
		virtual void operator+=(RecognitionResult const&);
	};

	class RecognitionAggregator : public IRecognitionAggregator
	{
	public:
		int m_nRA_field_10;
	public:
		RecognitionAggregator();
		~RecognitionAggregator();

		void getIfReady(RecognitionResult &);
	};
}
