#pragma once
#include "../../pch.h"

namespace mrz_detector
{
	class BlobEvaluator
	{
	public:
		BlobEvaluator();
		~BlobEvaluator();
		float askBoost(cv::Mat &a1);
		void calcFeatures(cv::Mat &a1, cv::Mat &a2);
		float eval(cv::Mat &a1);
		//bool load(std::string &a1);
	private:
		cv::Ptr<cv::ml::Boost> m_sBE_field_0;
	};
}