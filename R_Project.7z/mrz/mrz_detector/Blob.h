#pragma once
#include "../../pch.h"

namespace mrz_detector
{
	class Blob
	{
	public:
		cv::Point2f              m_xBlob_field_0;
		float                    m_rBlob_field_8;
		float                    m_rBlob_field_C;
		int                      m_nBlob_field_10;
		int                      m_nBlob_field_14;
		int                      m_nBlob_field_18;
		float                    m_rBlob_field_1C;
		float                    m_rBlob_field_20;
		vector<cv::Point2f>      m_vBlob_field_24;
		float                    m_rBlob_field_30;

	public:
		Blob();
		~Blob();
		Blob(Blob&&);
		Blob(Blob const&);
		Blob& operator=(Blob const&);
		Blob& operator=(Blob&&);

		void contour2Rect(void);
		void perspectiveTransform(cv::Mat &);
		void rotate180(cv::Size const&);
		void rotateBlobAndTransformContour2Rect(cv::Mat const&);
		cv::Point2f rotRectCenter(void);
		void scale(float);
		void translate(float, float);
	};
}
