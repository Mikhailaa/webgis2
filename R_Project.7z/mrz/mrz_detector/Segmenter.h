#pragma once
#include "../../pch.h"

namespace mrz_detector
{
	class Segmenter
	{
	public:
		float m_rSeg_field_0;
		int   m_nSeg_field_4;
		float m_rSeg_field_8;
		float m_rSeg_field_C;
	public:
		Segmenter();
		void deleteWhiteBorders(cv::Rect_<int> &, cv::Mat &);
		bool bottomIsBlack(cv::Mat &);
		bool isBlack(cv::Mat const&);
		bool leftIsBlack(cv::Mat &);
		int noAccessViolation(cv::Rect_<int> &, cv::Size_<int> const&);
		void normalizeContrast(cv::Mat &);
		bool rightIsBlack(cv::Mat &);
		void segmentize(cv::Rect_<int> &, cv::Mat &, cv::Mat &, cv::Size_<float> &, bool, bool);
		float threshold(cv::Mat &, cv::Mat &, int);
		bool topIsBlack(cv::Mat &);
		bool updateROI(int, cv::Mat &, cv::Size_<int> const&, cv::Rect_<int> &, cv::Size_<float> &);
	};
}