#pragma once
#include "../../pch.h"
#include "Blob.h"
#include "BlobEvaluator.h"
#include "mrz_detector.h"


namespace mrz_detector
{
	typedef bool FastBlobDetectorStatus;

	class FastBlobDetector
	{
		class BlobFilterParams
		{
		public:
			BlobFilterParams()
			{
				fBFP_field_0 = 0;
				rBFP_field_4 = 0.0f;
				rBFP_field_8 = 0.0f;
				fBFP_field_C = 0;
				rBFP_field_10 = 0.0f;
				rBFP_field_14 = 0.0f;
				nBFP_field_18 = 20;
				nBFP_field_1C = 100;
			}
		public:
			bool  fBFP_field_0;
			float rBFP_field_4;
			float rBFP_field_8;
			bool  fBFP_field_C;
			float rBFP_field_10;			
			float rBFP_field_14;
			int   nBFP_field_18;
			int   nBFP_field_1C;
		};

	public:
		FastBlobDetector();
		~FastBlobDetector();
		bool  isContourLargeQuadrangle(vector<cv::Point_<int>>&, float);
		int   isContourGood(vector<cv::Point> &, cv::Mat &, cv::Mat &, cv::Point_<double> &, double &);
		void getBlobsFromContours(cv::Mat &, cv::Mat &, cv::Size_<int> const&, vector<vector<cv::Point_<int>>> &, vector<cv::Vec<int, 4>> &, vector<Blob> &, FastBlobDetectorStatus &);
		bool  detect(cv::Mat&, vector<Blob>&, cv::Mat&, float a5, float a6, float a7, float a8, int a9, int a10, DataForBlobSaving *a11);
		float estimateMeanSymbolsize(cv::Mat &, float , float );
		void  binarize(cv::Mat &, cv::Mat &, cv::Mat &, float , float , bool );

		static void setBlobsId(vector<Blob>&);
	public:
		int              m_nFBD_field_0;
		BlobEvaluator    m_xFBD_field_4;
		BlobFilterParams m_xFBD_field_C;
		static int m_lastUsedBlobId;
	};
}
