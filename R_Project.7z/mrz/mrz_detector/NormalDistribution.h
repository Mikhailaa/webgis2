#pragma once
#include "../../pch.h"

namespace mrz_detector
{
	class NormalDistribution
	{
	public:
		float m_rND_field_0;
		float m_rND_field_4;
		float m_rND_field_8;
	public:
		NormalDistribution();
		NormalDistribution(vector<float> &);
		~NormalDistribution();
		
		void calcMeanAndDev(vector<float> &);
		void calcMeanAndDev(vector<float> &, vector<uint> &);
		float logProb(float);
	};
}
