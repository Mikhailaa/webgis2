#pragma once
#include "processparams.h"

enum eRPRM_GetImage_Modes
{
	RPRM_GetImage_Modes_4 = 0x4,
	RPRM_GetImage_Modes_10 = 0x10,
	RPRM_GetImage_Modes_20 = 0x20,
	RPRM_GetImage_Modes_40 = 0x40,
	RPRM_GetImage_Modes_80 = 0x80,
	RPRM_GetImage_Modes_84 = 0x84,
	RPRM_GetImage_Modes_100 = 0x100,
	RPRM_GetImage_Modes_200 = 0x200,
	RPRM_GetImage_Modes_10000 = 0x10000,
};

class ProcessParamsHolder
{
public:
	ProcessParamsHolder();
	ProcessParamsHolder(string &);
	~ProcessParamsHolder();

	void ExtendProcessingMode(void);
	bool getOption(processparams::eProcessMode const&);
	void initDefaults(void);
	bool NeedProcess(void);
	void SetMode(eRPRM_GetImage_Modes, bool);
	void setOption(processparams::eProcessMode const&, bool);
	void setOption(string const&, bool);
	void SetProcessAuth(unsigned long long);
	void SetProcessParam(uint);
	string ToString(void);

public:
	string					m_sPPH_scenario;
	int                     m_nPPH_C;
	int                     m_nPPH_10;
	int                     m_nPPH_14;
	uint                    m_nPPH_processParam; //int
	int                     m_nPPH_1C; //int
	unsigned long long      m_llPPH_processAuth; //long long
	int                     m_nPPH_28;
	int                     m_nPPH_2C;
	int			            m_nPPH_30; //int
	int			            m_nPPH_34; //int
	bool		            m_fPPH_doExtendProcessingMode; //bool
	bool		            m_fPPH_singleImageProcess;////////////////
	bool		            m_fPPH_doDetectCan;//int ? bool*4//
	bool		            m_fPPH_doFlipYAxis;              //
	bool                    m_fPPH_doLex;////////////////
	bool                    m_fPPH_log; //bool
	bool                    m_fPPH_stopOnMrz; //bool
	string                  m_sPPH_dateFormat;
	int						m_nPPH_measureSystem;
	int			            m_nPPH_lexAnalysisDepth;
	int			            m_nPPH_minimalHolderAge;
	bool		            m_fPPH_serializeContainers; //bool
	bool		            m_fPPH_debugSaveRFIDSession; //bool
	int			            m_nPPH_barcodeParserType; //int 
	bool		            m_fPPH_codeConvertRusCodes; //bool
	bool		            m_fPPH_xmlResults; //bool
	unordered_map<processparams::eProcessMode, bool>	m_umPPH_64;
	vector<int>             m_vPPH_documentIdList;
	vector<int>             m_vPPH_fieldTypesFilter;
	vector<uint>			m_vPPH_resultTypeOutput;
};