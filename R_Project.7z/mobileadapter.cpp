#include "mobileadapter.h"
#include "Json/Value.h"
#include "common/container/jsoncpp.h"
#include "imageConvertor.h"

recursive_mutex g_mutex_1140F70;

namespace mobileadapter
{
	int convertParam(eProcessCommands a1, void *a2, char const*a3, common::container::RclHolder &a4, string &a5, bool &a6)
	{
		a6 = false;
		if (a3)
		{
			a5.clear();
			a5 = a3;
		}

		Json::Value v25(Json::json_type_null);
		if (a5.size() && common::container::jsoncpp::convert(a5, v25))
			return 2;
		if (a1 >= ProcessCommands_2F44 && a1 <= ProcessCommands_2F4F)
		{
			if (a1 == ProcessCommands_2F45 || a1 == ProcessCommands_2F46 || a1 == ProcessCommands_2F48 || a1 == ProcessCommands_2F4F)
			{
				if (a2 == 0)
					return 2;
				v25["processParam"]["doFlipYAxis"] = Json::Value(true);
				if (v25["imageInputParam"].isMember("isLastImage"))
				{
					if (!v25["imageInputParam"]["isLastImage"].asBool())
						a6 = true;
				}
				imageConvertor::fromBytesToContainer(v25, a2, a4);
			}
			else
			{
				if (a1 == ProcessCommands_2F44 && a2)
					a4.addNoCopy(*((TResultContainerList *)a2));
			}
		}
		if (!v25.isNull())
			common::container::jsoncpp::convert(v25, a5);
		return 0;
	}

	int process(int a1, void *a2, char const*a3, void **a4, char **a5)
	{
		int nRet;
		if (!g_mutex_1140F70.try_lock())
			return 1;
		if (a4)
			*a4 = 0;
		if (a5)
			*a5 = 0;
		static common::container::RclHolder g_rclHolder_1140F78;
		if (a1 == 0x2F49)
			g_rclHolder_1140F78.clear();
		string v16;
		bool v15 = false;
		nRet = convertParam((eProcessCommands)a1, a2, a3, g_rclHolder_1140F78, v16, v15);
		if (nRet)
		{
			v15 = true;
		}
		else if (v15)
		{
			nRet = 0;
		}
		else
		{
			nRet = processgl(a1, &g_rclHolder_1140F78.m_xTRCL, v16.data(), a4, a5);
			g_rclHolder_1140F78.clear();
		}
		g_mutex_1140F70.unlock();
		return nRet;
	}
}
