#pragma once
#include "pch.h"
#include "common/container/RclHolder.h"

namespace imagemanipulation
{
	class integralImageData
	{
	public:
		cv::Mat m_xiI_0;
		cv::Mat m_xiI_38;
		cv::Mat m_xiI_70;
		int     m_niI_A8;
	public:
		integralImageData();
		~integralImageData();

		void clear(void);
	};

	void addImageToResultRcl(cv::Mat const&, eRPRM_Lights, common::container::RclHolder &);
	bool checkBackgroundLight(common::container::RclHolder &);
	int checkObjectColor(cv::Mat const&, tFullColors_cv, eCheckDiagnose &, tFullColors_cv&, bool);
	void convertImage24to8ByFieldDesc(cv::Mat &, cv::Mat &, int);
	int  enhancementContrastUV(cv::Mat &);
	int generateIntegralImage(common::container::RclHolder &, integralImageData &);
	void getMaskForImage(cv::Mat&, cv::Mat&);
	int getTextRects(common::container::RclHolder &, cv::Mat &, vector<cv::Rect> &, cv::Rect&);
	void filterMaskByOCRFileds(vector<cv::Rect> const&, cv::Mat &);
	bool isDullPaper(cv::Mat &, int);
	int replaceUVByDiff(common::container::RclHolder &, common::container::RclHolder &, float, basic_string<char> const&); //###
	void uniteImages(cv::Mat const&, cv::Mat const&, cv::Mat&, cv::Mat&, cv::Mat&);
}