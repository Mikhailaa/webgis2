#pragma once
#include "commonStruct.h"

namespace docformatinfo {

	CDocFormat getDocFormatByMM(float, float, float, CDocFormat);

	CDocFormat getDocFormatByProportion(float, float, int &, float, CDocFormat);

	int docSizeMM(CDocFormat, float &, float &);

	Size2f docSizeMM(CDocFormat);

	Size2f docSizeMMLaminate(CDocFormat);

	int docSizeMMLaminate(CDocFormat, float &, float &);

	int getPpmForImageSize(Size2f const&, Size2f const&);

	int getPpmForImageSize(Size2f const&a1, CDocFormat a2);

	Size2f getImageSizeForPpm(int, Size2f const&);
};