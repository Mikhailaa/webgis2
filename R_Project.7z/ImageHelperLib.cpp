#include "ImageHelperLib.h"

IImageHelper::IImageHelper()
{
	m_pxIHL_4 = 0;
	m_pfIHL_8 = 0;
}

IImageHelper::~IImageHelper()
{
	Release();
}

void IImageHelper::Release()
{
	m_pfIHL_8 = 0;
	ReleaseImage();
}

TResultContainer *IImageHelper::AllocResultContainer(TResultContainer *a1)
{
	if (!a1)
		return 0;
	TResultContainer *v2 = new TResultContainer;
	memclr(v2, sizeof(TResultContainer));
	v2->u.pTRC_RIC = FullDuplicateTRawImageContainer(a1->u.pTRC_RIC);
	if (!v2->u.pTRC_RIC)
	{
		delete v2;
		return 0;
	}
	v2->nTRC_result_type = 1;
	v2->nTRC_light = RPRM_Lights_6;
	v2->nTRC_buf_length = 4;
	v2->u1.nTRC_XML_length = 0;
	v2->pTRC_XML_buffer = 0;
	v2->nTRC_list_idx = 0;
	v2->nTRC_page_idx = 0;
	return v2;
}

TRawImageContainer *IImageHelper::FullDuplicateTRawImageContainer(TRawImageContainer *a1)
{
	TRawImageContainer *v2 = 0;
	if (a1)
	{
		TRawImageContainer *v3 = new TRawImageContainer;
		v3->pxRIC_bmi = 0;
		v3->pRIC_data = 0;
		if (a1->pxRIC_bmi)
		{
			if (a1->pRIC_data)
			{
				v3->pxRIC_bmi = new tagBITMAPINFO;
				v3->pRIC_data = new uchar[a1->pxRIC_bmi->bmiHeader.biSizeImage];
				memcpy(v3->pxRIC_bmi, a1->pxRIC_bmi, sizeof(tagBITMAPINFO));
				memcpy(v3->pRIC_data, a1->pRIC_data, a1->pxRIC_bmi->bmiHeader.biSizeImage);
			}
		}
		v2 = v3;
	}
	return v2;
}

void IImageHelper::ReleaseImage()
{
	if (m_pxIHL_4)
	{
		if (m_pxIHL_4->nTRC_result_type == 1 && m_pxIHL_4->u.pTRC_RIC)
		{
			if (m_pxIHL_4->u.pTRC_RIC->pxRIC_bmi)
				delete[] m_pxIHL_4->u.pTRC_RIC->pxRIC_bmi;
			delete[] m_pxIHL_4->u.pTRC_RIC->pRIC_data;
			delete m_pxIHL_4->u.pTRC_RIC;
		}
		if (m_pxIHL_4)
			delete m_pxIHL_4;
		m_pxIHL_4 = 0;
	}
}

int IImageHelper::InitFromBuffer(uchar *a2, uint a3)
{
	if (!m_pfIHL_8)
		return 6;
	ReleaseImage();
	void* v9[3];
	v9[0] = a2;
	v9[1] = (void*)a3;
	v9[2] = 0;
	imaging::RI_Parameters v12;
	TResultContainer *v8 = 0;
	v12.pRIP_0 = &v9;
	v12.pRIP_4 = &v8;
	int result = m_pfIHL_8(imaging::RI_Commands_A, &v12);
	if (!result)
	{
		m_pxIHL_4 = IImageHelper::AllocResultContainer(v8);
		result = 0;
	}
	return result;
}

TResultContainer *IImageHelper::init(TResultContainer *a2)
{
	m_pxIHL_4 = IImageHelper::AllocResultContainer(a2);
	return m_pxIHL_4;
}

int IImageHelper::WriteToBuffer(imaging::RI_SaveFileParameters *a2)
{
	int nRet;
	if (m_pfIHL_8)
	{
		if (a2)
		{
			if (a2->pxSFP_8)
			{
				ReleaseImage();
			}
			else
			{
				a2->pxSFP_8 = m_pxIHL_4;
			}
			imaging::RI_Parameters v11;
			v11.pRIP_0 = a2;
			v11.pRIP_4 = 0;
			nRet = m_pfIHL_8(imaging::RI_Commands_9, &v11);
			if (!nRet)
			{
				if (a2->pnSFP_14 && a2->ppSFP_10)
				{
					uchar* v9 = new uchar[*a2->pnSFP_14];
					memcpy(v9, *a2->ppSFP_10, *a2->pnSFP_14);
					v11.pRIP_0 = *a2->ppSFP_10;
					v11.pRIP_4 = 0;
					m_pfIHL_8(imaging::RI_Commands_0, &v11);
					*a2->ppSFP_10 = v9;
				}
			}
		}
		else
		{
			nRet = 2;
		}
	}
	else
	{
		nRet = 6;
	}
	return nRet;
}

int IImageHelper::WriteToFile(imaging::RI_SaveFileParameters *a2)
{
	if (!m_pfIHL_8)
		return 6;
	if (a2->pxSFP_8)
	{
		ReleaseImage();
	}
	else
	{
		a2->pxSFP_8 = m_pxIHL_4;
	}
	imaging::RI_Parameters v7;
	v7.pRIP_0 = a2;
	v7.pRIP_4 = 0;
	return m_pfIHL_8(imaging::RI_Commands_3, &v7);
}

int IImageHelper::WriteToFile(wchar_t const*a2, imaging::eRI_ImageFormats a3)
{
	if (!m_pfIHL_8)
		return 6;
	if (!m_pxIHL_4)
		return 5;
	if (!a2)
		return 2;
	imaging::RI_Parameters v6;
	imaging::RI_SaveFileParameters v7;
	v7.pnSFP_14 = 0;
	v7.pxSFP_8 = m_pxIHL_4;
	v7.nSFP_C = (int)a2;
	v7.ppSFP_10 = 0;
	v7.nSFP_4 = 75;
	if (a3 == imaging::RI_ImageFormats_FF)
		a3 = imaging::RI_ImageFormats_1;
	v7.nSFP_0 = a3;
	v6.pRIP_4 = 0;
	v6.pRIP_0 = &v7;
	return m_pfIHL_8(imaging::RI_Commands_3, &v6);
}

int IImageHelper::GetImageInfoFromBuffer(uchar *a2, uint a3, imaging::RI_ImageInfo *a4)
{
	if (!m_pfIHL_8)
		return 1;
	ReleaseImage();
	imaging::RI_Parameters v9;
	void *v10[3];
	v10[0] = a2;
	v10[1] = (void*)a3;
	v10[2] = 0;
	v9.pRIP_4 = a4;
	v9.pRIP_0 = v10;
	return m_pfIHL_8(imaging::RI_Commands_B, &v9);
}

TRawImageContainer *IImageHelper::GetRawImageContainer(void)
{
	TRawImageContainer* result;
	if (m_pxIHL_4 && m_pxIHL_4->nTRC_result_type == 1)
		result = m_pxIHL_4->u.pTRC_RIC;
	else
		result = 0;
	return result;
}

CImageHelperLib::CImageHelperLib()
{
	m_pfIHL_8 = imaging::ExecuteCommand;
}

CImageHelperLib::~CImageHelperLib()
{
}

void CImageHelperLib::Release()
{
}