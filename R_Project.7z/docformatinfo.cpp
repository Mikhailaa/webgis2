#include "docformatinfo.h"

namespace docformatinfo {

	CDocFormat getDocFormatByMM(float a1, float a2, float a3, CDocFormat a4)
	{
		static vector<CDocFormat> g_vec_1141078 = { DOCFORMAT_0, DOCFORMAT_1, DOCFORMAT_6, DOCFORMAT_2, DOCFORMAT_5, DOCFORMAT_4 };

		float r_s22 = 0.0f;
		for (uint i = 0; i < g_vec_1141078.size(); i++)
		{
			Size2f v29 = docSizeMM(g_vec_1141078[i]);
			Size2f v27 = docSizeMMLaminate(g_vec_1141078[i]);
			float r_s30 = fminf(fabsf(a1 - v29.width) / a1, 1.0f);
			float r_s28 = fminf(fabsf(a2 - v29.height) / a2, 1.0f);
			float r_s26 = (1.0f - r_s30) * (1.0f - r_s28);
			if (v27.width)
			{
				float r_s17 = fminf(fabsf(a1 - v27.width) / a1, 1.0f);
				float r_s0 = fminf(fabsf(a2 - v27.height) / a2, 1.0f);
				float r_s2 = (1.0f - r_s17) * (1.0f - r_s0);
				if (r_s2 > r_s26)
				{
					r_s28 = r_s0;
					r_s30 = r_s17;
					r_s26 = r_s2;
				}
			}
			if (r_s30 <= a3 && r_s28 <= a3)
			{
				if (r_s26 > r_s22)
				{
					r_s22 = r_s26;
					a4 = g_vec_1141078[i];
				}
			}
		}
		return a4;
	}

	CDocFormat getDocFormatByProportion(float a1, float a2, int &a3, float a4, CDocFormat a5)
	{
		static vector<CDocFormat> g_vec_1141084 = { DOCFORMAT_0, DOCFORMAT_2 };

		float r_s22 = 1.0f;
		float r_s18 = a4;
		Size2f v22;
		for (uint i = 0; i < g_vec_1141084.size(); i++)
		{
			v22 = docSizeMM(g_vec_1141084[i]);
			float r_s0 = fminf(fabsf((a1 / a2) - (v22.width / v22.height)) / (v22.width / v22.height), 1.0f);
			if (r_s0 <= r_s18 && r_s0 < r_s22)
			{
				r_s22 = r_s0;
				a5 = g_vec_1141084[i];
			}
		}
		a3 = 0;
		v22 = docSizeMM(a5);
		if (v22.width)
			a3 = (int)((a1 / v22.width) * 1000.0f);

		return a5;
	}

	int docSizeMM(CDocFormat a1, float &a2, float &a3)
	{
		switch (a1)
		{
		case DOCFORMAT_0:
			a3 = 54.0f;
			a2 = 85.6f;
			break;
		case DOCFORMAT_1:
			a3 = 74.0f;
			a2 = 105.0f;
			break;
		case DOCFORMAT_2:
			a3 = 88.0f;
			a2 = 125.0f;
			break;
		case DOCFORMAT_4:
			a3 = 210.0f;
			a2 = 297.0f;
			break;
		case DOCFORMAT_5:
			a3 = 125.0f;
			a2 = 176.0f;
			break;
		case DOCFORMAT_6:
			a3 = 65.5f;
			a2 = 92.5f;
			break;
		default:
			a3 = 0.0f;
			a2 = 0.0f;
			break;
		}
		return 0;
	}

	Size2f docSizeMM(CDocFormat a2)
	{
		Size2f a1 = {0.0f, 0.0f};
		docSizeMM(a2, a1.width, a1.height);
		return a1;
	}

	Size2f docSizeMMLaminate(CDocFormat a2)
	{
		Size2f a1 = { 0.0f, 0.0f };
		docSizeMMLaminate(a2, a1.width, a1.height);
		return a1;
	}

	int docSizeMMLaminate(CDocFormat a1, float &a2, float &a3)
	{
		if (a1 == DOCFORMAT_1)
		{
			a3 = 68.0f;
			a2 = 100.0f;
		}
		else if (a1)
		{
			a3 = 0.0f;
			a2 = 0.0f;
		}
		else
		{
			a3 = 50.0f;
			a2 = 81.6f;
		}
		return 0;
	}

	int getPpmForImageSize(Size2f const&a1, Size2f const&a2)
	{
		float v2 = a2.width;
		if (a2.width < a2.height)
			v2 = a2.height;
		if (v2 == 0.0f)
			return 0;
		float v4 = a1.width;
		if (a1.width < a1.height)
			v4 = a1.height;
		return (int)((v4 * 1000.0f) / v2);
	}

	int getPpmForImageSize(Size2f const&a1, CDocFormat a2)
	{
		return docformatinfo::getPpmForImageSize(a1, docSizeMM(a2));
	}

	Size2f getImageSizeForPpm(int a2, Size2f const&a3)
	{
		Size2f result;
		result.width = (a3.width * a2) / 1000.0f;
		result.height = (a3.height * a2) / 1000.0f;;
		return result;
	}
};