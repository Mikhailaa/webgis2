#include "ProcessParamsHolder.h"
#include "common/container/json.h"
#include "regula.h"

ProcessParamsHolder::ProcessParamsHolder()
{
	initDefaults();
}

ProcessParamsHolder::ProcessParamsHolder(string& a2)
{
	initDefaults();
	regula::ProcessParameters v40;
	vector<string> v39(v40.m_xPP_C);
	GenericDocument<UTF8<char>> v44 = common::container::json::ReadString(a2);
	if (!v44.HasParseError() && !v44.ObjectEmpty())
	{
		GenericValue<UTF8<char>>* val = common::container::json::GetMember(v44, string("processParam"));
		if (!val->ObjectEmpty() && !val->IsNull())
		{
			common::container::json::stringFromJson(*val, m_sPPH_scenario, string("scenario"));
			common::container::json::uint32FromJson(*val, m_nPPH_processParam, string("processParam"));
			common::container::json::uint64FromJson(*val, m_llPPH_processAuth, string("processAuth"));
			for (vector<string>::iterator iter = v39.begin(); iter != v39.end(); iter++)
			{
				int v21 = v40.getImageModes(*iter);
				int v24 = 0;
				if (!val->IsNull())
				{
					const char* v20 = (*iter).data();
					if (v20 && !val->ObjectEmpty())
					{
						bool v43 = false;
						common::container::json::boolFromJson(*val, v43, string(v20, strlen(v20)));
						if (v43) v24 = v21;
					}
				}
				m_nPPH_processParam |= v24;
			}
			for (GenericValue<UTF8<char>>::MemberIterator iter = val->MemberBegin(); iter != val->MemberEnd(); iter++)
			{
				if (iter->value.IsBool())
				{
					const char* v28 = iter->name.GetString();
					setOption(string(v28, strlen(v28)), iter->value.IsTrue());
				}
			}
			common::container::json::boolFromJson(*val, m_fPPH_doExtendProcessingMode, string("doExtendProcessingMode"));
			common::container::json::boolFromJson(*val, m_fPPH_singleImageProcess, string("singleImageProcess"));
			common::container::json::boolFromJson(*val, m_fPPH_doDetectCan, string("doDetectCan"));
			common::container::json::boolFromJson(*val, m_fPPH_doFlipYAxis, string("doFlipYAxis"));
			common::container::json::boolFromJson(*val, m_fPPH_doLex, string("doLex"));
			common::container::json::intFromJson(*val, m_nPPH_lexAnalysisDepth, string("lexAnalysisDepth"));
			common::container::json::intFromJson(*val, m_nPPH_minimalHolderAge, string("minimalHolderAge"));
			common::container::json::stringFromJson(*val, m_sPPH_dateFormat, string("dateFormat"));
			common::container::json::intFromJson(*val, m_nPPH_measureSystem, string("measureSystem"));
			common::container::json::intFromJson(*val, m_nPPH_barcodeParserType, string("barcodeParserType"));
			common::container::json::boolFromJson(*val, m_fPPH_codeConvertRusCodes, string("codeConvertRusCodes"));
			common::container::json::boolFromJson(*val, m_fPPH_log, string("log"));
			common::container::json::boolFromJson(*val, m_fPPH_stopOnMrz, string("stopOnMrz"));
			common::container::json::boolFromJson(*val, m_fPPH_serializeContainers, string("serializeContainers"));
			common::container::json::ArrayFromJson<int>(*val, m_vPPH_documentIdList, "documentIdList");
			common::container::json::ArrayFromJson<int>(*val, m_vPPH_fieldTypesFilter, "fieldTypesFilter");
			common::container::json::ArrayFromJson<uint>(*val, m_vPPH_resultTypeOutput, "resultTypeOutput");
			common::container::json::boolFromJson(*val, m_fPPH_debugSaveRFIDSession, string("debugSaveRFIDSession"));
			common::container::json::boolFromJson(*val, m_fPPH_xmlResults, string("xmlResults"));
		}
	}
	ExtendProcessingMode();
}

ProcessParamsHolder::~ProcessParamsHolder()
{
}

void ProcessParamsHolder::ExtendProcessingMode(void)
{
	if (m_fPPH_doExtendProcessingMode)
	{
		int n2 = m_nPPH_processParam;
		int n4 = n2 | 8;
		m_nPPH_processParam = n4;

		if (m_fPPH_doDetectCan)
		{
			n4 = n2 | 0x18;
		}

		int n5 = 0x20;

		if (!(n4 & 0x200))
		{
			n5 = (n4 >> 2) & 0x20;
		}

		int n6 = n5 | n4;
		int n7 = n6 & 0x2A0;
		if (n6 & 0x20)
			n6 |= 0x50;
		int n8 = n6 | 4 * (n6 & 4);
		int n10 = n7 | n8 & 0x14;

		if (n10 || m_fPPH_doDetectCan)
		{
			if (n8 & 0x10)
				n8 |= 0x8008;
			m_nPPH_processParam = n8;
		}

		if (getOption(processparams::PROCESSMODE_rfid))
		{
			m_nPPH_processParam |= 0x40u;
		}
	}
}
bool ProcessParamsHolder::getOption(processparams::eProcessMode const& a2)
{
	unordered_map<processparams::eProcessMode, bool>::iterator umiter = m_umPPH_64.find(a2);

	if (umiter != m_umPPH_64.end())
	{
		return umiter->second;
	}

	return false;
}
void ProcessParamsHolder::initDefaults(void)
{
	m_nPPH_30 = 0;
	m_nPPH_34 = 0;
	m_fPPH_doExtendProcessingMode = 1;
	m_nPPH_lexAnalysisDepth = 0;
	m_nPPH_minimalHolderAge = 0;

	m_fPPH_log = 0;
	m_fPPH_stopOnMrz = 0;

	m_fPPH_singleImageProcess = 0;
	m_fPPH_doDetectCan = 0;
	m_fPPH_doFlipYAxis = 0;
	m_fPPH_doLex = 0;

	m_fPPH_serializeContainers = 1;
	m_llPPH_processAuth = 0;
	m_nPPH_28 = 0;
	m_nPPH_2C = 0;

	m_nPPH_C = 0;
	m_nPPH_10 = 0;
	m_nPPH_14 = 0;
	m_nPPH_processParam = 0;

	m_sPPH_scenario = "Unknown";

	m_fPPH_debugSaveRFIDSession = 0;
	m_nPPH_barcodeParserType = 0;
	m_fPPH_codeConvertRusCodes = 0;
}

bool ProcessParamsHolder::NeedProcess(void)
{
	if (m_nPPH_processParam)
	{
		return true;
	}

	return (m_fPPH_doLex != 0);

}

void ProcessParamsHolder::SetMode(eRPRM_GetImage_Modes a2, bool a3)
{
	if (a3)
	{
		m_nPPH_processParam |= a2;
	}
	else
	{
		m_nPPH_processParam &= ~a2;
	}
}

void ProcessParamsHolder::setOption(processparams::eProcessMode const & a2, bool a3)
{
	m_umPPH_64[a2] = a3;
}

void ProcessParamsHolder::setOption(string const & a2, bool a3)
{
	setOption(processparams::ProcessModeConvertor::convert(a2), a3);
}

void ProcessParamsHolder::SetProcessAuth(unsigned long long a2)
{
	m_llPPH_processAuth = a2;
}

void ProcessParamsHolder::SetProcessParam(uint a2)
{
	m_nPPH_processParam = a2;
	ExtendProcessingMode();
}

string ProcessParamsHolder::ToString(void)
{
	GenericDocument<UTF8<char>> xGD42(kObjectType);
	GenericValue<UTF8<char>> xGV38(kObjectType);

	if (m_nPPH_processParam & 0x10000)
		xGV38.AddMember(GenericStringRef<char>("imageQA"), true, xGD42.GetAllocator());
	if (m_nPPH_processParam & 8)
		xGV38.AddMember(GenericStringRef<char>("images"), true, xGD42.GetAllocator());
	if (m_nPPH_processParam & 0x40)
		xGV38.AddMember(GenericStringRef<char>("mrz"), true, xGD42.GetAllocator());
	if (m_nPPH_processParam & 0x80)
		xGV38.AddMember(GenericStringRef<char>("ocr"), true, xGD42.GetAllocator());
	if (m_nPPH_processParam & 4)
		xGV38.AddMember(GenericStringRef<char>("graphics"), true, xGD42.GetAllocator());
	if (m_nPPH_processParam & 0x100)
		xGV38.AddMember(GenericStringRef<char>("barcode"), true, xGD42.GetAllocator());
	if (m_nPPH_processParam & 0x8000)
		xGV38.AddMember(GenericStringRef<char>("detect"), true, xGD42.GetAllocator());
	if (m_nPPH_processParam & 0x10)
		xGV38.AddMember(GenericStringRef<char>("locate"), true, xGD42.GetAllocator());
	if (m_nPPH_processParam & 0x200)
		xGV38.AddMember(GenericStringRef<char>("authenticity"), true, xGD42.GetAllocator());
	if (m_sPPH_scenario.length())
		common::container::json::AddStringMember(xGV38, m_sPPH_scenario, GenericStringRef<char>("scenario"), 0, xGD42.GetAllocator());
	xGV38.AddMember(GenericStringRef<char>("processParam"), m_nPPH_processParam, xGD42.GetAllocator());
	xGV38.AddMember(GenericStringRef<char>("processAuth"), m_llPPH_processAuth, xGD42.GetAllocator());
	if (!m_fPPH_doExtendProcessingMode)
		xGV38.AddMember(GenericStringRef<char>("doExtendProcessingMode"), false, xGD42.GetAllocator());
	if (m_fPPH_singleImageProcess)
		xGV38.AddMember(GenericStringRef<char>("singleImageProcess"), true, xGD42.GetAllocator());
	if (m_fPPH_doDetectCan)
		xGV38.AddMember(GenericStringRef<char>("doDetectCan"), true, xGD42.GetAllocator());
	if (m_fPPH_doFlipYAxis)
		xGV38.AddMember(GenericStringRef<char>("doFlipYAxis"), true, xGD42.GetAllocator());
	if (m_fPPH_doLex)
		xGV38.AddMember(GenericStringRef<char>("doLex"), true, xGD42.GetAllocator());
	if (m_nPPH_lexAnalysisDepth)
		xGV38.AddMember(GenericStringRef<char>("lexAnalysisDepth"), m_nPPH_lexAnalysisDepth, xGD42.GetAllocator());
	if (m_nPPH_minimalHolderAge)
		xGV38.AddMember(GenericStringRef<char>("minimalHolderAge"), m_nPPH_minimalHolderAge, xGD42.GetAllocator());
	if (m_fPPH_log)
		xGV38.AddMember(GenericStringRef<char>("log"), true, xGD42.GetAllocator());
	if (m_fPPH_stopOnMrz)
		xGV38.AddMember(GenericStringRef<char>("stopOnMrz"), true, xGD42.GetAllocator());
	if (!m_fPPH_serializeContainers)
		xGV38.AddMember(GenericStringRef<char>("serializeContainers"), false, xGD42.GetAllocator());
	for (unordered_map<processparams::eProcessMode, bool>::iterator iter = m_umPPH_64.begin(); iter != m_umPPH_64.end(); iter++)
	{
		string v26 = processparams::ProcessModeConvertor::convert(iter->first);
		xGV38.AddMember(GenericValue<UTF8<char>>(v26.data(), xGD42.GetAllocator()), iter->second, xGD42.GetAllocator());
	}
	if (!m_vPPH_documentIdList.empty())
		xGV38.AddMember(GenericStringRef<char>("documentIdList"), common::container::json::ArrayToJson<int>(m_vPPH_documentIdList, xGD42.GetAllocator()), xGD42.GetAllocator());
	if (!m_vPPH_fieldTypesFilter.empty())
		xGV38.AddMember(GenericStringRef<char>("fieldTypesFilter"), common::container::json::ArrayToJson<int>(m_vPPH_fieldTypesFilter, xGD42.GetAllocator()), xGD42.GetAllocator());
	common::container::json::AddStringMember(xGV38, m_sPPH_dateFormat, GenericStringRef<char>("dateFormat"), false, xGD42.GetAllocator());
	if (m_nPPH_measureSystem)
		xGV38.AddMember(GenericStringRef<char>("measureSystem"), m_nPPH_measureSystem, xGD42.GetAllocator());
	if (m_nPPH_barcodeParserType)
		xGV38.AddMember(GenericStringRef<char>("barcodeParserType"), m_nPPH_barcodeParserType, xGD42.GetAllocator());
	if (m_fPPH_codeConvertRusCodes)
		xGV38.AddMember(GenericStringRef<char>("codeConvertRusCodes"), true, xGD42.GetAllocator());
	xGD42.AddMember(GenericStringRef<char>("processParam"), xGV38, xGD42.GetAllocator());
	GenericStringBuffer<UTF8<char>> v27;
	Writer<GenericStringBuffer<UTF8<char>>> v29(v27);
	xGD42.Accept(v29);
	return v27.GetString();
}

