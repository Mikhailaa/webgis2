#pragma once

namespace utf8
{
	template<typename T>
	T& append(unsigned int a1, T& a2)
	{
		if (a1 > 0x100000 || (a1 & 0xFFFFF800) == 0xD800)
		{
			// throw(utf8::invalid_code_point, std::exception::~exception);
		}
		if (a1 <= 0x7F)
		{
			a2 += (T::value_type)a1;
			return a2;
		}
		if (!(a1 >> 11))
		{
			a2 += ((a1 >> 6) | 0xC0);
			a2 += (a1 | 0x80) & 0xBF;
			return a2;
		}
		if (0 == a1 >> 16)
		{
			a2 += ((a1 >> 12) | 0xE0);
		}
		else
		{
			a2 += ((a1 >> 18) | 0xF0);
			a2 += (((a1 >> 12) | 0x80) & 0xBF);
		}
		a2 += (((a1 >> 6) | 0x80) & 0xBF);
		a2 += ((a1 | 0x80) & 0xBF);
		return a2;
	};

	template<typename T>
	size_t distance(T a1, T a2)
	{
		size_t v3 = 0;
		while (a1 < a2)
		{
			next<T>(a1, a2);
			++v3;
		}
		return v3;
	};

	template<typename T>
	unsigned int next(T &a1, T a2)
	{
		unsigned int v10 = 0;
		int v3 = internal::validate_next<T>(a1, a2, v10);
		if (v3 >= 1 && v3 <= 5)
		{
			//throw;
		}
		return v10;
	};

	template<class _Tx, class _Ty>
	_Ty& replace_invalid(_Tx a1, _Tx a2, _Ty& a3)
	{
		static unsigned int replacement_marker = 0xFFFD;
		return replace_invalid<_Tx, _Ty>(a1, a2, a3, replacement_marker);
	};

	template<class _Tx, class _Ty>
	_Ty& replace_invalid(_Tx a1, _Tx a2, _Ty& a3, unsigned int a4)
	{
		_Tx v4 = a1;
		_Tx v12 = a1;
		_Tx v8;
		while (v4 != a2)
		{
			switch (internal::validate_next<_Tx>(v12, a2))
			{
			case 0:
				while (v4 != v12)
				{
					a3 += *v4;
					v4++;
				}
				break;
			case 1:
				//throw;
				break;
			case 2:
				a3 = append<_Ty>(a4, a3);
				v12++;
				v4 = v12;
				break;
			case 3:
			case 4:
			case 5:
				a3 = append<_Ty>(a4, a3);
				v8 = v12 + 1;
				do
				{
					v4 = v8;
					v12 = v8;
					if (a2 == v8)
						break;
					++v8;
				} while ((*v4 & 0xC0) == 0x80);
				break;
			default:
				v4 = v12;
				break;
			}
		}
		return a3;
	};

	template<class _Tx, class _Ty>
	_Tx& utf32to8(_Ty a1, _Ty a2, _Tx& a3)
	{
		while (a1 != a2)
		{
			a3 = append<_Tx>(*a1, a3);
			++a1;
		}
		return a3;
	};

	template<class _Tx, class _Ty>
	_Ty& utf8to32(_Tx a1, _Tx a2, _Ty& a3)
	{
		while (a1 != a2)
		{
			a3.push_back(next<_Tx>(a1, a2));
		}
		return a3;
	};

	namespace internal
	{
		template<typename T>
		int get_sequence_2(T &a1, T a2, unsigned int &a3)
		{
			if (a1 == a2)
				return 1;
			a3 = *a1;
			int nRet = increase_safely<T>(a1, a2);
			if (!nRet)
			{
				a3 = (*a1 & 0x3F) | ((a3 & 0x1F) << 6);
				return 0;
			}
			return nRet;
		}

		template<typename T>
		int get_sequence_3(T &a1, T a2, unsigned int &a3)
		{
			if (a1 == a2)
				return 1;
			a3 = *a1;
			int nRet = increase_safely<T>(a1, a2);
			if (!nRet)
			{
				a3 = ((a3 << 12) & 0xF03F) | ((*a1 & 0x3F) << 6);
				nRet = increase_safely<T>(a1, a2);
				if (!nRet)
				{
					a3 += (*a1 & 0x3F);
					return 0;
				}
			}
			return nRet;
		}

		template<typename T>
		int get_sequence_4(T &a1, T a2, unsigned int &a3)
		{
			if (a1 == a2)
				return 1;
			a3 = *a1;
			int nRet = increase_safely<T>(a1, a2);
			if (!nRet)
			{
				a3 = ((a3 << 18) & 0x1C0000) | ((*a1 & 0x3F) << 12);
				nRet = increase_safely<T>(a1, a2);
				if (!nRet)
				{
					a3 += (*a1 & 0x3F) << 6;
					nRet = increase_safely<T>(a1, a2);
					if (!nRet)
					{
						a3 += *a1 & 0x3F;
						return 0;
					}
				}
			}
			return nRet;
		}

		template<typename T>
		int increase_safely(T &a1, T a2)
		{
			a1++;
			if (a1 == a2)
				return 1;
			if ((*a1 & 0xC0) != 0x80)
				return 3;
			return 0;
		}

		template<typename T>
		bool is_overlong_sequence(unsigned int a1, T a2)
		{
			if (a1 > 0x7F)
			{
				if (a1 >> 11)
				{
					if ((a1 >> 16) != 0 || a2 == 3)
						return false;
				}
				else if (a2 == 2)
				{
					return false;
				}
				return true;
			}
			if (a2 != 1)
				return true;
			return false;
		}

		template<typename T>
		int sequence_length(T a1)
		{
			if (*a1 > -1)
				return 1;
			if ((*a1 & 0xE0) == 0xC0)
				return 2;
			if ((*a1 & 0xF0) == 0xE0)
				return 3;
			if ((*a1 & 0xF8) == 0xF0)
				return 4;
			return 0;
		}

		template<typename T>
		int validate_next(T &a1, T a2, unsigned int &a3)
		{
			unsigned int v4 = 0;
			unsigned int v11 = 0;
			int v8 = sequence_length<T>(a1);
			int result = 2;
			switch (v8)
			{
			case 0:
				return 2;
			case 1:
				if (a1 != a2)
				{
					v4 = *a1;
					v11 = *a1;
					break;
				}
				return 1;
			case 2:
				result = get_sequence_2<T>(a1, a2, v11);
				if (result)
					return result;
				v4 = v11;
				break;
			case 3:
				result = get_sequence_3<T>(a1, a2, v11);
				if (result)
					return result;
				v4 = v11;
				break;
			case 4:
				result = utf8::internal::get_sequence_4<T>(a1, a2, v11);
				if (result)
					return result;
				v4 = v11;
				break;
			default:
				break;
			}
			result = 5;
			if ((v4 >> 16) <= 0x10 && (v4 & 0xFFFFF800) != 0xD800)
			{
				if (!is_overlong_sequence(v4, v8))
				{
					a3 = v11;
					a1++;
					return 0;
				}
				result = 4;
			}
			return result;
		}

		template<typename T>
		int validate_next(T &a1, T a2)
		{
			unsigned int v3;
			return validate_next<T>(a1, a2, v3);
		}
	};
	
	namespace unchecked
	{
		template<typename T>
		T& append(unsigned int a1, T& a2)
		{
			if (a1 <= 0x7F)
			{
				a2 += (T::value_type)a1;
				return a2;
			}
			if (!(a1 >> 11))
			{
				a2 += ((a1 >> 6) | 0xC0);
				a2 += ((a1 | 0x80) & 0xBF);
				return a2;
			}
			if ((a1 >> 16) == 0)
			{
				a2 += ((a1 >> 12) | 0xE0);
			}
			else
			{
				a2 += ((a1 >> 18) | 0xF0);
				a2 += (((a1 >> 12) | 0x80) & 0xBF);
			}
			a2 += (((a1 >> 6) | 0x80) & 0xBF);
			a2 += ((a1 | 0x80) & 0xBF);
			return a2;
		}

		template<typename T>
		unsigned int next(T &a1)
		{
			unsigned int v3 = *a1;
			int v4 = internal::sequence_length<T>(a1);
			switch (v4)
			{
			case 2:
				a1++;
				v3 = (*a1 & 0x3F) | ((v3 & 0x1F) << 6);
				break;
			case 3:
				a1++;
				v3 = ((v3 << 12) & 0xF03F) | ((*a1 & 0x3F) << 6);
				a1++;
				v3 |= (*a1 & 0x3F);
				break;
			case 4:
				a1++;
				v3 = ((v3 << 18) & 0x1C0000) | ((*a1 & 0x3F) << 12);
				a1++;
				v3 |= ((*a1 & 0x3F) << 6);
				a1++;
				v3 |= (*a1 & 0x3F);
				break;
			default:
				break;
			}
			a1++;
			return v3;
		}

		template<class _Tx, class _Ty>
		_Tx& utf32to8(_Ty a1, _Ty a2, _Tx& a3)
		{
			while (a1 != a2)
			{
				a3 = append<_Tx>(*a1, a3);
				a1++;
			}
			return a3;
		}

		template<class _Tx, class _Ty>
		_Ty& utf8to32(_Tx a1, _Tx a2, _Ty& a3)
		{
			while (a1 < a2)
			{
				a3.push_back(unchecked::next<_Tx>(a1));
			}
			return a3;
		}
	}
}