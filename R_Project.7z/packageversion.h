#pragma once
#include <string>

using namespace std;

namespace packageversion
{
	string getCoreMode(void);
	string getCoreVersion(void);
	string getDocList(void);
};
