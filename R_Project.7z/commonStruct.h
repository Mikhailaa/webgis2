#pragma once

#include "Guid.h"
#include "Json/Value.h"

enum eRPRM_Lights
{
	RPRM_Lights_0 = 0,
	RPRM_Lights_1,
	RPRM_Lights_2,
	RPRM_Lights_3,
	RPRM_Lights_4,
	RPRM_Lights_5,
	RPRM_Lights_6,
	RPRM_Lights_8 = 0x8,
	RPRM_Lights_10 = 0x10,
	RPRM_Lights_18 = 0x18,
	RPRM_Lights_20 = 0x20,
	RPRM_Lights_40 = 0x40,
	RPRM_Lights_80 = 0x80,
	RPRM_Lights_800000 = 0x800000,
	RPRM_Lights_1000000 = 0x1000000,
	RPRM_Lights_2000000 = 0x2000000
};

enum eRPRM_Orientation {
	RPRM_Orientation_0 = 0,
	RPRM_Orientation_1,
	RPRM_Orientation_2,
	RPRM_Orientation_3,
	RPRM_Orientation_4,
	RPRM_Orientation_5,
	RPRM_Orientation_6,
	RPRM_Orientation_7,
	RPRM_Orientation_8,
	RPRM_Orientation_9,
	RPRM_Orientation_A,
	RPRM_Orientation_B,
	RPRM_Orientation_C,
	RPRM_Orientation_D,
	RPRM_Orientation_E,
	RPRM_Orientation_F
};

enum eProcessCommands
{
	ProcessCommands_CB = 0xCB,
	ProcessCommands_CC,
	ProcessCommands_CD,
	ProcessCommands_CE,
	ProcessCommands_CF,
	ProcessCommands_2F44 = 0x2F44,
	ProcessCommands_2F45,
	ProcessCommands_2F46,
	ProcessCommands_2F47,
	ProcessCommands_2F48,
	ProcessCommands_2F49,
	ProcessCommands_2F4A,
	ProcessCommands_2F4B,
	ProcessCommands_2F4C,
	ProcessCommands_2F4D,
	ProcessCommands_2F4E,
	ProcessCommands_2F4F,
	ProcessCommands_2F50,
};

enum eCheckResult
{
	CheckResult_0,
	CheckResult_1,
	CheckResult_2
};

enum eBoundsResultStatus
{
	BoundsResultStatus_0 = 0,
	BoundsResultStatus_1 = 1,
	BoundsResultStatus_2 = 2
};

enum eGraphicFieldType
{
	GFT_0,
	GFT_Portrait = 0xC9,
	GFT_Fingerprint, // 0xCA
	GFT_Iris, // 0xCB
	GFT_Signature, // 0xCC
	GFT_Barcode, // 0xCD
	GFT_ProofOfCitizenship, // 0xCE
	GFT_DocumentFrontSide, // 0xCF
	GFT_DocumentReverseSide, // 0xD0
	GFT_ColorDynamic, // 0xD1
	GFT_GhostPortrait, // 0xD2
	GFT_Stamp, // 0xD3
	GFT_PortraitOfChild, // 0xD4
	GFT_Other = 0xFA,
	GFT_LeftThumb = 0x12C,
	GFT_LeftIndexFinger, // 0x12D
	GFT_LeftMiddleFinger, // 0x12E
	GFT_LeftRingFinger, // 0x12F
	GFT_LeftLittleFinger, // 0x130
	GFT_RightThumb, // 0x131
	GFT_RightIndexFinger, // 0x132
	GFT_RightMiddleFinger, // 0x133
	GFT_RightRingFinger, // 0x134
	GFT_RightLittleFinger // 0x135
};

enum eRPRM_ResultType
{
	RT_TRawImageContainer_1 = 1,
	RT_TDocBarCodeInfo_5 = 5,
	RT_TOneCandidate_9 = 9,
	RT_TAuthenticityCheckList_14 = 20,
	RT_TRawImageContainer_17 = 23,
	RT_TImageQualityCheckList_1E = 30,
	RT_TAuthenticityCheckList_22 = 34,
	RT_RawImageContainerR_42 = 66,
	RT_TBindingResultsList_46 = 70,
	RT_TBoundsResult_55 = 85
};

enum CDocFormat
{
	DOCFORMAT_0 = 0,
	DOCFORMAT_1,
	DOCFORMAT_2,
	DOCFORMAT_3,
	DOCFORMAT_4,
	DOCFORMAT_5,
	DOCFORMAT_6,
	DOCFORMAT_7,
	DOCFORMAT_8,
	DOCFORMAT_9,
	DOCFORMAT_A,
	DOCFORMAT_B,
	DOCFORMAT_C,
	DOCFORMAT_D,
	DOCFORMAT_E,
	DOCFORMAT_3E8 = 1000,
	DOCFORMAT_3E9,
	DOCFORMAT_3EA,
	DOCFORMAT_UNKNOWN = -1,
};

enum eProcessGlCommands
{
	PGC_TImageQuality = 107,
	PGC_TImageQuality_CheckGlares,
	PGC_TImageQuality_UpdateGlaresCoordinates = 111,
	PGC_TImSegger = 302,
	PGC_TCreditCard = 313,
	PGC_TFaceDetector = 400,
	PGC_TBounds_DetectBounds = 511,
	PGC_TDocBoundLocator = 514,
	PGC_TBounds_ProcessSeries = 523,
	PGC_TBounds_ProcessSeries_524 = 524,
	PGC_TLex = 650,
	PGC_TCodeConverter = 1100,
	PGC_TCodeConverter_CheckBarcodeFormat = 1102,
	PGC_TBind = 1301,
	PGC_TBarcodesMT = 2280,
	PGC_TBarcodesMT_ReadDoc,
	PGC_TBarcodesMT_ReadFrame,
	PGC_TMrzDetector = 2400,
	PGC_TRecPass_2501 = 2501,
	PGC_TRecPass_2700 = 2700,
	PGC_TimeCheck = 12214,
	PGC_TRFID = 12501,
	PGC_TId3Rus = 12700,
	PGC_TExtPortraitProcessor = 12900,
	PGC_TGraphicFieldCropper = 13401,
	PGC_TAuthenticity = 13500,
};

enum eCheckDiagnose
{
	CheckDiagnose_0,
	CheckDiagnose_1,
	CheckDiagnose_19 = 0x19,
	CheckDiagnose_35 = 0x35,
	CheckDiagnose_82 = 0x82,
	CheckDiagnose_83,
	CheckDiagnose_84,
	CheckDiagnose_85
};

enum eRPRM_Authenticity
{
	RPRM_Authenticity_10000 = 0x10000,
};

enum eVisualFieldType
{
	VisualFieldType_0 = 0,
	VisualFieldType_1,
	VisualFieldType_3 = 3,
	VisualFieldType_32 = 50,
	VisualFieldType_33 = 51,
	VisualFieldType_4E = 78,
	VisualFieldType_9F = 0x9F,
	VisualFieldType_1ED = 493,
};

enum eInputFaceType
{
	InputFaceType_1 = 1,
	InputFaceType_2,
	InputFaceType_3,
};

enum MRZDetectorErrorCode
{
	MRZ_DETECTED,
	ENABLE_ALLOCATE_MEMORY,
	INPUT_CONTAINER_NULL_POINTER,
	OUTPUT_CONTAINER_NULL_POINTER,
	NO_GOOD_INPUT_IMAGE_FOUND,
	NO_DETECTION,
	NO_CLASSIFER_LOADED_RECOGN_IMPOSSIBLE,
	BAD_MRZ_SEGMENTATION,
	MRZ_RECOGNIZED_CONFIDENTLY,
	MRZ_RECOGNIZED_UNCONFIDENTLY,
	BAD_COMMAND,
	NO_INPUT_DOCUMENT_BOUNDS_FOUND,
	CONSECUTIVE_RESULTS_ARE_NOT_EQUAL,
	NO_DETECTION_MRZ_VERY_SMALL,
	NO_DETECTION_MRZ_IS_VERY_CLOSE_TO_LEFT,
	NO_DETECTION_MRZ_IS_VERY_CLOSE_TO_RIGHT,
	NO_DETECTION_MRZ_IS_VERY_CLOSE_TO_TOP,
	NO_DETECTION_MRZ_IS_VERY_CLOSE_TO_BOTTOM,
	NO_DETECTION_MRZ_IS_OUT_OF_FOCUS,
	NO_RECOGNITION_MRZ_IS_OUT_OF_FOCUS,
	NO_RECOGNITION_STRONG_PERSPECTIVE,
	NO_RECOGNITION_MRZ_IS_VERY_SMALL
};

enum tFullColors_cv
{
	FullColors_cv_0 = 0x0,
	FullColors_cv_1,
	FullColors_cv_2,
	FullColors_cv_3,
	FullColors_cv_4,
	FullColors_cv_5,
	FullColors_cv_6,
	FullColors_cv_7,
};

enum eRPRM_Capabilities
{
	RPRM_Capabilities_0,
	RPRM_Capabilities_4 = 4,
	RPRM_Capabilities_8 = 8,
	RPRM_Capabilities_C = 0xC,
	RPRM_Capabilities_10 = 0x10,
	RPRM_Capabilities_18 = 0x18,
	RPRM_Capabilities_20 = 0x20,
	RPRM_Capabilities_28 = 0x28,
	RPRM_Capabilities_30 = 0x30,
	RPRM_Capabilities_38 = 0x38,
	RPRM_Capabilities_2000 = 0x2000,
	RPRM_Capabilities_401C = 0x401C,
	RPRM_Capabilities_100004 = 0x100004,
};

enum eBarCodeType
{
	BarCodeType_0,
	BarCodeType_1,
	BarCodeType_2,
	BarCodeType_3,
	BarCodeType_4,
	BarCodeType_5,
	BarCodeType_6,
	BarCodeType_7,
	BarCodeType_8,
	BarCodeType_9,
	BarCodeType_A,
	BarCodeType_B,
	BarCodeType_C,
	BarCodeType_D,
	BarCodeType_E,
	BarCodeType_F,
	BarCodeType_10,
};

enum eBinProcessImg
{
	eBPI_NO = -1,
	eBPI_IR = 0,
	eBPI_WHITE = 1,
	eBPI_WHITE_Gray = 2,
	eBPI_WHITE_GrayTr = 3,
	eBPI_WHITE_R = 4,
	eBPI_WHITE_G = 5,
	eBPI_WHITE_B = 6,
	eBPI_WHITE_TR = 7,
	eBPI_UV = 8,
	eBPI_UV_R = 9,
	eBPI_UV_G = 10,
	eBPI_UV_B = 11
};

enum eBinProcess
{
	eBP_NO = -1,
	eBP_OFF = 0,
	eBP_Sobel = 1,
	eBP_BinUsual_50 = 2,
	eBP_BinUsual_30 = 4,
	eBP_BinOTSU = 8,
	eBP_Resize = 0x10,
	eBP_Rotate = 0x20,
	eBP_Resize2 = 0x40,
	eBP_BinFixLevel = 0x80,
	eBP_WBorder = 0x100,
	eBP_BinUsual_15R = 0x200,
	eBP_FilterBox = 0x400,
	eBP_Canny = 0x800,
	eBP_Mask = 0x1000,
	eBP_OTSU_ADAPT_GAUS = 0x2000,
	eBP_OTSU_CV = 0x4000,
	eBP_GaussianBlur = 0x8000,
	eBP_BinOTSU_Second = 0x10000,
	eBP_BinOTSU_Previus = 0x20000,
	eBP_Hough = 0x80000,
	eBP_Hough2 = 0x100000,
	eBP_Close = 0x200000,
	eBP_CloseRect = 0x400000
};

enum eDocumentFilterClass
{
	DocumentFilterClass_0 = 0,
	DocumentFilterClass_1,
	DocumentFilterClass_2,
	DocumentFilterClass_3,
	DocumentFilterClass_4,
	DocumentFilterClass_5,
	DocumentFilterClass_6,
	DocumentFilterClass_8 = 8,
	DocumentFilterClass_9,
	DocumentFilterClass_12 = 12,
	DocumentFilterClass_13,
	DocumentFilterClass_14,
	DocumentFilterClass_16 = 16,
};

enum eRPRM_SecurityFeatureType {
	RPRM_SecurityFeatureType_0 = 0,
	RPRM_SecurityFeatureType_3 = 3
};

enum eImageQualityCheckType {
	ImageQualityCheckType_0 = 0,
	ImageQualityCheckType_1 = 1,
	ImageQualityCheckType_2 = 2
};

struct TCheckResult
{
	int nTCR_pcr;	// eProcessCommandsResult
	int nTCR_cr;	// eCheckResult
};

class CRectCandidats;
typedef struct _TResultContainer TResultContainer;

typedef struct _TResultContainerList
{
	uint nTRCL_Count;
	TResultContainer *pTRCL_TRC;
}TResultContainerList;

typedef struct _TResultContainerPointersList
{
	uint nTRCPL_Count;
	TResultContainer ** ppTRCPL_List;
}TResultContainerPointersList;

typedef struct tagRECT
{
	int left;
	int top;
	int right;
	int bottom;
}RECT;

typedef struct tagRECTF
{
	float left;
	float top;
	float right;
	float bottom;
}RECTF;

typedef struct _TIP_PDF417_INFO
{
	int nTPI_bcColumn;
	int nTPI_bcRow;
	int nTPI_bcErrorLevel;
	float rTPI_minX;
	float rTPI_minY;
	float rTPI_Angle;
}TIP_PDF417_INFO;

typedef struct _TIP_DECODE_MODULE
{
	int nTDM_mType;
	int nTDM_mLength;
	unsigned char *nTDM_mData;
	int nTDM_mReserved1;
	int nTDM_mReserved2;
}TIP_DECODE_MODULE;

typedef struct _TDocBarCodeField
{
	int nDBCF_bcCodeResult;
	int nDBCF_bcType_DETECT;
	tagRECT xDBCF_bcROI_DETECT;
	float rDBCF_bcAngle_DETECT;
	int nDBCF_bcType_DECODE;
	int nDBCF_bcCountModule;
	TIP_DECODE_MODULE *pDBCF_bcDataModule;
	TIP_PDF417_INFO xDBCF_bcPDF417INFO;
	int nDBCF_bcTextFieldType;
	int nDBCF_bcTextDecoderTypes;
	char *pDBCF_bcFieldMask;
}TDocBarCodeField;

typedef struct _TDocBarCodeInfo
{
	uint nDBCI_nFields;
	TDocBarCodeField *pDBCI_pArrayFields;
}TDocBarCodeInfo;

typedef struct _TSymbolCandidate
{
	uint nTSC_SymbolCode;
	uint nTSC_SymbolProbability;
	ushort sTSC_Class;
	ushort sTSC_SubClass;
}TSymbolCandidate;

typedef struct _TSymbolResult
{
	tagRECT xTSR_SymbolRect;
	uint nTSR_CandidatesCount;
	TSymbolCandidate xnTSR_Candidates[4];
	union {
		uint nTSTR_Reserved;
		struct {
			ushort sTSTR_BaseLineBottom;
			ushort sTSTR_BaseLineTop; 
		} s;
	} u;
}TSymbolResult;

typedef struct _TStringResultSDK
{
	uint nTSRS_SymbolsCount;
	uint nTSRS_Reserved;
	TSymbolResult *pTSRS_StringResult;
}TStringResultSDK;

typedef struct _TDocVisualExtendedField
{
	union {
		int nDVEF_FieldType;
		struct {
			ushort wFieldType;
			ushort wLCID;
		} s0;
	} u0;
	union {
		tagRECT xDVEF_FieldRect;
		struct {
			int nDVEF_OriginDG;
			int nDVEF_OriginDGTag;
			int nDVEF_OriginTagEntry;
			int nDVEF_OriginEntryView;
		} s;
	} u;
	char szDVEF_FieldName[256];
	int nDVEF_StringsCount;
	TStringResultSDK *pDVEF_StringsResult;
	int nDVEF_Buf_Length;
	char *pszDVEF_Buf_Text;
	char *pszDVEF_FieldMask;
	int nDVEF_Validity;
	int nDVEF_InComparison;
	uint nDVEF_Reserved2;
	uint nDVEF_Reserved3;
}TDocVisualExtendedField;

typedef struct _TDocVisualExtendedInfo
{
	int nDVEI_Fields;
	TDocVisualExtendedField *pDVEI_ArrayFields;
}TDocVisualExtendedInfo;

typedef struct tagBITMAPINFOHEADER{
	uint      biSize;
	int       biWidth;
	int       biHeight;
	ushort	  biPlanes;
	ushort    biBitCount;
	uint      biCompression;
	uint      biSizeImage;
	int       biXPelsPerMeter;
	int       biYPelsPerMeter;
	uint      biClrUsed;
	uint      biClrImportant;
} BITMAPINFOHEADER;

typedef struct tagRGBQUAD {
	uchar    rgbBlue;
	uchar    rgbGreen;
	uchar    rgbRed;
	uchar    rgbReserved;
} RGBQUAD;

typedef struct tagBITMAPINFO {
	BITMAPINFOHEADER    bmiHeader;
	RGBQUAD             bmiColors[256];
}BITMAPINFO;

typedef struct _TRawImageContainer
{
	tagBITMAPINFO *pxRIC_bmi;
	uchar *pRIC_data;
}TRawImageContainer;

typedef struct _TDocGraphicField
{
	eGraphicFieldType nDGF_FieldType;
	tagRECT xDGF_FieldRect;
	char szDGF_FieldName[256];
	TRawImageContainer xDGF_image;
}TDocGraphicField;

typedef struct _TDocGraphicsInfo
{
	uint nDGI_nFields;
	TDocGraphicField *pDGI_pArrayFields;
}TDocGraphicsInfo;

typedef struct _TSingleRect
{
	float Left;
	float Top;
	float Right;
	float Bottom;
}TSingleRect;

typedef struct _TTestTextField
{
	uint nTTF_TEST_RESULT;
	uint nTTF_FieldType;
	ushort sTTF_FieldPos;
	ushort sTTF_FieldLength;
	ushort sTTF_ValidCheckSum;
	ushort sTTF_reserved;
}TTestTextField;

typedef struct _TSymbolEstimation
{
	char cTSE_CharSymbol;
	tagRECT xTSE_SymbolBounds;
	uint nTSE_SYMBOL_PARAM;
	uint nTSE_EMPTINESS;
	uint nTSE_EDGE;
	uint nTSE_STAIN;
	uint nTSE_CONTRAST_PRINT;
	uint nTSE_CONTRAST_SYMBOL;
	uint nTSE_ALIGNMENT_NEAREST_SYMBOLS;
	float rTSE_SizeErrorAlignWithPrev;
	float rTSE_SizeErrorAlignWithNext;
	uint nTSE_SYMBOLS_INTERVAL;
	float rTSE_SizeErrorIntervWithPrev;
	float rTSE_SizeErrorIntervWithNext;
	uint nTSE_SYMBOL_SIZE;
	float rTSE_SizeErrorSymbolHeight;
	float rTSE_SizeErrorSymbolWidth;
}TSymbolEstimation;

typedef struct _TStrEstimation
{
	int nTSTRE_SymbolsCount;
	float rTSTRE_StringAngle;
	tagRECT xTSTRE_StringBorders;
	int nTSTRE_STRING_POSITION;
	TSingleRect xTSTRE_ErrorPOSITION;
	int nTSTRE_STRINGS_DISTANCE;
	float rTSTRE_SizeError_DISTANCE;
	int nTSTRE_STRINGS_INTERVAL;
	float rTSTRE_SizeError_INTERVAL;
	int nTSTRE_ALIGNMENT_SYMBOLS_IN_STRING;
	float rTSTRE_SizeError_ALIGNMENT;
	int nTSTRE_SYMBOLS_PARAM;
	int nTSTRE_STRING_FILLING;
	int nTSTRE_CHECK_SUMS;
	int nTSTRE_FieldCount;
	TTestTextField xnTSTRE_Fields[12];
	TSymbolEstimation xnTSTRE_SymbolsEstimations[44];
}TStrEstimation;

typedef struct _TDocMRZTestQuality
{
	int nDMTQ_DOC_FORMAT;
	int nDMTQ_MRZ_FORMAT;
	int nDMTQ_TEXTUAL_FILLING;
	int nDMTQ_CHECK_SUMS;
	int nDMTQ_CONTRAST_PRINT;
	int nDMTQ_STAIN_MRZ;
	int nDMTQ_PRINT_POSITION;
	int nDMTQ_SYMBOLS_PARAM;
	int nDMTQ_StrCount;
	TStrEstimation xnDMTQ_Strings[3];
}TDocMRZTestQuality;

typedef struct _TFDSIDList
{
	char szFDSIDL_ICAOCode[4];
	uint nFDSIDL_Count;
	uint *pnFDSIDL_List;
	uint nFDSIDL_dType;
	uint nFDSIDL_dFormat;
	bool bFDSIDL_dMRZ;
	char *pszFDSIDL_dDescription;
	char *pszFDSIDL_dYear;
	char *pszFDSIDL_dCountryName;
	char *pszFDSIDL_dStateCode;
	char *pszFDSIDL_dStateName;
}TFDSIDList;

typedef struct _TOneCandidate
{
	char *pszTOC_DocumentName;
	int nTOC_ID;
	double dTOC_P;
	ushort sTOC_Rotated180;
	ushort sTOC_RotationAngle;
	uint nTOC_NecessaryLights;
	TRawImageContainer *pxTOC_preview;
	uint nTOC_RFID_Presence;
	uint nTOC_CheckAuthenticity;
	ushort sTOC_UVExp;
	ushort sTOC_OVIExp;
	uint nTOC_AuthenticityNecessaryLights;
	TFDSIDList *pxTOC_FDSIDList;
}TOneCandidate;

typedef struct _TCandidatesListContainer
{
	uint nCLC_RecResult;
	uint nCLC_Count;
	TOneCandidate *pxCLC_Candidates;
}TCandidatesListContainer;

typedef struct _TOCRDocInfo
{
	char szODI_DocName[256];
	uint nODI_DocID;
	char szODI_DocTxtID[256];
	uint nODI_DocFormat;
	uint nODI_NecessaryLights;
	uint nODI_nFields;
	uint nODI_RFID_Presence;
	uint nODI_reserved1;
	uint nODI_reserved2;
	uint nODI_reserved3;
}TOCRDocInfo;

typedef struct _TListDocsInfo
{
	uint nLDI_Count;
	TOCRDocInfo *pxLDI_ArrayOfDocs;
}TListDocsInfo;

typedef struct _TVerifiedFieldMap
{
	union {
		uint nVFM_FieldType;
		struct {
			ushort sVFM_wFieldType;
			ushort sVFM_wLCID;
		} s;
	} u;
	char *pszVFM_Field_MRZ;
	char *pszVFM_Field_RFID;
	char *pszVFM_Field_Visual;
	char *pszVFM_Field_Barcode;
	uchar ucVFM_Matrix[10];
}TVerifiedFieldMap;

typedef struct _TListVerifiedFields
{
	uint nLVF_Count;
	TVerifiedFieldMap *pxLVF_FieldMaps;
	char *pszLVF_DateFormat;
}TListVerifiedFields;

typedef struct tagPOINT
{
	int x;
	int y;
}POINT;

typedef struct tagSIZE
{
	int cx;
	int cy;
}SIZE;

typedef struct _TAuthenticityCheckResult
{
	int nACR_Type;
	int nACR_Result;
	int nACR_Count;
	void **ppACR_List;
}TAuthenticityCheckResult, *PTAuthenticityCheckResult;

typedef struct _TAuthenticityCheckList
{
	int nACL_Count;
	TAuthenticityCheckResult **ppACL_List;
}TAuthenticityCheckList;

typedef struct _TOCRSecurityTextResult
{
	union {
		uint nOSTR_ResultCode;
		struct {
			ushort ElementResult;
			ushort ElementDiagnose;
		} s;
	} u;
	uint nOSTR_CriticalFlag;
	uint nOSTR_LightType;
	tagRECT xOSTR_FieldRect;
	uint nOSTR_EtalonResultType;
	uint nOSTR_EtalonFieldType;
	uint nOSTR_EtalonLightType;
	tagRECT xOSTR_EtalonFieldRect;
	char szOSTR_SecurityTextResultOCR[256];
	char szOSTR_EtalonResultOCR[256];
	uint nOSTR_Reserved1;
	uint nOSTR_Reserved2;
}TOCRSecurityTextResult;

typedef struct _TPointArraySDK
{
	int nPAS_PointCount;
	tagPOINT *pxPAS_PointsList;
}TPointArraySDK;

typedef struct _TAreaArray
{
	int nTAA_Count;
	tagRECT *pxTAA_List;
	TPointArraySDK *pxTAA_Points;
}TAreaArray;

typedef struct _TIdentResult
{
	union {
		uint nTIR_Result;
		struct {
			ushort sTIR_ElementResult;
			ushort sTIR_ElementDiagnose;
		} s;
	} u;
	uint nTIR_LightIndex;
	tagRECT xTIR_Area;
	TRawImageContainer xTIR_Image;
	TRawImageContainer xTIR_EtalonImage;
	uint nTIR_PercentValue;
	TAreaArray *pxTIR_AreaList;
	uint nTIR_ElementType;
}TIdentResult;

typedef struct _TSecurityFeatureCheck
{
	union {
		int nSFC_Result;
		struct {
			ushort sSFC_ElementResult;
			ushort sSFC_ElementDiagnose;
		} s;
	} u;
	int nSFC_ElementType;
	tagRECT xSFC_ElementRect;
	uint nSFC_Visibility;
	uint nSFC_CriticalFlag;
	TAreaArray *pxSFC_AreaList;
	uint nSFC_Reserved2;
}TSecurityFeatureCheck;

typedef struct _TRawImageContainerList
{
	int nRICL_Count;
	TRawImageContainer *pxRICL_Images;
}TRawImageContainerList;

typedef struct _TPhotoIdentResult
{
	union {
		uint nPIR_Result;
		struct {
			ushort ElementResult;
			ushort ElementDiagnose;
		} s;
	} u;
	int nPIR_LightIndex;
	tagRECT xPIR_Area;
	TRawImageContainer xPIR_SourceImage;
	TRawImageContainerList xPIR_ResultImages;
	uint nPIR_FieldTypesCount;
	uint *pnPIR_FieldTypesList;
	int nPIR_Step;
	int nPIR_Angle;
	int nPIR_Reserved3;
}TPhotoIdentResult;

typedef struct _TFibersType
{
	union {
		uint nTFT_ErrorCode;
		struct {
			ushort sTFT_ElementResult;
			ushort sTFT_ElementDiagnose;
		} s;
	} u;
	union {
		uint nTFT_RectCount;
		uint nTFT_LightValue;
	} u1;
	tagRECT *pxTFT_RectArray;
	uint *pnTFT_Width;
	uint *pnTFT_Length;
	uint *pnTFT_Area;
	unsigned char cTFT_ColorValues[3];
	union {
		uint nTFT_ExpectedCount;
		uint nTFT_LightDisp;
	} u2;
}TFibersType;

typedef struct _TDatabaseCheck
{
	uint nTDC_recordsCount;
	char *pszTDC_recordsJson;
	char *pszTDC_sqlRequest;
}TDatabaseCheck;

typedef struct _TImageQualityCheck
{
	uint nIQC_type;
	int nIQC_result;
	int nIQC_featureType;
	TAreaArray *pxIQC_areas;
	float rIQC_10;
	float rIQC_14;
	int nIQC_18;
}TImageQualityCheck, *PTImageQualityCheck;

typedef struct _TImageQualityCheckList
{
	uint nIQCL_Count;
	eCheckResult nIQCL_result;
	TImageQualityCheck **ppxIQCL_List;
}TImageQualityCheckList;

typedef struct _TRegulaDeviceProperties
{
	uint nRDP_DeviceType;
	int nRDP_4;
	uint nRDP_SerialNumber;
	int nRDP_C;
	int nRDP_10;
	char *pszRDP_14;
	char *pszRDP_18;
	char *pszRDP_1C;
	int nRDP_20;
	int nRDP_24;
	int nRDP_28;
	char *pszRDP_LabelSerialNumberStr;
	unsigned long long n64RDP_CameraSerialNumber;
	GUID xRDP_CameraGuid;
	uint nRDP_Capabilities;
	uint nRDP_Authenticity;
	uint nRDP_Database;
	long nRDP_ValidUntil;
	bool fRDP_WillConnect;
}TRegulaDeviceProperties;

typedef struct _TDetailsRFID
{
	eCheckResult nTDR_overallStatus;
	eCheckResult nTDR_PA;
	eCheckResult nTDR_AA;
	eCheckResult nTDR_CA;
	eCheckResult nTDR_TA;
	eCheckResult nTDR_BAC;
	eCheckResult nTDR_PACE;
}TDetailsRFID;

typedef struct _TDetailsOptical
{
	eCheckResult nTDO_overallStatus;
	eCheckResult nTDO_mrz;
	eCheckResult nTDO_text;
	eCheckResult nTDO_docType;
	eCheckResult nTDO_security;
	eCheckResult nTDO_imageQA;
	eCheckResult nTDO_expiry;
	uint nTDO_pagesCount;
}TDetailsOptical;

typedef struct _TStatus
{
	eCheckResult nTS_overallStatus;
	TDetailsOptical xTS_detailsOptical;
	eCheckResult nTS_optical;
	TDetailsRFID xTS_detailsRFID;
	eCheckResult nTS_rfid;
	eCheckResult nTS_portrait;
	eCheckResult nTS_stopList;
}TStatus;

typedef struct _TTextSymbol
{
	uint nTTS_code;
	tagRECT xTTS_rect;
	uint nTTS_probability;
}TTextSymbol;

typedef struct _TRfidOrigin
{
	int nTRO_dg;
	int nTRO_dgTag;
	int nTRO_tagEntry;
	int nTRO_entryView;
}TRfidOrigin;

typedef struct _TTextComparison
{
	char *pTTC_sourceLeft;
	char *pTTC_sourceRight;
	uint nTTC_status;
}TTextComparison;

typedef struct _TTextValidity
{
	char *pTTV_source;
	uint nTTV_status;
}TTextValidity;

typedef struct _TTextFieldValue
{
	char *pTFV_value;
	char *pTFV_originalValue;
	uint nTFV_originalValidity;
	char *pTFV_source;
	uint nTFV_containerType;
	uint nTFV_pageIndex;
	tagRECT xTFV_fieldRect;
	TRfidOrigin xTFV_rfidOrigin;
	uint nTFV_probability;
	uint nTFV_originalSymbols;
	TTextSymbol *pxTFV_SymbolList;
}TTextFieldValue;

typedef struct _TTextSource
{
	char *pTTS_source;
	uint nTTS_containerType;
	uint nTTS_validityStatus;
}TTextSource;

typedef struct _TTextFieldValueList
{
	uint nTFVL_count;
	TTextFieldValue *pxTFVL_List;
}TTextFieldValueList;

typedef struct _TTextValidityList
{
	uint nTVL_count;
	TTextValidity *pxTVL_List;
}TTextValidityList;

typedef struct _TTextComparisonList
{
	uint nTCL_count;
	TTextComparison *pxTCL_List;
}TTextComparisonList;

typedef struct _TTextField
{
	ushort sTTF_fieldType;
	char *pszTTF_fieldName;
	ushort sTTF_lcid;
	char *pszTTF_lcidName;
	uint nTTF_status;
	char *pszTTF_value;
	TTextFieldValueList xTTF_valueList;
	uint nTTF_validityStatus;
	TTextValidityList xTTF_validityList;
	uint nTTF_comparisonStatus;
	TTextComparisonList xTTF_comparisonList;
}TTextField;

typedef struct _TTextFieldList
{
	uint nTFL_count;
	TTextField *pxTFL_List;
}TTextFieldList;

typedef struct _TTextSourceList
{
	uint nTSL_count;
	TTextSource *pxTSL_List;
}TTextSourceList;

typedef struct _TTextResult
{
	uint nTTR_status;
	uint nTTR_validityStatus;
	uint nTTR_comparisonStatus;
	char *pTTR_dateFormat;
	TTextFieldList xTTR_fieldList;
	TTextSourceList xTTR_availableSourceList;
}TTextResult;

typedef struct _TImageSource
{
	char *pTIS_source;
	uint nTIS_containerType;
}TImageSource;

typedef struct _TImageFieldValue
{
	char *pIFV_value;
	char *pIFV_originalValue;
	char *pIFV_source;
	uint nIFV_containerType;
	uint nIFV_pageIndex;
	uint nIFV_lightIndex;
	tagRECT xIFV_fieldRect;
	TRfidOrigin xIFV_rfidOrigin;
}TImageFieldValue;

typedef struct _TImageFieldValueList
{
	uint nIFVL_count;
	TImageFieldValue *pxIFVL_List;
}TImageFieldValueList;

typedef struct _TImageField
{
	eGraphicFieldType nTIF_fieldType;
	char *pTIF_fieldName;
	TImageFieldValueList xTIF_valueList;
}TImageField;

typedef struct _TImageFieldList
{
	uint nIFL_count;
	TImageField *pxIFL_List;
}TImageFieldList;

typedef struct _TImageSourceList
{
	uint nISL_count;
	TImageSource *pxISL_List;
}TImageSourceList;

typedef struct _TImagesResult
{
	TImageFieldList xTIR_fieldList;
	TImageSourceList xTIR_availableSourceList;
}TImagesResult;

typedef struct _GetPointPosRequest
{
	int n_GPPR_0;
	int n_GPPR_4;
	int n_GPPR_8;
	int n_GPPR_C;
	int n_GPPR_10;
	int n_GPPR_14;
}GetPointPosRequest;

typedef struct _TRawCalibrateImages
{
	int nRCI_0;
	TRawImageContainer xRCI_4;
	TRawImageContainer xRCI_C;
	TRawImageContainer xRCI_14;
}TRawCalibrateImages;

typedef struct _TBindingPosition
{
	int nTBP_shiftX;
	int nTBP_shiftY;
	float rTBP_probability;
	tagRECT xTBP_rect;
}TBindingPosition;

typedef struct _TBindingResult
{
	int nTBR_shiftX;
	int nTBR_shiftY;
	int nTBR_8;
	int nTBR_C;
	int nTBR_countPosition;
	TBindingPosition *pxTBR_position;
}TBindingResult;

typedef struct _TBindingResultsList
{
	int nBRL_Layers;
	TBindingResult *pxBRL_ArrayResults;
	int nBRL_8;
}TBindingResultsList;

typedef struct _TDwordArray
{
	uint nTDA_count;
	uint *pnTDA_array;
}TDwordArray;

typedef struct _TSourceImagesInfo
{
	int nSII_0;
	int nSII_4;
}TSourceImagesInfo;

typedef struct _CFieldFont
{
	int m_nFF_Type;
	float m_rFF_HeightRel;
	int m_nFF_HeightAbs;
	int m_nFF_layer;
	int m_nFF_Incline;
	ushort m_sFF_LCID;
	ushort m_sFF_LongSpace;
	uchar m_cFF_VarHeight;
	uchar m_cFF_emptyFieldToResult;
	uchar m_cFF_Reserv1;
	uchar m_cFF_Reserv2;
}CFieldFont;

typedef struct _TAlphabet
{
	uint nTA_apName;
	char szTA_apValues[256];
}TAlphabet;

typedef struct _TProcParams
{
	uint nTPP_TypeResultColor;
	uint nTPP_Median_Execute;
	uint nTPP_Blur_Level;
	uint nTPP_Sharpness_Level;
	uint nTPP_brightness;
	uint nTPP_contrast;
	float rTPP_Orientation;
	uint nTPP_Positive;
	uint nTPP_Mirror_flip;
	uint nTPP_Layer;
	ushort sTPP_FontHeight;
	ushort sTPP_RemoveLines;
	ushort sTPP_AutoSwitchIRtoWHITE;
	ushort sTPP_IRtoWHITEThreshold;
}TProcParams;

typedef struct _TVocList
{
	uint nTVL_VocCount;
	uint nnTVL_VocIDList[16];
}TVocList;

typedef struct _TPhotoParams
{
	int nTPP_corner_type;
	int nTPP_searching_range_X;
	int nTPP_searching_range_Y;
	int nTPP_closeX;
	int nTPP_closeY;
	int nTPP_light_param;
}TPhotoParams;

typedef struct _TVisualField
{
	union {
		uint nTVF_type;
		struct {
			ushort sTVF_wFieldType;
			ushort sTVF_wLCID;
		} s;
	} u;
	char szTVF_pName[256];
	uint nTVF_lightType;
	tagRECTF xTVF_RelRegion;
	tagRECT xTVF_Region;
	CFieldFont xTVF_Font;
	char szTVF_Mask[256];
	TAlphabet xTVF_Alphabet[4];
	TProcParams xTVF_ProcParams;
	TVocList xTVF_VocList;
	int nTVF_InComparison;
	ushort sTVF_postProcessing;
	ushort sTVF_status;
	TPhotoParams *pxTVF_ParamsFieldPhoto;
	int nTVF_docID;
}TVisualField;

typedef struct _TDocInfo
{
	char szTDI_pDocName[256];
	int nTDI_DocID;
	char szTDI_DocTxtID[256];
	int nTDI_DocFormat;
	int nTDI_DocType;
	int nTDI_NeccessaryLights;
	int nTDI_RFID_Presence;
	int nTDI_CheckAuthenticity;
	int nTDI_UVExp;
	int nTDI_AuthLights;
	uint nTDI_Reserved2;
	int nTDI_nFields;
	TVisualField *pxTDI_Fields;
}TDocInfo;

typedef struct _TDeviceType
{
	uint nTDT_devType;
	uint nTDT_cameraIndex;
	uint nTDT_bayerMatrix;
	uint nTDT_flip;
	uint nTDT_resultLightType;
	uint nTDT_devClass;
	uint nTDT_execLightCompensation;
	uint nTDT_execColorCompensation;
	uint nTDT_execContrastEnhancement;
	uint nTDT_execGrayFromColor;
	uint nTDT_lightOVDLevel;
	uint nTDT_2C;
	uint nTDT_30;
}TDeviceType;

typedef struct _TChildDocInfo
{
	uint nCDI_ID;
	uint nCDI_Processed;
}TChildDocInfo;

typedef struct _TDocumentInfo
{
	uint nTDI_ID;
	uint nTDI_ChildCount;
	TChildDocInfo *pxTDI_ChildDocumentsList;
}TDocumentInfo;

typedef struct _TOriginalRFIDGraphics
{
	int nORG_FieldType;
	int nORG_GraphicsType;
	int nORG_RFID_OriginDG;
	int nORG_RFID_OriginDGTag;
	int nORG_RFID_OriginTagEntry;
	int nORG_RFID_OriginEntryView;
	uint nORG_BufferLen;
	uchar *pORG_Buffer;
}TOriginalRFIDGraphics;

typedef struct _TOriginalRFIDGraphicsInfo
{
	uint nORGI_Fields;
	TOriginalRFIDGraphics *pxORGI_ArrayFields;
}TOriginalRFIDGraphicsInfo;

typedef struct _AreaToHide
{
	uint nATH_format;
	tagRECT xATH_area;
}AreaToHide;

class _FieldToHide
{
public:
	_FieldToHide() {};
	_FieldToHide(_FieldToHide const&a2)
		: vFTH_country(a2.vFTH_country), vFTH_doc(a2.vFTH_doc), vFTH_textFieldTypes(a2.vFTH_textFieldTypes), 
		vFTH_graphicFieldTypes(a2.vFTH_graphicFieldTypes), vFTH_areas(a2.vFTH_areas)
	{
		nFTH_docId = a2.nFTH_docId;
		fFTH_allTextFields = a2.fFTH_allTextFields;
		fFTH_allGraphicFields = a2.fFTH_allGraphicFields;
	};
	~_FieldToHide() {};

	string vFTH_country;
	string vFTH_doc;
	int nFTH_docId;
	bool fFTH_allTextFields;
	vector<uint> vFTH_textFieldTypes;
	bool fFTH_allGraphicFields;
	vector<uint> vFTH_graphicFieldTypes;
	vector<_AreaToHide> vFTH_areas;
};

typedef struct _TBinaryData
{
	int nTBD_FieldType;
	char szTBD_FieldName[256];
	int nTBD_Buf_Length;
	unsigned char *pTBD_Buffer;
}TBinaryData;

typedef struct _ResultList
{
	uint nRL_LightType;
	int nRL_Probability;
	tagRECT xRL_pRects;
	int nRL_CoincidenceToPhotoArea;
	tagRECT xRL_Rect_Photo;
	int nRL_Orientation;
	int nRL_Reserved;
}ResultList;

typedef struct _TBoundsResult
{
	int nTBR_docFormat;
	int nTBR_Width;
	int nTBR_Height;
	tagPOINT xTBR_Center;
	float rTBR_Angle;
	tagPOINT xTBR_LeftTop;
	tagPOINT xTBR_LeftBottom;
	tagPOINT xTBR_RightTop;
	tagPOINT xTBR_RightBottom;
	int nTBR_Inverse;
	uchar cTBR_PerspectiveTr;
	uchar cTBR_ResultStatus;
	uchar cTBR_ObjArea;
	uchar cTBR_ObjIntAngleDev;
	int nTBR_Dpi;
}TBoundsResult;

typedef struct _POINTFLOAT
{
	float x;
	float y;
}POINTFLOAT;

typedef struct _POSITIONDOCUMENT
{
	_POINTFLOAT xnPD_corners[4];
	float rPD_ugol;
	float rPD_area;
	int nPD_docType;
	float rPD_rezerv2;
}POSITIONDOCUMENT;

typedef struct _TFieldPosCorrectorResult
{
	tagRECT xFPCR_FieldRect;
	int nFPCR_Quad[4][3];
	tagRECT xFPCR_Side_status;
	uint nFPCR_Error_status;
	uint nFPCR_Reserved2;
	uint nFPCR_Reserved3;
}TFieldPosCorrectorResult;

typedef struct _Symbol
{
	float rSym_boundingRect[8];
}Symbol;

typedef struct _SymbolRow
{
	int nSR_length;
	Symbol xnSR_symbols[88];
}SymbolRow;

typedef struct _TResultMRZDetector
{
	int nRMD_MRZFormat;
	float rnRMD_boundingQuadrangle[8];
	int nRMD_MRZRowsNum;
	SymbolRow xnRMD_MRZRows[3];
}TResultMRZDetector;

struct FaceComparisonResult
{
	int nFCR_first;
	int nFCR_second;
	int nFCR_errorCode;
	string xFCR_errorMsg;
	float rFCR_score;
	float rFCR_similarity;
};

struct TDocBinaryInfo
{
	uint nDBI_nFields;
	TBinaryData *pxDBI_pArrayFields;
};

struct DocTypeCandidat
{
	int nDTC_type_field_0;
	float fDTC_value_field_4;
};

struct TBindingLayer
{
	int nBL_field_0;
	eRPRM_Lights nBL_RPRM_Lights;
	TProcParams xBL_TPP_field_8;
	int nBL_field_38;
	int nBL_field_3C;
	int nBL_field_40;
	int nBL_field_44;
	TDocGraphicField * pBL_DGF_field_48;
	int nBL_field_4C;
};

struct TBindingLayersList
{
	int nTBLL_count;
	TBindingLayer * pTBLL_TBL;
	int field_8;
};

struct TBindingResultInternal
{
	int field_0;
	int field_4;
	int field_8;
	int field_C;
	vector<TBindingPosition> vTBRI_field_10;
};

struct CMemBufer
{
	int nCMB_field_0;
	int nCMB_field_4;
	int nCMB_field_8;
	uchar *pCMB_data_field_C;
};

struct _TResultContainer
{
	uint nTRC_result_type;
	eRPRM_Lights nTRC_light;
	uint nTRC_buf_length;
	union {
		void* pTRC_obj;
		char* pTRC_CHAR;
		uchar* pTRC_UCHAR;
		uint nTRC_UINT;
		TRawImageContainer* pTRC_RIC;
		TDocVisualExtendedInfo* pTRC_DVEI;
		TDocBarCodeInfo* pTRC_DBCI;
		TDocGraphicsInfo* pTRC_DGI;
		TDocMRZTestQuality* pTRC_DMTQ;
		TCandidatesListContainer* pTRC_CLC;
		TOneCandidate* pTRC_TOC;
		TListDocsInfo* pTRC_LDI;
		TListVerifiedFields* pTRC_LVF;
		TAuthenticityCheckList* pTRC_ACL;
		TDatabaseCheck* pTRC_TDC;
		TImageQualityCheckList* pTRC_IQCL;
		TRegulaDeviceProperties* pTRC_RDP;
		TStatus* pTRC_TS;
		TTextResult* pTRC_TTR;
		TImagesResult* pTRC_TIR;
		Json::Value* pTRC_JV;
		tagRECTF* pTRC_RECTF;
		GetPointPosRequest* pTRC_GPPR;
		TIdentResult* pTRC_TIDR;
		_TRawCalibrateImages* pTRC_RCI;
		TBindingResultsList* pTRC_BRL;
		TDwordArray* pTRC_TDA;
		TSourceImagesInfo* pTRC_SII;
		TDocInfo* pTRC_TDI;
		TDeviceType* pTRC_TDT;
		CRectCandidats* pTRC_CRC;
		TDocumentInfo* pTRC_TDMI;
		TOriginalRFIDGraphicsInfo* pTRC_ORGI;
		TBoundsResult* pTRC_TBR;
		POSITIONDOCUMENT* pTRC_PDM;
		TResultMRZDetector* pTRC_RMD;
		TFieldPosCorrectorResult* pTRC_FPCR;
		TDocBinaryInfo* pTRC_DBI;
		tagPOINT* pTRC_POINT;
	} u;
	union {
		int nTRC_exposure;
		uint nTRC_XML_length;
	} u1;
	char* pTRC_XML_buffer;
	uint nTRC_list_idx;
	uint nTRC_page_idx;
};