﻿#include "Analyse.h"
#include <algorithm>
#include "../gdi/Line_32f.h"
#include "../RCv.h"

namespace RAnalyse
{
	void dynamicRange(cv::Mat &a2, int a3, int a4, int &a5, int &a6, int &a7, int a8, int a9)
	{
		float v10 = (float)a3;
		int v11 = a9;
		if (a9 == -1)
			v11 = a2.rows - 1;
		int v13 = a8 + 1;
		float v14 = 0.0;
		if (a8 != -1)
			v13 = a8;
		while (v13 < v11)
		{
			v14 += a2.at<float>(v13);
			if (v14 > v10)
				break;
			++v13;
		}
		v14 = 0.0;
		a6 = v13;
		while (v11 >= v13)
		{
			v14 += a2.at<float>(v11);
			if (v14 > (float)a4)
				break;
			--v11;
		}
		a7 = v11;
		a5 = v11 - a6;
	}

	int dynamicRange(int *pnParam1, int nParam2, int nParam3, int nParam4, int &nParam5, int &nParam6, int &nParam7)
	{
		int res = -1;
		if (pnParam1 && nParam2 >= 1)
		{
			int i, v9 = 0;
			for (i = 0; i < nParam2 - 1; i++)
			{
				v9 += pnParam1[i];
				if (v9 > nParam3)
					break;
			}
			nParam5 = i;
			v9 = 0;
			for (i = nParam2 - 1; i >= 0; i--)
			{
				v9 += pnParam1[i];
				if (v9 > nParam4)
					break;
			}
			nParam6 = i;
			res = 0;
			nParam7 = ((nParam5 == nParam6) && nParam5) ? 1 : (nParam6 - nParam5);
			if (nParam7 <= 0)
			{
				nParam5 = nParam6 = nParam7 = 0;
				res = -1;
			}
		}
		return res;
	}


	int findThresholdBinary(IImageControlR &a2, int &a3, int a4, int a5)
	{
		int v17[256];

		if (!a2.pdata())
			return -1;
		if (a2.width() * a2.height() < 1)
			return -1;
		for (int i = 0; i < 256; i++)
			v17[i] = 0;
		for (int i = 0; i < a2.height(); ++i)
		{
			for (int j = 0; j < a2.width(); j ++)
			{
				v17[a2.line(i)[j]] ++;
			}
		}
		return findThresholdBinary(v17, a3, a4, a5, 6);
	}

	int findThresholdBinary(int *a2, int &a3, int a4, int a5, int a6)
	{
		double v5 = 0.0;
		double v6 = 0.0;
		int v7 = a4;
		while (v7 < a5)
		{
			v6 += (double)a2[v7];
			v5 += (double)a2[v7] * v7;
			v7++;
		}
		int v28;
		if (v6 == 0.0)
		{
			v28 = (a5 + a4) / 2;
		}
		else
		{
			double v11 = v5 / v6;
			int v12 = 0;
			while (1)
			{
				int v13 = 0;
				int v15 = (int)(v11 + 0.5);
				double v16 = 0.0;
				int v14 = a4;
				while (v14 < v15)
				{
					v13 += a2[v14];
					v16 += (double)a2[v14] * v14;
					v14++;
				}
				double v19 = v11;
				if (v13)
					v19 = v16 / (double)v13;
				v16 = 0.0;
				v13 = 0;
				while (v15 < a5)
				{
					v13 += a2[v15];
					v16 += (double)a2[v15] * v15;
					v15++;
				}
				double v24 = v11;
				if (v13)
					v24 = v16 / (double)v13;
				double v25 = (v19 + v24) * 0.5;
				double v26 = fabs(v11 - v25);
				v11 = v25;
				if (v26 >= 1.0)
					++v12;
				if (v12 >= a6 || v26 < 1.0)
					break;
			}
			v28 = (int)(v11 + 0.5);
		}
		a3 = v28;

		return 0;
	}

	int findThresholdBinary3(IImageControlR &a1, int &a2, int &a3, int &a4, int a5, int a6)
	{
		int _an_10[256];
		if (a1.pdata() == NULL)
			return -1;
		if (a1.width() * a1.nChannels() < 1)
			return -1;
		for (int i = 0; i < 256; i++)
			_an_10[i] = 0;
		uchar *line;
		for (int j = 0; j < a1.width(); j++)
		{
			line = a1.line(j);
			for (int k = 0; k < a1.width(); k++);
			{

			}
		}
		return -1;
	}

	void findUpDown(uchar * a1, int a2, int a3, int a4, vector<pair<int, int>>& a5)
	{
		int v9 = 0;
		pair<int, int> p(0, 0);
		for (int i = a2; i < a3; i++)
		{
			if (a1[i] < a4)
			{
				if (v9)
				{
					p.second = i;
					a5.push_back(p);
				}
				v9 = 0;
			}
			else
			{
				if (!v9)
					p.first = i;
				v9 = 1;
			}
		}
		if (v9)
		{
			p.second = a3;
			a5.push_back(p);
		}
	}

	void getProjectionV_LineWidth(CBufferImage & xCBI_Param1, int nParam2, vector<uchar> & vParam3)
	{
		int v6 = xCBI_Param1.height();
		vParam3.resize(v6);
		CBufferImage cbi;
		int nn[256];
		for (int i = 0; i < v6; i++)
		{
			int v8 = xCBI_Param1.width();
			int nTmp = i;
			cbi.ref(xCBI_Param1, 0, nTmp, v8, 1);
			RCvMat::histogramRange(cbi, 0x100, nn);

			int v10 = 0, v11 = 0;
			for (int j = 0; j < 0x100; j++)
			{
				if (nn[j])
				{
					int v15 = nn[j];
					if (nParam2 - v10 < nn[j])
						v15 = nParam2 - v10;
					if (!v15)
						break;
					v11 += v15 * j;
					v10 += v15;
				}
			}
			uchar v16 = 0xFF;
			if (v10)
				v16 = ~(v11 / v10);
			vParam3[i] = v16;
		}
	}

	void getProjection_LineWidth(CBufferImage &a1, int a2, vector<uchar>& a3)
	{
		int v6 = a1.width();
		a3.resize(v6);
		CBufferImage _CBufImg_14;
		int _n_34[256];
		for (int i = 0; i < a1.width(); i++)
		{
			_CBufImg_14.ref(a1, i, 0, 1, a1.height());
			RCvMat::histogramRange(_CBufImg_14, 256, _n_34);
			int v10 = 0, v11 = 0, v15 = 0;
			uchar v16 = 0;
			for (int j = 0; j <= 0xFF; j++)
			{
				if (_n_34[j])
				{
					v15 = MIN(_n_34[j], a2 - v10);
					if (v15 == 0)
						break;
					v10 += v15;
					v11 += v15 * j;
				}
			}
			if (v10)
				v16 = ~(v11 / v10);
			else
				v16 = -1;
			a3[i] = v16;
		}
	}
	
	void gist(vector<float>& a1, vector<float>& a2, vector<float>& a3, int a4)
	{
		//correct
		int v1;
		a3.resize(a4, 0);
		for (uint i = 0; i < a1.size(); i++)
		{
			v1 = (int)a1[i];
			a3[v1] += a2[i] * (1.0f - (a1[i] - v1));
			a3[v1 + 1] += (a1[i] - v1) * a2[i];
		}
	}

	void gistCyclicWindow(vector<float> & vr_a1, int n_a2, vector<float> & vr_a3, vector<float> & vr_a4)
	{
		//correct
		int v1 = (int)(n_a2 * 0.5f - 0.1f);
		vector<float> v2(vr_a1.size() + 2 * v1);

		for (int i = 0; i < v1; i++)
		{
			v2[i] = vr_a1[vr_a1.size() - v1 + i];
			v2[vr_a1.size() + v1 + i] = vr_a1[i];
		}

		int v4 = 2 * v1 | 1;
		for (uint i = 0; i < vr_a1.size(); i++)
			v2[v1 + i] = vr_a1[i];

		vr_a3.resize(vr_a1.size());
		vr_a4.resize(vr_a1.size());

		float v5 = 0.0f, v6 = 0.0f;
		for (int i = 0; i < v4; i++)
		{
			v5 += v2[i];
			v6 += v2[i] * i;
		}

		float v8;
		for (uint i = 0; i < vr_a1.size() - 1; i++)
		{
			vr_a3[i] = v5;
			if (v5 == 0.0f)
			{
				v8 = (float)i;
			}
			else
			{
				v8 = v6 / v5 - v1;
			}
			vr_a4[i] = v8;
			v5 += v2[2 * v1 + i + 1] - v2[i];
			v6 += v2[2 * v1 + i + 1] * (v4 + i) - (v2[i] * i);
		}

		vr_a3[vr_a1.size() - 1] = v5;

		if (v5 == 0.0)
			vr_a4[vr_a1.size() - 1] = (float)(vr_a1.size() - 1);
		else
			vr_a4[vr_a1.size() - 1] = v6 / v5 - v1;
	}

	int histogramCenter(int *a2, float &a3, int a4, int a5)
	{
		int v4 = 0;
		int v5 = 0;
		a3 = -1.0f;
		while (a4 < a5)
		{
			v4 += a2[a4];
			v5 += a2[a4] * a4;
			a4++;
		}
		if (!v4)
			return 1;
		a3 = (float)v5 / v4;
		return 0;
	}

	void maxAprox(vector<int> vn_a1, int n_a2, vector<pair<int, int>>& vpairnn_a3)
	{
		vpairnn_a3.clear();
		vector<float>  _vr_28(n_a2, 1.0);
		int nMidB;
		nMidB = _vr_28.size() / 2 + 1;
		float rTmp_v13 = 1.0f / nMidB;
		for (uint j = 0; j < _vr_28.size() / 2; j++)
		{
			_vr_28[j] = rTmp_v13 * (j + 1.0f);
			_vr_28[_vr_28.size() - j - 1] = _vr_28[j];
		}
		vector<float> _vr_1C(vn_a1.size(), 0);
		while (1)
		{
			for (uint i = 0; i < _vr_1C.size(); i++)
			{
				vector<float> _vr_10(n_a2, 0);
				for (uint k = 0; k < _vr_10.size(); k++)
				{
					if (i + k >= vn_a1.size())
						break;
					_vr_10[k] = _vr_28[k] * vn_a1[k + i];
				}
				float rTmp_sum = 0.0;
				for (uint k = 0; k < _vr_10.size(); k++)
					rTmp_sum += _vr_10[k];
				_vr_1C[i] = rTmp_sum;
			}

			int MaxPos = 0;
			for (uint k = 1; k < _vr_1C.size(); k++)
			{
				if (_vr_1C[MaxPos] < _vr_1C[k])
					MaxPos = k;
			}
			if (_vr_1C[MaxPos] == 0)
				break;

			int v20 = ~(n_a2 + MaxPos);
			int v21 = ~(vn_a1.size());

			if (v21 > v20)
				v20 = v21;

			int v22 = -1 - (v20 + MaxPos);

			for (int k = 0; k < v22; k++)
				vn_a1[MaxPos + k] = 0;
			pair<int, int> pairTmp(MaxPos + n_a2 / 2 + 1, (int)_vr_1C[MaxPos]);
			vpairnn_a3.push_back(pairTmp);
		}
	}

	int maxAprox(vector<int>a1, int a2, float &a3)
	{
		return maxAprox(a1.data(), a1.size(), a2, a3);
	}

	int maxAprox(int *a1, int a2, int a3, float &a4)
	{
		int v10;
		return maxAprox(a1, a2, a3, a4, v10);
	}

	int maxAprox(int *a1, int a2, int a3, float &a4, int &a5)
	{
		int v7;
		return maxAprox(a1, a2, a3, a4, a5, v7);
	}

	int maxAprox(int *a1, int a2, int a3, float &a4, int &a5, int &a6)
	{
		float v7; // s2
		int v8; // r8
		float v9; // s4
		int v10; // r6
		int v11; // r2
		signed int *v12; // r4
		float v14; // s0
		float v15; // s2
		int v16; // r2
		int v17; // r5
		signed int v18; // s4

		v7 = 0.0;
		v8 = a3 / 2;
		for (int i = 0; i < a2; i++)
		{
			v9 = 0.0;
			v10 = i + 1 + v8;
			v11 = max(0, i - v8);
			if (v10 >= a2)
				v10 = a2;
			while (v11 < v10)
			{
				v12 = &a1[v11++];
				v9 = v9 + *v12;
			}
			if (v9 >= v7)
			{
				a6 = i;
				v7 = v9;
			}
		}
		if (v7 == 0.0) return 1;

		v14 = 0.0;
		v15 = 0.0;
		v16 = max(0, a6 - v8);
		if (v8 + a6 + 1 < a2)
			a2 = v8 + a6 + 1;
		while (v16 < a2)
		{
			v17 = a1[v16] * v16;
			v18 = a1[v16++];
			v15 += v18;
			v14 += v17;
		}
		a4 = v14 / v15;
		a5 = (int)v15;

		return 0;
	}
}

namespace AngleAnalyze
{
	float checkIntAngle(tagPOINT &a1, tagPOINT &a2, tagPOINT &a3, tagPOINT &a4)
	{
		float v10 = CLine_32f::getAngle(CLine_32f(a1, a2), CLine_32f(a2, a3)) + 360.0f;
		float v15 = CLine_32f::getAngle(CLine_32f(a2, a3), CLine_32f(a3, a4)) + 360.0f;
		float v14 = CLine_32f::getAngle(CLine_32f(a3, a4), CLine_32f(a4, a1)) + 360.0f;
		float v13 = CLine_32f::getAngle(CLine_32f(a4, a1), CLine_32f(a1, a2)) + 360.0f;
		float v12, v16, v17, v18;

		do
		{
			v12 = v10;
			v10 = fabsf(v10 + -90.0f);
		} while (v10 < v12);
		do
		{
			v16 = v15;
			v15 = fabsf(v15 + -90.0f);
		} while (v15 < v16);
		do
		{
			v17 = v14;
			v14 = fabsf(v14 + -90.0f);
		} while (v14 < v17);
		do
		{
			v18 = v13;
			v13 = fabsf(v13 + -90.0f);
		} while (v13 < v18);
		return fmaxf(fmaxf(v12, v16), fmaxf(v17, v18));
	}

	void filterByAngle(vector<LineEx>& a1, float a2, float a3, DocAngleParam & a4)
	{
		//correct
		float v1, v2 = 0.0;
		a4.m_vDAPField_0.clear();

		for (uint i = 0; i < a1.size(); i++)
		{
			v1 = (float)a1[i].m_rLineAngle;
			if (fabsf(a2 - v1) < a3 || fabsf(a2 + 90.0f - v1) < a3 || fabsf(a2 - 90.0f - v1) < a3 ||
				fabsf(a2 + 180.0f - v1) < a3 || fabsf(a2 - 180.0f - v1) < a3)
			{
				a4.m_vDAPField_0.push_back(i);
				v2 += a1[i].m_rLineLen;
			}
		}

		a4.m_rDAPAngle = a2;
		a4.m_rDAPLen = v2;
	}

	void filterByAngle(vector<LineEx>& a1, vector<int>& a2, float & a3, float & a4, vector<int>& a5, float & a6)
	{
		//correct
		float v1;

		a5.clear();
		a6 = 0.0;
		for (uint i = 0; i < a2.size(); i++)
		{
			v1 = (float)a1[a2[i]].m_rLineAngle;
			if (fabsf(a4 - v1) < a3 || fabsf(a4 + 90.0f - v1) < a3 || fabsf(a4 - 90.0f - v1) < a3 ||
				fabsf(a4 + 180.0f - v1) < a3 || fabsf(a4 - 180.0f - v1) < a3)
			{
				a5.push_back(a2[i]);
				a6 += a1[a2[i]].m_rLineLen;
			}
		}
	}

	void findAngles(vector<LineEx>& vLineEx_a1, float r_a2, float r_a3, vector<DocAngleParam>& vDocAngleParam_a4)
	{
		//correct
		vector<int> vn_40;
		vector<int>::iterator v3;
		set<int> v2, v5;
		DocAngleParam xDocAngleParam;

		vDocAngleParam_a4.clear();
		LineExProcess::initLinesAngle(vLineEx_a1);
		vn_40.reserve(vLineEx_a1.size());

		for (uint i = 0; i < vLineEx_a1.size(); i++)
			vn_40.push_back(i);

		xDocAngleParam.m_rDAPLen = 0.0;
		while (true)
		{
			vector<int> vn_7C(vn_40.size());
			vector<int>::iterator iter = set_difference(vn_40.begin(), vn_40.end(),
				xDocAngleParam.m_vDAPField_0.begin(), xDocAngleParam.m_vDAPField_0.end(), vn_7C.begin());

			vn_40 = vector<int>(vn_7C.begin(), iter);
			findAngle(vLineEx_a1, vn_40, r_a2, xDocAngleParam.m_rDAPAngle);
			filterByAngle(vLineEx_a1, vn_40, r_a2, xDocAngleParam.m_rDAPAngle, xDocAngleParam.m_vDAPField_0, xDocAngleParam.m_rDAPLen);
			if (xDocAngleParam.m_rDAPLen < r_a3)
				break;

			vDocAngleParam_a4.push_back(xDocAngleParam);

			if (vn_40.empty()) break;
		}
	}

	bool findAngle(vector<LineEx> & vLine_a1, vector<int> & vn_a2, float & r_a3, float & r_a4)
	{
		vector<float> vLen, vAngle, vGist;
		bool bRet;
		for (uint i = 0; i < vn_a2.size(); i++)
		{
			if (!(vLine_a1[vn_a2[i]].m_nLineType & 8))
				continue;
			vLen.push_back(vLine_a1[vn_a2[i]].m_rLineLen);

			if (vLine_a1[vn_a2[i]].m_rLineAngle > 90.0)
			{
				vAngle.push_back(float(vLine_a1[vn_a2[i]].m_rLineAngle - 90.0));
				continue;
			}
			if (vLine_a1[vn_a2[i]].m_rLineAngle < 0.0)
			{
				vAngle.push_back((float)(vLine_a1[vn_a2[i]].m_rLineAngle + 90.0));
				continue;
			}

			vAngle.push_back((float)vLine_a1[vn_a2[i]].m_rLineAngle);
		}

		RAnalyse::gist(vAngle, vLen, vGist, 92);


		vector<float> v1, v2;
		float rMin, v4;

		vGist[0] += vGist[90];
		vGist.resize(90);
		RAnalyse::gistCyclicWindow(vGist, (int)r_a3, v1, v2);

		int nMinIndex = 0;
		rMin = v1[0];
		for (uint i = 1; i < v1.size(); i++)
		{
			if (rMin < v1[i])
			{
				rMin = v1[i];
				nMinIndex = i;
			}
		}

		bRet = false;
		v4 = v2[nMinIndex];
		if (v4 < -45.0)
			v4 += 90.0;
		r_a4 = v4 - 90.0f;
		if (v4 < 45.0f)
			r_a4 = v4;

		return bRet;
	}

	//선들을 각도에 따라 분할한다. a5, a6은 분할된 선들이 총길이
	void splitOrtLines(vector<LineEx>& a1, float & a2, vector<int>& a3, vector<int>& a4, float * a5, float * a6)
	{
		//correct
		float v1, v2, v3 = 0.0, v4 = 0.0;

		a4.clear();
		a3.clear();

		for (uint i = 0; i < a1.size(); i++)
		{
			v1 = (float)a1[i].m_rLineAngle;
			v2 = fabsf(a2 - v1);
			if (fminf(v2, (float)(((unsigned int)(v2 - 180.0)) & 0x7fffffff)) >= 45.0f)
			{
				a3.push_back(i);
				v3 += a1[i].m_rLineLen;
			}
			else
			{
				a4.push_back(i);
				v4 += a1[i].m_rLineLen;
			}
		}

		if (a5)
			*a5 = v3;
		if (a6)
			*a6 = v4;
	}

	//선들을 각도에 따라 분할한다. a5, a6은 분할된 선들이 총길이
	void splitOrtLines(vector<LineEx>& a1, vector<int>& a2, float & a3, vector<int>& a4, vector<int>& a5, float * a6, float * a7)
	{
		float v1, v2, v3 = 0.0, v4 = 0.0;

		a4.clear();
		a5.clear();

		for (uint i = 0; i < a2.size(); i++)
		{
			v1 = (float)a1[a2[i]].m_rLineAngle;
			v2 = fabsf(a3 - v1);
			if (fminf(v2, (float)(((unsigned int)(v2 - 180.0)) & 0x7fffffff)) >= 45.0f)
			{
				a4.push_back(a2[i]);
				v3 += a1[a2[i]].m_rLineLen;
			}
			else
			{
				a5.push_back(a2[i]);
				v4 += a1[a2[i]].m_rLineLen;
			}
		}

		if (a6)
			*a6 = v3;
		if (a7)
			*a7 = v4;
	}
}
