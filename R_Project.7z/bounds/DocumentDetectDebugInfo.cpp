#include "DocumentDetectDebugInfo.h"
#include "../common/container/container.h"
#include "../common/fs.h"
#include "../common/RegulaConfig.h"


DocumentDetectDebugInfo::DocumentDetectDebugInfo(void)
{
}

DocumentDetectDebugInfo::~DocumentDetectDebugInfo(void)
{
}

void DocumentDetectDebugInfo::init(common::container::RclHolder &a2, float a3)
{
	Mat v16;
	Mat v17 = common::container::wrapByMat(a2);

	if ( a3 == 1.0 )
	{
		v17.copyTo(v16);
	}
	else
	{
		resize(v17, v16, Size((int)(a3 * v17.cols), (int)(a3 * v17.rows)));
	}
	if ( v16.flags & CV_MAT_CN_MASK )
	{
		cvtColor(v16, v16, COLOR_BGR2GRAY);
	}
	field_0 = 1;
	DocumentDetectDebugInfo::setImgFone(v16);
}

void DocumentDetectDebugInfo::setImgFone(Mat &a2)
{
	this->field_4.create(Size(a2.size.p[1], a2.size.p[0]), 0x10);
	if ( (a2.flags & CV_MAT_CN_MASK) == 0x10 )
	{
		a2.copyTo(this->field_4);
	}
	else
	{
		vector<Mat> v7;
		v7.resize(3);
		a2.copyTo(v7[0]);
		a2.copyTo(v7[1]);
		a2.copyTo(v7[2]);
		merge(v7, this->field_4);
	}
}

Mat DocumentDetectDebugInfo::linesSave(DocumentCandidate& a2, const char *a3)
{
	DocumentCandidateList v7;

	v7.m_vDocCanList.push_back(a2);
	return linesSave(v7, false, a3);
}

Mat DocumentDetectDebugInfo::linesSave(DocumentCandidateList& a2, bool a3, const char *a4)
{
	Mat a1;
	size_t i, j, k;
	vector<LineGroup *> v41, v42;
	vector<LineEx> v43, v44;

	if ( !this->field_0 )
		return a1;

	for(i = 0; i < a2.m_vDocCanList.size(); i ++)
	{
		v41.push_back(a2.m_vDocCanList[i].m_pBottomLGr);
		v41.push_back(a2.m_vDocCanList[i].m_pTopLGr);
		v41.push_back(a2.m_vDocCanList[i].m_pLeftLGr);
		v41.push_back(a2.m_vDocCanList[i].m_pRightLGr);
		for(j = 0; j < v41.size(); j ++)
		{
			for(k = 0; k < v42.size(); k ++)
			{
				if(v41[j] == v42[k]) break;
			}
			if(k == v42.size()) v42.push_back(v41[j]);
		}
		if(a3)
		{
			for(j = 0; j < v42.size(); j ++)
			{
				for(k = 0; k < (v42[j])->m_vLineExGr.size(); k ++)
				{
					v43.push_back((v42[j])->m_vLineExGr[k]);
				}
			}
		}
	}
	if(!a3)
	{
		for(j = 0; j < v42.size(); j ++)
		{
			for(k = 0; k < (v42[j])->m_vLineExGr.size(); k ++)
			{
				v44.push_back((v42[j])->m_vLineExGr[k]);
			}
		}
		a1 = linesSave(v44, a4);
	}

	return a1;
}

Mat DocumentDetectDebugInfo::linesSave(vector<LineEx>& a3, const char *a4)
{
	Mat a1;
	Mat v44;
	
	if ( !field_0 || field_4.empty())
		return a1;

	v44.create(Size(field_4.size.p[1], field_4.size.p[0]), 0x10);
	field_4.copyTo(v44);
	for(size_t i = 0; i < a3.size(); i ++)
	{
		line(v44, a3[i].m_xStartPoint, a3[i].m_xEndPoint, Scalar_<double>(0.0, 0.0, 75.0, 255.0));
	}
	if(a4 != 0 && field_1)
	{
		flip(v44, v44, 0);
		string v34("boundsImage.jpg", 15);
		string v38(a4, strlen(a4));
		v34 = v38;
		common::fs::Path v32(common::RegulaConfig::GetTmpPath());
		common::fs::Path v31(v34);
		common::fs::Path v33(v32.add(v31));
		v33.setFileExt(string(".jpg", 4));
		string v35 = v33.toString();
		imwrite(String(v33.toString()), v44);
	}
	a1 = v44;

	return a1;
}

Mat DocumentDetectDebugInfo::linesSave(DocumentCandidateList& a2, vector<int>& a3, bool a4, const char *a5)
{
	Mat a1;
	size_t i, j, k;
	vector<LineGroup *> v41, v42, v45;
	vector<LineEx> v43, v44;

	if ( !this->field_0 )
		return a1;

	for(i = 0; i < a2.m_vDocCanList.size(); i ++)
	{
		v41.push_back(a2.m_vDocCanList[i].m_pBottomLGr);
		v41.push_back(a2.m_vDocCanList[i].m_pTopLGr);
		v41.push_back(a2.m_vDocCanList[i].m_pLeftLGr);
		v41.push_back(a2.m_vDocCanList[i].m_pRightLGr);
		for(j = 0; j < v41.size(); j ++)
		{
			for(k = 0; k < v42.size(); k ++)
			{
				if(v41[j] == v42[k]) break;
			}
			if(k == v42.size()) v42.push_back(v41[j]);
		}
		v45.insert(v45.end(), v42.begin(), v42.end());
		if(a4)
		{
			for(j = 0; j < v42.size(); j ++)
			{
				for(k = 0; k < (v42[j])->m_vLineExGr.size(); k ++)
				{
					v43.push_back((v42[j])->m_vLineExGr[k]);
				}
			}
		}
	}
	for(j = 0; j < v45.size(); j ++)
	{
		for(k = 0; k < (v45[j])->m_vLineExGr.size(); k ++)
		{
			v44.push_back((v45[j])->m_vLineExGr[k]);
		}
	}
	a1 = linesSave(v44, a5);

	return a1;
}

Mat DocumentDetectDebugInfo::linesSave(DocumentCandidateList& a3, vector<pair<int,int>>& a4, bool a5, const char *a6)
{
	vector<int> v17;
	vector<pair<int,int>>::iterator iter;
	vector<int>::iterator iter1;

	for(iter = a4.begin(); iter != a4.end(); iter++)
	{
		int val = (*iter).first;
		for(iter1 = v17.begin(); iter1 != v17.end(); iter1++)
		{
			if(*iter1 == val) break;
		}
		if(iter1 == v17.end())
		{
			v17.push_back(val);
		}
		for(iter1 = v17.begin(); iter1 != v17.end(); iter1++)
		{
			if(*iter1 == (*iter).second) break;
		}
		if(iter1 == v17.end())
		{
			v17.push_back(val);
		}
	}
	return linesSave(a3, v17, a5, a6);
}

Mat DocumentDetectDebugInfo::linesSave(vector<LineGroup>& a3)
{
	vector<LineEx> v12;

	for(size_t i = 0; i < a3.size(); i ++)
	{
		for(size_t j = 0; j < a3[i].m_vLineExGr.size(); j ++)
		{
			v12.push_back((a3[i].m_vLineExGr)[j]);
		}
	}
	return linesSave(v12, 0);
}

Mat DocumentDetectDebugInfo::linesSave(vector<Point_<float>>& a3, const char *a4)
{
	Mat a1;

	if(a3.size() > 3)
	{
		vector<LineEx> a3a(4);
		a3a.push_back(LineEx(a3[0], a3[1]));
		a3a.push_back(LineEx(a3[1], a3[2]));
		a3a.push_back(LineEx(a3[2], a3[3]));
		a3a.push_back(LineEx(a3[3], a3[0]));
		a1 = linesSave(a3a, a4);
	}

	return a1;
}

void DocumentDetectDebugInfo::printCandidateInfo(DocumentCandidateList& a2, vector<int>& a3)
{

}