﻿#pragma once
#include "DocumentCandidate.h"
#include "DocumentIDCheck.h"
#include "DocumentDetectionParameter.h"

class DocumentDetect
{
public:
	DocumentDetect();
	~DocumentDetect();

	DocumentSize::DocumentIDCheck * docCheck();
	bool calckLen(DocumentCandidate & a1, float a2, float a3, int & a4, float & a5);
	void calculateDocumentParam(vector<int> & a1, vector<DocumentCandidate> & a2);
	void find_90_Last(DocumentCandidateList & a1, vector<int> & a2, vector<int> & a3);
	void find_Free_Best(DocumentCandidateList & a1, vector<int> & a2, vector<int> & a3, bool a4, int a5);
	void find_Free_Last(DocumentCandidateList & a1,vector<int> & a2, vector<int> & a3);
	void find_Multi(DocumentCandidateList & a1, DocumentCandidate & a2, vector<int> & a3, vector<int> & a4);

	static void calculateDocParam_MRZ2(TBoundsResult & a1, DocumentCandidate & a2, float & a3);
	static void calculateDocParam_MRZ2(vector<TBoundsResult> & a1, DocumentCandidate & a2, float & a3);
	static void calculateDocParam_MRZ4(TBoundsResult & a1, DocumentCandidate & a2, float & a3, uchar & a4);
	static void calculateDocParam_MRZ4(vector<TBoundsResult> & a1, DocumentCandidate & a2, float & a3);
	static void find_BigestFree(DocumentCandidateList & a1, vector<int> & a2, int a3, vector<int> & a4);
	static void removePerimeterLines(Size & a1, int a2, vector<LineEx>& a3, vector<LineEx>& a4);
	static void getLines(vector<vector<Point>> & a1, double & a2, vector<LineEx> & a3);
	 
public:
	DocumentDetectionParameter m_xDocDTParam;
	DocumentSize::DocumentIDCheck m_xDocIdCheck;
	bool m_bSegLenOut;
	static int m_countourIndx;
};