#pragma once

#include "../pch.h"

class LineEx;

class LineGroup
{
public:
	LineGroup();
	LineGroup(LineGroup const & a1);
	~LineGroup();
	
	void calcMiddlePoint();
	void calcRealAngle();
	void mergeSegments(float a1);
	void updateContoursID();
	float calcDist(cv::Point2f & a1);
	int maxUnionLen();
	float segnemtLen(float a1, float a2);
	float segnemtLenOut(float a1, float a2);
	int maxSegment();

public:
	
	float m_rAngleGr; //0
	vector<pair<float, float>> m_vSegPair;
	float m_rSegLen;    //10
	cv::Point m_xMidPoint;
	int m_nMaxSeg;   
	int m_nField_20;    //20
	vector<LineEx> m_vLineExGr;  
	vector<int> m_vContoursID;  //30
	bool m_bSegkLenGr_3C; 
};

class LineGroupList
{
public:
	LineGroupList(LineGroupList && a1);
	LineGroupList();
	~LineGroupList();

	void filterByCount_Segment(int a1, int a2, vector<int> & a3);
	void dividetByLen(vector<int> & a1, vector<int> & a2, vector<int> & a3, int a4);

public:
	vector<LineGroup> m_vLineGrList;
};