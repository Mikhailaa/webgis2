﻿#pragma once
#include "../pch.h"

namespace DocumentSize
{
	class TDocSize
	{
	public:
		void setSize(float a1, float a2);
		float m_rTDocW;
		float m_rTDocH;
		float m_rTDocWH;
		float m_rTDocHW;
	};

	class DocumentIDCheck
	{
	public:
		DocumentIDCheck();
		~DocumentIDCheck();

		bool isIDByProportions(float a1, float a2, float & a3, int & a4, int * a5);
		bool isIDByProportionAndSize(float a1, float a2, float a3, float & a4, float & a5, int & a6);
		void isID(int a1, int a2, int a3, float & a4, int & a5);
		void isID(float a1, float a2, float & a3, int & a4, int * a5);
		void initGroups(map<string, vector<pair<int, TDocSize>>> & a1);
		void resetDocumentsFilter();
		void setActiveGroups(string & a1);
		void setActiveGroups(vector<string> & a1);
		void setDocumentsFilter(vector<int> & a1);
		int minSideLenght(int a1, int a2);
		int docResolution(int a1, int a2, int a3);

	public:
		map<string, vector<pair<int, DocumentSize::TDocSize>>> m_mDocFormatGr;  //name, type, width, height
		vector<pair<int, DocumentSize::TDocSize>> m_vActiveGr;
		vector<pair<int, DocumentSize::TDocSize>> m_vFilterGr;
		float m_rMinSideLen;
	};

	vector<int> docFilter123x2();
	vector<int> docFilter13();
	void initByDefault(DocumentIDCheck & a1);
	void readDocumentFormatFromHeader(vector<pair<int, DocumentSize::TDocSize>> & a1);
	bool isA4Size(tagSIZE a1, int a2, float a3);
}

namespace Json
{
	void convert(Json::Value & a1, map<string, vector<pair<int, DocumentSize::TDocSize>>>& a2);
	void convert(Json::Value & a1, vector<pair<int, DocumentSize::TDocSize>> & a2);
};