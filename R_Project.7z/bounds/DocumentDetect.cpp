#include "DocumentDetect.h"
#include "DocumentDetectDebugInfo.h"
#include "Bounds.h"

DocumentDetect::DocumentDetect()
{
	m_bSegLenOut = true;
}

DocumentDetect::~DocumentDetect()
{

}

DocumentSize::DocumentIDCheck * DocumentDetect::docCheck()
{
	return &m_xDocIdCheck;
}

bool DocumentDetect::calckLen(DocumentCandidate & a1, float a2, float a3, int & a4, float & a5)
{
	LineGroup *v1, *v2, *v3, *v4;
	float v5, v6, v7, v9, v10;
	int v8, v11;
	int v12;
	bool v13;
	v1 = a1.m_pBottomLGr;
	v2 = a1.m_pTopLGr;
	v3 = a1.m_pLeftLGr;
	v4 = a1.m_pRightLGr;
	v12 = v3->m_bSegkLenGr_3C | v2->m_bSegkLenGr_3C | v1->m_bSegkLenGr_3C | v4->m_bSegkLenGr_3C;

	if (v1->m_bSegkLenGr_3C)
		a1.m_rBottomSegkLen = 1.0;
	else
	{
		v5 = v1->calcDist(a1.m_vCornerDC[0]);
		v6 = v1->calcDist(a1.m_vCornerDC[1]);
		v7 = v5;
		if (v5 > v6)
		{
			v7 = v6;
			v6 = v5;
		}

		v8 = (int)v1->segnemtLen(v7, v6);
		v9 = fabsf(v6 - v7);
		v10 = v8 / v9;
		a1.m_rBottomSegLen = v8;
		a1.m_rBottomSegkLen = v10;
		if (m_bSegLenOut)
		{
			v11 = (int)v1->segnemtLenOut(v7, v6);
			v10 = a1.m_rBottomSegkLen;
			a1.m_rBottomSegLenOut = v11;
			a1.m_rBottomSegkLenOut = v11 / v9;
		}

		if (v12 << 24)
			v13 = v10 < a3;
		else
			v13 = v10 < a2;

		if (v13)
			return true;
		a5 += v10;
		++a4;
	}

	if (v2->m_bSegkLenGr_3C)
		a1.m_rTopSegkLen = 1.0;
	else
	{
		v5 = v2->calcDist(a1.m_vCornerDC[2]);
		v6 = v2->calcDist(a1.m_vCornerDC[3]);
		v7 = v5;
		if (v5 > v6)
		{
			v7 = v6;
			v6 = v5;
		}

		v8 = (int)v2->segnemtLen(v7, v6);
		v9 = fabsf(v6 - v7);
		v10 = v8 / v9;
		a1.m_rTopSegLen = v8;
		a1.m_rTopSegkLen = v10;
		if (m_bSegLenOut)
		{
			v11 = (int)v2->segnemtLenOut(v7, v6);
			v10 = a1.m_rTopSegkLen;
			a1.m_rTopSegLenOut = v11;
			a1.m_rTopSegkLenOut = v11 / v9;
		}

		if (v12 << 24)
			v13 = v10 < a3;
		else
			v13 = v10 < a2;

		if (v13)
			return true;
		a5 += v10;
		++a4;
	}

	if (v3->m_bSegkLenGr_3C)
		a1.m_rLeftSegkLen = 1.0;
	else
	{
		v5 = v3->calcDist(a1.m_vCornerDC[0]);
		v6 = v3->calcDist(a1.m_vCornerDC[3]);
		v7 = v5;
		if (v5 > v6)
		{
			v7 = v6;
			v6 = v5;
		}

		v8 = (int)v3->segnemtLen(v7, v6);
		v9 = fabsf(v6 - v7);
		v10 = v8 / v9;
		a1.m_rLeftSegLen = v8;
		a1.m_rLeftSegkLen = v10;
		if (m_bSegLenOut)
		{
			v11 = (int)v3->segnemtLenOut(v7, v6);
			v10 = a1.m_rLeftSegkLen;
			a1.m_rLeftSegLenOut = v11;
			a1.m_rLeftSegkLenOut = v11 / v9;
		}

		if (v12 << 24)
			v13 = v10 < a3;
		else
			v13 = v10 < a2;

		if (v13)
			return true;
		a5 += v10;
		++a4;
	}

	if (v4->m_bSegkLenGr_3C)
		a1.m_rRightSegkLen = 1.0;
	else
	{
		v5 = v4->calcDist(a1.m_vCornerDC[1]);
		v6 = v4->calcDist(a1.m_vCornerDC[2]);
		v7 = v5;
		if (v5 > v6)
		{
			v7 = v6;
			v6 = v5;
		}

		v8 = (int)v4->segnemtLen(v7, v6);
		v9 = fabsf(v6 - v7);
		v10 = v8 / v9;
		a1.m_rRightSegLen = v8;
		a1.m_rRightSegkLen = v10;
		if (m_bSegLenOut)
		{
			v11 = (int)v4->segnemtLenOut(v7, v6);
			v10 = a1.m_rRightSegkLen;
			a1.m_rRightSegLenOut = v11;
			a1.m_rRightSegkLenOut = v11 / v9;
		}

		if (v12 << 24)
			v13 = v10 < a3;
		else
			v13 = v10 < a2;

		if (v13)
			return true;
		a5 += v10;
		++a4;
	}
	return false;
}

void DocumentDetect::calculateDocumentParam(vector<int>& a1, vector<DocumentCandidate>& a2)
{
	float v1 = 0.0f, v4, v6, v7, v8, v9, v10, v11;
	int v5;
	DocumentCandidate v2;

	for (uint i = 0; i < a1.size(); i++)
	{
		v2 = a2[a1[i]];
		if (!v2.m_bViltual && v2.m_rMainProb >= 0.92f
			&& v2.m_rIntAngle <= 10.0f && v2.m_xDocSize.width > v1)
			v1 = v2.m_xDocSize.width;
	}

	for (uint i = 0; i < a1.size(); i++)
	{
		DocumentCandidate & v3 = a2[a1[i]];
		if (!v3.m_bDCField_8)
		{
			v3.m_bDCField_8 = 1;
			v4 = 0.0f;
			v5 = 0;
			if (calckLen(v3, m_xDocDTParam.m_rDDPField_BC, m_xDocDTParam.m_rDDPField_C0, v5, v4))
			{
				v3.m_rProbAngle = 0.1f;
				v3.m_rMainProb = 0.1f;
			}
			else
			{
				v3.m_rProbAngle = 0.0f;
				v6 = 0.0f;
				if (m_xDocDTParam.m_rLineHelpStop >= v3.m_rMrzParam2)
				{
					v6 = 1.0f;
					if (v3.m_rMrzParam2 >= m_xDocDTParam.m_rLineHelpStart)
						v6 = (m_xDocDTParam.m_rLineHelpStop - v3.m_rMrzParam2) / (m_xDocDTParam.m_rLineHelpStop - m_xDocDTParam.m_rLineHelpStart);
				}

				v7 = 0.0f;
				if (v3.m_rMrzParam4 <= m_xDocDTParam.m_rLineHelpStop)
				{
					v7 = 1.0f;
					if(v3.m_rMrzParam4 >= m_xDocDTParam.m_rLineHelpStart)
						v7 = (m_xDocDTParam.m_rLineHelpStop - v3.m_rMrzParam4) / (m_xDocDTParam.m_rLineHelpStop - m_xDocDTParam.m_rLineHelpStart);
				}

				v8 = 0.0f;
				if (m_bSegLenOut)
				{
					v8 = 1.0f;
					if ((v3.m_rBottomSegkLenOut + v3.m_rTopSegkLenOut + v3.m_rLeftSegkLenOut
						+ v3.m_rRightSegkLenOut * 0.25f) < 1.0f)
						v8 = v3.m_rBottomSegkLenOut + v3.m_rTopSegkLenOut + v3.m_rLeftSegkLenOut
						+ v3.m_rRightSegkLenOut * 0.25f;
				}

				v9 = 1.0f;
				if (v1 > 0.0f)
				{
					v10 = 0.0f;
					v9 = 1.0f;
					if ((v1 - v3.m_xDocSize.width) > 0.0f)
						v10 = v1 - v3.m_xDocSize.width;
					if (v10 / v1 < 1.0f)
						v9 = v10 / v1;
				}

				v11 = 1.0;
				if (v4 / v5 < 1.0f)
					v11 = v4 / v5;

				v3.m_rDCField_4C = v8 + (1.0f - v11);
				v3.m_bCheckLineContour = v3.checkLinesContours();
				v3.m_rDCField_38 = -(v6 * m_xDocDTParam.m_rCalcProb_MRD_DIST_2 / 100.0f);
				v3.m_rDCField_3C = -(v7 * m_xDocDTParam.m_rCalcProb_MRD_DIST_4 / 100.0f);
				v3.m_rDCField_44 = -(1.0f - v11) * m_xDocDTParam.m_rCalcProb_LINE_INSIDE / 100.0f;
				v3.m_rDCField_48 = -(v8 * m_xDocDTParam.m_rDDPField_A4 / 100.0f);
				v3.m_rDCField_40 = -(v9 * m_xDocDTParam.m_rDDPField_A8 / 100.0f);
				v3.m_rDCField_50 = -(4 - v3.m_bCheckLineContour) * 0.25f * m_xDocDTParam.m_rCalcProb_LINE_CONTOUR / 100.0f;
				v3.m_rDCField_14 = v3.m_rDCField_48 + v3.m_rDCField_44 + v3.m_rDCField_40 +
					v3.m_rDCField_44 + v3.m_rDCField_38 + v3.m_rDCField_3C + v3.m_rDCField_50;
				
				if (m_xDocDTParam.m_fCalcProb_changingDPI)
				{
					if (v3.m_rMainProb > m_xDocDTParam.m_rCalcProb_changingDPI_MinProbBySize)
					{
						if (v3.m_rProportionDC > v3.m_rMainProb)
							v3.m_rMainProb = v3.m_rProportionDC;
					}
				}

				v3.m_rProbAngle = v3.m_rDCField_14 + v3.m_rMainProb;
				if (v3.m_nDocType == 5)
					v3.m_rProbAngle = v3.m_rDCField_14 + v3.m_rMainProb + 0.01f;
			}

		}
	}
}

void DocumentDetect::find_90_Last(DocumentCandidateList & a1, vector<int>& a2, vector<int>& a3)
{
	vector<int> v1, v2, v3;
	DocumentDetectDebugInfo * v4;
	a3.clear();

	if (!a2.empty())
	{
		a1.filterByMainProb(0.9f, a2, v1);
		if (!v1.empty())
		{
			a1.filterByMrzParam(0.85f, v1, v2);
			if (!v2.empty())
			{
				calculateDocumentParam(v2, a1.m_vDocCanList);
				a1.findBest(10, v2, v3);
				v4 = bounds::debug::dddi();
				v4->printCandidateInfo(a1, v3);
				a3.assign(v3.begin(), v3.end());
			}
		}
	}
}

void DocumentDetect::find_Free_Best(DocumentCandidateList & a1, vector<int> & a2, vector<int> & a3, bool a4, int a5)
{
	vector<int> v1, v2, v4, v5;
	calculateDocumentParam(a2, a1.m_vDocCanList);
	a1.filterByMainProb(0.1f, a2, v1);
	if (!v1.empty())
	{
		if (a4)
		{
			a1.filterViltualByAngle(5.0f, v1, v2);
		}
		
		a1.filterByKLen(0.4f, 0.2f, a4 ? v2 : v1, v4);
		if (!v4.empty())
		{
			a1.findBest(a5, v4, v5);
			a3.assign(v5.begin(), v5.end());
		}

	}
}

void DocumentDetect::find_Free_Last(DocumentCandidateList & a1, vector<int>& a2, vector<int>& a3)
{
	vector<int> v1, v2, v3, v4;
	DocumentDetectDebugInfo* v5;

	calculateDocumentParam(a2, a1.m_vDocCanList);
	a1.filterByMainProb(0.1f, a2, v1);
	if (!v1.empty())
	{
		a1.filterViltualByAngle(3.0f, v1, v2);
		a1.calculateProbAngle(v2);
		a1.filterByKLen_3_1(0.6f, 0.2f, v2, v3);
		if (!v3.empty())
		{
			a1.findBest(10, v3, v4);
			v5 = bounds::debug::dddi();
			v5->printCandidateInfo(a1, v4);
			a3.assign(v4.begin(), v4.end());
		}
	}
}

void DocumentDetect::find_Multi(DocumentCandidateList & a1, DocumentCandidate & a2, vector<int> & a3, vector<int> & a4)
{
	vector<int> v1, v3, v4, v5, v6;
	int v2;
	DocumentCandidate v7;
	DocumentDetectDebugInfo * v8;

	a1.filterByIntersect(a2, a3, v1);
	calculateDocumentParam(v1, a1.m_vDocCanList);
	v2 = m_xDocIdCheck.docResolution(a2.m_nDocType, (int)a2.m_xDocSize.width, 0);

	a1.calculateProbForDPI(m_xDocIdCheck, v1, v2);
	a1.filterByDocType(a2.m_nDocType, v1, v3);
	a1.calculateProbUpd(v3, 0);
	a1.findBest(10, v3, v4);
	a1.filterByMainProb(1.0f - m_xDocDTParam.m_rDocDeviation, v3, v5);
	v1.assign(v5.begin(), v5.end());

	while (true)
	{
		a1.filterByCalcReady(v1, v6);
		v2 = a1.findBest(v6);
		if (v2 == -1)
			break;

		a4.push_back(v2);
		v8 = bounds::debug::dddi();
		v8->linesSave(a1.m_vDocCanList[v2], 0);
		v7 = a1.m_vDocCanList[v2];
		a1.filterByIntersect(v7, v6, v1);
	}
}

void DocumentDetect::calculateDocParam_MRZ2(TBoundsResult & a1, DocumentCandidate & a2, float & a3)
{
	vector<Point2f> v2, v3, v4, v5;
	vector<vector<Point2f>> v6;
	float v7, v8, v9, v10;

	v2.push_back(bounds::result::centerDocByCorners(a1));
	if (bounds::result::isAllPointsInside(v2, a2.m_vCornerDC))
	{
		v3.push_back(Point2f((float)a1.xTBR_LeftBottom.x, (float)a1.xTBR_LeftBottom.y));
		v3.push_back(Point2f((float)a1.xTBR_RightBottom.x, (float)a1.xTBR_RightBottom.y));
		v4.push_back(a2.m_vCornerDC[0]);
		v4.push_back(a2.m_vCornerDC[1]);
		v5.push_back(a2.m_vCornerDC[2]);
		v5.push_back(a2.m_vCornerDC[3]);
		v6.push_back(v4);
		v6.push_back(v5);
		v7 = sqrt((v6[0][0].x - v6[0][1].x) * (v6[0][0].x - v6[0][1].x) + (v6[0][0].y - v6[0][1].y) * (v6[0][0].y - v6[0][1].y));
		v8 = sqrt((v6[0][0].x - v6[1][0].x) * (v6[0][0].x - v6[1][0].x) + (v6[0][0].y - v6[1][0].y) * (v6[0][0].y - v6[1][0].y));
		v9 = sqrt((v6[0][0].x - v6[1][1].x) * (v6[0][0].x - v6[1][1].x) + (v6[0][0].y - v6[1][1].y) * (v6[0][0].y - v6[1][1].y));

		if (v9 < v8)
			v8 = v9;
		if (v7 >= v8 && a2.m_nDocType == 5)
			reverse(v6.begin(), v6.end());

		if (v7 < v8 && a2.m_nDocType != 5)
			reverse(v6.begin(), v6.end());

		a3 = 3.4028e38f;
		for (uint i = 0; i < v6.size(); i++)
		{
			v10 = bounds::maxDistanceMrz2(v3, v6[i]);
			if (a3 > v10)
				a3 = v10;
		}
	}
	else
	{
		v10 = a2.m_xDocSize.width;
		if (a2.m_xDocSize.width < a2.m_xDocSize.height)
			v10 = a2.m_xDocSize.height;
		a3 = v10;
	}
}

void DocumentDetect::calculateDocParam_MRZ2(vector<TBoundsResult> & a1, DocumentCandidate & a2, float & a3)
{
	float v2;
	a3 = 1.0;

	if(!a1.empty())
	{
		vector<float> v1(a1.size());
		for (uint i = 0; i < v1.size(); i++)
			calculateDocParam_MRZ2(a1[i], a2, v1[i]);

		if (!v1.empty())
		{
			v2 = v1[0];
			for (uint i = 1; i < v1.size(); i++)
			{
				if (v1[i] < v2)
					v2 = v1[i];
			}
		}
		a3 = v2;
	}
}

void DocumentDetect::calculateDocParam_MRZ4(TBoundsResult & a1, DocumentCandidate & a2, float & a3, uchar & a4)
{
	vector<tagPOINT> v1;
	float v2, v3, v4, v5;

	v1.push_back(a1.xTBR_LeftTop);
	v1.push_back(a1.xTBR_LeftBottom);
	v1.push_back(a1.xTBR_RightBottom);
	v1.push_back(a1.xTBR_RightTop);

	a3 = 0;
	a4 = 0;
	for (uint i = 0; i < v1.size(); i++)
	{
		v5 = 3.4028e38f;
		for (uint j = 0; j < a2.m_vCornerDC.size(); j++)
		{
			v2 = a2.m_vCornerDC[j].x - v1[i].x;
			v3 = a2.m_vCornerDC[j].y - v1[i].y;
			v4 = sqrt(v2 * v2 + v3 * v3);
			if (v5 > v4)
			{
				v5 = v4;
				if (i == 1)
					a4 = j;
			}			
		}

		if (a3 < v5)
			a3 = v5;
	}
}

void DocumentDetect::calculateDocParam_MRZ4(vector<TBoundsResult> & a1, DocumentCandidate & a2, float & a3)
{
	float v1;
	uchar v2;
	a3 = 1.0;

	if (!a1.empty())
	{
		a3 = 3.4028e38f;
		for (uint i = 0; i < a1.size(); i++)
		{
			v1 = 0;
			v2 = 0;
			calculateDocParam_MRZ4(a1[i], a2, v1, v2);
			if (v1 < a3)
				a3 = v1;
		}
	}
}

void DocumentDetect::find_BigestFree(DocumentCandidateList & a1, vector<int>& a2, int a3, vector<int>& a4)
{
	vector<int> v1;
	DocumentDetectDebugInfo * v2;

	a4.clear();
	if (!a2.empty())
	{
		a1.calculateProbForFreeDoc(a2, 0.3f);
		a1.findBest(a3, a2, v1);
		v2 = bounds::debug::dddi();
		v2->printCandidateInfo(a1, v1);
		a4.assign(v1.begin(), v1.end());
	}
}

void DocumentDetect::removePerimeterLines(Size & a1, int a2, vector<LineEx>& a3, vector<LineEx>& a4)
{
	a4.clear();
	for (uint i = 0; i < a3.size(); i++)
	{
		if (a3[i].m_xStartPoint.x >= a2 && a3[i].m_xEndPoint.x >= a2)
		{
			if (a3[i].m_xStartPoint.x <= (a1.width - a2) && a3[i].m_xEndPoint.x <= (a1.width - a2))
			{
				if (a3[i].m_xStartPoint.y >= a2 && a3[i].m_xEndPoint.y >= a2)
				{
					if (a3[i].m_xStartPoint.y <= (a1.height - a2) && a3[i].m_xEndPoint.y <= (a1.height - a2))
						a4.push_back(a3[i]);
				}
			}
		}
	}
}

void DocumentDetect::getLines(vector<vector<Point>> & a1, double & a2, vector<LineEx> & a3)
{
	if (a3.empty())
	{
		int nReserve = 0;
		for (uint i = 0; i < a1.size(); i++)
		{
			nReserve += a1[i].size();
		}
		a3.reserve(nReserve);
	}
	
	for (uint i = 0; i < a1.size(); i++)
	{
		if (a1[i].size() >= 4)
		{
			++m_countourIndx;
			LineEx v1;
			v1.m_nCountourID = m_countourIndx;
			v1.m_nLineType = 9;

			vector<Point> v3(a1[i].size());
			Mat mat(a1[i], 0);
			approxPolyDP(mat, v3, a2, true);

			for (uint j = 0; j < v3.size() - 1; j++)
			{
				v1.m_xStartPoint = v3[j];
				v1.m_xEndPoint = v3[j + 1];
				a3.push_back(v1);
			}

			if (v3.size() > 2)
			{
				v1.m_xStartPoint = v3[v3.size() - 1];
				v1.m_xEndPoint = v3[0];
				a3.push_back(v1);
			}
		}
	}
}