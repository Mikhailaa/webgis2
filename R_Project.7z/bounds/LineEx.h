#pragma once

#include "../pch.h"

class LineGroup;

class LineEx
{
public:
	LineEx();
	LineEx(LineEx const & a1);
	LineEx(LineEx && a1);
	LineEx(cv::Point2f & a1, cv::Point2f & a2);
	LineEx(cv::Point & a1, cv::Point & a2);
	~LineEx();

	LineEx & operator=(LineEx & a1);
	LineEx & operator=(LineEx && a1);

public:
	cv::Point m_xStartPoint; //0
	cv::Point m_xEndPoint;
	double m_rLineAngle;  //10
	float m_rRotateSy;
	float m_rRotateEy;
	float m_rRotateSx;   //20
	float m_rRotateEx;
	float m_rLineLen;  
	int m_nCountourID;
	int m_nLineType;  //30
};


namespace LineExProcess {
	void calcLen(LineEx & a1);
	void calcLen(vector<LineEx> & a1);
	void computeIntersect(LineEx & a1, LineEx & a2, cv::Point2f & a3);
	void filterLinesByLength(vector<LineEx> & a1, float a2, vector<LineEx> & a3, vector<LineEx> & a4);
	void generateBorderLines(tagSIZE a1, vector<LineEx> & a2);
	void generateRectsLines(tagPOINT & a1, tagPOINT & a2, tagPOINT & a3, tagPOINT & a4, vector<LineEx> & a5);
	void initLineParam(LineEx & a1, float a2);
	void initLinesAngle(vector<LineEx> & a1);
	int combineLines(vector<LineEx> & a1, vector<int> & a2, float a3, vector<LineGroup> & a4, int a5);
}