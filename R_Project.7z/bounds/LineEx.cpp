﻿#include "LineEx.h"
#include "LineGroup.h"

#define PI 3.14159265358979323846

LineEx::LineEx()
{
	m_xStartPoint = cv::Point(0, 0);
	m_xEndPoint = cv::Point(0, 0);
	m_rLineAngle = 361.0;
	m_rRotateSy = 0.0f;
	m_rRotateEy = 0.0f;
	m_rRotateSx = 0.0f;
	m_rRotateEx = 0.0f;
	m_rLineLen = -1.0f;
	m_nCountourID = -1;
	m_nLineType = 1;
}

LineEx::LineEx(LineEx const & a1)
{
	m_xStartPoint = a1.m_xStartPoint;
	m_xEndPoint = a1.m_xEndPoint;
	m_rLineAngle = a1.m_rLineAngle;
	m_rRotateSy = a1.m_rRotateSy;
	m_rRotateEy = a1.m_rRotateEy;
	m_rRotateSx = a1.m_rRotateSx;
	m_rRotateEx = a1.m_rRotateEx;
	m_rLineLen = a1.m_rLineLen;
	m_nCountourID = a1.m_nCountourID;
	m_nLineType = a1.m_nLineType;
}

LineEx::LineEx(LineEx && a1)
{
	m_xStartPoint = a1.m_xStartPoint;
	m_xEndPoint = a1.m_xEndPoint;
	m_rLineAngle = a1.m_rLineAngle;
	m_rRotateSy = a1.m_rRotateSy;
	m_rRotateEy = a1.m_rRotateEy;
	m_rRotateSx = a1.m_rRotateSx;
	m_rRotateEx = a1.m_rRotateEx;
	m_rLineLen = a1.m_rLineLen;
	m_nCountourID = a1.m_nCountourID;
	m_nLineType = a1.m_nLineType;
}

LineEx::LineEx(cv::Point2f & a1, cv::Point2f & a2)
{
	m_xStartPoint = a1;
	m_xEndPoint = a2;
	m_rLineAngle = 361.0;
	m_rRotateSy = 0.0f;
	m_rRotateEy = 0.0f;
	m_rRotateSx = 0.0f;
	m_rRotateEx = 0.0f;
	m_rLineLen = -1.0f;
	m_nCountourID = -1;
	m_nLineType = 1;
}

LineEx::LineEx(cv::Point & a1, cv::Point & a2)
{
	m_xStartPoint = a1;
	m_xEndPoint = a2;
	m_rLineAngle = 0.0;
	m_rRotateSy = 0.0f;
	m_rRotateEy = 0.0f;
	m_rRotateSx = 0.0f;
	m_rRotateEx = 0.0f;
	m_rLineLen = 0.0f;
	m_nCountourID = 0;
	m_nLineType = 1;
}

LineEx::~LineEx()
{

}

LineEx & LineEx::operator=(LineEx & a1)
{
	m_xStartPoint = a1.m_xStartPoint;
	m_xEndPoint = a1.m_xEndPoint;
	memcpy(&m_rLineAngle, &a1.m_rLineAngle, 0x24);
	return *this;
}

LineEx & LineEx::operator=(LineEx && a1)
{
	m_xStartPoint = a1.m_xStartPoint;
	m_xEndPoint = a1.m_xEndPoint;
	memcpy(&m_rLineAngle, &a1.m_rLineAngle, 0x24);
	return *this;
}

namespace LineExProcess {
	void calcLen(LineEx & a1)
	{
		float v1, v2;
		v1 = (float)a1.m_xEndPoint.x - a1.m_xStartPoint.x;
		v2 = (float)a1.m_xEndPoint.y - a1.m_xStartPoint.y;
		a1.m_rLineLen = sqrt(v1 * v1 + v2 * v2);
	}

	void calcLen(vector<LineEx> & a1)
	{
		for (uint i = 0; i < a1.size(); i++)
			calcLen(a1[i]);
	}

	int combineLines(vector<LineEx> & vLine_a1, vector<int> & vn_a2, float r_a3,
		vector<LineGroup> & vLineGroup_a4, int n_a5)
	{
		//correct
		LineEx v3;
		vLineGroup_a4.clear();

		if (n_a5 >= 1)
			vLineGroup_a4.reserve(n_a5);

		vector<LineEx>  vLine_94(vLine_a1);
		vector<int> vn_a1_A0(vn_a2.size(), 1);

		while (!vn_a1_A0.empty() && (n_a5 == -1 || n_a5 != vLineGroup_a4.size()))
		{
			float rMax = -2.0;
			int nMinIndex = 0;
			for (uint i = 0; i < vn_a1_A0.size(); i++)
			{
				if (vn_a1_A0[i])
				{
					v3 = vLine_a1[vn_a2[i]];
					if (v3.m_rLineLen > rMax)
					{
						rMax = v3.m_rLineLen;
						nMinIndex = i;
					}
				}
			}
			
			if (rMax == -2.0) break;

			vector<int> vn_AC;
			vn_AC.push_back(vn_a2[nMinIndex]);
			vn_a1_A0[nMinIndex] = 0;
			initLineParam(vLine_94[vn_a2[nMinIndex]], (float)vLine_94[vn_a2[nMinIndex]].m_rLineAngle);

			for (uint i = 0; i < vn_a2.size(); i++)
			{
				if (vn_a1_A0[i])
				{
					initLineParam(vLine_94[vn_a2[i]], (float)vLine_94[vn_a2[nMinIndex]].m_rLineAngle);
					if (fabsf(vLine_94[vn_a2[i]].m_rRotateSy - vLine_94[vn_a2[nMinIndex]].m_rRotateSy) < r_a3 &&
						fabsf(vLine_94[vn_a2[i]].m_rRotateEy - vLine_94[vn_a2[nMinIndex]].m_rRotateEy) < r_a3)
					{
						vn_a1_A0[i] = 0;
						vn_AC.push_back(vn_a2[i]);
					}
				}
			}

			vLineGroup_a4.push_back(LineGroup());
			LineGroup & v7 = vLineGroup_a4.at(vLineGroup_a4.size() - 1);
			for (uint i = 0; i < vn_AC.size(); i++)
				v7.m_vLineExGr.push_back(vLine_a1[vn_AC[i]]);

			v7.calcRealAngle();
			v7.calcMiddlePoint();
			v7.updateContoursID();

			for (uint i = 0; i < v7.m_vLineExGr.size(); i++)
				initLineParam(v7.m_vLineExGr[i], v7.m_rAngleGr);

			v7.mergeSegments(5.0);
			v7.m_rSegLen = v7.segnemtLen(-100000.0, 100000.0);
		}

		for (uint i = 0; i < vLineGroup_a4.size(); i++)
		{
			for (uint j = 0; j < vLineGroup_a4[i].m_vLineExGr.size(); j++)
			{
				if (vLineGroup_a4[i].m_vLineExGr[j].m_nLineType == 2)  //borderLine
				{
					vLineGroup_a4[i].m_bSegkLenGr_3C = true;
					break;
				}
			}
		}
		
		return 0;
	}

	void computeIntersect(LineEx & a1, LineEx& a2, cv::Point2f & a3)
	{
		float v1, v2, v3, v4, v5, v6, v7;

		a3 = cv::Point2f(-1.0, -1.0);

		v1 = (float)a1.m_xStartPoint.x - a1.m_xEndPoint.x;
		v2 = (float)a1.m_xStartPoint.y - a1.m_xEndPoint.y;
		v3 = (float)a2.m_xStartPoint.x - a2.m_xEndPoint.x;
		v4 = (float)a2.m_xStartPoint.y - a2.m_xEndPoint.y;
		v5 = v1 * v4 - v2 * v3;

		if (v5)
		{
			v6 = (float)a2.m_xStartPoint.x * a2.m_xEndPoint.y - a2.m_xEndPoint.x * a2.m_xStartPoint.y;
			v7 = (float)a1.m_xEndPoint.y * a1.m_xStartPoint.x - a1.m_xStartPoint.y * a1.m_xEndPoint.x;
			a3.x = (v3 * v7 - v1 * v6) / v5;
			a3.y = (v4 * v7 - v2 * v6) / v5;
		}
	}

	void filterLinesByLength(vector<LineEx> & a1, float a2, vector<LineEx> & a3, vector<LineEx> & a4)
	{
		vector<float> v1;
		float v2, v3, v4;
		LineEx v5;

		a3.reserve(a1.size());
		a4.reserve(a1.size());

		for (uint i = 0; i < a1.size(); i++)
		{
			v2 = (float)a1[i].m_xEndPoint.x - a1[i].m_xStartPoint.x;
			v3 = (float)a1[i].m_xEndPoint.y - a1[i].m_xStartPoint.y;
			v4 = sqrt(v2 * v2 + v3 * v3);
			v1.push_back(v4);
		}

		for (uint i = 0; i < a1.size(); i++)
		{
			v5 = a1[i];
			v5.m_rLineLen = v1[i];
			if (v1[i] >= a2)
				a3.push_back(v5);
			else
				a4.push_back(v5);
		}
	}

	void generateBorderLines(tagSIZE a1, vector<LineEx> & a2)
	{
		a2.resize(4);

		a2[0].m_xStartPoint = cv::Point(0, 0);
		a2[0].m_xEndPoint = cv::Point(0, a1.cy - 1);
		a2[1].m_xStartPoint = cv::Point(0, 0);
		a2[1].m_xEndPoint = cv::Point(a1.cx - 1, 0);
		a2[2].m_xStartPoint = cv::Point(0, a1.cy - 1);
		a2[2].m_xEndPoint = cv::Point(a1.cx - 1, a1.cy - 1);
		a2[3].m_xStartPoint = cv::Point(a1.cx - 1, 0);
		a2[3].m_xEndPoint = cv::Point(a1.cx - 1, a1.cy - 1);

		for (uint i = 0; i < a2.size(); i++)
			a2[i].m_nLineType = 2;
	}

	void generateRectsLines(tagPOINT & a1, tagPOINT & a2, tagPOINT & a3, tagPOINT & a4, vector<LineEx> & a5)
	{
		LineEx v1;

		v1.m_xStartPoint.x = a2.x;
		v1.m_xStartPoint.y = a2.y;
		v1.m_xEndPoint.x = a1.x;
		v1.m_xEndPoint.y = a1.y;
		a5.push_back(v1);

		v1.m_xStartPoint.x = a4.x;
		v1.m_xStartPoint.y = a4.y;
		v1.m_xEndPoint.x = a3.x;
		v1.m_xEndPoint.y = a3.y;
		a5.push_back(v1);

		v1.m_xStartPoint.x = a1.x;
		v1.m_xStartPoint.y = a1.y;
		v1.m_xEndPoint.x = a3.x;
		v1.m_xEndPoint.y = a3.y;
		a5.push_back(v1);

		v1.m_xStartPoint.x = a2.x;
		v1.m_xStartPoint.y = a2.y;
		v1.m_xEndPoint.x = a4.x;
		v1.m_xEndPoint.y = a4.y;
		a5.push_back(v1);
	}

	void initLinesAngle(vector<LineEx> & a1)
	{
		//correct
		cv::Point v1;
		float v2, v3, v4;

		for (uint i = 0; i < a1.size(); i++)
		{
			if (a1[i].m_xStartPoint.x > a1[i].m_xEndPoint.x) 
			{
				v1 = a1[i].m_xStartPoint;
				a1[i].m_xStartPoint = a1[i].m_xEndPoint;
				a1[i].m_xEndPoint = v1;
			}

			v2 = (float)a1[i].m_xEndPoint.x - a1[i].m_xStartPoint.x;
			v4 = (float)a1[i].m_xEndPoint.y - a1[i].m_xStartPoint.y;

			if (v2)
				v3 = atanf( v4 / v2);
			else
				v3 = (float)(PI / 2);

			a1[i].m_rLineAngle = (v3 * 180.0) / PI;
		}
	}

	void initLineParam(LineEx & xLine_a1, float r_a2)
	{
		float  r_abs, r_v2, v3, v4, v5, v6, v7, v8, v9;

		r_abs = fabsf((float)(r_a2 - xLine_a1.m_rLineAngle));
		r_v2 = (r_a2 < 0.0f) ? 90.0f : -90.0f;
		v3 = r_a2 + r_v2;
		v4 = fminf(r_abs, fabs(r_abs - 180.0f));
				
		v5 = v3;
		v6 = r_a2;
		if (v4 > 45.0)
		{
			v5 = r_a2;
			v6 = v3;
		}

		v7 = (float)cos(v6 * PI / 180.0);
		v8 = (float)sin(v6 * PI / 180.0);

		xLine_a1.m_rRotateSx = v8 * xLine_a1.m_xStartPoint.y + v7 * xLine_a1.m_xStartPoint.x;
		xLine_a1.m_rRotateEx = v8 * xLine_a1.m_xEndPoint.y + v7 * xLine_a1.m_xEndPoint.x;

		if (xLine_a1.m_rRotateSx > xLine_a1.m_rRotateEx)
		{
			v9 = xLine_a1.m_rRotateSx;
			xLine_a1.m_rRotateSx = xLine_a1.m_rRotateEx;
			xLine_a1.m_rRotateEx = v9;
		}

		v7 = (float)cos(v5 * PI / 180.0);
		v8 = (float)sin(v5 * PI / 180.0);

		xLine_a1.m_rRotateSy = v8 * xLine_a1.m_xStartPoint.y + v7 * xLine_a1.m_xStartPoint.x;
		xLine_a1.m_rRotateEy = v8 * xLine_a1.m_xEndPoint.y + v7 * xLine_a1.m_xEndPoint.x;
	}
}