#pragma once
#include "../pch.h"
#include "../commonStruct.h"

struct ImageExMat
{
public:
	cv::Mat m_xImageExMat;
	eBinProcessImg m_neBPI;
	eBinProcess m_neBP;
};

class ImagesListMat
{
public:
	ImageExMat * create(eBinProcessImg a1, eBinProcess a2);
	ImageExMat * image(eBinProcessImg a1, eBinProcess a2);

public:
	vector<ImageExMat *> m_vImagesMat;
};

namespace ImagesListProcess
{
	void generateImage(ImagesListMat & a1, eBinProcessImg a2);
}
