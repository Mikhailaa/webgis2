#include "ProcessVariant.h"

ProcessVariant::ProcessVariant(ProcessVariant const & a1)
{
	m_veBPI = a1.m_veBPI;
	m_veBP = a1.m_veBP;
	m_rKLineLenFilter = a1.m_rKLineLenFilter;
	m_nProcessType = a1.m_nProcessType;
}

ProcessVariant::ProcessVariant(ProcessVariant && a1)
{
	m_veBPI = move(a1.m_veBPI);
	m_veBP = move(a1.m_veBP);
	m_rKLineLenFilter = move(a1.m_rKLineLenFilter);
	m_nProcessType = move(a1.m_nProcessType);
}

ProcessVariant::ProcessVariant()
{
	m_rKLineLenFilter = 1.0f;
	m_nProcessType = 0;
}

ProcessVariant::~ProcessVariant()
{
}

ProcessVariant & ProcessVariant::operator=(ProcessVariant const & a1)
{
	if (&a1 != this)
	{
		m_veBPI.assign(a1.m_veBPI.begin(), a1.m_veBPI.end());
		m_veBP.assign(a1.m_veBP.begin(), a1.m_veBP.end());
	}
	m_rKLineLenFilter = a1.m_rKLineLenFilter;
	m_nProcessType = a1.m_nProcessType;

	return *this;
}

void ProcessVariantsStore::filter(vector<wstring>& a2, vector<ProcessVariant>& a3)
{
	map<wstring, ProcessVariant>::iterator v1;
	a3.clear();
	for (uint i = 0; i < a2.size(); i++)
	{
		v1 = m_mapPV.find(a2[i]);
		
		if (v1 != m_mapPV.end())
			a3.push_back(v1->second);
	}
}
