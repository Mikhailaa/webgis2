#include "DocumentCandidate.h"
#include "LineEx.h"

bool IsPointInside(vector<Point2f>& a1, Point2f & a2)
{
	int v1, v3, v4, v5, v6, v7, v8;
	float v2;
	bool v9 = false;

	if (a1.size() >= 2)
	{
		v3 = a1.size() - 1;
		v1 = 0;
		v6 = 0;
		if (a1[v3].y < a2.y)
			v1 = 1;

		for (uint i = 0; i < a1.size(); i++)
		{
			v4 = 0;
			v2 = (a1[v3].x - a2.x) * ((a1[i].y - a2.y) - (a1[v3].y - a2.y)) -
				(a1[v3].y - a2.y) * ((a1[i].x - a2.x) - (a1[v3].x - a2.x));

			if (a1[i].y < a2.y)
			{
				v4 = 1;
				v5 = 0;
				if (v2 > 0.0)
					v5 = 1;
				v6 += v5 & (v1 ^ 1);
			}

			v7 = 0;
			v8 = 0;
			v3 = i;
			if (a1[i].y > a2.y)
				v7 = 1;
			if (v2 < 0.0)
				v8 = 1;

			v6 += v1 & v8 & v7;
			v1 = v4;
		}

		v9 = v6 & 1;
	}
	return v9;
}

bool intersectLines(Point2f & a1, Point2f & a2, Point2f & a3, Point2f & a4)
{
	float v1, v2;

	if (a1.x == a3.x && a1.y == a3.y)
		return true;
	if (a2.x == a4.x && a2.y == a4.y)
		return true;
	if (a2.x == a3.x && a2.y == a3.y)
		return true;
	if (a1.x == a4.x)
		return true;

	v1 = ((a4.x - a3.x) * (a1.y - a3.y) - (a1.x - a3.x) * (a4.y - a3.y)) *
		((a4.x - a3.x) * (a2.y - a3.y) - (a2.x - a3.x) * (a4.y - a3.y));
	v2 = ((a2.x - a1.x) * (a3.y - a1.y) - (a3.x - a1.x) * (a2.y - a1.y)) *
		((a2.x - a1.x) * (a4.y - a1.y) - (a4.x - a1.x) * (a2.y - a1.y));

	if (v1 < 0.0 && v2 < 0.0)
		return true;

	return false;
}

bool intersectLines(vector<Point2f> & a1, vector<Point2f> & a2)
{
	int v1, v2;

	for (uint i = 0; i < a1.size(); i++)
	{
		v1 = i + 1;
		if (v1 == a1.size())
			v1 = 0;

		for (uint j = 0; j < a2.size(); j++)
		{
			v2 = j + 1;
			if (v2 == a2.size())
				v2 = 0;
			if (intersectLines(a1[i], a1[v1], a2[j], a2[v2]))
				return true;
		}
	}

	return false;
}

DocumentCandidate::DocumentCandidate()
{
	memset(this, 0, 0xAC);
	m_rBottomSegLen = -1;
	m_rBottomSegkLen = 1.0;
	m_rTopSegLen = -1;
	m_rTopSegkLen = 1.0;
	m_rLeftSegLen = -1;
	m_rLeftSegkLen = 1.0;
	m_rRightSegLen = -1;
	m_rRightSegkLen = 1.0;
	clear();
}

DocumentCandidate::DocumentCandidate(DocumentCandidate const & a1)
{
	memcpy(this, &a1, 0xAC);
	m_vCornerDC = a1.m_vCornerDC;
	m_xCenterDC = a1.m_xCenterDC;
}

DocumentCandidate::DocumentCandidate(DocumentCandidate && a1)
{
	memcpy(this, &a1, 0xAC);
	m_vCornerDC = move(a1.m_vCornerDC);
	m_xCenterDC = move(a1.m_xCenterDC);
}

float DocumentCandidate::calcAngleByHSides()
{
	float v1, v2, v3, v4, v5, v6;

	v1 = m_pBottomLGr->m_rAngleGr;
	v2 = m_pTopLGr->m_rAngleGr;

	v3 = v1 > 45.0f || v1 < -45.0f || v2 > 45.0f || v2 < -45.0f;
	v4 = v1 / 90.0f - (int)(v1 / 90.0f);
	v5 = v2 / 90.0f - (int)(v2 / 90.0f);

	if (v4 > 0.5)
		v4 -= 1.0;
	if (v5 > 0.5)
		v5 -= 1.0;
	if (v4 < -0.5)
		v4 += 1.0;
	if (v5 < -0.5)
		v5 += 1.0;

	v6 = ((v4 + v5) * 0.5f) * 90.0f;
	if (v3)
		v6 += 90.0f;

	return v6;
}

float DocumentCandidate::minKLen()
{
	float v1, v2;

	v1 = m_rLeftSegkLen;
	v2 = m_rBottomSegkLen;
	if (m_rRightSegkLen < v1)
		v1 = m_rRightSegkLen;
	if (m_rTopSegkLen < v2)
		v2 = m_rTopSegkLen;
	if (v1 < v2)
		v2 = v1;
	return v2;
}

int DocumentCandidate::checkLinesContours()
{
	int vResult = 0;
	uint i, j;

	for (i = 0; i < m_pBottomLGr->m_vContoursID.size(); i++)
	{
		for (j = 0; j < m_pLeftLGr->m_vContoursID.size(); j++)
		{
			if (m_pLeftLGr->m_vContoursID[j] == m_pBottomLGr->m_vContoursID[i])
			{
				vResult = 1;
				break;
			}
		}

		if (j != m_pLeftLGr->m_vContoursID.size())
			break;
	}

	for (i = 0; i < m_pBottomLGr->m_vContoursID.size(); i++)
	{
		for (j = 0; j < m_pRightLGr->m_vContoursID.size(); j++)
		{
			if (m_pRightLGr->m_vContoursID[j] == m_pBottomLGr->m_vContoursID[i])
			{
				vResult++;
				break;
			}
		}

		if (j != m_pRightLGr->m_vContoursID.size())
			break;
	}

	for (i = 0; i < m_pTopLGr->m_vContoursID.size(); i++)
	{
		for (j = 0; j < m_pLeftLGr->m_vContoursID.size(); j++)
		{
			if (m_pLeftLGr->m_vContoursID[j] == m_pTopLGr->m_vContoursID[i])
			{
				vResult++;
				break;
			}
		}

		if (j != m_pLeftLGr->m_vContoursID.size())
			break;
	}

	for (i = 0; i < m_pTopLGr->m_vContoursID.size(); i++)
	{
		for (j = 0; j < m_pRightLGr->m_vContoursID.size(); j++)
		{
			if (m_pRightLGr->m_vContoursID[j] == m_pTopLGr->m_vContoursID[i])
			{
				vResult++;
				break;
			}
		}

		if (j != m_pRightLGr->m_vContoursID.size())
			break;
	}

	return vResult;
}

bool DocumentCandidate::cornersDocument(vector<Point2f> & a1)
{
	int v1, v2, v3, v4;
	bool bResult;

	a1.resize(4);
	v1 = m_pLeftLGr->maxSegment();
	v2 = m_pBottomLGr->maxSegment();
	v3 = m_pRightLGr->maxSegment();
	v4 = m_pTopLGr->maxSegment();

	bResult = true;

	if (v1 != -1 && v2 != -1 && v3 != -1 && v4 != -1)
	{
		LineExProcess::computeIntersect(m_pLeftLGr->m_vLineExGr[v1], m_pBottomLGr->m_vLineExGr[v2], a1[0]);
		LineExProcess::computeIntersect(m_pBottomLGr->m_vLineExGr[v2], m_pRightLGr->m_vLineExGr[v3], a1[1]);
		LineExProcess::computeIntersect(m_pRightLGr->m_vLineExGr[v3], m_pTopLGr->m_vLineExGr[v4], a1[2]);
		LineExProcess::computeIntersect(m_pTopLGr->m_vLineExGr[v4], m_pLeftLGr->m_vLineExGr[v1], a1[3]);

		bResult = false;
	}

	return bResult;
}

void DocumentCandidate::checkInternalAngle(float & a1, float & a2)
{
	vector<float> v1;

	v1.push_back(m_pBottomLGr->m_rAngleGr);
	v1.push_back(m_pLeftLGr->m_rAngleGr);
	v1.push_back(m_pTopLGr->m_rAngleGr);
	v1.push_back(m_pRightLGr->m_rAngleGr);

	checkInternalAngle(v1, a1, a2);
}

void DocumentCandidate::clear()
{
	m_xDocSize = Size2f(0, 0);
	m_bDCField_8 = 0;
	m_bMrzContain = 0;
	m_bCheckLineContour = 0;
	m_rAngleDC = 0;
	m_rDCField_50 = 0;
	m_rAuxProb = 0;
	m_nDocType = 3;
	m_rIntAngle = 0;
	m_rSumIntAngle = 0;
	m_rProbAngle = 0;
	m_rMainProb = 0;
	m_rMrzParam4 = 0;
	m_rMrzParam2 = 0;
	m_rDCField_3C = 0;
	m_rDCField_40 = 0;
}

void DocumentCandidate::cornersDocumentInvHW()
{
	float v1, v4, v6;
	int v3, v5;
	LineGroup * v2;

	v1 = m_xDocSize.width;
	m_xDocSize.width = m_xDocSize.height;
	m_xDocSize.height = v1;

	v2 = m_pBottomLGr;
	m_pBottomLGr = m_pLeftLGr;
	m_pLeftLGr = v2;

	v3 = m_rBottomSegLen;
	v4 = m_rBottomSegkLen;
	v5 = m_rBottomSegLenOut;
	v6 = m_rBottomSegkLenOut;
	m_rBottomSegLen = m_rLeftSegLen;
	m_rBottomSegkLen = m_rLeftSegkLen;
	m_rBottomSegLenOut = m_rLeftSegLenOut;
	m_rBottomSegkLenOut = m_rLeftSegkLenOut;
	m_rLeftSegLen = v3;
	m_rLeftSegkLen = v4;
	m_rLeftSegLenOut = v5;
	m_rLeftSegkLenOut = v6;

	v2 = m_pTopLGr;
	m_pTopLGr = m_pRightLGr;
	m_pRightLGr = v2;

	v3 = m_rTopSegLen;
	v4 = m_rTopSegkLen;
	v5 = m_rTopSegLenOut;
	v6 = m_rTopSegkLenOut;
	m_rTopSegLen = m_rRightSegLen;
	m_rTopSegkLen = m_rRightSegkLen; //?
	m_rTopSegLenOut = m_rRightSegLenOut;
	m_rTopSegkLenOut = m_rRightSegkLenOut;
	m_rRightSegLen = v3;
	m_rRightSegkLen = v4;
	m_rRightSegLenOut = v5;
	m_rRightSegkLenOut = v6;

	Point2f tmpPoint = m_vCornerDC[0];
	m_vCornerDC[0] = m_vCornerDC[1];
	m_vCornerDC[1] = m_vCornerDC[2];
	m_vCornerDC[2] = m_vCornerDC[3];
	m_vCornerDC[3] = tmpPoint;
}

void DocumentCandidate::cornersDocumentUpdHV(bool a1, bool a2)
{
	float v2, v4;
	int v1, v3;
	LineGroup * v5;

	if (a1)
	{
		reverse(m_vCornerDC.begin(), m_vCornerDC.end());
		v5 = m_pBottomLGr;
		m_pBottomLGr = m_pTopLGr;
		m_pTopLGr = v5;

		v1 = m_rBottomSegLen;
		v2 = m_rBottomSegkLen;
		v3 = m_rBottomSegLenOut;
		v4 = m_rBottomSegkLenOut;
		m_rBottomSegLen = m_rTopSegLen;
		m_rBottomSegkLen = m_rTopSegkLen;
		m_rBottomSegLenOut = m_rTopSegLenOut;
		m_rBottomSegkLenOut = m_rTopSegkLenOut;
		m_rTopSegLen = v1;
		m_rTopSegkLen = v2;
		m_rTopSegLenOut = v3;
		m_rTopSegkLenOut = v4;
	}

	if (a2)
	{
		Point2f tmpPoint = m_vCornerDC[0];
		m_vCornerDC[0] = m_vCornerDC[1];
		m_vCornerDC[1] = tmpPoint;

		tmpPoint = m_vCornerDC[2];
		m_vCornerDC[2] = m_vCornerDC[3];
		m_vCornerDC[3] = tmpPoint;

		v5 = m_pLeftLGr;
		m_pLeftLGr = m_pRightLGr;
		m_pRightLGr = v5;

		v1 = m_rLeftSegLen;
		v2 = m_rLeftSegkLen;
		v3 = m_rLeftSegLenOut;
		v4 = m_rLeftSegkLenOut;
		m_rLeftSegLen = m_rRightSegLen;
		m_rLeftSegkLen = m_rRightSegkLen;
		m_rLeftSegLenOut = m_rRightSegLenOut;
		m_rLeftSegkLenOut = m_rRightSegkLenOut;
		m_rRightSegLen = v1;
		m_rRightSegkLen = v2;
		m_rRightSegLenOut = v3;
		m_rRightSegkLenOut = v4;
	}
}

void DocumentCandidate::setSides(vector<LineGroup *> & a1)
{
	if (a1.size() >= 4)
	{
		m_pBottomLGr = a1[0];
		m_pTopLGr = a1[1];
		m_pLeftLGr = a1[2];
		m_pRightLGr = a1[3];
	}
}

void DocumentCandidate::kLenSides(vector<float> & a1)
{
	float v1, v2, v3;
	a1.resize(4);

	v1 = m_vCornerDC[0].x - m_vCornerDC[1].x;
	v2 = m_vCornerDC[0].y - m_vCornerDC[1].y;
	v3 = sqrt(v1 * v1 + v2 * v2);
	a1[0] = m_pBottomLGr->m_rSegLen / v3;

	v1 = m_vCornerDC[1].x - m_vCornerDC[2].x;
	v2 = m_vCornerDC[1].y - m_vCornerDC[2].y;
	v3 = sqrt(v1 * v1 + v2 * v2);
	a1[1] = m_pRightLGr->m_rSegLen / v3;

	v1 = m_vCornerDC[2].x - m_vCornerDC[3].x;
	v2 = m_vCornerDC[2].y - m_vCornerDC[3].y;
	v3 = sqrt(v1 * v1 + v2 * v2);
	a1[2] = m_pTopLGr->m_rSegLen / v3;

	v1 = m_vCornerDC[3].x - m_vCornerDC[0].x;
	v2 = m_vCornerDC[3].y - m_vCornerDC[0].y;
	v3 = sqrt(v1 * v1 + v2 * v2);
	a1[3] = m_pBottomLGr->m_rSegLen / v3;
}

float DocumentCandidate::calcAngleBySides(vector<float> & a1)
{
	float v1 = 0.0, v2;

	for (uint i = 0; i < a1.size(); i++)
	{
		v2 = a1[i] / 90.0f - (int)(a1[i] / 90.0f);

		if (v2 > 0.5f)
			v2 -= 1.0f;
		if (v2 < -0.5f)
			v2 += 1.0f;

		v1 += v2;
	}

	return (v1 * 0.25f) * 90.0f;
}

void DocumentCandidate::checkInternalAngle(vector<float> & a1, float & a2, float & a3)
{
	float v1, v2, v3, v4, v5, v6, v7, v8, v9, v10;

	v1 = fabsf(a1[0] - a1[1]);
	do
	{
		v2 = v1;
		v1 = fabsf(v1 - 90.0f);
	} while (v1 < v2);

	v3 = fabsf(a1[1] - a1[2]);
	do
	{
		v4 = v3;
		v3 = fabsf(v3 - 90.0f);
	} while (v3 < v4);

	v5 = fabsf(a1[2] - a1[3]);
	do
	{
		v6 = v5;
		v5 = fabsf(v5 - 90.0f);
	} while (v5 < v6);

	v7 = fabsf(a1[3] - a1[0]);
	do
	{
		v8 = v7;
		v7 = fabsf(v7 - 90.0f);
	} while (v7 < v8);

	v9 = fmaxf(v2, v4);
	v10 = fmaxf(v6, v8);

	a2 = fmaxf(v9, v10);
	a3 = v2 + v4 + v6 + v8;
}

void DocumentCandidate::documentSize(vector<Point2f> & a1, float & a2, float & a3, Point2f & a4, bool & a5, bool & a6)
{
	vector<Point2f> v1;
	float v2, v3;

	v2 = (a1[0].x + a1[1].x) * 0.5f;
	v3 = (a1[0].y + a1[1].y) * 0.5f;
	v1.push_back(Point2f(v2, v3));
	v2 = (a1[1].x + a1[2].x) * 0.5f;
	v3 = (a1[1].y + a1[2].y) * 0.5f;
	v1.push_back(Point2f(v2, v3));
	v2 = (a1[2].x + a1[3].x) * 0.5f;
	v3 = (a1[2].y + a1[3].y) * 0.5f;
	v1.push_back(Point2f(v2, v3));
	v2 = (a1[3].x + a1[0].x) * 0.5f;
	v3 = (a1[3].y + a1[0].y) * 0.5f;
	v1.push_back(Point2f(v2, v3));

	v2 = (v1[0].x + v1[2].x) * 0.5f;
	v3 = (v1[0].y + v1[2].y) * 0.5f;
	a4 = Point2f(v2, v3);

	v2 = v1[0].x - v1[2].x;
	v3 = v1[0].y - v1[2].y;
	a3 = sqrt(v2 * v2 + v3 * v3);

	v2 = v1[1].x - v1[3].x;
	v3 = v1[1].y - v1[3].y;
	a2 = sqrt(v2 * v2 + v3 * v3);

	a5 = 0;
	a6 = 0;
	if (v1[0].y > v1[2].y)
		a5 = 1;
	if (v1[3].x > v1[1].x)
		a6 = 1;
}

DocumentCandidate & DocumentCandidate::operator=(DocumentCandidate && a1)
{
	memcpy(this, &a1, 0xAC);
	m_vCornerDC = move(a1.m_vCornerDC);
	m_xCenterDC = move(a1.m_xCenterDC);
	return *this;
}

DocumentCandidate & DocumentCandidate::operator=(DocumentCandidate const & a1)
{
	memcpy(this, &a1, 0xAC);
	m_vCornerDC.assign(a1.m_vCornerDC.begin(), a1.m_vCornerDC.end());
	m_xCenterDC = a1.m_xCenterDC;
	return *this;
}

/*------------------------------DocumentCandidateList---------------------------------*/
void DocumentCandidateList::calculateProbAngle(vector<int>& a1)
{
	float v2 = 0.0;

	for (uint i = 0; i < a1.size(); i++)
	{
		DocumentCandidate & v1 = m_vDocCanList.at(a1[i]);
		if (v1.m_rSumIntAngle - 5.0f > 0.0f)
			v2 = v1.m_rSumIntAngle - 5.0f;
		v1.m_rProbAngle = (v1.m_rDCField_14 + 0.99f) + (v2 * 0.01f / -5.0f);
	}
}

void DocumentCandidateList::calculateProbForDPI(DocumentSize::DocumentIDCheck & a1, vector<int> & a2, int a3)
{
	float v1 = 1000.0f / a3, v3, v4;

	for (uint i = 0; i < a2.size(); i++)
	{
		DocumentCandidate & v2 = m_vDocCanList.at(a2[i]);
		v3 = v2.m_xDocSize.width * v1;
		v4 = v2.m_xDocSize.height * v1;
		v2.m_rProbAngle = 1.0;
		a1.isID(v3, v4, v2.m_rMainProb, v2.m_nDocType, 0);
	}
}

void DocumentCandidateList::calculateProbForFreeDoc(vector<int>& a1, float a2)
{
	float v1 = 0.0, v3, v4;

	for (uint i = 0; i < a1.size(); i++)
	{
		DocumentCandidate & v2 = m_vDocCanList.at(a1[i]);
		v3 = v2.m_xDocSize.width + v2.m_xDocSize.height;

		if (v2.m_bViltual || v1 >= v3)
			v2.m_rProbAngle = 0.0;
		else
		{
			v2.m_rProbAngle = v3;
			v1 = v3;
		}
	}

	for (uint i = 0; i < a1.size(); i++)
	{
		DocumentCandidate & v5 = m_vDocCanList.at(a1[i]);
		if (v5.m_rProbAngle > 0.0)
		{
			v4 = v5.m_xDocSize.width / v5.m_xDocSize.height;
			v5.m_rProbAngle /= v1;
			if (v4 < a2)
				v5.m_rProbAngle = 0.0;
			else if (1.0 / v4 < a2)
				v5.m_rProbAngle = 0.0;
		}
	}
}

void DocumentCandidateList::calculateProbForWrongDPI(float a1)
{
	float v2, v3;

	for (uint i = 0; i < m_vDocCanList.size(); i++)
	{
		DocumentCandidate & v1 = m_vDocCanList.at(i);
		v2 = v1.m_rAuxProb;
		if (v2 != 0.0 && v1.m_rMainProb > a1)
		{
			v3 = v1.m_rProportionDC;
			if (v3 > v2)
				v1.m_rMainProb = v3;
		}
	}
}

void DocumentCandidateList::calculateProbUpd(vector<int>& a1, int a2)
{
	if (a2)
	{
		for (uint i = 0; i < a1.size(); i++)
		{
			DocumentCandidate & v1 = m_vDocCanList.at(a1[i]);
			v1.m_rProbAngle = v1.m_rMainProb + v1.m_rDCField_14 + v1.m_rDCField_38;
		}
	}
	else
	{
		for (uint i = 0; i < a1.size(); i++)
		{
			DocumentCandidate & v1 = m_vDocCanList.at(a1[i]);
			v1.m_rProbAngle = v1.m_rMainProb + v1.m_rDCField_14;
		}
	}
}

void DocumentCandidateList::filterByCalcReady(vector<int>& a1, vector<int>& a2)
{
	a2.clear();
	a2.reserve(m_vDocCanList.size());
	for (uint i = 0; i < a1.size(); i++)
	{
		DocumentCandidate & v1 = m_vDocCanList.at(a1[i]);
		if (v1.m_bDCField_8)
			a2.push_back(a1[i]);
	}
}

void DocumentCandidateList::filterByDocType(int a1, vector<int> & a2, vector<int> & a3)
{
	a3.clear();
	a3.reserve(m_vDocCanList.size());
	for (uint i = 0; i < a2.size(); i++)
	{
		DocumentCandidate & v1 = m_vDocCanList.at(a2[i]);
		if (v1.m_nDocType == a1)
			a3.push_back(a2[i]);
	}
}

void DocumentCandidateList::filterByIntAngle(float a1, vector<int> & a2, vector<int> & a3)
{
	a2.clear();
	a2.reserve(m_vDocCanList.size());
	a3.clear();
	a3.reserve(m_vDocCanList.size());

	for (uint i = 0; i < m_vDocCanList.size(); i++)
	{
		DocumentCandidate & v1 = m_vDocCanList.at(i);
		if (v1.m_rIntAngle >= a1)
			a3.push_back(i);
		else
			a2.push_back(i);
	}
}

void DocumentCandidateList::filterByIntersect(DocumentCandidate & a1, vector<int>& a2, vector<int>& a3)
{
	a3.clear();
	a3.reserve(m_vDocCanList.size());

	for (uint i = 0; i < a2.size(); i++)
	{
		DocumentCandidate & v1 = m_vDocCanList.at(a2[i]);
		int j;
		for (j = 0; j < 4; j++)
		{
			if (!IsPointInside(a1.m_vCornerDC, v1.m_vCornerDC[j]))
				if (IsPointInside(v1.m_vCornerDC, a1.m_vCornerDC[j]))
					break;
			else
				break;
		}

		if (j != 4)
			continue;

		if (!intersectLines(v1.m_vCornerDC, a1.m_vCornerDC))
			a3.push_back(a2[i]);
	}
}

void DocumentCandidateList::filterByKLen(float a1, float a2, vector<int>& a3, vector<int>& a4)
{
	int v2, v3;

	a4.clear();
	a4.reserve(m_vDocCanList.size());
	for (uint i = 0; i < a3.size(); i++)
	{
		DocumentCandidate & v1 = m_vDocCanList.at(a3[i]);
		if (v1.minKLen() >= a2)
		{
			v2 = 1;
			v3 = 0;
			if (v1.m_rBottomSegkLen > a1)
			{
				v2 = 2;
				v3 = 1;
			}
			if (v1.m_rTopSegkLen > a1)
				v3 = v2;
			if (v1.m_rLeftSegkLen > a1)
				++v3;
			if (v1.m_rRightSegkLen > a1)
				++v3;
			if (v3 >= 3)
				a4.push_back(a3[i]);
		}
	}
}

void DocumentCandidateList::filterByKLen_3_1(float a1, float a2, vector<int>& a3, vector<int>& a4)
{
	float v2, v3;

	a4.clear();
	a4.reserve(m_vDocCanList.size());

	for (uint i = 0; i < a3.size(); i++)
	{
		DocumentCandidate & v1 = m_vDocCanList.at(a3[i]);
		if (v1.minKLen() >= a2)
		{
			v2 = 1;
			v3 = 0;
			if (v1.m_rBottomSegkLen > a1)
			{
				v2 = 2;
				v3 = 1;
			}
			if (v1.m_rTopSegkLen > a1)
				v3 = v2;
			if (v1.m_rLeftSegkLen > a1)
				++v3;
			if (v1.m_rRightSegkLen > a1)
				++v3;
			if (v3 >= 3)
				a4.push_back(a3[i]);
		}
	}
}

void DocumentCandidateList::filterByMainProb(float a1, vector<int>& a2, vector<int>& a3)
{
	a3.clear();
	a3.reserve(m_vDocCanList.size());

	for (uint i = 0; i < a2.size(); i++)
	{
		DocumentCandidate & v1 = m_vDocCanList.at(a2[i]);
		if (v1.m_rMainProb > a1)
			a3.push_back(a2[i]);
	}
}

void DocumentCandidateList::filterByMrzParam(float a1, vector<int>& a2, vector<int>& a3)
{
	a3.clear();
	a3.reserve(m_vDocCanList.size());

	for (uint i = 0; i < a2.size(); i++)
	{
		DocumentCandidate & v1 = m_vDocCanList.at(a2[i]);
		if (v1.m_rMrzParam4 > a1)
			a3.push_back(a2[i]);
	}
}

void DocumentCandidateList::filterByViltual(bool a1, vector<int> & a2, vector<int> & a3)
{
	a3.clear();
	a3.reserve(m_vDocCanList.size());

	for (uint i = 0; i < a2.size(); i++)
	{
		DocumentCandidate & v1 = m_vDocCanList.at(a2[i]);
		if (a1)
			if (!v1.m_bViltual)
				continue;
		else if (v1.m_bViltual)
			continue;
		a3.push_back(a2[i]);
	}
}

void DocumentCandidateList::filterViltualByAngle(float a1, vector<int>& a2, vector<int>& a3)
{
	a3.clear();
	a3.reserve(m_vDocCanList.size());

	for (uint i = 0; i < a2.size(); i++)
	{
		DocumentCandidate & v1 = m_vDocCanList.at(a2[i]);
		if (v1.m_rIntAngle < a1 || !v1.m_bViltual)
			a3.push_back(a2[i]);
	}
}

void DocumentCandidateList::findBest(int a1, vector<int>& a2, vector<int>& a3)
{
	a3.clear();
	if (!a2.empty())
	{
		vector<int> v1(a2.size(), 0);
		for (int i = 0; i < a1; i++)
		{
			for (uint j = 0; j < v1.size(); j++)
			{
				if (!v1[j])
				{
					for (uint k = j + 1; k < v1.size(); k++)
					{
						if (!v1[k])
						{
							if (m_vDocCanList[a2[j]].m_rProbAngle < m_vDocCanList[a2[k]].m_rProbAngle)
								j = k;
						}
					}

					a3.push_back(a2[j]);
					v1[j] = 1;
					break;
				}
			}
		}
	}
}

int DocumentCandidateList::findBest(vector<int>& a1)
{
	float v1, v2;
	int v3;

	if (a1.empty())
		return -1;
	v3 = a1[0];
	for (uint i = 0; i < a1.size(); i++)
	{
		v1 = m_vDocCanList[a1[i]].m_rProbAngle;
		v2 = m_vDocCanList[v3].m_rProbAngle;
		if (v1 > v2)
			v3 = a1[i];
	}

	if (m_vDocCanList[v3].m_rProbAngle == 0.0)
		return -1;

	return v3;
}

bool DocumentCandidateList::findBestByLines(vector<int>& a1, int & a2)
{
	float v1 = 2.0;

	a2 = -1;
	if (a1.empty())
		return true;

	a2 = 0;
	for (uint i = 0; i < a1.size(); i++)
	{
		DocumentCandidate & v2 = m_vDocCanList.at(a1[i]);
		if (v2.m_rProbAngle > 0.11)
		{
			if (v2.m_rDCField_4C < v1)
			{
				a2 = a1[i];
				v1 = v2.m_rDCField_4C;
			}
		}
	}

	return false;
}

void DocumentCandidateList::splitByViltual(vector<int>& a1, vector<int>& a2, vector<int>& a3)
{
	a2.clear();
	a2.reserve(m_vDocCanList.size());
	a3.clear();
	a3.reserve(m_vDocCanList.size());

	for (uint i = 0; i < a1.size(); i++)
	{
		if (m_vDocCanList[a1[i]].m_bViltual)
			a3.push_back(a1[i]);
		else
			a2.push_back(a1[i]);
	}
}




