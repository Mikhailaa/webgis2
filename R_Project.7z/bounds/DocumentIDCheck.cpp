#include "DocumentIDCheck.h"

namespace DocumentSize
{
	void TDocSize::setSize(float a1, float a2)
	{
		m_rTDocW = a1;
		m_rTDocH = a2;
		m_rTDocWH = a1 / a2;
		m_rTDocHW = a2 / a1;
	}

	DocumentIDCheck::DocumentIDCheck()
	{
		m_rMinSideLen = 10000.0;
	}

	DocumentIDCheck::~DocumentIDCheck()
	{

	}

	bool DocumentIDCheck::isIDByProportions(float a1, float a2, float & a3, int & a4, int * a5)
	{
		float v1, v2, v3, v4;
		bool v5 = false;
		a3 = 0.0;
		v1 = 0.0;
		v2 = a1 / a2;
		
		for (uint i = 0; i < m_vFilterGr.size(); i++)
		{
			v3 = fabsf(v2 - m_vFilterGr[i].second.m_rTDocWH) / m_vFilterGr[i].second.m_rTDocWH;
			if (v3 <= 0.35)
			{
				v4 = 1.0f - v3;
				if (v4 > v1)
				{
					a4 = m_vFilterGr[i].first;
					if (a5)
						*a5 = i;
					v1 = v4;
				}
			}
		}

		a3 = v1;
		if (v1 != 0.0)
			v5 = true;

		return v5;
	}

	bool DocumentIDCheck::isIDByProportionAndSize(float a1, float a2, float a3, float & a4, float & a5, int & a6)
	{
		float v1, v2, v3, v4, v5;
		bool v6 = false;
		a4 = 0.0;
		a5 = 0.0;
		v1 = a1 / a2;

		for (uint i = 0; i < m_vFilterGr.size(); i++)
		{
			v2 = 1.0f - fabsf(v1 - m_vFilterGr[i].second.m_rTDocWH) / m_vFilterGr[i].second.m_rTDocWH;
			if (v2 > a4)
			{
				v3 = fminf(fabsf(m_vFilterGr[i].second.m_rTDocW - a1) / m_vFilterGr[i].second.m_rTDocW, 1.0);
				v4 = fminf(fabsf(m_vFilterGr[i].second.m_rTDocH - a1) / m_vFilterGr[i].second.m_rTDocH, 1.0);
				v5 = (1.0f - v3) * (1.0f - v4);
				if (v5 > a3)
				{
					a4 = v2;
					a5 = v5;
					a6 = m_vFilterGr[i].first;
				}
			}
		}

		if (a5 != 0.0)
			v6 = true;
		return v6;
	}

	void DocumentIDCheck::isID(int a1, int a2, int a3, float & a4, int & a5)
	{
		isID(a1 * 1000.0f / a3, a2 * 1000.0f / a3, a4, a5, 0);
	}

	//width, height, area, type, index
	void DocumentIDCheck::isID(float a1, float a2, float & a3, int & a4, int * a5)
	{
		float v1, v2, v3, v4;
		a3 = 0.0;
		v4 = 0.0;
		for (uint i = 0; i < m_vFilterGr.size(); i++)
		{
			v1 = fminf(fabsf(m_vFilterGr[i].second.m_rTDocW - a1) / m_vFilterGr[i].second.m_rTDocW, 1.0);
			v2 = fminf(fabsf(m_vFilterGr[i].second.m_rTDocH - a2) / m_vFilterGr[i].second.m_rTDocH, 1.0);
			v3 = (1.0f - v1) * (1.0f - v2);
			if (v3 > v4)
			{
				v4 = v3;
				a3 = v3;
				a4 = m_vFilterGr[i].first;
				if (a5)
					*a5 = i;
			}
		}
	}

	void DocumentIDCheck::initGroups(map<string, vector<pair<int, TDocSize>>> & a1)
	{
		m_mDocFormatGr = a1;
		resetDocumentsFilter();
	}

	void DocumentIDCheck::resetDocumentsFilter()
	{
		vector<int> v1;
		setDocumentsFilter(v1);
	}

	void DocumentIDCheck::setActiveGroups(string & a1)
	{
		vector<string> v1;
		v1.push_back(a1);
		setActiveGroups(v1);
	}

	void DocumentIDCheck::setActiveGroups(vector<string> & a1)
	{
		vector<pair<int, DocumentSize::TDocSize>> v1;

		m_vActiveGr.clear();
		for (uint i = 0; i < a1.size(); i++)
		{
			v1 = m_mDocFormatGr[a1[i]];
			for (uint j = 0; j < v1.size(); j++)
				m_vActiveGr.push_back(v1[j]);
		}
	}

	float sub_440478(vector<pair<int, DocumentSize::TDocSize>> & a1)
	{
		float v1, v2, v3;
		if (a1.size())
			v1 = a1[0].second.m_rTDocW;
		else
			v1 = 0.0;
		for (uint i = 0; i < a1.size(); i++) 
		{
			v2 = a1[i].second.m_rTDocW;
			v3 = a1[i].second.m_rTDocH;
			if (v2 < v1)
				v1 = v2;
			if (v3 < v1)
				v1 = v3;
		}
		return v1;
	}

	void DocumentIDCheck::setDocumentsFilter(vector<int> & a1)
	{
		if (a1.empty())
		{
			m_vFilterGr.assign(m_vActiveGr.begin(), m_vActiveGr.end());
			m_rMinSideLen = sub_440478(m_vFilterGr);
		}
		else
		{
			for (uint i = 0; i < m_vActiveGr.size(); i++)
			{
				for (uint j = 0; j < a1.size(); j++)
				{
					if (m_vActiveGr[i].first == a1[j])
					{
						m_vFilterGr.push_back(m_vActiveGr[i]);
						break;
					}
				}
			}

			m_rMinSideLen = sub_440478(m_vFilterGr);
		}
	}

	int DocumentIDCheck::minSideLenght(int a1, int a2)
	{
		if (a1)
			a2 = (int)((m_rMinSideLen * a1) / 1000.0f);
		return a2;
	}

	int DocumentIDCheck::docResolution(int a1, int a2, int a3)
	{
		for (uint i = 0; i < m_vFilterGr.size(); i++)
		{
			if (a1 == m_vFilterGr[i].first)
				return (int)(a2 * 1000.0f / m_vFilterGr[i].second.m_rTDocW);
		}

		return a3;
	}

	vector<int> docFilter123x2()
	{
		vector<int> v1;
		//v1.resize(4);
		v1.push_back(0);
		v1.push_back(1);
		v1.push_back(2);
		v1.push_back(5);
		return v1;
	}

	vector<int> docFilter13()
	{
		vector<int> v1;
		//v1.resize(2);
		v1.push_back(0);
		v1.push_back(2);
		return v1;
	}

	bool isA4Size(tagSIZE a1, int a2, float a3)
	{
		float v1, v2;

		if (!a2)
			return false;

		v1 = (a1.cx * 1000.0f) / a2;
		v2 = (a1.cy * 1000.0f) / a2;

		if (fabsf(210.0f - v1) < a3 * 210.0f && fabsf(297.0f - v2) < a3 * 297.0f)
			return true;

		if (fabsf(210.0f - v2) < a3 * 210.0f && fabsf(297.0f - v1) < a3 * 297.0f)
			return true;

		return false;
	}

	void initByDefault(DocumentIDCheck & a1)
	{
		vector<pair<int, DocumentSize::TDocSize>> v1;
		string v2("fromHeader");
		map<string, vector<pair<int, DocumentSize::TDocSize>>> v3;

		readDocumentFormatFromHeader(v1);
		v3[v2] = v1;

		a1.initGroups(v3);
		a1.setActiveGroups(v2);
	}

	void readDocumentFormatFromHeader(vector<pair<int, DocumentSize::TDocSize>>& a1)
	{
		pair<int, DocumentSize::TDocSize> v1;

		v1.first = 0;
		v1.second.m_rTDocW = 85.6f;
		v1.second.m_rTDocH = 54.0f;
		v1.second.m_rTDocWH = 1.5852f;
		v1.second.m_rTDocHW = 0.63084f;
		a1.push_back(v1);

		v1.first = 1;
		v1.second.m_rTDocW = 105.0f;
		v1.second.m_rTDocH = 74.0f;
		v1.second.m_rTDocWH = 1.4189f;
		v1.second.m_rTDocHW = 0.70476f;
		a1.push_back(v1);

		v1.first = 2;
		v1.second.m_rTDocW = 125.0f;
		v1.second.m_rTDocH = 88.0f;
		v1.second.m_rTDocWH = 1.4205f;
		v1.second.m_rTDocHW = 0.704f;
		a1.push_back(v1);

		v1.first = 2;
		v1.second.m_rTDocW = 92.5f;
		v1.second.m_rTDocH = 65.5f;
		v1.second.m_rTDocWH = 1.4122f;
		v1.second.m_rTDocHW = 0.70811f;
		a1.push_back(v1);

		v1.first = 5;
		v1.second.m_rTDocW = 176.0f;
		v1.second.m_rTDocH = 125.0f;
		v1.second.m_rTDocWH = 1.408f;
		v1.second.m_rTDocHW = 0.71023f;
		a1.push_back(v1);

		v1.first = 0;
		v1.second.m_rTDocW = 81.6f;
		v1.second.m_rTDocH = 50.0f;
		v1.second.m_rTDocWH = 1.632f;
		v1.second.m_rTDocHW = 0.61275f;
		a1.push_back(v1);

		v1.first = 1;
		v1.second.m_rTDocW = 100.0f;
		v1.second.m_rTDocH = 68.0f;
		v1.second.m_rTDocWH = 1.4706f;
		v1.second.m_rTDocHW = 0.68f;
		a1.push_back(v1);

		v1.first = 6;
		v1.second.m_rTDocW = 210.0f;
		v1.second.m_rTDocH = 113.0f;
		v1.second.m_rTDocWH = 1.8584f;
		v1.second.m_rTDocHW = 0.5381f;
		a1.push_back(v1);
	}
}

namespace Json
{
	void convert(Json::Value & a1, map<string, vector<pair<int, DocumentSize::TDocSize>>>& a2)
	{
		Json::ValueIteratorBase begin, end;
		string v2;

		begin = a1.begin();
		end = a1.end();

		while (begin != end)
		{
			Json::Value v1 = begin.deref();
			v2 = v1["name"].asString();

			convert(v1, a2[v2]);

			begin.increment();
		}
	}

	void convert(Json::Value & a1, vector<pair<int, DocumentSize::TDocSize>> & a2)
	{
		Json::Value jv(a1["types"]);
		uint v1 = jv.size();
		a2.resize(v1);
		float w, h;

		for (uint i = 0; i < v1; i++)
		{
			Json::Value v2 = jv[i];
			a2[i].first = v2["type"].asInt();
			w = v2["W"].asFloat();
			h = v2["H"].asFloat();
			a2[i].second.setSize(w, h);
		}
	}
}