#pragma once

#include "../pch.h"
#include "LineGroup.h"
#include "DocumentIDCheck.h"

bool IsPointInside(vector<Point2f>& a1, Point2f & a2);
bool intersectLines(Point2f & a1, Point2f & a2, Point2f & a3, Point2f & a4);
bool intersectLines(vector<Point2f> & a1, vector<Point2f> & a2);

class DocumentCandidate
{
public:
	DocumentCandidate();
	DocumentCandidate(DocumentCandidate const & a1);
	DocumentCandidate(DocumentCandidate && a1);

	float calcAngleByHSides();
	float minKLen();
	int checkLinesContours();
	bool cornersDocument(vector<Point2f> & a1);
	void checkInternalAngle(float & a1, float & a2);
	void clear();
	void cornersDocumentInvHW();
	void cornersDocumentUpdHV(bool a1, bool a2);
	void kLenSides(vector<float> & a1);
	void setSides(vector<LineGroup *> & a1);
	
	static float calcAngleBySides(vector<float> & a1);
	static void checkInternalAngle(vector<float> & a1, float & a2, float & a3);
	static void documentSize(vector<Point2f> & a1, float & a2, float & a3, Point2f & a4, bool & a5, bool & a6);

	DocumentCandidate & operator=(DocumentCandidate && a1);
	DocumentCandidate & operator=(DocumentCandidate const & a1);

public:
	Size2f m_xDocSize;
	bool m_bDCField_8;
	float m_rProbAngle;
	float m_rMainProb;   //10
	float m_rDCField_14;
	float m_rProportionDC;
	float m_rAuxProb;
	int m_nDocType;   //20
	float m_rIntAngle;
	float m_rSumIntAngle;
	bool m_bMrzContain;
	float m_rMrzParam4;  //30
	float m_rMrzParam2;
	float m_rDCField_38;
	float m_rDCField_3C;
	float m_rDCField_40;  //40
	float m_rDCField_44;
	float m_rDCField_48;
	float m_rDCField_4C;
	float m_rDCField_50;   //50
	float m_rAngleDC; 
	char m_bCheckLineContour;
	char m_bViltual;
	int m_rBottomSegLen;  
	float m_rBottomSegkLen;   //60
	int m_rBottomSegLenOut;
	float m_rBottomSegkLenOut;
	LineGroup * m_pBottomLGr;  
	int m_rTopSegLen;    //70
	float m_rTopSegkLen;
	int m_rTopSegLenOut;
	float m_rTopSegkLenOut;
	LineGroup * m_pTopLGr;   //80
	int m_rLeftSegLen;
	float m_rLeftSegkLen;
	int m_rLeftSegLenOut;
	float m_rLeftSegkLenOut;  //90
	LineGroup * m_pLeftLGr;   
	int m_rRightSegLen;
	float m_rRightSegkLen;
	int m_rRightSegLenOut;  //A0
	float m_rRightSegkLenOut;
	LineGroup * m_pRightLGr;  
	vector<Point2f> m_vCornerDC;  //AC
	Point2f m_xCenterDC;  //B8
};


class DocumentCandidateList
{
public:
	void calculateProbAngle(vector<int> & a1);
	void calculateProbForDPI(DocumentSize::DocumentIDCheck & a1, vector<int> & a2, int a3);
	void calculateProbForFreeDoc(vector<int> & a1, float a2);
	void calculateProbForWrongDPI(float a1);
	void calculateProbUpd(vector<int> & a1, int a2);
	void filterByCalcReady(vector<int> & a1, vector<int> & a2);
	void filterByDocType(int a1, vector<int> & a2, vector<int> & a3);
	void filterByIntAngle(float a1, vector<int> & a2, vector<int> & a3);
	void filterByIntersect(DocumentCandidate & a1, vector<int> & a2, vector<int> & a3);
	void filterByKLen(float a1, float a2, vector<int> & a3, vector<int> & a4);
	void filterByKLen_3_1(float a1, float a2, vector<int> & a3, vector<int> & a4);
	void filterByMainProb(float a1, vector<int> & a2, vector<int> & a3);
	void filterByMrzParam(float a1, vector<int> & a2, vector<int> & a3);
	void filterByViltual(bool a1, vector<int> & a2, vector<int> & a3);
	void filterViltualByAngle(float a1, vector<int> & a2, vector<int> & a3);
	void findBest(int a1, vector<int> & a2, vector<int> & a3);
	int findBest(vector<int>& a1);
	bool findBestByLines(vector<int> & a1, int & a2);
	void splitByViltual(vector<int> & a1, vector<int> & a2, vector<int>& a3);
	
public:
	vector<DocumentCandidate> m_vDocCanList;
};