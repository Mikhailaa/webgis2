#pragma once

#include "../common/container/rclholder.h"
#include "DocumentCandidate.h"
#include "LineGroup.h"
#include "LineEx.h"
#include "../pch.h"

class DocumentDetectDebugInfo
{
public:
	DocumentDetectDebugInfo(void);
	~DocumentDetectDebugInfo(void);

	void init(common::container::RclHolder &a2, float a3);
	void setImgFone(cv::Mat &a2);
	cv::Mat linesSave(DocumentCandidate& a2, const char *a3);
	cv::Mat linesSave(DocumentCandidateList& a2, bool a3, const char *a4);
	cv::Mat linesSave(vector<LineEx>& a3, const char *a4);
	cv::Mat linesSave(DocumentCandidateList& a2, vector<int>& a3, bool a4, const char *a5);
	cv::Mat linesSave(DocumentCandidateList& a3, vector<pair<int,int>>& a4, bool a5, const char *a6);
	cv::Mat linesSave(vector<LineGroup>& a3);
	cv::Mat linesSave(vector<Point2f>& a3, const char *a4);
	void printCandidateInfo(DocumentCandidateList& a2, vector<int>& a3);

public:
	bool field_0;
	bool field_1;
	cv::Mat field_4;
};

