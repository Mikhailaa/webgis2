#pragma once
#include "../commonStruct.h"

class ProcessVariant
{
public:
	ProcessVariant(ProcessVariant const & a1);
	ProcessVariant(ProcessVariant && a1);
	ProcessVariant();
	~ProcessVariant();

	ProcessVariant & operator=(ProcessVariant const & a1);

public:
	vector<eBinProcessImg> m_veBPI; 
	vector<eBinProcess> m_veBP;
	float m_rKLineLenFilter;  //18
	int m_nProcessType;  //1C
};

class ProcessVariantsStore 
{
public:
	map<wstring, ProcessVariant> m_mapPV;
	void filter(vector<wstring> & a2, vector<ProcessVariant> & a3);
};