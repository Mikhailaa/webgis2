﻿#include "DocumentDetectionParameter.h"

/*-----------------------------------DocumentDetectionParameter----------------------------------------*/

DocumentDetectionParameter::DocumentDetectionParameter()
{
	m_rMinLengthLineForDetect = 0.0;
	m_rMinLengthLineForDetectResolution = 0.0;
	m_rMinLinesLengthForContour = 0.0;
	m_rMinLinesLengthForContourResolution = 0.0;
	m_rLineDistForUnion = 0.0;
	m_rLineDistForUnionResolution = 0.0;
	m_rAngleRange = 0.0;
	m_rAverContour = 0.0;
	m_rAverContourResolution = 0.0;
	m_rDocDeviation = 0.0;
	m_rDocDeviationLast = 0.0;
	m_bOnlyDocFromIni = false;
	m_nRemoveBorderLine = 0;
	m_nThresholdBin = 0;
	m_nWorkW = 0;
	m_nWorkDPI = 0;
	m_rFullDocDiff = 0.0;
	m_bPerspectiveTr = false;
	m_bFullImgAnalOff = false;
	m_rMinProbByProportion = 0.0;
	m_rMinProbBySize = 0.0;
	m_rMinProbBySizeCalcProb = 0.0;
	m_bFullDocumentDetectOnly = false;
	m_rFullDocumentDetectDevMax = 0.0;
	m_rkMinDocSizebyWHImg = 0.0;
	m_nROIFlag = 0;
	m_nROIX1 = 0;
	m_nROIY1 = 0;
	m_nROIX2 = 0;
	m_nROIY2 = 0;
	m_nMultiPages = 0;
	m_nCheckWithBorder = 0;
	m_nUseVDAsMainResult = 0;
	m_nUseMRZForFilterCandidate = 0;
	m_nUseMRZForFilterCandidate2 = 0;
	m_bUseMRZForCrop = false;
	m_nUseFreeIntAngle = 0;
	m_nMaxDevIntAngleForRectObj = 0;
	m_rkMinSideSize = 0.0;
	m_rLineHelpStop = 0.0;
	m_rLineHelpStart = 0.0;
	m_rDDPField_A4 = 0.0;
	m_rDDPField_A8 = 0.0;
	m_rCalcProb_LINE_INSIDE = 0.0;
	m_rCalcProb_MRD_DIST_2 = 0.0;
	m_rCalcProb_MRD_DIST_4 = 0.0;
	m_rCalcProb_LINE_CONTOUR = 0.0;
	m_rDDPField_BC = 0.0;
	m_rDDPField_C0 = 0.0;
	m_fCalcProb_changingDPI = 0;
	m_rCalcProb_changingDPI_MinProbBySize = 0.0;
	m_rDDPField_CC = 0.0;

	m_vActiveGroups.clear();
	m_vProcess.clear();

	initByDef();
}

DocumentDetectionParameter::~DocumentDetectionParameter()
{

}

DocumentDetectionParameter::DocumentDetectionParameter(DocumentDetectionParameter const & a1)
{
	memcpy(this, &a1, 0xD0);
	m_vActiveGroups = a1.m_vActiveGroups;
	m_vProcess = a1.m_vProcess;
}

DocumentDetectionParameter::DocumentDetectionParameter(DocumentDetectionParameter && a1)
{
	memcpy(this, &a1, 0xD0);

	m_vActiveGroups = move(a1.m_vActiveGroups);
	m_vProcess = move(a1.m_vProcess);
}

void DocumentDetectionParameter::initByDef()
{
	m_rMinLengthLineForDetect = 5.0f;
	m_rMinLinesLengthForContour = 80.0f;
	m_rLineDistForUnion = 1.0f;
	m_rAngleRange = 3.0f;
	m_rAverContour = 1.0f;
	m_nContourType = 2;
	m_rDocDeviation = 0.05f;
	m_bOnlyDocFromIni = false;
	m_nThresholdBin = 50;
	m_nRemoveBorderLine = 1;
	m_nWorkW = 512;
	m_nWorkDPI = 3000;
	m_rFullDocDiff = 0.02f;
	m_bPerspectiveTr = false;
	m_rMinProbByProportion = 0.9f;
	m_rMinProbBySize = 0.9f;
	m_rMinProbBySizeCalcProb = 0.85f;
	m_rkMinDocSizebyWHImg = 0.3f;
	m_nMultiPages = 0;
	m_nUseVDAsMainResult = 0;
	m_nROIFlag = 0;
	m_nROIX1 = 0;
	m_nROIX2 = 0;
	m_nROIY1 = 0;
	m_nROIY2 = 0;
	m_rkMinSideSize = 0.9f;
	m_rLineHelpStop = 0.95f;
	m_rLineHelpStart = 0.85f;
	m_rDDPField_A4 = 3.0f;
	m_rDDPField_A8 = 3.0f;
	m_rCalcProb_LINE_INSIDE = 7.0f;
	m_rCalcProb_MRD_DIST_2 = 10.0f;
	m_rCalcProb_MRD_DIST_4 = 2.0f;
	m_rCalcProb_LINE_CONTOUR = 3.0f;
	m_rDDPField_BC = 0.1f;
	m_rDDPField_C0 = 0.2f;
	m_fCalcProb_changingDPI = 0;
	m_rDDPField_CC = 1.0f;
}

void DocumentDetectionParameter::initParameter(DocumentDetectionParameter & a1)
{
	*this = a1;
}

void DocumentDetectionParameter::setResolution(int a1)
{
	float v1, v2, v3, v4;

	v1 = m_rMinLengthLineForDetect * a1 / 1000.0f;
	v2 = m_rMinLinesLengthForContour * a1 / 1000.0f;
	v3 = m_rAverContour * a1 / 1000.0f;
	v4 = m_rLineDistForUnion * a1 / 1000.0f;

	m_rMinLengthLineForDetectResolution = v1;
	m_rMinLinesLengthForContourResolution = v2;
	m_rAverContourResolution = v3;
	m_rLineDistForUnionResolution = v4;

}

DocumentDetectionParameter & DocumentDetectionParameter::operator=(DocumentDetectionParameter & a1)
{
	memcpy(this, &a1, 0xD0);

	if (&a1 != this)
	{
		m_vActiveGroups.assign(a1.m_vActiveGroups.begin(), a1.m_vActiveGroups.end());
		m_vProcess.assign(a1.m_vProcess.begin(), a1.m_vProcess.end());
	}
	
	return *this;
}

/*-----------------------------------DocumentDetectionParameters----------------------------------------*/

DocumentDetectionParameters::DocumentDetectionParameters()
{
	m_mDeviceIdWM.clear();
	m_vWorkModeName.clear();
	m_vWorkModeParam.clear();
}

DocumentDetectionParameters::~DocumentDetectionParameters()
{

}

void DocumentDetectionParameters::add(string & a1, DocumentDetectionParameter & a2)
{
	if (!m_xDefModeParam.m_nWorkW)
		m_xDefModeParam = a2;

	m_vWorkModeName.push_back(a1);
	m_vWorkModeParam.push_back(a2);
}

bool DocumentDetectionParameters::contain(string & a1)
{
	if (find(m_vWorkModeName.begin(), m_vWorkModeName.end(), a1) == m_vWorkModeName.end())
		return false;
	
	return true;
}

void DocumentDetectionParameters::sefDefParam(DocumentDetectionParameter & a1)
{
	m_xDefModeParam = a1;
}

DocumentDetectionParameter & DocumentDetectionParameters::param(string & a1)
{
	uint i;

	for (i = 0; i < m_vWorkModeName.size(); i++)
	{
		if (m_vWorkModeName[i] == a1)
			return m_vWorkModeParam[i];
	}

	return m_xDefModeParam;
}

