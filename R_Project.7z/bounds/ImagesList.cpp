#include "ImagesList.h"

ImageExMat * ImagesListMat::create(eBinProcessImg a1, eBinProcess a2)
{
	ImageExMat *v1;
	v1 = image(a1, a2);

	if (!v1)
	{
		v1 = new ImageExMat;
		v1->m_neBPI = a1;
		v1->m_neBP = a2;
		m_vImagesMat.push_back(v1);
		return v1;
	}

	return v1;
}

ImageExMat * ImagesListMat::image(eBinProcessImg a1, eBinProcess a2)
{
	for (uint i = 0; i < m_vImagesMat.size(); i++)
	{
		if (m_vImagesMat[i]->m_neBPI == a1 && m_vImagesMat[i]->m_neBP == a2)
			return m_vImagesMat[i];
	}

	return 0;
}

void ImagesListProcess::generateImage(ImagesListMat & a1, eBinProcessImg a2)
{
	ImageExMat * v1, *v2, *v3, *v4;
	vector<cv::Mat> v5(3);

	if (!a1.image(a2, eBP_OFF))
	{
		switch (a2)
		{
		case eBPI_WHITE_Gray:
			v1 = a1.image(eBPI_WHITE, eBP_OFF);
			if (v1)
			{
				v2 = a1.create(eBPI_WHITE_Gray, eBP_OFF);
				if (v1->m_xImageExMat.flags & CV_MAT_CN_MASK)
					cv::cvtColor(v1->m_xImageExMat, v2->m_xImageExMat, COLOR_BGR2GRAY);
				else 
					v1->m_xImageExMat.copyTo(v2->m_xImageExMat);
			}
			break;

		case eBPI_WHITE_GrayTr:
			v1 = a1.image(eBPI_WHITE_TR, eBP_OFF);
			if (v1)
			{
				v2 = a1.create(eBPI_WHITE_GrayTr, eBP_OFF);
				if (v1->m_xImageExMat.flags & CV_MAT_CN_MASK)
					cv::cvtColor(v1->m_xImageExMat, v2->m_xImageExMat, COLOR_BGR2GRAY);
				else
					v1->m_xImageExMat.copyTo(v2->m_xImageExMat);
			}
			break;

		case eBPI_WHITE_R:
		case eBPI_WHITE_G:
		case eBPI_WHITE_B:
			v1 = a1.image(eBPI_WHITE, eBP_OFF);
			if (v1)
			{
				v2 = a1.create(eBPI_WHITE_R, eBP_OFF);
				v3 = a1.create(eBPI_WHITE_G, eBP_OFF);
				v4 = a1.create(eBPI_WHITE_B, eBP_OFF);
				if (v1->m_xImageExMat.flags & CV_MAT_CN_MASK)
				{
					cv::split(v1->m_xImageExMat, v5);
					v5[0].copyTo(v4->m_xImageExMat);
					v5[1].copyTo(v3->m_xImageExMat);
					v5[2].copyTo(v2->m_xImageExMat);
				}
			}
			break;

		case eBPI_UV_R:
		case eBPI_UV_G:
		case eBPI_UV_B:
			v1 = a1.image(eBPI_UV, eBP_OFF);
			if (v1)
			{
				v2 = a1.create(eBPI_UV_R, eBP_OFF);
				v3 = a1.create(eBPI_UV_G, eBP_OFF);
				v4 = a1.create(eBPI_UV_B, eBP_OFF);
				if (v1->m_xImageExMat.flags & CV_MAT_CN_MASK)
				{
					cv::split(v1->m_xImageExMat, v5);
					v5[0].copyTo(v4->m_xImageExMat);
					v5[1].copyTo(v3->m_xImageExMat);
					v5[2].copyTo(v2->m_xImageExMat);
				}
			}
			break;

		default:
			break;
		}
	}
}