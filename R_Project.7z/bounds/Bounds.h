﻿#pragma once

#include "../moduleprocessgl.h"
#include "../Json/Value.h"
#include "DocumentDetectionParameter.h"
#include "DocumentCandidate.h"
#include "DocumentDetect.h"
#include "DocumentIDCheck.h"
#include "DocumentDetectDebugInfo.h"
#include "LineEx.h"
#include "LineGroup.h"
#include "../common/container/RclHolder.h"
#include "../common/resources.h"
#include "../pch.h"
#include "../ImageControl.h"
#include "Analyse.h"
#include "ImagesList.h"
#include "ProcessVariant.h"
#include "../sdk/ResultContainerList.h"

namespace BoundsNS {
	namespace Error {
		int checkCodeError(int nResult);
	}
}

namespace bounds {
	/*---------------Start FaceInfo---------------*/
	class FaceInfo
	{
	public:
		FaceInfo();

		void clear();
		void setK(float k);
		void setRect(tagRECT rect);

	public:
		tagRECT m_xFIRect;
		Point2f m_xFICenter;
		tagRECT m_xFIkRect;
		Point2f m_xFIkCenter;
		bool m_bFIClear;
	};

	float maxDistanceMrz2(vector<Point2f> & a1, vector<Point2f> & a2);

	namespace maskprocess {
		bool updateRect(vector<Point2f> & a1, float a2, vector<Point2f> & a3);
	}

	namespace detectX2 {
		void filterCandidatesByPPM(DocumentCandidateList & a1, vector<int> & a2, vector<int> & a3, CDocFormat a4, int a5);
		bool sub_427138(vector<Point2f> & a1, vector<Point2f> & a2);
		void find2CandidateNonIntersect(DocumentCandidateList & a1, vector<int> & a2, vector<pair<int, int>> & a3);
		void findCandidatesWithCommonSide(DocumentCandidateList & a1, vector<int> & a2, vector<pair<int, int>> & a3);
	}

	namespace byrecognize {
		namespace series {
			class BoundsState
			{
			public:
				BoundsState();
				~BoundsState();

				void resetCurrentFrame();
				void reset();

			public:
				int m_nBoundsState_field_0;
				vector<TBoundsResult> m_vBoundsState_field_4;
				common::container::RclHolder m_xBoundsState_field_10;
				int m_nBoundsState_field_24;
				bool m_nBoundsState_field_28;
				bool m_nBoundsState_field_29;
			};
		}

		enum eBoundsByRecognizeMode
		{
			eBBRM_None,
			eBBRM_Full,
			eBBRM_FullSplit2,
			eBBRM_BasicOne,
			eBBRM_BasicOneBig,
			eBBRM_Id3x2,
			eBBRM_Id3x2Series,
			eBBRM_Id1x2,
			eBBRM_Id3x2One,
			eBBRM_Id3x2Split2Series,
			eBBRM_Id3x2Split2,
			eBBRM_Basic,
			eBBRM_Mrz
		};

		void detectByRecognize(common::container::RclHolder & a1, DocumentCandidateList & a2, vector<int> & a3, common::container::RclHolder & a4, DocumentDetect & a5, vector<TBoundsResult> & a6, vector<TBoundsResult> & a7, vector<Point2f> & a8, int a9, bounds::byrecognize::series::BoundsState & a10, vector<eBoundsByRecognizeMode> & a11, tagSIZE & a12, tagRECT & a13, float a14);
		int checkPagePair(DocumentCandidateList & a1, TResultContainerList & a2, vector<pair<int, int>> & a3, vector<TBoundsResult> & a4, float a5, int a6, CDocFormat a7, vector<int> & a8, common::container::RclHolder & a9, vector<int> & a10);
		void checkId3x2Split2(DocumentCandidateList & a1, TResultContainerList & a2, vector<int> & a3, float a4, vector<Point2f> & a5, vector<int> & a6, common::container::RclHolder & a7);
		void checkCandidateByMRZ(TBoundsResult & a1, TResultContainerList & a2, common::container::RclHolder & a3);
		int checkCandidateByRecognize(common::container::RclHolder & a1, common::container::RclHolder & a2);
		int checkCandidate(DocumentCandidateList & a1, TResultContainerList & a2, vector<int> & a3, vector<TBoundsResult> & a4, float a5, vector<int> & a6, common::container::RclHolder & a7);
		eBoundsByRecognizeMode convert(string & a1);
	}

	namespace testmodesupport {
		extern TDeviceType g_DeviceType;
		void addDeviceType(common::container::RclHolder & rclHolder, int nDeviceType);
		int updateSaveImageStatus(string &, int);
	}

	namespace docteachersupport {
		void addDeviceTypeFromSamplePath(common::container::RclHolder & rclHolder);
		void saveSampleAsImages(common::container::RclHolder & rclHoder, string const & str);
	}

	namespace debug {
		DocumentDetectDebugInfo * dddiFull();
		DocumentDetectDebugInfo * dddi();
	}

	namespace face {
		bool convertFaceDetectResultFromiOS(Json::Value & a1, Json::Value & a2, Size & a3);
		bool checkByFaceArea(vector<Point2f> & a1, tagRECT & a2, float a3);
	}

	namespace visa {
		void updateVisaID2Result(TResultContainerList & a1, TBoundsResult & a2, vector<float> & a3);
	}

	namespace test {
		void createTestSample(common::container::RclHolder & a1, string & a2, string & a3);
	}

	namespace boundsresult {
		vector<Point> getCorners(TBoundsResult & boundsResult);
		vector<Point> getCorners180(TBoundsResult & boundsResult);
		vector<Point2f> getCorners2f(TBoundsResult & boundsResult);
		void convert(DocumentCandidate & a1, TBoundsResult & a2);
		void convertInv(DocumentCandidate & a1, TBoundsResult & a2);
		double calculateMaxCornerDist(TBoundsResult & a1, TBoundsResult & a2);
		bool checkBoundsResults(TBoundsResult & a1, TBoundsResult & a2, float a3);
		void scale(TBoundsResult & a1, float a2, float a3);
		void scale(TBoundsResult & a1, TBoundsResult & a2, float a3, float a4);
		void scale(vector<Point2f> & a1, vector<Point2f> & a2, float a3);
	}

	namespace result {
		Point2f centerDocByCorners(TBoundsResult const& a2);
		bool isAllPointsInside(vector<Point2f> & a1, vector<Point2f> & a2);
		void updateSizeOutByDocFormat(TBoundsResult & a1);
	}

	namespace lines {
		class GrLines
		{
		public:
			GrLines(GrLines && a1);
			GrLines();

			LineGroupList m_xGL_field_0;
			LineGroupList m_xGL_field_C;
			vector<int> m_xGL_field_18;
			vector<int> m_xGL_field_24;
			LineGroupList m_xGL_field_30;
			LineGroupList m_xGL_field_3C;
		};

		class ProcessStore
		{
		public:
			DocumentCandidateList m_xPS_field_0;
			vector<int> m_xPS_field_C;
			vector<int> m_xPS_field_18;
			vector<DocAngleParam> m_xPS_field_24;
			vector<LineEx> m_xPS_field_30;
			vector<GrLines> m_xPS_field_3C;
		};

		float calcAngleWLines(vector<LineEx> & vLine);
		void getLines(vector<cv::Mat> & a1, DocumentDetectionParameter & a2, double a3, vector<LineEx> & a4);
		int getImages(ImagesListMat & a1, ProcessVariant & a2, cv::Mat & a3, DocumentDetectionParameter & a4, vector<cv::Mat> & a5);
		void getLines(vector<ProcessVariant> & a1, uint a2, vector<bounds::lines::ProcessStore> & a3, ImagesListMat & a4, cv::Mat & a5, DocumentDetectionParameter & a6, uint & a7);
	}

	typedef struct _tagCheckDocumentParam
	{
		int nCDPField_0;
		bool fCDPField_4;
		float rCDPField_8;
		bool fCDPchangingDPI;
		tagSIZE xCDPSize; //10
		vector<TBoundsResult> *vBoundsResult1; //18 
		vector<TBoundsResult> *vBoundsResult2; //1c
		vector<Point2f> * vCDPPoint;  //20
		bounds::FaceInfo * xCDPFaceInfo;  //24
		DocumentDetect * xCDPDocDetect; //28
		float fCDPField_2C;  //2c
		float fCDPField_30;
	}CheckDocumentParam;

	namespace candidates {
		void makeDocument(vector<LineGroup *> & a1, vector<LineGroup *> & a2, DocumentSize::DocumentIDCheck & a3, CheckDocumentParam & a4, int a5, vector<DocumentCandidate> & a6, int a7);
		void makeDocument(vector<LineGroup> & a1, vector<int> & a2, vector<LineGroup> & a3, vector<int> & a4, vector<LineGroup> & a5, vector<LineGroup> & a6, DocumentSize::DocumentIDCheck & a7, CheckDocumentParam & a8, int a9, vector<DocumentCandidate> & a10, int a11);
		void checkDocument(DocumentSize::DocumentIDCheck & a1, CheckDocumentParam & a2, DocumentCandidate & a3, vector<DocumentCandidate> & a4);
	}
}

namespace BoundsResult {
	bool checkResult(common::container::RclHolder & a1, common::container::RclHolder & a2, float a3);
	vector<LineEx> getLines(vector<Point2f> & vPoint);
	void initCorners(TBoundsResult & result, vector<Point2f> & vPoint);
	void initResult(tagSIZE & xSize, int nDocFormat, DocumentCandidate & docCan);
	void initResult90(tagSIZE & xSize, int nDocFormat, DocumentCandidate & docCan);
	void initResultAutoWH(tagSIZE & xSize, int nDocFormat, DocumentCandidate & docCan);
	void updateSizeOutByDocFormat(int nDocFormat, float & width, float & height);
	void updateSizeOutByDocFormat(DocumentCandidate & docCan);
	int splitID3x2(DocumentCandidate & docCan, TBoundsResult & xResult1, TBoundsResult & xResult2);
}

//이령역의 함수들은 bounds.ini화일에서 설정정보들을 읽어 저장한다.
namespace boundsini {
	void loadFromJson(Json::Value & a1, DocumentDetectionParameter & a2);
	void loadFromJson(Json::Value & a1, DocumentDetectionParameters & a2);
	void loadFromJson(Json::Value & a1, ProcessVariant & a2);
	void loadFromJson(Json::Value & a1, ProcessVariantsStore & a2);
}

/*----------------------Start BoundsInternal----------------------*/
class BoundsInternal
{
public:
	BoundsInternal();
	~BoundsInternal();

	void resetHelpInfo();
	void initDocumentFilter(TBoundsResult & a1);
	void initHelpInfo(TResultContainerList & a1);
	int setAdditionalDocGroups(string & a1);
	int detectDoc(TResultContainerList & a1, Json::Value & a2);

	static void createResultList(TBoundsResult & a1, vector<TBoundsResult> & a2, bool a3);
	static void createResultList(vector<DocumentCandidate> & a1, TBoundsResult * a2, float a3, bool a4, vector<TBoundsResult> & a5, int a6);
	static void checkFullImageDoc(TBoundsResult & a1, tagSIZE & a2, float & a3);
	static void generateMask(Size & a1, MatImage & a2, vector<Point2f> & a3, vector<Point2f> & a4);
	static int getImages(TResultContainerList & a1, ImagesListMat & a2, int & a3, tagSIZE & a4);
	static void filterByExtParameters(Json::Value & a1,vector<DocumentCandidate> & a2, float a3);
	static void initFullVideoSensorInfo(POSITIONDOCUMENT & a1, tagSIZE & a2, TBoundsResult & a3);
	static void convert(DocumentCandidate & a1, TBoundsResult * a2, float a3, bool a4, vector<TBoundsResult> & a5, int a6);
	static int updateFullVideoSensorInfo(TBoundsResult & a1, vector<TBoundsResult> & a2);
	static void updateResultsParam(vector<TBoundsResult> & a1, tagSIZE & a2);

public:
	int m_nmaxWorkTimeMs;  //0
	string m_strWorkMode;
	string m_strDefWorkMode;
	DocumentCandidate m_xBIDocCan;
	DocumentDetect m_xBIDocDetect;
	string m_strBoundsInternal_field_1F0;
	common::container::RclHolder m_xBoundsInternal_field_1FC;
	vector<TBoundsResult> m_vBITBoundsResult_210;
	vector<string> m_vBIAddtionalDocGr;
	ProcessVariantsStore  m_mBIProcVariant;
	DocumentDetectionParameters m_xBIDocDetectParams;
	vector<Point2f> m_vBIPoint_340;
	vector<Point2f> m_vBIPoint_34C;
	vector<Point2f> m_vBIPoint_358;
	vector<Point2f> m_vBIPoint_364;
	int m_nSaveImage;   //370
	vector<TBoundsResult> m_vBITBoundsResult_374;
	vector<TBoundsResult> m_vBITBoundsResult_380;
	vector<Point2f> m_vBIPoint_38C;
	vector<Point2f> m_vBIPoint_398;
	int m_nBIField_3A4;
	bool m_fBIField_3A8;
	TBoundsResult m_xBITBoundsResult_3AC;
	float m_rBIk;
	Size m_xBIImgSize;
	bounds::FaceInfo m_xBIFaceInfo;
	Json::Value m_xBIBoundsParam;
	Json::Value m_xuseDpiFromImage;
	Json::Value m_xModuleParam;
	int m_nBIDeviceType;   //480
	int m_ndeviceIDDebug;
	bool m_bGenerateTestSample;
	bool m_bisNeedUpdateDPI;
	int m_nmaxImageSizeInPix;
	common::container::RclHolder m_xBIHolder_490;
	bounds::byrecognize::series::BoundsState m_xBIBoundsState;
	vector<int> m_vBIDocFilter;
};

/*----------------------Start Bounds---------------------*/


class Bounds : public moduleprocessgl::IProcessFunction
{
public:
	Bounds();
	~Bounds();

	vector<int> getCommands();
	int process(int a1, void * a2, const char * a3, void ** a4, char** a5);
	int processSeries(void * a1, Json::Value & a2, void ** a3, char ** a4);
	int init(TResultContainerList * pContainerList);
	int detectDoc(CResultContainerListR & a1, Json::Value & a2, TResultContainerList ** a3);
	int locateDocOnePage(TResultContainerList & a1);
	int locateDocOnePage(common::container::RclHolder & a1, common::container::RclHolder & a2);
	int locateDoc(common::container::RclHolder & a1, eRPRM_ResultType a2, TBoundsResult & a3);
	int locateDoc(common::container::RclHolder & a1, common::container::RclHolder & a2, eRPRM_ResultType a3, TBoundsResult & a4, int a5);
	void initModuleForRequest(common::container::RclHolder & rclHolder);
	void setModulesParams(char const* szModuleParam);
	void startNewSession();
	int locateDoc(common::container::RclHolder & a1, common::container::RclHolder & a2);

	static int locatePoints(TResultContainerList & a1);

public:
	int m_nBField_4;
	BoundsInternal m_xBoundsInternal; 
	bool m_bStartNewSession;
	int m_nBField_4E8;
	common::container::RclHolder m_xBounds_field_4EC;
};

