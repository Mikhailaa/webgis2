﻿#pragma once

#include "../pch.h"

class DocumentDetectionParameter
{
public:
	DocumentDetectionParameter();
	DocumentDetectionParameter(DocumentDetectionParameter const & a1);
	DocumentDetectionParameter(DocumentDetectionParameter && a1);
	~DocumentDetectionParameter();

	void initByDef();
	void initParameter(DocumentDetectionParameter & a1);
	void setResolution(int a1);

	DocumentDetectionParameter & operator=(DocumentDetectionParameter & a1);

public:
	float m_rMinLengthLineForDetect;  //0
	float m_rMinLengthLineForDetectResolution;
	float m_rMinLinesLengthForContour;
	float m_rMinLinesLengthForContourResolution;
	float m_rLineDistForUnion; //10
	float m_rLineDistForUnionResolution;
	float m_rAngleRange;
	float m_rAverContour;  
	float m_rAverContourResolution; //20
	int m_nContourType;
	float m_rDocDeviation;
	float m_rDocDeviationLast;
	bool m_bOnlyDocFromIni;  //30
	int m_nRemoveBorderLine;
	int m_nThresholdBin;
	int m_nWorkW;
	int m_nWorkDPI;   //40
	float m_rFullDocDiff;
	bool m_bPerspectiveTr;
	bool m_bFullImgAnalOff;
	float m_rMinProbByProportion;
	float m_rMinProbBySize;   //50
	float m_rMinProbBySizeCalcProb;
	bool m_bFullDocumentDetectOnly;
	float m_rFullDocumentDetectDevMax;
	float m_rkMinDocSizebyWHImg;   //60
	int m_nROIFlag;
	int m_nROIX1;
	int m_nROIY1;
	int m_nROIX2;     //70
	int m_nROIY2;
	int m_nMultiPages;
	int m_nCheckWithBorder;
	int m_nUseVDAsMainResult;   //80
	int m_nUseMRZForFilterCandidate;
	int m_nUseMRZForFilterCandidate2;
	bool m_bUseMRZForCrop;
	int m_nUseFreeIntAngle;  //90
	int m_nMaxDevIntAngleForRectObj;
	float m_rkMinSideSize;
	float m_rLineHelpStop;
	float m_rLineHelpStart;  //A0
	float m_rDDPField_A4;  
	float m_rDDPField_A8;  
	float m_rCalcProb_LINE_INSIDE;
	float m_rCalcProb_MRD_DIST_2; //B0
	float m_rCalcProb_MRD_DIST_4;
	float m_rCalcProb_LINE_CONTOUR;
	float m_rDDPField_BC;
	float m_rDDPField_C0;  //C0
	bool m_fCalcProb_changingDPI;
	float m_rCalcProb_changingDPI_MinProbBySize;
	float m_rDDPField_CC;  //전화width / 그림width
	vector<string> m_vActiveGroups; //D0
	vector<wstring> m_vProcess;
};

class DocumentDetectionParameters
{
public:
	DocumentDetectionParameters();
	~DocumentDetectionParameters();

	void add(string & a1, DocumentDetectionParameter & a2);
	void sefDefParam(DocumentDetectionParameter & a1);
	bool contain(string & a1);
	//해당한 활동방식에 대한 파라메터를 돌려준다.
	DocumentDetectionParameter & param(string & a1); 

public:
	map<int, string> m_mDeviceIdWM;  //<deviceId, workMode>
	DocumentDetectionParameter m_xDefModeParam; //C
	vector<string> m_vWorkModeName; //F4
	vector<DocumentDetectionParameter> m_vWorkModeParam; //100
};
