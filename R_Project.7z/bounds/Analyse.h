#pragma once
#include "../pch.h"
#include "../ImageControl.h"
#include "LineEx.h"

class DocAngleParam 
{
public:
	vector<int> m_vDAPField_0;
	float m_rDAPAngle;
	float m_rDAPLen;  //10
};

namespace RAnalyse {
	void dynamicRange(cv::Mat &, int, int, int &, int &, int &, int, int);
	int dynamicRange(int *pnParam1, int nParam2, int nParam3, int nParam4, int &nParam5, int &nParam6, int &nParam7);
	int findThresholdBinary(IImageControlR &, int &, int, int);
	int findThresholdBinary(int *, int &, int, int, int);
	int findThresholdBinary3(IImageControlR &, int &, int &, int &, int, int);
	void findUpDown(uchar * a1, int a2, int a3, int a4, vector<pair<int, int>>& a5);
	void getProjectionV_LineWidth(CBufferImage & xCBI_Param1, int nParam2, vector<uchar> & vParam3);
	void getProjection_LineWidth(CBufferImage &a1, int a2, vector<uchar>& a3);
	void gist(vector<float> & a1, vector<float> & a2, vector<float> & a3, int a4);
	void gistCyclicWindow(vector<float> & a1, int a2, vector<float> & a3, vector<float> & a4);
	int histogramCenter(int *, float &, int, int);
	void maxAprox(vector<int> vn_a1, int n_a2, vector<pair<int, int>>& vpairnn_a3);
	int maxAprox(vector<int>a1, int a2, float &a3);
	int maxAprox(int *a1, int a2, int a3, float &a4);
	int maxAprox(int *a1, int a2, int a3, float &a4, int &a5);
	int maxAprox(int *a1, int a2, int a3, float &a4, int &a5, int &a6);
};

namespace AngleAnalyze {
	float checkIntAngle(tagPOINT &, tagPOINT &, tagPOINT &, tagPOINT &);
	void filterByAngle(vector<LineEx> & a1, float a2, float a3, DocAngleParam & a4);
	void filterByAngle(vector<LineEx> & a1, vector<int> & a2, float & a3, float & a4, vector<int> & a5, float & a6);
	void findAngles(vector<LineEx> & a1, float a2, float a3, vector<DocAngleParam> & a4);
	bool findAngle(vector<LineEx> & vLine, vector<int> & vInt, float & r3, float & r4);
	void splitOrtLines(vector<LineEx> & a1, float & a2, vector<int> & a3, vector<int> & a4, float * a5, float * a6);
	void splitOrtLines(vector<LineEx> & a1, vector<int> & a2, float & a3, vector<int> & a4, vector<int> & aa5, float * a6, float * a7);
}
