#include "LineGroup.h"
#include "LineEx.h"

#define PI 3.14159265358979323846

LineGroup::LineGroup()
{
	m_nMaxSeg = -1;
	m_bSegkLenGr_3C = 0;
	m_rAngleGr = 0;
	m_nField_20 = 0;
	m_rSegLen = 0;
}

LineGroup::LineGroup(LineGroup const & a1)
{
	m_rAngleGr = a1.m_rAngleGr;
	m_vSegPair = a1.m_vSegPair;
	m_rSegLen = a1.m_rSegLen;
	m_xMidPoint = a1.m_xMidPoint;
	m_nMaxSeg = a1.m_nMaxSeg;
	m_nField_20 = a1.m_nField_20;
	m_vLineExGr = a1.m_vLineExGr;
	m_vContoursID = a1.m_vContoursID;
	m_bSegkLenGr_3C = a1.m_bSegkLenGr_3C;
}

LineGroup::~LineGroup()
{

}

float LineGroup::calcDist(cv::Point2f & a1)
{
	double v1, v2;
	v1 = m_rAngleGr * PI / 180.0;
	v2 = sin(v1) * a1.y + cos(v1) * a1.x;
	return (float)v2;
}

int LineGroup::maxUnionLen()
{
	float r_ret, v2;

	r_ret = 0.0;
	for (uint i = 0; i < m_vSegPair.size(); i++)
	{
		v2 = fabsf(m_vSegPair[i].second - m_vSegPair[i].first);
		if (r_ret < v2)
			r_ret = v2;
	}

	return (int)r_ret;
}

float LineGroup::segnemtLen(float a1, float a2)
{
	float v1 = 0.0,v2,v3;

	if (m_vSegPair.empty())
	{
		mergeSegments(0.0);
	}

	for (uint i = 0; i < m_vSegPair.size(); i++)
	{
		v2 = m_vSegPair[i].first;
		if (v2 <= a2)
		{
			v3 = m_vSegPair[i].second;
			if (v3 >= a1)
			{
				if (v2 < a1)
					v2 = a1;
				if (v3 > a2)
					v3 = a2;
				v1 += v3 - v2;
			}
		}
	}

	return v1;
}

float LineGroup::segnemtLenOut(float a1, float a2)
{
	float v1 = 0.0, v2, v3, v4;

	if (m_vSegPair.empty())
		mergeSegments(0.0);

	for (uint i = 0; i < m_vSegPair.size(); i++)
	{
		v2 = m_vSegPair[i].first;
		v3 = m_vSegPair[i].second;
		if (v2 >= a1)
			v2 = a2;
		else if (v3 > a1)
			v3 = a1;

		v4 = 0.0;
		if (v3 - v2 > 0.0)
			v4 = v3 - v2;
		v1 += v4;
	}

	return v1;
}

void LineGroup::calcMiddlePoint()
{
	float v1, v2, v3, v4, v5;

	if (!m_vLineExGr.empty())
	{
		v3 = 0.0;
		v4 = 0.0;
		v5 = 0.0;
		for (uint i = 1; i < m_vLineExGr.size(); i++)
		{	
			v1 = (float)(m_vLineExGr[i].m_xStartPoint.x + m_vLineExGr[i].m_xEndPoint.x);
			v2 = (float)(m_vLineExGr[i].m_xStartPoint.y + m_vLineExGr[i].m_xEndPoint.y);
			v3 += m_vLineExGr[i].m_rLineLen;
			v4 += v1 * m_vLineExGr[i].m_rLineLen * 0.5f;
			v5 += v2 * m_vLineExGr[i].m_rLineLen * 0.5f;
		}

		if (v3 > 0.0f)
		{
			m_xMidPoint.x = (int)(v4 / v3);
			m_xMidPoint.y = (int)(v5 / v3);
		}
	}
}

void LineGroup::calcRealAngle()
{
	int v1;
	float v2, v3, v4, v5;

	v1 = maxSegment();
	v2 = (float)m_vLineExGr[v1].m_rLineAngle;
	v4 = 0.0f;
	v5 = 0.0f;

	for (uint i = 0; i < m_vLineExGr.size(); i++)
	{
		v3 = (float)m_vLineExGr[i].m_rLineAngle;
		if (fabsf(v2 - (v3 + 180.0f)) < fabsf(v2 - v3))
			v3 += 180.0;
		if (fabsf(v2 - (v3 - 180.0f)) < fabsf(v2 - v3))
			v3 -= 180.0;
		v4 += m_vLineExGr[i].m_rLineLen;
		v5 += m_vLineExGr[i].m_rLineLen * v3;
	}

	m_rAngleGr = v5 / v4;
}

void LineGroup::mergeSegments(float a1)
{
	vector<pair<float, bool>> v1;
	float v2, v6;
	int v5, v8, v9;
	pair<float, float> v7;

	if (m_vSegPair.empty())
	{
		for (uint i = 0; i < m_vLineExGr.size(); i++)
		{
			if (m_vLineExGr[i].m_rRotateSx >= m_vLineExGr[i].m_rRotateEx)
			{
				v2 = m_vLineExGr[i].m_rRotateSx;
				m_vLineExGr[i].m_rRotateSx = m_vLineExGr[i].m_rRotateEx;
				m_vLineExGr[i].m_rRotateEx = v2;
			}

			v1.push_back(pair<float, bool>(m_vLineExGr[i].m_rRotateSx, false));
			v1.push_back(pair<float, bool>(m_vLineExGr[i].m_rRotateEx, true));
		}

		sort(v1.begin(), v1.end());
		v5 = 0;
		v6 = 0.0;
		for (uint i = 0; i < v1.size(); i++)
		{
			if (!v5)
			{
				v6 = v1[i].first;
				v7.first = v1[i].first;
			}

			v8 = 1;
			if (!v1[i].second)
				v8 = -1;
			v5 += v8;
			v9 = m_vSegPair.size() - 1;

			if (!v5)
			{
				if (m_vSegPair.empty() || (v6 - m_vSegPair[v9].second) >= a1)
				{
					v7.second = v1[i].first;
					m_vSegPair.push_back(v7);
				}
				else
					m_vSegPair[v9].second = v1[i].first;
			}
		}
	}
}

void LineGroup::updateContoursID()
{
	vector<int> v1(10, 0);
	int v2;

	if (!m_vLineExGr.empty())
	{
		for (uint i = 0; i < m_vLineExGr.size(); i++)
		{
			v2 = m_vLineExGr[i].m_nCountourID;
			if (v2 >= 0)
			{
				if (v2 >= (int)v1.size())
					v1.resize(v2 + 1);
				v1[v2] = 1;
			}
		}

		m_vContoursID.clear();
		for (uint i = 0; i < v1.size(); i++)
		{
			if (v1[i])
				m_vContoursID.push_back(i);
		}
	}
	
}

int LineGroup::maxSegment()
{
	int v1;
	float v2;

	v1 = m_nMaxSeg;
	if (v1 == -1)
	{
		v2 = -1.0f;
		for (uint i = 0; i < m_vLineExGr.size(); i++)
		{
			if (m_vLineExGr[i].m_rLineLen == -1.0)
				LineExProcess::calcLen(m_vLineExGr[i]);

			if ( v2 < m_vLineExGr[i].m_rLineLen)
			{
				v2 = m_vLineExGr[i].m_rLineLen;
				v1 = i;
			}
		}
		m_nMaxSeg = v1;
	}

	return v1;
}

/*-----------------------------LineGroupList--------------------------*/
LineGroupList::LineGroupList(LineGroupList && a1)
{
	m_vLineGrList = move(a1.m_vLineGrList);
}

LineGroupList::LineGroupList()
{

}

LineGroupList::~LineGroupList()
{

}

void LineGroupList::filterByCount_Segment(int n_a1, int n_a2, vector<int> & vn_a3)  //count, limit
{
	LineGroup v3, v4, v6;

	vn_a3.clear();

	if (!m_vLineGrList.empty())
	{
		vector<int> vn_2C(m_vLineGrList.size());
		for (uint i = 0; i < vn_2C.size(); i++)
			vn_2C[i] = i;

		int i = 0;
		do
		{
			if (i >= n_a1)
				break;

			int nIndex = 0;
			for (uint j = 0; j < vn_2C.size(); j++)
			{
				v3 = m_vLineGrList.at(vn_2C[j]);
				v4 = m_vLineGrList.at(vn_2C[nIndex]);

				int r_a1 = v3.maxUnionLen();
				int r_a2 = v4.maxUnionLen();
				if (v3.maxUnionLen() >= v4.maxUnionLen())
					nIndex = j;
			}

			v6 = m_vLineGrList.at(vn_2C[nIndex]);
			if (v6.maxUnionLen() < n_a2)
				break;
			vn_a3.push_back(vn_2C[nIndex]);
			vn_2C.erase(vn_2C.begin() + nIndex);
			i++;
		} while (!vn_2C.empty());
	}
}

void LineGroupList::dividetByLen(vector<int> & a1, vector<int> & a2, vector<int> & a3, int a4)
{
	a2.clear();
	a3.clear();

	for (uint i = 0; i < a1.size(); i++)
	{
		if (m_vLineGrList[a1[i]].m_rSegLen >= a4)
			a2.push_back(a1[i]);
		else
			a3.push_back(a1[i]);
	}
}