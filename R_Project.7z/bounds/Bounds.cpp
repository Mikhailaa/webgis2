﻿#include "Bounds.h"
#include "../common/container/container.h"
#include "../regula.h"
#include "../docformatinfo.h"
#include "../mrz/MRZAnalyze.h"
#include "../rclhelp.h"
#include "../common/StringUtils.h"
#include "../json/CharReaderBuilder.h"
#include "../common/common.h"
#include "../common/fs.h"
#include "../common/container/json.h"
#include "../common/container/jsoncpp.h"
#include <fstream>
#include "../RCv.h"
#include "../sdk/ResultContainerList.h"
#include "../common/RegulaConfig.h"
#include "../common/ModuleOrchestrator.h"

int DocumentDetect::m_countourIndx;
DocumentDetectDebugInfo g_debugInfo_1129A4C, g_debugInfo_1129A10;

struct gBoundsExternal_global_registrator {
	shared_ptr<Bounds> gBoundsExternal;
	gBoundsExternal_global_registrator() {
		gBoundsExternal = common::getModuleOrchestrator()->addModule<Bounds>();
	}
} gBoundsExternal_global_registrator_;

eBinProcessImg convertImgType(wstring & a1)
{
	int v1 = a1.size();

	if (v1 == 7)
	{
		if (!a1.compare(0, -1, L"eBPI_IR", 7))
			return eBPI_IR;
	}

	if (v1 == 10)
	{
		if (!a1.compare(0, -1, L"eBPI_WHITE", 10))
			return eBPI_WHITE;
	}
	if (v1 == 15)
	{
		if (!a1.compare(0, -1, L"eBPI_WHITE_Gray", 15))
			return eBPI_WHITE_Gray;
	}
	if (v1 == 17)
	{
		if (!a1.compare(0, -1, L"eBPI_WHITE_GrayTr", 17))
			return eBPI_WHITE_GrayTr;
	}

	if (v1 == 12)
	{
		if (!a1.compare(0, -1, L"eBPI_WHITE_R", 12))
			return eBPI_WHITE_R;
	}

	if (v1 == 12)
	{
		if (!a1.compare(0, -1, L"eBPI_WHITE_G", 12))
			return eBPI_WHITE_G;
	}

	if (v1 == 12)
	{
		if (!a1.compare(0, -1, L"eBPI_WHITE_B", 12))
			return eBPI_WHITE_B;
	}

	if (v1 == 13)
	{
		if (!a1.compare(0, -1, L"eBPI_WHITE_TR", 13))
			return eBPI_WHITE_TR;
	}

	if (v1 == 7)
	{
		if (!a1.compare(0, -1, L"eBPI_UV", 7))
			return eBPI_UV;
	}

	if (v1 == 9)
	{
		if (!a1.compare(0, -1, L"eBPI_UV_R", 9))
			return eBPI_UV_R;
	}

	if (v1 == 9)
	{
		if (!a1.compare(0, -1, L"eBPI_UV_G", 9))
			return eBPI_UV_G;
	}

	if (v1 == 9)
	{
		if (!a1.compare(0, -1, L"eBPI_UV_B", 9))
			return eBPI_UV_B;
	}

	return eBPI_NO;
}

eBinProcess convertImgProcess(wstring & a1)
{
	int v1 = a1.size();

	if (v1 == 7)
	{
		if (!a1.compare(0, -1, L"eBP_OFF", 7))
			return eBP_OFF;
	}

	if (v1 == 9)
	{
		if (!a1.compare(0, -1, L"eBP_Sobel", 9))
			return eBP_Sobel;
	}

	if (v1 == 15)
	{
		if (!a1.compare(0, -1, L"eBP_BinUsual_50", 15))
			return eBP_BinUsual_50;
	}

	if (v1 == 15)
	{
		if (!a1.compare(0, -1, L"eBP_BinUsual_30", 15))
			return eBP_BinUsual_30;
	}

	if (v1 == 11)
	{
		if (!a1.compare(0, -1, L"eBP_BinOTSU", 11))
			return eBP_BinOTSU;
	}

	if (v1 == 10)
	{
		if (!a1.compare(0, -1, L"eBP_Resize", 10))
			return eBP_Resize;
	}

	if (v1 == 10)
	{
		if (!a1.compare(0, -1, L"eBP_Rotate", 10))
			return eBP_Rotate;
	}

	if (v1 == 11)
	{
		if (!a1.compare(0, -1, L"eBP_Resize2", 11))
			return eBP_Resize2;
	}

	if (v1 == 15)
	{
		if (!a1.compare(0, -1, L"eBP_BinFixLevel", 15))
			return eBP_BinFixLevel;
	}

	if (v1 == 11)
	{
		if (!a1.compare(0, -1, L"eBP_WBorder", 11))
			return eBP_WBorder;
	}

	if (v1 == 16)
	{
		if (!a1.compare(0, -1, L"eBP_BinUsual_15R", 16))
			return eBP_BinUsual_15R;
	}

	if (v1 == 13)
	{
		if (!a1.compare(0, -1, L"eBP_FilterBox", 13))
			return eBP_FilterBox;
	}

	if (v1 == 9)
	{
		if (!a1.compare(0, -1, L"eBP_Canny", 9))
			return eBP_Canny;
	}

	if (v1 == 8)
	{
		if (!a1.compare(0, -1, L"eBP_Mask", 8))
			return eBP_Mask;
	}

	if (v1 == 9)
	{
		if (!a1.compare(0, -1, L"eBP_Close", 9))
			return eBP_Close;
	}

	if (v1 == 13)
	{
		if (!a1.compare(0, -1, L"eBP_CloseRect", 13))
			return eBP_CloseRect;
	}

	if (v1 == 9)
	{
		if (!a1.compare(0, -1, L"eBP_Hough", 9))
			return eBP_Hough;
	}

	if (v1 == 10)
	{
		if (!a1.compare(0, -1, L"eBP_Hough2", 10))
			return eBP_Hough2;
	}

	if (v1 == 11)
	{
		if (!a1.compare(0, -1, L"eBP_OTSU_CV", 11))
			return eBP_OTSU_CV;
	}

	if (v1 == 19)
	{
		if (!a1.compare(0, -1, L"eBP_OTSU_ADAPT_GAUS", 19))
			return eBP_OTSU_ADAPT_GAUS;
	}

	if (v1 == 16)
	{
		if (!a1.compare(0, -1, L"eBP_GaussianBlur", 16))
			return eBP_GaussianBlur;
	}

	if (v1 == 18)
	{
		if (!a1.compare(0, -1, L"eBP_BinOTSU_Second", 18))
			return eBP_BinOTSU_Second;
	}

	if (v1 == 19)
	{
		if (!a1.compare(0, -1, L"eBP_BinOTSU_Previus", 19))
			return eBP_BinOTSU_Previus;
	}

	return eBP_NO;
}

/*------------------Start BoundsInternal-------------------*/
BoundsInternal::BoundsInternal()
	:m_xBIBoundsParam(Json::json_type_null), m_xuseDpiFromImage(Json::json_type_null), m_xModuleParam(Json::json_type_null)
{
	m_nmaxWorkTimeMs = 0;
	m_nmaxImageSizeInPix = 10000000;
	m_strWorkMode.clear();
	m_strDefWorkMode.clear();
	m_strBoundsInternal_field_1F0.clear();
	m_rBIk = 0.0;
	m_nBIField_3A4 = 0;
	m_fBIField_3A8 = false;
	memset(&m_xBITBoundsResult_3AC, 0, sizeof(TBoundsResult));
}

BoundsInternal::~BoundsInternal()
{
}

void BoundsInternal::resetHelpInfo()
{
	m_vBITBoundsResult_374.clear();
	m_vBITBoundsResult_380.clear();
	m_vBIPoint_38C.clear();
	m_nBIField_3A4 = 0;
	m_fBIField_3A8 = false;
}

//BoundsInternal에 추가적인 DocGroup을 설정한다.
int BoundsInternal::setAdditionalDocGroups(string & a1)
{
	Json::CharReaderBuilder charReader;
	Json::OurCharReader * ourCharReader;
	Json::Value vResult(0), vMember(0);
	string strResult;
	vector<string> vSplit;
	int nResult;

	if (a1.size())
	{
		ourCharReader = charReader.newCharReader();

		if (ourCharReader->parse(a1.c_str(), a1.c_str() + a1.size(), &vResult, 0))
		{
			strResult = vResult["AdditionalDocGroups"].asString();
			vSplit = common::StringUtils::Split(strResult, ',');
			for (uint i = 0; i < vSplit.size(); i++)
				m_vBIAddtionalDocGr.push_back(vSplit[i]);
			nResult = 0;
		}
		else
			nResult = 1;

	}
	else
	{
		m_vBIAddtionalDocGr.clear();
		nResult = 0;
	}

	return nResult;
}
#include <io.h>
int BoundsInternal::detectDoc(TResultContainerList & a1, Json::Value & a2)
{
	RclHolder rclHolder;
	vector<int> vDocFilter, vDocTemp, vByAngle;
	vector<string> vSplit;
	vector<TResultContainer *> vContainer;
	vector<TBoundsResult> vBoundsResult;
	vector<bounds::byrecognize::eBoundsByRecognizeMode> vRecognize;
	DocumentCandidateList docCanList;
	vector<DocumentCandidate> vDocCan;
	vector<LineEx> vLineBorder, vLineRect;
	vector<ProcessVariant> vProcessVariant;
	DocumentSize::DocumentIDCheck * docIDCheck;
	tagSIZE size;
	tagSIZE ksize;
	TBoundsResult *boundsResult, boundsResultRet;
	ImagesListMat imageListMat;
	string strRet, strMode;
	MatImage matImage;
	bounds::CheckDocumentParam checkDocParam;
	int nDpi, nResult, nRet, nTemp, nTemp1;
	float fTemp1, fTemp2, fTemp3, fCheckFull, fTemp5;
	int nDocFormat, nTemp2, nMinSide;
	Point point1, point2, point3, point4;
	Mat mat1;

	rclHolder.addNoCopy(a1);
	rclHolder.addNewNoCopy(51, &a2);

	m_vBITBoundsResult_210.clear();
	m_vBIDocFilter.clear();
	m_xBIBoundsState.resetCurrentFrame();

	vDocFilter = DocumentSize::docFilter123x2();
	m_nBIDeviceType = rclhelp::deviceTypeReal(a1);
	strRet = m_xBIBoundsParam.get("checkVariants", Json::Value("")).asString();

	vSplit = common::StringUtils::Split(strRet, ',');
	vRecognize.reserve(vSplit.size());
	for (uint i = 0; i < vSplit.size(); i++)
		vRecognize.push_back(bounds::byrecognize::convert(vSplit[i]));

	initHelpInfo(a1);
	strMode = m_xBIDocDetectParams.m_mDeviceIdWM[m_nBIDeviceType];

	if (m_nBIDeviceType && strMode.size())
		m_strWorkMode = strMode;
	else
		m_strWorkMode = m_strDefWorkMode;

	m_xBIDocDetect.m_xDocDTParam.initParameter(m_xBIDocDetectParams.param(m_strWorkMode));

	if (m_fBIField_3A8 && m_xBIDocDetect.m_xDocDTParam.m_nUseVDAsMainResult)
	{
		m_vBITBoundsResult_210.push_back(m_xBITBoundsResult_3AC);
		return 0;
	}

	nDpi = 0;
	if (nResult = getImages(a1, imageListMat, nDpi, size))
		return nResult;

	m_xBIImgSize = Size(size.cx, size.cy);

	if (size.cx * size.cy > m_nmaxImageSizeInPix)
		return 0;
	
	bool fUseDpi = true;
	if (!m_nBIDeviceType)
	{
		if (!m_xuseDpiFromImage["useDpiFromImage"].asInt())
			fUseDpi = false;
	}

	BoundsResult::initResult(size, DOCFORMAT_3E8, m_xBIDocCan);

	if (a2["processparam"].get("alreadyCropped", Json::Value(false)).asBool())
		return 0;
	
	bool fFlagA4;
	if (m_nBIDeviceType == 0x10000004)
		fFlagA4 = true;
	else if (m_nBIDeviceType)
		fFlagA4 = false;
	else
		fFlagA4 = DocumentSize::isA4Size(size, nDpi, 0.03f);   //화상크기가 a4인가 판정한다.
	
	if (!nDpi)
	{
		vDocFilter = DocumentSize::docFilter13();
		if (m_vBITBoundsResult_374.size() == 2)
			m_vBITBoundsResult_374.resize(1);
	}
	/*-----------------------------------------no------------------------------------*/
	if (fFlagA4)
	{
		vDocFilter.clear();
		vDocFilter.push_back(2);
		vDocFilter.push_back(5);
		if (rclhelp::documentFormatFromMRZOld(a1) != 2)
		{
			vDocFilter.push_back(0);
			vDocFilter.push_back(1);
		}
		m_strWorkMode.assign("BoundsMode_Scanner");
	}
	else
	{
		CDocFormat fomart;
		if ((fomart = rclhelp::documentFormat(a1)) == DOCFORMAT_UNKNOWN)
			fomart = rclhelp::documentFormatFromMRZOld(a1);

		vDocTemp = DocumentSize::docFilter123x2();
		uint j;
		for (j = 0; j < vDocTemp.size(); j++)
		{
			if (vDocTemp[j] == fomart)
				break;
		}
		/*-----------------------------------------no------------------------------------*/
		if (j != vDocTemp.size())
		{
			vDocFilter.clear();
			vDocFilter.push_back(fomart);

			if (fomart == DOCFORMAT_2)
			{
				if (!vRecognize.empty() && (nDpi || m_nBIField_3A4))
					vDocFilter.push_back(5);
			}
			else if (fomart == DOCFORMAT_1 && MRZAnalyze::isVisaID2(a1))
				vDocFilter.push_back(2);
		}

		if (!m_nBIDeviceType)
		{
			m_strWorkMode = m_xBIBoundsParam.get("processMode", Json::Value("")).asString();

			if (m_strWorkMode == "FullImage")
				return 0;
			if (!m_xBIDocDetectParams.contain(m_strWorkMode))
				m_strWorkMode.assign("BoundsMode_NoDPI_Perspective");
		}
	}

	m_xBIDocDetect.m_xDocDTParam.initParameter(m_xBIDocDetectParams.param(m_strWorkMode));

	/*-----------------------------------------no------------------------------------*/
	if (m_nBIDeviceType)
	{
		if (!m_vBITBoundsResult_374.empty() &&
			AngleAnalyze::checkIntAngle(m_vBITBoundsResult_374[0].xTBR_LeftTop, m_vBITBoundsResult_374[0].xTBR_LeftBottom,
				m_vBITBoundsResult_374[0].xTBR_RightBottom, m_vBITBoundsResult_374[0].xTBR_RightTop) > 3.0)
			m_xBIDocDetect.m_xDocDTParam.m_nUseMRZForFilterCandidate = 0;
	}

	docIDCheck = m_xBIDocDetect.docCheck();

	/*-----------------------------------------no------------------------------------*/
	vSplit.clear();
	if (m_xBIBoundsParam.isMember("activeDocFormatGroups"))
	{
		vSplit = common::StringUtils::Split(m_xBIBoundsParam["activeDocFormatGroups"].asString(), ',');
		docIDCheck->setActiveGroups(vSplit);
		docIDCheck->resetDocumentsFilter();
	}
	else
	{
		vSplit.assign(m_xBIDocDetect.m_xDocDTParam.m_vActiveGroups.begin(), m_xBIDocDetect.m_xDocDTParam.m_vActiveGroups.end());
		vSplit.insert(vSplit.end(), m_vBIAddtionalDocGr.begin(), m_vBIAddtionalDocGr.end());
		
		if (&vDocFilter != &m_vBIDocFilter && !m_vBIDocFilter.empty())
			vDocFilter = m_vBIDocFilter;

		docIDCheck->setActiveGroups(vSplit);
		docIDCheck->setDocumentsFilter(vDocFilter);
	}
	/*-----------------------------------------no------------------------------------*/
	if (m_xuseDpiFromImage.isMember("OnlyDocFromIni"))
		m_xBIDocDetect.m_xDocDTParam.m_bOnlyDocFromIni = m_xuseDpiFromImage["OnlyDocFromIni"].asBool();
	/*-----------------------------------------no------------------------------------*/
	if (m_xModuleParam.isMember("UseVDAsMainResult"))
		m_xBIDocDetect.m_xDocDTParam.m_nUseVDAsMainResult = m_xModuleParam["UseVDAsMainResult"].asBool();

	if (m_xBIDocDetect.m_xDocDTParam.m_nWorkDPI >= nDpi)  //bb8
	{
		nTemp = size.cy;
		if (size.cx < size.cy)
			nTemp = size.cx;
		m_rBIk = (float)m_xBIDocDetect.m_xDocDTParam.m_nWorkW / nTemp;
	}
	else
	{
		m_rBIk = (float)m_xBIDocDetect.m_xDocDTParam.m_nWorkDPI / nDpi;

		nTemp = size.cy;
		if (size.cx < size.cy)
			nTemp = size.cx;

		if (m_rBIk * nTemp < m_xBIDocDetect.m_xDocDTParam.m_nWorkW)
			m_rBIk = (float)m_xBIDocDetect.m_xDocDTParam.m_nWorkW / nTemp;
	}

	m_xBIDocDetect.m_xDocDTParam.m_rDDPField_CC = m_rBIk;
	if (m_nSaveImage)
	{
		bounds::debug::dddi()->init(rclHolder, m_rBIk);
	}

	nTemp = !nDpi ? m_nBIField_3A4 : nDpi;

	ksize.cx = (int)(m_rBIk * size.cx);
	ksize.cy = (int)(m_rBIk * size.cy);

	int n370 = (int)(m_rBIk * nTemp);
	nTemp1 = (n370 > 5000) ? n370 : 5000;

	m_xBIDocDetect.m_xDocDTParam.setResolution(nTemp1);
	m_xBIFaceInfo.setK(m_rBIk);
	m_vBIPoint_398.assign(m_vBIPoint_38C.begin(), m_vBIPoint_38C.end());

	/*-----------------------------------------no------------------------------------*/
	for (uint i = 0; i < m_vBIPoint_398.size(); i++)
	{
		m_vBIPoint_398[i].x *= m_rBIk;
		m_vBIPoint_398[i].y *= m_rBIk;
	}
	/*-----------------------------------------no------------------------------------*/
	if (m_vBITBoundsResult_374.empty())
	{
		if (vRecognize.empty() && !m_xBIHolder_490.empty())
		{
			vContainer = m_xBIHolder_490.getRcList(85);

			if (!vContainer.empty() && vContainer[0]->u.pTRC_TBR != 0)
			{
				boundsResult = vContainer[0]->u.pTRC_TBR;
				vector<Point2f> vPoint = {
					Point2f((float)boundsResult->xTBR_LeftTop.x, (float)boundsResult->xTBR_LeftTop.y),
					Point2f((float)boundsResult->xTBR_RightTop.x, (float)boundsResult->xTBR_RightTop.y),
					Point2f((float)boundsResult->xTBR_RightBottom.x, (float)boundsResult->xTBR_RightBottom.y),
					Point2f((float)boundsResult->xTBR_LeftBottom.x, (float)boundsResult->xTBR_LeftBottom.y)
				};
				bounds::maskprocess::updateRect(vPoint, 0.3f, m_vBIPoint_340);
				bounds::maskprocess::updateRect(vPoint, -0.2f, m_vBIPoint_34C);
				bounds::boundsresult::scale(m_vBIPoint_340, m_vBIPoint_358, m_rBIk);
				bounds::boundsresult::scale(m_vBIPoint_34C, m_vBIPoint_364, m_rBIk);
				Size sz;
				sz.width = ksize.cx;
				sz.height = ksize.cy;
				generateMask(sz, matImage, m_vBIPoint_358, m_vBIPoint_364);
			}
		}
	}
	else
	{
		vBoundsResult.resize(m_vBITBoundsResult_374.size());
		for (uint i = 0; i < m_vBITBoundsResult_374.size(); i++)
			bounds::boundsresult::scale(m_vBITBoundsResult_374[i], vBoundsResult[i], m_rBIk, 0.0);
	}

	/*-----------------------------------------no------------------------------------*/
	if (!m_xBIDocDetect.m_xDocDTParam.m_bFullImgAnalOff && nDpi)
	{
		bool fInit = false;
		DocumentCandidate docCand;
		fTemp1 = 0.0;
		nDocFormat = -1;
		m_xBIDocDetect.m_xDocIdCheck.isID(size.cx, size.cy, nDpi, fTemp1, nDocFormat);
		if ((nDocFormat == 0 || nDocFormat == 1 || nDocFormat == 2 || nDocFormat == 5) && fTemp1 > (1.0 - m_xBIDocDetect.m_xDocDTParam.m_rFullDocDiff))
		{
			BoundsResult::initResult(size, nDocFormat, docCand);
			fInit = true;
		}
		else
		{
			m_xBIDocDetect.m_xDocIdCheck.isID(size.cy, size.cx, nDpi, fTemp1, nDocFormat);
			if ((nDocFormat == 0 || nDocFormat == 1 || nDocFormat == 2 || nDocFormat == 5) && fTemp1 > (1.0 - m_xBIDocDetect.m_xDocDTParam.m_rFullDocDiff))
			{
				BoundsResult::initResult90(size, nDocFormat, docCand);
				fInit = true;
			}
			else
			{
				if (m_xBIDocDetect.m_xDocDTParam.m_fCalcProb_changingDPI)
				{
					fTemp2 = fTemp3 = 0.0;
					nTemp2 = -1;
					m_xBIDocDetect.m_xDocIdCheck.isIDByProportionAndSize((float)size.cx * 1000.0f / nDpi,
						(float)size.cy * 1000.0f / nDpi, 0.92f, fTemp2, fTemp3, nTemp2);

					if (fTemp2 > (1.0 - m_xBIDocDetect.m_xDocDTParam.m_rFullDocDiff))
					{
						BoundsResult::initResult(size, nDocFormat, docCand);
						fInit = true;
					}
				}
			}
		}
		if (fInit)
		{
			if (m_vBITBoundsResult_380.empty() || docCand.m_nDocType == m_vBITBoundsResult_380[0].nTBR_docFormat)
			{
				vDocCan.push_back(docCand);
				m_rBIk = 1.0;
				createResultList(vDocCan, m_vBITBoundsResult_380.empty() ? 0 : &m_vBITBoundsResult_380[0], 1.0, 0, m_vBITBoundsResult_210, 0);
				return 0;
			}
		}
	}

	/*-----------------------------------------no------------------------------------*/
	for (uint i = 0; i < m_vBITBoundsResult_374.size(); i++)
	{
		fCheckFull = 0.0;
		checkFullImageDoc(m_vBITBoundsResult_374[i], size, fCheckFull);
		if (fCheckFull > (1.0 - m_xBIDocDetect.m_xDocDTParam.m_rFullDocDiff))
		{
			vDocCan.resize(1);
			if (size.cx <= size.cy)
				BoundsResult::initResult90(ksize, m_vBITBoundsResult_374[i].nTBR_docFormat, vDocCan[0]);
			else
				BoundsResult::initResult(ksize, m_vBITBoundsResult_374[i].nTBR_docFormat, vDocCan[0]);

			createResultList(vDocCan, &m_vBITBoundsResult_374[0], m_rBIk, false, m_vBITBoundsResult_210, 0);
			return 0;
		}
	}

	LineExProcess::generateBorderLines(ksize, vLineBorder);
	LineExProcess::initLinesAngle(vLineBorder);

	/*-----------------------------------------no------------------------------------*/
	if (m_fBIField_3A8)
	{
		memset(&boundsResultRet, 0, sizeof(TBoundsResult));
		bounds::boundsresult::scale(m_xBITBoundsResult_3AC, boundsResultRet, m_rBIk, 0.0);
		LineExProcess::generateRectsLines(boundsResultRet.xTBR_LeftTop, boundsResultRet.xTBR_RightTop,
			boundsResultRet.xTBR_LeftBottom, boundsResultRet.xTBR_RightBottom, vLineRect);
	}

	m_mBIProcVariant.filter(m_xBIDocDetect.m_xDocDTParam.m_vProcess, vProcessVariant);
	vector<bounds::lines::ProcessStore> vProcessStore(vProcessVariant.size());

	/*-----------------------------------------no------------------------------------*/
	int n_r4;
	if (n370)
	{
		if (m_xBIDocDetect.m_xDocDTParam.m_bOnlyDocFromIni)
			nMinSide = m_xBIDocDetect.m_xDocIdCheck.minSideLenght(n370, 0);
		else
			nMinSide = 35 * n370 / 1000;
		n_r4 = (int)(m_xBIDocDetect.m_xDocDTParam.m_rkMinSideSize * nMinSide);
	}
	else
	{
		int nWidth = ksize.cx;
		if (ksize.cy < ksize.cx)
			nWidth = ksize.cy;
		nMinSide = (int)(m_xBIDocDetect.m_xDocDTParam.m_rkMinDocSizebyWHImg * nWidth);
		n_r4 = nMinSide;
	}

	checkDocParam.vCDPPoint = 0;
	checkDocParam.xCDPFaceInfo = 0;
	checkDocParam.vBoundsResult1 = 0;
	checkDocParam.vBoundsResult2 = 0;
	checkDocParam.fCDPField_2C = 0.5f;
	checkDocParam.fCDPField_30 = 0.2f;
	checkDocParam.nCDPField_0 = n370;
	checkDocParam.fCDPField_4 = fUseDpi;
	checkDocParam.rCDPField_8 = (float)n_r4;
	checkDocParam.xCDPSize = ksize;
	checkDocParam.xCDPDocDetect = &m_xBIDocDetect;
	checkDocParam.fCDPchangingDPI = m_xBIDocDetect.m_xDocDTParam.m_fCalcProb_changingDPI;

	/*-----------------------------------------no------------------------------------*/
	if (!m_vBITBoundsResult_374.empty())
	{
		if (m_xBIDocDetect.m_xDocDTParam.m_nUseMRZForFilterCandidate)
			checkDocParam.vBoundsResult1 = &vBoundsResult;
		if (!m_xBIBoundsParam["MrzFromOtherFrame"].asBool() && m_xBIDocDetect.m_xDocDTParam.m_nUseMRZForFilterCandidate2)
			checkDocParam.vBoundsResult2 = &vBoundsResult;
	}

	/*-----------------------------------------no- 3-----------------------------------*/
	if (!m_vBIPoint_398.empty())
		checkDocParam.vCDPPoint = &m_vBIPoint_398;
	if (vRecognize.empty())
		checkDocParam.xCDPFaceInfo = &m_xBIFaceInfo;
	if (m_xBIDocDetect.m_xDocDTParam.m_nMultiPages)
		m_xBIDocDetect.m_bSegLenOut = 0;

	DocumentDetect::m_countourIndx = 0;
	DocumentCandidate docCan;
	uint nLines;
	bool nFlag1 = false, nFlag2 = vRecognize.empty();
	int nTemp5, nTemp4, nTemp6;

	nRet = 0;
	for (uint i = 0; i < vProcessVariant.size(); i++)
	{
		nLines = i;
		vDocCan.clear();
		bounds::lines::getLines(vProcessVariant, nLines, vProcessStore, imageListMat, mat1, m_xBIDocDetect.m_xDocDTParam, nLines);
		/*{
			LineEx line;
			FILE* fp = fopen("d:\\test\\1.line", "rb");
			long l = _filelength(_fileno(fp));
			nLines = 3;
			l /= sizeof(LineEx);
			vProcessStore[nLines].m_xPS_field_30.clear();
			for (int i = 0; i < l; i++)
			{
				fread(&line, sizeof(LineEx), 1, fp);
				vProcessStore[nLines].m_xPS_field_30.push_back(line);
			}
			fclose(fp);
		}*/
		if (!vProcessStore[nLines].m_xPS_field_30.empty() && vProcessVariant[nLines].m_nProcessType)
		{
			if (!nFlag1 && (nLines != vProcessVariant.size() - 1) && !nFlag2)
			{
				i = nLines;
				continue;
			}
			nFlag1 |= (nLines == vProcessVariant.size() - 1);

			AngleAnalyze::findAngles(vProcessStore[nLines].m_xPS_field_30, m_xBIDocDetect.m_xDocDTParam.m_rAngleRange, m_xBIDocDetect.m_xDocDTParam.m_rMinLinesLengthForContourResolution, vProcessStore[nLines].m_xPS_field_24);
			vProcessStore[nLines].m_xPS_field_3C.resize(vProcessStore[nLines].m_xPS_field_24.size());

			if (!vLineBorder.empty())
			{
				for (uint j = 0; j < vProcessStore[nLines].m_xPS_field_24.size(); j++)
				{
					vector<int> vSplit1, vSplit2;
					DocAngleParam docAngleParam;
					AngleAnalyze::filterByAngle(vLineBorder, vProcessStore[nLines].m_xPS_field_24[j].m_rDAPAngle,
						m_xBIDocDetect.m_xDocDTParam.m_rAngleRange, docAngleParam);
					AngleAnalyze::splitOrtLines(vLineBorder, vProcessStore[nLines].m_xPS_field_24[j].m_rDAPAngle,
						vSplit1, vSplit2, 0, 0);
					LineExProcess::combineLines(vLineBorder, vSplit2, m_xBIDocDetect.m_xDocDTParam.m_rLineDistForUnionResolution, vProcessStore[nLines].m_xPS_field_3C[j].m_xGL_field_30.m_vLineGrList, -1);
					LineExProcess::combineLines(vLineBorder, vSplit1, m_xBIDocDetect.m_xDocDTParam.m_rLineDistForUnionResolution, vProcessStore[nLines].m_xPS_field_3C[j].m_xGL_field_3C.m_vLineGrList, -1);
				}
			}

			fTemp1 = m_xBIDocDetect.m_xDocDTParam.m_rkMinSideSize;
			if (!vRecognize.empty())
				fTemp1 = 0.4f;
			int n_3A0 = (int)(fTemp1 * nMinSide * 0.3f);
			int n_39C = (int)(fTemp1 * nMinSide * 0.2f);

			for (uint j = 0; j < vProcessStore[nLines].m_xPS_field_24.size(); j++)
			{
				vector<int> vSplit2, vSplit3;
				AngleAnalyze::splitOrtLines(vProcessStore[nLines].m_xPS_field_30, vProcessStore[nLines].m_xPS_field_24[j].m_vDAPField_0,
					vProcessStore[nLines].m_xPS_field_24[j].m_rDAPAngle, vSplit2, vSplit3, 0, 0);

				LineExProcess::combineLines(vProcessStore[nLines].m_xPS_field_30, vSplit3, m_xBIDocDetect.m_xDocDTParam.m_rLineDistForUnionResolution, vProcessStore[nLines].m_xPS_field_3C[j].m_xGL_field_0.m_vLineGrList, 30);
				LineExProcess::combineLines(vProcessStore[nLines].m_xPS_field_30, vSplit2, m_xBIDocDetect.m_xDocDTParam.m_rLineDistForUnionResolution, vProcessStore[nLines].m_xPS_field_3C[j].m_xGL_field_C.m_vLineGrList, 30);

				vector<int> vSegInt1, vSegInt2, vSegInt3, vSegInt4;
				vProcessStore[nLines].m_xPS_field_3C[j].m_xGL_field_0.filterByCount_Segment(20, n_39C, vSegInt1);
				vProcessStore[nLines].m_xPS_field_3C[j].m_xGL_field_C.filterByCount_Segment(20, n_39C, vSegInt2);
				vProcessStore[nLines].m_xPS_field_3C[j].m_xGL_field_0.dividetByLen(vSegInt1, vProcessStore[nLines].m_xPS_field_3C[j].m_xGL_field_18, vSegInt3, n_3A0);
				vProcessStore[nLines].m_xPS_field_3C[j].m_xGL_field_C.dividetByLen(vSegInt2, vProcessStore[nLines].m_xPS_field_3C[j].m_xGL_field_24, vSegInt4, n_3A0);
				bounds::candidates::makeDocument(vProcessStore[nLines].m_xPS_field_3C[j].m_xGL_field_0.m_vLineGrList, vProcessStore[nLines].m_xPS_field_3C[j].m_xGL_field_18, vProcessStore[nLines].m_xPS_field_3C[j].m_xGL_field_C.m_vLineGrList,
					vProcessStore[nLines].m_xPS_field_3C[j].m_xGL_field_24, vProcessStore[nLines].m_xPS_field_3C[j].m_xGL_field_30.m_vLineGrList, vProcessStore[nLines].m_xPS_field_3C[j].m_xGL_field_3C.m_vLineGrList, m_xBIDocDetect.m_xDocIdCheck,
					checkDocParam, (int)(fTemp1 * nMinSide), vProcessStore[nLines].m_xPS_field_0.m_vDocCanList, m_xBIDocDetect.m_xDocDTParam.m_nCheckWithBorder);
			}

			if (!checkDocParam.fCDPField_4)
				vProcessStore[nLines].m_xPS_field_0.calculateProbForWrongDPI(0.85f);

			vProcessStore[nLines].m_xPS_field_0.filterByIntAngle((float)m_xBIDocDetect.m_xDocDTParam.m_nMaxDevIntAngleForRectObj,
				vProcessStore[nLines].m_xPS_field_C, vProcessStore[nLines].m_xPS_field_18);

			fTemp5 = m_xBIDocDetect.m_xDocDTParam.m_rDocDeviation;
			if (nFlag1)
				fTemp5 = m_xBIDocDetect.m_xDocDTParam.m_rDocDeviationLast;

			vector<int> vSplit4(vProcessStore[nLines].m_xPS_field_0.m_vDocCanList.size());
			for (uint j = 0; j < vSplit4.size(); j++)
				vSplit4[j] = j;

			if (!vRecognize.empty())
			{
				vector<int> vFreeBest;
				tagRECT frameRect = common::jsoncpp::imageparam::getFrameRect(a2["imageInputParam"]["frame"]);
				m_xBIDocDetect.find_Free_Best(vProcessStore[nLines].m_xPS_field_0, vSplit4, vFreeBest, 0, 500);
				bounds::byrecognize::detectByRecognize(rclHolder, vProcessStore[nLines].m_xPS_field_0, vFreeBest, m_xBIHolder_490, m_xBIDocDetect, m_vBITBoundsResult_374,
					m_vBITBoundsResult_380, m_vBIPoint_38C, m_nBIField_3A4, m_xBIBoundsState, vRecognize, size, frameRect, m_rBIk);

				nResult = nRet;
				nTemp6 = nFlag1 & 1;
				if (nTemp6) nResult = 0;
			}
			else if (vProcessStore[nLines].m_xPS_field_0.m_vDocCanList.empty())
			{
				nResult = nRet;
				nTemp6 = nFlag1 & 1;
				if (nTemp6) nResult = 0;
				nTemp5 = nFlag1 ^ 1;
			}
			else
			{
				nTemp4 = -1;
				nTemp5 = -1;
				m_xBIDocDetect.m_bSegLenOut = 0;
				vector<int> vSplit1, vSplit3;
				m_xBIDocDetect.find_90_Last(vProcessStore[nLines].m_xPS_field_0, vProcessStore[nLines].m_xPS_field_C, vSplit3);

				if (!vSplit3.empty())
					nTemp5 = vSplit3[0];

				m_xBIDocDetect.m_bSegLenOut = true;

				if (m_xBIDocDetect.m_xDocDTParam.m_nUseFreeIntAngle)
				{
					m_xBIDocDetect.find_Free_Best(vProcessStore[nLines].m_xPS_field_0, vProcessStore[nLines].m_xPS_field_18, vSplit1, nFlag2, 10);
					if (!vSplit1.empty())
						nTemp4 = vSplit1[0];
				}

				if (nTemp5 == -1 || nTemp4 != -1)
				{
					if (nTemp5 == -1 && nTemp4 != -1)
					{
						docCan = vProcessStore[nLines].m_xPS_field_0.m_vDocCanList[nTemp4];
					}
					if (nTemp5 != -1 && nTemp4 != -1)
					{
						if (vProcessStore[nLines].m_xPS_field_0.m_vDocCanList[nTemp4].m_rProbAngle >=
							vProcessStore[nLines].m_xPS_field_0.m_vDocCanList[nTemp5].m_rProbAngle)
							docCan = vProcessStore[nLines].m_xPS_field_0.m_vDocCanList[nTemp4];
						else
							docCan = vProcessStore[nLines].m_xPS_field_0.m_vDocCanList[nTemp5];
					}
				}
				else
				{
					if (vProcessStore[nLines].m_xPS_field_0.m_vDocCanList[nTemp5].m_rProbAngle >= 1.0 - fTemp5)
						docCan = vProcessStore[nLines].m_xPS_field_0.m_vDocCanList[nTemp5];
				}

				if (m_xBIDocDetect.m_xDocDTParam.m_nMultiPages && docCan.m_bDCField_8 && docCan.m_rIntAngle <= 2.0)
				{
					vector<int> vSplit2;
					m_xBIDocDetect.find_Multi(vProcessStore[nLines].m_xPS_field_0, docCan, vProcessStore[nLines].m_xPS_field_C, vSplit2);
					for (uint j = 0; j < vSplit2.size(); j++)
						vDocCan.push_back(vProcessStore[nLines].m_xPS_field_0.m_vDocCanList[vSplit2[j]]);
				}

				if (vDocCan.empty() && !m_vBIPoint_38C.empty() && (docCan.m_rMrzParam2 < 0.93 || docCan.m_rMrzParam4 < 0.9))
					docCan.clear();

				nTemp6 = 0;
				if (docCan.m_rProbAngle >= 1.0 - m_xBIDocDetect.m_xDocDTParam.m_rDocDeviation)
					nTemp6 = 14;

				if (docCan.m_rProbAngle < 1.0 - m_xBIDocDetect.m_xDocDTParam.m_rDocDeviation && nFlag1)
				{
					if (!m_xBIDocDetect.m_xDocDTParam.m_bOnlyDocFromIni)
					{
						vector<int> vSplit2;
						DocumentDetect::find_BigestFree(vProcessStore[nLines].m_xPS_field_0, vProcessStore[nLines].m_xPS_field_C, 10, vSplit2);
						if (!vSplit2.empty())
						{
							if (vProcessStore[nLines].m_xPS_field_0.m_vDocCanList[vSplit2[0]].m_rProbAngle > 0.0)
							{
								docCan = vProcessStore[nLines].m_xPS_field_0.m_vDocCanList[vSplit2[0]];
								docCan.m_nDocType = 3;
							}
						}
					}
					nTemp6 = 0;
				}

				if (nTemp6 == 0 && nFlag1) nTemp5 = 0;
				else nTemp5 = 1;
				nResult = nTemp5 & 1;
				if (!nResult)
					nTemp6 = 1;
				if (nResult)
					nResult = nRet;
			}

			if (!vRecognize.empty() || (nTemp5 << 31))
			{
				if (nTemp6)
				{
					if (nTemp6 == 14)
						break;
					return nResult;
				}
				nRet = nResult;
			}
			else if (docCan.m_rMainProb == 0.0)
			{
				vector<int> vSplit3;
				m_xBIDocDetect.find_Free_Last(vProcessStore[nLines].m_xPS_field_0, vProcessStore[nLines].m_xPS_field_18, vSplit3);
				if (!vSplit3.empty())
					docCan = vProcessStore[nLines].m_xPS_field_0.m_vDocCanList[vSplit3[0]];
			}
		}
		i = nLines;
	}

	filterByExtParameters(a2, vDocCan, m_rBIk);
	if (!vDocCan.empty() && !m_vBITBoundsResult_374.empty() && (docCan.m_rMrzParam2 < 0.93 || docCan.m_rMrzParam4 < 0.9))
	{
		createResultList(m_vBITBoundsResult_374[0], m_vBITBoundsResult_210, m_xBIDocDetect.m_xDocDTParam.m_bPerspectiveTr);
		return 0;
	}
	
	if (docCan.m_rMainProb)
	{
		bounds::debug::dddi()->linesSave(docCan.m_vCornerDC, 0);
		vDocCan.insert(vDocCan.begin(), docCan);
	}
	filterByExtParameters(a2, vDocCan, m_rBIk);
	if (vDocCan.empty() && !m_vBITBoundsResult_374.empty() && m_xBIDocDetect.m_xDocDTParam.m_bUseMRZForCrop)
	{
		createResultList(m_vBITBoundsResult_374[0], m_vBITBoundsResult_210, m_xBIDocDetect.m_xDocDTParam.m_bPerspectiveTr);
		return 0;
	}
	
	createResultList(vDocCan, m_vBITBoundsResult_380.empty() ? 0 : &m_vBITBoundsResult_380[0], m_rBIk, m_xBIDocDetect.m_xDocDTParam.m_bPerspectiveTr, m_vBITBoundsResult_210, 0);
	return 0;
}

void BoundsInternal::initHelpInfo(TResultContainerList & a1)
{
	TBoundsResult boundResult;
	vector<Point2f> vPoint;
	vector<MRZAnalyze::MrzCornerResult> vMrzResult;
	TResultContainer *resultContainer;
	tagSIZE size;
	DocumentSize::DocumentIDCheck * docIDCheck;
	int nMrzInfo0, nMrzInfo1, nMrzInfo2;

	resetHelpInfo();
	if (m_nBIDeviceType && MRZAnalyze::isBGRVisa(a1))
	{
		m_vBIDocFilter.assign(1, 2);
		memset(&boundResult, 0, sizeof(TBoundsResult));
		boundResult.nTBR_docFormat = 2;
		initDocumentFilter(boundResult);
	}
	else
	{
		if (!MRZAnalyze::isArgId(a1) && !MRZAnalyze::isEcuId(a1) || m_nBIDeviceType)
		{
			if (!MRZAnalyze::getRealDocPos(a1, vPoint, m_vBIPoint_38C, vMrzResult, m_nBIField_3A4))
			{
				if (vMrzResult.size())
				{
					for (uint i = 0; i < vMrzResult.size(); i++)
					{
						MRZAnalyze::MrzCornerResult mrzCorner(vMrzResult[i]);
						memset(&boundResult, 0, sizeof(TBoundsResult));
						boundResult.nTBR_docFormat = mrzCorner.m_nMCR_DocForamt;
						boundResult.cTBR_PerspectiveTr = 1;
						boundResult.cTBR_ResultStatus = 4;
						BoundsResult::initCorners(boundResult, mrzCorner.m_vMrzCorner_field_0);
						bounds::result::updateSizeOutByDocFormat(boundResult);
						m_vBITBoundsResult_374.push_back(boundResult);
					}

					MRZAnalyze::getBoundaryArea(vPoint, m_vBIPoint_38C, vMrzResult[0].m_nMCR_DocForamt, 0.8f, 0.6f, m_vBIPoint_340);
					MRZAnalyze::getBoundaryArea(vPoint, m_vBIPoint_38C, vMrzResult[0].m_nMCR_DocForamt, 1.1f, 1.3f, m_vBIPoint_34C);
					m_vBITBoundsResult_380.assign(m_vBITBoundsResult_374.begin(), m_vBITBoundsResult_374.end());

					nMrzInfo0 = 1000;
					nMrzInfo1 = 0;
					nMrzInfo2 = 0;
					if (MRZAnalyze::getMrzInfo(a1, nMrzInfo0, nMrzInfo1, nMrzInfo2))
					{
						if (nMrzInfo0 == 1000 || nMrzInfo0 == 1 || (nMrzInfo0 == 0 && nMrzInfo1 == 1))
							m_vBITBoundsResult_374.clear();
					}
				}
			}
			
			resultContainer = rclhelp::findFirstContainer(a1, 86);
			if (resultContainer)
			{
				size = rclhelp::imageSize(a1);
				POSITIONDOCUMENT* positionDoc = resultContainer->u.pTRC_PDM;
				if (rclhelp::deviceTypeReal(a1) != 117670165 || positionDoc && positionDoc->nPD_docType != 2)
				{
					initFullVideoSensorInfo(*positionDoc, size, m_xBITBoundsResult_3AC);
					m_fBIField_3A8 = true;
					if (!m_vBITBoundsResult_380.empty())
						updateFullVideoSensorInfo(m_xBITBoundsResult_3AC, m_vBITBoundsResult_380);
				}
			}
			if (m_vBITBoundsResult_374.empty())
			{
				docIDCheck = m_xBIDocDetect.docCheck();
				docIDCheck->resetDocumentsFilter();
			}
		}
		else
			rclhelp::setResolution(a1, 0);
	}
}

//문서려과를 설정한다.
void BoundsInternal::initDocumentFilter(TBoundsResult & a1)
{
	vector<int> v1;
	DocumentSize::DocumentIDCheck * v2;

	if (a1.nTBR_docFormat == 1000)
		v1.push_back(0);
	else
		v1.push_back(a1.nTBR_docFormat);

	if (a1.nTBR_docFormat == 2)
		v1.push_back(5);

	v2 = m_xBIDocDetect.docCheck();
	v2->setDocumentsFilter(v1);
}

//a2에 a1를 추가하고 초기화한다.
void BoundsInternal::createResultList(TBoundsResult & a1, vector<TBoundsResult> & a2, bool a3)
{
	a1.nTBR_Dpi = 0;
	if (a1.cTBR_PerspectiveTr)
	{
		float width = (float)a1.nTBR_Width;
		float height = (float)a1.nTBR_Height;
		BoundsResult::updateSizeOutByDocFormat(a1.nTBR_docFormat, width, height);
		a1.nTBR_Width = (int)width;
		a1.nTBR_Height = (int)height;
	}
	a2.clear();
	a2.push_back(a1);
	a2[0].xTBR_Center.x = 0;
	a2[0].xTBR_Center.y = 0;
	a2[0].cTBR_PerspectiveTr = a3;
	a2[0].nTBR_Inverse = 0;
	a2[0].cTBR_ResultStatus = 0;
}

//a5에 결과목록을 돌려받는다.
void BoundsInternal::createResultList(vector<DocumentCandidate> & a1, TBoundsResult * a2, float a3, bool a4, vector<TBoundsResult> & a5, int a6)
{
	a5.clear();
	for (uint i = 0; i < a1.size(); i++)
		convert(a1[i], a2, a3, a4, a5, a6);
}

//a1, a2의 구석점과 크기의 차의 최소값을 a3에 넣는다.
void BoundsInternal::checkFullImageDoc(TBoundsResult & a1, tagSIZE & a2, float & a3)
{
	float fAngle;
	float fMin1, fMin2, fMin3, fMin4, fMin5, fMin6, fMin7, fMin8, fMax1, fMax2, fMax3, fMax4, fMax5, fMax6;
	int nTemp1, nTemp2;

	a3 = 0.0f;
	fAngle = fabsf(a1.rTBR_Angle);
	if (fAngle + -90.0f < fAngle)
		fAngle = fAngle + -90.0f;
	if (fAngle <= 2.0)
	{
		nTemp1 = a2.cx - a1.xTBR_LeftBottom.x;
		nTemp2 = a1.xTBR_LeftBottom.x;
		if (nTemp1 < 0)
			nTemp1 = -nTemp1;
		if (nTemp2 < 0)
			nTemp2 = -nTemp2;
		fMin1 = fmin((float)nTemp2, (float)nTemp1);

		nTemp1 = a2.cx - a1.xTBR_LeftTop.x;
		nTemp2 = a1.xTBR_LeftTop.x;
		if (nTemp1 < 0)
			nTemp1 = -nTemp1;
		if (nTemp2 < 0)
			nTemp2 = -nTemp2;
		fMin2 = fmin((float)nTemp2, (float)nTemp1);

		nTemp1 = a2.cx - a1.xTBR_RightBottom.x;
		nTemp2 = a1.xTBR_RightBottom.x;
		if (nTemp1 < 0)
			nTemp1 = -nTemp1;
		if (nTemp2 < 0)
			nTemp2 = -nTemp2;
		fMin3 = fmin((float)nTemp2, (float)nTemp1);

		nTemp1 = a2.cy - a1.xTBR_LeftBottom.y;
		nTemp2 = a1.xTBR_LeftBottom.y;
		if (nTemp1 < 0)
			nTemp1 = -nTemp1;
		if (nTemp2 < 0)
			nTemp2 = -nTemp2;
		fMin4 = fmin((float)nTemp2, (float)nTemp1);

		nTemp1 = a2.cy - a1.xTBR_RightBottom.y;
		nTemp2 = a1.xTBR_RightBottom.y;
		if (nTemp1 < 0)
			nTemp1 = -nTemp1;
		if (nTemp2 < 0)
			nTemp2 = -nTemp2;
		fMin5 = fmin((float)nTemp2, (float)nTemp1);

		fMax1 = fmaxf(fMin1 / a2.cx, fMin2 / a2.cx);

		nTemp1 = a2.cx - a1.xTBR_RightTop.x;
		nTemp2 = a1.xTBR_RightTop.x;
		if (nTemp1 < 0)
			nTemp1 = -nTemp1;
		if (nTemp2 < 0)
			nTemp2 = -nTemp2;
		fMin6 = fmin((float)nTemp2, (float)nTemp1);

		fMax2 = fmaxf(fMin3 / a2.cx, fMin6 / a2.cx);
		fMax3 = fmaxf(fMax1, fMax2);

		nTemp1 = a2.cy - a1.xTBR_LeftTop.y;
		nTemp2 = a1.xTBR_LeftTop.y;
		if (nTemp1 < 0)
			nTemp1 = -nTemp1;
		if (nTemp2 < 0)
			nTemp2 = -nTemp2;
		fMin7 = fmin((float)nTemp2, (float)nTemp1);

		fMax4 = fmaxf(fMin4 / a2.cy, fMin7 / a2.cy);

		nTemp1 = a2.cy - a1.xTBR_RightTop.y;
		nTemp2 = a1.xTBR_RightTop.y;
		if (nTemp1 < 0)
			nTemp1 = -nTemp1;
		if (nTemp2 < 0)
			nTemp2 = -nTemp2;
		fMin8 = fmin((float)nTemp2, (float)nTemp1);

		fMax5 = fmaxf(fMin5 / a2.cy, fMin8 / a2.cy);
		fMax6 = fmaxf(fMax4, fMax5);

		a3 = 1.0f - fmaxf(fMax3, fMax6);
	}
}

void BoundsInternal::generateMask(Size & a1, MatImage & a2, vector<Point2f> & a3, vector<Point2f> & a4)
{
	vector<LineEx> vLine1, vLine2;
	Point point;
	int nTemp1, nTemp2, nX, nY;

	a2.m_vMI_4.create(a1.height, a1.width, 0);
	a2.m_vMI_4.setTo(Scalar(0, 0, 0, 0), noArray());

	vLine1 = BoundsResult::getLines(a3);
	vLine2 = BoundsResult::getLines(a4);

	for (uint i = 0; i < vLine1.size(); i++)
		line(a2.m_vMI_4, vLine1[i].m_xStartPoint, vLine1[i].m_xEndPoint, Scalar(255, 0, 0, 0));

	for (uint i = 0; i < vLine2.size(); i++)
		line(a2.m_vMI_4, vLine2[i].m_xStartPoint, vLine2[i].m_xEndPoint, Scalar(255, 0, 0, 0));

	nX = a1.width - 1;
	nY = a1.height - 1;
	nTemp1 = vLine1[0].m_xStartPoint.x + vLine1[0].m_xStartPoint.x;
	nTemp2 = vLine1[0].m_xStartPoint.y + vLine1[0].m_xStartPoint.y;

	if (a1.width > nTemp1 / 2)
		nX = nTemp1 / 2;
	if (a1.height > nTemp2 / 2)
		nY = nTemp2 / 2;

	point.y = (nY < 0) ? 0 : nY;
	point.x = (nX < 0) ? 0 : nX;

	floodFill(a2.m_vMI_4, point, Scalar(255, 0, 0, 0), 0, Scalar(10, 0, 0, 0), Scalar(10, 0, 0, 0));
}

//a1로부터 화상목록과 dpi, 크기를 얻는다.
int BoundsInternal::getImages(TResultContainerList & a1, ImagesListMat & a2, int & a3, tagSIZE & a4)
{
	int nResult = -20601;
	int nDepth, nwidthStep, nBitCount;
	
	if (a1.nTRCL_Count && rclhelp::checkImagesSize(a1))
	{
		vector<pair<eRPRM_Lights, eBinProcessImg>> vResult = {
			pair<eRPRM_Lights, eBinProcessImg>(RPRM_Lights_18, eBPI_IR),
			pair<eRPRM_Lights, eBinProcessImg>(RPRM_Lights_2000000, eBPI_WHITE_Gray),
			pair<eRPRM_Lights, eBinProcessImg>(RPRM_Lights_6, eBPI_WHITE),
			pair<eRPRM_Lights, eBinProcessImg>(RPRM_Lights_20, eBPI_WHITE_TR),
			pair<eRPRM_Lights, eBinProcessImg>(RPRM_Lights_80, eBPI_UV)
		};

		nResult = 0;

		for (uint i = 0; i < vResult.size(); i++)
		{
			RawImageContainerR *imageContainer = (RawImageContainerR *)regula::light::findImageUsingLightGroup(a1, vResult[i].first, false, false, false);
			if (imageContainer && imageContainer->pxRIC_bmi)
			{
				if (imageContainer->pxRIC_bmi->bmiHeader.biBitCount >= 8)
				{
					a3 = imageContainer->pxRIC_bmi->bmiHeader.biXPelsPerMeter;
					a4.cx = imageContainer->pxRIC_bmi->bmiHeader.biWidth;
					a4.cy = imageContainer->pxRIC_bmi->bmiHeader.biHeight;
					nDepth = imageContainer->depth();
					nBitCount = imageContainer->pxRIC_bmi->bmiHeader.biBitCount;
					nwidthStep = imageContainer->widthStep();
					Mat mat(a4.cy, a4.cx, (nBitCount - 8) | nDepth & 7, imageContainer->pRIC_data, nwidthStep);
					ImageExMat * matRet = a2.create(vResult[i].second, eBP_OFF);
					matRet->m_xImageExMat = mat;
					nResult = 1;
				}
			}
		}

		if (a3 < 3000)
			a3 = 0;

		nResult = ~nResult & 1;
	}

	return nResult;
}

void BoundsInternal::filterByExtParameters(Json::Value & a1, vector<DocumentCandidate> & a2, float a3)
{
	Json::Value vConfig(0), vMember(0);
	float fminDPI, fAngle, fImageSize;
	int nDocType;

	vMember = a1["processParam"].get("minDPI", Json::Value(0));
	fminDPI = vMember.asFloat();
	vMember = a1["processParam"].get("perspectiveAngle", Json::Value(0));
	fAngle = vMember.asFloat();

	if (fminDPI == 0.0 && fAngle == 0.0)
		return;
	else
	{
		a2.clear();
		for (uint i = 0; i < a2.size(); i++)
		{
			nDocType = a2[i].m_nDocType - 3;
			if (a2[i].m_nDocType != 3)
				nDocType = a2[i].m_nDocType;
			fImageSize = (float)docformatinfo::getPpmForImageSize(a2[i].m_xDocSize, (CDocFormat)nDocType);

			if (fImageSize >= fminDPI)
			{
				if (fAngle == 0.0 || fAngle >= a2[i].m_rIntAngle)
				{
					DocumentCandidate docCan(a2[i]);
					a2.push_back(docCan);
				}
			}
		}
	}
}

//문서위치와 크기로부터 a3을 초기화한다.
void BoundsInternal::initFullVideoSensorInfo(POSITIONDOCUMENT & a1, tagSIZE & a2, TBoundsResult & a3)
{
	memset(&a3, 0, sizeof(TBoundsResult));
	a3.rTBR_Angle = a1.rPD_ugol;
	a3.nTBR_docFormat = a1.nPD_docType;

	float fX = (a1.xnPD_corners[0].x + a1.xnPD_corners[1].x + a1.xnPD_corners[2].x + a1.xnPD_corners[3].x) * 0.25f * a2.cx;
	float fY = (a1.xnPD_corners[0].y + a1.xnPD_corners[1].y + a1.xnPD_corners[2].y + a1.xnPD_corners[3].y) * 0.25f * a2.cy;
	a3.xTBR_Center.x = (int)fX;
	a3.xTBR_Center.y = (int)fY;
	a3.xTBR_LeftTop.x = (int)(a1.xnPD_corners[0].x * a2.cx);
	a3.xTBR_LeftTop.y = (int)(a1.xnPD_corners[0].y * a2.cy);
	a3.xTBR_LeftBottom.x = (int)(a1.xnPD_corners[1].x * a2.cx);
	a3.xTBR_LeftBottom.y = (int)(a1.xnPD_corners[1].y * a2.cy);
	a3.xTBR_RightTop.x = (int)(a1.xnPD_corners[3].x * a2.cx);
	a3.xTBR_RightTop.y = (int)(a1.xnPD_corners[3].y * a2.cy);
	a3.xTBR_RightBottom.x = (int)(a1.xnPD_corners[2].x * a2.cx);
	a3.xTBR_RightBottom.y = (int)(a1.xnPD_corners[2].y * a2.cy);

	double fWidth = sqrt((double)((a1.xnPD_corners[1].y - a1.xnPD_corners[2].y) * a2.cy) * ((a1.xnPD_corners[1].y - a1.xnPD_corners[2].y) * a2.cy) +
		(double)((a1.xnPD_corners[1].x - a1.xnPD_corners[2].x) * a2.cx) * ((a1.xnPD_corners[1].x - a1.xnPD_corners[2].x) * a2.cx));
	double fHeight = sqrt((double)((a1.xnPD_corners[0].y - a1.xnPD_corners[1].y) * a2.cy) * ((a1.xnPD_corners[0].y - a1.xnPD_corners[1].y) * a2.cy) +
		(double)((a1.xnPD_corners[0].x - a1.xnPD_corners[1].x) * a2.cx) * ((a1.xnPD_corners[0].x - a1.xnPD_corners[1].x) * a2.cx));
	a3.nTBR_Width = (int)fWidth;
	a3.nTBR_Height = (int)fHeight;
}

//a2에 의하여 a1를 갱신한다.
int BoundsInternal::updateFullVideoSensorInfo(TBoundsResult & a1, vector<TBoundsResult> & a2)
{
	double fSqu1, fSqu2, fSqu3, fSqu4;
	float fAngle;
	tagPOINT tempPoint;

	if (a2.empty())
		return 1;

	vector<Point> vCorner1 = bounds::boundsresult::getCorners(a1);
	vector<Point> vCorner2 = bounds::boundsresult::getCorners(a2[0]);

	fSqu1 = sqrt((double)(vCorner1[1].x - vCorner2[1].x) * (vCorner1[1].x - vCorner2[1].x) +
		(double)(vCorner1[1].y - vCorner2[1].y) * (vCorner1[1].y - vCorner2[1].y));

	fSqu2 = sqrt((double)(vCorner1[2].x - vCorner2[2].x) * (vCorner1[2].x - vCorner2[2].x) +
		(double)(vCorner1[2].y - vCorner2[2].y) * (vCorner1[2].y - vCorner2[2].y));

	if (fSqu1 < fSqu2)
		fSqu1 = fSqu2;

	fSqu3 = sqrt((double)(vCorner1[3].x - vCorner2[1].x) * (vCorner1[3].x - vCorner2[1].x) +
		(double)(vCorner1[3].y - vCorner2[1].y) * (vCorner1[3].y - vCorner2[1].y));

	fSqu4 = sqrt((double)(vCorner1[0].x - vCorner2[2].x) * (vCorner1[0].x - vCorner2[2].x) +
		(double)(vCorner1[0].y - vCorner2[2].y) * (vCorner1[0].y - vCorner2[2].y));

	if (fSqu3 < fSqu4)
		fSqu3 = fSqu4;

	if (fSqu3 < fSqu1)
	{
		fAngle = 180.0;
		if (a1.rTBR_Angle > 0.0)
			fAngle = -180.0;

		tempPoint = a1.xTBR_LeftTop;
		a1.xTBR_LeftTop = a1.xTBR_RightBottom;
		a1.xTBR_RightBottom = tempPoint;
		tempPoint = a1.xTBR_LeftBottom;
		a1.xTBR_LeftBottom = a1.xTBR_RightTop;
		a1.xTBR_RightTop = tempPoint;
		a1.rTBR_Angle += fAngle;
	}

	return 0;
}

//a1의 Result값들을 a2에 의하여 갱신한다.
void BoundsInternal::updateResultsParam(vector<TBoundsResult> & a1, tagSIZE & a2)
{
	int nSqu = a2.cx * a2.cy;

	for (uint i = 0; i < a1.size(); i++)
	{
		a1[i].cTBR_ObjArea = (uchar)(((float)(a1[i].nTBR_Height * a1[i].nTBR_Width) * 100.0f) / nSqu);

		if (!a1[i].xTBR_Center.x)
		{
			a1[i].xTBR_Center.x = (a1[i].xTBR_RightBottom.x + a1[i].xTBR_RightTop.x + a1[i].xTBR_LeftTop.x + a1[i].xTBR_LeftBottom.x) / 4;
			a1[i].xTBR_Center.y = (a1[i].xTBR_RightBottom.y + a1[i].xTBR_RightTop.y + a1[i].xTBR_LeftTop.y + a1[i].xTBR_LeftBottom.y) / 4;
		}
	}
}

//docCandidate로부터 a5에 BoundsResult값을 돌려받는다.
void BoundsInternal::convert(DocumentCandidate & a1, TBoundsResult * a2, float a3, bool a4, vector<TBoundsResult> & a5, int a6)
{
	DocumentCandidate docCan(a1);
	TBoundsResult boundsResult, boundsResult1, boundsResult2;
	vector<Point> vCorner1, vCorner2;
	float fTemp1, fTemp2, fTemp3, fTemp4, fAngle;
	float fTemp;
	Point2f tempPoint;

	if (a1.m_bMrzContain)
	{
		if (a2 && a1.m_nDocType != 5 && a2->nTBR_docFormat != 1000)
			a1.m_nDocType = a2->nTBR_docFormat;
	}

	if (a6)
		BoundsResult::updateSizeOutByDocFormat(a1);

	if (docCan.m_nDocType == 5 && docCan.m_xDocSize.width > docCan.m_xDocSize.height)
	{
		fTemp = docCan.m_xDocSize.width;
		docCan.m_xDocSize.width = docCan.m_xDocSize.height;
		docCan.m_xDocSize.height = fTemp;
		docCan.m_vCornerDC.insert(docCan.m_vCornerDC.begin(), docCan.m_vCornerDC.back());
		docCan.m_vCornerDC.pop_back();
	}

	memset(&boundsResult, 0, sizeof(TBoundsResult));
	bounds::boundsresult::convert(docCan, boundsResult);
	bounds::boundsresult::scale(boundsResult, boundsResult, 1.0f / a3, 0.0f);

	if (a2)
	{
		vCorner1 = bounds::boundsresult::getCorners(boundsResult);
		vCorner2 = bounds::boundsresult::getCorners(*a2);

		fTemp1 = (float)sqrt((vCorner1[1].x - vCorner2[1].x) * (vCorner1[1].x - vCorner2[1].x) +
			(vCorner1[1].y - vCorner2[1].y) * (vCorner1[1].y - vCorner2[1].y));
		fTemp2 = (float)sqrt((vCorner1[2].x - vCorner2[2].x) * (vCorner1[2].x - vCorner2[2].x) +
			(vCorner1[2].y - vCorner2[2].y) * (vCorner1[2].y - vCorner2[2].y));

		if (fTemp1 < fTemp2)
			fTemp1 = fTemp2;

		fTemp3 = (float)sqrt((vCorner1[3].x - vCorner2[1].x) * (vCorner1[3].x - vCorner2[1].x) +
			(vCorner1[3].y - vCorner2[1].y) * (vCorner1[3].y - vCorner2[1].y));
		fTemp4 = (float)sqrt((vCorner1[0].x - vCorner2[2].x) * (vCorner1[0].x - vCorner2[2].x) +
			(vCorner1[0].y - vCorner2[2].y) * (vCorner1[0].y - vCorner2[2].y));

		if (fTemp3 < fTemp4)
			fTemp3 = fTemp4;

		if (fTemp3 < fTemp1)
		{
			fAngle = -180.0f;
			if (a1.m_rAngleDC < 0.0f)
				fAngle = 180.0f;
			a1.m_rAngleDC += fAngle;

			tempPoint = a1.m_vCornerDC[0];
			a1.m_vCornerDC[0] = a1.m_vCornerDC[2];
			a1.m_vCornerDC[2] = tempPoint;
			tempPoint = a1.m_vCornerDC[1];
			a1.m_vCornerDC[1] = a1.m_vCornerDC[3];
			a1.m_vCornerDC[3] = tempPoint;
		}
	}

	if (a1.m_nDocType == 5)
	{
		fAngle = a1.m_rAngleDC - 90.0f;
		if (fAngle < -180.0f)
			fAngle += 360.0f;
		a1.m_rAngleDC = fAngle;
		if (!BoundsResult::splitID3x2(a1, boundsResult1, boundsResult2))
		{
			if (a2)
				boundsResult1.cTBR_ResultStatus |= 2;
			bounds::boundsresult::scale(boundsResult1, boundsResult1, 1.0f / a3, 0.0f);
			bounds::boundsresult::scale(boundsResult2, boundsResult2, 1.0f / a3, 0.0f);
			a5.push_back(boundsResult1);
			a5.push_back(boundsResult2);
		}
	}
	else
	{
		bounds::boundsresult::convert(a1, boundsResult);
		bounds::boundsresult::scale(boundsResult, boundsResult, 1.0f / a3, 0.0f);
		a5.push_back(boundsResult);
	}

	for (uint i = 0; i < a5.size(); i++)
		a5[i].cTBR_PerspectiveTr = a4;
}

namespace BoundsNS {
	namespace Error {
		// nResult = 0, 1, -20699 ~ -20600까지 값일때 그대로 돌려준다.
		int checkCodeError(int nResult)
		{
			if (nResult == 0 || nResult == 1 || (nResult >= -20699 && nResult <= -20600))
				return nResult;
			return -20600;
		}
	}
}

namespace bounds
{
	/*---------------Start FaceInfo---------------*/
	FaceInfo::FaceInfo()
	{
		memset(&m_xFIRect, 0, sizeof(tagRECT));
		memset(&m_xFIkRect, 0, sizeof(tagRECT));
		m_xFICenter = Point2f(0.0, 0.0);
		m_xFIkCenter = Point2f(0.0, 0.0);
		clear();
	}

	void FaceInfo::clear()
	{
		m_bFIClear = false;
	}

	void FaceInfo::setK(float k)
	{
		m_xFIkCenter.x = m_xFICenter.x * k;
		m_xFIkCenter.y = m_xFICenter.y * k;
		m_xFIkRect.left = (int)(m_xFIRect.left * k);
		m_xFIkRect.bottom = (int)(m_xFIRect.bottom * k);
		m_xFIkRect.right = (int)(m_xFIRect.right * k);
		m_xFIkRect.top = (int)(m_xFIRect.top * k);
	}

	void FaceInfo::setRect(tagRECT rect)
	{
		m_bFIClear = true;
		m_xFIRect = rect;
		m_xFICenter.x = (float)(rect.left + rect.right) / 2;
		m_xFICenter.y = (float)(rect.top + rect.bottom) / 2;
	}
	/*-------------------End FaceInfo---------------------*/

	float maxDistanceMrz2(vector<Point2f> & a1, vector<Point2f> & a2)
	{
		double fTemp1, fTemp2, fTemp3, fTemp4, fTemp5, fTemp6;
		float fTmp, fResult;

		if (a1.size() == 2 && a2.size() == 2)
		{
			fTemp1 = sqrt((double)(a1[0].x - a2[0].x) * (a1[0].x - a2[0].x) + (double)(a1[0].y - a2[0].y) * (a1[0].y - a2[0].y));
			fTemp2 = sqrt((double)(a1[0].x - a2[1].x) * (a1[0].x - a2[1].x) + (double)(a1[0].y - a2[1].y) * (a1[0].y - a2[1].y));

			if (fTemp1 > fTemp2)
				reverse(a2.begin(), a2.end());

			fTemp1 = sqrt((double)(a1[0].x - a1[1].x) * (a1[0].x - a1[1].x) + (double)(a1[0].y - a1[1].y) * (a1[0].y - a1[1].y));
			fTemp2 = sqrt((double)(a1[0].x - a2[0].x - a1[1].x + a2[1].x) * (a1[0].x - a2[0].x - a1[1].x + a2[1].x) +
				(double)(a1[0].y - a2[0].y - a1[1].y + a2[1].y) * (a1[0].y - a2[0].y - a1[1].y + a2[1].y));
			fTemp3 = sqrt((double)(a1[0].x - a2[0].x) * (a1[0].x - a2[0].x) + (double)(a1[0].y - a2[0].y) * (a1[0].y - a2[0].y));
			fTemp4 = sqrt((double)(a2[0].x - a1[1].x) * (a2[0].x - a1[1].x) + (double)(a2[0].y - a1[1].y) * (a2[0].y - a1[1].y));

			if (fTemp1 - fTemp4 <= 0.0)
				fTmp = 0.0;
			else
				fTmp = (float)((fTemp1 - fTemp4) / fTemp1);

			fTemp5 = sqrt((double)(a1[1].x - a2[1].x) * (a1[1].x - a2[1].x) + (double)(a1[1].y - a2[1].y) * (a1[1].y - a2[1].y));
			fTemp6 = sqrt((double)(a2[1].x - a1[0].x) * (a2[1].x - a1[0].x) + (double)(a2[1].y - a1[0].y) * (a2[1].y - a1[0].y));

			if (fTemp1 - fTemp6 > 0.0)
				fTmp = (float)((fTemp1 - fTemp6) / fTemp1);
			fTmp = MAX(fTmp, 0.0f);

			if (fTemp3 < fTemp5)
				fTemp3 = fTemp5;
			fResult = (float)fTemp3;
			
			if (fTmp > 0.02)
				fTemp3 *= 3.0;

			if (fTemp2 / fTemp1 > 0.00999999978)
				fResult = (float)fTemp3;
		}

		return fResult;
	}

	namespace maskprocess {
		//a1성분을 갱신하여 a3에 넣는다.
		bool updateRect(vector<Point2f> & a1, float a2, vector<Point2f> & a3)
		{
			float fTemp1, fTemp2, fTemp3;

			if (a1.size() != 4)
				return true;

			a3.resize(4);

			fTemp1 = (a1[0].x + a1[2].x) * 0.5f;
			fTemp2 = (a1[0].y + a1[2].y) * 0.5f;
			fTemp3 = (a1[1].x + a1[3].x) * 0.5f;
			a3.push_back(Point2f(fTemp1 - (a2 + 1.0f) * (fTemp1 - a1[0].x), fTemp2 - (a2 + 1.0f) * (fTemp2 - a1[0].y)));
			a3.push_back(Point2f(fTemp3 - (a2 + 1.0f) * (fTemp3 - a1[1].x), fTemp2 - (a2 + 1.0f) * (fTemp2 - a1[1].y)));
			a3.push_back(Point2f(fTemp1 - (a2 + 1.0f) * (fTemp1 - a1[2].x), fTemp2 - (a2 + 1.0f) * (fTemp2 - a1[2].y)));
			a3.push_back(Point2f(fTemp3 - (a2 + 1.0f) * (fTemp3 - a1[3].x), fTemp2 - (a2 + 1.0f) * (fTemp2 - a1[3].y)));

			return false;
		}
	}

	namespace detectX2 {
		//해당한 조건에 맞는 DocumentCandidate들의 첨수를 a3에 넣는다.
		void filterCandidatesByPPM(DocumentCandidateList & a1, vector<int> & a2, vector<int> & a3, CDocFormat a4, int a5)
		{
			Size2f size;
			a3.reserve(a2.size());

			for (uint i = 0; i < a2.size(); i++)
			{
				size = a1.m_vDocCanList[a2[i]].m_xDocSize;

				if (docformatinfo::getPpmForImageSize(size, a4) >= a5)
					a3.push_back(a2[i]);
			}
		}

		bool sub_427138(vector<Point2f> & a1, vector<Point2f> & a2)
		{
			Point2f point;
			
			point.x = (a1[0].x + a1[1].x + a1[2].x + a1[3].x) * 0.25f;
			point.y = (a1[0].y + a1[1].y + a1[2].y + a1[3].y) * 0.25f;

			if (pointPolygonTest(a2, point, 0) <= 0.0)
			{
				point.x = (a2[0].x + a2[1].x + a2[2].x + a2[3].x) * 0.25f;
				point.y = (a2[0].y + a2[1].y + a2[2].y + a2[3].y) * 0.25f;
				if (pointPolygonTest(a1, point, 0) > 0.0)
					return true;
			}
			else
				return true;

			return false;
		}

		//해당한 조건에 맞는 DocumentCandidate들의 첨수를 a3에 넣는다.
		void find2CandidateNonIntersect(DocumentCandidateList & a1, vector<int> & a2, vector<pair<int, int>> & a3)
		{
			DocumentCandidate docCandidate1, docCandidate2;
			float fSqu1, fSqu2;

			for (uint i = 0; i < a2.size(); i++)
			{
				docCandidate1 = a1.m_vDocCanList[a2[i]];
				if (docCandidate1.m_rIntAngle < 5)
				{
					for (uint j = i + 1; j < a2.size(); j++)
					{
						docCandidate2 = a1.m_vDocCanList[a2[j]];
						fSqu1 = docCandidate1.m_xDocSize.width * docCandidate1.m_xDocSize.height;
						fSqu2 = docCandidate2.m_xDocSize.width * docCandidate2.m_xDocSize.height;
						if (docCandidate2.m_rIntAngle < 5 && fabsf(fSqu1 - fSqu2) / fSqu1 <= 0.2 &&
							!sub_427138(docCandidate1.m_vCornerDC, docCandidate2.m_vCornerDC))
						{
							a3.push_back(pair<int, int>(i, j));
						}
					}
				}
			}
		}

		//해당한 조건에 맞는 DocumentCandidate들의 첨수를 a3에 넣는다.
		void findCandidatesWithCommonSide(DocumentCandidateList & a1, vector<int> & a2, vector<pair<int, int>> & a3)
		{
			DocumentCandidate docCandidate1, docCandidate2;
			vector<int> vDoc;
			float fSqu1, fSqu2;
			int nCount;

			for (uint i = 0; i < a2.size(); i++)
			{
				for (uint j = 0; j < a2.size(); j++)
				{
					docCandidate1 = a1.m_vDocCanList[a2[i]];
					docCandidate2 = a1.m_vDocCanList[a2[j]];
					vDoc.assign(docCandidate1.m_vCornerDC.size(), -1);
					nCount = 0;

					uint k, m;
					for (k = 0; k < docCandidate1.m_vCornerDC.size(); k++)
					{
						for (m = 0; m < docCandidate2.m_vCornerDC.size(); m++)
						{
							fSqu1 = docCandidate1.m_vCornerDC[k].x - docCandidate2.m_vCornerDC[m].x;
							fSqu2 = docCandidate2.m_vCornerDC[k].y - docCandidate2.m_vCornerDC[m].y;
							if (sqrt(fSqu1 * fSqu1 + fSqu2 * fSqu2) < docCandidate1.m_xDocSize.width * 0.05)
							{
								if (nCount > 1 || vDoc[k] != -1)
									break;

								nCount++;
								vDoc[k] = m;
							}
						}

						if (m < docCandidate1.m_vCornerDC.size()) break;
					}

					if (k < docCandidate1.m_vCornerDC.size()) continue;

					if (nCount >= 2 && !sub_427138(docCandidate1.m_vCornerDC, docCandidate2.m_vCornerDC))
						a3.push_back(pair<int, int>(i, j));
				}
			}
		}
	}

	namespace byrecognize
	{
		void detectByRecognize(RclHolder & a1, DocumentCandidateList & a2, vector<int> & a3, RclHolder & a4, DocumentDetect & a5, vector<TBoundsResult> & a6, vector<TBoundsResult> & a7, vector<Point2f> & a8, int a9, bounds::byrecognize::series::BoundsState & a10, vector<eBoundsByRecognizeMode> & a11, tagSIZE & a12, tagRECT & a13, float a14)
		{
			float fTemp, fTemp1;
			int nDocFormat, nTemp, nTemp1;
			vector<int> vVitual, vInt1, vCheckCan, vInt2;
			vector<pair<int, int>> vPair;
			RclHolder rclHolder2;
			Json::Value *pValue = 0, vTemp(0);
			tagSIZE size;
			DocumentSize::DocumentIDCheck docIdCheck;
			TBoundsResult boundsResult;

			fTemp = (a9 * 0.7f > 3500.0f) ? a9 * 0.7f : 3500.0f;
			nDocFormat = rclhelp::documentFormatFromMRZOld(a1.m_xTRCL);
			if (nDocFormat == -1)
				nDocFormat = rclhelp::documentFormat(a1.m_xTRCL);

			a10.m_nBoundsState_field_28 = 0;

			vector<int> v_15c;
			a2.splitByViltual(a3, vVitual, v_15c);

			bool bUnknown = false;
			for (uint i = 0; i < a11.size(); i++)
			{
				RclHolder rclholder1;
				switch (a11[i])
				{
				case 1:
				{
					rclholder1.addCopy(a1.getRcList(1));
					common::images::CropImage(rclholder1.m_xTRCL, a13);
					rclHolder2.addNoCopy(a1.getRcList());
					rclHolder2.remove(1);
					rclHolder2.addNoCopy(rclholder1.m_xTRCL);
					vector<TResultContainer*> vResult = a1.getRcList(51);

					if (!vResult.empty())
						pValue = vResult[0]->u.pTRC_JV;
					if (!rclHolder2.hasRc(98))
					{
						if (pValue)
						{
							(*pValue)["recpassParam"]["cropByRectPosition"] = Json::Value(true);
							(*pValue)["recpassParam"]["lockImageProportion"] = Json::Value(true);
							if ((*pValue)["processParam"]["customParams"]["boundsParam"].isMember("fullMode"))
							{
								Json::ValueIteratorBase iter = (*pValue)["processParam"]["customParams"]["boundsParam"]["fullMode"].begin();
								Json::ValueIteratorBase end = (*pValue)["processParam"]["customParams"]["boundsParam"]["fullMode"].end();

								while (iter != end)
								{
									vInt1.push_back(iter.deref().asInt());
									iter.increment();
								}
							}
						}

						if (!vInt1.empty())
						{
							RclHolder  rclHolder3;
							rclhelp::docinfo::addMainDocumentInfo(rclHolder2, rclHolder3, vInt1);
						}
					}

					size = rclhelp::imageSize(rclHolder2.m_xTRCL);
					DocumentCandidate docCan;
					BoundsResult::initResultAutoWH(size, 1000, docCan);
					a2.m_vDocCanList.push_back(docCan);
					vInt1.clear();
					vInt1.push_back(a2.m_vDocCanList.size() - 1);
					bounds::byrecognize::checkCandidate(a2, rclHolder2.m_xTRCL, vInt1, a7, 1.0, vCheckCan, a10.m_xBoundsState_field_10);
					if (pValue)
					{
						(*pValue)["recpassParam"]["cropByRectPosition"] = Json::Value(false);
						(*pValue)["recpassParam"]["lockImageProportion"] = Json::Value(false);
					}
					break;
				}
				case 2:
					vInt1.clear();
					if (nDocFormat)
					{
						initByDefault(docIdCheck);
						vInt1.push_back(5);
						docIdCheck.setDocumentsFilter(vInt1);
						DocumentCandidate docCan;
						BoundsResult::initResultAutoWH(a12, 5, docCan);
						nTemp = 1000;
						fTemp1 = 0;
						docIdCheck.isIDByProportions(docCan.m_xDocSize.width, docCan.m_xDocSize.height, fTemp1, nTemp, 0);

						if (nTemp == 5 && fTemp1 > 0.9)
							a2.m_vDocCanList.push_back(docCan);

						vInt1.clear();
						vInt1.push_back(a2.m_vDocCanList.size() - 1);
						bounds::byrecognize::checkId3x2Split2(a2, a1.m_xTRCL, vInt1, 1.0, a8, vCheckCan, a10.m_xBoundsState_field_10);
					}
					break;
				case 3:
				case 4:
					if (!a3.empty())
					{
						vInt1.clear();
						if (a11[i] == 4)
						{
							uint j;

							for (j = 0; j < vVitual.size(); j++)
							{
								if ((a2.m_vDocCanList[vVitual[j]].m_xDocSize.width * a2.m_vDocCanList[vVitual[j]].m_xDocSize.height) /
									(a12.cx * a14 * a12.cy * a14) > 0.6)
									break;
							}

							if (j == vVitual.size() || vVitual[j] == -1)
								break;

							vInt1.push_back(vVitual[j]);
						}
						else
						{
							vInt1.push_back(a3[0]);
						}


						if (bounds::byrecognize::checkCandidate(a2, a1.m_xTRCL, vInt1, a7, a14, vCheckCan, a10.m_xBoundsState_field_10) == 1)
							bUnknown = true;
					}
					break;

				case 5:
				case 6:
				case 7:
					if (nDocFormat)
					{
						nTemp = 0;
						if (a11[i] != 7)
							nTemp = 2;
						vInt1.clear();
						bounds::detectX2::filterCandidatesByPPM(a2, a3, vInt1, (CDocFormat)nTemp, (int)(fTemp * a14));

						if (a11[i] == 6)
						{
							a2.filterByViltual(0, vInt1, vInt2);
							vInt1.assign(vInt2.begin(), vInt2.end());
						}

						vInt2.clear();

						if (a11[i] == 7)
							bounds::detectX2::find2CandidateNonIntersect(a2, vInt1, vPair);
						else
							bounds::detectX2::findCandidatesWithCommonSide(a2, vInt1, vPair);

						if (!vPair.empty())
						{
							if (bounds::byrecognize::checkPagePair(a2, a1.m_xTRCL, vPair, a7, a14, 50, (CDocFormat)nTemp, vCheckCan, a10.m_xBoundsState_field_10, vInt2))
								bUnknown = true;
						}
					}
					break;
				case 9:
				case 10://0xA
					if (nDocFormat)
					{
						vInt1.clear();
						vInt2.clear();

						if (a9)
							a2.filterByDocType(5, a3, vInt1);

						bounds::detectX2::filterCandidatesByPPM(a2, vInt1, vInt2, (CDocFormat)5, (int)(fTemp * a14));
						vInt2.clear();
						bounds::byrecognize::checkId3x2Split2(a2, a1.m_xTRCL, vInt2, a14, a8, vCheckCan, a10.m_xBoundsState_field_10);
					}
					break;

				case 11://0xB
					if (!a3.empty())
					{
						nTemp = 6;
						nTemp1 = 6;
						int nSize = (int)vVitual.size();
						int nSize1 = (int)v_15c.size();
						if (nSize < 6)
							nTemp = nSize;
						if (nSize1 < 6)
							nTemp1 = nSize1;

						if (nTemp + nTemp1 < 12)
						{
							nTemp = 12 - nTemp1;
							if (nSize < nTemp)
								nTemp = nSize;
							if (nTemp + nTemp1 < 12)
							{
								nTemp1 = 12 - nTemp;
								if (nSize1 < nTemp1)
									nTemp1 = nSize1;
							}
						}

						int nCheckResult = 2;
						if (nTemp)
						{
							vector<int> v_bp108(vVitual.begin(), vVitual.begin() + nTemp);
							int n_bp228 = -1;
							a2.findBestByLines(vVitual, n_bp228);

							if (n_bp228 != -1)
							{
								uint j;
								for (j = 0; j < v_bp108.size(); j++)
								{
									if (v_bp108[j] == n_bp228) break;
								}

								if (j == v_bp108.size())
								{
									v_bp108.insert(v_bp108.begin(), n_bp228);
								}
							}
							nCheckResult = bounds::byrecognize::checkCandidate(a2, a1.m_xTRCL, v_bp108, a7, a14, vCheckCan, a10.m_xBoundsState_field_10);
						}

						if (nCheckResult == 2 && nTemp1)
						{
							vector<int> v_bp108(v_15c.begin(), v_15c.begin() + nTemp1);
							nCheckResult = bounds::byrecognize::checkCandidate(a2, a1.m_xTRCL, v_bp108, a7, a14, vCheckCan, a10.m_xBoundsState_field_10);
						}

						if (nCheckResult == 1)
						{
							//Log("BoundsInternal::detectDoc FOCUS ERROR while check basic");
							bUnknown = true;
						}

						break;
					}
					break;

				case 12:
					if (!a6.empty() && !a10.m_nBoundsState_field_29)
					{
						bounds::byrecognize::checkCandidateByMRZ(a6[0], a1.m_xTRCL, a10.m_xBoundsState_field_10);
						a10.m_nBoundsState_field_29 = true;
					}
					break;
				}

				if (!a10.m_xBoundsState_field_10.empty())
				{
					if (vCheckCan.size())
					{
						for (uint j = 0; j < vCheckCan.size(); j++)
						{
							if (a2.m_vDocCanList[vCheckCan[j]].m_bMrzContain)
								a10.m_nBoundsState_field_29 = true;
							bounds::boundsresult::convert(a2.m_vDocCanList[vCheckCan[j]], boundsResult);
							a10.m_vBoundsState_field_4.push_back(boundsResult);
						}

						if (!a10.m_nBoundsState_field_24)
							a10.m_nBoundsState_field_24 = a11[i];
					}
				}

				if (a10.m_vBoundsState_field_4.empty() || !a6.empty() && !a10.m_nBoundsState_field_29)
				{
					if(!bUnknown)
						continue;
				}
				break;
			}

			if (!a10.m_xBoundsState_field_10.empty())
			{
				rclhelp::page::updatePageIndexByDocId(a10.m_xBoundsState_field_10);
				if (a10.m_nBoundsState_field_24)
					a10.m_nBoundsState_field_0 = a10.m_nBoundsState_field_24;

				a10.m_nBoundsState_field_28 = 1;
			}
		}


		int checkPagePair(DocumentCandidateList & a1, TResultContainerList & a2, vector<pair<int, int>> & a3, vector<TBoundsResult> & a4, float a5, int a6, CDocFormat a7, vector<int> & a8, RclHolder & a9, vector<int> & a10)
		{
			RclHolder rclHolder1(a2, 1), rclHolder2;
			vector<int> vInt1, vInt2, vInt3;
			int nResult = 1;
			uint i, j, k, m, l;

			a9.clear();

			for (i = 0; i < a3.size(); i++)
			{
				if (i == a3.size() - 1 && !vInt1.empty())
				{
					common::unit(a10, vInt1);
					i = -1;
					a9.clear();
					a8.clear();
					vInt1.clear();
					vInt3.clear();
					continue;
				}

				for (j = 0; j < a10.size(); j++)
				{
					if (a10[j] == a3[i].first)
						break;
				}

				if (j == a10.size())
				{
					for (k = 0; k < a10.size(); k++)
					{
						if (a10[k] == a3[i].second)
							break;
					}

					if (k == a10.size())
					{
						if (vInt1.empty())
							break;

						for (m = 0; m < vInt1.size(); m++)
						{
							if (vInt1[m] == a3[i].first)
								break;
						}

						if (m != vInt1.size())
							break;

						for (l = 0; l < vInt1.size(); l++)
						{
							if (vInt1[l] == a3[i].second)
								break;
						}

						if (l != vInt1.size())
							break;
					}
				}
			}

			if (a8.size() == 2)
				nResult = 0;
			else
			{
				if (!vInt2.empty())
				{
					a9.clear();
					a8.clear();
					a9.addCopy(rclHolder2.m_xTRCL);
					a8.push_back(vInt2[0]);
				}

				nResult = 0;
			}

			for (i = 0; i < a1.m_vDocCanList.size(); i++)
			{
				if (a7 != 3)
					rclHolder2.addNewCopy<void>(95, (void*)a7, 0);
				rclHolder2.addNoCopy(rclHolder1.getRcList(1));
				rclHolder2.addNoCopy(rclHolder1.getRcList(51));

				if (a1.m_vDocCanList[i].m_rDCField_44)
				{
					rclHolder2.addNoCopy(rclHolder1.getRcList(3));
				}
			}

			return nResult;
		}

		void checkId3x2Split2(DocumentCandidateList & a1, TResultContainerList & a2, vector<int> & a3, float a4, vector<Point2f> & a5, vector<int> & a6, RclHolder & a7)
		{
			RclHolder rclHolder1(a2, 1), rclHolder2, rclHolder3;
			vector<TBoundsResult> vBoundsResult;
			vector<Point2f> vPoint;
			vector<int> vInt, vInt1;
			int nResult, nResult1, nResult2;
			bool nFlag;

			a7.clear();
			a6.clear();

			for (uint i = 0; i < a3.size(); i++)
			{
				BoundsInternal::convert(a1.m_vDocCanList[a3[i]], 0, a4, 1, vBoundsResult, 0);

				if (vBoundsResult.size() != 2)
					continue;

				if (!a5.empty())
				{
					for (uint j = 0; j < vBoundsResult.size(); j++)
					{
						vPoint = bounds::boundsresult::getCorners2f(vBoundsResult[j]);
						if (bounds::result::isAllPointsInside(a5, vPoint))
							vBoundsResult[j].cTBR_ResultStatus |= 2;
					}

					if (vBoundsResult[1].cTBR_ResultStatus & 2)
						reverse(vBoundsResult.begin(), vBoundsResult.end());
				}

				nResult2 = 0;
				nFlag = 0;
				vInt.clear();
				for (uint j = 0; j < vBoundsResult.size(); j++)
				{
					rclHolder2.addNewCopy<void>(95, (void *)2, 0);
					rclHolder2.addNoCopy(rclHolder1.getRcList(1));
					rclHolder2.addNoCopy(rclHolder1.getRcList(51));

					if (vBoundsResult[j].cTBR_ResultStatus & 2)
					{
						rclHolder2.addNoCopy(rclHolder1.getRcList(3));
						nFlag = 1;
					}

					rclHolder2.addNewCopy<TBoundsResult>(85, &vBoundsResult[j], 0)->nTRC_page_idx = j;

					if (vInt.empty())
					{
						rclHolder2.addNoCopy(rclHolder1.getRcList(98));
					}
					else
					{
						rclhelp::docdesc::getPairPageDocList(vInt[0], vInt1);
						if (vInt.empty())
						{
							nResult1 = 7;
							nResult2 = 1;
						}
						else
						{
							rclhelp::docinfo::addMainDocumentInfo(rclHolder2, rclHolder2, vInt1);
							nResult1 = 0;
						}
					}

					nResult = bounds::byrecognize::checkCandidateByRecognize(rclHolder2, rclHolder3);

					if (nResult)
						a7.clear();
					else
					{
						vInt.push_back(rclhelp::documentIDRecogn(rclHolder3.m_xTRCL));
						a7.addCopy(rclHolder3.m_xTRCL);
					}

					if (!a7.empty())
						break;
				}

				if (nResult2 << 31 == 0 && vInt.size() == 2)
					nResult1 = 0;
				else
				{
					a1.m_vDocCanList[a3[i]].m_bMrzContain = nFlag;
					a6.assign(a3.begin(), a3.end());
					nResult1 = 1;
				}

				if (nResult1 && nResult != 3)
					break;
			}
		}

		//검사결과값을 a3에 돌린다.
		void checkCandidateByMRZ(TBoundsResult & a1, TResultContainerList & a2, RclHolder & a3)
		{
			RclHolder rclHolder1, rclHolder2, rclHolder3, rclHolderTemp;
			TBoundsResult boundsResult;
			vector<int> vInt;
			int nPage, nMax;

			rclHolder1.addNoCopy(a2);
			rclHolder2.addNoCopy(rclHolder1.getRcList(1));
			rclHolder2.addNoCopy(rclHolder1.getRcList(3));
			rclHolder2.addNoCopy(rclHolder1.getRcList(51));

			memcpy(&boundsResult, &a1, sizeof(TBoundsResult));
			rclHolder2.addNewCopy<TBoundsResult>(85, &boundsResult, 0);
			bounds::byrecognize::checkCandidateByRecognize(rclHolder2, rclHolder3);
			vInt = rclhelp::getPages(a3.m_xTRCL);

			if (vInt.empty())
				nPage = 0;
			else
			{
				nMax = vInt[0];
				for (uint i = 1; i < vInt.size(); i++)
				{
					if (nMax < vInt[i])
						nMax = vInt[i];
				}

				nPage = nMax + 1;
			}

			rclHolderTemp.addNoCopy(rclHolder3);
			rclHolderTemp.setPageIndex(nPage);
			a3.addCopy(rclHolderTemp.m_xTRCL);
		}

		int checkCandidateByRecognize(RclHolder & a1, RclHolder & a2)
		{
			RclHolder rclHolder1(a1.m_xTRCL, 1);
			TResultContainerList * resultConList;
			int nTemp = 15;

			vector<TResultContainer *> vResult1 = rclHolder1.getRcList(85);
			if (vResult1.size() == 1)
			{
				rclhelp::bounds::updateBoundsResultByDpi(rclHolder1, -1, 5900, 0.1f, 0);
				rclHolder1.setPageIndex(vResult1[0]->nTRC_page_idx);

				if (!moduleprocessgl::process(0x207, &rclHolder1, 0, (void **)&resultConList, 0))
				{
					a2.addCopy(resultConList);
					RclHolder rclHolder2;
					rclHolder2.addNoCopy(a2.m_xTRCL);
					rclHolder2.addNoCopy(rclHolder1.getRcList(98));
					rclHolder2.addNoCopy(rclHolder1.getRcList(95));
					rclHolder2.addNoCopy(rclHolder1.getRcList(3));
					rclHolder2.addNoCopy(rclHolder1.getRcList(51));

					nTemp = moduleprocessgl::process(0x9C8, &rclHolder2, 0, (void **)&resultConList, 0);
										
					if(!nTemp || nTemp == 29)
					{
						RclHolder rclHolderTemp(resultConList, 1);
						a2.addCopy(rclHolderTemp.getRcList(9));
						a2.addCopy(rclHolderTemp.getRcList(95));
						a2.addCopy(*vResult1[0]);
						a2.setPageIndex(vResult1[0]->nTRC_page_idx);
						return 0;
					}
				}
			}

			return 2;
		}

		//DocumentCandidate들을 검사하여 검사결과를 a6, a7에 돌려준다.
		int checkCandidate(DocumentCandidateList & a1, TResultContainerList & a2, vector<int> & a3, vector<TBoundsResult> & a4, float a5, vector<int> & a6, RclHolder & a7)
		{
			RclHolder rclHolder;
			TBoundsResult *pBoundsResult = 0;
			int nResult = 2;
		
			a7.clear();
			a6.clear();
			rclHolder.addNoCopy(a2);

			for (uint i = 0; i < a3.size(); i++)
			{
				if (!a4.empty())
					pBoundsResult = &a4[0];

				DocumentCandidate docCandidate(a1.m_vDocCanList[a3[i]]);
				if (docCandidate.m_nDocType == 5)
					docCandidate.m_nDocType = 3;

				vector<TBoundsResult> vBoundsResult;
				BoundsInternal::convert(a1.m_vDocCanList[a3[i]], pBoundsResult, a5, true, vBoundsResult, 0);

				int nTemp;
				if (vBoundsResult.size() == 1)
				{
					vector<int> vRecognID;
					RclHolder rclTemp;
					rclTemp.addNoCopy(rclHolder.getRcList(1));

					if (a1.m_vDocCanList[a3[i]].m_bMrzContain)
					{
						rclTemp.addNoCopy(rclHolder.getRcList(3));
					}
					rclTemp.addNoCopy(rclHolder.getRcList(51));
					rclTemp.addNoCopy(rclHolder.getRcList(98));
					rclTemp.addNewCopy<TBoundsResult>(85, &vBoundsResult[0], 0);

					RclHolder rclTemp1;
					nResult = checkCandidateByRecognize(rclTemp, rclTemp1);
					if (!nResult)
					{
						vRecognID.push_back(rclhelp::documentIDRecogn(rclTemp1.m_xTRCL));
						a7.addCopy(rclTemp1.m_xTRCL);
					}
					else
						nTemp = nResult;

					if (nResult != 1)
					{
						if (a7.empty())
							nTemp = 0;
						else
						{
							a6.push_back(a3[i]);
							nTemp = 2;
						}
					}
				}
				else
					nTemp = 3;

				if (nTemp && nTemp != 3)
				{
					if (nTemp != 2)
					{
						return 1;
					}
					break;
				}
			}

			if (a6.empty())
				a7.clear();

			return nResult;
		}

		//해당한 문자렬에 대응한 RecognizeMode를 돌려준다.
		eBoundsByRecognizeMode convert(string & a1)
		{
			static unordered_map<string, eBoundsByRecognizeMode> g_map_11299C4 = {
				unordered_map<string, eBoundsByRecognizeMode>::value_type(string("full"), eBBRM_Full),
				unordered_map<string, eBoundsByRecognizeMode>::value_type(string("fullSplit2"), eBBRM_FullSplit2),
				unordered_map<string, eBoundsByRecognizeMode>::value_type(string("basicOne"), eBBRM_BasicOne),
				unordered_map<string, eBoundsByRecognizeMode>::value_type(string("basicOneBig"), eBBRM_BasicOneBig),
				unordered_map<string, eBoundsByRecognizeMode>::value_type(string("id3x2"), eBBRM_Id3x2),
				unordered_map<string, eBoundsByRecognizeMode>::value_type(string("id3x2Series"), eBBRM_Id3x2Series),
				unordered_map<string, eBoundsByRecognizeMode>::value_type(string("id1x2"), eBBRM_Id1x2),
				unordered_map<string, eBoundsByRecognizeMode>::value_type(string("id3x2One"), eBBRM_Id3x2One),
				unordered_map<string, eBoundsByRecognizeMode>::value_type(string("id3x2Split2Series"), eBBRM_Id3x2Split2Series),
				unordered_map<string, eBoundsByRecognizeMode>::value_type(string("id3x2Split2"), eBBRM_Id3x2Split2),
				unordered_map<string, eBoundsByRecognizeMode>::value_type(string("basic"), eBBRM_Basic),
				unordered_map<string, eBoundsByRecognizeMode>::value_type(string("mrz"), eBBRM_Mrz)
			};
			
			return common::mapValues(g_map_11299C4, a1, eBBRM_None);
		}

		namespace series {
			BoundsState::BoundsState()
			{
				reset();
			}

			BoundsState::~BoundsState()
			{
			}

			void BoundsState::reset()
			{
				m_nBoundsState_field_0 = 0;
				m_nBoundsState_field_24 = 0;
				m_nBoundsState_field_28 = 0;
				m_nBoundsState_field_29 = 0;
				m_vBoundsState_field_4.clear();
				m_xBoundsState_field_10.clear();
			}

			void BoundsState::resetCurrentFrame()
			{
				m_nBoundsState_field_24 = 0;
				m_vBoundsState_field_4.clear();
				m_xBoundsState_field_10.clear();
			}
		}
	}

	namespace testmodesupport {
		TDeviceType g_DeviceType;
		//RclHolder에 장치형태를 설정한다.
		void addDeviceType(RclHolder & rclHolder, int nDeviceType)
		{
			g_DeviceType.nTDT_devType = nDeviceType;
			g_DeviceType.nTDT_cameraIndex = 0;
			rclHolder.addNewNoCopy(82, &g_DeviceType);
		}

		int updateSaveImageStatus(string &, int)
		{
			return 1;
		}
	}

	namespace docteachersupport {
		void addDeviceTypeFromSamplePath(RclHolder & rclHolder)
		{

		}

		void saveSampleAsImages(RclHolder & rclHoder, string const & str)
		{

		}
	}

	namespace debug {
		DocumentDetectDebugInfo * dddiFull()
		{
			return &g_debugInfo_1129A4C;
		}

		DocumentDetectDebugInfo * dddi()
		{
			return &g_debugInfo_1129A10;
		}
	}

	namespace face
	{
		//a2 = a1["boundsParam"] a1에서 faceMetadata자료를 얻고 a3크기에 가장 
		//근사한 얼굴령역을 얻어 a2에 설정한다.
		bool convertFaceDetectResultFromiOS(Json::Value & a1, Json::Value & a2, Size & a3)
		{
			int x, y, width, height;
			int a, b, c, nX, nY;
			bool flag;
			Size size;

			if (!a1.isMember("faceMetadata"))
				return true;

			Json::Value vConfig = a1["faceMetadata"];
			Json::ValueIteratorBase begin = vConfig.begin();
			Json::ValueIteratorBase end = vConfig.end();

			size.width = 0;
			size.height = 0;
			nX = nY = 0;

			while (begin != end)
			{
				Json::Value vMember = begin.deref();
				x = vMember["bounds"]["x"].asInt();
				y = vMember["bounds"]["y"].asInt();
				height = vMember["bounds"]["height"].asInt();
				width = vMember["bounds"]["width"].asInt();
				begin.increment();

				a = height + y;
				if (a3.height < a)
					a = a3.height;
				if (y > 0)
					a -= y;

				b = width + x;
				if (a3.width < b)
					b = a3.width;
				if (x > 0)
					b -= x;

				c = a * b;
				if (b < 1 || a < 1)
					c = 0;

				flag = false;

				if (width * height > size.width * size.height)
					flag = true;

				if ((c == width * height) && flag)
				{
					size.height = height;
					size.width = width;
					nX = x;
					nY = y;
				}
			}

			if (size.width * size.height == 0)
				return true;

			a2["FaceRect"]["left"] = Json::Value(nX);
			a2["FaceRect"]["bottom"] = Json::Value(nY);
			a2["FaceRect"]["right"] = Json::Value(size.width + nX);
			a2["FaceRect"]["top"] = Json::Value(size.height + nY);

			return false;
		}

		//a1령역과 a2령역의 비가 a3보다 작으면 true를 돌린다.
		bool checkByFaceArea(vector<Point2f> & a1, tagRECT & a2, float a3)
		{
			double dblArea;
			int nArea;
			dblArea = contourArea(a1);
			nArea = abs((a2.bottom - a2.top) * (a2.right - a2.left));
			return dblArea / nArea <= a3;
		}
	}

	namespace visa
	{
		void updateVisaID2Result(TResultContainerList & a1, TBoundsResult & a2, vector<float> & a3)
		{
			tagSIZE size;
			vector<Point2f> vPoint1, vPoint2;
			vector<MRZAnalyze::MrzCornerResult> vMrzResult;
			float fTemp1, fTemp2;

			if (a3.size() != 4)
				a3.assign(4, 0.0f);

			size = rclhelp::imageSize(a1);
			if (!MRZAnalyze::getRealDocPos(a1, vPoint1, vPoint2, vMrzResult))
			{
				vector<Point2f> vResult0(vMrzResult[0].m_vMrzCorner_field_0);
				reverse(vResult0.begin(), vResult0.end());

				vector<Point2f> vResult1 = {
					Point2f((float)a2.xTBR_LeftBottom.x, (float)a2.xTBR_LeftBottom.y),
					Point2f((float)a2.xTBR_RightBottom.x, (float)a2.xTBR_RightBottom.y),
					Point2f((float)a2.xTBR_RightTop.x, (float)a2.xTBR_RightTop.y),
					Point2f((float)a2.xTBR_LeftTop.x, (float)a2.xTBR_LeftTop.y) };

				vector<Point2f> vResult2 = {
					Point2f(0.0f, 0.0f), Point2f((float)a2.nTBR_Width, 0.0f),
					Point2f((float)a2.nTBR_Width, (float)a2.nTBR_Height),
					Point2f(0.0f, (float)a2.nTBR_Height) };

				Matx<Point2f, 3, 3> matxRet = getPerspectiveTransform(vResult1, vResult2);
				vector<Point2f> vRet(4);
				perspectiveTransform(vResult0, vRet, matxRet);

				matxRet = getPerspectiveTransform(vResult2, vResult1);
				vector<Point2f> vRet1(vResult2);
				vRet1.assign(vRet.begin(), vRet.end());

				fTemp1 = vRet[3].y - vRet[0].x;
				fTemp2 = vRet[1].x - vRet[0].x;
				vRet1[0].x = vRet1[3].x = ((vRet[0].x - fTemp2 * a3[0]) > 0.0f) ? (vRet[0].x - fTemp2 * a3[0]) : 0.0f;
				vRet1[1].x = vRet1[2].x = ((vRet[1].x + fTemp2 * a3[2]) < (float)a2.nTBR_Width) ? (vRet[1].x + fTemp2 * a3[2]) : a2.nTBR_Width;
				vRet1[0].y = vRet1[1].y = ((vRet[0].y - fTemp1 * a3[1]) > 0.0f) ? (vRet[0].y - fTemp1 * a3[1]) : 0.0f;
				vRet1[2].y = vRet1[3].y = ((vRet[2].y + fTemp1 * a3[3]) < (float)a2.nTBR_Height) ? (vRet[2].y + fTemp1 * a3[3]) : a2.nTBR_Height;

				vector<Point2f> vRet2(4);
				perspectiveTransform(vRet1, vRet2, matxRet);

				a2.xTBR_LeftBottom.x = (int)vRet2[0].x;
				a2.xTBR_LeftBottom.y = (int)vRet2[0].y;
				a2.xTBR_RightBottom.x = (int)vRet2[1].x;
				a2.xTBR_RightBottom.y = (int)vRet2[1].y;
				a2.xTBR_RightTop.x = (int)vRet2[2].x;
				a2.xTBR_RightTop.y = (int)vRet2[2].y;
				a2.xTBR_LeftTop.x = (int)vRet2[3].x;
				a2.xTBR_LeftTop.y = (int)vRet2[3].y;

				fTemp1 = sqrt((vRet2[0].y - vRet2[1].y) * (vRet2[0].y - vRet2[1].y) + (vRet2[0].x - vRet2[1].x) * (vRet2[0].x - vRet2[1].x));
				fTemp2 = (float)sqrt((double)(a2.xTBR_RightTop.y - a2.xTBR_LeftTop.y) * (a2.xTBR_RightTop.y - a2.xTBR_LeftTop.y) +
					(double)(a2.xTBR_RightTop.x - a2.xTBR_LeftTop.x) * (a2.xTBR_RightTop.x - a2.xTBR_LeftTop.x));
				a2.nTBR_Width = (int)((fTemp1 + fTemp2) / 2);

				fTemp1 = (float)sqrt((double)(a2.xTBR_RightBottom.y - a2.xTBR_RightTop.y) * (a2.xTBR_RightBottom.y - a2.xTBR_RightTop.y) +
					(double)(a2.xTBR_RightBottom.x - a2.xTBR_RightTop.x) * (a2.xTBR_RightBottom.x - a2.xTBR_RightTop.x));
				fTemp2 = (float)sqrt((double)(a2.xTBR_LeftTop.y - a2.xTBR_LeftBottom.y) * (a2.xTBR_LeftTop.y - a2.xTBR_LeftBottom.y) +
					(double)(a2.xTBR_LeftTop.x - a2.xTBR_LeftBottom.x) * (a2.xTBR_LeftTop.x - a2.xTBR_LeftBottom.x));
				a2.nTBR_Height = (int)((fTemp1 + fTemp2) / 2);

				a2.xTBR_Center.x = (a2.xTBR_LeftTop.x + a2.xTBR_LeftBottom.x + a2.xTBR_RightBottom.x + a2.xTBR_RightTop.x) / 4;
				a2.xTBR_Center.y = (a2.xTBR_RightBottom.y + a2.xTBR_LeftBottom.y + a2.xTBR_LeftTop.y + a2.xTBR_RightTop.y) / 4;
				
				if (rclhelp::deviceTypeReal(a1))
				{
					vector<Point2f> vRet3(4);
					matxRet = getPerspectiveTransform(vRet2, vResult2);
					perspectiveTransform(vResult0, vRet3, matxRet);
					a2.nTBR_Dpi = MRZAnalyze::resolutionFromMrzWidth(vMrzResult[0].m_nMCR_DocForamt, (int)(vRet[1].x - vRet[0].x));
				}
			}
		}
	}

	namespace test {
		//a3등록부에 json화일들을 창조하고 a1의 내용과 a2내용을 보관한다.
		void createTestSample(RclHolder & a1, string & a2, string & a3)
		{
			string strDir = a3, strFile, strJson;
			basic_ifstream<char> inStream;
			basic_ofstream<char> outStream;

			if (a1.getRcList(71).empty())
				common::fs::mkDir(common::fs::Path(strDir));
			else
			{
				char* szDir = a1.getRcList(71)[0]->u.pTRC_CHAR;
				strDir.assign(szDir, strlen(szDir));
			}

			if (!a1.getRcList(3).empty())
			{
				if (!a1.getRcList(87).empty())
				{
					strFile = strDir;
					strFile.append("/Result_MRZ.json");
					inStream.open(strFile, ios::in);
					if (!inStream.is_open())
					{
						strFile = strDir;
						strFile.append("/Result_MRZ_.json");
					}
					inStream.close();

					RclHolder rclResult;
					rclResult.addNoCopy(a1.getRcList(3));
					rclResult.addNoCopy(a1.getRcList(87));
					strJson = common::container::json::ToJson(rclResult.m_xTRCL);

					outStream.open(strFile, ios::out);
					outStream << strJson;
					outStream.close();
				}
			}

			if (!a1.getRcList(85).empty())
			{
				RclHolder rclResult;
				vector<TResultContainer*> vResult = a1.getRcList(85);
				for (uint i = 0; i < vResult.size(); i ++)
					rclResult.addNoCopy(*vResult[i]);
				strJson = common::container::json::ToJson(rclResult.m_xTRCL);

				strFile = strDir;
				strFile.append("/Result_BoundsEtalon.json");
				inStream.open(strFile, ios::in);

				if (!inStream.is_open())
				{
					strFile = strDir;
					strFile.append("/Result_BoundsEtalon_.json");
				}

				inStream.close();
				outStream.open(strFile, ios::out);
				outStream << strJson;
				outStream.close();
			}

			if (!a1.getRcList(86).empty())
			{
				RclHolder rclResult;
				rclResult.addNoCopy(a1.getRcList(86));
				strJson = common::container::json::ToJson(rclResult.m_xTRCL);

				strFile = strDir;
				strFile.append("/Result_FullVideoSensor.json");
				inStream.open(strFile, ios::in);

				if (!inStream.is_open())
				{
					strFile = strDir;
					strFile.append("/Result_FullVideoSensor_.json");
				}

				inStream.close();
				outStream.open(strFile, ios::out);
				outStream << strJson;
				outStream.close();
			}

			if (!a1.getRcList(82).empty())
			{
				RclHolder rclResult;
				rclResult.addNoCopy(a1.getRcList(82));
				strJson = common::container::json::ToJson(rclResult.m_xTRCL);

				strFile = strDir;
				strFile.append("/Result_DeviceType.json");
				inStream.open(strFile, ios::in);

				if (!inStream.is_open())
				{
					strFile = strDir;
					strFile.append("/Result_DeviceType_.json");
				}

				inStream.close();
				outStream.open(strFile, ios::out);
				outStream << strJson;
				outStream.close();
			}

			if (a2.size())
			{
				strFile = strDir;
				strFile.append("/Result_BoundsCurrent.json");
				outStream.open(strFile, ios::out);
				outStream << a2;
				outStream.close();
			}
		}
	}

	namespace boundsresult {
		//TBoundsResult로부터 구석점을 돌려받는다.
		vector<Point> getCorners(TBoundsResult & boundsResult)
		{
			vector<Point> vPoint = {
				Point(boundsResult.xTBR_LeftTop.x, boundsResult.xTBR_LeftTop.y),
				Point(boundsResult.xTBR_LeftBottom.x, boundsResult.xTBR_LeftBottom.y),
				Point(boundsResult.xTBR_RightBottom.x, boundsResult.xTBR_RightBottom.y),
				Point(boundsResult.xTBR_RightTop.x, boundsResult.xTBR_RightTop.y)
			};
			return vPoint;
		}

		//TBoundsResult로부터 180도 돌린 구석점을 돌려받는다.
		vector<Point> getCorners180(TBoundsResult & boundsResult)
		{
			vector<Point> vPoint = {
				Point(boundsResult.xTBR_RightBottom.x, boundsResult.xTBR_RightBottom.y),
				Point(boundsResult.xTBR_RightTop.x, boundsResult.xTBR_RightTop.y),
				Point(boundsResult.xTBR_LeftTop.x, boundsResult.xTBR_LeftTop.y),
				Point(boundsResult.xTBR_LeftBottom.x, boundsResult.xTBR_LeftBottom.y)
			};
			return vPoint;
		}

		//TBoundsResult로부터 구석점을 돌려받는다.
		vector<Point2f> getCorners2f(TBoundsResult & boundsResult)
		{
			vector<Point2f> vPoint = {
				Point2f((float)boundsResult.xTBR_LeftTop.x, (float)boundsResult.xTBR_LeftTop.y),
				Point2f((float)boundsResult.xTBR_LeftBottom.x, (float)boundsResult.xTBR_LeftBottom.y),
				Point2f((float)boundsResult.xTBR_RightBottom.x, (float)boundsResult.xTBR_RightBottom.y),
				Point2f((float)boundsResult.xTBR_RightTop.x, (float)boundsResult.xTBR_RightTop.y)
			};
			return vPoint;
		}

		//DocumentCandidate를 TBoundsResult로 변환한다.
		void convert(DocumentCandidate & a1, TBoundsResult & a2)
		{
			a2.cTBR_ObjIntAngleDev = (uchar)a1.m_rIntAngle;
			a2.nTBR_docFormat = a1.m_nDocType;
			a2.nTBR_Width = (int)a1.m_xDocSize.width;
			a2.nTBR_Height = (int)a1.m_xDocSize.height;
			a2.rTBR_Angle = a1.m_rAngleDC;

			if (a1.m_vCornerDC.size() >= 4)
			{
				a2.xTBR_RightTop.x = (int)a1.m_vCornerDC[2].x;
				a2.xTBR_RightTop.y = (int)a1.m_vCornerDC[2].y;
				a2.xTBR_RightBottom.x = (int)a1.m_vCornerDC[1].x;
				a2.xTBR_RightBottom.y = (int)a1.m_vCornerDC[1].y;
				a2.xTBR_LeftTop.x = (int)a1.m_vCornerDC[3].x;
				a2.xTBR_LeftTop.y = (int)a1.m_vCornerDC[3].y;
				a2.xTBR_LeftBottom.x = (int)a1.m_vCornerDC[0].x;
				a2.xTBR_LeftBottom.y = (int)a1.m_vCornerDC[0].y;
			}

			a2.xTBR_Center.x = (int)a1.m_xCenterDC.x;
			a2.xTBR_Center.y = (int)a1.m_xCenterDC.y;

			if (a1.m_bMrzContain)
				a2.cTBR_ResultStatus |= 2;
		}

		//네 구석점을 반전하여 DocumentCandidate를 TBoundsResult로 변환한다.
		void convertInv(DocumentCandidate & a1, TBoundsResult & a2)
		{
			DocumentCandidate docInv(a1);

			if (a1.m_vCornerDC.size() == 4)
				reverse(docInv.m_vCornerDC.begin(), docInv.m_vCornerDC.end());

			convert(docInv, a2);
		}

		//구석점들사이의 최대거리를 계산하여 돌려준다.
		double calculateMaxCornerDist(TBoundsResult & a1, TBoundsResult & a2)
		{
			double dblSqrt1, dblSqrt2, dblX1, dblY1, dblX2, dblY2, dblTemp1 = 0.0, dblTemp2 = 0.0;
			vector<Point> vCorner1, vCorner2, vCorner3;
			vCorner1 = getCorners(a1);
			vCorner2 = getCorners(a2);
			vCorner3 = getCorners180(a2);

			for (uint i = 0; i < vCorner1.size(); i++)
			{
				dblX1 = vCorner1[i].x - vCorner2[i].x;
				dblY1 = vCorner1[i].y - vCorner2[i].y;
				dblX2 = vCorner1[i].y - vCorner3[i].y;
				dblY2 = vCorner1[i].x - vCorner3[i].x;
				dblSqrt1 = sqrt(dblX1 * dblX1 + dblY1 * dblY1);
				dblSqrt2 = sqrt(dblX2 * dblX2 + dblY2 * dblY2);

				if (dblTemp1 < dblSqrt1)
					dblTemp1 = dblSqrt1;

				if (dblTemp2 < dblSqrt2)
					dblTemp2 = dblSqrt2;
			}

			if (dblTemp2 < dblTemp1)
				dblTemp1 = dblTemp2;

			if (dblTemp1 > 1.79769313e308)
				dblTemp1 = -1;

			return dblTemp1;
		}

		bool checkBoundsResults(TBoundsResult & a1, TBoundsResult & a2, float a3)
		{
			double dblMax;

			dblMax = calculateMaxCornerDist(a1, a2);

			if (dblMax <= a3 * a1.nTBR_Width)
				return true;

			return false;
		}

		//TBoundsResult안의 x성분은 a2배, y성분은 a3배 확대/축소
		void scale(TBoundsResult & a1, float a2, float a3)
		{
			float fHeight = a3;

			if (fHeight == 0.0)
				fHeight = a2;

			a1.xTBR_LeftTop.x = (int)(a2 * a1.xTBR_LeftTop.x);
			a1.xTBR_LeftTop.y = (int)(fHeight * a1.xTBR_LeftTop.y);
			a1.xTBR_LeftBottom.x = (int)(a2 * a1.xTBR_LeftBottom.x);
			a1.xTBR_LeftBottom.y = (int)(fHeight * a1.xTBR_LeftBottom.y);
			a1.xTBR_RightTop.x = (int)(a2 * a1.xTBR_RightTop.x);
			a1.xTBR_RightTop.y = (int)(fHeight * a1.xTBR_RightTop.y);
			a1.xTBR_RightBottom.x = (int)(a2 * a1.xTBR_RightBottom.x);
			a1.xTBR_RightBottom.y = (int)(fHeight * a1.xTBR_RightBottom.y);
			a1.xTBR_Center.x = (int)(a2 * a1.xTBR_Center.x);
			a1.xTBR_Center.y = (int)(fHeight * a1.xTBR_Center.y);

			a1.nTBR_Width = (int)(a2 * a1.nTBR_Width);
			a1.nTBR_Height = (int)(fHeight * a1.nTBR_Height);

			a1.nTBR_Dpi = (int)((a2 + fHeight) * 0.5 * a1.nTBR_Dpi);
			a1.cTBR_ObjArea = (uchar)(a1.nTBR_Width * a1.nTBR_Height);
		}

		void scale(TBoundsResult & a1, TBoundsResult & a2, float a3, float a4)
		{
			memcpy(&a2, &a1, sizeof(TBoundsResult));
			scale(a2, a3, a4);
		}

		void scale(vector<Point2f> & a1, vector<Point2f> & a2, float a3)
		{
			if (a1 != a2)
				a2.assign(a1.begin(), a1.end());

			for (uint i = 0; i < a2.size(); i++)
			{
				a2[i].x *= a3;
				a2[i].y *= a3;
			}
		}
	}

	namespace result
	{
		//a1에 네 구석점의 중심을 돌려준다.
		Point2f centerDocByCorners(TBoundsResult const& a2)
		{
			Point2f a1;
			vector<tagPOINT> vPoint;
			vPoint.push_back(a2.xTBR_LeftTop);
			vPoint.push_back(a2.xTBR_LeftBottom);
			vPoint.push_back(a2.xTBR_RightBottom);
			vPoint.push_back(a2.xTBR_RightTop);

			a1.x = 0.0f;
			a1.y = 0.0f;

			for (uint i = 0; i < vPoint.size(); i++)
			{
				a1.x += (float)vPoint[i].x;
				a1.y += (float)vPoint[i].y;
			}

			a1.x *= 0.25;
			a1.y *= 0.25;

			return a1;
		}

		bool isAllPointsInside(vector<Point2f> & a1, vector<Point2f> & a2)
		{
			for (uint i = 0; i < a1.size(); i++)
			{
				if (pointPolygonTest(a2, a1[i], 0) < 0.0)
					return false;
			}

			return true;
		}

		//doc형식에 따라 doc크기를 갱신한다.
		void updateSizeOutByDocFormat(TBoundsResult & a1)
		{
			float fHeight, fWidth;
			fHeight = (float)a1.nTBR_Height;
			fWidth = (float)a1.nTBR_Width;

			BoundsResult::updateSizeOutByDocFormat(a1.nTBR_docFormat, fWidth, fHeight);
			a1.nTBR_Width = (int)fWidth;
			a1.nTBR_Height = (int)fHeight;
		}
	}

	namespace lines {
		float calcAngleWLines(vector<LineEx> & vLine)
		{
			float v1 = 0.0, v2;
			vector<float> v3;

			if (!vLine.empty())
			{
				for (uint i = 0; i < vLine.size(); i++)
					v1 += vLine[i].m_rLineLen;

				v2 = v1 / vLine.size();

				for (uint i = 0; i < vLine.size(); i++)
				{
					if (vLine[i].m_rLineLen > v2)
						v3.push_back((float)vLine[i].m_rLineAngle);
				}

				if (v3.empty())
					v1 = 0.0;
				else
					v1 = v3[0];

				if (v3.size() == 2)
				{
					v1 = (v3[0] + v3[1]) * 0.5f;
					if (fabsf(v3[0] - v3[1]) > 90.0f)
						v1 += 90.0;
				}
			}

			return v1;
		}
		
		void getLines(vector<Mat> & a1, DocumentDetectionParameter & a2, double a3, vector<LineEx> & a4)
		{
			for (uint i = 0; i < a1.size(); i++)
			{
				if (a1[i].total())
				{
					vector<vector<Point>> vPoint;
					vector<Vec4i> vVec;

					if (a2.m_nContourType)
						findContours(a1[i], vPoint, vVec, RETR_LIST, CHAIN_APPROX_SIMPLE);
					else
						findContours(a1[i], vPoint, vVec, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);
					
					if (!vPoint.empty())
						DocumentDetect::getLines(vPoint, a3, a4);
				}
			}

			if (a2.m_nRemoveBorderLine)
			{
				Size size;
				size.width = a1[0].cols;
				size.height = a1[0].rows;
				vector<LineEx> vLine(a4);
				DocumentDetect::removePerimeterLines(size, 3, vLine, a4);
			}
		}

		void getLines(vector<ProcessVariant> & a1, uint a2, vector<bounds::lines::ProcessStore> & a3, ImagesListMat & a4, Mat & a5, DocumentDetectionParameter & a6, uint & a7)
		{
			vector<LineEx> vLineResult;
			int nTemp;

			a7 = -1;

			for (; a2 < a1.size(); a2++)	
			{
				if (a1[a2].m_nProcessType)
				{
					a7 = a2;
					break;
				}

				Mat mat;
				vector<Mat> vMat;

				ImagesListMat matList = a4;
				if (!getImages(matList, a1[a2], mat, a6, vMat))
				{
					vector<LineEx> vLine;
					getLines(vMat, a6, a6.m_rAverContourResolution, vLine);
					vector<LineEx> vFilterLine;
					if (mat.total())
					{
						if (!a5.rows)
						{
							Mat matStruct;
							matStruct = getStructuringElement(0, Size(3, 3), Point(1, 1));
							erode(mat, a5, matStruct);
						}

						for (uint j = 0; j < vLine.size(); j++)
						{
							nTemp = *a5.step.p;
							if (a5.data[nTemp * vLine[j].m_xStartPoint.y + vLine[j].m_xStartPoint.x] == 255 &&
								a5.data[nTemp * vLine[j].m_xEndPoint.y + vLine[j].m_xEndPoint.x] == 255)
								vFilterLine.push_back(vLine[j]);
						}
					}
					else
						vFilterLine.assign(vLine.begin(), vLine.end());

					vector<LineEx> vLine1, vLine2;
					LineExProcess::filterLinesByLength(vFilterLine, a6.m_rMinLengthLineForDetectResolution * a1[a2].m_rKLineLenFilter, vLine1, vLine2);
					vLineResult.insert(vLineResult.begin(), vLine1.begin(), vLine1.end());
				}
			}

			for (uint i = 0; i < a2; i++)
			{
				if (a1[i].m_nProcessType)
					vLineResult.insert(vLineResult.begin(), a3[i].m_xPS_field_30.begin(), a3[i].m_xPS_field_30.end());
			}

			if (a7 != -1)
				a3[a7].m_xPS_field_30.assign(vLineResult.begin(), vLineResult.end());
		}

		//화상처리를 진행한 결과를 a5에 돌려받는다.
		int getImages(ImagesListMat & a1, ProcessVariant & a2, Mat & a3, DocumentDetectionParameter & a4, vector<Mat> & a5)
		{
			ImageExMat *v1, *v2;
			Mat v3, v4;
			int v5, v7, v8, v9;
			float v6[2] = { 0, 256 };
			float v10;
			CBufferImage bufferImage;
			int nResult = 0;
			eBinProcess eBP;

			a5.resize(a2.m_veBPI.size());

			for (uint i = 0; i < a2.m_veBPI.size(); i++)
			{
				v1 = a1.image(a2.m_veBPI[i], eBP_OFF);

				if (!v1)
				{
					ImagesListProcess::generateImage(a1, a2.m_veBPI[i]);
					v1 = a1.image(a2.m_veBPI[i], eBP_OFF);
				}

				if (v1->m_xImageExMat.total())
				{
					eBP = eBP_OFF;

					for (uint j = 0; j < a2.m_veBP.size(); j++)
					{
						v1 = a1.image(a2.m_veBPI[i], eBP);
						
						if (v1)
						{
							eBP = (eBinProcess)(eBP | a2.m_veBP[j]);
							v2 = a1.image(a2.m_veBPI[i], eBP);

							if (!v2)
							{
								v2 = a1.create(a2.m_veBPI[i], eBP);

								switch (a2.m_veBP[j])
								{
								case eBP_Sobel:  //Ok
									RCv::SobelFull(v1->m_xImageExMat, v2->m_xImageExMat);
									break;
								case eBP_BinUsual_50:
								case eBP_BinUsual_30:
									v5 = 256;
									calcHist(&v1->m_xImageExMat, 1, 0, v4, v3, 1, &v5, (const float **)&v6);
									RAnalyse::dynamicRange(v3, 3, 3, v9, v7, v8, -1, -1);
									if (a2.m_veBP[j] == 4)
										v10 = v7 + v9 * 0.3f;
									else
									{
										if (a2.m_veBP[j] != 2)
											v10 = 0.0;
										else
											v10 = v7 + v9 * 0.5f;
									}

									threshold(v1->m_xImageExMat, v2->m_xImageExMat, v10, 255.0, 0);
									break;
								case 3:
								case 5:
								case 6:
								case 7:
									break;
								case eBP_BinOTSU:
									RCvMat::ref(v1->m_xImageExMat, bufferImage);
									v7 = 0;
									RAnalyse::findThresholdBinary(bufferImage, v7, 1, 256);
									threshold(v1->m_xImageExMat, v2->m_xImageExMat, v7, 255.0, 0);
									break;
								case eBP_Resize:  //Ok
									resize(v1->m_xImageExMat, v2->m_xImageExMat,
										Size((int)(v1->m_xImageExMat.cols * a4.m_rDDPField_CC), (int)(v1->m_xImageExMat.rows * a4.m_rDDPField_CC)));
									break;
								case eBP_BinFixLevel:
									threshold(v1->m_xImageExMat, v2->m_xImageExMat, a4.m_nThresholdBin, 255.0, 0);
									break;
								case eBP_BinUsual_15R:
									threshold(v1->m_xImageExMat, v2->m_xImageExMat, 15.0, 255.0, 0);
									break;
								case eBP_FilterBox:  //Ok
									boxFilter(v1->m_xImageExMat, v2->m_xImageExMat, -1, Size(5, 5));
									break;
								case eBP_Canny:
									Canny(v1->m_xImageExMat, v2->m_xImageExMat, 20.0, 60.0, 3, 0);
									break;
								case eBP_Mask:
									if (a3.total())
										bitwise_and(v1->m_xImageExMat, a3, v2->m_xImageExMat, 0x2010000);
									else
										v1->m_xImageExMat.copyTo(v2->m_xImageExMat);
									break;
								case eBP_OTSU_ADAPT_GAUS:
									adaptiveThreshold(v1->m_xImageExMat, v2->m_xImageExMat, 255.0, 1, 0, 3, 5.0);
									break;
								case eBP_OTSU_CV:  //Ok
									threshold(v1->m_xImageExMat, v2->m_xImageExMat, 1.0, 255.0, 8);
									break;
								case eBP_GaussianBlur:
									GaussianBlur(v1->m_xImageExMat, v2->m_xImageExMat, Size(5, 5), 0);
									break;
								case eBP_BinOTSU_Second:
									v7 = v8 = v9 = 0;
									RCvMat::ref(v1->m_xImageExMat, bufferImage);
									RAnalyse::findThresholdBinary3(bufferImage, v7, v8, v9, 1, 256);
									threshold(v1->m_xImageExMat, v2->m_xImageExMat, v9, 256.0, 0);
									break;
								case eBP_BinOTSU_Previus:
									v7 = v8 = v9 = 0;
									RCvMat::ref(v1->m_xImageExMat, bufferImage);
									RAnalyse::findThresholdBinary3(bufferImage, v7, v8, v9, 1, 256);
									threshold(v1->m_xImageExMat, v2->m_xImageExMat, v8, 256.0, 0);
									break;
								case eBP_Close:
									v3 = getStructuringElement(2, Size(21, 21), Point(10, 10));
									morphologyEx(v1->m_xImageExMat, v2->m_xImageExMat, 3, v3);
									break;
								case eBP_CloseRect:
									v3 = getStructuringElement(0, Size(13, 13), Point(6, 6));
									morphologyEx(v1->m_xImageExMat, v2->m_xImageExMat, 3, v3);
									break;
								}

								if (a4.m_nROIFlag)
								{
									if (a2.m_veBP[j] <= 8 && (1 << a2.m_veBP[j]) & 0x114 || a2.m_veBP[j] == 512 || a2.m_veBP[j] == 128)
									{
										Mat v11(v2->m_xImageExMat, Rect(0, 0, (int)(a4.m_nROIX1 * v2->m_xImageExMat.cols / 100.0f), v2->m_xImageExMat.rows));
										v11.setTo(Scalar(0, 0, 0, 0));
										Mat v12(v2->m_xImageExMat, Rect(0, 0, v2->m_xImageExMat.cols, (int)(a4.m_nROIY1 * v2->m_xImageExMat.rows / 100.0f)));
										v11 = v12;
										v11.setTo(Scalar(0, 0, 0, 0));
										Mat v13(v2->m_xImageExMat, Rect((int)((100.0f - a4.m_nROIX2) * v2->m_xImageExMat.cols / 100.0f), 0, 
											(int)(v2->m_xImageExMat.cols - (100.0f - a4.m_nROIX2) * v2->m_xImageExMat.cols / 100.0f), v2->m_xImageExMat.rows));
										v11 = v13;
										v11.setTo(Scalar(0, 0, 0, 0));
										Mat v14(v2->m_xImageExMat, Rect(0, (int)((100.0f - a4.m_nROIY2) * v2->m_xImageExMat.rows / 100.0f), v2->m_xImageExMat.cols, (int)(v2->m_xImageExMat.rows - (100.0f - a4.m_nROIY2) * v2->m_xImageExMat.rows / 100.0f)));
										v11 = v14;
										v11.setTo(Scalar(0, 0, 0, 0));
									}
								}
							}

						}
						else
							return 1;
					}

					if (v2)
						v2->m_xImageExMat.copyTo(a5[i]);
				}
			}

			for (uint i = 0; i < a5.size(); i++)
			{
				if (!a5[i].total())
				{
					nResult = 1;
					break;
				}
			}

			return nResult;
		}

		GrLines::GrLines(GrLines && a1)
			: m_xGL_field_0(move(a1.m_xGL_field_0)),
			m_xGL_field_C(move(a1.m_xGL_field_C)),
			m_xGL_field_30(move(a1.m_xGL_field_30)),
			m_xGL_field_3C(move(a1.m_xGL_field_3C))
		{
		}

		GrLines::GrLines()
		{
		}
	}

	namespace candidates {
		void checkDocument(DocumentSize::DocumentIDCheck & a1, CheckDocumentParam & a2, DocumentCandidate & a3, vector<DocumentCandidate> & a4)
		{
			bool bY, bX, bFlag;
			float fWH, fTemp, fTemp1;
			int nSidesCount, nTemp;
			vector<float> vLenSides;
			
			a3.m_rProbAngle = 0;
			a3.m_rMainProb = 0;

			a3.cornersDocument(a3.m_vCornerDC);
			DocumentCandidate::documentSize(a3.m_vCornerDC, a3.m_xDocSize.width, a3.m_xDocSize.height, a3.m_xCenterDC, bY, bX);

			fWH = (a3.m_xDocSize.height < a3.m_xDocSize.width) ? a3.m_xDocSize.height : a3.m_xDocSize.width;

			if (fWH >= a2.rCDPField_8)
			{
				a3.kLenSides(vLenSides);
				nSidesCount = 0;

				uint i;
				for (i = 0; i < vLenSides.size(); i++)
				{
					if (vLenSides[i] < a2.fCDPField_30)
					{
						bFlag = 1;
						break;
					}

					if (vLenSides[i] > a2.fCDPField_2C)
						nSidesCount++;
				}

				if (i == vLenSides.size())
				{
					bFlag = 0;
					if (nSidesCount < 3)
						bFlag = 1;
				}

				if (!bFlag)
				{
					a3.cornersDocumentUpdHV(bY, bX);
					if (a2.xCDPDocDetect->m_xDocDTParam.m_bFullDocumentDetectOnly)
					{
						float rMax = a3.m_xDocSize.width;
						if (a3.m_xDocSize.width < a3.m_xDocSize.height)
							rMax = a3.m_xDocSize.height;

						rMax *= a2.xCDPDocDetect->m_xDocDTParam.m_rFullDocumentDetectDevMax;

						for (uint i = 0; i < a3.m_vCornerDC.size(); i++)
						{
							if ((0.0 - a3.m_vCornerDC[i].x) > rMax || (a3.m_vCornerDC[i].x - a2.xCDPSize.cx) > rMax ||
								(0.0 - a3.m_vCornerDC[i].y) > rMax || (a3.m_vCornerDC[i].y - a2.xCDPSize.cy) > rMax)
								return;
						}
					}

					if (a3.m_xDocSize.width < a3.m_xDocSize.height)
					{
						//no check
						a3.cornersDocumentInvHW();
					}

					if (!a2.xCDPFaceInfo || !a2.xCDPFaceInfo->m_bFIClear ||
						IsPointInside(a3.m_vCornerDC, a2.xCDPFaceInfo->m_xFIkCenter) &&
						bounds::face::checkByFaceArea(a3.m_vCornerDC, a2.xCDPFaceInfo->m_xFIkRect, 0.5))
					{
						if (a4.size() == 307)
						{
							i = i;
						}
						a3.m_rAngleDC = a3.calcAngleByHSides();
						a3.checkInternalAngle(a3.m_rIntAngle, a3.m_rSumIntAngle);
						if (!a2.nCDPField_0 || !a2.fCDPField_4)
						{
							nTemp = -1;
							a1.isIDByProportions(a3.m_xDocSize.width, a3.m_xDocSize.height, a3.m_rProportionDC, a3.m_nDocType, &nTemp);
							fTemp = a3.m_rProportionDC;
							if (fTemp > 0.95)
							{
								fTemp = (fTemp - 0.95f) * 0.01f / 0.05f + 0.95f;
								a3.m_rProportionDC = (fTemp - 0.95f) * 0.01f / 0.05f + 0.95f;
							}

							if (a2.xCDPDocDetect->m_xDocDTParam.m_bOnlyDocFromIni && fTemp < a2.xCDPDocDetect->m_xDocDTParam.m_rMinProbByProportion)
								return;

							a3.m_rMainProb = fTemp;
						}

						if (a2.nCDPField_0)
						{
							//no check
							nTemp = -1;
							a1.isID(1000.0f * a3.m_xDocSize.width / a2.nCDPField_0, 1000.0f * a3.m_xDocSize.height / a2.nCDPField_0,
								a3.m_rAuxProb, a3.m_nDocType, &nTemp);
							if (a2.xCDPDocDetect->m_xDocDTParam.m_bOnlyDocFromIni)
							{
								float fTemp = a2.xCDPDocDetect->m_xDocDTParam.m_rMinProbBySize;
								if (!a2.fCDPField_4)
									fTemp = a2.xCDPDocDetect->m_xDocDTParam.m_rMinProbBySizeCalcProb;
								if (a3.m_rAuxProb < fTemp)
									return;
							}
							if (a2.fCDPField_4)
								a3.m_rMainProb = a3.m_rAuxProb;
							if (a2.nCDPField_0)
							{
								if (a2.fCDPchangingDPI)
								{
									fTemp = 0.0;
									nTemp = -1;
									a1.isIDByProportionAndSize(1000.0f * a3.m_xDocSize.width / a2.nCDPField_0, 1000.0f * a3.m_xDocSize.height / a2.nCDPField_0,
										0.92f, fTemp, fTemp1, nTemp);
									if (fTemp > a3.m_rAuxProb)
									{
										a3.m_rProportionDC = fTemp;
										a3.m_rMainProb = fTemp;
										a3.m_rAuxProb = fTemp1;
										a3.m_nDocType = nTemp;
									}
								}
							}
						}

						a3.m_rMrzParam4 = 1.0;
						a3.m_rMrzParam2 = 1.0;

						if (a2.vCDPPoint)
						{
							//no check
							if (!bounds::result::isAllPointsInside(*a2.vCDPPoint, a3.m_vCornerDC))
							{
								a3.m_bMrzContain = 0;
								a3.m_rMrzParam4 = 0;
								a3.m_rMrzParam2 = 0;
							}
							else
							{
								a3.m_bMrzContain = 1;
								if (a2.vBoundsResult1)
								{
									fTemp1 = 0.0f;
									DocumentDetect::calculateDocParam_MRZ4(*a2.vBoundsResult1, a3, fTemp1);
									a3.m_rMrzParam4 = 1.0f - fTemp1 / a3.m_xDocSize.width;
									DocumentDetect::calculateDocParam_MRZ2(*a2.vBoundsResult1, a3, fTemp1);
									a3.m_rMrzParam2 = 1.0f - fTemp1 / a3.m_xDocSize.width;
								}
								else
								{
									a3.m_rMrzParam4 = 1.0f;
									if (a2.vBoundsResult2)
									{
										fTemp1 = 0.0;
										DocumentDetect::calculateDocParam_MRZ2(*a2.vBoundsResult2, a3, fTemp1);
										a3.m_rMrzParam2 = 1.0f - fTemp1 / a3.m_xDocSize.width;
									}
									else
										a3.m_rMrzParam2 = 1.0f;
								}
							}
						}

						a4.push_back(a3);
					}
				}
			}
		}

		void makeDocument(vector<LineGroup *> & a1, vector<LineGroup *> & a2, DocumentSize::DocumentIDCheck & a3, CheckDocumentParam & a4, int a5, vector<DocumentCandidate> & a6, int a7)
		{
			int nLimit, nCount;

			for (uint i = 0; i < a1.size(); i++)
			{
				for (uint j = i + 1; j < a1.size(); j++)
				{
					for (uint k = 0; k < a2.size(); k++)
					{
						for (uint m = k + 1; m < a2.size(); m++)
						{
							vector<LineGroup *> vLineGroup;
							vLineGroup.push_back(a1[i]);
							vLineGroup.push_back(a1[j]);
							vLineGroup.push_back(a2[k]);
							vLineGroup.push_back(a2[m]);

							nLimit = 0;
							nCount = 0;
							for (uint l = 0; l < vLineGroup.size(); l++)
							{
								nLimit += vLineGroup[l]->m_bSegkLenGr_3C;
								if (vLineGroup[l]->m_rSegLen < a5)
									++nCount;
							}

							if (nLimit <= a7)
							{
								if (nLimit == 0 || nCount <= 1)
								{
									DocumentCandidate docCan;
									docCan.m_bViltual = nLimit;
									docCan.setSides(vLineGroup);
									checkDocument(a3, a4, docCan, a6);
								}
							}
						}
					}
				}
			}
		}

		void makeDocument(vector<LineGroup> & a1, vector<int> & a2, vector<LineGroup> & a3, vector<int> & a4, vector<LineGroup> & a5, vector<LineGroup> & a6, DocumentSize::DocumentIDCheck & a7, CheckDocumentParam & a8, int a9, vector<DocumentCandidate> & a10, int a11)
		{
			vector<LineGroup*> vLineGroup1, vLineGroup2;

			for (uint i = 0; i < a2.size(); i++)
				vLineGroup1.push_back(&a1[a2[i]]);

			for (uint i = 0; i < a5.size(); i++)
				vLineGroup1.push_back(&a5[i]);

			for (uint i = 0; i < a4.size(); i++)
				vLineGroup2.push_back(&a3[a4[i]]);

			for (uint i = 0; i < a6.size(); i++)
				vLineGroup2.push_back(&a6[i]);

			makeDocument(vLineGroup1, vLineGroup2, a7, a8, a9, a10, a11);
		}
	}
}

namespace BoundsResult {
	//결과값에서 경계점들에 대한 검사를 진행한다.
	bool checkResult(RclHolder & a1, RclHolder & a2, float a3)
	{
		vector<TResultContainer *> vResult1, vResult2;
		vector<Point> vCorner1, vCorner2, vCorner180;
		TBoundsResult * boundsResult;
		double fDelta1, fDelta2, fDelta, fLimit;
		double fSqrt1, fSqrt2;

		vResult1 = a1.getRcList(85);
		vResult2 = a2.getRcList(85);

		if (vResult1.empty() || vResult2.empty() || vResult1.size() != vResult2.size())
			return true;

		for (uint i = 0; i < vResult1.size(); i++)
		{
			boundsResult = vResult1[i]->u.pTRC_TBR;
			vCorner1 = bounds::boundsresult::getCorners(*boundsResult);
			fLimit = boundsResult->nTBR_Width * a3;
			fDelta = 1.79769313e308;

			for (uint j = 0; j < vResult2.size(); j++)
			{
				vCorner2 = bounds::boundsresult::getCorners(*vResult2[j]->u.pTRC_TBR);
				vCorner180 = bounds::boundsresult::getCorners180(*vResult2[j]->u.pTRC_TBR);

				fDelta1 = fDelta2 = 0.0;

				for (uint k = 0; k < vCorner1.size(); k++)
				{
					fSqrt1 = sqrt((vCorner1[k].y - vCorner2[k].y) * (vCorner1[k].y - vCorner2[k].y) +
						(vCorner1[k].x - vCorner2[k].x) * (vCorner1[k].x - vCorner2[k].x));

					if (fDelta1 < fSqrt1)
						fDelta1 = fSqrt1;

					fSqrt2 = sqrt((vCorner1[k].y - vCorner180[k].y) * (vCorner1[k].y - vCorner180[k].y) +
						(vCorner1[k].x - vCorner180[k].x) * (vCorner1[k].x - vCorner180[k].x));

					if (fDelta2 < fSqrt2)
						fDelta2 = fSqrt2;
				}

				if (fDelta2 < fDelta1)
					fDelta1 = fDelta2;

				if (fDelta < fDelta1)
					fDelta1 = fDelta;

				fDelta = fDelta1;

				if (fDelta1 < fLimit)
					break;
			}

			if (fDelta1 > fLimit)
				return true;
		}

		return false;
	}

	//점벡토르로부터 선벡토르를 얻는다.
	vector<LineEx> getLines(vector<Point2f> & vPoint)
	{
		vector<LineEx> vLine;
		vLine.push_back(LineEx(vPoint[0], vPoint[1]));
		vLine.push_back(LineEx(vPoint[1], vPoint[2]));
		vLine.push_back(LineEx(vPoint[2], vPoint[3]));
		vLine.push_back(LineEx(vPoint[3], vPoint[0]));
		return vLine;
	}

	//문서형태에 따라 크기를 갱신한다.
	void updateSizeOutByDocFormat(int nDocFormat, float & width, float & height)
	{
		float v1 = 0.05f, v2;

		if (nDocFormat == 1000)
		{
			nDocFormat = 2;
			v1 = 1.0;
		}

		if (nDocFormat <= 2)
		{
			v2 = common::docsize::kWH((CDocFormat)nDocFormat);
			if (fabsf(width / height - v2) / v2 <= v1)
				height = width / v2;
		}
	}

	//문서형태에 따라 크기를 갱신한다.
	void updateSizeOutByDocFormat(DocumentCandidate & docCan)
	{
		updateSizeOutByDocFormat(docCan.m_nDocType, docCan.m_xDocSize.width, docCan.m_xDocSize.height);
	}

	//DocumentCandidate를 초기화한다.
	void initResult(tagSIZE & xSize, int nDocFormat, DocumentCandidate & docCan)
	{
		docCan.m_nDocType = nDocFormat;
		docCan.m_rAngleDC = 0.0;
		docCan.m_xDocSize.width = (float)xSize.cx;
		docCan.m_xDocSize.height = (float)xSize.cy;
		docCan.m_xCenterDC = Point2f(xSize.cx * 0.5f, xSize.cy * 0.5f);
		docCan.m_vCornerDC.resize(4);
		docCan.m_vCornerDC[0] = Point2f(0.0f, 0.0f);
		docCan.m_vCornerDC[1] = Point2f((float)xSize.cx - 1, 0.0f);
		docCan.m_vCornerDC[2] = Point2f((float)xSize.cx - 1, (float)xSize.cy - 1);
		docCan.m_vCornerDC[3] = Point2f(0.0f, (float)xSize.cy - 1);
	}

	//DocumentCandidate를 초기화한다.
	void initResult90(tagSIZE & xSize, int nDocFormat, DocumentCandidate & docCan)
	{
		docCan.m_nDocType = nDocFormat;
		docCan.m_rAngleDC = 90.0;
		docCan.m_xDocSize.width = (float)xSize.cx;
		docCan.m_xDocSize.height = (float)xSize.cy;
		docCan.m_vCornerDC.resize(4);
		docCan.m_vCornerDC[0] = Point2f((float)xSize.cx, 0.0f);
		docCan.m_vCornerDC[1] = Point2f((float)xSize.cx, (float)xSize.cy);
		docCan.m_vCornerDC[2] = Point2f(0.0f, (float)xSize.cy);
		docCan.m_vCornerDC[3] = Point2f(0.0f, 0.0f);
	}

	//DocumentCandidate를 자동초기화한다.
	void initResultAutoWH(tagSIZE & xSize, int nDocFormat, DocumentCandidate & docCan)
	{
		if (xSize.cx >= xSize.cy)
			initResult(xSize, nDocFormat, docCan);
		else
			initResult90(xSize, nDocFormat, docCan);
	}

	//DocumentCandidate를 2개의 ID3형식으로 가른다.
	int splitID3x2(DocumentCandidate & docCan, TBoundsResult & xResult1, TBoundsResult & xResult2)
	{
		float fAngle;

		if (docCan.m_nDocType != 5)
			return 1;

		xResult1.nTBR_docFormat = 2;
		xResult1.nTBR_Width = (int)docCan.m_xDocSize.height;
		xResult1.nTBR_Height = (int)(docCan.m_xDocSize.width * 0.5f);
		xResult1.rTBR_Angle = docCan.m_rAngleDC;
		xResult1.xTBR_RightTop.x = (int)docCan.m_vCornerDC[1].x;
		xResult1.xTBR_RightTop.y = (int)docCan.m_vCornerDC[1].y;
		xResult1.xTBR_RightBottom.x = (int)docCan.m_vCornerDC[0].x;
		xResult1.xTBR_RightBottom.y = (int)docCan.m_vCornerDC[0].y;
		xResult1.xTBR_LeftTop.x = (int)docCan.m_vCornerDC[2].x;
		xResult1.xTBR_LeftTop.y = (int)docCan.m_vCornerDC[2].y;
		xResult1.xTBR_LeftBottom.x = (int)docCan.m_vCornerDC[3].x;
		xResult1.xTBR_LeftBottom.y = (int)docCan.m_vCornerDC[3].y;
		memcpy(&xResult2, &xResult1, sizeof(TBoundsResult));

		xResult1.xTBR_RightTop.x = (int)((docCan.m_vCornerDC[0].x + docCan.m_vCornerDC[1].x) / 2);
		xResult1.xTBR_RightTop.y = (int)((docCan.m_vCornerDC[0].y + docCan.m_vCornerDC[1].y) / 2);
		xResult1.xTBR_LeftTop.x = (int)((docCan.m_vCornerDC[2].x + docCan.m_vCornerDC[3].x) / 2);
		xResult1.xTBR_LeftTop.y = (int)((docCan.m_vCornerDC[2].y + docCan.m_vCornerDC[3].y) / 2);

		fAngle = -180.0;

		if (xResult2.rTBR_Angle < 0.0)
			fAngle = 180.0;

		xResult2.xTBR_RightBottom = xResult2.xTBR_LeftTop;
		xResult2.xTBR_LeftBottom = xResult2.xTBR_RightTop;
		xResult2.xTBR_RightTop = xResult1.xTBR_LeftTop;
		xResult2.xTBR_LeftTop = xResult1.xTBR_RightTop;

		xResult2.rTBR_Angle += fAngle;

		return 0;
	}

	//네구석점으로부터 TBoundsResult값을 초기화한다.(크기, 형태 등)
	void initCorners(TBoundsResult & result, vector<Point2f> & vPoint)
	{
		DocumentCandidate docCan;
		vector<LineEx> vLine;
		vector<float> vAngle;
		float fWidth, fHeight;
		bool bX, bY;

		docCan.m_vCornerDC.assign(vPoint.begin(), vPoint.end());
		docCan.m_nDocType = result.nTBR_docFormat;
		DocumentCandidate::documentSize(docCan.m_vCornerDC, fWidth, fHeight, docCan.m_xCenterDC, bY, bX);
		docCan.m_xDocSize.width = fWidth;
		docCan.m_xDocSize.height = fHeight;

		if (fHeight > fWidth && docCan.m_nDocType != 5)
			docCan.cornersDocumentInvHW();

		vLine = getLines(docCan.m_vCornerDC);
		LineExProcess::initLinesAngle(vLine);
		LineExProcess::calcLen(vLine);

		vAngle.assign(vLine.size(), 0);
		for (uint i = 0; i < vLine.size(); i++)
			vAngle.push_back((float)vLine[i].m_rLineAngle);

		docCan.m_rAngleDC = DocumentCandidate::calcAngleBySides(vAngle);

		if (bX)
			docCan.m_rAngleDC = bounds::lines::calcAngleWLines(vLine) + 180.0f;

		DocumentCandidate::checkInternalAngle(vAngle, docCan.m_rIntAngle, docCan.m_rSumIntAngle);
		bounds::boundsresult::convertInv(docCan, result);
	}
}

//bounds.ini화일에서 설정정보들을 읽어 저장한다.
namespace boundsini {
	void loadFromJson(Json::Value & a1, DocumentDetectionParameter & a2)
	{
		Json::Value vMember(0), vTemp(0);
		string strTemp;
		Json::ValueIteratorBase begin, end;

		if (a1.isMember("ThresholdBin"))
		{
			vMember = a1.get("ThresholdBin", Json::Value(0));
			a2.m_nThresholdBin = vMember.asInt();
		}

		if (a1.isMember("ContourType"))
		{
			vMember = a1.get("ContourType", Json::Value(0));
			a2.m_nContourType = vMember.asInt();
		}

		if (a1.isMember("WorkW"))
		{
			vMember = a1.get("WorkW", Json::Value(0));
			a2.m_nWorkW = vMember.asInt();
		}

		if (a1.isMember("WorkDPI"))
		{
			vMember = a1.get("WorkDPI", Json::Value(0));
			a2.m_nWorkDPI = vMember.asInt();
		}

		if (a1.isMember("AverContour"))
		{
			vMember = a1.get("AverContour", Json::Value(0));
			a2.m_rAverContour = (float)vMember.asDouble();
		}

		if (a1.isMember("FullDocDiffReady"))
		{
			vMember = a1.get("FullDocDiffReady", Json::Value(0));
			a2.m_rFullDocDiff = (float)vMember.asDouble();
		}

		if (a1.isMember("RemoveBorderLine"))
		{
			vMember = a1.get("RemoveBorderLine", Json::Value(0));
			a2.m_nRemoveBorderLine = vMember.asInt();
		}

		if (a1.isMember("OnlyDocFromIni"))
		{
			vMember = a1.get("OnlyDocFromIni", Json::Value(1));
			a2.m_bOnlyDocFromIni = vMember.asBool();
		}

		if (a1.isMember("PerspectiveTr"))
		{
			vMember = a1.get("PerspectiveTr", Json::Value(0));
			a2.m_bPerspectiveTr = vMember.asBool();
		}

		if (a1.isMember("AngleRange"))
		{
			vMember = a1.get("AngleRange", Json::Value(0));
			a2.m_rAngleRange = (float)vMember.asDouble();
		}

		if (a1.isMember("FullImageAnalyzeOff"))
		{
			vMember = a1.get("FullImageAnalyzeOff", Json::Value(1));
			a2.m_bFullImgAnalOff = vMember.asBool();
		}

		if (a1.isMember("ROIFlag"))
		{
			vMember = a1.get("ROIFlag", Json::Value(0));
			a2.m_nROIFlag = vMember.asInt();
		}

		if (a2.m_nROIFlag)
		{
			if (a1.isMember("ROIX1"))
			{
				vMember = a1.get("ROIX1", Json::Value(0));
				a2.m_nROIX1 = vMember.asInt();
			}

			if (a1.isMember("ROIY1"))
			{
				vMember = a1.get("ROIY1", Json::Value(0));
				a2.m_nROIY1 = vMember.asInt();
			}

			if (a1.isMember("ROIX2"))
			{
				vMember = a1.get("ROIX2", Json::Value(0));
				a2.m_nROIX2 = vMember.asInt();
			}

			if (a1.isMember("ROIY2"))
			{
				vMember = a1.get("ROIY2", Json::Value(0));
				a2.m_nROIY2 = vMember.asInt();
			}
		}

		if (a1.isMember("DocDeviation"))
		{
			vMember = a1.get("DocDeviation", Json::Value(0));
			a2.m_rDocDeviation = (float)vMember.asDouble();
		}

		if (a1.isMember("DocDeviationLast"))
		{
			vMember = a1.get("DocDeviationLast", Json::Value(0));
			a2.m_rDocDeviationLast = (float)vMember.asDouble();
		}

		if (a1.isMember("MinLenghtLineForDetect"))
		{
			vMember = a1.get("MinLenghtLineForDetect", Json::Value(0));
			a2.m_rMinLengthLineForDetect = (float)vMember.asDouble();
		}

		if (a1.isMember("MinLinesLengthForContour"))
		{
			vMember = a1.get("MinLinesLengthForContour", Json::Value(0));
			a2.m_rMinLinesLengthForContour = (float)vMember.asDouble();
		}

		if (a1.isMember("LineDistForUnion"))
		{
			vMember = a1.get("LineDistForUnion", Json::Value(0));
			a2.m_rLineDistForUnion = (float)vMember.asDouble();
		}

		if (a1.isMember("MinProbByProportion"))
		{
			vMember = a1.get("MinProbByProportion", Json::Value(0));
			a2.m_rMinProbByProportion = (float)vMember.asDouble();
		}

		if (a1.isMember("MinProbBySize"))
		{
			vMember = a1.get("MinProbBySize", Json::Value(0));
			a2.m_rMinProbBySize = (float)vMember.asDouble();
		}

		if (a1.isMember("MinProbBySizeCalcProb"))
		{
			vMember = a1.get("MinProbBySizeCalcProb", Json::Value(0));
			a2.m_rMinProbBySizeCalcProb = (float)vMember.asDouble();
		}

		if (a1.isMember("FullDocumentDetectOnly"))
		{
			vMember = a1.get("FullDocumentDetectOnly", Json::Value(0));
			a2.m_bFullDocumentDetectOnly = vMember.asBool();
		}

		if (a1.isMember("FullDocumentDetectDevMax"))
		{
			vMember = a1.get("FullDocumentDetectDevMax", Json::Value(0));
			a2.m_rFullDocumentDetectDevMax = (float)vMember.asDouble();
		}

		if (a1.isMember("kMinDocSizebyWHImg"))
		{
			vMember = a1.get("kMinDocSizebyWHImg", Json::Value(0));
			a2.m_rkMinDocSizebyWHImg = (float)vMember.asDouble();
		}

		if (a1.isMember("kMinSideSize"))
		{
			vMember = a1.get("kMinSideSize", Json::Value(0));
			a2.m_rkMinSideSize = (float)vMember.asDouble();
		}

		if (a1.isMember("LineHelpStart"))
		{
			vMember = a1.get("LineHelpStart", Json::Value(0));
			a2.m_rLineHelpStart = (float)vMember.asDouble();
		}

		if (a1.isMember("LineHelpStop"))
		{
			vMember = a1.get("LineHelpStop", Json::Value(0));
			a2.m_rLineHelpStop = (float)vMember.asDouble();
		}

		if (a1.isMember("MultiPages"))
		{
			vMember = a1.get("MultiPages", Json::Value(0));
			a2.m_nMultiPages = vMember.asInt();
		}

		if (a1.isMember("CheckWithBorder"))
		{
			vMember = a1.get("CheckWithBorder", Json::Value(0));
			a2.m_nCheckWithBorder = vMember.asInt();
		}

		if (a1.isMember("UseVDAsMainResult"))
		{
			vMember = a1.get("UseVDAsMainResult", Json::Value(0));
			a2.m_nUseVDAsMainResult = vMember.asInt();
		}

		if (a1.isMember("UseMRZForFilterCandidate"))
		{
			vMember = a1.get("UseMRZForFilterCandidate", Json::Value(0));
			a2.m_nUseMRZForFilterCandidate = vMember.asInt();
		}

		if (a1.isMember("UseMRZForFilterCandidate2"))
		{
			vMember = a1.get("UseMRZForFilterCandidate2", Json::Value(0));
			a2.m_nUseMRZForFilterCandidate2 = vMember.asInt();
		}

		if (a1.isMember("UseMRZForCrop"))
		{
			vMember = a1.get("UseMRZForCrop", Json::Value(0));
			a2.m_bUseMRZForCrop = vMember.asBool();
		}

		if (a1.isMember("UseFreeIntAngle"))
		{
			vMember = a1.get("UseFreeIntAngle", Json::Value(0));
			a2.m_nUseFreeIntAngle = vMember.asInt();
		}

		if (a1.isMember("MaxDevIntAngleForRectObj"))
		{
			vMember = a1.get("MaxDevIntAngleForRectObj", Json::Value(0));
			a2.m_nMaxDevIntAngleForRectObj = vMember.asInt();
		}

		if (a1.isMember("CalcProb_LINE_CONTOUR"))
		{
			vMember = a1.get("CalcProb_LINE_CONTOUR", Json::Value(0));
			a2.m_rCalcProb_LINE_CONTOUR = vMember.asFloat();
		}

		if (a1.isMember("CalcProb_LINE_INSIDE"))
		{
			vMember = a1.get("CalcProb_LINE_INSIDE", Json::Value(0));
			a2.m_rCalcProb_LINE_INSIDE = vMember.asFloat();
		}

		if (a1.isMember("CalcProb_MRD_DIST_2"))
		{
			vMember = a1.get("CalcProb_MRD_DIST_2", Json::Value(0));
			a2.m_rCalcProb_MRD_DIST_2 = vMember.asFloat();
		}

		if (a1.isMember("CalcProb_MRD_DIST_4"))
		{
			vMember = a1.get("CalcProb_MRD_DIST_4", Json::Value(0));
			a2.m_rCalcProb_MRD_DIST_4 = vMember.asFloat();
		}

		if (a1.isMember("CalcProb_changingDPI"))
		{
			vMember = a1.get("CalcProb_changingDPI", Json::Value(0));
			a2.m_fCalcProb_changingDPI = (vMember.asInt() != 0) ? true : false;
		}

		if (a1.isMember("CalcProb_changingDPI_MinProbBySize"))
		{
			vMember = a1.get("CalcProb_changingDPI_MinProbBySize", Json::Value(0));
			a2.m_rCalcProb_changingDPI_MinProbBySize = vMember.asFloat();
		}

		if (a1.isMember("ActiveGroups"))
		{
			vMember = a1.get("ActiveGroups", Json::Value("BaseID"));
			strTemp = vMember.asString();
			a2.m_vActiveGroups = common::StringUtils::Split(strTemp, ',');
		}

		if (a1.isMember("Process"))
		{
			a2.m_vProcess.clear();
			vMember = Json::Value(a1["Process"]);
			begin = vMember.begin();
			end = vMember.end();

			while (begin != end)
			{
				vTemp = begin.deref();
				strTemp = vTemp.get("Name", Json::Value("")).asString();
				a2.m_vProcess.push_back(common::UnicodeUtils::Utf8ToWStr(strTemp));
				begin.increment();
			}
		}
	}

	void loadFromJson(Json::Value & a1, DocumentDetectionParameters & a2)
	{
		Json::ValueIteratorBase begin, end;
		string strName;
		DocumentDetectionParameter docDetectDefMode;
		int nDevieID;

		Json::Value vConfig(a1["BoundsDeviceModes"]);
		begin = vConfig.begin();
		end = vConfig.end();

		while (begin != end)
		{
			Json::Value vMember(begin.deref());
			nDevieID = vMember["deviceID"].asInt();
			a2.m_mDeviceIdWM[nDevieID] = vMember["WorkMode"].asString();
			begin.increment();
		}

		docDetectDefMode.initByDef();
		loadFromJson(Json::Value(a1["BoundsWorkDefMode"]), docDetectDefMode);
		a2.sefDefParam(docDetectDefMode);

		vConfig = Json::Value(a1["BoundsWorkModes"]);
		begin = vConfig.begin();
		end = vConfig.end();

		while (begin != end)
		{
			Json::Value vMember(begin.deref());
			strName = vMember["Name"].asString();
			DocumentDetectionParameter docDetectWorkModes(docDetectDefMode);

			if (vMember.isMember("params"))
				loadFromJson(Json::Value(vMember["params"]), docDetectWorkModes);

			a2.add(strName, docDetectWorkModes);
			begin.increment();
		}
	}

	void loadFromJson(Json::Value & a1, ProcessVariant & a2)
	{
		Json::ValueIteratorBase begin, end;
		wstring wstrTemp;
		string strTemp;
		eBinProcessImg nImageType;
		eBinProcess nImageAngle;

		if (a1.isMember("Param"))
		{
			Json::Value vParam(a1["Param"]);
			//if (vParam.isMember("OnlyFirstAngle"))
			//	vMember = vParam.get("OnlyFirstAngle", Json::Value(0));

			if (vParam.isMember("KLineLenFilter"))
			{
				a2.m_rKLineLenFilter = (float)vParam.get("KLineLenFilter", Json::Value(0)).asDouble();
			}

			if (vParam.isMember("ProcessType"))
			{
				a2.m_nProcessType = vParam.get("ProcessType", Json::Value(0)).asInt();
			}
		}

		if (a1.isMember("imgType"))
		{
			a2.m_veBPI.clear();
			Json::Value vParam(a1["imgType"]);
			begin = vParam.begin();
			end = vParam.end();
			while (begin != end)
			{
				strTemp = begin.deref().get("name", Json::Value("")).asString();
				nImageType = convertImgType(common::UnicodeUtils::Utf8ToWStr(strTemp));
				a2.m_veBPI.push_back(nImageType);
				begin.increment();
			}
		}

		if (a1.isMember("imgAlg"))
		{
			a2.m_veBP.clear();
			Json::Value vParam(a1["imgAlg"]);
			begin = vParam.begin();
			end = vParam.end();
			while (begin != end)
			{
				strTemp = begin.deref().get("name", Json::Value("")).asString();
				nImageAngle = convertImgProcess(common::UnicodeUtils::Utf8ToWStr(strTemp));
				a2.m_veBP.push_back(nImageAngle);
				begin.increment();
			}
		}
	}

	void loadFromJson(Json::Value & a1, ProcessVariantsStore & a2)
	{
		Json::ValueIteratorBase begin, end;
		string strName;
		wstring wstrName;

		Json::Value vConfig(a1["BoundsProcessModes"]);
		begin = vConfig.begin();
		end = vConfig.end();

		while (begin != end)
		{
			ProcessVariant proVariant;
			Json::Value vMember(begin.deref());
			strName = vMember["Name"].asString();
			loadFromJson(vMember, proVariant);
			a2.m_mapPV[common::UnicodeUtils::Utf8ToWStr(strName)] = proVariant;
			begin.increment();
		}
	}
}

/*-----------------------------------Start Bounds----------------------------------------*/
Bounds::Bounds()
{
}

Bounds::~Bounds()
{
}

//지령목록을 얻는다.
vector<int> Bounds::getCommands()
{
	static vector<int> v1 = { 0x2FAD, 0x2FB1, 0x209, 0xCD, 0xD1, 0x1F5, 0x204, 0x1FF, 0x200, 0x202, 0x208, 0x20A, 0x20B, 0x20C, 0x207, 0x206 };
	return v1;
}

//해당한 지령에 대한 처리를 진행한다.
int Bounds::process(int a1, void * a2, const char * a3, void ** a4, char** a5)
{
	Json::Value vConfig(Json::json_type_null), vMember(Json::json_type_null), vTemp(Json::json_type_null);
	int nResult = 0;
	CResultContainerListR * pContainerList;
	RclHolder rclHoder;
	string str;
	tagSIZE size;
 	TResultContainerList* pRCL = (TResultContainerList*)a2;

	switch (a1)
	{
	case 0x1F5:
		m_xBoundsInternal.m_xuseDpiFromImage["OnlyDocFromIni"] = Json::Value(a2 ? true : false);
		break;
	case 0x1F6:
	case 0x1F7:
	case 0x1F8:
	case 0x1F9:
	case 0x1FA:
	case 0x1FB:
	case 0x1FC:
	case 0x1FD:
	case 0x1FE:
	case 0x201:
	case 0x203:
	case 0x205:
		nResult = 1;
		break;
	case 0x1FF:
		nResult = detectDoc(*(CResultContainerListR*)pRCL, common::container::jsoncpp::convert(a3), (TResultContainerList**)a4);
		break;
	case 0x200:
	case 0x206:
		nResult = locateDocOnePage(*pRCL);
		break;
	case 0xCD:
	case 0x202:
		init(pRCL);
		break;
	case 0x204:
		pContainerList = 0;
		nResult = detectDoc(*(CResultContainerListR*)pRCL, common::container::jsoncpp::convert(a3), (TResultContainerList**)&pContainerList);
		if (pContainerList && pContainerList->count())
		{
			*a4 = pContainerList->container(0)->internalPointer();
		}
		break;
	case 0x207:
		m_xBounds_field_4EC.clear();
		rclHoder.addNoCopy(*pRCL);
		nResult = locateDoc(rclHoder, m_xBounds_field_4EC);
		if (a4)
			*a4 = &m_xBounds_field_4EC;
		break;
	case 0x208:
		break;
	case 0x209:
		m_xBoundsInternal.m_nSaveImage = a2 ? 1 : 0;
		break;
	case 0x20A:
		if (a3)
			str.assign(a3, strlen(a3));
		m_xBoundsInternal.setAdditionalDocGroups(str);
		break;
	case 0x20B:
		vConfig = common::container::jsoncpp::convert(a3);
		size = rclhelp::imageSize(*pRCL);
		vMember = Json::Value(vConfig["boundsParam"]);

		if (!vConfig.isNull())
		{
			Size sz;
			sz.width = size.cx;
			sz.height = size.cy;
			bounds::face::convertFaceDetectResultFromiOS(vConfig, vMember, sz);
		}
		vTemp = Json::Value(vConfig["processParam"]["customParams"]["boundsParam"]);

		if (vTemp.isMember("checkVariants"))
			vMember["checkVariants"] = Json::Value(vTemp["checkVariants"]);

		if (vMember.isMember("processMode"))
			vMember["processMode"] = Json::Value("BoundsMode_NoDPI_Perspective_Mobile");

		if (vMember["processMode"].asString() != "FullImage")
			vMember["fullFrameAsDefault"] = Json::Value(false);

		vConfig["boundsParam"] = Json::Value(vMember);
		nResult = processSeries(a2, vConfig, a4, a5);
		break;
	case 0x20C:
		nResult = locatePoints(*pRCL);
		break;
	case 0x2FAD:
	case 0x2FB1:
		startNewSession();
		break;
	case 0xD1:
		setModulesParams(a3);
		break;
	default:
		nResult = 1;
		break;
	}

	return BoundsNS::Error::checkCodeError(nResult);
}

int Bounds::processSeries(void * a1, Json::Value & a2, void ** a3, char ** a4)
{
	Json::Value vMember(0), vTemp(0);
	RclHolder rclCheck;
	TResultContainerList * containerList;
	vector<TResultContainer*> vResult;
	vector<float> vFloat;
	string strTemp;
	int nResult, nDetectRet;
	int a;
	bool bFlag;
	float c;

	if (m_bStartNewSession)
		startNewSession();

	vMember = a2["boundsParam"].get("fullFrameAsDefault", Json::Value(false));
	bFlag = vMember.asBool();

	nDetectRet = detectDoc(*(CResultContainerListR*)a1, a2, &containerList);

	a = 2;
	if (bFlag)
		a = 1;

	c = 0.2f;
	if (m_nBField_4E8 < a)
		c = 0.1f;


	if (nDetectRet || !containerList || containerList->nTRCL_Count == 0)
	{
		m_xBoundsInternal.m_xBIHolder_490.clear();
		m_nBField_4E8 = 0;
		nResult = -20607;
	}
	else
	{
		if (m_xBoundsInternal.m_xBIHolder_490.empty())
		{
			m_xBoundsInternal.m_xBIHolder_490.addCopy(containerList);
			nResult = -20607;
			m_nBField_4E8++;
		}
		else
		{
			rclCheck.addNoCopy(containerList);
			if (BoundsResult::checkResult(m_xBoundsInternal.m_xBIHolder_490, rclCheck, c))
				m_nBField_4E8 = 0;
			else
				m_nBField_4E8++;

			m_xBoundsInternal.m_xBIHolder_490.clear();
			m_xBoundsInternal.m_xBIHolder_490.addCopy(rclCheck.getRcList(85));
			nResult = -20607;
		}
	}


	if (m_nBField_4E8 < a)
	{
		if (!m_xBoundsInternal.m_xBIBoundsState.m_nBoundsState_field_24)
			return nResult;
		else
		{
			rclCheck.addNoCopy(containerList);
			vResult = rclCheck.getRcList(85);

			for (uint i = 0; i < vResult.size(); i++)
			{
				TBoundsResult * boundsResult = vResult[i]->u.pTRC_TBR;
				boundsResult->cTBR_ResultStatus |= 1;
			}

			if (!vResult.empty() && MRZAnalyze::isVisaID2(*(TResultContainerList *)a1))
			{
				vFloat.push_back(0.05f);
				vFloat.push_back(0.0f);
				vFloat.push_back(0.05f);
				vFloat.push_back(0.1f);
				bounds::visa::updateVisaID2Result(*(TResultContainerList*)a1, *vResult[0]->u.pTRC_TBR, vFloat);
			}

			if (a4)
			{
				vTemp["Result"] = Json::Value(1);
				common::container::jsoncpp::convert(vTemp, strTemp);
				*a4 = (char *)strTemp.c_str();

			}

			if (a3)
				*a3 = containerList;
		}
	}
	return nResult;
}

void Bounds::setModulesParams(char const* szModuleParam)
{
	if (szModuleParam)
	{
		Json::Value vParam(Json::json_type_null);
		string strParam(szModuleParam);

		if (common::container::jsoncpp::convert(strParam, vParam))
			m_xBoundsInternal.m_xModuleParam = Json::Value(vParam);
	}
}

void Bounds::startNewSession()
{
	m_nBField_4E8 = 0;
	m_bStartNewSession = 0;
	m_xBoundsInternal.m_vBITBoundsResult_210.clear();
	m_xBoundsInternal.m_xBIHolder_490.clear();
	m_xBoundsInternal.m_xBIBoundsState.reset();
}

int Bounds::init(TResultContainerList * pContainerList)
{
	string strIniName("Bounds.ini");
	string strFileContent;
	Json::Value vFile(Json::json_type_null), vConfig(Json::json_type_null), vMember(Json::json_type_null);
	map<string, vector<pair<int, DocumentSize::TDocSize>>> mapMember;
	DocumentSize::DocumentIDCheck * docIdCheck;
	DocumentDetectionParameter detectParam;

	common::resources::getFile(pContainerList, strIniName, strFileContent);
	
	if (!strFileContent.size())
		return 2;
	
	if (common::container::jsoncpp::convert(strFileContent, vFile))
		return 2;
		
	if (vFile.isMember("DocFormats"))
	{
		vMember = Json::Value(vFile["DocFormats"])["Groups"];
		Json::convert(vMember, mapMember);
		docIdCheck = m_xBoundsInternal.m_xBIDocDetect.docCheck();
		docIdCheck->initGroups(mapMember);
	}

	boundsini::loadFromJson(vFile, m_xBoundsInternal.m_xBIDocDetectParams);
	boundsini::loadFromJson(vFile, m_xBoundsInternal.m_mBIProcVariant);

	m_xBoundsInternal.m_strDefWorkMode.assign("BoundsWorkDefMode");
	detectParam = m_xBoundsInternal.m_xBIDocDetectParams.param(m_xBoundsInternal.m_strDefWorkMode);
	m_xBoundsInternal.m_xBIDocDetect.m_xDocDTParam.initParameter(detectParam);

	vConfig = Json::Value(vFile["Main"]);
	vMember = vConfig.get("SaveImage", Json::Value(0));
	m_xBoundsInternal.m_nSaveImage = vMember.asInt();
	vMember = vConfig.get("maxWorkTimeMs", Json::Value(1001));
	m_xBoundsInternal.m_nmaxWorkTimeMs = vMember.asInt();
	vMember = vConfig.get("GenerateTestSample", Json::Value(false));
	m_xBoundsInternal.m_bGenerateTestSample = vMember.asBool();
	vMember = vConfig.get("deviceIDDebug", Json::Value(0));
	m_xBoundsInternal.m_ndeviceIDDebug = vMember.asInt();
	vMember = vConfig.get("isNeedUpdateDPI", Json::Value(0));
	m_xBoundsInternal.m_bisNeedUpdateDPI = vMember.asBool();
	vMember = vConfig.get("maxImageSizeInPix", Json::Value(30000000));
	m_xBoundsInternal.m_nmaxImageSizeInPix = vMember.asInt();
	vMember = vConfig.get("useDpiFromImage", Json::Value(0));
	m_xBoundsInternal.m_xuseDpiFromImage["useDpiFromImage"] = Json::Value(vMember.asInt());

	if (m_xBoundsInternal.m_nSaveImage)
		m_xBoundsInternal.m_nmaxWorkTimeMs = 1000000000;

	m_nBField_4E8 = 0;
	m_bStartNewSession = 1;

	return 0;
}

//장치ID와 데바그정보에 대한 초기화를 진행한다.
void Bounds::initModuleForRequest(RclHolder & rclHolder)
{
	DocumentDetectDebugInfo * debugInfo;

	if (rclHolder.getRcList(82).empty())
	{
		bounds::docteachersupport::addDeviceTypeFromSamplePath(rclHolder);
		if (m_xBoundsInternal.m_ndeviceIDDebug)
			bounds::testmodesupport::addDeviceType(rclHolder, m_xBoundsInternal.m_ndeviceIDDebug);
	}

	bounds::testmodesupport::updateSaveImageStatus(m_xBoundsInternal.m_strBoundsInternal_field_1F0, m_xBoundsInternal.m_nSaveImage);

	if (m_xBoundsInternal.m_nSaveImage)
	{
		debugInfo = bounds::debug::dddiFull();
		debugInfo->init(rclHolder, 1.0);
	}
}

//문서를 검출한다.
int Bounds::detectDoc(CResultContainerListR & a1, Json::Value & jstr_a2, TResultContainerList ** a3)
{
	tagSIZE size;
	tagRECT rect;
	RclHolder rclContainer, rclPage;
	vector<int> vPages;
	vector<TResultContainer *> vResult;
	vector<shared_ptr<RclHolder>> vHolder;
	vector<DocumentCandidate> vDocument;
	Json::Value vRet(0);
	string strPath;
	bool bRet;
	int nResult, nFlag;

	size = ResultContainerListNS::imageSize(a1);
	nResult = -3001;
	if (size.cx && size.cy)
	{
		m_xBoundsInternal.m_xBIBoundsParam = Json::Value(jstr_a2["boundsParam"]);
		m_xBoundsInternal.m_xBIFaceInfo.clear();

		/*-----------------------------------------no------------------------------------*/
		if (m_xBoundsInternal.m_xBIBoundsParam.isMember("FaceRect"))
		{
			common::container::jsoncpp::convert(Json::Value(m_xBoundsInternal.m_xBIBoundsParam["FaceRect"]), rect, m_xBoundsInternal.m_xBIFaceInfo.m_bFIClear);

			if (rect.left >= 0 || rect.bottom >= 0 || rect.right <= size.cx || rect.top <= size.cy)
				m_xBoundsInternal.m_xBIFaceInfo.setRect(rect);
			else
				m_xBoundsInternal.m_xBIFaceInfo.clear();
		}

		rclContainer.addNoCopy(a1);

		vector<int> vContainer = { 1, 3, 7, 0x57 };
		vHolder = rclhelp::splitByContainerType(rclContainer, vContainer);

		if (vHolder.size() == 2)
		{
			vPages = rclhelp::getPages(vHolder[0].get()->m_xTRCL);
			m_xBoundsInternal.m_xBoundsInternal_field_1FC.clear();

			
			for (uint i = 0; i < vPages.size(); i++)
			{
				m_xBoundsInternal.m_vBITBoundsResult_210.clear();
				rclPage.addNoCopy(vHolder[0].get()->getRcListByPage(vPages[i]));
				rclPage.addNoCopy(vHolder[1].get()->m_xTRCL);
				rclPage.setPageIndex(vPages[i]);
				initModuleForRequest(rclPage);
				m_xBoundsInternal.detectDoc(rclPage.m_xTRCL, jstr_a2);

				m_xBoundsInternal.updateResultsParam(m_xBoundsInternal.m_vBITBoundsResult_210, size);
				
				if (m_xBoundsInternal.m_xBIBoundsState.m_xBoundsState_field_10.empty())
				{
					vRet = m_xBoundsInternal.m_xBIBoundsParam.get("fullFrameAsDefault", Json::Value(1));

					if (vRet.asBool())
						bRet = m_xBoundsInternal.m_vBITBoundsResult_210.empty();
					else
					{
						vRet = jstr_a2["processParam"].get("alreadyCropped", Json::Value(0));
						if (vRet.asBool())
							bRet = m_xBoundsInternal.m_vBITBoundsResult_210.empty();
						else
							bRet = false;
					}

					if (bRet)
					{
						m_xBoundsInternal.m_rBIk = 1.0;
						vDocument.push_back(m_xBoundsInternal.m_xBIDocCan);
						m_xBoundsInternal.createResultList(vDocument, 0, m_xBoundsInternal.m_rBIk, 0, m_xBoundsInternal.m_vBITBoundsResult_210, 0);
						nFlag = 1;
						m_xBoundsInternal.m_xBIBoundsState.m_nBoundsState_field_24 = 1;
					}
					else
						nFlag = 0;

					for (uint j = 0; j < m_xBoundsInternal.m_vBITBoundsResult_210.size(); j++)
					{
						if (!nFlag && MRZAnalyze::isVisaID2(rclPage.m_xTRCL))
						{
							vector<float> vVisa = { 0.05f, 0.0f, 0.05f, 0.1f };
							bounds::visa::updateVisaID2Result(rclPage.m_xTRCL, m_xBoundsInternal.m_vBITBoundsResult_210[j], vVisa);
						}

						m_xBoundsInternal.m_xBoundsInternal_field_1FC.addNewCopy<TBoundsResult>(85, &m_xBoundsInternal.m_vBITBoundsResult_210[j], 0);
					}
				}
				else if (i == vPages.size() - 1)
				{
					vResult = m_xBoundsInternal.m_xBIBoundsState.m_xBoundsState_field_10.getRcList();
					m_xBoundsInternal.m_xBoundsInternal_field_1FC.addNoCopy(vResult);
				}
				else
				{
					m_xBoundsInternal.m_xBoundsInternal_field_1FC.addCopy(m_xBoundsInternal.m_xBIBoundsState.m_xBoundsState_field_10.m_xTRCL);
					m_xBoundsInternal.m_xBIBoundsState.reset();
				}
				
			}
			
			if (a3)
				*a3 = &m_xBoundsInternal.m_xBoundsInternal_field_1FC.m_xTRCL;
			
			vResult = rclContainer.getRcList(69);
			
			if (m_xBoundsInternal.m_bGenerateTestSample || !vResult.empty())
			{
				common::fs::Path path("c:/RD/");
				strPath = common::fs::generateTimeFolderName(path);
				bounds::docteachersupport::saveSampleAsImages(rclContainer, strPath);
			}
			
			/*RclHolder rclTemp;
			string strTemp;
			rclTemp.addNoCopy(m_xBoundsInternal.m_xBoundsInternal_field_1FC.m_xTRCL);
			strTemp = rclTemp.toJson();
			bounds::test::createTestSample(rclContainer, strTemp, strPath);*/
		}
		nResult = 0;
	}
	return nResult;
}

//TRawImage에 대한 투시, 아핀변환을 진행한다.
int Bounds::locateDocOnePage(TResultContainerList & a1)
{
	RclHolder rclHolder;
	TResultContainer * pResultContainer;
	TBoundsResult * pBoundsResult, boundsResult;
	TRawImageContainer * pRawImage;
	tagSIZE size;
	vector<TResultContainer*> vResult;
	int nResult;
	int nWidth, nHeight;
	float nX, nY;

	nResult = -20601;
	rclHolder.addNoCopy(a1);

	if (!rclHolder.empty())
	{
		if (rclhelp::checkImagesSize(rclHolder))
		{
			pResultContainer = rclhelp::findFirstContainer(rclHolder.m_xTRCL, 85);
			if (pResultContainer)
			{
				pBoundsResult = pResultContainer->u.pTRC_TBR;
				if (pBoundsResult)
				{
					if (pBoundsResult->nTBR_Width && pBoundsResult->nTBR_Height)
					{
						size = rclhelp::imageSize(rclHolder.m_xTRCL);
						if (pBoundsResult->rTBR_Angle == 0.0 && pBoundsResult->nTBR_Width == size.cx && pBoundsResult->nTBR_Height == size.cy)
							nResult = 0;
						else
						{
							nResult = locateDoc(rclHolder, RT_TRawImageContainer_1, *pBoundsResult);
							if (!nResult)
							{
								vResult = rclHolder.getRcList(23);
								if (vResult.empty())
									nResult = 0;
								else
								{
									pRawImage = rclhelp::convertPointerToRawImage(vResult[0]);
									nWidth = pRawImage->pxRIC_bmi->bmiHeader.biWidth;
									nHeight = pRawImage->pxRIC_bmi->bmiHeader.biHeight;
									nX = (float)nWidth / size.cx;
									nY = (float)nHeight / size.cy;
									memcpy(&boundsResult, pBoundsResult, sizeof(TBoundsResult));

									boundsResult.nTBR_Width = (int)(boundsResult.nTBR_Width * nX);
									boundsResult.nTBR_Height = (int)(boundsResult.nTBR_Height * nY);
									boundsResult.xTBR_Center.x = (int)(boundsResult.xTBR_Center.x * nX);
									boundsResult.xTBR_Center.y = (int)(boundsResult.xTBR_Center.y * nY);
									boundsResult.xTBR_LeftTop.x = (int)(boundsResult.xTBR_LeftTop.x * nX);
									boundsResult.xTBR_LeftTop.y = (int)(boundsResult.xTBR_LeftTop.y * nY);
									boundsResult.xTBR_LeftBottom.x = (int)(boundsResult.xTBR_LeftBottom.x * nX);
									boundsResult.xTBR_LeftBottom.y = (int)(boundsResult.xTBR_LeftBottom.y * nY);
									boundsResult.xTBR_RightTop.x = (int)(boundsResult.xTBR_RightTop.x * nX);
									boundsResult.xTBR_RightTop.y = (int)(boundsResult.xTBR_RightTop.y * nY);
									boundsResult.xTBR_RightBottom.x = (int)(boundsResult.xTBR_RightBottom.x * nX);
									boundsResult.xTBR_RightBottom.y = (int)(boundsResult.xTBR_RightBottom.y * nY);
									boundsResult.cTBR_ObjArea = (int)(boundsResult.nTBR_Width * boundsResult.nTBR_Height);
									boundsResult.nTBR_Dpi = (int)((boundsResult.nTBR_Dpi * (nX + nY) * 0.5f));

									nResult = locateDoc(rclHolder, RT_TRawImageContainer_17, boundsResult);
								}
							}
						}
					}
				}
			}
		}
	}

	return nResult;
}

//TRawImage에 대한 투시, 아핀변환을 진행한다.
int Bounds::locateDocOnePage(RclHolder & a1, RclHolder & a2)
{
	vector<TResultContainer*> vResult, vRet;
	TRawImageContainer *pRawImage;
	tagSIZE size;
	TBoundsResult * pBoundsResult;
	TBoundsResult boundsScale;
	int nTemp, nResult;

	if (!rclhelp::checkImagesSize(a1))
		return -20601;

	size = rclhelp::imageSize(a1.m_xTRCL);
	vResult = a1.getRcList(85);

	for (uint i = 0; i < vResult.size(); i++)
	{
		pBoundsResult = vResult[i]->u.pTRC_TBR;
		if (pBoundsResult && pBoundsResult->nTBR_Width && pBoundsResult->nTBR_Height)
		{
			if (pBoundsResult->rTBR_Angle == 0.0 && pBoundsResult->nTBR_Width == size.cx && pBoundsResult->nTBR_Height == size.cy)
			{
				a2.addCopy(a1.getRcList(1));
				return 0;
			}

			nTemp = vResult[i]->nTRC_page_idx;
			if (i)
				nTemp = i + 100 * vResult[i]->nTRC_page_idx;

			if (nResult = locateDoc(a1, a2, RT_TRawImageContainer_1, *pBoundsResult, nTemp))
				break;

			vRet = a1.getRcList(23);

			if (!vRet.empty())
			{
				memset(&boundsScale, 0, sizeof(TBoundsResult));
				pRawImage = rclhelp::convertPointerToRawImage(vRet[0]);
				bounds::boundsresult::scale(*pBoundsResult, boundsScale, (float)pRawImage->pxRIC_bmi->bmiHeader.biWidth / size.cx, (float)pRawImage->pxRIC_bmi->bmiHeader.biHeight / size.cy);
				nResult = locateDoc(a1, a2, RT_TRawImageContainer_17, boundsScale, i);
			}
			else
				nResult = 0;
		}
	}

	return nResult;
}

//화상에 대하여 투시, 아핀변환을 진행한다.
int Bounds::locateDoc(RclHolder & a1, eRPRM_ResultType a2, TBoundsResult & a3)
{
	int nDpi, nFlag;
	vector<TResultContainer*> vResult1, vResult2, vResult3;
	TRawImageContainer * pRawImage1, *pRawImage2, *pRawImage3;
	Mat mat1, mat2, mat3, matDst, mat4, mat5, mat6;
	int nWidthStep1, nWidthStep2;
	
	nDpi = a3.nTBR_Dpi;
	if (!nDpi)
	{
		nDpi = m_xBoundsInternal.m_xBIDocDetect.docCheck()->docResolution(a3.nTBR_docFormat, a3.nTBR_Width, 0);
	}
	if (a3.nTBR_Width < 1 || a3.nTBR_Height <= 0)
		return -20601;
	
	vResult1 = a1.getRcList(a2, RPRM_Lights_2000000);
	nFlag = 0;
	if (!vResult1.empty())
	{
		vResult2 = a1.getRcList(a2, regula::light::whiteGroup());
		if (!vResult2.empty())
			nFlag = 1;
	}
	
	vResult3 = a1.getRcList(a2);

	for (uint i = 0; i < vResult3.size(); i++)
	{
		if (nFlag && vResult3[i]->nTRC_light == RPRM_Lights_2000000)
			continue;

		pRawImage1 = vResult3[i]->u.pTRC_RIC;
		if (!pRawImage1 || !pRawImage1->pxRIC_bmi)
			return -20601;
		
		mat1 = common::container::wrapByMat(*pRawImage1);
		nWidthStep1 = calcWidthStep(a3.nTBR_Width, ((0x48442211 >> ((mat1.flags << 2) & 0x1C)) << 3) & 0x78, ((mat1.flags >> 3) & 0x1FF) + 1, 4);
		if ((int)pRawImage1->pxRIC_bmi->bmiHeader.biSizeImage / nWidthStep1 < a3.nTBR_Height)
			return 0;
		
		Mat matDst(Size(a3.nTBR_Width, a3.nTBR_Height), mat1.flags & 0xfff);

		if (a3.cTBR_PerspectiveTr)
		{
			vector<Point2f> point1 = {
				Point2f(0.0f, 0.0f), Point2f((float)matDst.cols, 0.0f),
				Point2f((float)matDst.cols, (float)matDst.rows), Point2f(0.0f, (float)matDst.rows) };

			vector<Point2f> point2 = {
				Point2f((float)a3.xTBR_LeftBottom.x, (float)a3.xTBR_LeftBottom.y),
				Point2f((float)a3.xTBR_RightBottom.x, (float)a3.xTBR_RightBottom.y),
				Point2f((float)a3.xTBR_RightTop.x, (float)a3.xTBR_RightTop.y),
				Point2f((float)a3.xTBR_LeftTop.x, (float)a3.xTBR_LeftTop.y) };

			mat4 = getPerspectiveTransform(point2, point1);  //투시변환을 진행
			warpPerspective(mat1, matDst, mat4, Size(matDst.cols, matDst.rows));
		}
		else
		{
			mat5 = getRotationMatrix2D(Point2f((float)a3.xTBR_Center.x, (float)a3.xTBR_Center.y), a3.rTBR_Angle, 1.0);
			*(double*)&mat5.data[16] -= (float)a3.xTBR_Center.x - a3.nTBR_Width * 0.5;
			*(double*)&mat5.data[*mat5.step.p + 16] -= (float)a3.xTBR_Center.y - a3.nTBR_Height * 0.5;
			warpAffine(mat1, matDst, mat5, Size(matDst.cols, matDst.rows));   //아핀변환을 실시
		}

		pRawImage1->pxRIC_bmi->bmiHeader.biWidth = a3.nTBR_Width;
		pRawImage1->pxRIC_bmi->bmiHeader.biHeight = a3.nTBR_Height;

		if (a3.nTBR_Height * nWidthStep1 > (int)pRawImage1->pxRIC_bmi->bmiHeader.biSizeImage)
			pRawImage1->pxRIC_bmi->bmiHeader.biHeight = pRawImage1->pxRIC_bmi->bmiHeader.biSizeImage / nWidthStep1;
		pRawImage1->pxRIC_bmi->bmiHeader.biSizeImage = pRawImage1->pxRIC_bmi->bmiHeader.biHeight * nWidthStep1;

		matDst.copyTo(common::container::wrapByMat(*pRawImage1));

		if (m_xBoundsInternal.m_bGenerateTestSample && !rclhelp::deviceTypeReal(a1.m_xTRCL))
		{
			pRawImage1->pxRIC_bmi->bmiHeader.biXPelsPerMeter = nDpi;
			pRawImage1->pxRIC_bmi->bmiHeader.biYPelsPerMeter = nDpi;
		}
	}
	if (nFlag)
	{
		pRawImage2 = vResult2[0]->u.pTRC_RIC;
		if (pRawImage2)
		{
			mat2 = common::container::wrapByMat(*pRawImage2);
			for (uint i = 0; i < vResult1.size(); i++)
			{
				pRawImage3 = vResult1[i]->u.pTRC_RIC;
				nWidthStep2 = calcWidthStep(mat2.cols, 8, 1, 4);
				pRawImage3->pxRIC_bmi->bmiHeader.biWidth = mat2.cols;
				pRawImage3->pxRIC_bmi->bmiHeader.biHeight = mat2.rows;
				pRawImage3->pxRIC_bmi->bmiHeader.biSizeImage = nWidthStep2 * mat2.rows;
				pRawImage3->pxRIC_bmi->bmiHeader.biXPelsPerMeter = pRawImage2->pxRIC_bmi->bmiHeader.biXPelsPerMeter;
				pRawImage3->pxRIC_bmi->bmiHeader.biYPelsPerMeter = pRawImage2->pxRIC_bmi->bmiHeader.biXPelsPerMeter;
				cvtColor(mat2, common::container::wrapByMat(*pRawImage3), COLOR_BGR2GRAY);
			}
		}
	}
	if (m_xBoundsInternal.m_nSaveImage)
	{
		RclHolder rclHolder1;
		rclHolder1.addCopy(a1.m_xTRCL);
		string strPath = common::RegulaConfig::GetTmpPath();
		common::fs::Path path(strPath);
		string strFolder = common::fs::generateTimeFolderName(path);
		bounds::docteachersupport::saveSampleAsImages(rclHolder1, strFolder);
	}

	return 0;
}

int Bounds::locateDoc(RclHolder & a1, RclHolder & a2)
{
	vector<int> vPages = rclhelp::getPages(a1.m_xTRCL);

	for (uint i = 0; i < vPages.size(); i++)
	{
		RclHolder rclPages;
		rclPages.addNoCopy(a1.getRcListByPage(vPages[i]));
		locateDocOnePage(rclPages, a2);
	}

	return 0;
}

//page_idx에 따라 화상에 투시 아핀변한을 진행한다.
int Bounds::locateDoc(RclHolder & a1, RclHolder & a2, eRPRM_ResultType a3, TBoundsResult & a4, int a5)
{
	int nDpi, nFlag, nTemp;
		
	if (a4.nTBR_Width < 1 || a4.nTBR_Height < 1)
		return -20601;
	
	nDpi = a4.nTBR_Dpi;	
	if (!nDpi)
	{
		nDpi = m_xBoundsInternal.m_xBIDocDetect.docCheck()->docResolution(a4.nTBR_docFormat, a4.nTBR_Width, 0);
	}

	nFlag = 0;
	if (!a1.getRcList(a3, RPRM_Lights_2000000).empty())
	{
		if (!a1.getRcList(a3, regula::light::whiteGroup()).empty())
			nFlag = 1;
	}

	vector<TResultContainer *> vResult3 = a1.getRcList(a3);
			
	for (uint i = 0; i < vResult3.size(); i++)
	{
		if (nFlag && vResult3[i]->nTRC_light == RPRM_Lights_2000000)
			continue;

		TRawImageContainer * rawImage = vResult3[i]->u.pTRC_RIC;
		if (!rawImage || !rawImage->pxRIC_bmi)
			return -20601;
		
		Mat mat = wrapByMat(*rawImage);
		Mat matDst(Size(a4.nTBR_Width, a4.nTBR_Height), mat.flags & 0xfff);

		if (a4.cTBR_PerspectiveTr)
		{
			vector<Point2f> point1 = {
				Point2f(0.0f, 0.0f), Point2f((float)matDst.cols, 0.0f), Point2f((float)matDst.cols, (float)matDst.rows), Point2f(0.0f, (float)matDst.rows)
			};

			vector<Point2f> point2 = {
				Point2f((float)a4.xTBR_LeftBottom.x, (float)a4.xTBR_LeftBottom.y),
				Point2f((float)a4.xTBR_RightBottom.x, (float)a4.xTBR_RightBottom.y),
				Point2f((float)a4.xTBR_RightTop.x, (float)a4.xTBR_RightTop.y),
				Point2f((float)a4.xTBR_LeftTop.x, (float)a4.xTBR_LeftTop.y)
			};

			warpPerspective(mat, matDst, getPerspectiveTransform(point2, point1), Size(matDst.cols, matDst.rows));
		}
		else
		{
			Mat matRet = getRotationMatrix2D(Point2f((float)a4.xTBR_Center.x, (float)a4.xTBR_Center.y), a4.rTBR_Angle, 1.0);
			*(double*)&matRet.data[16] -= (float)a4.xTBR_Center.x - a4.nTBR_Width * 0.5;
			*(double*)&matRet.data[*matRet.step.p + 16] -= (float)a4.xTBR_Center.y - a4.nTBR_Height * 0.5;
			warpAffine(mat, matDst, matRet, Size(matDst.cols, matDst.rows));
		}
				
		
		unique_ptr<TRawImageContainer, TRawImageContainer*(*)(TRawImageContainer*)> uptr_rawRet = copyMatToRic(matDst);
		a2.addNewWithOwnership(a3, uptr_rawRet.get(), vResult3[i]->nTRC_light);
		a2.m_xTRCL.pTRCL_TRC->nTRC_page_idx = a5;
		a2.m_xTRCL.pTRCL_TRC->pTRC_XML_buffer = vResult3[i]->pTRC_XML_buffer;
		a2.m_xTRCL.pTRCL_TRC->u1.nTRC_XML_length = vResult3[i]->u1.nTRC_XML_length;

		nTemp = rawImage->pxRIC_bmi->bmiHeader.biXPelsPerMeter;
		if (m_xBoundsInternal.m_bisNeedUpdateDPI)
		{
			if (!rclhelp::deviceTypeReal(a1.m_xTRCL))
				nTemp = nDpi;
		}

		uptr_rawRet->pxRIC_bmi->bmiHeader.biXPelsPerMeter = nTemp;
		uptr_rawRet->pxRIC_bmi->bmiHeader.biYPelsPerMeter = nTemp;
		uptr_rawRet.release();
	}
		
	if (nFlag)
		rclhelp::generateWhiteGray(a2);

	if (m_xBoundsInternal.m_nSaveImage)
	{
		string strPath = common::RegulaConfig::GetTmpPath();
		common::fs::Path path(strPath);
		string strFolder = common::fs::generateTimeFolderName(path);
		bounds::docteachersupport::saveSampleAsImages(a2, strFolder);
	}

	return 0;
}

//Rect형식의 정점들을 Border형식으로 변환한다.
int Bounds::locatePoints(TResultContainerList & a1)
{
	RclHolder rclHoder;
	TResultContainer * pResultContainer;
	TBoundsResult * pBoundsResult;
	int nResult = -20601;

	rclHoder.addNoCopy(a1);
	if (!rclHoder.empty())
	{
		if (rclhelp::checkImagesSize(rclHoder))
		{
			pResultContainer = rclhelp::findFirstContainer(rclHoder.m_xTRCL, 85);

			if (pResultContainer && pResultContainer->u.pTRC_TBR)
			{
				pBoundsResult = pResultContainer->u.pTRC_TBR;
				if (pBoundsResult->nTBR_Width && pBoundsResult->nTBR_Height)
				{
					vector<TResultContainer *> vResult = rclHoder.getRcList(60);

					if (!vResult.empty())
					{
						vector<Point2f> vPoint1, vPoint2, vPoint3, vPoint4;
						for (uint i = 0; i < vResult.size(); i++)
						{
							if (vResult[i]->u.pTRC_POINT)
							{
								vPoint1.push_back(Point2f((float)vResult[i]->u.pTRC_POINT->x, (float)vResult[i]->u.pTRC_POINT->y));
								vPoint2.push_back(Point2f(1.0f, 1.0f));
							}
						}
						//border
						vPoint3.push_back(Point2f(0.0f, 0.0f));
						vPoint3.push_back(Point2f((float)pBoundsResult->nTBR_Width, 0.0f));
						vPoint3.push_back(Point2f((float)pBoundsResult->nTBR_Width, (float)pBoundsResult->nTBR_Height));
						vPoint3.push_back(Point2f(0.0f, (float)pBoundsResult->nTBR_Height));
						//rect
						vPoint4.push_back(Point2f((float)pBoundsResult->xTBR_LeftBottom.x, (float)pBoundsResult->xTBR_LeftBottom.y));
						vPoint4.push_back(Point2f((float)pBoundsResult->xTBR_RightBottom.x, (float)pBoundsResult->xTBR_RightBottom.y));
						vPoint4.push_back(Point2f((float)pBoundsResult->xTBR_RightTop.x, (float)pBoundsResult->xTBR_RightTop.y));
						vPoint4.push_back(Point2f((float)pBoundsResult->xTBR_LeftTop.x, (float)pBoundsResult->xTBR_LeftTop.y));

						//변환행렬을 얻고 변환을 진행하여 vPoint2에 얻는다.
						Mat mat = getPerspectiveTransform(vPoint4, vPoint3);
						perspectiveTransform(vPoint1, vPoint2, mat);

						for (uint i = 0; i < vResult.size(); i++)
						{
							if (vResult[i]->u.pTRC_POINT)
							{
								vResult[i]->u.pTRC_POINT->x = (int)vPoint2[i].x;
								vResult[i]->u.pTRC_POINT->y = (int)vPoint2[i].y;
							}
						}
					}
					nResult = 0;
				}
			}
		}
	}
	return nResult;
}
