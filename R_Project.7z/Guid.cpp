#include "Guid.h"

uchar hexDigitToChar(char a1)
{
	if (a1 >= '0' && a1 <= '9')
		return (uchar)(a1 - '0');
	if (a1 >= 'a' && a1 <= 'f')
		return (uchar)(a1 + 10 - 'a');
	if (a1 >= 'A' && a1 <= 'F')
		return (uchar)(a1 + 10 - 'A');
	return 0;
}

uchar hexPairToChar(char a1, char a2)
{
	return hexDigitToChar(a1) * 0x10 + hexDigitToChar(a2);
}

void operator<<(ostream &a1, Guid const&a2)
{
	a1 << (ushort)a2.m_vGuid_val[0];
	a1 << (ushort)a2.m_vGuid_val[1];
	a1 << (ushort)a2.m_vGuid_val[2];
	a1 << (ushort)a2.m_vGuid_val[3];
	a1 << "-";
	a1 << (ushort)a2.m_vGuid_val[4];
	a1 << (ushort)a2.m_vGuid_val[5];
	a1 << "-";
	a1 << (ushort)a2.m_vGuid_val[6];
	a1 << (ushort)a2.m_vGuid_val[7];
	a1 << "-";
	a1 << (ushort)a2.m_vGuid_val[8];
	a1 << (ushort)a2.m_vGuid_val[9];
	a1 << "-";
	a1 << (ushort)a2.m_vGuid_val[10];
	a1 << (ushort)a2.m_vGuid_val[11];
	a1 << (ushort)a2.m_vGuid_val[12];
	a1 << (ushort)a2.m_vGuid_val[13];
	a1 << (ushort)a2.m_vGuid_val[14];
	a1 << (ushort)a2.m_vGuid_val[15];
}

Guid::Guid()
{
	m_vGuid_val.assign(16, 0);
}

Guid::~Guid()
{
}

Guid::Guid(string const&a2)
{
	bool v7 = true;
	size_t v4 = a2.size();
	const char*v5 = a2.data();
	for (size_t i = 0; i < v4; i++)
	{
		char v2, v8 = v5[i];
		if (v8 != '-')
		{
			if (v8 != '{' && v8 != '}')
			{
				if (v7)
				{
					v7 = false;
					v2 = v8;
				}
				else
				{
					uchar v10 = hexPairToChar(v2, v8);
					m_vGuid_val.push_back(v10);
					v7 = true;
				}
			}
		}
	}
}

Guid::Guid(uchar const*a2)
{
	if (a2)
	{
		m_vGuid_val.assign(a2, a2 + 0x10);
	}
	else
	{
		m_vGuid_val.assign(16, 0);
	}
}

GUID Guid::toNative()
{
	GUID guid;
	memclr(&guid, sizeof(GUID));
	if (m_vGuid_val.size() >= 16)
	{
		guid.Data1 = (m_vGuid_val[0] << 24) | (m_vGuid_val[1] << 16) | (m_vGuid_val[2] << 8) | m_vGuid_val[3];
		guid.Data2 = (m_vGuid_val[4] << 8) | m_vGuid_val[5];
		guid.Data3 = (m_vGuid_val[6] << 8) | m_vGuid_val[7];
		guid.Data4[0] = m_vGuid_val[8];
		guid.Data4[1] = m_vGuid_val[9];
		guid.Data4[2] = m_vGuid_val[10];
		guid.Data4[3] = m_vGuid_val[11];
		guid.Data4[4] = m_vGuid_val[12];
		guid.Data4[5] = m_vGuid_val[13];
		guid.Data4[6] = m_vGuid_val[14];
		guid.Data4[7] = m_vGuid_val[15];
	}
	return guid;
}

string Guid::ToString(void) const
{
	stringstream v6;
	v6.unsetf(ios_base::dec);
	v6.setf(ios_base::hex);

	v6 << *this;
	return v6.str();
}

Guid::Guid(Guid const & a1)
{
	m_vGuid_val = a1.m_vGuid_val;
}

Guid& Guid::operator=(Guid const&a2)
{
	if (this != &a2)
		m_vGuid_val.assign(a2.m_vGuid_val.begin(), a2.m_vGuid_val.end());
	return *this;
}

Guid& Guid::operator=(Guid&& a2)
{
	m_vGuid_val = move(a2.m_vGuid_val);
	return *this;
}

Guid& Guid::operator=(_GUID const&a2)
{
	if (m_vGuid_val.size() < 16)
		m_vGuid_val.resize(16);
	m_vGuid_val[0] = (uchar)(a2.Data1 >> 24);
	m_vGuid_val[1] = (uchar)((a2.Data1 >> 16) & 0xFF);
	m_vGuid_val[2] = (uchar)((a2.Data1 >> 8) & 0xFF);
	m_vGuid_val[3] = (uchar)a2.Data1;
	m_vGuid_val[4] = (uchar)((a2.Data2 >> 8) & 0xFF);
	m_vGuid_val[5] = (uchar)a2.Data2;
	m_vGuid_val[6] = (uchar)((a2.Data3 >> 8) & 0xFF);
	m_vGuid_val[7] = (uchar)a2.Data3;
	m_vGuid_val[8] = a2.Data4[0];
	m_vGuid_val[9] = a2.Data4[1];
	m_vGuid_val[10] = a2.Data4[2];
	m_vGuid_val[11] = a2.Data4[3];
	m_vGuid_val[12] = a2.Data4[4];
	m_vGuid_val[13] = a2.Data4[5];
	m_vGuid_val[14] = a2.Data4[6];
	m_vGuid_val[15] = a2.Data4[7];
	return *this;
}

bool Guid::operator==(Guid const&a2)
{
	if (m_vGuid_val.size() != a2.m_vGuid_val.size())
		return false;
	vector<uchar>::const_iterator iter2 = a2.m_vGuid_val.begin();
	for (vector<uchar>::iterator iter = m_vGuid_val.begin(); iter != m_vGuid_val.end(); iter++, iter2++)
	{
		if (*iter != *iter2)
			return false;
	}
	return true;
}
