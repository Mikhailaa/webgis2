#pragma once
#include <stdio.h>
#include <stdarg.h>
#include <memory.h>
#include "DynArray.h"
#include "XMLAttribute.h"

#pragma pack(1)
namespace tinyxml2
{
	struct SpecialSymbol
	{
		char* name;
		int namelen;
		char symbol;
	};
	static SpecialSymbol symbols[5]={{"quot",4,'"'},{"amp",3,'&'},{"apos",4,'\''},{"lt",2,'<'},{"gt",2,'>'}};
	class XMLComment;
	class XMLUnknown;
	class XMLText;
	class XMLElement;
	class XMLDocument_AAA;
	class XMLDeclaration;
	class XMLPrinter
	{
	public:
		bool field_4;  // isOpened
		DynArray<const char*,10> field_8;
		bool field_3C;
		FILE *field_40;
		int field_44;  // space count(ref cnt)
		int field_48;
		bool field_4C;
		bool field_4D; // compact mode
		bool field_4E[64];
		bool field_8E[64];
		tinyxml2::DynArray<char,20> field_D0;
		XMLPrinter();
		XMLPrinter(FILE* a2,bool a3,int a4);
		~XMLPrinter(void);
		virtual bool Visit(const XMLComment& a2);
		virtual bool Visit(const XMLUnknown& a2);
		virtual bool Visit(const XMLText& a2);
		virtual bool Visit(const XMLDeclaration& a2);
		virtual bool VisitExit(const XMLElement& a2);
		virtual bool VisitExit(const XMLDocument_AAA& a2);
		virtual bool CompactMode(const XMLElement& a2);
		virtual int CloseElement(bool a2);
		virtual bool VisitEnter(const XMLElement& a2,const XMLAttribute* a3);
		virtual bool VisitEnter(const XMLDocument_AAA& a2);
		virtual void PrintSpace(int a2);
		int OpenElement(const char* a2,bool a3);
		void PushAttribute(const char* a2,const char* a3);
		void Print(const char* a2,...);
		void PrintString(const char* a2,bool a3);
		void PushUnknown(const char* a2);
		void PushDeclaration(const char* a2);
		void PushText(const char* a2,bool a3);
		void PushComment(const char* a2);
		void SealElementIfJustOpened();
	};
}
#pragma pack()

