#pragma once
#include <stdio.h>
#include <stdarg.h>
#include "XMLNode.h"
#include "XMLUnknown.h"
#include "MemPoolT.h"
using namespace tinyxml2;

namespace tinyxml2
{
	class XMLDocument_AAA : public XMLNode
	{
	public:
		char field_30;
		bool field_31;
		char field_32;
		char field_33;
		int field_34;
		int field_38;
		char *field_3C;
		char* field_40;
		char* field_44;
		MemPoolT<56> mempool56;
		MemPoolT<36> mempool36;
		MemPoolT<52> mempool52;
		MemPoolT<48> mempool48;
		XMLDocument_AAA(void);
		XMLDocument_AAA(bool a2,int a3);
		~XMLDocument_AAA(void);
		XMLUnknown* NewUnknown(const char* a2);
		XMLElement* NewElement(const char* a2);
		XMLText* NewText(const char* a2);
		XMLDeclaration* NewDeclaration(const char* a2);
		XMLComment* NewComment(const char* a2);
		void Clear();
		virtual bool ShallowEqual(const XMLNode* a2) ;
		virtual XMLUnknown* ShallowClone(XMLDocument_AAA* a2) ;
		virtual char* ParseDeep(char* a2,StrPair* a3);
		virtual int Accept(XMLPrinter* a2) ;
		int SaveFile(FILE* a2,bool a3);
		XMLElement* RootElement();
		void Print(XMLPrinter* a2);
		char* Parse();
		int Parse(const char* a2,unsigned int a3);
		int LoadFile(FILE* a2);
		char* Identify(char* a2,XMLNode** a3);
		XMLNode* DeleteNode(XMLNode* a2);
	};
}








