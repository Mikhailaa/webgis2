#pragma once

namespace tinyxml2
{
	class XMLDeclaration : public XMLNode
	{
	public:
		XMLDeclaration(XMLDocument_AAA* a2);
		XMLDeclaration(void);
		~XMLDeclaration(void);
		virtual bool ShallowEqual(const XMLNode* a2) ;
		virtual XMLUnknown* ShallowClone(XMLDocument_AAA* a2) ;//fix
		virtual char* ParseDeep(char* a2,StrPair* a3);
		virtual int Accept(XMLPrinter* a2) ;
	};
}


