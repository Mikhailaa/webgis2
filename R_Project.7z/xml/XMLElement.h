#pragma once

namespace tinyxml2
{
	class XMLNode;
	class XMLDocument_AAA;
	class XMLAttribute;
	class XMLPrinter;

	class XMLElement : public XMLNode
	{
	public:
		int field_30;
		XMLAttribute* field_34;
		int field_38;
		int field_3C;
		int field_40;
		int field_44;
		int field_48;
		char field_4C;
		bool field_4D;
		XMLElement(){};
		XMLElement(XMLDocument_AAA* a2);
		~XMLElement(void);
		virtual bool ShallowEqual(const XMLNode* a2);
		virtual XMLUnknown* ShallowClone(XMLDocument_AAA* a2);
		virtual char* ParseDeep(char* a2,StrPair* a3);
		virtual int Accept(XMLPrinter* a2);
		char* ParseAttributes(char* a2);
		static void DeleteAttribute(XMLAttribute* a2);
		void DeleteAttribute(const char* a2);
		void SetAttribute(const char* a2,unsigned int a3);
		void SetAttribute(const char* a2,long long a3);
		void SetAttribute(const char* a2,int a3);
		void SetAttribute(const char* a2,float a3);
		void SetAttribute(const char* a2,double a3);
		void SetAttribute(const char* a2,const char* a3);
		void SetAttribute(const char* a2,bool a3);
		void SetText(unsigned int a2);
		void SetText(long long  a3);
		void SetText(int a2);
		void SetText(float a2);
		void SetText(double a2);
		void SetText(bool a2);
		void SetText(const char* a2);
		int QueryUnsignedText(unsigned int* a2);
		int QueryIntText(int* a2);
		int QueryInt64Text(long long* a2);
		int QueryFloatText(float* a2);
		int QueryDoubleText(double* a2);
		int QueryBoolText(bool* a2);
		int QueryUnsignedAttribute(const char* a2,unsigned int* a3);
		int QueryIntAttribute(const char* a2,int* a3);
		int QueryInt64Attribute(const char* a2,long long* a3);
		int QueryFloatAttribute(const char* a2,float* a3);
		int QueryDoubleAttribute(const char* a2,double* a3);
		int QueryBoolAttribute(const char* a2,bool* a3);
		XMLAttribute* FindOrCreateAttribute(const char* a2);
		XMLAttribute* FindAttribute(const char* a2);
		char* Attribute(const char* a2,const char* a3);
		char* GetText();
		
	};
}


