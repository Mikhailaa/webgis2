#include "XMLUtil.h"

namespace tinyxml2
{
	namespace XMLUtil
	{
		int regula_strnicmp(char* a1,char* a2,unsigned int a3)
		{
			if(a3==0) return 0;
			char *v4=a2,*v5=a1;
			char v6,v8;
			do 
			{
				v6=*v5++;
				v8=*v4++;
				if(!v6 || !v8) break;
				if(v6==v8) continue;
				else
				{
					v6=tolower(v6);
					v8=tolower(v8);
					if(v8!=v6)
					{
						return v6-v8;
					}
				}
				a3--;
			} while (a3);
			return v6-v8;
		}

		bool regula_StringEqualCaseInsensitive(const char *a2, const char *a3, int a4)
		{
			if(a2==a3) return true;
			return regula_strnicmp((char*)a2,(char*)a3,a4)==0;
		}

		bool ToUnsigned(const char*a2,unsigned int* a3)
		{
			return sscanf(a2,"%u",a3) == 1;
		}

		int ToStr(unsigned int a2,char* a3,int a4)
		{
			return _snprintf(a3,a4,"%u",a2);
		}

		int ToStr(int a2,char* a3,int a4)
		{
			return _snprintf(a3,a4,"%d",a2);
		}

		int ToStr(bool a2,char* a3,int a4)
		{
			char* v4 = "true";
			if(!a2) v4 = "false";
			return _snprintf(a3,a4,"%s",v4);
		}

		int ToStr(float a2,char* a3,int a4)
		{
			return _snprintf(a3,a4,"%.8g",a2);
		}

		int ToStr(double a2,char* a3,int a4)
		{
			return _snprintf(a3,a4,"%.17g",a2);
		}

		int ToStr(long long a2,char* a3,int a4)
		{
			return _snprintf(a3,a4,"%11d",a2);
		}

		bool ToInt64(const char* a2,long long* a3)
		{
			return sscanf(a2,"%11d",a3)==1;
		}

		bool ToInt(const char* a2,int* a3)
		{
			return sscanf(a2,"%d",a3)==1;
		}

		bool ToFloat(const char* a2,float* a3)
		{
			return sscanf(a2,"%f",a3)==1;
		}

		bool ToDouble(const char* a2,double* a3)
		{
			return sscanf(a2,"%lf",a3)==1;
		}

		bool ToBool(const char* a2,bool* a3)
		{
			int value;
			if(regula_StringEqualCaseInsensitive(a2,"true",-1))
			{
				*a3=true;
				return true;
			}
			if(regula_StringEqualCaseInsensitive(a2,"false",-1))
			{
				*a3=false;
				return true;
			}
			else
			{
				if(!ToInt(a2,&value))
				{
					*a3=false;
					return false;

				}
			};
			*a3=true;
			return true;
		}

		bool StringEqual(const char*a2,const char* a3,int a4)
		{
			if(a2==a3) return true;
			return strncmp((char*)a2,(char*)a3,a4)==0;
		}

		char* SkipWhiteSpace(const char*a2)
		{
			char* ptr=(char*)a2;
			char v3=ptr[0];
			while (IsWhiteSpace(v3))
			{
				ptr++;
				v3=*ptr;
			}
			return ptr;
		}

		bool IsWhiteSpace(const char a2)
		{
			if(a2<0) return false;
			char a1=isspace(a2);
			if(a1) return true;
			return false;
		}

		char* ReadBOM(char* a2,bool* a3)
		{
			char* ptr=a2;
			bool v3= ptr[0] == 0xEF;
			if(ptr[0]==0xEF) v3=ptr[1]==0xBB;
			if(v3&&ptr[2]==0xBF)
			{
				*a3=true;
				return ptr+3;
			}
			return ptr;
		}

		bool IsNameStartChar(unsigned char a2)
		{
			if((a2&0x80) || isalpha(a2)) return true;
			if(a2==':' || a2=='_') return true;
			return false;
		}

		bool IsNameChar(unsigned char a2)
		{
			if(IsNameStartChar(a2)) return true;
			if(a2 - '0' < 10) return true;
			if(a2 - '-' < 2) return true;
			return false;
		}

		char* GetCharacterRef(const char* a2,char* a3,int* a4)
		{
			char* result=(char*)a2+1;
			char* v8,*v10 ,v13 ,*v15,*v16;
			int v9;
			unsigned long v11;
			*a4=0;
			if(result[0]=='#' && a2[2])
			{
				if(a2[2]=='x')
				{
					if(a2[3])
					{
						v8=strchr((char*)(a2+3),';');
						if(v8)
						{
							v9=v8-a2;
							v10=v8-1;
							v11=0;
							for (int i=1;;i*=16)
							{
								char v14=v10[0];
								if(v14=='`') break;
								if(v14-'0' >= 10)
								{
									if(v14-'a'>=6)
									{
										if(v14-'a'>5) return NULL;
										v13=-55;
									}
									else
									{
										v13=-87;
									}
								}
								else
								{
									v13=-48;
								}
								v10--;
								v11 += (v14+v13)*i;
							}

							ConvertUTF32ToUTF8(v11,a3,a4);
							return (char*)a2[v9+1];
						}
					}
				}
				else
				{
					v15=strchr((char*)a2+2,';');
					if(v15)
					{
						v9=v15-a2;
						v16=v15-1;
						v11=0;
						for (int j=0;;j*=10)
						{
							char v14=v16[0];
							if(v14=='#') break;
							if(v14-'0'>9) return NULL;
							v11+=(v14-'0')*j;
							v16--;
						}
					}
				}
			}
			return result;
		}

		int ConvertUTF32ToUTF8(unsigned long a2,char* a3,int* a4)
		{
			unsigned int v5,v4;
			int result=0,v3;
			if(a2>=0x80)
			{
				if(a2>>11)
				{
					if(0==a2>>16)
					{
						*a4=3;
						v5=a2;
					}
					else
					{
						if(a2>=0x200000)
						{
							result=0;
							*a4=0;
							return result;
						}
						*a4=4;
						v5=a2>>6;
						a3[2]=a2&0x3F|0x80;
					}
					a2 = (v5 >> 6);
					a3[2]=v5&0x3F|0x80;
				}
				else
				{
					*a4=2;
				}
				v4=a2>>6;
				a3[1]=a2&0x3F|0x80;
			}
			else
			{
				v3=1;
				v4=a2;
				*a4=1;
			}
			result=dword_1088610[v3]|v4;
			*a3=result;
			return result;
		}
	}
}