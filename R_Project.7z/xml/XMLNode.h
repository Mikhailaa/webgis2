#pragma once
#include "StrPair.h"

namespace tinyxml2
{
	class XMLDocument_AAA;
	class XMLUnknown;
	class XMLElement;
	class XMLDeclaration;
	class StrPair;
	class XMLPrinter;
	class XMLText;
	class XMLComment;

	
	class XMLNode
	{
	public:
		XMLDocument_AAA* field_4;
		XMLNode* field_8;
		StrPair field_C;
		XMLNode* field_18;
		XMLNode* field_1C;
		XMLNode* field_20;
		XMLNode* field_24;
		int field_28;
		void* field_2C;  // MemPoolT

		XMLNode(){};
		XMLNode(XMLDocument_AAA* a2);
		~XMLNode(void);

		virtual XMLUnknown* ToUnknown() const;
		virtual XMLText* ToText() const ;
		virtual XMLElement* ToElement() const;
		virtual XMLDocument_AAA* ToDocument() const;
		virtual XMLComment* ToComment() const;
		virtual XMLDeclaration* ToDeclaration() const;
		virtual bool ShallowEqual(const XMLNode* a2) = 0;
		virtual XMLUnknown* ShallowClone(XMLDocument_AAA* a2) = 0;
		virtual char* ParseDeep(char* a2,StrPair* a3);
		virtual int Accept(XMLPrinter* a2) = 0;
		char* Value() ;
		XMLNode* Unlink(XMLNode* a2);
		int SetValue(const char* a2,bool a3);
		XMLElement* NextSiblingElement(const char* a2);
		XMLNode* InsertFirstChild(XMLNode* a2);
		XMLNode* InsertEndChild(XMLNode* a2);
		void* InsertChildPreamble(XMLNode* a2);
		XMLNode* InsertAfterChild(XMLNode* a2,XMLNode* a3);
		XMLElement* FirstChildElement(const char*);
		XMLNode* DeleteNode(XMLNode* a2);
		XMLNode* DeleteChild(XMLNode* a2);
		void DeleteChildren();
	};
}


