#pragma once
using namespace std;

namespace tinyxml2
{
	template<class T,int i>
	class DynArray
	{
	public:
		T* field_0;
		T field_4[i];
		int field_2C; // allocated
		int field_30; // size
		DynArray()
		{
			field_0=field_4;
			field_2C=i;
			field_30=0;
		};
		~DynArray(){};
		void DynArray::EnsureCapacity(int a2);
		T* DynArray::Push(T a2);
		T* DynArray::PushArr(int a2);
	private:
	};
	
	template<class T,int i>
	T* DynArray<T,i>::Push(T a2)
	{
		EnsureCapacity(field_30+1);
		field_0[field_30]=a2;
		field_30++;
		return field_0;
	}

	template<class T,int i>
	void DynArray<T,i>::EnsureCapacity(int a2)
	{
		if(a2<0) return;
		if(field_2C>=a2) return;
		T* v5=new T[2*a2];
		memcpy_s(v5,2*a2,field_0,field_30*sizeof(T));
		if(field_0!=field_4) delete field_0;
		field_0=v5;
		field_2C=2*a2;
	}

	template<class T,int i>
	T* DynArray<T,i>::PushArr(int a2)
	{
		EnsureCapacity(a2+field_30);
		T* result=field_0+field_30;
		field_30=field_30+a2;
		return result;
	}
}