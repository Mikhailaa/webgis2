#include "XMLPrinter.h"
#include "XMLNode.h"
#include "XMLText.h"
#include "XMLDocument.h"
#include "XMLUtil.h"


namespace tinyxml2
{
	XMLText::XMLText(XMLDocument_AAA* a2)
		:XMLNode(a2)
	{
	}


	XMLText::~XMLText(void)
	{
	}

	int XMLText::Accept(XMLPrinter* a2)
	{
		return a2->Visit(*this);
	}

	char* XMLText::ParseDeep(char* a2,StrPair* a3)
	{
		char* result,*v10;
		XMLDocument_AAA* v6;
		int v8;
		v6=field_4;
		if(field_30)
		{
			result=field_C.ParseText(a2,"]]>",2);
			if(result) return result;
			v6->field_34=11;
			v6->field_3C=a2;
			v6->field_40=0;
			return NULL;
		}
		v8=3;
		if(v6->field_31==false) v8=2;
		if(v6->field_38==1) v8|=4;
		v10=field_C.ParseText(a2,"<",v8);
		if(v10==NULL)
		{
			v6->field_34=10;
			v6->field_3C=a2;
			v6->field_40=0;
			return NULL;
		}
		result=v10-1;
		if(v10[0]==0) return NULL;
		return result;
	}
	XMLText* XMLText::ToText()
	{
		return this;
	}

	bool XMLText::ShallowEqual( const XMLNode* a2 )
	{
		XMLText* v3 = a2->ToText();
		if(!v3)
			return 0;
		char* v4 = v3->Value();
		char* v5 = Value();
		return XMLUtil::StringEqual(v4,v5, 0x7fffffff);
	}

	XMLUnknown* XMLText::ShallowClone( XMLDocument_AAA* a2 )
	{
		XMLDocument_AAA* v2 = a2 ? a2 : field_4;
		char* v4 = Value();
		XMLText* result = v2->NewText(v4);
		result->field_30 = field_30;
		return (XMLUnknown*)result;
	}

}

