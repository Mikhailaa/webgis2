#include "XMLNode.h"
#include "XMLComment.h"
#include "XMLUtil.h"
#include "XMLUnknown.h"
#include "XMLDocument.h"
#include "XMLPrinter.h"

namespace tinyxml2
{
	XMLComment::XMLComment(void)
	{

	}

	XMLComment::XMLComment( XMLDocument_AAA* a2 )
		:XMLNode(a2)
	{

	}


	XMLComment::~XMLComment(void)
	{
	}

	bool XMLComment::ShallowEqual( const XMLNode* a2 )
	{
		XMLComment* v3 = a2->ToComment();
		if(!v3) 
			return 0;
		char* v4 = v3->Value();
		char* v5 = Value();
		return XMLUtil::StringEqual(v4,v5,0x7fffffff);
	}

	XMLUnknown* XMLComment::ShallowClone( XMLDocument_AAA* a2 )
	{
		XMLDocument_AAA* v2 = a2 ? a2 : field_4;
		char* v3 = Value();
		return (XMLUnknown*)v2->NewComment(v3);
	}

	char* XMLComment::ParseDeep( char* a2,StrPair* a3 )
	{
		char* result = field_C.ParseText(a2,"-->",2);
		if(!result)
		{
			field_4->field_34 = 12;
			field_4->field_3C = a2;
			field_4->field_40 = 0;
		}
		return result;
	}

	int XMLComment::Accept( XMLPrinter* a2 )
	{
		return a2->Visit(*this);
	}

}

