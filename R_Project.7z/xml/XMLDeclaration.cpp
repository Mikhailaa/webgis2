#include "XMLNode.h"
#include "XMLDeclaration.h"
#include <string.h>
#include "XMLPrinter.h"
#include "XMLDocument.h"
#include "XMLUtil.h"
#include "XMLUnknown.h"

namespace tinyxml2
{
	XMLDeclaration::XMLDeclaration()
	{

	}

	XMLDeclaration::XMLDeclaration( XMLDocument_AAA* a2 )
		:XMLNode(a2)
	{
		
	}

	XMLDeclaration::~XMLDeclaration()
	{

	}

	bool XMLDeclaration::ShallowEqual( const XMLNode* a2 )
	{
		XMLDocument_AAA* v3 = a2->ToDocument();
		if(!v3) return false;
		return XMLUtil::StringEqual(v3->Value(),Value(),0x7fffffff);
	}

	XMLUnknown* XMLDeclaration::ShallowClone( XMLDocument_AAA* a2 )
	{
		XMLDocument_AAA* v2 = a2 ? a2 : field_4;
		const char* v3 = Value();
		return (XMLUnknown*)a2->NewDeclaration(v3);
	}

	char* XMLDeclaration::ParseDeep( char* a2,StrPair* a3 )
	{
		char* result = field_C.ParseText(a2,"?>",2);
		if(!result)
		{
			field_4->field_34 = 13;
			field_4->field_3C = a2;
			field_4->field_40 = 0;
		}
		return result;
	}

	int XMLDeclaration::Accept( XMLPrinter* a2 )
	{
		return a2->Visit(*this);
	}

}