#include "XMLDocument.h"
#include "XMLPrinter.h"
#include "XMLUtil.h"
#include "XMLText.h"
#include "XMLElement.h"
#include "XMLDeclaration.h"
#include "XMLComment.h"
#include "../commonStruct.h"
#include "../common/StringUtils.h"
#include "../common/UnicodeUtils.h"

namespace tinyxml2
{
	XMLDocument_AAA::XMLDocument_AAA(void)
		:XMLNode()
	{
	}

	XMLDocument_AAA::XMLDocument_AAA( bool a2,int a3 )
		:XMLNode(this)
	{
		field_30=0;
		field_31=a2;
		field_34=0;
		field_38=a3;
		field_3C=field_40=0;
	}


	XMLDocument_AAA::~XMLDocument_AAA(void)
	{
		Clear();
	}

	XMLElement* XMLDocument_AAA::NewElement( const char* a2 )
	{
		XMLElement* v5 = (XMLElement*)mempool52.Alloc();
		XMLElement v6(this);
		memcpy_s(v5,sizeof(XMLElement),&v6,sizeof(XMLElement));
		v5->field_2C=&mempool52;
		v5->field_C.SetStr(a2,false);
		return v5;
	}

	XMLText* XMLDocument_AAA::NewText( const char* a2 )
	{
		XMLText* v5 = (XMLText*)mempool56.Alloc();
		XMLText v6(this);
		memcpy_s(v5,sizeof(XMLText),&v6,sizeof(XMLText));
		v5->field_2C=&mempool56;
		v5->field_C.SetStr(a2,false);
		return v5;
	}

	void XMLDocument_AAA::Clear()
	{
		DeleteChildren();
		field_34=0;
		field_3C=field_40=NULL;
		delete field_44;
		field_44=NULL;
	}

	bool XMLDocument_AAA::ShallowEqual( const XMLNode* a2 )
	{
		return false;
	}

	XMLUnknown* XMLDocument_AAA::ShallowClone( XMLDocument_AAA* a2 )
	{
		return NULL;
	}

	char* XMLDocument_AAA::ParseDeep( char* a2,StrPair* a3 )
	{
		return NULL;
	}

	int XMLDocument_AAA::Accept( XMLPrinter* a2 )
	{
		XMLNode* v4,*v5;
		if(a2->VisitEnter(*this))
		{
			v4=field_18;
			do 
			{
				v5=v4;
				if(v5==NULL) break;
				v4=v5->field_24;
			} while (v5->Accept(a2)); /////??????????????????????????????
		}
		return a2->VisitExit(*this);
	}

	int XMLDocument_AAA::SaveFile( FILE* a2,bool a3 )
	{
		field_34=0;
		field_3C=field_40=0;
		XMLPrinter v7(a2,a3,0);
		Accept(&v7);
		return field_34;
	}

	XMLElement* XMLDocument_AAA::RootElement()
	{
		return FirstChildElement(NULL);
	}

	void XMLDocument_AAA::Print( XMLPrinter* a2 )
	{
		if(a2)
		{
			Accept(a2);
		}
		else
		{
			XMLPrinter v5(stdout,0,0);
			Accept(&v5);
		}
	}

	char* XMLDocument_AAA::Parse()
	{
		bool v4;
		char* v3=XMLUtil::SkipWhiteSpace(field_44);
		char* v5=XMLUtil::ReadBOM(&field_30,&v4);
		if(v5[0]) return ParseDeep(v5,NULL);
		field_34=15;
		field_3C=field_40=NULL;
		return NULL;
	}

	int XMLDocument_AAA::Parse( const char* a2,unsigned int a3 )
	{
		Clear();
		if(a2 && a3 && a2[0])
		{
			if(a3==-1) a3=strlen(a2);
			char* v6=new char[a3+1];
			field_44=v6;
			memcpy_s(v6,a3,a2,a3);
			v6[a3]=0;
			Parse();
			if(field_34)
			{
				DeleteChildren();
				mempool56.Clear();
				mempool36.Clear();
				mempool52.Clear();
				mempool48.Clear();
				return field_34;
			}
			return 0;
		}
		else
		{
			field_34=15;
			field_3C=field_40=0;
		}
		return 15;
	}

	XMLDeclaration* XMLDocument_AAA::NewDeclaration( const char* a2 )
	{
		XMLDeclaration* v5 = (XMLDeclaration*)mempool48.Alloc();
		XMLDeclaration v6(this);
		memcpy_s(v5,sizeof(XMLDeclaration),&v6,sizeof(XMLDeclaration));
		v5->field_2C=&mempool48;
		if(a2==NULL) v5->field_C.SetStr("xml version=\"1.0\" encoding=\"UTF-8\"",false);
		else v5->field_C.SetStr(a2,false);
		return v5;
	}

	XMLComment* XMLDocument_AAA::NewComment( const char* a2 )
	{
		XMLComment* v5 = (XMLComment*)mempool48.Alloc();
		XMLComment v6(this);
		memcpy_s(v5,sizeof(XMLComment),&v6,sizeof(XMLComment));
		v5->field_2C=&mempool48;
		v5->field_C.SetStr(a2,false);
		return v5;
	}

	int XMLDocument_AAA::LoadFile( FILE* a2 )
	{
		int result;
		Clear();
		fseek(a2,0,0);
		if(!(fgetc(a2)==-1&&ferror(a2)))
		{
			fseek(a2,0,0);
			long v4=ftell(a2);
			fseek(a2,0,0);
			if(v4)
			{
				if(v4!=-1)
				{
					char* v5=new char[v4+1];
					field_44=v5;
					if(fread(v5,1,v4,a2)==v4)
					{
						field_44[v4]=0;
						Parse();
						return field_34;
					}
				}
			}
		}
		result=5;
		field_34=5;
		field_3C=field_40=0;
		return result;
	}

	char* XMLDocument_AAA::Identify( char* a2,XMLNode** a3 )
	{
		char* v6=XMLUtil::SkipWhiteSpace(a2);
		XMLNode* v8=NULL;
		if(*v6)
		{
			if(!XMLUtil::StringEqual(v6,"<?",2))
			{
				if(XMLUtil::StringEqual(v6,"<!--",4))
				{
					v8=(XMLComment*)mempool48.Alloc();
					XMLComment v1(this);
					memcpy_s(v8,sizeof(XMLComment),&v1,sizeof(XMLComment));
					v8->field_2C=&mempool48;
					v6+=4;
				}
				if(XMLUtil::StringEqual(v6,"<![CDATA[",9))
				{
					v8=(XMLText*)mempool52.Alloc();
					XMLText v1(this);
					memcpy_s(v8,sizeof(XMLText),&v1,sizeof(XMLText));
					v8->field_2C=&mempool52;
					((XMLText*)v8)->field_30=true;
					v6+=9;
				}
				if(!XMLUtil::StringEqual(v6,"<!",2))
				{
					if(XMLUtil::StringEqual(v6,"<",1))
					{
						v8=(XMLElement*)mempool56.Alloc();
						XMLElement v1(this);
						memcpy_s(v8,sizeof(XMLElement),&v1,sizeof(XMLElement));
						v8->field_2C=&mempool56;
						v6++;
					}
					else
					{
						v8=(XMLText*)mempool52.Alloc();
						XMLText v1(this);
						memcpy_s(v8,sizeof(XMLText),&v1,sizeof(XMLText));
						v8->field_2C=&mempool52;
						v6=a2;
					}
				}
			}
			else
			{
				v8=(XMLUnknown*)mempool48.Alloc();
				XMLUnknown v1(this);
				memcpy_s(v8,sizeof(XMLUnknown),&v1,sizeof(XMLUnknown));
				v8->field_2C=&mempool48;
				v6+=2;
			}
		}
		*a3=v8;
		return v6;
	}

	XMLNode* XMLDocument_AAA::DeleteNode( XMLNode* a2 )
	{
		if(a2->field_8) return a2->field_8->DeleteChild(a2);
		((MemPoolT<48>*)a2->field_2C)->SetTracked();
		return a2->DeleteNode(NULL);
	}

	XMLUnknown* tinyxml2::XMLDocument_AAA::NewUnknown(const char* a2)
	{
		XMLUnknown* v5 = (XMLUnknown*)mempool48.Alloc();
		XMLUnknown v6(this);
		memcpy_s(v5,sizeof(XMLUnknown),&v6,sizeof(XMLUnknown));
		v5->field_2C=&mempool48;
		v5->field_C.SetStr(a2,false);
		return v5;
	}
}







