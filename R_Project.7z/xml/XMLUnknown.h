#pragma once
#include "XMLNode.h"

namespace tinyxml2
{
	class XMLUnknown : public XMLNode
	{
	public:
		XMLUnknown(XMLDocument_AAA* a2);
		~XMLUnknown(void);
		virtual XMLUnknown* ToUnknown(void) const;
		bool ShallowEqual(const XMLNode* a2);
		XMLUnknown* ShallowClone(XMLDocument_AAA* a2);
		char* ParseDeep(char* a2,StrPair* a3);
		int Accept(XMLPrinter* a2);
	};
}


