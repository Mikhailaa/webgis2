#pragma once
#include "../commonStruct.h"

enum eImageFormat
{
	ImageFormat_0,
	ImageFormat_1,
};

class TGraphicFormats
{
public:
	TGraphicFormats();
	~TGraphicFormats();
	static TGraphicFormats CreateById(eImageFormat, int);
	void operator=(TGraphicFormats const&);

	int m_nTGF_0;
	int m_nTGF_4;
	int m_nTGF_8;
	vector<string> m_xTGF_C;
	vector<string> m_xTGF_18;
	vector<eImageFormat> m_xTGF_24;
};

class XmlSerializerInternal 
{
public:
	XmlSerializerInternal();
	~XmlSerializerInternal();
	int makeXML(TResultContainer &);
	int makeXML(TResultContainerList &);

	int		nXSI_field_0;
	TGraphicFormats xXSI_TGF;
	string	sXSI_field_34;
	wstring	wsXSI_field_40;
	wstring wsXSI_field_4C;
	string	sXSI_field_58;
	string	sXSI_field_64;
	wstring wsXSI_field_70;
	bool	bXSI_field_7C;
	bool	bXSI_field_7D;
	bool	bXSI_field_7E;
	int		nXSI_field_80;
	int		nXSI_field_84;
	int		nXSI_field_88;
};
