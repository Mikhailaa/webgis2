#pragma once
#include <ctype.h>
#include <stdio.h>
#include <string.h>
using namespace std;

namespace tinyxml2
{
	namespace XMLUtil
	{
		static int dword_1088610[7]={0,0,0xC0,0xE0,0xF0,0xF8,0xFC};
		int regula_strnicmp(char* a1,char* a2,unsigned int a3);
		bool regula_StringEqualCaseInsensitive(const char *a2, const char *a3, int a4);
		bool ToUnsigned(const char*a2,unsigned int* a3);
		int ToStr(unsigned int a2,char* a3,int a4);
		int ToStr(int a2,char* a3,int a4);
		int ToStr(bool a2,char* a3,int a4);
		int ToStr(float a2,char* a3,int a4);
		int ToStr(double a2,char* a3,int a4);
		int ToStr(long long a2,char* a3,int a4);
		bool ToInt64(const char* a2,long long* a3);
		bool ToInt(const char* a2,int* a3);
		bool ToFloat(const char* a2,float* a3);
		bool ToDouble(const char* a2,double* a3);
		bool ToBool(const char* a2,bool* a3);
		bool StringEqual(const char*a2,const char* a3,int a4);
		char* SkipWhiteSpace(const char*a2);
		bool IsWhiteSpace(const char a2);
		char* ReadBOM(char* a2,bool* a3);
		bool IsNameStartChar(unsigned char a2);
		bool IsNameChar(unsigned char a2);
		char* GetCharacterRef(const char* a2,char* a3,int* a4);
		int ConvertUTF32ToUTF8(unsigned long a2,char* a3,int* a4);
	}
}