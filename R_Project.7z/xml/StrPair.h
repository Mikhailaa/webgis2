#pragma once
#define NULL 0

namespace tinyxml2
{
	class StrPair
	{
	public:
		int field_0;
		char* field_4;
		char* field_8;
		StrPair();
		~StrPair();
		char* ParseText(char* a1, const char* a2, int a3);
		char* ParseName(char* a2);
		char* GetStr() ;
		int SetStr(const char* a2, int a3);
		void Reset();
		int CollapseWhitespace();
		int Set(char* a2,char* a3,int a4);
		void TransferTo(StrPair* a2);
	};

}

