#include "XMLPrinter.h"
#include "XMLNode.h"
#include "XMLComment.h"
#include "XMLDocument.h"
#include "XMLElement.h"
#include "XMLText.h"
#include "XMLDeclaration.h"


namespace tinyxml2
{

	XMLPrinter::XMLPrinter(void)
	{
	}

	XMLPrinter::XMLPrinter(FILE* a2,bool a3,int a4)
	{
		field_4=false;
		field_3C=true;
		field_40=a2;
		field_44=a4;
		field_48=-1;
		field_4C=true;
		field_4D=a3;
		memset(&field_4E,0,64);
		memset(&field_8E,0,64);
		for (int i=0;i<5;i++)
		{
			field_4E[symbols[i].symbol]=true;
		}
		field_8E['<']=field_8E['&']=field_8E['>']=true;
		field_D0.Push(0);
	}


	XMLPrinter::~XMLPrinter(void)
	{
	}

	bool tinyxml2::XMLPrinter::Visit(const XMLComment& a2)
	{
		char* v3=((XMLComment)a2).Value();
		PushComment(v3);
		return true;
	}

	bool tinyxml2::XMLPrinter::Visit(const XMLText& a2)
	{
		char* v3=((XMLText)a2).Value();
		PushText(v3,a2.field_30);
		return true;
	}

	bool tinyxml2::XMLPrinter::Visit(const XMLUnknown& a2)
	{
		char* v3=((XMLUnknown)a2).Value();
		PushUnknown(v3);
		return true;
	}

	bool XMLPrinter::Visit(const XMLDeclaration& a2)
	{
		char* v3=((XMLDeclaration)a2).Value();
		PushDeclaration(v3);
		return true;
	}

	bool XMLPrinter::VisitExit(const XMLElement& a2)
	{
		bool v3=CompactMode(a2);
		CloseElement(v3);
		return true;
	}

	bool XMLPrinter::VisitExit(const XMLDocument_AAA& a2)
	{
		return true;
	}

	bool XMLPrinter::CompactMode(const XMLElement& a2)
	{
		return a2.field_4D;
	}

	int XMLPrinter::CloseElement(bool a2)
	{
		field_44--;
		field_8.field_30--;
		if(field_4)
		{
			Print("/>");
		}
		else
		{
			if(field_48<=-1&&!a2)
			{
				Print("\n");
				PrintSpace(field_44);
			}
			Print("</%s>",field_8.field_0+field_8.field_30-1);
		}
		if(field_44==field_48) field_48=-1;
		if(!field_44 && !a2) Print("\n");
		field_4=false;
		return 0;
	}

	bool XMLPrinter::VisitEnter(const XMLElement& a2,const XMLAttribute* a3)
	{
		XMLElement* v7=a2.field_8->ToElement();
		bool v8;
		char* v9,*v10,*v11;
		XMLAttribute* v5=(XMLAttribute*)a3;
		if(a2.field_8 && v7)
		{
			v8=CompactMode(*v7);
		}
		else
		{
			v8=field_4D;
		}
		v9=((XMLElement)a2).Value();
		OpenElement(v9,v8);
		while (v5)
		{
			v10=v5->field_4.GetStr();
			v11=v5->field_10.GetStr();
			PushAttribute(v10,v11);
			v5=v5->field_1C;
		}
		return true;
	}

	bool XMLPrinter::VisitEnter(const XMLDocument_AAA& a2)
	{
		field_4C=a2.field_31;
		if(a2.field_30)
		{
			Print("%s","");
		}
		return true;
	}

	int XMLPrinter::OpenElement(const char* a2,bool a3)
	{
		SealElementIfJustOpened();
		field_8.Push(a2);
		if(field_48<=-1&&!field_3C&&!a3) Print("\n");
		if(!a3) PrintSpace(field_44);
		Print("<%s",a2);
		field_3C=false;
		field_4=true;
		field_44++;
		return field_44;
	}

	void XMLPrinter::PushAttribute(const char* a2,const char* a3)
	{
		Print(" %s=\"",a2);
		PrintString(a3,false);
		Print("\"");
	}

	void XMLPrinter::Print(const char* a2,...)
	{
		va_list va;
		va_start(va,a2);
		if(field_40)
		{
			vfprintf(field_40,a2,va);
		}
		else
		{
			int v4=vsnprintf(NULL,0,a2,va);
			char* v7=field_D0.PushArr(v4);
			vsnprintf(v7-1,v4+1,a2,va);
		}
	}

	void XMLPrinter::PushText(const char* a2,bool a3)
	{
		if(a2[0])
		{
			SealElementIfJustOpened();
			if(a3)
			{
				Print("<![CDATA[%s]]>",a2);
			}
			else PrintString(a2,true);
		}
	}

	void XMLPrinter::PushUnknown(const char* a2)
	{
		SealElementIfJustOpened();
		if(field_48<=-1&&!field_3C&&!field_4D)
		{
			Print("\n");
			PrintSpace(field_44);
		}
	}

	void XMLPrinter::PushDeclaration( const char* a2 )
	{
		SealElementIfJustOpened();
		if(field_48<=-1&&!field_3C&&!field_4D)
		{
			Print("\n");
			PrintSpace(field_44);
		}
		field_3C=false;
		Print("<?%s?>",a2);
	}

	void XMLPrinter::PushComment( const char* a2 )
	{
		SealElementIfJustOpened();
		if(field_48<=-1&&!field_3C&&!field_4D)
		{
			Print("\n");
			PrintSpace(field_44);
		}
		field_3C=false;
		Print("<--?%s?-->",a2);
	}

	void XMLPrinter::SealElementIfJustOpened()
	{
		if(field_4)
		{
			field_4=false;
			Print(">");
		}
	}

	void XMLPrinter::PrintSpace(int a2)
	{
		for (int i=0;i<a2;i++)
		{
			Print("\t");
		}
	}

	void XMLPrinter::PrintString( const char* a2,bool a3 )
	{
		char* v4=(char*)a2;
		bool* v5;
		char* v6=(char*)a2;
		int v7;
		if(!field_4C)
		{
			Print("%s",a2);
			return;
		}
		v5=field_4E;
		if(a3) v5=field_8E;
		
		while (true)
		{
			char v10=v4[0];
			if(!v10) break;
			if(v10<='?' && v5[v10])
			{
				if (v6<v4)
				{
					v7=v4-v6;
					Print("%.*s",v7,v6);
				}
				for (int i=0;i<5;i++)
				{
					if(symbols[i].symbol==v4[0])
					{
						Print("&%s;",symbols[i].name);
						break;
					}
				}
				v6++;
			}
			v4++;
		}

		if(v6<v4 || !field_4C) 
		{
			Print("%s",v6);
		}
	}

}




