#pragma once
#include "StrPair.h"
using namespace tinyxml2;

namespace tinyxml2
{
	class StrPair;
	template<int i>
	class MemPoolT;
	class XMLAttribute
	{
	public:
		StrPair field_4;
		StrPair field_10;
		XMLAttribute* field_1C; // next
		MemPoolT<36>* field_20;
		XMLAttribute(void);
		virtual ~XMLAttribute(void);
		char* ParseDeep(char* a2,bool a3);
		void SetAttribute(unsigned int a2);
		void SetAttribute(long long  a3);
		void SetAttribute(int a2);
		void SetAttribute(float a2);
		void SetAttribute(double a2);
		void SetAttribute(bool a2);
		void SetAttribute(const char* a2);
		int QueryUnsignedValue(unsigned int* a2);
		int QueryIntValue(int* a2);
		int QueryInt64Value(long long* a2);
		int QueryFloatValue(float* a2);
		int QueryDoubleValue(double* a2);
		int QueryBoolValue(bool* a2);
		int SetName(const char* a2);
		char* Value();
		char* Name();
	};
}


