#include "XmlSerializerInternal.h"

TGraphicFormats::TGraphicFormats()
{
}

TGraphicFormats::~TGraphicFormats()
{
}

TGraphicFormats TGraphicFormats::CreateById(eImageFormat a2, int a3)
{
	TGraphicFormats ret;
	uint i;
	for (i = 0; i != ret.m_xTGF_24.size(); i++)
	{
		if (ret.m_xTGF_24[i] == a2) break;
	}
	if (i == ret.m_xTGF_24.size())
	{
		//throw(runtime_error("Can't create format from id!"));
	}
	ret.m_nTGF_0 = a3;
	ret.m_nTGF_4 = i;

	return ret;
}

void TGraphicFormats::operator=(TGraphicFormats const&)
{
}

XmlSerializerInternal::XmlSerializerInternal()
{
}

XmlSerializerInternal::~XmlSerializerInternal()
{
}

int XmlSerializerInternal::makeXML(TResultContainer &)
{
	return 0;
}

int XmlSerializerInternal::makeXML(TResultContainerList &)
{
	return 0;
}