#pragma once
#include <memory.h>
#include "DynArray.h"
#define PAGE_SIZE 4096
namespace tinyxml2
{
	typedef long long QWORD;

	template<int i>
	class MemPoolT
	{
	public:
		tinyxml2::DynArray<int*,10> field_4;
		int field_34;
		int* field_38;
		int field_3C; // alloc counter
		int field_40;
		int field_44;
		int field_48;
		MemPoolT()
		{
		};
		virtual ~MemPoolT()
		{
			Clear();
		};
		virtual int* Alloc();
		virtual int** Clear();
		virtual void Free(void* a2);
		virtual int ItemSize();
		virtual MemPoolT<i>* SetTracked();
	};

	template<int i>
	int* MemPoolT<i>::Alloc()
	{
		int *v1=field_38,v4;
		if(field_38==NULL)
		{
			field_38=new int[i*(PAGE_SIZE/i)/4];
			memset(field_38,0,4*i*113);
			field_4.Push(field_38);
			v1=field_38;
			int unit=i/4;
			v1[1008]=0;
			v1+=1008%unit;
			for (int index=0;index<1008;index+=unit)
			{
				v1[index]=(int)&v1[index+unit];
			}
		}
		v4=field_3C;
		field_38=(int*)v1[0];
		field_3C++;
		if(v4>=field_44) field_44=v4+1;
		field_40++;
		field_48++;
		return field_38;
	};

	template<int i>
	int** MemPoolT<i>::Clear()
	{
		int** result;
		while (true)
		{
			if(!field_34) break;
			int v5=field_34;
			field_34--;
			if(field_4.field_0[field_34]) delete field_4.field_0[field_34];
		}
		result=&field_38;
		field_38=0;
		field_3C=field_40=field_44=0;
		return result;
	}

	template<int i>
	void MemPoolT<i>::Free(void* a2)
	{
		if(a2)
		{
			field_3C--;
			((int*)a2)[0]=(int)field_38;
			field_38=(int*)a2;
		}
	}

	template<int i>
	int MemPoolT<i>::ItemSize()
	{
		return i;
	}

	template<int i>
	MemPoolT<i>* MemPoolT<i>::SetTracked()
	{
		field_48--;
		return this;
	}
}
	                                                   

















































































































