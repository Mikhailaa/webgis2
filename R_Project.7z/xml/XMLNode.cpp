#include "StrPair.h"
#include "XMLUtil.h"
#include "XMLNode.h"
#include "XMLElement.h"
#include "XMLDocument.h"
#include "XMLUnknown.h"
#include "XMLDeclaration.h"
#include "XMLText.h"
#include "XMLComment.h"
#include "XMLPrinter.h"

namespace tinyxml2
{
	XMLNode::XMLNode(XMLDocument_AAA* a2)
	{
		field_18=field_1C=field_20=field_24=field_8;
		field_28=0;
		field_2C=0;
		field_4=a2;
	}


	XMLNode::~XMLNode(void)
	{
	}

	char* XMLNode::Value() 
	{
		if(ToDocument()==NULL) return NULL;
		return field_C.GetStr();
	}

	XMLNode* XMLNode::Unlink(XMLNode* a2)
	{
		if(field_18==a2) field_18=a2->field_24;
		if(field_1C==a2) field_1C=a2->field_20;
		if(a2->field_20) a2->field_20->field_24=a2->field_24;
		if(a2->field_24) a2->field_24->field_20=a2->field_20;
		a2->field_8=0;
		return NULL;
	}

	XMLText* XMLNode::ToText() const
	{
		return NULL;
	}

	XMLElement* XMLNode::ToElement() const
	{
		return NULL;
	}

	XMLDocument_AAA* XMLNode::ToDocument() const
	{
		return NULL;
	}

	XMLDeclaration* XMLNode::ToDeclaration() const
	{
		return NULL;
	}

	XMLComment* XMLNode::ToComment() const
	{
		return NULL;
	}

	XMLUnknown* XMLNode::ToUnknown() const
	{
		return NULL;
	}

	int XMLNode::SetValue(const char* a2,bool a3)
	{
		if(a3==false) return field_C.SetStr(a2,a3);
		field_C.Reset();
		field_C.field_4=(char*)a2;
		return 0;
	}

	char* XMLNode::ParseDeep(char* a2,StrPair* a3)
	{
		return NULL;
	}

	XMLElement* XMLNode::NextSiblingElement(const char* a2)
	{
		tinyxml2::XMLNode* v2=this;
		tinyxml2::XMLElement* v4;
		char* v6;
		while (true)
		{
			v2=v2->field_24;
			if(!v2) break;
			v4=v2->ToElement();
			if(v4)
			{
				if(!a2) return v4;
				v6=v4->Value();
				if(XMLUtil::StringEqual(a2,v6,-1)) return v4;
			}
		}
		return NULL;
	}

	XMLNode* XMLNode::InsertFirstChild(XMLNode* a2)
	{
		if(a2->field_4!=field_4) return 0;
		field_4->InsertChildPreamble(a2); 
		if(field_18)
		{
			field_18->field_20=a2;
			a2->field_24=field_18;
			field_18=a2;
		}
		else
		{
			field_18=a2;
			field_1C=a2;
			a2->field_24=0;
		}
		a2->field_8=this;
		field_20=NULL;
		return a2;
	}

	XMLNode* XMLNode::InsertEndChild(XMLNode* a2)
	{
		if(a2->field_4)
		if(a2->field_4!=field_4) return 0;
		field_4->InsertChildPreamble(a2);
		if(field_1C)
		{
			field_1C->field_24=a2;
			a2->field_20=field_1C;
			field_1C=a2;
		}
		else
		{
			field_18=a2;
			field_1C=a2;
			a2->field_20=0;
		}
		a2->field_8=this;
		field_24=NULL;
		return a2;
	}

	void* XMLNode::InsertChildPreamble(XMLNode* a2)
	{
		if(a2->field_8) return a2->field_8->Unlink(a2);
		else return ((MemPoolT<48>*)a2->field_2C)->SetTracked();
	}

	XMLNode* XMLNode::InsertAfterChild(XMLNode* a2,XMLNode* a3)
	{
		bool v8=field_4==a3->field_4;
		if(v8) v8=a2->field_8==this;
		if(!v8) return NULL;
		if(a2->field_24)
		{
			a2->field_24->InsertChildPreamble(a3);
			a3->field_20=a2;
			a3->field_24=a2->field_24;
			a2->field_24->field_20=a3;
			a2->field_24=a3;
			a3->field_8=this;
			return a3;
		}
		return InsertEndChild(a3);
	}

	XMLElement* XMLNode::FirstChildElement(const char* a2)
	{
		XMLNode *i;
		XMLElement *v4;
		char* v6;
		for (i=field_18;; i=i->field_24)
		{
			if(i==NULL) break;
			v4=i->ToElement();
			if(v4)
			{
				if(a2==NULL) return v4;
				v6=v4->Value();
				if(XMLUtil::StringEqual(v6,a2,-1)) return v4;
			}
		}
		return NULL;
	}

	XMLNode* XMLNode::DeleteNode(XMLNode* a2)
	{
		((MemPoolT<48>*)a2->field_2C)->Free(this);
		return this;
	}

	XMLNode* XMLNode::DeleteChild(XMLNode* a2)
	{
		Unlink(a2);
		return a2->DeleteNode(NULL);
	}

	void XMLNode::DeleteChildren()
	{
		XMLNode* v1=this,*v3;
		while (true)
		{
			v3=v1->field_18;
			if(!v3) break;
			v1->Unlink(v3);
			v3->DeleteNode(NULL);
		}
		field_18=field_1C=0;
	}
}

