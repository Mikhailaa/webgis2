#include "XMLAttribute.h"
#include "MemPoolT.h"
#include "XMLUtil.h"
#include "XMLDocument.h"
#include "XMLNode.h"

namespace tinyxml2
{
	XMLAttribute::XMLAttribute(void)
	{
		
	}

	XMLAttribute::~XMLAttribute(void)
	{
		field_10.Reset();
		field_4.Reset();
	}

	char* XMLAttribute::ParseDeep( char* a2,bool a3 )
	{
		char v15[20]="";
		char* v6 = field_4.ParseName(a2);
		if(!v6) 
			return 0;
		if(!*v6)
			return 0;
		char *v7 = XMLUtil::SkipWhiteSpace(v6);
		if(*v7 != '=')
			return 0;
		char *v8 = XMLUtil::SkipWhiteSpace(v7+1);
		if(*v8 == '"')
		{
			v15[0] = *v8;
			v15[1] = 0;
			return field_10.ParseText(v8 + 1,v15,(a3 ? 3 : 2));
		}
		return NULL;
	}

	void XMLAttribute::SetAttribute( unsigned int a2 )
	{
		char a3a[200]="";
		XMLUtil::ToStr(a2,a3a,0xBC);
		field_10.SetStr(a3a,0);
	}

	void XMLAttribute::SetAttribute( long long a3 )
	{
		char a3a[200]="";
		XMLUtil::ToStr(a3,a3a,200);
		field_10.SetStr(a3a,0);
	}

	void XMLAttribute::SetAttribute( int a2 )
	{
		char a3a[200]="";
		XMLUtil::ToStr(a2,a3a,0xBC);
		field_10.SetStr(a3a,0);
	}

	void XMLAttribute::SetAttribute( float a2 )
	{
		char a3a[200]="";
		XMLUtil::ToStr(a2,a3a,0xBC);
		field_10.SetStr(a3a,0);
	}

	void XMLAttribute::SetAttribute( double a2 )
	{
		char a3a[200]="";
		XMLUtil::ToStr(a2,a3a,0xBC);
		field_10.SetStr(a3a,0);
	}

	void XMLAttribute::SetAttribute( bool a2 )
	{
		char a3a[200]="";
		XMLUtil::ToStr(a2,a3a,0xBC);
		field_10.SetStr(a3a,0);
	}

	void XMLAttribute::SetAttribute( const char* a2 )
	{
		field_10.SetStr(a2,0);
	}

	int XMLAttribute::QueryUnsignedValue( unsigned int* a2 )
	{
		char* v3 = field_10.GetStr();
		int v5 = XMLUtil::ToUnsigned(v3,a2);
		return v5 ? 0 : 2;
	}

	int XMLAttribute::QueryIntValue( int* a2 )
	{
		const char* v3 = field_10.GetStr();
		int v5 = XMLUtil::ToInt(v3,a2);
		return v5 ? 0 : 2;
	}

	int XMLAttribute::QueryInt64Value( long long* a2 )
	{
		const char* v3 = field_10.GetStr();
		int v5 = XMLUtil::ToInt64(v3,a2);
		return v5 ? 0 : 2;
	}

	int XMLAttribute::QueryFloatValue( float* a2 )
	{
		const char* v3 = field_10.GetStr();
		int v5 = XMLUtil::ToFloat(v3,a2);
		return v5 ? 0 : 2;
	}

	int XMLAttribute::QueryDoubleValue( double* a2 )
	{
		const char* v3 = field_10.GetStr();
		int v5 = XMLUtil::ToDouble(v3,a2);
		return v5 ? 0 : 2;
	}

	int XMLAttribute::QueryBoolValue( bool* a2 )
	{
		const char* v3 = field_10.GetStr();
		int v5 = XMLUtil::ToBool(v3,a2);
		return v5 ? 0 : 2;
	}

	int XMLAttribute::SetName( const char* a2 )
	{
		return field_4.SetStr(a2,false);
	}

	char* XMLAttribute::Value()
	{
		return field_10.GetStr();
	}

	char* XMLAttribute::Name()
	{
		return field_4.GetStr();
	}
}

