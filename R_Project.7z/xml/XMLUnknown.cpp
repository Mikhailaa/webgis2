#include "XMLUtil.h"
#include "XMLDocument.h"
#include "XMLPrinter.h"
#include "XMLUnknown.h"


namespace tinyxml2
{
	XMLUnknown::XMLUnknown(XMLDocument_AAA* a2)
		:XMLNode(a2)
	{
		
	}


	XMLUnknown::~XMLUnknown(void)
	{
	}

	XMLUnknown* XMLUnknown::ToUnknown() const
	{
		return 0;
	}

	bool tinyxml2::XMLUnknown::ShallowEqual(const XMLNode* a2)
	{
		XMLNode* v3=(XMLNode*)(a2->ToUnknown());
		if(!v3) return false;
		char* v4=v3->Value();
		char* v5=Value();
		return XMLUtil::StringEqual(v4,v5,-1);
	}

	XMLUnknown* XMLUnknown::ShallowClone(XMLDocument_AAA* a2)
	{
		XMLDocument_AAA* v2=a2;
		if(!a2) v2=field_4;
		char* v3=Value();
		return v2->NewUnknown(v3);
	}

	int XMLUnknown::Accept(XMLPrinter* a2)
	{
		return a2->Visit(*this);
	}

	char* XMLUnknown::ParseDeep(char* a2,StrPair* a3)
	{
		char* result=field_C.ParseText(a2,">",2);
		if(result==0)
		{
			field_4->field_34=14;
			field_4->field_3C=a2;
			field_4->field_40=0;
		}
		return result;
	}
}




