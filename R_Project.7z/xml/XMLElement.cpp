#include "XMLNode.h"
#include "XMLElement.h"
#include "XMLAttribute.h"
#include "XMLDocument.h"
#include "XMLUtil.h"
#include "XMLPrinter.h"

namespace tinyxml2
{
	XMLElement::XMLElement(XMLDocument_AAA* a2)
		:XMLNode(a2)
	{
		field_34=NULL;
		field_30=0;
	}


	XMLElement::~XMLElement(void)
	{
		XMLAttribute* v2=field_34,*v4;
		while(v2)
		{
			v4=v2->field_1C;
			DeleteAttribute(v2);
			field_34=v4;
			v2=v4;
		}
	}

	void XMLElement::DeleteAttribute( XMLAttribute* a2 )
	{
		if(a2)
		{
			a2->field_20->Free(a2);
		}
	}

	void XMLElement::DeleteAttribute( const char* a2 )
	{
		XMLAttribute* v9=field_34,*v4=NULL; 
		XMLAttribute** v2=&field_34;
		while (true)
		{
			if(v9==0) break;
			char* v6=v9->field_4.GetStr();
			if(XMLUtil::StringEqual(a2,v6,-1))
			{
				if(v4) v2=&v4->field_1C;
				*v2=v9->field_1C;
				DeleteAttribute(v9);
				return;
			}
			v4=v9;
			v9=v9->field_1C;
		}
	}

	bool XMLElement::ShallowEqual( const XMLNode* a2 )
	{
		XMLElement* v4=a2->ToElement();
		if(!v4) return false;
		char* v5=v4->Value();
		char* v6=Value();
		if(!XMLUtil::StringEqual(v5,v6,-1)) return false;
		XMLAttribute* v8=v4->field_34;
		XMLAttribute* i=field_34;
		while (true)
		{
			if(!field_34 || field_34) break;
			char* v12=i->field_10.GetStr();
			char* v13=v8->field_10.GetStr();
			if(!XMLUtil::StringEqual(v12,v13,-1)) return false;
			v8=v8->field_1C;
			i=i->field_1C;
		}
		return ((unsigned int)v8|(unsigned int)i)==0;
	}

	XMLUnknown* XMLElement::ShallowClone( XMLDocument_AAA* a2 )
	{
		XMLDocument_AAA* v2=a2;
		if(a2==NULL) v2=field_4;
		char* v4=Value();
		XMLElement* v5=v2->NewElement(v4);
		XMLAttribute* i=field_34;
		while (true)
		{
			if(!i) break;
			char* v7=i->field_4.GetStr();
			char* v8=i->field_10.GetStr();
			v5->SetAttribute(v7,v8);
		}
		return (XMLUnknown*)v5;
	}

	void XMLElement::SetAttribute( const char* a2,const char* a3 )
	{
		XMLAttribute* v4=FindOrCreateAttribute(a2);
		v4->SetAttribute(a3);
	}

	void XMLElement::SetAttribute( const char* a2,unsigned int a3 )
	{
		XMLAttribute* v4=FindOrCreateAttribute(a2);
		v4->SetAttribute(a3);
	}

	void XMLElement::SetAttribute( const char* a2,long long a3 )
	{
		XMLAttribute* v4=FindOrCreateAttribute(a2);
		v4->SetAttribute(a3);
	}

	void XMLElement::SetAttribute( const char* a2,int a3 )
	{
		XMLAttribute* v4=FindOrCreateAttribute(a2);
		v4->SetAttribute(a3);
	}

	void XMLElement::SetAttribute( const char* a2,float a3 )
	{
		XMLAttribute* v4=FindOrCreateAttribute(a2);
		v4->SetAttribute(a3);
	}

	void XMLElement::SetAttribute( const char* a2,double a3 )
	{
		XMLAttribute* v4=FindOrCreateAttribute(a2);
		v4->SetAttribute(a3);
	}

	void XMLElement::SetAttribute( const char* a2,bool a3 )
	{
		XMLAttribute* v4=FindOrCreateAttribute(a2);
		v4->SetAttribute(a3);
	}

	void XMLElement::SetText( unsigned int a2 )
	{
		char v7[0xBC];
		XMLUtil::ToStr(a2,v7,0xBC);
		SetText(v7);
	}

	void XMLElement::SetText( long long a3 )
	{
		char v4[200];
		XMLUtil::ToStr(a3,v4,200);
		SetText(v4);
	}

	void XMLElement::SetText( int a2 )
	{
		char v7[0xBC];
		XMLUtil::ToStr(a2,v7,0xBC);
		SetText(v7);
	}

	void XMLElement::SetText( float a2 )
	{
		char v7[0xBC];
		XMLUtil::ToStr(a2,v7,0xBC);
		SetText(v7);
	}

	void XMLElement::SetText( double a2 )
	{
		char v4[200];
		XMLUtil::ToStr(a2,v4,200);
		SetText(v4);
	}

	void XMLElement::SetText( bool a2 )
	{
		char v7[0xBC];
		XMLUtil::ToStr(a2,v7,0xBC);
		SetText(v7);
	}

	void XMLElement::SetText( const char* a2 )
	{
		if(field_18 && field_18->ToText())
			field_18->field_C.SetStr(a2,false);
		else
		{
			XMLText* v6=field_4->NewText(a2);
			InsertFirstChild((XMLNode*)v6);
		}
	}

	int XMLElement::QueryUnsignedText( unsigned int* a2 )
	{
		if(!field_18 || !field_18->ToText()) return 19;
		char* v5=field_18->Value();
		bool v7=XMLUtil::ToUnsigned(v5,a2);
		if(v7) return 0;
		return 18;
	}

	int XMLElement::QueryUnsignedAttribute( const char* a2,unsigned int* a3 )
	{
		XMLAttribute* v4=FindOrCreateAttribute(a2);
		if(v4) return v4->QueryUnsignedValue(a3);
		return 1;
	}

	int XMLElement::QueryIntText( int* a2 )
	{
		if(!field_18 || !field_18->ToText()) return 19;
		char* v5=field_18->Value();
		bool v7=XMLUtil::ToInt(v5,a2);
		if(v7) return 0;
		return 18;
	}

	int XMLElement::QueryIntAttribute( const char* a2,int* a3 )
	{
		XMLAttribute* v4=FindOrCreateAttribute(a2);
		if(v4) return v4->QueryIntValue(a3);
		return 1;
	}

	int XMLElement::QueryInt64Text( long long* a2 )
	{
		if(!field_18 || !field_18->ToText()) return 19;
		char* v5=field_18->Value();
		bool v7=XMLUtil::ToInt64(v5,a2);
		if(v7) return 0;
		return 18;
	}

	int XMLElement::QueryFloatText( float* a2 )
	{
		if(!field_18 || !field_18->ToText()) return 19;
		char* v5=field_18->Value();
		bool v7=XMLUtil::ToFloat(v5,a2);
		if(v7) return 0;
		return 18;
	}

	int XMLElement::QueryDoubleText( double* a2 )
	{
		if(!field_18 || !field_18->ToText()) return 19;
		char* v5=field_18->Value();
		bool v7=XMLUtil::ToDouble(v5,a2);
		if(v7) return 0;
		return 18;
	}

	int XMLElement::QueryBoolText( bool* a2 )
	{
		if(!field_18 || !field_18->ToText()) return 19;
		char* v5=field_18->Value();
		bool v7=XMLUtil::ToBool(v5,a2);
		if(v7) return 0;
		return 18;
	}

	int XMLElement::QueryInt64Attribute( const char* a2,long long* a3 )
	{
		XMLAttribute* v4=FindOrCreateAttribute(a2);
		if(v4) return v4->QueryInt64Value(a3);
		return 1;
	}

	int XMLElement::QueryFloatAttribute( const char* a2,float* a3 )
	{
		XMLAttribute* v4=FindOrCreateAttribute(a2);
		if(v4) return v4->QueryFloatValue(a3);
		return 1;
	}

	int XMLElement::QueryDoubleAttribute( const char* a2,double* a3 )
	{
		XMLAttribute* v4=FindOrCreateAttribute(a2);
		if(v4) return v4->QueryDoubleValue(a3);
		return 1;
	}

	int XMLElement::QueryBoolAttribute( const char* a2,bool* a3 )
	{
		XMLAttribute* v4=FindOrCreateAttribute(a2);
		if(v4) return v4->QueryBoolValue(a3);
		return 1;
	}

	char* XMLElement::ParseDeep( char* a2,StrPair* a3 )
	{
		char* v5=XMLUtil::SkipWhiteSpace(a2);
		if(*v5=='/')
		{
			field_30=2;
			v5++;
		}
		char* v6=field_C.ParseName(v5);
		if(field_C.field_4==field_C.field_8) return NULL;
		char* v7=ParseAttributes(v6);
		if(NULL==v7) return NULL;
		if(*v7&&field_30==0) return ParseDeep(v7,a3);
		return v7;
	}

	char* XMLElement::ParseAttributes( char* a2 )
	{
		char* v5=a2;
		XMLAttribute* v4=NULL;
		while (v5)
		{
			v5=XMLUtil::SkipWhiteSpace(v5);
			if(*v5==0)
			{
				field_4->field_40=Value();
				field_4->field_3C=a2;
				field_4->field_34=7;
				return NULL;
			}
			if(!XMLUtil::IsNameStartChar(*v5))
			{
				if(*v5=='/')
				{
					if(v5[1]=='>')
					{
						field_30=true;
						return v5+2;
					}
				}
				else if(*v5=='>') return v5+1;
				else
				{
					field_4->field_40=v5;
					field_4->field_3C=a2;
					field_4->field_34=7;
					return NULL;
				}
			}
			field_4->mempool36.Alloc();
			XMLAttribute* v9=new XMLAttribute();
			v9->field_20=&field_4->mempool36;
			field_4->mempool36.SetTracked();
			v5=v9->ParseDeep(v5,field_4->field_31);
			if(v5==NULL)
			{
LABEL_16:		XMLElement::DeleteAttribute(v9);
				field_4->field_40=v5;
				field_4->field_3C=a2;
				field_4->field_34=8;
				return NULL;
			}
			char* v13=v9->field_4.GetStr();
			if(Attribute(v13,NULL)) goto LABEL_16;
			XMLAttribute** v14=&(v4->field_1C);
			if(v4==NULL) v14=&field_34;
			v4=v9;
			*v14=v9;
		}
		return NULL;
	}

	char* XMLElement::GetText()
	{
		if(field_18 && field_18->ToText()) return field_18->Value();
		else return NULL;
	}

	XMLAttribute* XMLElement::FindOrCreateAttribute( const char* a2 )
	{
		XMLAttribute* v6=field_34,*v5=NULL;
		XMLAttribute** v3=&field_34;
		while (true)
		{
			if(v6==NULL) break;
			char* v7=v6->field_4.GetStr();
			if(XMLUtil::StringEqual(v7,a2,-1)) return v6;
			v5=v6;
			v6=v6->field_1C;
		}
		XMLAttribute* v8=(XMLAttribute*)field_4->mempool36.Alloc();
		XMLAttribute v9;
		memcpy_s(v8,sizeof(XMLAttribute),&v9,sizeof(XMLAttribute));
		v8->field_20=&field_4->mempool36;
		if(v5) v3=&v5->field_1C;
		*v3=v8;
		v8->SetName(a2);
		v8->field_20->SetTracked();
		return v8;
	}

	XMLAttribute* XMLElement::FindAttribute( const char* a2 )
	{
		XMLAttribute* v2,*v6;
		for (v2=field_34;;v2=v6->field_1C)
		{
			v6=v2;
			if(!v2) break;
			char* v4=v6->field_4.GetStr();
			if(XMLUtil::StringEqual(v4,a2,-1)) return v6;
		}
		return NULL;
	}

	char* XMLElement::Attribute( const char* a2,const char* a3 )
	{
		XMLAttribute* v4=FindAttribute(a2);
		StrPair* v5;
		char* v6;
		if(v4 && ((v5=&v4->field_10,!a3) || (v6=v4->field_10.GetStr(),XMLUtil::
			StringEqual(v6,a3,-1))))
		{
			return v5->GetStr();
		}
		return NULL;
	}

	int XMLElement::Accept( XMLPrinter* a2 )
	{
		XMLNode* v4,*v5;
		if(a2->VisitEnter(*this,field_34))
		{
			v4=field_18;
			do 
			{
				v5=v4;
				if(v5==NULL) break;
				v4=v5->field_24;
			} while (v5->Accept(a2)); /////??????????????????????????????
		}
		return a2->VisitExit(*this);
	}
}

