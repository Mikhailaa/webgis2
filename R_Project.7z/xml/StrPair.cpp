#include "StrPair.h"
#include "XMLUtil.h"
#include "XMLPrinter.h"

namespace tinyxml2
{
	StrPair::StrPair(void)
	{
	}


	StrPair::~StrPair(void)
	{
		Reset();
	}

	char* StrPair::ParseName( char* a2 )
	{
		if(!a2 || !*a2 || !XMLUtil::IsNameStartChar(*a2))
		{
			return NULL;
		}
		bool v6;
		char* v4=a2+1;
		do 
		{
			if(!*v4) break;
			v6=XMLUtil::IsNameChar(*v4);
			v4++;
		} while (v6);
		Reset();
		field_0=256;
		field_4=a2;
		field_8=v4;
		return v4;
	}

	int StrPair::CollapseWhitespace()
	{
		char* v3=XMLUtil::SkipWhiteSpace(field_4);
		field_4=v3;
		int result=*v3;
		char* v4=v3;
		if(result)
		{
			char* v6=v4;
			while (result)
			{
				if(XMLUtil::IsWhiteSpace(result))
				{
					v4=XMLUtil::SkipWhiteSpace(v4);
					if(!*v4) break;
					*v6=' ';
					v6++;
				}
				v6=v4;
				v6++;
				v4++;
				result=*v4;
			}
			result=0;
			*v6=0;
		}
		return result;
	}

	int StrPair::Set( char* a2,char* a3,int a4 )
	{
		Reset();
		int result=a4|0x100;
		field_0=result;
		field_4=a2;
		field_8=a3;
		return result;
	}

	void StrPair::TransferTo( StrPair* a2 )
	{
		if(this!=a2)
		{
			a2->Reset();
			a2->field_0=field_0;
			a2->field_4=field_4;
			a2->field_8=field_8;
			field_0=0;
			field_4=field_8=NULL;
		}
	}

	char* tinyxml2::StrPair::ParseText(char* a2, const char* a3, int a4)
	{
		char v8=*a3;
		int v9=strlen(a3);
		char* i=a2;
		for (;;)
		{
			if(!*i) return NULL;
			if(*i==v8&&!strncmp(i,a3,v9)) break;
			i++;
		}
		Set(a2,i,a4);
		return i+v9;
	}

	char* tinyxml2::StrPair::GetStr(void) 
	{
		int a4,v2=0;
		char a3[4];
		if(!(field_0 & 0x100)) return field_4;
		*field_8=0;
		bool v3=field_0==0x100;
		field_0^=100;
		if(!v3)
		{
			char* v4=field_4;
			char* v5=field_4;
			while (v5<field_8)
			{
				if(field_0&2)
				{
					char v7=*v5;
					if(v7=='\n')
					{
						v5++;
						*v4++='\n';
						if(*v5=='\r') v5++;
					}
					else if(v7=='\r')
					{
						v5++;
						*v4++='\n';
						if(*v5=='\n') v5++;
					}
				}
				else
				{
					char v9=*v5;
					if(v9=='\n'||v9=='\r') continue;
					if((field_0&1)&&v9=='&')
					{
						if(v5[1]=='#')
						{
							*(unsigned int*)a3=0;
							char* v10=XMLUtil::GetCharacterRef(v5,a3,&a4);
							int v11;
							if(v9)
							{
								memcpy(v4,a3,a4);
								v11=a4;
								v5=v10;
							}
							else
							{
								*v4=*v5++;
								v11=1;
							}
							v4+=v11;
						}
						else
						{
							for (int i=0;i<4;i++)
							{
								if(!strncmp(v5+1,symbols[i].name,symbols[i].namelen&&v5[symbols[i].namelen+1]==';'))
								{
									*v4++=symbols[i].symbol;
									v5+=symbols[i].namelen+2;
									break;
								}

							}
							v4++;
							v5++;
						}
					}
					else
					{
						*v4++=v9;
						v5++;
					}
				}
			}
			*v4=0;
			v2=field_0;
			if(field_0&4)
			{
				CollapseWhitespace();
			}
		}
		field_0=v2&0x200;
		return field_4;
	}

	int tinyxml2::StrPair::SetStr(const char* a2, int a3)
	{
		Reset();
		int v6=strlen(a2);
		char* v9=new char[v6+1];
		field_4=v9;
		memcpy_s(v9,v6+1,a2,v6+1);
		field_8=v9+v6;
		field_0=a3|0x200;
		return field_0;
	}
	
	void tinyxml2::StrPair::Reset(void)
	{
		if(field_0&0x200) delete field_4;
		field_0=0;
		field_4=field_8=NULL;
	}
}









