#include "processmanagerdefault.h"
#include "common/common.h"
#include "sdk/TSDKProcessingClass.h"

namespace processmanagerdefault
{
	namespace scenario
	{
		vector<eProcessScenario> getScenarioWithDocTypeRequired(void)
		{
			vector<eProcessScenario> v = { ProcessScenario_DocType, ProcessScenario_Ocr, ProcessScenario_FullProcess, ProcessScenario_FullAuth };
			return v;
		}

		unordered_map<string, eProcessScenario>& sub_3FEE70()
		{
			static unordered_map<string, eProcessScenario> g_map_1129934 = {
				unordered_map<string, eProcessScenario>::value_type(string("Mrz"), ProcessScenario_Mrz),
				unordered_map<string, eProcessScenario>::value_type(string("Barcode"), ProcessScenario_Barcode),
				unordered_map<string, eProcessScenario>::value_type(string("Locate"), ProcessScenario_Locate),
				unordered_map<string, eProcessScenario>::value_type(string("Ocr"), ProcessScenario_Ocr),
				unordered_map<string, eProcessScenario>::value_type(string("OcrFree"), ProcessScenario_OcrFree),
				unordered_map<string, eProcessScenario>::value_type(string("DocType"), ProcessScenario_DocType),
				unordered_map<string, eProcessScenario>::value_type(string("MrzOrBarcode"), ProcessScenario_MrzOrBarcode),
				unordered_map<string, eProcessScenario>::value_type(string("MrzOrLocate"), ProcessScenario_MrzOrLocate),
				unordered_map<string, eProcessScenario>::value_type(string("MrzAndLocate"), ProcessScenario_MrzAndLocate),
				unordered_map<string, eProcessScenario>::value_type(string("MrzOrOcr"), ProcessScenario_MrzOrOcr),
				unordered_map<string, eProcessScenario>::value_type(string("MrzOrBarcodeOrOcr"), ProcessScenario_MrzOrBarcodeOrOcr),
				unordered_map<string, eProcessScenario>::value_type(string("LocateVisual_And_MrzOrOcr"), ProcessScenario_LocateVisual_And_MrzOrOcr),
				unordered_map<string, eProcessScenario>::value_type(string("CreditCard"), ProcessScenario_CreditCard),
				unordered_map<string, eProcessScenario>::value_type(string("FullProcess"), ProcessScenario_FullProcess),
				unordered_map<string, eProcessScenario>::value_type(string("Id3Rus"), ProcessScenario_Id3Rus),
				unordered_map<string, eProcessScenario>::value_type(string("FullAuth"), ProcessScenario_FullAuth),
				unordered_map<string, eProcessScenario>::value_type(string("RusStamp"), ProcessScenario_RusStamp),
				unordered_map<string, eProcessScenario>::value_type(string("Capture"), ProcessScenario_Capture),
			};

			return g_map_1129934;
		}

		eProcessScenario convert(string const&a1)
		{
			return common::mapValues(sub_3FEE70(), a1, ProcessScenario_0);
		}

		eProcessScenario convert(ProcessParamsHolder &a1)
		{
			if (!a1.m_fPPH_doExtendProcessingMode)
				return ProcessScenario_0;
			if (a1.m_nPPH_processParam & 0x80)
				return ProcessScenario_Ocr;
			if (a1.m_nPPH_processParam & 0x20)
				return ProcessScenario_DocType;
			if (a1.m_nPPH_processParam & 0x10)
			{
				if (a1.m_nPPH_processParam & 0x40)
					return ProcessScenario_MrzAndLocate;
				return ProcessScenario_Locate;
			}
			if (a1.m_nPPH_processParam & 0x40)
			{
				if (a1.m_nPPH_processParam & 0x100)
					return ProcessScenario_MrzOrBarcode;
				return ProcessScenario_Mrz;
			}
			if (a1.m_nPPH_processParam & 0x100)
				return ProcessScenario_Barcode;
			return ProcessScenario_0;
		}

		string convert(eProcessScenario a2)
		{
			string str;
			vector<string> vecStr = common::mapKeys(sub_3FEE70(), a2);
			if (!vecStr.empty())
				return vecStr[0];
			return str;
		}

		void convertScenario(eProcessScenario a1, common::container::RclHolder & a2, ProcessParamsHolder & a3)
		{
			vector<eRPRM_GetImage_Modes> ve1a;
			vector<processparams::eProcessMode> ve10;

			switch (a1)
			{
			case ProcessScenario_Mrz:
				ve1a = { RPRM_GetImage_Modes_40 };
				break;
			case ProcessScenario_Barcode:
				ve1a = { RPRM_GetImage_Modes_100 };
				break;
			case ProcessScenario_Locate:
				ve1a = { RPRM_GetImage_Modes_10 };
				break;
			case ProcessScenario_Ocr:
			case ProcessScenario_LocateVisual_And_MrzOrOcr:
			case ProcessScenario_RusStamp:
			case ProcessScenario_OcrFree:
				ve1a = { RPRM_GetImage_Modes_84 };
				break;
			case ProcessScenario_DocType:
				ve1a = { RPRM_GetImage_Modes_20 };
				break;
			case ProcessScenario_MrzOrBarcode:
				ve1a = { RPRM_GetImage_Modes_40,  RPRM_GetImage_Modes_100 };
				break;
			case ProcessScenario_MrzOrLocate:
			case ProcessScenario_MrzAndLocate:
				ve1a = { RPRM_GetImage_Modes_40,  RPRM_GetImage_Modes_10 };
				break;
			case ProcessScenario_MrzOrOcr:
				ve1a = { RPRM_GetImage_Modes_40,  RPRM_GetImage_Modes_84 };
				break;
			case ProcessScenario_MrzOrBarcodeOrOcr:
				ve1a = { RPRM_GetImage_Modes_40, RPRM_GetImage_Modes_100, RPRM_GetImage_Modes_84 };
				break;
			case ProcessScenario_CreditCard:
				ve1a = { RPRM_GetImage_Modes_10 };
				ve10 = { processparams::PROCESSMODE_creditcard,  processparams::PROCESSMODE_lex };
				break;
			case ProcessScenario_FullProcess:
				ve1a = { RPRM_GetImage_Modes_84,  RPRM_GetImage_Modes_100 };
				break;
			case ProcessScenario_FullAuth:
				ve1a = { RPRM_GetImage_Modes_84, RPRM_GetImage_Modes_100, RPRM_GetImage_Modes_200 };
				if (!a3.m_llPPH_processAuth)
				{
					a3.SetProcessAuth(0xFFFFFFFFFFFFFFFF);
				}
				break;
			default:
				break;
			}

			int n5 = 0x10000;
			for (size_t i = 0; i < ve1a.size(); i++)
			{
				n5 |= ve1a[i];
			}

			for (size_t i = 0; i < ve10.size(); i++)
			{
				a3.setOption(ve10[i], true);
			}

			a3.m_fPPH_doExtendProcessingMode = true;
			a3.SetProcessParam(n5);
		}

		bool isSupportSeriesProcessMode(eProcessScenario a1)
		{
			return (a1 != ProcessScenario_Capture);
		}

		void sub_3FE558(eProcessScenario a1, vector<eModuleType> * a2)
		{
			a2[0].clear();
			a2[1].clear();

			switch (a1)
			{
			case ProcessScenario_Mrz:
				a2[1].push_back(ModuleType_MrzDetector);
				break;
			case ProcessScenario_Barcode:
				a2[1].push_back(ModuleType_BarcodesMT);
				a2[1].push_back(ModuleType_ExtBarcodeReader);
				break;
			case ProcessScenario_Locate:
				a2[1].push_back(ModuleType_DocBoundLocator);
				break;
			case ProcessScenario_Ocr:
			case ProcessScenario_RusStamp:
			case ProcessScenario_OcrFree:
				a2[1].push_back(ModuleType_ImSegger);
				break;
			case ProcessScenario_DocType:
				a2[1].push_back(ModuleType_RecPass);
				break;
			case ProcessScenario_MrzOrBarcode:
				a2[1].push_back(ModuleType_MrzDetector);
				a2[1].push_back(ModuleType_BarcodesMT);
				a2[1].push_back(ModuleType_ExtBarcodeReader);
				break;
			case ProcessScenario_MrzOrLocate:
				a2[1].push_back(ModuleType_MrzDetector);
				a2[1].push_back(ModuleType_DocBoundLocator);
				a2[1].push_back(ModuleType_CanDetector);
				break;
			case ProcessScenario_MrzAndLocate:
				a2[0].push_back(ModuleType_MrzDetector);
				a2[0].push_back(ModuleType_DocBoundLocator);
				break;
			case ProcessScenario_MrzOrOcr:
				a2[1].push_back(ModuleType_MrzDetector);
				a2[1].push_back(ModuleType_ImSegger);
				break;
			case ProcessScenario_MrzOrBarcodeOrOcr:
				a2[1].push_back(ModuleType_MrzDetector);
				a2[1].push_back(ModuleType_BarcodesMT);
				a2[1].push_back(ModuleType_ExtBarcodeReader);
				a2[1].push_back(ModuleType_ImSegger);
				break;
			case ProcessScenario_LocateVisual_And_MrzOrOcr:
				a2[0].push_back(ModuleType_DocBoundLocator);
				a2[1].push_back(ModuleType_MrzDetector);
				a2[1].push_back(ModuleType_ImSegger);
				break;
			case ProcessScenario_CreditCard:
				a2[0].push_back(ModuleType_CreditCard);
				break;
			case ProcessScenario_FullProcess:
				a2[0].push_back(ModuleType_ImSegger);
				a2[0].push_back(ModuleType_BarcodesMT);
				break;
			case ProcessScenario_Id3Rus:
				a2[0].push_back(ModuleType_Id3Rus);
				a2[1].push_back(ModuleType_ImSegger);
				break;
			case ProcessScenario_FullAuth:
				a2[0].push_back(ModuleType_RecPass);
				a2[0].push_back(ModuleType_Authenticity);
				break;
			case ProcessScenario_Capture:
				break;
			default:
				break;
			}
		}

		bool isProcessFinished(eProcessScenario a1, vector<IModuleStatus*> const & a2, bool a3)
		{
			if (a3 && common::process::isProcessingTimeExceeded())
				return true;
			if (a1)
			{
				vector<eModuleType> ve3a[2];
				sub_3FE558(a1, ve3a);
				vector<IModuleStatus *> vI2a = filterModulesByInitStatus(a2);
				vector<IModuleStatus *> vI21 = filterModulesByType(vI2a, ve3a[0]);

				for (size_t i = 0; i < vI21.size(); i++)
				{
					if (!vI21[i]->isFinished())
					{
						return false;
					}
				}

				vector<IModuleStatus *> vI1a = filterModulesByType(vI2a, ve3a[1]);

				if (vI1a.empty())
				{
					return true;
				}

				for (size_t i = 0; i < vI1a.size(); i++)
				{
					if (vI1a[i]->isResultReady())
					{
						return true;
					}
				}

				for (size_t i = 0; i < vI1a.size(); i++)
				{
					if (ScenarioRelations::isRelationsBlocked(vI1a[i]->m_vIMS_field_4))
					{
						return true;
					}
				}
			}
			return false;
		}

		bool isProcessFinished(eProcessScenario a1, vector<IModuleStatus*> const & a2, vector<eModuleType>& a3)
		{
			bool f7 = false;
			if (a1)
			{
				f7 = processmanagerdefault::scenario::isProcessFinished(a1, a2, true);
				vector<eModuleType> ve2a[2];
				sub_3FE558(a1, ve2a);
				vector<IModuleStatus *> vI1a = filterModulesByInitStatus(a2);
				vector<IModuleStatus *> vI12 = filterModulesByType(vI1a, ve2a[0]);
				vector<IModuleStatus *> vI11 = filterModulesByType(vI1a, ve2a[1]);
				a3.clear();
				vector<eModuleType> ve10 = getModulesNotFinished(vI12);
				a3.insert(a3.end(), ve10.begin(), ve10.end());
				vector<eModuleType> ve9 = getModulesNotFinished(vI11);
				a3.insert(a3.end(), ve9.begin(), ve9.end());
			}
			return f7;
		}

		void getScenarioDependence(eProcessScenario a1, vector<eModuleType>& a2)
		{
			vector<eModuleType> ve5[2];
			sub_3FE558(a1, ve5);
			a2 = ve5[0];
			a2.insert(a2.end(), ve5[1].begin(), ve5[1].end());
		}

		vector<eModuleType> getModulesNotFinished(vector<IModuleStatus*> const & a2)
		{
			vector<eModuleType> a1;

			for (size_t i = 0; i < a2.size(); i++)
			{
				if (!a2[i]->isResultReady())
				{
					a1.push_back(a2[i]->type());
				}
			}

			return vector<eModuleType>();
		}

		vector<IModuleStatus*> filterModulesByInitStatus(vector<IModuleStatus*> const & a2)
		{
			vector<IModuleStatus*> a1;

			for (size_t i = 0; i < a2.size(); i++)
			{
				if (a2[i]->isInitialized())
				{
					a1.push_back(a2[i]);
				}
			}

			return a1;
		}

		vector<IModuleStatus*> filterModulesByType(vector<IModuleStatus*> const & a2, vector<eModuleType> const & a3)
		{
			vector<IModuleStatus*> a1;

			for (size_t i = 0; i < a3.size(); i++)
			{
				for (size_t j = 0; j < a2.size(); j++)
				{
					if (a2[j]->type() == a3[i])
					{
						a1.push_back(a2[j]);
					}
				}
			}

			return a1;
		}

		vector<eProcessScenario> filterScenarioByModules(vector<eProcessScenario> const & a2, vector<eModuleType> const & a3)
		{
			vector<eProcessScenario> a1;
			size_t i, j, k;

			for (i = 0; i < a2.size(); i++)
			{
				vector<eModuleType> ve13;
				getScenarioDependence(a2[i], ve13);
				for (j = 0; j < ve13.size(); j++)
				{
					for (k = 0; k < a3.size(); k++)
					{
						if (ve13[j] == a3[k]) break;
					}
					if (k < a3.size()) continue;
					break;
				}
				if (j == ve13.size()) a1.push_back(a2[i]);
			}

			return a1;
		}

		int getMultiPageOffMode(eProcessScenario a1)
		{
			if (a1 == ProcessScenario_Mrz || a1 == ProcessScenario_Barcode || a1 == ProcessScenario_MrzOrBarcode || a1 == ProcessScenario_MrzOrLocate || a1 == ProcessScenario_MrzOrBarcodeOrOcr ||
				a1 == ProcessScenario_Id3Rus || a1 == ProcessScenario_FullAuth || a1 == ProcessScenario_RusStamp || a1 == ProcessScenario_OcrFree)
				return 1;
			return 0;
		}

		map<eProcessScenario, eRPRM_Capabilities> & sub_3FE0A0()
		{
			static map<eProcessScenario, eRPRM_Capabilities> g_map_1129928 = {
				map<eProcessScenario, eRPRM_Capabilities>::value_type(ProcessScenario_MrzOrBarcodeOrOcr, RPRM_Capabilities_38),
				map<eProcessScenario, eRPRM_Capabilities>::value_type(ProcessScenario_FullProcess, RPRM_Capabilities_30),
				map<eProcessScenario, eRPRM_Capabilities>::value_type(ProcessScenario_FullAuth, RPRM_Capabilities_30),
				map<eProcessScenario, eRPRM_Capabilities>::value_type(ProcessScenario_CreditCard, RPRM_Capabilities_100004),
				map<eProcessScenario, eRPRM_Capabilities>::value_type(ProcessScenario_Mrz, RPRM_Capabilities_8),
				map<eProcessScenario, eRPRM_Capabilities>::value_type(ProcessScenario_Barcode, RPRM_Capabilities_20),
				map<eProcessScenario, eRPRM_Capabilities>::value_type(ProcessScenario_Locate, RPRM_Capabilities_4),
				map<eProcessScenario, eRPRM_Capabilities>::value_type(ProcessScenario_Ocr, RPRM_Capabilities_10),
				map<eProcessScenario, eRPRM_Capabilities>::value_type(ProcessScenario_OcrFree, RPRM_Capabilities_10),
				map<eProcessScenario, eRPRM_Capabilities>::value_type(ProcessScenario_RusStamp, RPRM_Capabilities_10),
				map<eProcessScenario, eRPRM_Capabilities>::value_type(ProcessScenario_DocType, RPRM_Capabilities_2000),
				map<eProcessScenario, eRPRM_Capabilities>::value_type(ProcessScenario_MrzOrBarcode, RPRM_Capabilities_28),
				map<eProcessScenario, eRPRM_Capabilities>::value_type(ProcessScenario_MrzOrLocate, RPRM_Capabilities_C),
				map<eProcessScenario, eRPRM_Capabilities>::value_type(ProcessScenario_MrzAndLocate, RPRM_Capabilities_C),
				map<eProcessScenario, eRPRM_Capabilities>::value_type(ProcessScenario_MrzOrOcr, RPRM_Capabilities_18),
				map<eProcessScenario, eRPRM_Capabilities>::value_type(ProcessScenario_Id3Rus, RPRM_Capabilities_18),
				map<eProcessScenario, eRPRM_Capabilities>::value_type(ProcessScenario_LocateVisual_And_MrzOrOcr, RPRM_Capabilities_401C),
				map<eProcessScenario, eRPRM_Capabilities>::value_type(ProcessScenario_Capture, RPRM_Capabilities_0)
			};
			
			return g_map_1129928;
		}

		vector<eProcessScenario> getAvailableScenarios(eRPRM_Capabilities a2)
		{
			vector<eProcessScenario> a1;

			for (map<eProcessScenario, eRPRM_Capabilities>::iterator iter = sub_3FE0A0().begin(); iter != sub_3FE0A0().end(); iter++)
			{
				if ((iter->second & a2) == iter->second)
					a1.push_back(iter->first);
			}

			return a1;
		}

		int getBarcodeExtMode(eProcessScenario a1)
		{
			if (a1 == ProcessScenario_Barcode || a1 == ProcessScenario_MrzOrBarcode || a1 == ProcessScenario_MrzOrBarcodeOrOcr || a1 == ProcessScenario_FullProcess || a1 == ProcessScenario_FullAuth)
				return 1;
			return 0;
		}

		eRPRM_Capabilities getCapabilities(eProcessScenario a1)
		{
			if (sub_3FE0A0().find(a1) == sub_3FE0A0().end())
				return (eRPRM_Capabilities )-1;
			return sub_3FE0A0()[a1];
		}

		string getCaptionForScenario(eProcessScenario a2)
		{
			switch (a2)
			{
			case ProcessScenario_Mrz:
				return string("MRZ");
			case ProcessScenario_Barcode:
				return string("Barcode");
			case ProcessScenario_Locate:
				return string("Locate");
			case ProcessScenario_Ocr:
				return string("Visual OCR");
			case ProcessScenario_DocType:
				return string("Document Type");
			case ProcessScenario_MrzOrBarcode:
				return string("MRZ or Barcode");
			case ProcessScenario_MrzOrLocate:
				return string("MRZ or Locate");
			case ProcessScenario_MrzAndLocate:
				return string("MRZ and Locate");
			case ProcessScenario_MrzOrOcr:
				return string("MRZ or Visual OCR");
			case ProcessScenario_MrzOrBarcodeOrOcr:
				return string("MRZ or Visual OCR or Barcode");
			case ProcessScenario_LocateVisual_And_MrzOrOcr:
				return string("MRZ or Visual OCR (with images)");
			case ProcessScenario_CreditCard:
				return string("Credit Card");
			case ProcessScenario_FullProcess:
				return string("Full Process");
			case ProcessScenario_Id3Rus:
				return string("Russian ID3 (fast)");
			case ProcessScenario_FullAuth:
				return string("Full Process + Authenticity");
			case ProcessScenario_RusStamp:
				return string("Visual OCR for stamp");
			case ProcessScenario_OcrFree:
				return string("Free OCR");
			case ProcessScenario_Capture:
				return string("Capture");
			default:
				break;
			}
			return string("Test scenario");
		}

		string getDescription(eProcessScenario a2)
		{
			switch (a2)
			{
			case ProcessScenario_Mrz:
				return string("Pre-defined processing scenario for getting MRZ results from input");
			case ProcessScenario_Barcode:
				return string("Pre-defined processing scenario for getting Barcode results from input");
			case ProcessScenario_Locate:
				return string("Pre-defined processing scenario for finding document blank on input");
			case ProcessScenario_Ocr:
				return string("Pre-defined processing scenario for getting documents Visual Zone OCR results from input");
			case ProcessScenario_DocType:
				return string("Pre-defined processing scenario for recognizing type of the document from input");
			case ProcessScenario_MrzOrBarcode:
				return string("Pre-defined processing scenario for getting MRZ and/or Barcode results from input");
			case ProcessScenario_MrzOrLocate:
				return string("Pre-defined processing scenario for finding document blank and/or getting MRZ results from input");
			case ProcessScenario_MrzAndLocate:
				return string("Pre-defined processing scenario for finding document blank and getting MRZ results from input");
			case ProcessScenario_MrzOrOcr:
				return string("Pre-defined processing scenario for getting MRZ or Visual Zone OCR results from input");
			case ProcessScenario_MrzOrBarcodeOrOcr:
				return string("Pre-defined processing scenario for getting MRZ or Barcode or Visual Zone OCR results from input");
			case ProcessScenario_LocateVisual_And_MrzOrOcr:
				return string("Pre-defined processing scenario for finding document blank and getting MRZ or Visual Zone OCR results from input");
			case ProcessScenario_CreditCard:
				return string("Pre-defined processing scenario for getting Bank Card data from input");
			case ProcessScenario_FullProcess:
				return string("Pre-defined processing scenario for getting all information from document");
			case ProcessScenario_Id3Rus:
				return string("Pre-defined processing scenario for getting all information from ID3 Russian document");
			case ProcessScenario_FullAuth:
				return string("Pre-defined processing scenario for getting all information from document and check authenticity");
			case ProcessScenario_RusStamp:
				return string("Pre-defined processing scenario for getting information from Russian document registration stamps");
			case ProcessScenario_OcrFree:
				return string("Pre-defined processing scenario for getting OCR results from input image");
			case ProcessScenario_Capture:
				return string("Pre-defined scenario for get full image from camera device without any recognize processing.");
			default:
				break;
			}
			return string();
		}

		int getFaceExtMode(eProcessScenario a1)
		{
			if (a1 == ProcessScenario_Locate || a1 == ProcessScenario_Ocr || a1 == ProcessScenario_DocType || a1 == ProcessScenario_MrzOrLocate || a1 == ProcessScenario_MrzAndLocate ||
				a1 == ProcessScenario_MrzOrOcr || a1 == ProcessScenario_MrzOrBarcodeOrOcr || a1 == ProcessScenario_LocateVisual_And_MrzOrOcr || a1 == ProcessScenario_FullProcess)
				return 1;
			return 0;
		}

		bool getManualCrop(eProcessScenario a1)
		{
			if (a1 == ProcessScenario_Mrz || a1 == ProcessScenario_Barcode || a1 == ProcessScenario_MrzOrBarcode || a1 == ProcessScenario_Id3Rus || a1 == ProcessScenario_OcrFree || a1 == ProcessScenario_Capture)
				return false;
			return true;
		}

		vector<eModuleType> getModulesType(vector<IModuleStatus *> const&a2)
		{
			vector<eModuleType> a1;

			a1.reserve(a2.size());
			for (size_t i = 0; i < a2.size(); i++)
			{
				a1.push_back(a2[i]->type());
			}

			return a1;
		}

		int getOrientation(eProcessScenario)
		{
			return 0;
		}

		pair<eResolutionType, vector<eRPRM_Lights>> getPriorityRequirements(vector<pair<eResolutionType, vector<eRPRM_Lights>>> &a2)
		{
			pair<eResolutionType, vector<eRPRM_Lights>> a1;
			size_t i, j, k;

			if (!a2.empty())
			{
				vector<eRPRM_Lights> tmp = { RPRM_Lights_6, RPRM_Lights_80 };
				vector<pair<eResolutionType, vector<eRPRM_Lights>>> v33 = {
					pair<eResolutionType, vector<eRPRM_Lights>>(ResolutionType_0, vector<eRPRM_Lights>(RPRM_Lights_6)),
					pair<eResolutionType, vector<eRPRM_Lights>>(ResolutionType_0, tmp),
					pair<eResolutionType, vector<eRPRM_Lights>>(ResolutionType_1, tmp),
					pair<eResolutionType, vector<eRPRM_Lights>>(ResolutionType_1, vector<eRPRM_Lights>(RPRM_Lights_6))
				};

				for (i = 0; i < v33.size(); i++)
				{
					for (j = 0; j < a2.size(); j++)
					{
						if (a2[j].first == v33[i].first && a2[j].second.size() == v33[i].second.size())
						{
							for (k = 0; k < a2[j].second.size(); k ++)
							{
								if (a2[j].second[k] != v33[i].second[k])
									break;
							}
							if (k == a2[j].second.size()) break;
						}
					}
					if (j < a2.size())
					{
						a1 = a2[j];
						break;
					}
				}
				if (i == v33.size()) a1 = a2[0];
			}

			return a1;
		}

		double getProportionLandscape(eProcessScenario a1)
		{
			if (a1 == ProcessScenario_Barcode || a1 == ProcessScenario_Capture)
				return 0.0;
			if (a1 == ProcessScenario_OcrFree)
				return 5.0;
			if (a1 == ProcessScenario_Id3Rus)
				return 1.42;
			return 1.59;
		}

		double getProportionLandscapeDoublePageSpread(eProcessScenario a1)
		{
			return getProportionLandscape(a1);
		}

		double getProportionPortrait(eProcessScenario a1)
		{
			if (a1 == ProcessScenario_Barcode || a1 == ProcessScenario_Capture)
				return 0.0;
			if (a1 == ProcessScenario_OcrFree)
				return 5.0;
			if (a1 == ProcessScenario_CreditCard)
				return 1.59;
			return 1.42;
		}

		double getProportionPortraitDoublePageSpread(eProcessScenario a1)
		{
			if (a1 == ProcessScenario_Ocr || a1 == ProcessScenario_DocType || a1 == ProcessScenario_MrzOrOcr || a1 == ProcessScenario_MrzOrBarcodeOrOcr ||
				a1 == ProcessScenario_LocateVisual_And_MrzOrOcr || a1 == ProcessScenario_FullProcess)
				return 0.71;
			return getProportionPortrait(a1);
		}

		bool getUVTorch(eProcessScenario a1)
		{
			return (a1 == ProcessScenario_FullAuth);
		}

		vector<pair<eResolutionType, vector<eRPRM_Lights>>> needRequirements(vector<TSDKProcessingClass *> const&a2, vector<eModuleType> const&a3)
		{
			vector<pair<eResolutionType, vector<eRPRM_Lights>>> a1;

			if (!a2.empty() && !a3.empty())
			{
				set<pair<eResolutionType, vector<eRPRM_Lights>>> v18;
				for (size_t i = 0, j; i < a2.size(); i++)
				{
					eModuleType v11 = a2[i]->type();
					for (j = 0; j < a3.size(); j++)
					{
						if (a3[j] == v11) break;
					}
					if (j < a3.size())
					{
						vector<eRPRM_Lights> v17 = a2[i]->lights();
						eResolutionType v16 = a2[i]->resolutionType();
						v18.emplace(v16, v17);
					}
				}
				if (v18.size())
				{
					a1.insert(a1.end(), v18.begin(), v18.end());
				}
			}

			return a1;
		}
	}

	namespace ScenarioRelations
	{
		bool isRelationsBlocked(vector<IModuleStatus *>& a2)
		{
			for (size_t i = 0; i < a2.size(); i++)
			{
				if (a2[i]->isFinished() && !a2[i]->isResultReady())
				{
					return true;
				}
			}
			return false;
		}

		vector<IModuleStatus*> setRelations(vector<IModuleStatus*>& a2)
		{
			vector<IModuleStatus*> a1;
			a1.assign(a2.begin(), a2.end());
			return a1;
		}
	}

	vector<eRPRM_Lights> IModuleRequirements::lights()
	{
		vector<eRPRM_Lights> ret;
		ret.push_back(RPRM_Lights_6);
		return ret;
	}

	eResolutionType IModuleRequirements::resolutionType()
	{
		return ResolutionType_0;
	}
	
	string convert(eModuleType a2)
	{
		static map<eModuleType, string> g_map_112994C = {
			map<eModuleType, string>::value_type(ModuleType_0, ""),
			map<eModuleType, string>::value_type(ModuleType_MrzDetector, "mrz"),
			map<eModuleType, string>::value_type(ModuleType_ExtBarcodeReader, "barcode"),
			map<eModuleType, string>::value_type(ModuleType_3, "barcode1d"),
			map<eModuleType, string>::value_type(ModuleType_BarcodesMT, "barcode2d"),
			map<eModuleType, string>::value_type(ModuleType_DocBoundLocator, "locate"),
			map<eModuleType, string>::value_type(ModuleType_RecPass, "doctype"),
			map<eModuleType, string>::value_type(ModuleType_Bind, ""),
			map<eModuleType, string>::value_type(ModuleType_ImSegger, "ocr"),
			map<eModuleType, string>::value_type(ModuleType_CanDetector, ""),
			map<eModuleType, string>::value_type(ModuleType_GraphicFieldCropper, ""),
			map<eModuleType, string>::value_type(ModuleType_CreditCard, "creditcard"),
			map<eModuleType, string>::value_type(ModuleType_ImageQuality, "imageQA"),
			map<eModuleType, string>::value_type(ModuleType_RFID, "rfid")
		};

		string a1;
		map<eModuleType, string>::iterator iter = g_map_112994C.find(a2);
		if (iter != g_map_112994C.end())
			a1 = iter->second;
		return a1;
	}
}