﻿#include "CountriesUtils.h"
#include "../common/resources.h"
#include "../common/StringUtils.h"
#include "../common/UnicodeUtils.h"
#include "../common/FilesystemUtils.h"
#include "../common/container/json.h"
#include "../common/ModuleOrchestrator.h"

GenericValue<UTF8<char> > * g_prpjGV_112A320 = 0;
GenericValue<UTF8<char> > * g_prpjGV_112A328 = 0;
GenericValue<UTF8<char> > * g_prpjGV_112A330 = 0;
bool g_bInit_112A324 = 0;

namespace countriesUtils_lib
{
	struct gCountriesUtils_global_registrator {
		shared_ptr<CountriesUtils> gCountriesUtils;
		gCountriesUtils_global_registrator() {
			gCountriesUtils = common::getModuleOrchestrator()->addModule<CountriesUtils>();
		}
	} gCountriesUtils_global_registrator_;

	CountriesUtils* getObj()
	{
		return gCountriesUtils_global_registrator_.gCountriesUtils.get();
	}

	CountriesUtils::CountriesUtils()
		: m_xCUL_GD(0, 1024, 0)
	{
	}

	CountriesUtils::~CountriesUtils()
	{
	}

	int CountriesUtils::init(TResultContainerList *trcl)
	{
		string str1("CountriesUtils.json");
		string str2;
		uchar *pch = 0;
		int n = 0;
		
		common::resources::getFile(trcl, str1, &pch, n, str2);
		int len = str2.length();
		if (pch && n && !len)
		{
			str2.append((char*)pch, n);
		}
		len = str2.length();
		if (!len)
		{
			str1 = string("/usr/local/lib/regula/sdk");	// common::RegulaConfig::GetInstallationPath()
			if (str1.length())
			{
				str1.append("CountriesUtils.json");
				common::filesystemutils::readFile(str1, str2);
			}
		}
		len = str2.length();
		if (len)
		{
			m_xCUL_GD = common::container::json::ReadString(str2);
			LatinToRusTranslator::init(m_xCUL_GD, m_mCUL_field_50);
			LatinToRusTranslator::initVisaCodes(m_xCUL_GD, m_mCUL_field_5C);
		}
		pch = 0;
		n = 0;
		str1 = string("ChinaUnicodes.json");
		common::resources::getFile(trcl, str1, &pch, n, str2);
		len = str2.length();
		if (pch && n && !len)
		{
			str2.append((char*)pch, n);
		}
		len = str2.length();
		if (!len)
		{
			str1 = string("/usr/local/lib/regula/sdk");	// common::RegulaConfig::GetInstallationPath()
			if (str1.length())
			{
				str1.append("CountriesUtils.json");
				common::filesystemutils::readFile(str1, str2);
			}
		}
		len = str2.length();
		if (len)
		{
			m_sCUL_field_48 = make_shared<ChineseUnicodeToUTF8Translator>();
			m_sCUL_field_48->m_xCUTUT_GD = common::container::json::ReadString(str2);
			if (m_sCUL_field_48->m_xCUTUT_GD.GetType() != kObjectType)
			{
				return 2;
			}
			return 2 * (m_sCUL_field_48->m_xCUTUT_GD.MemberCount() == 0);
		}
		return 0;
	}

	GenericDocument<UTF8<char> >* CountriesUtils::getJsonDoc()
	{
		return &m_xCUL_GD;
	}

	map<wstring, string>* CountriesUtils::rusToLatin()
	{
		return &m_mCUL_field_50;
	}

	map<string, wstring>* CountriesUtils::visaCodes()
	{
		return &m_mCUL_field_5C;
	}

	shared_ptr<ChineseUnicodeToUTF8Translator>* CountriesUtils::chinaTranslator()
	{
		return &m_sCUL_field_48;
	}

	vector<int> CountriesUtils::getCommands()
	{
		static vector<int> vCmd({ 205, 13700 });
		return vCmd;
	}

	int CountriesUtils::process(int a2, void *a3, const char *a4, void **a5, char **a6)
	{
		if (a2 == 205 || a2 == 13700)
		{
			return init((TResultContainerList*)a3);
		}
		return 1;
	}	

	/////////////////////////////////////////////////////
	/////////////////////////////////////////////////////

	LatinToRusTranslator::LatinToRusTranslator()
	{

	}

	LatinToRusTranslator::~LatinToRusTranslator()
	{

	}

	int LatinToRusTranslator::init(GenericDocument<UTF8<char> > & xrpjGD_Param1, map<wstring, string> & mParam2)
	{
		GenericValue<UTF8<char> > *pGV = common::container::json::GetMember(xrpjGD_Param1, string("RusToLatin"));
		for (GenericValue<UTF8<char> >::MemberIterator miter = pGV->MemberBegin(); miter != pGV->MemberEnd(); miter++)
		{
			wstring wname = common::UnicodeUtils::UncheckedUtf8ToWStr(miter->name.GetString());
			mParam2.emplace(pair<wstring, string>(wname, miter->value.GetString()));
		}
		return (mParam2.size() == 0);
	}

	int LatinToRusTranslator::initVisaCodes(GenericDocument<UTF8<char> > & xrpjGD_Param1, map<string, wstring> & mParam2)
	{
		GenericValue<UTF8<char> > *pGV = common::container::json::GetMember(xrpjGD_Param1, string("RusVisaCodes"));
		for (GenericValue<UTF8<char> >::MemberIterator miter = pGV->MemberBegin(); miter != pGV->MemberEnd(); miter++)
		{
			wstring wval = common::UnicodeUtils::UncheckedUtf8ToWStr(miter->value.GetString());
			mParam2.emplace(pair<string, wstring>(miter->name.GetString(), wval));
		}
		return (mParam2.size() == 0);
	}

	wstring LatinToRusTranslator::latinToRus(string & strParam)
	{
		wstring res;
		int len = strParam.length();
		for (int i = 0; i < len; i++)
		{
			char c[2] = { 0 };
			c[0] = strParam.at(i);
			string strTemp(c);
			CountriesUtils *pCU = getObj();
			map<wstring, string> *m = pCU->rusToLatin();
			map<wstring, string>::iterator iter;
			for (iter = m->begin(); iter != m->end(); iter++)
			{
				if (iter->second == strTemp)
				{
					res.append(iter->first);
				}
			}
		}
		return res;
	}

	string LatinToRusTranslator::rusToLatin(wstring & wsParam)
	{
		string res;
		int len = wsParam.length();
		for (int i = 0; i < len; i++)
		{
			wchar_t w[2] = { 0 };
			w[0] = wsParam.at(i);
			wstring wsTemp(w);
			CountriesUtils *pCU = getObj();
			map<wstring, string> *m = pCU->rusToLatin();
			int count = m->count(wsTemp);
			if (count) 
			{
				string str = m->at(wsTemp);
				res.append(str);
			}
		}
		return res;
	}

	bool LatinToRusTranslator::verifyVisaCode(string & strParam)
	{
		if (strParam.length() < 3)
		{
			return false;
		}
		string strTemp = strParam.substr(0, 3);
		CountriesUtils *pCU = getObj();
		map<string, wstring> *m = pCU->visaCodes();
		int count = m->count(strTemp);
		if (!count)
		{
			return false;
		}
		return true;
	}

	string LatinToRusTranslator::CodesRusVisaIdToRus(string & strParam)
	{
		string res = strParam;
		int len = strParam.length();
		if (len > 2)
		{
			string strTemp = strParam.substr(0, 3);
			CountriesUtils *pCU = getObj();
			map<string, wstring> *m = pCU->visaCodes();
			int count = m->count(strTemp);
			if (count)
			{
				res = common::UnicodeUtils::UncheckedWStrToUtf8(m->at(strTemp));
			}
			else
			{
				res = strTemp;
			}
		}
		return res;
	}

	
	/////////////////////////////////////////////////////
	/////////////////////////////////////////////////////

	ChineseUnicodeToUTF8Translator::ChineseUnicodeToUTF8Translator()
		: m_xCUTUT_GD(0, 1024, 0)
	{

	}

	ChineseUnicodeToUTF8Translator::~ChineseUnicodeToUTF8Translator()
	{

	}

	void ChineseUnicodeToUTF8Translator::getDocForInit()
	{
		
	}

	GenericValue<UTF8<char> > ChineseUnicodeToUTF8Translator::getUnicodesList()
	{
		GenericValue<UTF8<char> > res;
		if (m_xCUTUT_GD.GetAllocator().Size())
		{
			if (m_xCUTUT_GD.HasMember("ChineseUnicodeToUTF8"))
			{
				res = m_xCUTUT_GD["ChineseUnicodeToUTF8"];
			}
		}
		return res;
	}

	GenericValue<UTF8<char> > ChineseUnicodeToUTF8Translator::getSimplifiedList()
	{
		GenericValue<UTF8<char> > res;
		if (m_xCUTUT_GD.GetAllocator().Size())
		{
			if (m_xCUTUT_GD.HasMember("SimplifiedToUnicode"))
			{
				res = m_xCUTUT_GD["SimplifiedToUnicode"];
			}
		}
		return res;
	}

	GenericValue<UTF8<char> > ChineseUnicodeToUTF8Translator::getTraditionalList()
	{
		GenericValue<UTF8<char> > res;
		if (m_xCUTUT_GD.GetAllocator().Size())
		{
			if (m_xCUTUT_GD.HasMember("TraditionalToUnicode"))
			{
				res = m_xCUTUT_GD["TraditionalToUnicode"];
			}
		}
		return res;
	}

	bool ChineseUnicodeToUTF8Translator::isHex(string & strParam)
	{
		if (strParam.length())
		{
			string strCh("0123456789abcdefABCDEF");
			uint i;
			map<char, char> m;
			for (i = 0; i < strCh.length(); i++)
			{
				m[strCh[i]] = strCh[i];
			}
			for (i = 0; i < strParam.length(); i++)
			{
				if (!m.count(strParam[i]))
				{
					return false;
				}
			}
			return true;
		}
		return false;
	}

	string ChineseUnicodeToUTF8Translator::hexToBytes(string & strParam)
	{
		string res;
		if (isHex(strParam))
		{
			int i, len = strParam.length();
			for (i = 0; i < len; i += 2)
			{
				char stTemp[3] = { 0 };
				stTemp[0] = strParam[i];
				stTemp[1] = strParam[i + 1];
				long l = strtol(stTemp, 0, 16);
				res += (char)l;
			}
		}
		return res;
	}

	string ChineseUnicodeToUTF8Translator::toChineseUTF8(string & strParam)
	{
		if (!g_bInit_112A324)
		{
			return string("");
		}

		int i, len = strParam.length();
		if (len & 0x3)	// 중국어글자는 4바이트이므로 4의 배수인가를 판정.
		{
			return string("");
		}
		string res, strTemp;
		string str = ArithmeticStrUp(strParam);
		len = str.length();
		for (i = 0; i < len; i += 4)
		{
			char st[5] = { 0 };
			st[0] = str[i];
			st[1] = str[i + 1];
			st[2] = str[i + 2];
			st[3] = str[i + 3];
			strTemp = string(str);
			if (g_prpjGV_112A320->HasMember(st))
			{
				string strT;
				common::container::json::stringFromJson(*g_prpjGV_112A320, strT, strTemp);
				res.append(hexToBytes(strT));
			}
			else
			{
				res.append(strTemp);
			}
		}
		return res;
	}

	char ChineseUnicodeToUTF8Translator::ArithmeticCharUp(char chParam)
	{
		char res = '0';
		if (chParam >= 'A' && chParam <= 'J')
		{
			res = chParam - ('A' - '0');
		}
		else if (chParam > 'J' && chParam <= 'Z')
		{
			res = chParam - 10;
		}
		return res;
	}

	string ChineseUnicodeToUTF8Translator::ArithmeticStrUp(string & strParam)
	{
		string res;
		int i, len = strParam.length();
		for (i = 0 ; i < len; i++)
		{
			res += ChineseUnicodeToUTF8Translator::ArithmeticCharUp(strParam[i]);
		}
		return res;
	}

	wstring ChineseUnicodeToUTF8Translator::TraditionalToUnicode(string & strParam)
	{
		// getTraditionalList
		return SimpTrad_ToUnicode(strParam, *g_prpjGV_112A330);
	}

	wstring ChineseUnicodeToUTF8Translator::SimpTrad_ToUnicode(string & strParam)
	{
		// getSimplifiedList
		return SimpTrad_ToUnicode(strParam, *g_prpjGV_112A328);
	}

	wstring ChineseUnicodeToUTF8Translator::SimpTrad_ToUnicode(string & strParam1, GenericValue<UTF8<char> > & xrpjGV_Param2)
	{
		wstring res;
		int len = strParam1.length();
		if (len > 3)
		{
			vector<string> v;
			v = common::StringUtils::Split(strParam1, ' ');
			for (uint i = 0; i < v.size(); i++)
			{
				int l = v[i].length();
				if (!l || l != 4)
				{
					return wstring();
				}
				if (!g_prpjGV_112A320->HasMember(v[i].data()))
				{
					return wstring();
				}
				string strTemp;
				common::container::json::stringFromJson(*g_prpjGV_112A320, strTemp, v[i]);
				int n = strtol(strTemp.data(), 0, 16);
				res.push_back(n);
			}
		}
		return res;
	}

	wstring ChineseUnicodeToUTF8Translator::SimplifiedToUnicode(string & strParam)
	{
		// getSimplifiedList
		return SimpTrad_ToUnicode(strParam, *g_prpjGV_112A328);
	}


	/////////////////////////////////////////////////////
	/////////////////////////////////////////////////////

	CountryCodeConvertor::CountryCodeConvertor()
	{

	}

	CountryCodeConvertor::~CountryCodeConvertor()
	{

	}

	string CountryCodeConvertor::convert2to3(GenericDocument<UTF8<char> > & xrpjGD_Param1, string & strParam2)
	{
		string res = strParam2;
		string str;
		str = common::StringUtils::toUpper(strParam2);
		GenericValue<UTF8<char> > * prpjGV = common::container::json::GetMember(*xrpjGD_Param1.Begin(), string("CountryCodesConvert2to3"));
		if (!prpjGV->IsNull() && prpjGV->HasMember(str.data()))
		{
			res = string((*prpjGV)[str.data()].GetString());
		}
		return res;
	}


	/////////////////////////////////////////////////////
	/////////////////////////////////////////////////////

	CountryCodeToNameConvertor::CountryCodeToNameConvertor()
	{

	}

	CountryCodeToNameConvertor::~CountryCodeToNameConvertor()
	{

	}

	string CountryCodeToNameConvertor::convertCodeToName(GenericDocument<UTF8<char> > & xrpjGD_Param1, string & strParam2)
	{
		string res = strParam2;
		string str;
		str = common::StringUtils::toUpper(strParam2);
		string strTemp("CountryCodesConvertToName");
		GenericValue<UTF8<char> > *prpjGV = common::container::json::GetMember(*xrpjGD_Param1.Begin(), strTemp);
		if (!prpjGV->IsNull() && prpjGV->HasMember(str.data()))
		{
			string a2 = string((*prpjGV)[str.data()].GetString());
			res = common::StringUtils::Replace(a2, string("_"), string(" "));
		}
		return res;
	}

	int CountryCodeToNameConvertor::verifyCountryCode(GenericDocument<UTF8<char> > & xrpjGD_Param1, string & strParam2, bool bParam3)
	{
		string str;
		str = common::StringUtils::toUpper(strParam2);
		GenericValue<UTF8<char> > *prpjGV = common::container::json::GetMember(xrpjGD_Param1, string("CountryCodesConvertToName"));
		if (!prpjGV->IsNull() && prpjGV->HasMember(str.data()))
		{
			return 0;
		}
		if (!bParam3)
		{
			return 11;
		}
		prpjGV = common::container::json::GetMember(xrpjGD_Param1, string("NonstandatdCodesFromMRZ"));
		if (!prpjGV->IsNull() && prpjGV->HasMember(str.data()))
		{
			return 0;
		}
		return 11;
	}


	/////////////////////////////////////////////////////
	/////////////////////////////////////////////////////

	MRZTypesHolder::MRZTypesHolder()
	{

	}

	MRZTypesHolder::~MRZTypesHolder()
	{

	}

	int MRZTypesHolder::docTypeByFormat(GenericDocument<UTF8<char> > & xrpjGD_Param1, string & strParam2)
	{
		int nType = 0;
		static map<string, int> mDocType;

		if (!mDocType.size())
		{
			mDocType[string("dtDrivingLicense")] = 49;
			mDocType[string("dtIdentityCard")] = 12;
			mDocType[string("dtPermitToReenter")] = 133;
			mDocType[string("dtVisaID2")] = 29;
			mDocType[string("dtRegistrationCertificate")] = 206;
			mDocType[string("dtPassport")] = 11;
			mDocType[string("dtVisaID3")] = 30;
			mDocType[string("dtEmergencyPassport")] = 26;
			mDocType[string("dtTravelDocument")] = 17;
			mDocType[string("dtResidencePermitIdentityCard")] = 24;
		}
		GenericValue<UTF8<char> > *prpjGV = common::container::json::GetMember(xrpjGD_Param1, string("MRZNamesAndTypes"));
		if (!prpjGV->IsNull() && prpjGV->HasMember(strParam2.data()))
		{
			string v27((*prpjGV)[strParam2.data()].GetString());
			if (v27.length())
			{
				if(mDocType.count(v27))
					nType = mDocType[v27];
			}
		}
		return nType;
	}


	/////////////////////////////////////////////////////
	/////////////////////////////////////////////////////

	string translateToLatin(wstring & wsParam)
	{
		CountriesUtils * pObj = getObj();
		if (pObj->m_xCUL_GD.IsNull())
		{
			pObj->init(0);
		}
		return LatinToRusTranslator::rusToLatin(wsParam);
	}

	string convertCodeToName(string & strParam)
	{
		CountriesUtils * pObj = getObj();
		if (pObj->m_xCUL_GD.IsNull())
		{
			pObj->init(0);
		}
		return CountryCodeToNameConvertor::convertCodeToName(pObj->m_xCUL_GD, strParam);
	}

	wstring SimplifiedToUnicode(string & strParam)
	{
		CountriesUtils * pObj = getObj();
		shared_ptr<ChineseUnicodeToUTF8Translator> sp = pObj->m_sCUL_field_48;
		if (!sp.get())
		{
			pObj->init(0);
		}
		sp = pObj->m_sCUL_field_48;
		if (!sp.get()->m_xCUTUT_GD.IsNull())
		{
			return ChineseUnicodeToUTF8Translator::SimplifiedToUnicode(strParam);
		}
		return wstring();
	}

	wstring TraditionalToUnicode(string & strParam)
	{
		CountriesUtils * pObj = getObj();
		shared_ptr<ChineseUnicodeToUTF8Translator> sp = pObj->m_sCUL_field_48;
		if (!sp.get())
		{
			pObj->init(0);
		}
		sp = pObj->m_sCUL_field_48;
		if (!sp.get()->m_xCUTUT_GD.IsNull())
		{
			return ChineseUnicodeToUTF8Translator::TraditionalToUnicode(strParam);
		}
		return wstring();
	}

	string translateToRussianUTF8(string & strParam)
	{
		CountriesUtils * pObj = getObj();
		if (pObj->m_xCUL_GD.IsNull())
		{
			pObj->init(0);
		}
		LatinToRusTranslator::latinToRus(strParam);
		return strParam;
	}

	string translateToChinese(string & strParam)
	{
		CountriesUtils * pObj = getObj();
		shared_ptr<ChineseUnicodeToUTF8Translator> sp = pObj->m_sCUL_field_48;
		if (!sp.get())
		{
			pObj->init(0);
		}
		sp = pObj->m_sCUL_field_48;
		if (!sp.get()->m_xCUTUT_GD.IsNull())
		{
			return ChineseUnicodeToUTF8Translator::toChineseUTF8(strParam);
		}
		return string();
	}

	int verifyCountryCode(string & strParam1, bool bParam2)
	{
		CountriesUtils * pObj = getObj();
		if (pObj->m_xCUL_GD.GetType() == kNullType)
		{
			pObj->init(0);
		}
		return CountryCodeToNameConvertor::verifyCountryCode(pObj->m_xCUL_GD, strParam1, bParam2);
	}

	string convert2to3(string & strParam)
	{
		CountriesUtils * pObj = getObj();
		if (pObj->m_xCUL_GD.IsNull())
		{
			pObj->init(0);
		}
		return CountryCodeConvertor::convert2to3(pObj->m_xCUL_GD, strParam);
	}

	string rusVisaCodeUTF8(string & strParam)
	{
		CountriesUtils * pObj = getObj();
		if (pObj->m_xCUL_GD.IsNull())
		{
			pObj->init(0);
		}
		return LatinToRusTranslator::CodesRusVisaIdToRus(strParam);
	}

	bool isValidRusVisaCode(string & strParam)
	{
		CountriesUtils * pObj = getObj();
		if (pObj->m_xCUL_GD.IsNull())
		{
			pObj->init(0);
		}
		return LatinToRusTranslator::verifyVisaCode(strParam);
	}

	int getDocTypeByFormatName(string & strParam)
	{
		CountriesUtils * pObj = getObj();
		if (pObj->m_xCUL_GD.IsNull())
		{
			pObj->init(0);
		}
		return countriesUtils_lib::MRZTypesHolder::docTypeByFormat(pObj->m_xCUL_GD, strParam);
	}
}

