#pragma once

#include "../pch.h"
#include "../commonStruct.h"
#include "../common/resources.h"
#include "document.h"
#include "../moduleprocessgl.h"

extern rapidjson::GenericValue<rapidjson::UTF8<char> > * g_prpjGV_112A320;
extern rapidjson::GenericValue<rapidjson::UTF8<char> > * g_prpjGV_112A328;
extern rapidjson::GenericValue<rapidjson::UTF8<char> > * g_prpjGV_112A330;
extern bool g_bInit_112A324;
extern map<string, int> g_mDocType_112A308;

namespace countriesUtils_lib
{
	class ChineseUnicodeToUTF8Translator
	{
	public:
		ChineseUnicodeToUTF8Translator();
		~ChineseUnicodeToUTF8Translator();
		void getDocForInit();
		rapidjson::GenericValue<rapidjson::UTF8<char> > getUnicodesList();
		rapidjson::GenericValue<rapidjson::UTF8<char> > getSimplifiedList();
		rapidjson::GenericValue<rapidjson::UTF8<char> > getTraditionalList();

		static bool isHex(string &);
		static string hexToBytes(string &);
		static string toChineseUTF8(string &);
		static char ArithmeticCharUp(char);
		static string ArithmeticStrUp(string &);
		static wstring TraditionalToUnicode(string &);
		static wstring SimpTrad_ToUnicode(string &);
		static wstring SimpTrad_ToUnicode(string &, rapidjson::GenericValue<rapidjson::UTF8<char> > &);
		static wstring SimplifiedToUnicode(string &);

	public:
		// members
		rapidjson::GenericDocument<rapidjson::UTF8<char> > m_xCUTUT_GD;

	};

	class CountriesUtils : public moduleprocessgl::IProcessFunction
	{
	public:
		// functions
		CountriesUtils();
		virtual ~CountriesUtils();
		int init(TResultContainerList *);
		rapidjson::GenericDocument<rapidjson::UTF8<char> >* getJsonDoc();
		map<wstring, string>* rusToLatin();
		map<string, wstring>* visaCodes();
		shared_ptr<ChineseUnicodeToUTF8Translator>* chinaTranslator();
		vector<int> getCommands();
		int process(int a2, void *a3, const char *a4, void **a5, char **a6);

	public:
		// members
		int m_nCUL_field_4;
		rapidjson::GenericDocument<rapidjson::UTF8<char> > m_xCUL_GD;	// on ida size is 60 byte, on vc size is 56 byte.
		int m_nCUL_field_40;
		int m_nCUL_field_44;
		shared_ptr<ChineseUnicodeToUTF8Translator> m_sCUL_field_48;
		map<wstring, string> m_mCUL_field_50;
		map<string, wstring> m_mCUL_field_5C;

	};

	CountriesUtils * getObj();

	class LatinToRusTranslator
	{
	public:
		LatinToRusTranslator();
		~LatinToRusTranslator();
		static int init(rapidjson::GenericDocument<rapidjson::UTF8<char> > &, map<wstring, string> &);
		static int initVisaCodes(rapidjson::GenericDocument<rapidjson::UTF8<char> > &, map<string, wstring> &);
		static wstring latinToRus(string &);
		static string rusToLatin(wstring &);
		static bool verifyVisaCode(string &);
		static string CodesRusVisaIdToRus(string &);
	};

	class CountryCodeConvertor
	{
	public:
		CountryCodeConvertor();
		~CountryCodeConvertor();

		static string convert2to3(rapidjson::GenericDocument<rapidjson::UTF8<char> > & xrpjGD_Param1, string & strParam2);
	};

	class CountryCodeToNameConvertor
	{
	public:
		CountryCodeToNameConvertor();
		~CountryCodeToNameConvertor();

		static string convertCodeToName(rapidjson::GenericDocument<rapidjson::UTF8<char> > & xrpjGD_Param1, string & strParam2);
		static int verifyCountryCode(rapidjson::GenericDocument<rapidjson::UTF8<char> > & xrpjGD_Param1, string & strParam2, bool bParam3);
	};

	class MRZTypesHolder
	{
	public:
		MRZTypesHolder();
		~MRZTypesHolder();

		static int docTypeByFormat(rapidjson::GenericDocument<rapidjson::UTF8<char> > & xrpjGD_Param1, string & strParam2);
	};

	string translateToLatin(wstring &);
	string convertCodeToName(string &);
	wstring SimplifiedToUnicode(string &);
	wstring TraditionalToUnicode(string &);
	string translateToRussianUTF8(string &);
	string translateToChinese(string &);
	int verifyCountryCode(string &, bool);
	string convert2to3(string &);
	string rusVisaCodeUTF8(string &);
	bool isValidRusVisaCode(string &);
	int getDocTypeByFormatName(string &);
}