#pragma once
#include "pch.h"
#include "json/Value.h"
#include "moduleprocessgl.h"
#include "ProcessParamsHolder.h"
#include "common/container/RclHolder.h"
#include "processmanagerdefault.h"
#include "sdk/TAuthenticity.h"
#include "sdk/TBarcodesMT.h"
#include "sdk/TBind.h"
#include "sdk/TCodeConverter.h"
#include "sdk/TCreditCard.h"
#include "sdk/TDocBoundLocator.h"
#include "sdk/TExtBarcodeReader.h"
#include "sdk/TExtPortraitProcessor.h"
#include "sdk/TFaceDetector.h"
#include "sdk/TGraphicFieldCropper.h"
#include "sdk/TId3Rus.h"
#include "sdk/TImageQuality.h"
#include "sdk/TImSegger.h"
#include "sdk/TMrzDetector.h"
#include "sdk/TLex.h"
#include "sdk/TRecPass.h"
#include "sdk/TCanDetector.h"
#include "imagemanipulation.h"
#include "common/ModuleOrchestrator.h"
#include "common/Timer.h"

namespace procmgrdefault
{
	namespace jsonResponse
	{
		int getProcessingFinishedStatus(Json::Value const&, int);
		namespace def
		{
			string notReady();
		}
	}

	namespace jsonRequest
	{
		string getScenario(Json::Value &);
		processmanagerdefault::scenario::eProcessScenario getScenarioType(Json::Value &a1);
		bool getMRZProcessAsImage(Json::Value &);
	}

	namespace utils
	{
		void flipResults(common::container::RclHolder &, tagSIZE &, ProcessParamsHolder &);
		void getModulesAndScenariosInfo(vector<processmanagerdefault::IModuleStatus *> &, string &); //###
	}

	class ContainerTypeContol
	{
	public:
		ContainerTypeContol();
		~ContainerTypeContol();
	public:
		vector<int> m_vCTC_0;
		vector<int> m_vCTC_C;
		vector<int> m_vCTC_18;
	};

	class ProcMgrDefault : public moduleprocessgl::IProcessFunction
	{
	public:
		ProcMgrDefault();
		~ProcMgrDefault();

		void AddVisualFieldsFilter(ProcessParamsHolder &);
		void analyzeAuthResult(common::container::RclHolder &, string &);
		int checkTimeout(void);
		void Clear(void);
		void free(void);
		void generateResult(int, Json::Value const&, ProcessParamsHolder &, string &, void **);
		vector<int> getCommands(void);
		void init(void *, char *);
		bool isNeedStopByTimers(Json::Value const&);
		int process(int, void *, const char *, void **, char **);
		void StartNewDocument(void);
		void StartNewFrame(void);
		void StartNewPage(bool);
		static void setDPIFromBoundsResult(common::container::RclHolder &);
		void setProcessParamsByLoadedModules(ProcessParamsHolder &);
		void uniteRcl_Frame_sourceRcl(common::container::RclHolder &, TResultContainerList *);
		void updateDocIdListForCurrentFramesSeries(bool);
		void updateStatusFrameSeriesWithoutMrz(void);
		void updateUnprocessedDocIdListForDoc(int &);
		void updateWorkDpi(Json::Value const&, common::container::RclHolder &);
	public:
		common::container::RclHolder                   m_xPMD_4;
		common::container::RclHolder                   m_xPMD_18;
		common::container::RclHolder                   m_xPMD_2C;
		common::container::RclHolder                   m_xPMD_40;
		common::container::RclHolder                   m_xPMD_54;
		common::container::RclHolder                   m_xPMD_68;
		string				                           m_bsPMD_7C;
		int                                            m_nPMD_88;
		int                                            m_nPMD_8C;
		int                                            m_nPMD_90;
		bool                                           m_fPMD_94;
		bool                                           m_fPMD_95;
		bool                                           m_fPMD_96;
		vector<int>                                    m_vPMD_98;
		vector<int>                                    m_vPMD_A4;
		bool                                           m_fPMD_B0;
		string									       m_bsPMD_B4;
		common::Timer                                  m_xPMD_C0;
		common::Timer                                  m_xPMD_E0;
		TImageQuality                                  m_xPMD_ImageQuality;
		TDocBoundLocator                               m_xPMD_DocBoundLocator;
		TMrzDetector                                   m_xPMD_MrzDetector;
		TLex                                           m_xPMD_Lex;
		TRecPass                                       m_xPMD_RecPass;
		TBind                                          m_xPMD_Bind;
		TImSegger                                      m_xPMD_ImSegger;
		TId3Rus                                        m_xPMD_Id3Rus;
		TBarcodesMT                                    m_xPMD_BarcodesMT;
		TExtBarcodeReader                              m_xPMD_ExtBarcodeReader;
		TCodeConverter                                 m_xPMD_CodeConverter;
		TGraphicFieldCropper                           m_xPMD_GraphicFieldCropper;
		//TRFID                                          m_xPMD_2B0;
		TCanDetector                                   m_xPMD_CanDetector;
		TCreditCard                                    m_xPMD_CreditCard;
		TAuthenticity                                  m_xPMD_Authenticity;
		TExtPortraitProcessor                          m_xPMD_ExtPortraitProcessor;
		TFaceDetector                                  m_xPMD_FaceDetector;
		int                                            m_nPMD_3A4;
		bool                                           m_fPMD_3A8;
		imagemanipulation::integralImageData           m_xPMD_3AC;
		vector<processmanagerdefault::IModuleStatus *> m_vPMD_458;
		vector<TSDKProcessingClass *>                  m_vPMD_464;
		processmanagerdefault::scenario::eProcessScenario        m_ePMD_470;
		ContainerTypeContol                            m_xPMD_474;
		int                                            m_nPMD_498;
		common::Timer                                  m_xPMD_4A0;
		common::Timer                                  m_xPMD_4C0;
		common::Timer                                  m_xPMD_4E0;
		int                                            m_nPMD_500;
	};	
}