# RapidXML
C++ XML Parser. http://rapidxml.sourceforge.net/

# Release notes
Version 1.15 features:
* RapidXML is delivered as a VS2019, VC142 static library
* RapidXMLSTD.hpp - A C-like wrapper that is exposed by the library. It reduces the verbosity of raw RapidXML classes, making it easier to get started with this project.